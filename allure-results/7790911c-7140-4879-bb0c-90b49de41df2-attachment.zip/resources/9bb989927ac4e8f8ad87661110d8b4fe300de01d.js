import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { notasFinancierasModuleConfig } from "/src/features/notas_financieras/notas_financieras.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue, formatLinkedSalesInvoiceRef } from "/src/utils/formatters.ts";
import { formatTaxRateCell, getAppliedTaxDisplayName } from "/src/utils/taxDisplay.ts";
import { isClientLeyExportacionTdfExempt } from "/src/utils/clientTaxExemption.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) return 0;
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const NotasFinancierasDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: financialNote, loading, error } = useCrudItem(notasFinancierasModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const isClientTaxExempt = useMemo(
    () => isClientLeyExportacionTdfExempt(financialNote?.client),
    [financialNote?.client]
  );
  const calculatedTotals = useMemo(() => {
    if (!financialNote || !financialNote.items?.length) return { subtotal: 0, discountAmount: 0, taxBase: 0, totalTaxes: 0 };
    const subtotal = financialNote.items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const discountAmount = subtotal * (Number(financialNote.discount_percentage) || 0) / 100;
    const withouttax = isClientTaxExempt ? 0 : financialNote.withouttax_amount ?? 0;
    const taxBase = Math.max(0, subtotal - discountAmount - withouttax);
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (financialNote.has_item_level_taxes && financialNote.items.length > 0) {
        totalTaxes = financialNote.items.reduce((sum, it) => sum + getItemTaxTotal(it), 0);
      } else {
        totalTaxes = (financialNote.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    return { subtotal, discountAmount, taxBase, totalTaxes };
  }, [financialNote, isClientTaxExempt]);
  const aggregatedTaxes = useMemo(() => {
    if (!financialNote || isClientTaxExempt) return [];
    const items2 = financialNote.items || [];
    if (financialNote.has_item_level_taxes && items2.length > 0) {
      const map = /* @__PURE__ */ new Map();
      for (const item of items2) {
        for (const t of item.taxes || []) {
          const key = t.tax_id;
          if (!map.has(key)) {
            map.set(key, {
              tax_id: t.tax_id,
              tax_name: t.tax_name ?? void 0,
              tax_type_label: t.tax_type_label,
              rate: t.rate,
              amount: 0,
              tax_type: t.tax_type
            });
          }
          map.get(key).amount += Number(t.amount);
        }
      }
      return Array.from(map.values());
    }
    return (financialNote.taxes || []).map((t) => ({
      tax_id: t.tax_id,
      tax_name: t.tax_name,
      tax_type_label: t.tax_type_label,
      rate: t.rate,
      amount: Number(t.amount),
      tax_type: t.tax_type
    }));
  }, [financialNote, isClientTaxExempt]);
  const handlePrint = async () => {
    if (!financialNote) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/financial-notes/${financialNote.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
    lineNumber: 123,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la nota financiera: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
    lineNumber: 124,
    columnNumber: 21
  }, this);
  if (!financialNote) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el documento." }, void 0, false, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
    lineNumber: 125,
    columnNumber: 30
  }, this);
  const isDebit = financialNote.type === "DEBIT";
  const items = financialNote.items || [];
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(notasFinancierasModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 138,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 137,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "NF: ",
            financialNote.series,
            "-",
            financialNote.voucher_number
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 141,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${isDebit ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`, children: isDebit ? "Nota de Débito" : "Nota de Crédito" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 144,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 140,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 136,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handlePrint,
          disabled: isPrinting,
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
          children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 159,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 161,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 152,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 151,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
      lineNumber: 135,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      financialNote.cae_number && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "CAE Autorizado" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 172,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-xl font-mono font-bold text-green-900 tracking-wider", children: financialNote.cae_number }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 173,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 171,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "Vencimiento CAE" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 176,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-lg font-medium text-green-900", children: formatValue(financialNote.cae_due_date ?? void 0, "date") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 177,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 175,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 170,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 182,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: /* @__PURE__ */ jsxDEV(Link, { to: `/clientes/${financialNote.client_id ?? financialNote.client?.id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: financialNote.client?.name || financialNote.client_name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 184,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 183,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 181,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 190,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatValue(financialNote.issue_date, "date") }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 191,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 189,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Factura Asociada" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 194,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: financialNote.sales_invoice ? /* @__PURE__ */ jsxDEV(Link, { to: `/facturas-de-venta/${financialNote.sales_invoice.id}`, className: "text-indigo-600 hover:underline", children: formatLinkedSalesInvoiceRef(financialNote.sales_invoice) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 197,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: "Independiente" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 201,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 195,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 193,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 206,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: financialNote.salesperson?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 207,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 205,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 210,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: financialNote.currency?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 211,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 209,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de Cambio" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 214,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: Number(financialNote.exchange_rate).toFixed(2) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 215,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 213,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Concepto" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 218,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: financialNote.concept || "—" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 219,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 217,
        columnNumber: 17
      }, this),
      financialNote.afip_pos && /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Punto de Venta" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 223,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: financialNote.afip_pos }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 224,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 222,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
      lineNumber: 168,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Ítems de la Nota" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 231,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Descripción" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 236,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Código Concepto" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 237,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 238,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 239,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Desc. %" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 240,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 241,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 242,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 235,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 234,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
          const lineSub = Number(item.quantity) * Number(item.unit_price);
          const lineDisc = lineSub * (Number(item.discount_percentage) || 0) / 100;
          const lineTotal = lineSub - lineDisc + (!isClientTaxExempt && financialNote.has_item_level_taxes ? getItemTaxTotal(item) : 0);
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6 font-medium text-gray-900", children: item.description }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 252,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.concept_code }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 253,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 254,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 255,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: [
              Number(item.discount_percentage || 0).toFixed(2),
              "%"
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 256,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSub - lineDisc, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 257,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 258,
              columnNumber: 41
            }, this)
          ] }, `line-${item.line_number}-${index}`, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 251,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 245,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 233,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 232,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
      lineNumber: 230,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 272,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900 whitespace-pre-wrap", children: financialNote.notes || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 273,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 271,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 270,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 269,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: aggregatedTaxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 281,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 286,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 287,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 288,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 285,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 284,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: aggregatedTaxes.map(
            (tax, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6", children: getAppliedTaxDisplayName(tax) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
                lineNumber: 294,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatTaxRateCell(tax) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
                lineNumber: 295,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
                lineNumber: 296,
                columnNumber: 49
              }, this)
            ] }, tax.tax_id || index, true, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 293,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 291,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 283,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 282,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 280,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 278,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 308,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 309,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 307,
          columnNumber: 21
        }, this),
        calculatedTotals.discountAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Descuento:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 313,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.discountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 314,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 312,
          columnNumber: 11
        }, this),
        !isClientTaxExempt && (financialNote.withouttax_amount ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-red-600`, children: "Valor No Gravado:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 319,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-red-600`, children: [
            "- ",
            formatValue(financialNote.withouttax_amount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 320,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 318,
          columnNumber: 11
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 326,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-base")} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 327,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 325,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: financialNote.has_item_level_taxes ? "Impuestos (Item):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 330,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
              lineNumber: 333,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 329,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 324,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 338,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-lg")} font-bold text-indigo-600`, children: formatValue(financialNote.total_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
            lineNumber: 339,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
          lineNumber: 337,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
        lineNumber: 306,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
      lineNumber: 268,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx",
    lineNumber: 133,
    columnNumber: 5
  }, this);
};
_s(NotasFinancierasDetailPage, "Of4jVdqlYXPXenkm6fF6AzmGHuY=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = NotasFinancierasDetailPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUd3QixTQStDSixVQS9DSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2R3hCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxvQ0FBd0Q7QUFDakUsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLGVBQWU7QUFDckMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGFBQWFDLG1DQUFtQztBQUN6RCxTQUFTQyxtQkFBbUJDLGdDQUFnQztBQUM1RCxTQUFTQyx1Q0FBdUM7QUFDaEQsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFDbEQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsa0JBQWtCQSxDQUFDQyxTQUFvQztBQUN6RCxNQUFJLENBQUNBLEtBQUtDLFNBQVNELEtBQUtDLE1BQU1DLFdBQVcsRUFBRyxRQUFPO0FBQ25ELFNBQU9GLEtBQUtDLE1BQU1FLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFDdEU7QUFFTyxhQUFNQyw2QkFBNkJBLE1BQU07QUFBQUMsS0FBQTtBQUM1QyxRQUFNLEVBQUVDLEdBQUcsSUFBSS9CLFVBQTBCO0FBQ3pDLFFBQU1nQyxXQUFXL0IsWUFBWTtBQUM3QixRQUFNLEVBQUVvQixNQUFNWSxlQUFlQyxTQUFTQyxNQUFNLElBQUk5QixZQUEyQkMsOEJBQThCeUIsRUFBRTtBQUMzRyxRQUFNLENBQUNLLFlBQVlDLGFBQWEsSUFBSWpDLFNBQVMsS0FBSztBQUVsRCxRQUFNa0Msb0JBQW9CbkM7QUFBQUEsSUFDdEIsTUFBTVksZ0NBQWdDa0IsZUFBZU0sTUFBTTtBQUFBLElBQzNELENBQUNOLGVBQWVNLE1BQU07QUFBQSxFQUMxQjtBQUVBLFFBQU1DLG1CQUFtQnJDLFFBQVEsTUFBTTtBQUNuQyxRQUFJLENBQUM4QixpQkFBaUIsQ0FBQ0EsY0FBY1EsT0FBT2xCLE9BQVEsUUFBTyxFQUFFbUIsVUFBVSxHQUFHQyxnQkFBZ0IsR0FBR0MsU0FBUyxHQUFHQyxZQUFZLEVBQUU7QUFDdkgsVUFBTUgsV0FBV1QsY0FBY1EsTUFBTWpCLE9BQU8sQ0FBQ3NCLEdBQUdDLE1BQU1ELElBQUluQixPQUFPb0IsRUFBRUMsUUFBUSxJQUFJckIsT0FBT29CLEVBQUVFLFVBQVUsR0FBRyxDQUFDO0FBQ3RHLFVBQU1OLGlCQUFpQkQsWUFBWWYsT0FBT00sY0FBY2lCLG1CQUFtQixLQUFLLEtBQUs7QUFDckYsVUFBTUMsYUFBYWIsb0JBQW9CLElBQUtMLGNBQWNtQixxQkFBcUI7QUFDL0UsVUFBTVIsVUFBVVMsS0FBS0MsSUFBSSxHQUFHWixXQUFXQyxpQkFBaUJRLFVBQVU7QUFFbEUsUUFBSU4sYUFBYTtBQUNqQixRQUFJLENBQUNQLG1CQUFtQjtBQUNwQixVQUFJTCxjQUFjc0Isd0JBQXdCdEIsY0FBY1EsTUFBTWxCLFNBQVMsR0FBRztBQUN0RXNCLHFCQUFhWixjQUFjUSxNQUFNakIsT0FBTyxDQUFDQyxLQUFLK0IsT0FBTy9CLE1BQU1MLGdCQUFnQm9DLEVBQUUsR0FBRyxDQUFDO0FBQUEsTUFDckYsT0FBTztBQUNIWCxzQkFBY1osY0FBY1gsU0FBUyxJQUFJRSxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU1FLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQUEsTUFDN0Y7QUFBQSxJQUNKO0FBRUEsV0FBTyxFQUFFYyxVQUFVQyxnQkFBZ0JDLFNBQVNDLFdBQVc7QUFBQSxFQUMzRCxHQUFHLENBQUNaLGVBQWVLLGlCQUFpQixDQUFDO0FBRXJDLFFBQU1tQixrQkFBa0J0RCxRQUFRLE1BQU07QUFDbEMsUUFBSSxDQUFDOEIsaUJBQWlCSyxrQkFBbUIsUUFBTztBQUNoRCxVQUFNRyxTQUFRUixjQUFjUSxTQUFTO0FBQ3JDLFFBQUlSLGNBQWNzQix3QkFBd0JkLE9BQU1sQixTQUFTLEdBQUc7QUFDeEQsWUFBTW1DLE1BQU0sb0JBQUlDLElBQWdJO0FBQ2hKLGlCQUFXdEMsUUFBUW9CLFFBQU87QUFDdEIsbUJBQVdtQixLQUFLdkMsS0FBS0MsU0FBUyxJQUFJO0FBQzlCLGdCQUFNdUMsTUFBTUQsRUFBRUU7QUFDZCxjQUFJLENBQUNKLElBQUlLLElBQUlGLEdBQUcsR0FBRztBQUNmSCxnQkFBSU0sSUFBSUgsS0FBSztBQUFBLGNBQ1RDLFFBQVFGLEVBQUVFO0FBQUFBLGNBQ1ZHLFVBQVVMLEVBQUVLLFlBQVlDO0FBQUFBLGNBQ3hCQyxnQkFBZ0JQLEVBQUVPO0FBQUFBLGNBQ2xCQyxNQUFNUixFQUFFUTtBQUFBQSxjQUNSeEMsUUFBUTtBQUFBLGNBQ1J5QyxVQUFVVCxFQUFFUztBQUFBQSxZQUNoQixDQUFDO0FBQUEsVUFDTDtBQUNBWCxjQUFJWSxJQUFJVCxHQUFHLEVBQUdqQyxVQUFVRCxPQUFPaUMsRUFBRWhDLE1BQU07QUFBQSxRQUMzQztBQUFBLE1BQ0o7QUFDQSxhQUFPMkMsTUFBTUMsS0FBS2QsSUFBSWUsT0FBTyxDQUFDO0FBQUEsSUFDbEM7QUFDQSxZQUFReEMsY0FBY1gsU0FBUyxJQUFJb0MsSUFBSSxDQUFBRSxPQUFNO0FBQUEsTUFDekNFLFFBQVFGLEVBQUVFO0FBQUFBLE1BQ1ZHLFVBQVVMLEVBQUVLO0FBQUFBLE1BQ1pFLGdCQUFnQlAsRUFBRU87QUFBQUEsTUFDbEJDLE1BQU1SLEVBQUVRO0FBQUFBLE1BQ1J4QyxRQUFRRCxPQUFPaUMsRUFBRWhDLE1BQU07QUFBQSxNQUN2QnlDLFVBQVVULEVBQUVTO0FBQUFBLElBQ2hCLEVBQUU7QUFBQSxFQUNOLEdBQUcsQ0FBQ3BDLGVBQWVLLGlCQUFpQixDQUFDO0FBRXJDLFFBQU1vQyxjQUFjLFlBQVk7QUFDNUIsUUFBSSxDQUFDekMsY0FBZTtBQUVwQixVQUFNMEMsVUFBVTNELGdCQUFnQjtBQUNoQyxRQUFJLENBQUMyRCxTQUFTO0FBQ1Z6RCxZQUFNaUIsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFFLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNBLFlBQU1wQixpQkFBaUIwRCxTQUFTLG9CQUFvQjFDLGNBQWNGLEVBQUUsTUFBTTtBQUFBLElBQzlFLFNBQVNJLFFBQU87QUFDWixVQUFJLENBQUN3QyxRQUFRQyxPQUFPQyxPQUFRRixTQUFRQyxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFRNUMsTUFBTSw0QkFBNEJBLE1BQUs7QUFDL0NqQixZQUFNaUIsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dFLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFFQSxNQUFJSCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLElBQXFDQTtBQUFBQSxPQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1GO0FBQ3JHLE1BQUksQ0FBQ0YsY0FBZSxRQUFPLHVCQUFDLFNBQUksV0FBVSw2QkFBNEIsNENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUU7QUFFbEcsUUFBTStDLFVBQVUvQyxjQUFjZ0QsU0FBUztBQUN2QyxRQUFNeEMsUUFBUVIsY0FBY1EsU0FBUztBQUNyQyxRQUFNeUMsa0JBQWtCO0FBQ3hCLFFBQU1DLGtCQUFrQjtBQUV4QixTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFFWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwrQkFDWDtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNbkQsU0FBU2Isa0JBQWtCYiw2QkFBNkI4RSxTQUFTLENBQUMsR0FBRyxXQUFVLG9EQUNsRyxpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsaURBQStDO0FBQUE7QUFBQSxZQUNwRG5ELGNBQWNvRDtBQUFBQSxZQUFPO0FBQUEsWUFBRXBELGNBQWNxRDtBQUFBQSxlQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVcsdURBQXVETixVQUFVLDRCQUE0Qiw2QkFBNkIsSUFFdElBLG9CQUFVLG1CQUFtQixxQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDWDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBU047QUFBQUEsVUFDVCxVQUFVdEM7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVEEsdUJBQ0csdUJBQUMsYUFBVSxXQUFVLDBCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxJQUUzQyx1QkFBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQTtBQUFBLFFBVHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBLEtBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBR0EsdUJBQUMsUUFBRyxXQUFVLGtFQUNUSDtBQUFBQSxvQkFBY3NELGNBQ1gsbUNBQ0k7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0VBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTJELDhCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBQ3ZGLHVCQUFDLFFBQUcsV0FBVSxrRUFBa0V0RCx3QkFBY3NELGNBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlHO0FBQUEsYUFGN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsb0VBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTJELCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMkM1RSxzQkFBWXNCLGNBQWN1RCxnQkFBZ0J0QixRQUFXLE1BQU0sS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0g7QUFBQSxhQUYxSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUosdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXZ0IsaUJBQWlCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdkMsdUJBQUMsUUFBRyxXQUFVLGdDQUNWLGlDQUFDLFFBQUssSUFBSSxhQUFhakQsY0FBY3dELGFBQWF4RCxjQUFjTSxRQUFRUixFQUFFLElBQUksV0FBVSx5REFDbkZFLHdCQUFjTSxRQUFRbUQsUUFBUXpELGNBQWMwRCxlQUFlLFNBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdULGlCQUFpQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQzdDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0N2RSxzQkFBWXNCLGNBQWMyRCxZQUFZLE1BQU0sS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXVixpQkFBaUIsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxRQUNoRCx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1RqRCx3QkFBYzRELGdCQUNYLHVCQUFDLFFBQUssSUFBSSxzQkFBc0I1RCxjQUFjNEQsY0FBYzlELEVBQUUsSUFBSSxXQUFVLG1DQUN2RW5CLHNDQUE0QnFCLGNBQWM0RCxhQUFhLEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkMsS0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV1gsaUJBQWlCLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ2pELHdCQUFjNkQsYUFBYUosUUFBUSxPQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsV0FGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdSLGlCQUFpQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0NqRCx3QkFBYzhELFVBQVVMLFFBQVEsT0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFdBRnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXUixpQkFBaUIsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDdkQsaUJBQU9NLGNBQWMrRCxhQUFhLEVBQUVDLFFBQVEsQ0FBQyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUEsV0FGakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdmLGlCQUFpQix3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFFBQ3hDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0NqRCx3QkFBY2lFLFdBQVcsT0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0NqRSxjQUFja0UsWUFDWCx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdqQixpQkFBaUIsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDakQsd0JBQWNrRSxZQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsV0FGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0F6RFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJEQTtBQUFBLElBR0EsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsV0FBVSwrQ0FBOEMsZ0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxTQUFJLFdBQVUsMkVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsMkJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsVUFDbEcsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCwrQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx1QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFFBQUcsV0FBVSwyRUFBMEUsMkJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1HO0FBQUEsYUFQdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1oxRCxnQkFBTWlCLElBQUksQ0FBQ3JDLE1BQU0rRSxVQUFVO0FBQ3hCLGdCQUFNQyxVQUFVMUUsT0FBT04sS0FBSzJCLFFBQVEsSUFBSXJCLE9BQU9OLEtBQUs0QixVQUFVO0FBQzlELGdCQUFNcUQsV0FBV0QsV0FBVzFFLE9BQU9OLEtBQUs2QixtQkFBbUIsS0FBSyxLQUFLO0FBQ3JFLGdCQUFNcUQsWUFBWUYsVUFBVUMsWUFBWSxDQUFDaEUscUJBQXFCTCxjQUFjc0IsdUJBQXVCbkMsZ0JBQWdCQyxJQUFJLElBQUk7QUFDM0gsaUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBNERBLGVBQUttRixlQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRjtBQUFBLFlBQzNGLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNuRixlQUFLb0YsZ0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsWUFDbkUsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzlFLGlCQUFPTixLQUFLMkIsUUFBUSxFQUFFaUQsUUFBUSxDQUFDLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0YsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3RGLHNCQUFZVSxLQUFLNEIsWUFBWSxVQUFVLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckcsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3RCO0FBQUFBLHFCQUFPTixLQUFLNkIsdUJBQXVCLENBQUMsRUFBRStDLFFBQVEsQ0FBQztBQUFBLGNBQUU7QUFBQSxpQkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEc7QUFBQSxZQUM5Ryx1QkFBQyxRQUFHLFdBQVUsOENBQThDdEYsc0JBQVkwRixVQUFVQyxVQUFVLFVBQVUsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxZQUN4Ryx1QkFBQyxRQUFHLFdBQVUsdUVBQXVFM0Ysc0JBQVk0RixXQUFXLFVBQVUsS0FBdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxlQVBuSCxRQUFRbEYsS0FBS3FGLFdBQVcsSUFBSU4sS0FBSyxJQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsUUFFUixDQUFDLEtBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBLEtBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxTQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1gsaUNBQUMsU0FBSSxXQUFVLGFBQ1gsaUNBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUcsV0FBV2xCLGlCQUFpQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFFBQUcsV0FBVSxvREFBb0RqRCx3QkFBYzBFLFNBQVMsT0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFdBRmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNWbEQsMEJBQWdCbEMsU0FBUyxLQUN0Qix1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUNyRSx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsWUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1prQywwQkFBZ0JDO0FBQUFBLFlBQUksQ0FBQ2hDLEtBQUswRSxVQUN2Qix1QkFBQyxRQUNHO0FBQUEscUNBQUMsUUFBRyxXQUFVLDREQUE0RHRGLG1DQUF5QlksR0FBRyxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RztBQUFBLGNBQ3hHLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENiLDRCQUFrQmEsR0FBRyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRjtBQUFBLGNBQ25GLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENmLHNCQUFZZSxJQUFJRSxRQUFRLFVBQVUsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0c7QUFBQSxpQkFIM0ZGLElBQUlvQyxVQUFVc0MsT0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFVBQ0gsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQSxLQXhCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVdsQixpQkFBaUIseUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFDM0MsdUJBQUMsVUFBSyxXQUFXQyxpQkFBa0J4RSxzQkFBWTZCLGlCQUFpQkUsVUFBVSxVQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsYUFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ0YsaUJBQWlCRyxpQkFBaUIsS0FDL0IsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXdUMsaUJBQWlCLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQzVDLHVCQUFDLFVBQUssV0FBV0MsaUJBQWlCO0FBQUE7QUFBQSxZQUFHeEUsWUFBWTZCLGlCQUFpQkcsZ0JBQWdCLFVBQVU7QUFBQSxlQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLGFBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUgsQ0FBQ0wsc0JBQXNCTCxjQUFjbUIscUJBQXFCLEtBQUssS0FDNUQsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUc4QixlQUFlLGlCQUFpQixpQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZUFBZSxpQkFBaUI7QUFBQTtBQUFBLFlBQUd4RSxZQUFZc0IsY0FBY21CLG1CQUFvQixVQUFVO0FBQUEsZUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUg7QUFBQSxhQUZySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVILENBQUNkLHFCQUNFLG1DQUNJO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXLEdBQUc0QyxlQUFlLGtCQUFrQiwrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZ0JBQWdCeUIsUUFBUSxXQUFXLFdBQVcsQ0FBQyxrQkFBbUJqRyxzQkFBWTZCLGlCQUFpQkksU0FBUyxVQUFVLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdJO0FBQUEsZUFGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXc0MsaUJBQ1pqRCx3QkFBY3NCLHVCQUF1QixzQkFBc0IseUJBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVzRCLGlCQUFpQjtBQUFBO0FBQUEsY0FBR3hFLFlBQVk2QixpQkFBaUJLLFlBQVksVUFBVTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBSjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUosdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUdxQyxlQUFlLDBCQUEwQiw0QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZ0JBQWdCeUIsUUFBUSxXQUFXLFNBQVMsQ0FBQyw4QkFBK0JqRyxzQkFBWXNCLGNBQWM0RSxjQUFjLFVBQVUsS0FBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0o7QUFBQSxhQUZ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBO0FBQUEsU0F6RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBFQTtBQUFBLE9Bak5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrTkE7QUFFUjtBQUFFL0UsR0FsVFdELDRCQUEwQjtBQUFBLFVBQ3BCN0IsV0FDRUMsYUFDK0JJLFdBQVc7QUFBQTtBQUFBeUcsS0FIbERqRjtBQUEwQixJQUFBaUY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiTGluayIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUNydWRJdGVtIiwibm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZyIsIkxvYWRpbmdTcGlubmVyIiwiSW9BcnJvd0JhY2siLCJJb1ByaW50IiwiRmFTcGlubmVyIiwiZm9ybWF0VmFsdWUiLCJmb3JtYXRMaW5rZWRTYWxlc0ludm9pY2VSZWYiLCJmb3JtYXRUYXhSYXRlQ2VsbCIsImdldEFwcGxpZWRUYXhEaXNwbGF5TmFtZSIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJiZWdpblBkZlByZXZpZXciLCJmaW5pc2hQZGZQcmV2aWV3IiwidG9hc3QiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImdldEl0ZW1UYXhUb3RhbCIsIml0ZW0iLCJ0YXhlcyIsImxlbmd0aCIsInJlZHVjZSIsInN1bSIsInRheCIsIk51bWJlciIsImFtb3VudCIsIk5vdGFzRmluYW5jaWVyYXNEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiZmluYW5jaWFsTm90ZSIsImxvYWRpbmciLCJlcnJvciIsImlzUHJpbnRpbmciLCJzZXRJc1ByaW50aW5nIiwiaXNDbGllbnRUYXhFeGVtcHQiLCJjbGllbnQiLCJjYWxjdWxhdGVkVG90YWxzIiwiaXRlbXMiLCJzdWJ0b3RhbCIsImRpc2NvdW50QW1vdW50IiwidGF4QmFzZSIsInRvdGFsVGF4ZXMiLCJzIiwiaSIsInF1YW50aXR5IiwidW5pdF9wcmljZSIsImRpc2NvdW50X3BlcmNlbnRhZ2UiLCJ3aXRob3V0dGF4Iiwid2l0aG91dHRheF9hbW91bnQiLCJNYXRoIiwibWF4IiwiaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMiLCJpdCIsImFnZ3JlZ2F0ZWRUYXhlcyIsIm1hcCIsIk1hcCIsInQiLCJrZXkiLCJ0YXhfaWQiLCJoYXMiLCJzZXQiLCJ0YXhfbmFtZSIsInVuZGVmaW5lZCIsInRheF90eXBlX2xhYmVsIiwicmF0ZSIsInRheF90eXBlIiwiZ2V0IiwiQXJyYXkiLCJmcm9tIiwidmFsdWVzIiwiaGFuZGxlUHJpbnQiLCJzZXNzaW9uIiwid2luZG93IiwiY2xvc2VkIiwiY2xvc2UiLCJjb25zb2xlIiwiaXNEZWJpdCIsInR5cGUiLCJ0b3RhbExhYmVsU3R5bGUiLCJ0b3RhbFZhbHVlU3R5bGUiLCJiYXNlUm91dGUiLCJzZXJpZXMiLCJ2b3VjaGVyX251bWJlciIsImNhZV9udW1iZXIiLCJjYWVfZHVlX2RhdGUiLCJjbGllbnRfaWQiLCJuYW1lIiwiY2xpZW50X25hbWUiLCJpc3N1ZV9kYXRlIiwic2FsZXNfaW52b2ljZSIsInNhbGVzcGVyc29uIiwiY3VycmVuY3kiLCJleGNoYW5nZV9yYXRlIiwidG9GaXhlZCIsImNvbmNlcHQiLCJhZmlwX3BvcyIsImluZGV4IiwibGluZVN1YiIsImxpbmVEaXNjIiwibGluZVRvdGFsIiwiZGVzY3JpcHRpb24iLCJjb25jZXB0X2NvZGUiLCJsaW5lX251bWJlciIsIm5vdGVzIiwicmVwbGFjZSIsInRvdGFsX2Ftb3VudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzRmluYW5jaWVyYXNEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgbm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZywgdHlwZSBGaW5hbmNpYWxOb3RlIH0gZnJvbSAnLi4vbm90YXNfZmluYW5jaWVyYXMuY29uZmlnJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9QcmludCB9IGZyb20gJ3JlYWN0LWljb25zL2lvNSc7XG5pbXBvcnQgeyBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSwgZm9ybWF0TGlua2VkU2FsZXNJbnZvaWNlUmVmIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBmb3JtYXRUYXhSYXRlQ2VsbCwgZ2V0QXBwbGllZFRheERpc3BsYXlOYW1lIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdGF4RGlzcGxheSc7XG5pbXBvcnQgeyBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY2xpZW50VGF4RXhlbXB0aW9uJztcbmltcG9ydCB7IGJlZ2luUGRmUHJldmlldywgZmluaXNoUGRmUHJldmlldyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuY29uc3QgZ2V0SXRlbVRheFRvdGFsID0gKGl0ZW06IEZpbmFuY2lhbE5vdGVbJ2l0ZW1zJ11bMF0pID0+IHtcbiAgICBpZiAoIWl0ZW0udGF4ZXMgfHwgaXRlbS50YXhlcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICAgIHJldHVybiBpdGVtLnRheGVzLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG59O1xuXG5leHBvcnQgY29uc3QgTm90YXNGaW5hbmNpZXJhc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IGZpbmFuY2lhbE5vdGUsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxGaW5hbmNpYWxOb3RlPihub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgW2lzUHJpbnRpbmcsIHNldElzUHJpbnRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgaXNDbGllbnRUYXhFeGVtcHQgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0KGZpbmFuY2lhbE5vdGU/LmNsaWVudCksXG4gICAgICAgIFtmaW5hbmNpYWxOb3RlPy5jbGllbnRdXG4gICAgKTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFmaW5hbmNpYWxOb3RlIHx8ICFmaW5hbmNpYWxOb3RlLml0ZW1zPy5sZW5ndGgpIHJldHVybiB7IHN1YnRvdGFsOiAwLCBkaXNjb3VudEFtb3VudDogMCwgdGF4QmFzZTogMCwgdG90YWxUYXhlczogMCB9O1xuICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IGZpbmFuY2lhbE5vdGUuaXRlbXMucmVkdWNlKChzLCBpKSA9PiBzICsgTnVtYmVyKGkucXVhbnRpdHkpICogTnVtYmVyKGkudW5pdF9wcmljZSksIDApO1xuICAgICAgICBjb25zdCBkaXNjb3VudEFtb3VudCA9IHN1YnRvdGFsICogKE51bWJlcihmaW5hbmNpYWxOb3RlLmRpc2NvdW50X3BlcmNlbnRhZ2UpIHx8IDApIC8gMTAwO1xuICAgICAgICBjb25zdCB3aXRob3V0dGF4ID0gaXNDbGllbnRUYXhFeGVtcHQgPyAwIDogKGZpbmFuY2lhbE5vdGUud2l0aG91dHRheF9hbW91bnQgPz8gMCk7XG4gICAgICAgIGNvbnN0IHRheEJhc2UgPSBNYXRoLm1heCgwLCBzdWJ0b3RhbCAtIGRpc2NvdW50QW1vdW50IC0gd2l0aG91dHRheCk7XG5cbiAgICAgICAgbGV0IHRvdGFsVGF4ZXMgPSAwO1xuICAgICAgICBpZiAoIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICBpZiAoZmluYW5jaWFsTm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiBmaW5hbmNpYWxOb3RlLml0ZW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICB0b3RhbFRheGVzID0gZmluYW5jaWFsTm90ZS5pdGVtcy5yZWR1Y2UoKHN1bSwgaXQpID0+IHN1bSArIGdldEl0ZW1UYXhUb3RhbChpdCksIDApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b3RhbFRheGVzID0gKGZpbmFuY2lhbE5vdGUudGF4ZXMgfHwgW10pLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4geyBzdWJ0b3RhbCwgZGlzY291bnRBbW91bnQsIHRheEJhc2UsIHRvdGFsVGF4ZXMgfTtcbiAgICB9LCBbZmluYW5jaWFsTm90ZSwgaXNDbGllbnRUYXhFeGVtcHRdKTtcblxuICAgIGNvbnN0IGFnZ3JlZ2F0ZWRUYXhlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIWZpbmFuY2lhbE5vdGUgfHwgaXNDbGllbnRUYXhFeGVtcHQpIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBmaW5hbmNpYWxOb3RlLml0ZW1zIHx8IFtdO1xuICAgICAgICBpZiAoZmluYW5jaWFsTm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiBpdGVtcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPG51bWJlciwgeyB0YXhfaWQ6IG51bWJlcjsgdGF4X25hbWU/OiBzdHJpbmc7IHRheF90eXBlX2xhYmVsPzogc3RyaW5nOyByYXRlOiBudW1iZXI7IGFtb3VudDogbnVtYmVyOyB0YXhfdHlwZT86IDEgfCAyIHwgMyB9PigpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB0IG9mIGl0ZW0udGF4ZXMgfHwgW10pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5ID0gdC50YXhfaWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghbWFwLmhhcyhrZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXAuc2V0KGtleSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRheF9pZDogdC50YXhfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHQudGF4X25hbWUgPz8gdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRheF90eXBlX2xhYmVsOiB0LnRheF90eXBlX2xhYmVsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJhdGU6IHQucmF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X3R5cGU6IHQudGF4X3R5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBtYXAuZ2V0KGtleSkhLmFtb3VudCArPSBOdW1iZXIodC5hbW91bnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKG1hcC52YWx1ZXMoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChmaW5hbmNpYWxOb3RlLnRheGVzIHx8IFtdKS5tYXAodCA9PiAoe1xuICAgICAgICAgICAgdGF4X2lkOiB0LnRheF9pZCxcbiAgICAgICAgICAgIHRheF9uYW1lOiB0LnRheF9uYW1lLFxuICAgICAgICAgICAgdGF4X3R5cGVfbGFiZWw6IHQudGF4X3R5cGVfbGFiZWwsXG4gICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCksXG4gICAgICAgICAgICB0YXhfdHlwZTogdC50YXhfdHlwZSxcbiAgICAgICAgfSkpO1xuICAgIH0sIFtmaW5hbmNpYWxOb3RlLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG4gICAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghZmluYW5jaWFsTm90ZSkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBQREYuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc1ByaW50aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZmluaXNoUGRmUHJldmlldyhzZXNzaW9uLCBgL2ZpbmFuY2lhbC1ub3Rlcy8ke2ZpbmFuY2lhbE5vdGUuaWR9L3BkZmApO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgZ2VuZXJhciBlbCBQREY6XCIsIGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRvIGdlbmVyYXIgZWwgY29tcHJvYmFudGUgUERGLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNQcmludGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBhbCBjYXJnYXIgbGEgbm90YSBmaW5hbmNpZXJhOiB7ZXJyb3IgYXMgc3RyaW5nfTwvZGl2PjtcbiAgICBpZiAoIWZpbmFuY2lhbE5vdGUpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5ObyBzZSBlbmNvbnRyw7MgZWwgZG9jdW1lbnRvLjwvZGl2PjtcblxuICAgIGNvbnN0IGlzRGViaXQgPSBmaW5hbmNpYWxOb3RlLnR5cGUgPT09ICdERUJJVCc7XG4gICAgY29uc3QgaXRlbXMgPSBmaW5hbmNpYWxOb3RlLml0ZW1zIHx8IFtdO1xuICAgIGNvbnN0IHRvdGFsTGFiZWxTdHlsZSA9IFwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0ZXh0LXJpZ2h0XCI7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS04XCI+XG4gICAgICAgICAgICB7LyogRU5DQUJFWkFETyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGItNCBtYi00IGJvcmRlci1iIHNtOmZsZXggc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtZ3JheS01MDAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9BcnJvd0JhY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5GOiB7ZmluYW5jaWFsTm90ZS5zZXJpZXN9LXtmaW5hbmNpYWxOb3RlLnZvdWNoZXJfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG10LTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSAke2lzRGViaXQgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnIDogJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRGViaXQgPyAnTm90YSBkZSBEw6liaXRvJyA6ICdOb3RhIGRlIENyw6lkaXRvJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc206bXQtMCBzbTptbC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNQcmludGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzUHJpbnRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb1ByaW50IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIERFVEFMTEVTIERFIENBQkVDRVJBICovfVxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLXgtNCBnYXAteS02IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAge2ZpbmFuY2lhbE5vdGUuY2FlX251bWJlciAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTEgYmctZ3JlZW4tNTAgcC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmVlbi03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5DQUUgQXV0b3JpemFkbzwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14bCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZ3JlZW4tOTAwIHRyYWNraW5nLXdpZGVyXCI+e2ZpbmFuY2lhbE5vdGUuY2FlX251bWJlcn08L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTEgYmctZ3JlZW4tNTAgcC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmVlbi03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5WZW5jaW1pZW50byBDQUU8L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmVlbi05MDBcIj57Zm9ybWF0VmFsdWUoZmluYW5jaWFsTm90ZS5jYWVfZHVlX2RhdGUgPz8gdW5kZWZpbmVkLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5DbGllbnRlPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2NsaWVudGVzLyR7ZmluYW5jaWFsTm90ZS5jbGllbnRfaWQgPz8gZmluYW5jaWFsTm90ZS5jbGllbnQ/LmlkfWB9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbmFuY2lhbE5vdGUuY2xpZW50Py5uYW1lIHx8IGZpbmFuY2lhbE5vdGUuY2xpZW50X25hbWUgfHwgJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RmVjaGEgRW1pc2nDs248L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntmb3JtYXRWYWx1ZShmaW5hbmNpYWxOb3RlLmlzc3VlX2RhdGUsICdkYXRlJyl9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5GYWN0dXJhIEFzb2NpYWRhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaW5hbmNpYWxOb3RlLnNhbGVzX2ludm9pY2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2AvZmFjdHVyYXMtZGUtdmVudGEvJHtmaW5hbmNpYWxOb3RlLnNhbGVzX2ludm9pY2UuaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TGlua2VkU2FsZXNJbnZvaWNlUmVmKGZpbmFuY2lhbE5vdGUuc2FsZXNfaW52b2ljZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+SW5kZXBlbmRpZW50ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VmVuZGVkb3I8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntmaW5hbmNpYWxOb3RlLnNhbGVzcGVyc29uPy5uYW1lIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9Pk1vbmVkYTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e2ZpbmFuY2lhbE5vdGUuY3VycmVuY3k/Lm5hbWUgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VGlwbyBkZSBDYW1iaW88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntOdW1iZXIoZmluYW5jaWFsTm90ZS5leGNoYW5nZV9yYXRlKS50b0ZpeGVkKDIpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q29uY2VwdG88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntmaW5hbmNpYWxOb3RlLmNvbmNlcHQgfHwgJ+KAlCd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7ZmluYW5jaWFsTm90ZS5hZmlwX3BvcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5QdW50byBkZSBWZW50YTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntmaW5hbmNpYWxOb3RlLmFmaXBfcG9zfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2RsPlxuXG4gICAgICAgICAgICB7Lyogw41URU1TICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPsONdGVtcyBkZSBsYSBOb3RhPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+RGVzY3JpcGNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkPDs2RpZ28gQ29uY2VwdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RGVzYy4gJTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+U3VidG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnByLTZcIj5Ub3RhbCBMw61uZWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWIgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGluZURpc2MgPSBsaW5lU3ViICogKE51bWJlcihpdGVtLmRpc2NvdW50X3BlcmNlbnRhZ2UpIHx8IDApIC8gMTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsaW5lVG90YWwgPSBsaW5lU3ViIC0gbGluZURpc2MgKyAoIWlzQ2xpZW50VGF4RXhlbXB0ICYmIGZpbmFuY2lhbE5vdGUuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgPyBnZXRJdGVtVGF4VG90YWwoaXRlbSkgOiAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2BsaW5lLSR7aXRlbS5saW5lX251bWJlcn0tJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02IGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5kZXNjcmlwdGlvbn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0uY29uY2VwdF9jb2RlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntOdW1iZXIoaXRlbS5xdWFudGl0eSkudG9GaXhlZCgyKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUoaXRlbS51bml0X3ByaWNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57TnVtYmVyKGl0ZW0uZGlzY291bnRfcGVyY2VudGFnZSB8fCAwKS50b0ZpeGVkKDIpfSU8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUobGluZVN1YiAtIGxpbmVEaXNjLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBzbTpwci02XCI+e2Zvcm1hdFZhbHVlKGxpbmVUb3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTRUNDScOTTiBERSBUT1RBTEVTICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Ob3RhczwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPntmaW5hbmNpYWxOb3RlLm5vdGVzIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgYXBsaWNhZG9zPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkltcHVlc3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5UYXNhICglKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TW9udG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubWFwKCh0YXgsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3RheC50YXhfaWQgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+e2dldEFwcGxpZWRUYXhEaXNwbGF5TmFtZSh0YXgpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFRheFJhdGVDZWxsKHRheCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlN1YnRvdGFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy5zdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge2NhbGN1bGF0ZWRUb3RhbHMuZGlzY291bnRBbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2N1ZW50bzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuZGlzY291bnRBbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChmaW5hbmNpYWxOb3RlLndpdGhvdXR0YXhfYW1vdW50ID8/IDApID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSB0ZXh0LXJlZC02MDBgfT5WYWxvciBObyBHcmF2YWRvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZX0gdGV4dC1yZWQtNjAwYH0+LSB7Zm9ybWF0VmFsdWUoZmluYW5jaWFsTm90ZS53aXRob3V0dGF4X2Ftb3VudCEsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSBmb250LXNlbWlib2xkYH0+QmFzZSBJbXBvbmlibGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZS5yZXBsYWNlKCd0ZXh0LXNtJywgJ3RleHQtYmFzZScpfSBmb250LXNlbWlib2xkYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaW5hbmNpYWxOb3RlLmhhc19pdGVtX2xldmVsX3RheGVzID8gXCJJbXB1ZXN0b3MgKEl0ZW0pOlwiIDogXCJJbXB1ZXN0b3MgKEdsb2JhbCk6XCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pisge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxUYXhlcywgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTIgYm9yZGVyLXQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtbGcgZm9udC1zZW1pYm9sZGB9PlRvdGFsIEZpbmFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1sZycpfSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+e2Zvcm1hdFZhbHVlKGZpbmFuY2lhbE5vdGUudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuXG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL25vdGFzX2ZpbmFuY2llcmFzL3BhZ2VzL05vdGFzRmluYW5jaWVyYXNEZXRhaWxQYWdlLnRzeCJ9