import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FaChartBar } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
const renderEstadoReporte = (item) => {
  return item.is_active ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800", children: "Activo" }, void 0, false, {
    fileName: "/app/src/features/reportes/reportes.config.tsx",
    lineNumber: 44,
    columnNumber: 3
  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800", children: "Inactivo" }, void 0, false, {
    fileName: "/app/src/features/reportes/reportes.config.tsx",
    lineNumber: 45,
    columnNumber: 3
  }, this);
};
export const reportesModuleConfig = {
  endpoint: "reports",
  // El endpoint del backend suele mantenerse en inglés
  moduleName: "Reporte",
  moduleNamePlural: "Reportes Disponibles",
  baseRoute: "/reportes",
  // Ruta frontend en español
  disableActions: true,
  detail: {
    displayNameKey: "name"
  },
  list: {
    columns: [
      {
        header: "Reporte",
        accessor: "name",
        render: (item) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 h-8 w-8 rounded bg-indigo-100 flex items-center justify-center text-indigo-600 mr-3", children: /* @__PURE__ */ jsxDEV(FaChartBar, {}, void 0, false, {
            fileName: "/app/src/features/reportes/reportes.config.tsx",
            lineNumber: 66,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "/app/src/features/reportes/reportes.config.tsx",
            lineNumber: 65,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.name }, void 0, false, {
            fileName: "/app/src/features/reportes/reportes.config.tsx",
            lineNumber: 68,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/reportes.config.tsx",
          lineNumber: 64,
          columnNumber: 7
        }, this)
      },
      { header: "Código", accessor: "code", render: (item) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs text-gray-500", children: item.code }, void 0, false, {
        fileName: "/app/src/features/reportes/reportes.config.tsx",
        lineNumber: 72,
        columnNumber: 61
      }, this) },
      { header: "Descripción", accessor: "description", render: (item) => /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-sm truncate max-w-xs block", title: item.description, children: item.description }, void 0, false, {
        fileName: "/app/src/features/reportes/reportes.config.tsx",
        lineNumber: 73,
        columnNumber: 73
      }, this) },
      { header: "Estado", accessor: "is_active", render: renderEstadoReporte }
    ]
  },
  relationalFields: {
    idField: "id",
    codeField: "code",
    nameField: "name"
  },
  form: { block: [] }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNVO0FBMUNWLFNBQVNBLGtCQUFrQjtBQXdDM0IsTUFBTUMsc0JBQXNCQSxDQUFDQyxTQUEyQjtBQUNwRCxTQUFPQSxLQUFLQyxZQUNOLHVCQUFDLFVBQUssV0FBVSw2RkFBNEYsc0JBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0gsSUFDbEgsdUJBQUMsVUFBSyxXQUFVLHlGQUF3Rix3QkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnSDtBQUMxSDtBQUVPLGFBQU1DLHVCQUF1RDtBQUFBLEVBQ2hFQyxVQUFVO0FBQUE7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsa0JBQWtCO0FBQUEsRUFDbEJDLFdBQVc7QUFBQTtBQUFBLEVBQ1hDLGdCQUFnQjtBQUFBLEVBQ2hCQyxRQUFRO0FBQUEsSUFDSkMsZ0JBQWdCO0FBQUEsRUFDcEI7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsU0FBUztBQUFBLE1BQ0w7QUFBQSxRQUNJQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFBLENBQUNkLFNBQ0wsdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFHQUNYLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVcsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQTZCQSxlQUFLZSxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLE1BRVI7QUFBQSxNQUNBLEVBQUVILFFBQVEsVUFBVUMsVUFBVSxRQUFRQyxRQUFRQSxDQUFDZCxTQUFTLHVCQUFDLFVBQUssV0FBVSxtQ0FBbUNBLGVBQUtnQixRQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZELEVBQVE7QUFBQSxNQUM3SCxFQUFFSixRQUFRLGVBQWVDLFVBQVUsZUFBZUMsUUFBUUEsQ0FBQ2QsU0FBUyx1QkFBQyxVQUFLLFdBQVUsaURBQWdELE9BQU9BLEtBQUtpQixhQUFjakIsZUFBS2lCLGVBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkcsRUFBUTtBQUFBLE1BQ3ZMLEVBQUVMLFFBQVEsVUFBVUMsVUFBVSxhQUFhQyxRQUFRZixvQkFBb0I7QUFBQSxJQUFDO0FBQUEsRUFFaEY7QUFBQSxFQUVBbUIsa0JBQWtCO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsRUFDZjtBQUFBLEVBRUFDLE1BQU0sRUFBRUMsT0FBTyxHQUFHO0FBQ3RCIiwibmFtZXMiOlsiRmFDaGFydEJhciIsInJlbmRlckVzdGFkb1JlcG9ydGUiLCJpdGVtIiwiaXNfYWN0aXZlIiwicmVwb3J0ZXNNb2R1bGVDb25maWciLCJlbmRwb2ludCIsIm1vZHVsZU5hbWUiLCJtb2R1bGVOYW1lUGx1cmFsIiwiYmFzZVJvdXRlIiwiZGlzYWJsZUFjdGlvbnMiLCJkZXRhaWwiLCJkaXNwbGF5TmFtZUtleSIsImxpc3QiLCJjb2x1bW5zIiwiaGVhZGVyIiwiYWNjZXNzb3IiLCJyZW5kZXIiLCJuYW1lIiwiY29kZSIsImRlc2NyaXB0aW9uIiwicmVsYXRpb25hbEZpZWxkcyIsImlkRmllbGQiLCJjb2RlRmllbGQiLCJuYW1lRmllbGQiLCJmb3JtIiwiYmxvY2siXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsicmVwb3J0ZXMuY29uZmlnLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2VcIjtcbmltcG9ydCB7IEZhQ2hhcnRCYXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcblxuLy8gLS0tIERlZmluaWNpb25lcyBkZSBUaXBvcyBwYXJhIGxhIE1ldGFkYXRhIGRlbCBSZXBvcnRlIC0tLVxuXG5leHBvcnQgaW50ZXJmYWNlIFJlcG9ydENvbHVtbkNvbmZpZyB7XG4gICAga2V5OiBzdHJpbmc7XG4gICAgdHlwZTogJ3RleHQnIHwgJ2RhdGUnIHwgJ21vbmV5JyB8ICdiYWRnZScgfCAnbnVtYmVyJyB8ICdsaW5rJztcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIGxpbmtfaWRfa2V5Pzogc3RyaW5nO1xuICAgIGxpbmtfcGF0aD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSZXBvcnRGaWx0ZXJDb25maWcge1xuICAgIGlkOiBudW1iZXI7XG4gICAgZmllbGQ6IHN0cmluZztcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIHR5cGU6ICd0ZXh0JyB8ICdkYXRlJyB8ICdzZWxlY3QnIHwgJ251bWJlcicgfCAncmVsYXRpb25zaGlwJyB8ICdjaGVja2JveCc7XG4gICAgb3BlcmF0b3I6ICdsaWtlJyB8ICc9JyB8ICc+JyB8ICc8JyB8ICc+PScgfCAnPD0nIHwgJ2RhdGVfZnJvbScgfCAnZGF0ZV90byc7XG4gICAgb3JkZXI6IG51bWJlcjtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIG9wdGlvbnM/OiBzdHJpbmcgfCB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXIgfVtdIHwgYW55O1xufVxuXG4vLyAtLS0gSW50ZXJmYWNlIFByaW5jaXBhbCBkZWwgUmVwb3J0ZSAtLS1cbmV4cG9ydCBpbnRlcmZhY2UgUmVwb3J0RGVmaW5pdGlvbiB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgY29kZTogc3RyaW5nO1xuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gICAgbW9kZWxfY2xhc3M6IHN0cmluZztcbiAgICBpc19hY3RpdmU6IGJvb2xlYW47XG4gICAgcmVsYXRpb25zaGlwczogc3RyaW5nW107XG5cbiAgICAvLyBNZXRhZGF0YSBwYXJhIGxhIGVqZWN1Y2nDs25cbiAgICBjb2x1bW5zX2NvbmZpZzogUmVwb3J0Q29sdW1uQ29uZmlnW107XG4gICAgZmlsdGVyczogUmVwb3J0RmlsdGVyQ29uZmlnW107XG4gICAgYXZhaWxhYmxlX2Zvcm1hdHM/OiBzdHJpbmdbXTtcbn1cblxuLy8gSGVscGVyIHBhcmEgZXN0YWRvIHZpc3VhbFxuY29uc3QgcmVuZGVyRXN0YWRvUmVwb3J0ZSA9IChpdGVtOiBSZXBvcnREZWZpbml0aW9uKSA9PiB7XG4gICAgcmV0dXJuIGl0ZW0uaXNfYWN0aXZlXG4gICAgICAgID8gPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIj5BY3Rpdm88L3NwYW4+XG4gICAgICAgIDogPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIHRleHQtcmVkLTgwMFwiPkluYWN0aXZvPC9zcGFuPjtcbn07XG5cbmV4cG9ydCBjb25zdCByZXBvcnRlc01vZHVsZUNvbmZpZzogTW9kdWxlQ29uZmlnPFJlcG9ydERlZmluaXRpb24+ID0ge1xuICAgIGVuZHBvaW50OiAncmVwb3J0cycsIC8vIEVsIGVuZHBvaW50IGRlbCBiYWNrZW5kIHN1ZWxlIG1hbnRlbmVyc2UgZW4gaW5nbMOpc1xuICAgIG1vZHVsZU5hbWU6ICdSZXBvcnRlJyxcbiAgICBtb2R1bGVOYW1lUGx1cmFsOiAnUmVwb3J0ZXMgRGlzcG9uaWJsZXMnLFxuICAgIGJhc2VSb3V0ZTogJy9yZXBvcnRlcycsIC8vIFJ1dGEgZnJvbnRlbmQgZW4gZXNwYcOxb2xcbiAgICBkaXNhYmxlQWN0aW9uczogdHJ1ZSxcbiAgICBkZXRhaWw6IHtcbiAgICAgICAgZGlzcGxheU5hbWVLZXk6ICduYW1lJyxcbiAgICB9LFxuXG4gICAgbGlzdDoge1xuICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaGVhZGVyOiAnUmVwb3J0ZScsXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6ICduYW1lJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBoLTggdy04IHJvdW5kZWQgYmctaW5kaWdvLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWluZGlnby02MDAgbXItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUNoYXJ0QmFyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntpdGVtLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0PDs2RpZ28nLCBhY2Nlc3NvcjogJ2NvZGUnLCByZW5kZXI6IChpdGVtKSA9PiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0uY29kZX08L3NwYW4+IH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0Rlc2NyaXBjacOzbicsIGFjY2Vzc29yOiAnZGVzY3JpcHRpb24nLCByZW5kZXI6IChpdGVtKSA9PiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc20gdHJ1bmNhdGUgbWF4LXcteHMgYmxvY2tcIiB0aXRsZT17aXRlbS5kZXNjcmlwdGlvbn0+e2l0ZW0uZGVzY3JpcHRpb259PC9zcGFuPiB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdFc3RhZG8nLCBhY2Nlc3NvcjogJ2lzX2FjdGl2ZScsIHJlbmRlcjogcmVuZGVyRXN0YWRvUmVwb3J0ZSB9LFxuICAgICAgICBdLFxuICAgIH0sXG5cbiAgICByZWxhdGlvbmFsRmllbGRzOiB7XG4gICAgICAgIGlkRmllbGQ6ICdpZCcsXG4gICAgICAgIGNvZGVGaWVsZDogJ2NvZGUnLFxuICAgICAgICBuYW1lRmllbGQ6ICduYW1lJyxcbiAgICB9LFxuXG4gICAgZm9ybTogeyBibG9jazogW10gfVxufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3JlcG9ydGVzL3JlcG9ydGVzLmNvbmZpZy50c3gifQ==