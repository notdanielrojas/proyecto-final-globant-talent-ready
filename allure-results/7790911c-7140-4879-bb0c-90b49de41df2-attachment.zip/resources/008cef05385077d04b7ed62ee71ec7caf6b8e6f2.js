import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/remitos/pages/RemitosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/remitos/pages/RemitosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { remitosModuleConfig } from "/src/features/remitos/remitos.config.tsx";
export const RemitosListPage = () => {
  _s();
  const {
    response,
    loading,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams,
    isAppending
  } = useCrud(remitosModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/remitos/pages/RemitosListPage.tsx",
    lineNumber: 46,
    columnNumber: 21
  }, this);
  return (
    // ✅ Corregido el error 2740 (Missing properties) pasando todas las props necesarias
    /* @__PURE__ */ jsxDEV(
      GenericListPage,
      {
        config: remitosModuleConfig,
        paginationResponse: response,
        loading,
        isAppending,
        onDelete: deleteItem,
        onSort: handleSort,
        sortBy,
        sortDirection,
        onPageChange: handlePageChange,
        onLoadMore: handleLoadMore,
        onSearch: handleSearch,
        searchTerm: searchParams.term ?? "",
        dateFilterStart: searchParams.startDate ?? "",
        dateFilterEnd: searchParams.endDate ?? "",
        enableDateRangeFilter: true
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/remitos/pages/RemitosListPage.tsx",
        lineNumber: 50,
        columnNumber: 5
      },
      this
    )
  );
};
_s(RemitosListPage, "nmSY78h6SWW9xzsMlwnZrGFzYhE=", false, function() {
  return [useCrud];
});
_c = RemitosListPage;
var _c;
$RefreshReg$(_c, "RemitosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/remitos/pages/RemitosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/remitos/pages/RemitosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUV4QyxTQUFTQywyQkFBd0M7QUFLMUMsYUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFFakMsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSWhCLFFBQWdCRSxxQkFBcUJELHdCQUF3QixDQUFDO0FBRWxFLE1BQUlNLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RDtBQUFBO0FBQUEsSUFFSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUUw7QUFBQUEsUUFDUixvQkFBb0JHO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVUc7QUFBQUEsUUFDVixRQUFRQztBQUFBQSxRQUNSO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBY0c7QUFBQUEsUUFDZCxZQUFZQztBQUFBQSxRQUNaLFVBQVVDO0FBQUFBLFFBQ1YsWUFBWUMsYUFBYUUsUUFBUTtBQUFBLFFBQ2pDLGlCQUFpQkYsYUFBYUcsYUFBYTtBQUFBLFFBQzNDLGVBQWVILGFBQWFJLFdBQVc7QUFBQSxRQUN2Qyx1QkFBdUI7QUFBQTtBQUFBLE1BZjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWVnQztBQUFBO0FBR3hDO0FBQUVmLEdBdkNXRCxpQkFBZTtBQUFBLFVBZXBCSCxPQUFPO0FBQUE7QUFBQW9CLEtBZkZqQjtBQUFlLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsImdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIiwicmVtaXRvc01vZHVsZUNvbmZpZyIsIlJlbWl0b3NMaXN0UGFnZSIsIl9zIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJpc0FwcGVuZGluZyIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVtaXRvc0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0RGF0ZVJhbmdlJztcbi8vIOKchSBDT1JSRUNDScOTTiBERSBSVVRBOiBBanVzdGFyIGxhIHJ1dGEgc2kgZXMgbmVjZXNhcmlvLiAoRWo6ICcuLicpXG5pbXBvcnQgeyByZW1pdG9zTW9kdWxlQ29uZmlnLCB0eXBlIFJlbWl0byB9IGZyb20gJy4uL3JlbWl0b3MuY29uZmlnJztcbi8vIE5PVEE6IFNpIGVsIGFyY2hpdm8gZXN0w6EgZW4gZWwgbWlzbW8gZGlyZWN0b3JpbyBxdWUgZmFjdHVyYXNfdmVudGEuY29uZmlnLnRzeCwgbGEgcnV0YSBlcyAnLi4vcmVtaXRvcy9yZW1pdG9zLmNvbmZpZycgXG4vLyBwZXJvIGRhZGEgbGEgcnV0YSBlbiBlbCBlcnJvciwgbG8gbcOhcyBzZWd1cm8gZXMgcXVlIGxhIGNhcnBldGEgJ3JlbWl0b3MnIGVzdMOpIGVuIGZlYXR1cmVzLFxuLy8geSBlbCBhcmNoaXZvIGRlIGNvbmZpZyBlbiBsYSByYcOteiBkZWwgbcOzZHVsbzogJy4uXFxcXHJlbWl0b3MuY29uZmlnJ1xuXG5leHBvcnQgY29uc3QgUmVtaXRvc0xpc3RQYWdlID0gKCkgPT4ge1xuICAgIC8vIOKchSBDT1JSRUNDScOTTiBFU0xJTlQvVFM6IERlc2VzdHJ1Y3R1cmFtb3Mgc29sbyBsYXMgdmFyaWFibGVzIHVzYWRhcyBlbiA8R2VuZXJpY0xpc3RQYWdlPlxuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgfSA9IHVzZUNydWQ8UmVtaXRvPihyZW1pdG9zTW9kdWxlQ29uZmlnLCBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSgpKTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIC8vIOKchSBDb3JyZWdpZG8gZWwgZXJyb3IgMjc0MCAoTWlzc2luZyBwcm9wZXJ0aWVzKSBwYXNhbmRvIHRvZGFzIGxhcyBwcm9wcyBuZWNlc2FyaWFzXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8UmVtaXRvPlxuICAgICAgICAgICAgY29uZmlnPXtyZW1pdG9zTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9yZW1pdG9zL3BhZ2VzL1JlbWl0b3NMaXN0UGFnZS50c3gifQ==