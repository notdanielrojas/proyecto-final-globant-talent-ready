import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/SearchModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/SearchModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useCrud } from "/src/hooks/useCrud.ts";
import { GenericTable } from "/src/components/common/GenericTable.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { FaSearch, FaTimes } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const SearchModal = ({ isOpen, onClose, onSelect, config }) => {
  _s();
  const {
    response,
    loading,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleSearch,
    searchParams
  } = useCrud(config, config.initialFilters || {}, { persistListState: false });
  const [localSearch, setLocalSearch] = useState({ term: "" });
  useEffect(() => {
    setLocalSearch({ term: searchParams.term ?? "" });
  }, [searchParams.term]);
  if (!isOpen) {
    return null;
  }
  const handleRowClick = (item) => {
    onSelect(item);
    onClose();
  };
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    handleSearch({ ...searchParams, term: localSearch.term });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm", "aria-modal": "true", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-4xl p-6 mx-4 bg-white rounded-lg shadow-xl h-[90vh] flex flex-col", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: [
        "Buscar ",
        config.moduleName
      ] }, void 0, true, {
        fileName: "/app/src/components/common/SearchModal.tsx",
        lineNumber: 74,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "p-2 text-gray-500 rounded-full hover:bg-gray-200", children: /* @__PURE__ */ jsxDEV(FaTimes, { size: 20 }, void 0, false, {
        fileName: "/app/src/components/common/SearchModal.tsx",
        lineNumber: 76,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/SearchModal.tsx",
        lineNumber: 75,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/SearchModal.tsx",
      lineNumber: 73,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSearchSubmit, className: "flex items-center mt-4", autoComplete: "off", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: localSearch.term,
          onChange: (e) => setLocalSearch({ term: e.target.value }),
          placeholder: "Buscar por nombre, código...",
          autoComplete: "off",
          className: "w-full px-3 py-2 border border-gray-300 rounded-l-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/SearchModal.tsx",
          lineNumber: 81,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-r-md hover:bg-indigo-700",
          children: /* @__PURE__ */ jsxDEV(FaSearch, {}, void 0, false, {
            fileName: "/app/src/components/common/SearchModal.tsx",
            lineNumber: 95,
            columnNumber: 25
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/SearchModal.tsx",
          lineNumber: 91,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/SearchModal.tsx",
      lineNumber: 80,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow mt-4 overflow-y-auto", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/SearchModal.tsx",
      lineNumber: 102,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/SearchModal.tsx",
      lineNumber: 101,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(
      GenericTable,
      {
        data: response?.data ?? [],
        columns: config.list.columns,
        baseRoute: config.baseRoute,
        onSort: handleSort,
        sortBy,
        sortDirection,
        paginationMeta: response?.meta ?? null,
        onPageChange: handlePageChange,
        onRowClick: handleRowClick
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/SearchModal.tsx",
        lineNumber: 105,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/common/SearchModal.tsx",
      lineNumber: 99,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/SearchModal.tsx",
    lineNumber: 72,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/common/SearchModal.tsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
};
_s(SearchModal, "BLecUlkUb9buwBSnfHCfVWOqKyU=", false, function() {
  return [useCrud];
});
_c = SearchModal;
var _c;
$RefreshReg$(_c, "SearchModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/SearchModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/SearchModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0RHBCLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBRXhCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsVUFBVUMsZUFBZTtBQVMzQixhQUFNQyxjQUFjLENBQW9DLEVBQUVDLFFBQVFDLFNBQVNDLFVBQVVDLE9BQTRCLE1BQU07QUFBQUMsS0FBQTtBQUMxSCxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJbEIsUUFBUVMsUUFBUUEsT0FBT1Usa0JBQWtCLENBQUMsR0FBRyxFQUFFQyxrQkFBa0IsTUFBTSxDQUFDO0FBRzVFLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJeEIsU0FBMkIsRUFBRXlCLE1BQU0sR0FBRyxDQUFDO0FBRzdFeEIsWUFBVSxNQUFNO0FBQ1p1QixtQkFBZSxFQUFFQyxNQUFNTCxhQUFhSyxRQUFRLEdBQUcsQ0FBQztBQUFBLEVBQ3BELEdBQUcsQ0FBQ0wsYUFBYUssSUFBSSxDQUFDO0FBRXRCLE1BQUksQ0FBQ2pCLFFBQVE7QUFDVCxXQUFPO0FBQUEsRUFDWDtBQUVBLFFBQU1rQixpQkFBaUJBLENBQUNDLFNBQVk7QUFDaENqQixhQUFTaUIsSUFBSTtBQUNibEIsWUFBUTtBQUFBLEVBQ1o7QUFFQSxRQUFNbUIscUJBQXFCQSxDQUFDQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUdqQlgsaUJBQWEsRUFBRSxHQUFHQyxjQUFjSyxNQUFNRixZQUFZRSxLQUFLLENBQUM7QUFBQSxFQUM1RDtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLG9GQUFtRixjQUFXLFFBQ3pHLGlDQUFDLFNBQUksV0FBVSwyRkFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxtREFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFFBQVFkLE9BQU9vQjtBQUFBQSxXQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDMUUsdUJBQUMsWUFBTyxTQUFTdEIsU0FBUyxXQUFVLG9EQUNoQyxpQ0FBQyxXQUFRLE1BQU0sTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCLEtBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxVQUFLLFVBQVVtQixvQkFBb0IsV0FBVSwwQkFBeUIsY0FBYSxPQUNoRjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFFTCxPQUFPTCxZQUFZRTtBQUFBQSxVQUVuQixVQUFVLENBQUNJLE1BQU1MLGVBQWUsRUFBRUMsTUFBTUksRUFBRUcsT0FBT0MsTUFBTSxDQUFDO0FBQUEsVUFDeEQsYUFBWTtBQUFBLFVBQ1osY0FBYTtBQUFBLFVBQ2IsV0FBVTtBQUFBO0FBQUEsUUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRMEo7QUFBQSxNQUUxSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBRVYsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFTO0FBQUE7QUFBQSxRQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNWbkIsb0JBQ0csdUJBQUMsU0FBSSxXQUFVLDJDQUNYLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTUQsVUFBVXFCLFFBQVE7QUFBQSxRQUN4QixTQUFTdkIsT0FBT3dCLEtBQUtDO0FBQUFBLFFBQ3JCLFdBQVd6QixPQUFPMEI7QUFBQUEsUUFDbEIsUUFBUXRCO0FBQUFBLFFBQ1I7QUFBQSxRQUNBO0FBQUEsUUFDQSxnQkFBZ0JGLFVBQVV5QixRQUFRO0FBQUEsUUFDbEMsY0FBY3BCO0FBQUFBLFFBQ2QsWUFBWVE7QUFBQUE7QUFBQUEsTUFUaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUytCLEtBZnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxPQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBLEtBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFUjtBQUFFZCxHQXZGV0wsYUFBVztBQUFBLFVBVWhCTCxPQUFPO0FBQUE7QUFBQXFDLEtBVkZoQztBQUFXLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNydWQiLCJHZW5lcmljVGFibGUiLCJMb2FkaW5nU3Bpbm5lciIsIkZhU2VhcmNoIiwiRmFUaW1lcyIsIlNlYXJjaE1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsIm9uU2VsZWN0IiwiY29uZmlnIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJoYW5kbGVTb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJpbml0aWFsRmlsdGVycyIsInBlcnNpc3RMaXN0U3RhdGUiLCJsb2NhbFNlYXJjaCIsInNldExvY2FsU2VhcmNoIiwidGVybSIsImhhbmRsZVJvd0NsaWNrIiwiaXRlbSIsImhhbmRsZVNlYXJjaFN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm1vZHVsZU5hbWUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImRhdGEiLCJsaXN0IiwiY29sdW1ucyIsImJhc2VSb3V0ZSIsIm1ldGEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZWFyY2hNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZywgU2VhcmNoUGFyYW1zIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgR2VuZXJpY1RhYmxlIH0gZnJvbSAnLi9HZW5lcmljVGFibGUnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBGYVNlYXJjaCwgRmFUaW1lcyB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcblxuaW50ZXJmYWNlIFNlYXJjaE1vZGFsUHJvcHM8VD4ge1xuICAgIGlzT3BlbjogYm9vbGVhbjtcbiAgICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAgIG9uU2VsZWN0OiAoaXRlbTogVCkgPT4gdm9pZDtcbiAgICBjb25maWc6IE1vZHVsZUNvbmZpZzxUPiAmIHsgaW5pdGlhbEZpbHRlcnM/OiBQYXJ0aWFsPFNlYXJjaFBhcmFtcz4gfTtcbn1cblxuZXhwb3J0IGNvbnN0IFNlYXJjaE1vZGFsID0gPFQgZXh0ZW5kcyB7IGlkOiBzdHJpbmcgfCBudW1iZXIgfT4oeyBpc09wZW4sIG9uQ2xvc2UsIG9uU2VsZWN0LCBjb25maWcgfTogU2VhcmNoTW9kYWxQcm9wczxUPikgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGhhbmRsZVNvcnQsXG4gICAgICAgIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbixcbiAgICAgICAgaGFuZGxlUGFnZUNoYW5nZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXNcbiAgICB9ID0gdXNlQ3J1ZChjb25maWcsIGNvbmZpZy5pbml0aWFsRmlsdGVycyB8fCB7fSwgeyBwZXJzaXN0TGlzdFN0YXRlOiBmYWxzZSB9KTtcblxuICAgIC8vIOKchSBDT1JSRUNDScOTTjogRWwgZXN0YWRvIGxvY2FsIGFob3JhIHJlZmxlamEgbGEgZXN0cnVjdHVyYSBkZSBTZWFyY2hQYXJhbXNcbiAgICBjb25zdCBbbG9jYWxTZWFyY2gsIHNldExvY2FsU2VhcmNoXSA9IHVzZVN0YXRlPHsgdGVybTogc3RyaW5nIH0+KHsgdGVybTogJycgfSk7XG5cbiAgICAvLyBTaW5jcm9uaXphIGVsIGVzdGFkbyBsb2NhbCBzaSBsb3MgcGFyw6FtZXRyb3MgZXh0ZXJub3MgY2FtYmlhblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldExvY2FsU2VhcmNoKHsgdGVybTogc2VhcmNoUGFyYW1zLnRlcm0gPz8gJycgfSk7XG4gICAgfSwgW3NlYXJjaFBhcmFtcy50ZXJtXSk7XG5cbiAgICBpZiAoIWlzT3Blbikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBjb25zdCBoYW5kbGVSb3dDbGljayA9IChpdGVtOiBUKSA9PiB7XG4gICAgICAgIG9uU2VsZWN0KGl0ZW0pO1xuICAgICAgICBvbkNsb3NlKCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlYXJjaFN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAvLyDinIUgQ09SUkVDQ0nDk046IFNlIGVudsOtYW4gc29sbyBsb3MgcGFyw6FtZXRyb3MgcmVsZXZhbnRlcyBkZWwgbW9kYWxcbiAgICAgICAgLy8gRWwgaG9vayByZWxsZW5hcsOhIGxhcyBmZWNoYXMgdmFjw61hcyBzaSBlcyBuZWNlc2FyaW8uXG4gICAgICAgIGhhbmRsZVNlYXJjaCh7IC4uLnNlYXJjaFBhcmFtcywgdGVybTogbG9jYWxTZWFyY2gudGVybSB9KTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci1zbVwiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy00eGwgcC02IG14LTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cteGwgaC1bOTB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5CdXNjYXIge2NvbmZpZy5tb2R1bGVOYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwicC0yIHRleHQtZ3JheS01MDAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFUaW1lcyBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VhcmNoU3VibWl0fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC00XCIgYXV0b0NvbXBsZXRlPVwib2ZmXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBFbCB2YWxvciBkZWwgaW5wdXQgYWhvcmEgZXMgbG9jYWxTZWFyY2gudGVybVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2xvY2FsU2VhcmNoLnRlcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyDinIUgQ09SUkVDQ0nDk046IFNlIGFjdHVhbGl6YSBzb2xvIGxhIHByb3BpZWRhZCAndGVybScgZGVsIGVzdGFkbyBsb2NhbFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMb2NhbFNlYXJjaCh7IHRlcm06IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIG5vbWJyZSwgY8OzZGlnby4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1yLW1kIGhvdmVyOmJnLWluZGlnby03MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFTZWFyY2ggLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbXQtNCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkaW5nU3Bpbm5lciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8R2VuZXJpY1RhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17cmVzcG9uc2U/LmRhdGEgPz8gW119XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29uZmlnLmxpc3QuY29sdW1uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlUm91dGU9e2NvbmZpZy5iYXNlUm91dGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnaW5hdGlvbk1ldGE9e3Jlc3BvbnNlPy5tZXRhID8/IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUm93Q2xpY2s9e2hhbmRsZVJvd0NsaWNrfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwudHN4In0=