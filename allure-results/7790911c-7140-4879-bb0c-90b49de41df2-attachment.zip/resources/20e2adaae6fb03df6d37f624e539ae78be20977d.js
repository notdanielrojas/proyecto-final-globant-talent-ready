import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash, FaMoneyCheckAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, getAll, searchByField } from "/src/services/apiService.ts";
import { notasFinancierasCompraModuleConfig } from "/src/features/notas_financieras_compra/notas_financieras_compra.config.tsx";
import { comprasModuleConfig } from "/src/features/compras/compras.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { formatTaxRateCell } from "/src/utils/taxDisplay.ts";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const defaultItem = {
  line_number: 1,
  description: "",
  concept_code: "NOTA-FINANCIERA",
  quantity: 1,
  unit_price: 0,
  discount_percentage: 0,
  taxes: []
};
const defaultInitial = {
  type: "DEBIT",
  series: "B",
  purchase_id: 0,
  vendor_id: 0,
  vendor_name: "",
  vendor_code: "",
  currency_id: 1,
  issue_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  total_amount: 0,
  exchange_rate: 1,
  discount_percentage: 0,
  status: "DRAFT",
  notes: null,
  has_item_level_taxes: false,
  items: [],
  taxes: [],
  withouttax_amount: 0
};
function calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes) {
  if (!vendorTaxes || vendorTaxes.length === 0) return [];
  const taxBase = Math.max(0, subtotal - withouttax_amount);
  return vendorTaxes.map((tax) => ({
    tax_id: tax.id,
    tax_name: tax.name,
    rate: tax.rate,
    amount: taxBase * (Number(tax.rate) / 100)
  }));
}
export const NotasFinancierasCompraFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData } = useCrudItem(notasFinancierasCompraModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(notasFinancierasCompraModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitial);
  const [items, setItems] = useState(() => [{ ...defaultItem, tempId: crypto.randomUUID() }]);
  const [vendorTaxes, setVendorTaxes] = useState([]);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [perceptionRows, setPerceptionRows] = useState([]);
  const [perceptionTaxes, setPerceptionTaxes] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const [purchaseCodeInput, setPurchaseCodeInput] = useState("");
  const [checkModalOpen, setCheckModalOpen] = useState(false);
  const [checkModalItemTempId, setCheckModalItemTempId] = useState(null);
  const [deliveredChecksList, setDeliveredChecksList] = useState([]);
  const [deliveredChecksMeta, setDeliveredChecksMeta] = useState(null);
  const [loadingDeliveredChecks, setLoadingDeliveredChecks] = useState(false);
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      const vendorName = loadedData.vendor_name ?? loadedData.vendor?.name ?? "";
      const vendorCode = loadedData.vendor_code ?? loadedData.vendor?.vendor_code ?? "";
      setFormData({
        ...defaultInitial,
        ...loadedData,
        vendor_name: vendorName,
        vendor_code: vendorCode
      });
      const loadedItems = (loadedData.items || []).length ? (loadedData.items || []).map((it) => ({ ...it, concept_code: it.concept_code || "NOTA-FINANCIERA", quantity: it.quantity ?? 1, tempId: crypto.randomUUID() })) : [{ ...defaultItem, tempId: crypto.randomUUID() }];
      setItems(loadedItems);
      setPurchaseCodeInput(loadedData.purchase?.document_number ?? String(loadedData.purchase_id ?? ""));
      if (loadedData.vendor_id) {
        getById(proveedoresModuleConfig.endpoint, loadedData.vendor_id).then((v) => setVendorTaxes(v.relatedTaxes || [])).catch(() => setVendorTaxes([]));
      }
      if (loadedData.taxes && Array.isArray(loadedData.taxes) && loadedData.taxes.length > 0) {
        const type1 = loadedData.taxes.filter((t) => t.tax_type !== 2);
        const type2 = loadedData.taxes.filter((t) => t.tax_type === 2);
        setAppliedTaxes(type1.map((t) => ({
          tax_id: t.tax_id,
          tax_name: t.tax_name,
          rate: t.rate,
          amount: Number(t.amount) || 0
        })));
        setPerceptionRows(type2.map((t) => ({
          tempId: crypto.randomUUID(),
          tax_id: t.tax_id,
          tax_name: t.tax_name ?? t.tax?.name ?? null,
          amount: Number(t.amount) || 0
        })));
      }
    }
  }, [mode, loadedData]);
  useEffect(() => {
    if (id) return;
    if (vendorTaxes.length === 0) {
      setAppliedTaxes([]);
      return;
    }
    if (vendorTaxes.length > 1) {
      setAppliedTaxes(vendorTaxes.map((t) => ({
        tax_id: t.id,
        tax_name: t.name,
        rate: t.rate,
        amount: 0
      })));
    }
  }, [id, vendorTaxes]);
  useEffect(() => {
    if (id || vendorTaxes.length !== 1) return;
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const withouttax_amount = formData.withouttax_amount ?? 0;
    const calculated = calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes);
    setAppliedTaxes(calculated);
  }, [id, items, formData.withouttax_amount, vendorTaxes]);
  useEffect(() => {
    getAll("taxes", { type: "2" }).then((res) => setPerceptionTaxes(res.data || [])).catch(() => setPerceptionTaxes([]));
  }, []);
  const handleUpdateAppliedTaxAmount = (tax_id, amount) => {
    setAppliedTaxes((prev) => prev.map((t) => t.tax_id === tax_id ? { ...t, amount } : t));
  };
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const withouttax_amount = formData.withouttax_amount ?? 0;
    const totalTaxes = vendorTaxes.length === 1 ? calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes).reduce((s, t) => s + Number(t.amount), 0) : appliedTaxes.reduce((s, t) => s + (Number(t.amount) || 0), 0);
    const percepcionesTotal = perceptionRows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
    const total = subtotal + totalTaxes + percepcionesTotal;
    return { subtotal, withouttax_amount, totalTaxes, percepcionesTotal, total };
  }, [items, formData.withouttax_amount, vendorTaxes, appliedTaxes, perceptionRows]);
  const aggregatedTaxes = useMemo(() => {
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const withouttax_amount = formData.withouttax_amount ?? 0;
    if (vendorTaxes.length === 1) {
      const applied = calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes);
      return applied.map((t) => ({
        tax_id: t.tax_id,
        tax_name: t.tax_name,
        rate: t.rate,
        amount: Number(t.amount)
      }));
    }
    return appliedTaxes.map((t) => ({
      tax_id: t.tax_id,
      tax_name: t.tax_name,
      tax_type: t.tax_type,
      tax_type_label: t.tax_type_label,
      tax: t.tax,
      rate: t.rate,
      amount: Number(t.amount)
    }));
  }, [items, formData.withouttax_amount, vendorTaxes, appliedTaxes]);
  const loadDeliveredChecks = useCallback((pageUrl) => {
    if (!pageUrl && !formData.vendor_id) return;
    setLoadingDeliveredChecks(true);
    const req = pageUrl ? getAll(pageUrl) : getAll("payment-orders/delivered-checks", { vendor_id: formData.vendor_id });
    req.then((res) => {
      setDeliveredChecksList(res.data || []);
      setDeliveredChecksMeta(res.meta ?? null);
    }).catch(() => {
      toast.error("Error al cargar cheques entregados.");
      setDeliveredChecksList([]);
      setDeliveredChecksMeta(null);
    }).finally(() => setLoadingDeliveredChecks(false));
  }, [formData.vendor_id]);
  useEffect(() => {
    if (!checkModalOpen || !formData.vendor_id) return;
    loadDeliveredChecks();
  }, [checkModalOpen, formData.vendor_id, loadDeliveredChecks]);
  const handleOpenCheckModal = (itemTempId) => {
    if (!formData.vendor_id) {
      toast.info("Seleccione primero un proveedor.");
      return;
    }
    setCheckModalItemTempId(itemTempId);
    setCheckModalOpen(true);
  };
  const handleSelectCheck = (deliveredCheck) => {
    if (!checkModalItemTempId) return;
    const checkValue = deliveredCheck.check?.value != null ? Number(deliveredCheck.check.value) : 0;
    setItems((prev) => prev.map(
      (it) => it.tempId === checkModalItemTempId ? { ...it, deliveredCheck, quantity: 1, unit_price: checkValue } : it
    ));
    setCheckModalOpen(false);
    setCheckModalItemTempId(null);
  };
  const handleClearItemCheck = (itemTempId) => {
    setItems((prev) => prev.map((it) => it.tempId === itemTempId ? { ...it, deliveredCheck: null } : it));
  };
  const clearForm = () => {
    setFormData({ ...defaultInitial });
    setItems([{ ...defaultItem, tempId: crypto.randomUUID() }]);
    setVendorTaxes([]);
    setAppliedTaxes([]);
    setPerceptionRows([]);
    setPurchaseCodeInput("");
    setCheckModalOpen(false);
    setCheckModalItemTempId(null);
    setDeliveredChecksList([]);
    setDeliveredChecksMeta(null);
  };
  const handleVendorSelected = async (vendor) => {
    setLoading(true);
    try {
      const full = await getById(proveedoresModuleConfig.endpoint, vendor.id);
      const taxes = full.relatedTaxes || [];
      setVendorTaxes(taxes);
      setFormData((prev) => ({
        ...prev,
        vendor_id: full.id,
        vendor_name: full.name || "",
        vendor_code: full.vendor_code || "",
        purchase_id: 0,
        purchase: void 0,
        series: full.serie ?? prev?.series ?? "B",
        currency_id: prev?.currency_id ?? 1,
        exchange_rate: prev?.exchange_rate ?? 1
      }));
      setItems([{ ...defaultItem, tempId: crypto.randomUUID() }]);
      setPurchaseCodeInput("");
      toast.success("Proveedor seleccionado. Elija la compra.");
    } catch (err) {
      console.error(err);
      toast.error("Error al cargar el proveedor.");
    } finally {
      setLoading(false);
    }
  };
  const handleVendorCodeSubmit = async () => {
    const code = formData.vendor_code?.trim();
    if (!code) {
      toast.info("Ingrese el código del proveedor.");
      return;
    }
    setLoading(true);
    try {
      const found = await searchByField(proveedoresModuleConfig.endpoint, [{ fieldName: "vendor_code", value: code }]);
      if (found) {
        await handleVendorSelected(found);
      } else {
        toast.error(`No se encontró proveedor con código "${code}".`);
      }
    } catch (e) {
      console.error(e);
      toast.error("Error al buscar proveedor.");
    } finally {
      setLoading(false);
    }
  };
  const handlePurchaseSelected = async (purchase) => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione primero un proveedor.");
      return;
    }
    setLoading(true);
    try {
      const full = await getById(comprasModuleConfig.endpoint, purchase.id);
      if (full.vendor_id !== formData.vendor_id) {
        toast.error("La compra no pertenece al proveedor seleccionado.");
        setLoading(false);
        return;
      }
      const vendorName = full.vendor?.name || full.vendor_name || "";
      setFormData((prev) => ({
        ...prev,
        purchase_id: full.id,
        purchase: {
          id: full.id,
          internal_voucher: full.internal_voucher || String(full.id),
          purchase_date: full.purchase_date,
          document_number: full.document_number
        },
        vendor_id: full.vendor_id,
        vendor_name: vendorName,
        series: full.series || prev?.series || "B",
        currency_id: full.currency_id ?? prev?.currency_id ?? 1,
        exchange_rate: full.exchange_rate ?? 1,
        has_item_level_taxes: true
      }));
      setPurchaseCodeInput(full.document_number || String(full.id));
      toast.success("Compra seleccionada.");
    } catch (err) {
      console.error(err);
      toast.error("Error al cargar la compra.");
    } finally {
      setLoading(false);
    }
  };
  const handlePurchaseCodeSubmit = async () => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione primero un proveedor.");
      return;
    }
    const code = purchaseCodeInput.trim();
    if (!code) {
      toast.info("Ingrese el número de la compra.");
      return;
    }
    setLoading(true);
    try {
      const found = await searchByField(comprasModuleConfig.endpoint, [{ fieldName: "document_number", value: code }]);
      if (found) {
        await handlePurchaseSelected(found);
      } else {
        toast.error("No se encontró una compra con ese número.");
      }
    } catch (e) {
      console.error(e);
      toast.error("Error al buscar la compra.");
    } finally {
      setLoading(false);
    }
  };
  const handleSelectFromModal = (selected) => {
    if (editingTarget === "vendor") {
      handleVendorSelected(selected);
    } else {
      handlePurchaseSelected(selected);
    }
    setEditingTarget(null);
    setIsModalOpen(false);
  };
  const handleAddItem = () => setItems((prev) => [...prev, { ...defaultItem, tempId: crypto.randomUUID() }]);
  const handleRemoveItem = (tempId) => setItems((prev) => prev.length > 1 ? prev.filter((i) => i.tempId !== tempId) : prev);
  const handleUpdateItem = (tempId, field, value) => {
    setItems((prev) => prev.map((i) => i.tempId === tempId ? { ...i, [field]: value } : i));
  };
  const handleAnnulPurchase = async () => {
    if (formData.type !== "CREDIT") {
      toast.info("La anulación solo aplica para notas de tipo crédito.");
      return;
    }
    if (!formData.purchase_id) {
      toast.warn("Seleccione primero una compra para anular.");
      return;
    }
    setLoading(true);
    try {
      const purchase = await getById(comprasModuleConfig.endpoint, formData.purchase_id);
      let baseItemsTotal = 0;
      if (Array.isArray(purchase.items) && purchase.items.length > 0) {
        baseItemsTotal = purchase.items.reduce((sum, it) => {
          if (typeof it.value === "number") return sum + Number(it.value);
          const qty = Number(it.quantity) || 0;
          const unit = Number(it.unit_price) || 0;
          return sum + qty * unit;
        }, 0);
      } else if (Array.isArray(purchase.products) && purchase.products.length > 0) {
        const products = purchase.products;
        baseItemsTotal = products.reduce((sum, p) => sum + (Number(p.quantity) || 0) * (Number(p.price_cost) || 0), 0);
      } else if (typeof purchase.total_amount === "number") {
        baseItemsTotal = Number(purchase.total_amount) || 0;
      }
      if (baseItemsTotal <= 0) {
        toast.error("No fue posible calcular el total de ítems de la compra para anular.");
        return;
      }
      const annulItem = {
        ...defaultItem,
        tempId: crypto.randomUUID(),
        description: "ANULACION TOTAL",
        quantity: 1,
        unit_price: baseItemsTotal,
        discount_percentage: 0,
        taxes: [],
        deliveredCheck: null
      };
      setItems([annulItem]);
      const rawTaxes = purchase.applied_taxes ?? [];
      if (Array.isArray(rawTaxes) && rawTaxes.length > 0) {
        const type1 = rawTaxes.filter((t) => t.tax_type !== 2);
        const type2 = rawTaxes.filter((t) => t.tax_type === 2);
        setAppliedTaxes(type1.map((t) => ({
          tax_id: t.tax_id,
          tax_name: t.tax_name,
          rate: t.rate,
          amount: Number(t.amount) || 0
        })));
        setPerceptionRows(type2.map((t) => ({
          tempId: crypto.randomUUID(),
          tax_id: t.tax_id,
          tax_name: t.tax_name ?? t.tax?.name ?? null,
          amount: Number(t.amount) || 0
        })));
      } else {
        setAppliedTaxes([]);
        setPerceptionRows([]);
      }
      setFormData((prev) => ({
        ...prev,
        withouttax_amount: purchase.withouttax_amount ?? prev.withouttax_amount ?? 0
      }));
      toast.success("Datos de anulación cargados desde la compra seleccionada.");
    } catch (error) {
      console.error(error);
      toast.error("No se pudo cargar la información de la compra para anular.");
    } finally {
      setLoading(false);
    }
  };
  const appliedTaxesForPayload = useMemo(() => {
    if (vendorTaxes.length === 1) {
      const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
      const withouttax_amount = formData.withouttax_amount ?? 0;
      return calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes);
    }
    return appliedTaxes;
  }, [items, formData.withouttax_amount, vendorTaxes, appliedTaxes]);
  const handleSave = async () => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione un proveedor.");
      return;
    }
    if (!formData.purchase_id) {
      toast.warn("Seleccione una compra.");
      return;
    }
    if (items.length === 0 || items.some((it) => !it.description?.trim())) {
      toast.warn("Cada ítem debe tener descripción.");
      return;
    }
    if (!formData.series) {
      toast.warn("La serie es obligatoria.");
      return;
    }
    if (!formData.voucher_number?.trim()) {
      toast.warn("El número de comprobante es obligatorio.");
      return;
    }
    const cleanItems = items.map((it, idx) => {
      const { tempId, deliveredCheck, ...rest } = it;
      return {
        ...rest,
        line_number: idx + 1,
        ...deliveredCheck?.id != null && { payment_order_item_id: deliveredCheck.id }
      };
    });
    const taxesType1 = appliedTaxesForPayload.filter((t) => Number(t.amount) > 0).map((t) => ({ ...t, tax_type: 1 }));
    const taxesType2 = perceptionRows.filter((r) => r.tax_id != null && Number(r.amount) > 0).map((r) => ({
      tax_id: r.tax_id,
      tax_name: r.tax_name ?? "",
      rate: 0,
      amount: r.amount,
      tax_type: 2
    }));
    const payload = {
      ...formData,
      type: formData.type || "DEBIT",
      voucher_number: formData.voucher_number.trim(),
      series: formData.series || "B",
      purchase_id: formData.purchase_id,
      vendor_id: formData.vendor_id,
      vendor_code: formData.vendor_code ?? void 0,
      vendor_name: formData.vendor_name ?? void 0,
      currency_id: formData.currency_id ?? 1,
      issue_date: formData.issue_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      total_amount: calculatedTotals.total,
      exchange_rate: formData.exchange_rate ?? 1,
      discount_percentage: formData.discount_percentage ?? 0,
      status: formData.status || "DRAFT",
      notes: formData.notes ?? null,
      concept: null,
      withouttax_amount: formData.withouttax_amount ?? 0,
      has_item_level_taxes: false,
      items: cleanItems,
      taxes: [...taxesType1, ...taxesType2]
    };
    try {
      const saved = await saveItem(payload);
      if (saved) {
        toast.success("Nota Financiera guardada.");
        navigate(getListReturnPath(notasFinancierasCompraModuleConfig.baseRoute));
      }
    } catch (e) {
      toast.error("Error al guardar.");
    }
  };
  if (loadingData) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
    lineNumber: 605,
    columnNumber: 27
  }, this);
  const inputStyle = "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm focus:ring-indigo-500 focus:border-indigo-500";
  const purchaseModalConfig = formData.vendor_id ? { ...comprasModuleConfig, initialFilters: { vendor_id: formData.vendor_id } } : comprasModuleConfig;
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6 relative", children: [
    (isLoading || saving) && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px]", children: [
      /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-8 h-8 text-indigo-600 animate-spin mb-2" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 616,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Procesando..." }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 617,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 615,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Nueva Nota Financiera" : `Editar Nota ${formData.voucher_number || id}` }, void 0, false, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 621,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Número de comprobante (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 627,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: formData.voucher_number || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, voucher_number: e.target.value })),
            className: inputStyle,
            placeholder: "Ej: 70099",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 628,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 626,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 636,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: formData.type || "DEBIT",
            onChange: (e) => setFormData((prev) => ({ ...prev, type: e.target.value })),
            className: inputStyle,
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "DEBIT", children: "Débito" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 642,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "CREDIT", children: "Crédito" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 643,
                columnNumber: 25
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 637,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 635,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 647,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: formData.series || "B",
            onChange: (e) => setFormData((prev) => ({ ...prev, series: e.target.value })),
            className: inputStyle,
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 653,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 654,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 655,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "X", children: "X" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 656,
                columnNumber: 25
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 648,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 646,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Proveedor (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 661,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: formData.vendor_code || "",
            nameValue: formData.vendor_name || null,
            onCodeChange: (c) => setFormData((prev) => ({ ...prev, vendor_code: c || "" })),
            onCodeSubmit: handleVendorCodeSubmit,
            onSearchClick: () => {
              setModalConfig(proveedoresModuleConfig);
              setEditingTarget("vendor");
              setIsModalOpen(true);
            },
            onClearClick: clearForm
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 662,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 660,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Nº de Factura (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 672,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: purchaseCodeInput,
              nameValue: formData.purchase_id ? formData.purchase?.document_number ? `Nº Factura: ${formData.purchase?.document_number}` : `ID compra: ${formData.purchase_id}` : null,
              onCodeChange: (c) => setPurchaseCodeInput(c ?? ""),
              onCodeSubmit: handlePurchaseCodeSubmit,
              onSearchClick: () => {
                setModalConfig(purchaseModalConfig);
                setEditingTarget("purchase");
                setIsModalOpen(true);
              },
              onClearClick: () => {
                setFormData((prev) => ({ ...prev, purchase_id: 0, purchase: void 0 }));
                setItems([{ ...defaultItem, tempId: crypto.randomUUID() }]);
                setPurchaseCodeInput("");
              },
              disabled: !formData.vendor_id
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 675,
              columnNumber: 29
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 674,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleAnnulPurchase,
              disabled: !formData.purchase_id || formData.type !== "CREDIT" || isLoading || saving,
              className: "mt-1 inline-flex items-center px-3 py-2 text-xs font-medium rounded-md border border-red-200 text-red-700 bg-red-50 hover:bg-red-100 disabled:opacity-50 disabled:cursor-not-allowed",
              title: "Generar nota para anulación total de la compra",
              children: "Anular"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 685,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 673,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 671,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 697,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: formData.issue_date || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, issue_date: e.target.value })),
            className: inputStyle,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 698,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 696,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 705,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 2,
            value: formData.notes || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, notes: e.target.value || null })),
            className: inputStyle,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 706,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 704,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 625,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-4", children: "Ítems" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 715,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase", children: "Descripción" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 720,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 721,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 722,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 723,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 w-10" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 724,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 719,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 718,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map(
          (row) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: row.description,
                  onChange: (e) => handleUpdateItem(row.tempId, "description", e.target.value),
                  className: "w-full px-2 py-1 border border-gray-300 rounded text-sm",
                  placeholder: "Descripción del ítem",
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                  lineNumber: 731,
                  columnNumber: 41
                },
                this
              ),
              row.deliveredCheck?.check && /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-gray-600 flex items-center gap-2 flex-wrap", children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "Cheque recibido No. ",
                  row.deliveredCheck.check.check_number,
                  ", Cliente: ",
                  row.deliveredCheck.check.check_holder ?? "N/A",
                  ". Factura: ",
                  row.deliveredCheck.check.reference_number ?? "N/A"
                ] }, void 0, true, {
                  fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                  lineNumber: 739,
                  columnNumber: 49
                }, this),
                /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleClearItemCheck(row.tempId), className: "text-red-500 hover:text-red-700", title: "Quitar cheque", children: "×" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                  lineNumber: 742,
                  columnNumber: 49
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 738,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 730,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                min: 0,
                step: "0.01",
                value: row.quantity,
                onChange: (num) => handleUpdateItem(row.tempId, "quantity", num),
                className: "w-20 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 747,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 746,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                step: "0.01",
                value: row.unit_price,
                onChange: (num) => handleUpdateItem(row.tempId, "unit_price", num),
                className: "w-32 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 756,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 755,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-medium", children: formatValue(Number(row.quantity) * Number(row.unit_price), "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 763,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 flex items-center justify-end gap-1", children: [
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenCheckModal(row.tempId), className: "p-1 text-indigo-600 hover:text-indigo-800", title: "Asociar cheque recibido", disabled: !formData.vendor_id, children: /* @__PURE__ */ jsxDEV(FaMoneyCheckAlt, {}, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 766,
                columnNumber: 45
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 765,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveItem(row.tempId), className: "text-red-500 hover:text-red-700", title: "Quitar ítem", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 768,
                columnNumber: 172
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 768,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 764,
              columnNumber: 37
            }, this)
          ] }, row.tempId, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 729,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 727,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 717,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 716,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddItem, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 776,
          columnNumber: 21
        }, this),
        " Añadir ítem"
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 775,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 714,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-800", children: "Impuestos aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 782,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid grid-cols-3 items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 col-span-2", children: "Valor No Gravado (no gravado)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 784,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              step: "0.01",
              value: formData.withouttax_amount,
              onChange: (num) => setFormData((prev) => ({ ...prev, withouttax_amount: num ?? 0 })),
              className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
              placeholder: "0"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 785,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 783,
          columnNumber: 21
        }, this),
        aggregatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 798,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 799,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 800,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 797,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 796,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: aggregatedTaxes.map(
            (tax, idx) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 806,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatTaxRateCell(tax) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 807,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: vendorTaxes.length > 1 && typeof tax.tax_id === "number" ? /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: tax.amount,
                  onChange: (num) => handleUpdateAppliedTaxAmount(tax.tax_id, num ?? 0),
                  className: "w-24 px-2 py-1 text-right border border-gray-300 rounded text-sm"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                  lineNumber: 810,
                  columnNumber: 21
                },
                this
              ) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 817,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 808,
                columnNumber: 45
              }, this)
            ] }, tax.tax_id ?? idx, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 805,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 803,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 795,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 794,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-gray-500", children: "No hay impuestos aplicados." }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 826,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 mt-4 border-t border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium text-gray-800 mb-2", children: "Percepciones" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 829,
            columnNumber: 25
          }, this),
          perceptionTaxes.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No hay percepciones configuradas." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 831,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: perceptionRows.map(
              (row) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: row.tax_id ?? "",
                    onChange: (e) => {
                      const val = e.target.value;
                      if (!val) {
                        setPerceptionRows((prev) => prev.map((r) => r.tempId === row.tempId ? { ...r, tax_id: null, tax_name: null } : r));
                        return;
                      }
                      const tax = perceptionTaxes.find((t) => t.id === Number(val));
                      if (!tax) return;
                      const alreadyUsed = perceptionRows.some((r) => r.tempId !== row.tempId && r.tax_id === tax.id);
                      if (alreadyUsed) {
                        toast.warn("Esa percepción ya está en la lista. No se puede repetir.");
                        return;
                      }
                      setPerceptionRows((prev) => prev.map(
                        (r) => r.tempId === row.tempId ? { ...r, tax_id: tax.id, tax_name: tax.name } : r
                      ));
                    },
                    className: "col-span-2 w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm sm:text-sm",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccione percepción" }, void 0, false, {
                        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                        lineNumber: 858,
                        columnNumber: 49
                      }, this),
                      perceptionTaxes.map(
                        (tax) => /* @__PURE__ */ jsxDEV("option", { value: tax.id, disabled: perceptionRows.some((r) => r.tempId !== row.tempId && r.tax_id === tax.id), children: tax.name }, tax.id, false, {
                          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                          lineNumber: 860,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                    lineNumber: 837,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    DecimalInput,
                    {
                      value: row.amount,
                      onChange: (num) => setPerceptionRows((prev) => prev.map(
                        (r) => r.tempId === row.tempId ? { ...r, amount: num ?? 0 } : r
                      )),
                      className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm sm:text-sm",
                      placeholder: "0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                      lineNumber: 866,
                      columnNumber: 49
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setPerceptionRows((prev) => prev.filter((r) => r.tempId !== row.tempId)),
                      className: "text-red-500 hover:text-red-700 p-1",
                      title: "Quitar",
                      children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                        lineNumber: 880,
                        columnNumber: 53
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                      lineNumber: 874,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                  lineNumber: 865,
                  columnNumber: 45
                }, this)
              ] }, row.tempId, true, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 836,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 834,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setPerceptionRows((prev) => [...prev, { tempId: crypto.randomUUID(), tax_id: null, tax_name: null, amount: 0 }]),
                className: "inline-flex items-center px-3 py-2 mt-2 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700",
                children: [
                  /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
                    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                    lineNumber: 891,
                    columnNumber: 37
                  }, this),
                  " Agregar percepción"
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 886,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 833,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 828,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 781,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 898,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 898,
            columnNumber: 115
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 898,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-gray-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Valor No Gravado (no gravado):" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 899,
            columnNumber: 81
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(calculatedTotals.withouttax_amount ?? 0, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 899,
            columnNumber: 124
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 899,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Impuestos:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 900,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: [
            "+ ",
            formatValue(calculatedTotals.totalTaxes, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 900,
            columnNumber: 116
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 900,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Percepciones:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 901,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: [
            "+ ",
            formatValue(calculatedTotals.percepcionesTotal, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 901,
            columnNumber: 119
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 901,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900", children: "Total:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 902,
            columnNumber: 78
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-indigo-600", children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 902,
            columnNumber: 133
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 902,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 897,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 780,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(notasFinancierasCompraModuleConfig.baseRoute)), className: "px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 907,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: isLoading || saving, className: "inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50", children: [
        /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 909,
          columnNumber: 21
        }, this),
        " Guardar"
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 908,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 906,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => {
      setIsModalOpen(false);
      setEditingTarget(null);
    }, onSelect: handleSelectFromModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 914,
      columnNumber: 7
    }, this),
    checkModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[80vh] flex flex-col", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Seleccionar cheque recibido" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 921,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
          setCheckModalOpen(false);
          setCheckModalItemTempId(null);
          setDeliveredChecksMeta(null);
        }, className: "text-gray-400 hover:text-gray-600", children: "×" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 922,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 920,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-auto flex-1", children: loadingDeliveredChecks ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-8 h-8 text-indigo-600 animate-spin" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 926,
        columnNumber: 68
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 926,
        columnNumber: 13
      }, this) : deliveredChecksList.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 py-4", children: "No hay cheques entregados para este proveedor." }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 928,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded", children: [
        /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Nº Cheque" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 934,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Titular" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 935,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Valor" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 936,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Ref." }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 937,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 w-24" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 938,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 933,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 932,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: deliveredChecksList.map(
            (dc) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: dc.check?.check_number ?? "-" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 944,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: dc.check?.check_holder ?? "-" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 945,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-right", children: dc.check ? formatValue(Number(dc.check.value), "currency") : "-" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 946,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: dc.check?.reference_number ?? "-" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 947,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleSelectCheck(dc), className: "text-indigo-600 hover:text-indigo-800 text-sm font-medium", children: "Seleccionar" }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 949,
                columnNumber: 57
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
                lineNumber: 948,
                columnNumber: 53
              }, this)
            ] }, dc.id, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
              lineNumber: 943,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
            lineNumber: 941,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 931,
          columnNumber: 37
        }, this),
        deliveredChecksMeta && /* @__PURE__ */ jsxDEV(Pagination, { meta: deliveredChecksMeta, onPageChange: (u) => loadDeliveredChecks(u) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
          lineNumber: 956,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 930,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
        lineNumber: 924,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 919,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
      lineNumber: 918,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx",
    lineNumber: 613,
    columnNumber: 5
  }, this);
};
_s(NotasFinancierasCompraFormPage, "tg6FT5kPS8gputmINCDrbiGoa9k=", false, function() {
  return [useParams, useNavigate, useCrudItem, useCrudItem];
});
_c = NotasFinancierasCompraFormPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasCompraFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeWtCNEIsU0FvT0EsVUFwT0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeGtCNUIsU0FBU0EsVUFBVUMsV0FBV0MsU0FBU0MsbUJBQW1CO0FBQzFELFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFFBQVFDLFdBQVdDLFFBQVFDLFNBQVNDLHVCQUF1QjtBQUNwRSxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBU0MsUUFBUUMscUJBQXFCO0FBQy9DLFNBQVNDLDBDQUFzRztBQUMvRyxTQUFTQywyQkFBMkI7QUFFcEMsU0FBU0MsK0JBQStDO0FBQ3hELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MseUJBQXlCO0FBS2xDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsY0FBeUM7QUFBQSxFQUMzQ0MsYUFBYTtBQUFBLEVBQ2JDLGFBQWE7QUFBQSxFQUNiQyxjQUFjO0FBQUEsRUFDZEMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaQyxxQkFBcUI7QUFBQSxFQUNyQkMsT0FBTztBQUNYO0FBRUEsTUFBTUMsaUJBQWlEO0FBQUEsRUFDbkRDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsYUFBYTtBQUFBLEVBQ2JDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQUEsRUFDYkMsYUFBYTtBQUFBLEVBQ2JDLGFBQWE7QUFBQSxFQUNiQyxhQUFZLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pEQyxjQUFjO0FBQUEsRUFDZEMsZUFBZTtBQUFBLEVBQ2ZmLHFCQUFxQjtBQUFBLEVBQ3JCZ0IsUUFBUTtBQUFBLEVBQ1JDLE9BQU87QUFBQSxFQUNQQyxzQkFBc0I7QUFBQSxFQUN0QkMsT0FBTztBQUFBLEVBQ1BsQixPQUFPO0FBQUEsRUFDUG1CLG1CQUFtQjtBQUN2QjtBQXFCQSxTQUFTQyx3QkFBd0JDLFVBQWtCRixtQkFBMkJHLGFBQXlDO0FBQ25ILE1BQUksQ0FBQ0EsZUFBZUEsWUFBWUMsV0FBVyxFQUFHLFFBQU87QUFDckQsUUFBTUMsVUFBVUMsS0FBS0MsSUFBSSxHQUFHTCxXQUFXRixpQkFBaUI7QUFDeEQsU0FBT0csWUFBWUssSUFBSSxDQUFBQyxTQUFRO0FBQUEsSUFDM0JDLFFBQVFELElBQUlFO0FBQUFBLElBQ1pDLFVBQVVILElBQUlJO0FBQUFBLElBQ2RDLE1BQU1MLElBQUlLO0FBQUFBLElBQ1ZDLFFBQVFWLFdBQVdXLE9BQU9QLElBQUlLLElBQUksSUFBSTtBQUFBLEVBQzFDLEVBQUU7QUFDTjtBQUVPLGFBQU1HLGlDQUFpQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2hELFFBQU0sRUFBRVAsR0FBRyxJQUFJM0QsVUFBMEI7QUFDekMsUUFBTW1FLFdBQVdwRSxZQUFZO0FBQzdCLFFBQU1xRSxPQUFPVCxLQUFLLFNBQVM7QUFFM0IsUUFBTSxFQUFFVSxNQUFNQyxZQUFZQyxTQUFTQyxZQUFZLElBQUlqRSxZQUFtQ0ksb0NBQW9DZ0QsRUFBRTtBQUM1SCxRQUFNLEVBQUVjLFVBQVVGLFNBQVNHLE9BQU8sSUFBSW5FLFlBQW1DSSxvQ0FBb0NnRCxFQUFFO0FBRS9HLFFBQU0sQ0FBQ2dCLFVBQVVDLFdBQVcsSUFBSWpGLFNBQXlDbUMsY0FBYztBQUN2RixRQUFNLENBQUNpQixPQUFPOEIsUUFBUSxJQUFJbEYsU0FBcUIsTUFBTSxDQUFDLEVBQUUsR0FBRzJCLGFBQWF3RCxRQUFRQyxPQUFPQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQ3RHLFFBQU0sQ0FBQzdCLGFBQWE4QixjQUFjLElBQUl0RixTQUF1QixFQUFFO0FBQy9ELFFBQU0sQ0FBQ3VGLGNBQWNDLGVBQWUsSUFBSXhGLFNBQXVCLEVBQUU7QUFDakUsUUFBTSxDQUFDeUYsZ0JBQWdCQyxpQkFBaUIsSUFBSTFGLFNBQStGLEVBQUU7QUFDN0ksUUFBTSxDQUFDMkYsaUJBQWlCQyxrQkFBa0IsSUFBSTVGLFNBQWdCLEVBQUU7QUFDaEUsUUFBTSxDQUFDNkYsV0FBV0MsVUFBVSxJQUFJOUYsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQytGLGFBQWFDLGNBQWMsSUFBSWhHLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNpRyxhQUFhQyxjQUFjLElBQUlsRyxTQUFtQyxJQUFJO0FBQzdFLFFBQU0sQ0FBQ21HLGVBQWVDLGdCQUFnQixJQUFJcEcsU0FBdUMsSUFBSTtBQUNyRixRQUFNLENBQUNxRyxtQkFBbUJDLG9CQUFvQixJQUFJdEcsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ3VHLGdCQUFnQkMsaUJBQWlCLElBQUl4RyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDeUcsc0JBQXNCQyx1QkFBdUIsSUFBSTFHLFNBQXdCLElBQUk7QUFDcEYsUUFBTSxDQUFDMkcscUJBQXFCQyxzQkFBc0IsSUFBSTVHLFNBQStCLEVBQUU7QUFDdkYsUUFBTSxDQUFDNkcscUJBQXFCQyxzQkFBc0IsSUFBSTlHLFNBQStELElBQUk7QUFDekgsUUFBTSxDQUFDK0csd0JBQXdCQyx5QkFBeUIsSUFBSWhILFNBQVMsS0FBSztBQUUxRUMsWUFBVSxNQUFNO0FBQ1osUUFBSXdFLFNBQVMsVUFBVUUsWUFBWTtBQUMvQixZQUFNc0MsYUFBYXRDLFdBQVduQyxlQUFnQm1DLFdBQVd1QyxRQUFnQmhELFFBQVE7QUFDakYsWUFBTWlELGFBQWF4QyxXQUFXbEMsZUFBZ0JrQyxXQUFXdUMsUUFBZ0J6RSxlQUFlO0FBQ3hGd0Msa0JBQVk7QUFBQSxRQUNSLEdBQUc5QztBQUFBQSxRQUNILEdBQUd3QztBQUFBQSxRQUNIbkMsYUFBYXlFO0FBQUFBLFFBQ2J4RSxhQUFhMEU7QUFBQUEsTUFDakIsQ0FBQztBQUNELFlBQU1DLGVBQWV6QyxXQUFXdkIsU0FBUyxJQUFJSyxVQUN0Q2tCLFdBQVd2QixTQUFTLElBQUlTLElBQUksQ0FBQXdELFFBQU8sRUFBRSxHQUFHQSxJQUFJdkYsY0FBY3VGLEdBQUd2RixnQkFBZ0IsbUJBQW1CQyxVQUFVc0YsR0FBR3RGLFlBQVksR0FBR29ELFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxFQUFjLElBQ3ZLLENBQUMsRUFBRSxHQUFHMUQsYUFBYXdELFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDO0FBQ3RESCxlQUFTa0MsV0FBVztBQUNwQmQsMkJBQXFCM0IsV0FBVzJDLFVBQVVDLG1CQUFtQkMsT0FBTzdDLFdBQVdyQyxlQUFlLEVBQUUsQ0FBQztBQUNqRyxVQUFJcUMsV0FBV3BDLFdBQVc7QUFDdEIxQixnQkFBbUJLLHdCQUF3QnVHLFVBQVU5QyxXQUFXcEMsU0FBUyxFQUNwRW1GLEtBQUssQ0FBQUMsTUFBS3JDLGVBQWVxQyxFQUFFQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQzlDQyxNQUFNLE1BQU12QyxlQUFlLEVBQUUsQ0FBQztBQUFBLE1BQ3ZDO0FBQ0EsVUFBSVgsV0FBV3pDLFNBQVM0RixNQUFNQyxRQUFRcEQsV0FBV3pDLEtBQUssS0FBS3lDLFdBQVd6QyxNQUFNdUIsU0FBUyxHQUFHO0FBQ3BGLGNBQU11RSxRQUFTckQsV0FBV3pDLE1BQWlEK0YsT0FBTyxDQUFBQyxNQUFLQSxFQUFFQyxhQUFhLENBQUM7QUFDdkcsY0FBTUMsUUFBU3pELFdBQVd6QyxNQUFpRCtGLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsYUFBYSxDQUFDO0FBRXZHM0Msd0JBQWdCd0MsTUFBTW5FLElBQUksQ0FBQ3FFLE9BQU87QUFBQSxVQUM5Qm5FLFFBQVFtRSxFQUFFbkU7QUFBQUEsVUFDVkUsVUFBVWlFLEVBQUVqRTtBQUFBQSxVQUNaRSxNQUFNK0QsRUFBRS9EO0FBQUFBLFVBQ1JDLFFBQVFDLE9BQU82RCxFQUFFOUQsTUFBTSxLQUFLO0FBQUEsUUFDaEMsRUFBRSxDQUFDO0FBRUhzQiwwQkFBa0IwQyxNQUFNdkUsSUFBSSxDQUFDcUUsT0FBTztBQUFBLFVBQ2hDL0MsUUFBUUMsT0FBT0MsV0FBVztBQUFBLFVBQzFCdEIsUUFBUW1FLEVBQUVuRTtBQUFBQSxVQUNWRSxVQUFVaUUsRUFBRWpFLFlBQVlpRSxFQUFFcEUsS0FBS0ksUUFBUTtBQUFBLFVBQ3ZDRSxRQUFRQyxPQUFPNkQsRUFBRTlELE1BQU0sS0FBSztBQUFBLFFBQ2hDLEVBQUUsQ0FBQztBQUFBLE1BQ1A7QUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUNLLE1BQU1FLFVBQVUsQ0FBQztBQUVyQjFFLFlBQVUsTUFBTTtBQUNaLFFBQUkrRCxHQUFJO0FBQ1IsUUFBSVIsWUFBWUMsV0FBVyxHQUFHO0FBQzFCK0Isc0JBQWdCLEVBQUU7QUFDbEI7QUFBQSxJQUNKO0FBQ0EsUUFBSWhDLFlBQVlDLFNBQVMsR0FBRztBQUN4QitCLHNCQUFnQmhDLFlBQVlLLElBQUksQ0FBQXFFLE9BQU07QUFBQSxRQUNsQ25FLFFBQVFtRSxFQUFFbEU7QUFBQUEsUUFDVkMsVUFBVWlFLEVBQUVoRTtBQUFBQSxRQUNaQyxNQUFNK0QsRUFBRS9EO0FBQUFBLFFBQ1JDLFFBQVE7QUFBQSxNQUNaLEVBQUUsQ0FBQztBQUFBLElBQ1A7QUFBQSxFQUNKLEdBQUcsQ0FBQ0osSUFBSVIsV0FBVyxDQUFDO0FBRXBCdkQsWUFBVSxNQUFNO0FBQ1osUUFBSStELE1BQU1SLFlBQVlDLFdBQVcsRUFBRztBQUNwQyxVQUFNRixXQUFXSCxNQUFNaUYsT0FBTyxDQUFDQyxHQUFHQyxNQUFNRCxJQUFJakUsT0FBT2tFLEVBQUV4RyxRQUFRLElBQUlzQyxPQUFPa0UsRUFBRXZHLFVBQVUsR0FBRyxDQUFDO0FBQ3hGLFVBQU1xQixvQkFBb0IyQixTQUFTM0IscUJBQXFCO0FBQ3hELFVBQU1tRixhQUFhbEYsd0JBQXdCQyxVQUFVRixtQkFBbUJHLFdBQVc7QUFDbkZnQyxvQkFBZ0JnRCxVQUFVO0FBQUEsRUFDOUIsR0FBRyxDQUFDeEUsSUFBSVosT0FBTzRCLFNBQVMzQixtQkFBbUJHLFdBQVcsQ0FBQztBQUd2RHZELFlBQVUsTUFBTTtBQUNaYSxXQUFZLFNBQVMsRUFBRXNCLE1BQU0sSUFBSSxDQUFDLEVBQzdCc0YsS0FBSyxDQUFBZSxRQUFPN0MsbUJBQW1CNkMsSUFBSUMsUUFBUSxFQUFFLENBQUMsRUFDOUNiLE1BQU0sTUFBTWpDLG1CQUFtQixFQUFFLENBQUM7QUFBQSxFQUMzQyxHQUFHLEVBQUU7QUFFTCxRQUFNK0MsK0JBQStCQSxDQUFDNUUsUUFBZ0JLLFdBQW1CO0FBQ3JFb0Isb0JBQWdCLENBQUFvRCxTQUFRQSxLQUFLL0UsSUFBSSxDQUFBcUUsTUFBS0EsRUFBRW5FLFdBQVdBLFNBQVMsRUFBRSxHQUFHbUUsR0FBRzlELE9BQU8sSUFBSThELENBQUMsQ0FBQztBQUFBLEVBQ3JGO0FBRUEsUUFBTVcsbUJBQW1CM0ksUUFBUSxNQUFNO0FBQ25DLFVBQU1xRCxXQUFXSCxNQUFNaUYsT0FBTyxDQUFDQyxHQUFHQyxNQUFNRCxJQUFJakUsT0FBT2tFLEVBQUV4RyxRQUFRLElBQUlzQyxPQUFPa0UsRUFBRXZHLFVBQVUsR0FBRyxDQUFDO0FBQ3hGLFVBQU1xQixvQkFBb0IyQixTQUFTM0IscUJBQXFCO0FBQ3hELFVBQU15RixhQUFhdEYsWUFBWUMsV0FBVyxJQUNwQ0gsd0JBQXdCQyxVQUFVRixtQkFBbUJHLFdBQVcsRUFBRTZFLE9BQU8sQ0FBQ0MsR0FBR0osTUFBTUksSUFBSWpFLE9BQU82RCxFQUFFOUQsTUFBTSxHQUFHLENBQUMsSUFDMUdtQixhQUFhOEMsT0FBTyxDQUFDQyxHQUFHSixNQUFNSSxLQUFLakUsT0FBTzZELEVBQUU5RCxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2xFLFVBQU0yRSxvQkFBb0J0RCxlQUFlNEMsT0FBTyxDQUFDQyxHQUFHVSxNQUFNVixLQUFLakUsT0FBTzJFLEVBQUU1RSxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQ3hGLFVBQU02RSxRQUFRMUYsV0FBV3VGLGFBQWFDO0FBQ3RDLFdBQU8sRUFBRXhGLFVBQVVGLG1CQUFtQnlGLFlBQVlDLG1CQUFtQkUsTUFBTTtBQUFBLEVBQy9FLEdBQUcsQ0FBQzdGLE9BQU80QixTQUFTM0IsbUJBQW1CRyxhQUFhK0IsY0FBY0UsY0FBYyxDQUFDO0FBRWpGLFFBQU15RCxrQkFBa0JoSixRQUFRLE1BQU07QUFDbEMsVUFBTXFELFdBQVdILE1BQU1pRixPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlqRSxPQUFPa0UsRUFBRXhHLFFBQVEsSUFBSXNDLE9BQU9rRSxFQUFFdkcsVUFBVSxHQUFHLENBQUM7QUFDeEYsVUFBTXFCLG9CQUFvQjJCLFNBQVMzQixxQkFBcUI7QUFDeEQsUUFBSUcsWUFBWUMsV0FBVyxHQUFHO0FBQzFCLFlBQU0wRixVQUFVN0Ysd0JBQXdCQyxVQUFVRixtQkFBbUJHLFdBQVc7QUFDaEYsYUFBTzJGLFFBQVF0RixJQUFJLENBQUFxRSxPQUFNO0FBQUEsUUFDckJuRSxRQUFRbUUsRUFBRW5FO0FBQUFBLFFBQ1ZFLFVBQVVpRSxFQUFFakU7QUFBQUEsUUFDWkUsTUFBTStELEVBQUUvRDtBQUFBQSxRQUNSQyxRQUFRQyxPQUFPNkQsRUFBRTlELE1BQU07QUFBQSxNQUMzQixFQUFFO0FBQUEsSUFDTjtBQUNBLFdBQU9tQixhQUFhMUIsSUFBSSxDQUFBcUUsT0FBTTtBQUFBLE1BQzFCbkUsUUFBUW1FLEVBQUVuRTtBQUFBQSxNQUNWRSxVQUFVaUUsRUFBRWpFO0FBQUFBLE1BQ1prRSxVQUFVRCxFQUFFQztBQUFBQSxNQUNaaUIsZ0JBQWdCbEIsRUFBRWtCO0FBQUFBLE1BQ2xCdEYsS0FBS29FLEVBQUVwRTtBQUFBQSxNQUNQSyxNQUFNK0QsRUFBRS9EO0FBQUFBLE1BQ1JDLFFBQVFDLE9BQU82RCxFQUFFOUQsTUFBTTtBQUFBLElBQzNCLEVBQUU7QUFBQSxFQUNOLEdBQUcsQ0FBQ2hCLE9BQU80QixTQUFTM0IsbUJBQW1CRyxhQUFhK0IsWUFBWSxDQUFDO0FBRWpFLFFBQU04RCxzQkFBc0JsSixZQUFZLENBQUNtSixZQUFxQjtBQUMxRCxRQUFJLENBQUNBLFdBQVcsQ0FBQ3RFLFNBQVN6QyxVQUFXO0FBQ3JDeUUsOEJBQTBCLElBQUk7QUFDOUIsVUFBTXVDLE1BQU1ELFVBQ054SSxPQUEyQndJLE9BQU8sSUFDbEN4SSxPQUEyQixtQ0FBbUMsRUFBRXlCLFdBQVd5QyxTQUFTekMsVUFBVyxDQUFDO0FBQ3RHZ0gsUUFDSzdCLEtBQUssQ0FBQWUsUUFBTztBQUNUN0IsNkJBQXVCNkIsSUFBSUMsUUFBUSxFQUFFO0FBQ3JDNUIsNkJBQXVCMkIsSUFBSWUsUUFBUSxJQUFJO0FBQUEsSUFDM0MsQ0FBQyxFQUNBM0IsTUFBTSxNQUFNO0FBQ1R2SCxZQUFNbUosTUFBTSxxQ0FBcUM7QUFDakQ3Qyw2QkFBdUIsRUFBRTtBQUN6QkUsNkJBQXVCLElBQUk7QUFBQSxJQUMvQixDQUFDLEVBQ0E0QyxRQUFRLE1BQU0xQywwQkFBMEIsS0FBSyxDQUFDO0FBQUEsRUFDdkQsR0FBRyxDQUFDaEMsU0FBU3pDLFNBQVMsQ0FBQztBQUV2QnRDLFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ3NHLGtCQUFrQixDQUFDdkIsU0FBU3pDLFVBQVc7QUFDNUM4Ryx3QkFBb0I7QUFBQSxFQUN4QixHQUFHLENBQUM5QyxnQkFBZ0J2QixTQUFTekMsV0FBVzhHLG1CQUFtQixDQUFDO0FBRTVELFFBQU1NLHVCQUF1QkEsQ0FBQ0MsZUFBdUI7QUFDakQsUUFBSSxDQUFDNUUsU0FBU3pDLFdBQVc7QUFDckJqQyxZQUFNdUosS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxJQUNKO0FBQ0FuRCw0QkFBd0JrRCxVQUFVO0FBQ2xDcEQsc0JBQWtCLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU1zRCxvQkFBb0JBLENBQUNDLG1CQUF1QztBQUM5RCxRQUFJLENBQUN0RCxxQkFBc0I7QUFDM0IsVUFBTXVELGFBQWFELGVBQWVFLE9BQU9DLFNBQVMsT0FBTzdGLE9BQU8wRixlQUFlRSxNQUFNQyxLQUFLLElBQUk7QUFDOUZoRixhQUFTLENBQUEwRCxTQUFRQSxLQUFLL0U7QUFBQUEsTUFBSSxDQUFBd0QsT0FDdEJBLEdBQUdsQyxXQUFXc0IsdUJBQ1IsRUFBRSxHQUFHWSxJQUFJMEMsZ0JBQWdCaEksVUFBVSxHQUFHQyxZQUFZZ0ksV0FBVyxJQUM3RDNDO0FBQUFBLElBQ1YsQ0FBQztBQUNEYixzQkFBa0IsS0FBSztBQUN2QkUsNEJBQXdCLElBQUk7QUFBQSxFQUNoQztBQUVBLFFBQU15RCx1QkFBdUJBLENBQUNQLGVBQXVCO0FBQ2pEMUUsYUFBUyxDQUFBMEQsU0FBUUEsS0FBSy9FLElBQUksQ0FBQXdELE9BQU1BLEdBQUdsQyxXQUFXeUUsYUFBYSxFQUFFLEdBQUd2QyxJQUFJMEMsZ0JBQWdCLEtBQUssSUFBSTFDLEVBQUUsQ0FBQztBQUFBLEVBQ3BHO0FBRUEsUUFBTStDLFlBQVlBLE1BQU07QUFDcEJuRixnQkFBWSxFQUFFLEdBQUc5QyxlQUFlLENBQUM7QUFDakMrQyxhQUFTLENBQUMsRUFBRSxHQUFHdkQsYUFBYXdELFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMURDLG1CQUFlLEVBQUU7QUFDakJFLG9CQUFnQixFQUFFO0FBQ2xCRSxzQkFBa0IsRUFBRTtBQUNwQlkseUJBQXFCLEVBQUU7QUFDdkJFLHNCQUFrQixLQUFLO0FBQ3ZCRSw0QkFBd0IsSUFBSTtBQUM1QkUsMkJBQXVCLEVBQUU7QUFDekJFLDJCQUF1QixJQUFJO0FBQUEsRUFDL0I7QUFFQSxRQUFNdUQsdUJBQXVCLE9BQU9uRCxXQUFzQjtBQUN0RHBCLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNd0UsT0FBTyxNQUFNekosUUFBbUJLLHdCQUF3QnVHLFVBQVVQLE9BQU9sRCxFQUFFO0FBQ2pGLFlBQU05QixRQUFRb0ksS0FBSzFDLGdCQUFnQjtBQUNuQ3RDLHFCQUFlcEQsS0FBSztBQUNwQitDLGtCQUFZLENBQUEyRCxVQUFTO0FBQUEsUUFDakIsR0FBR0E7QUFBQUEsUUFDSHJHLFdBQVcrSCxLQUFLdEc7QUFBQUEsUUFDaEJ4QixhQUFhOEgsS0FBS3BHLFFBQVE7QUFBQSxRQUMxQnpCLGFBQWE2SCxLQUFLN0gsZUFBZTtBQUFBLFFBQ2pDSCxhQUFhO0FBQUEsUUFDYmdGLFVBQVVpRDtBQUFBQSxRQUNWbEksUUFBUWlJLEtBQUtFLFNBQVM1QixNQUFNdkcsVUFBVTtBQUFBLFFBQ3RDSyxhQUFha0csTUFBTWxHLGVBQWU7QUFBQSxRQUNsQ00sZUFBZTRGLE1BQU01RixpQkFBaUI7QUFBQSxNQUMxQyxFQUFFO0FBQ0ZrQyxlQUFTLENBQUMsRUFBRSxHQUFHdkQsYUFBYXdELFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMURpQiwyQkFBcUIsRUFBRTtBQUN2QmhHLFlBQU1tSyxRQUFRLDBDQUEwQztBQUFBLElBQzVELFNBQVNDLEtBQUs7QUFDVkMsY0FBUWxCLE1BQU1pQixHQUFHO0FBQ2pCcEssWUFBTW1KLE1BQU0sK0JBQStCO0FBQUEsSUFDL0MsVUFBQztBQUNHM0QsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU04RSx5QkFBeUIsWUFBWTtBQUN2QyxVQUFNQyxPQUFPN0YsU0FBU3ZDLGFBQWFxSSxLQUFLO0FBQ3hDLFFBQUksQ0FBQ0QsTUFBTTtBQUNQdkssWUFBTXVKLEtBQUssa0NBQWtDO0FBQzdDO0FBQUEsSUFDSjtBQUNBL0QsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNBLFlBQU1pRixRQUFRLE1BQU1oSyxjQUF5Qkcsd0JBQXdCdUcsVUFBVSxDQUFDLEVBQUV1RCxXQUFXLGVBQWVkLE9BQU9XLEtBQUssQ0FBQyxDQUFDO0FBQzFILFVBQUlFLE9BQU87QUFDUCxjQUFNVixxQkFBcUJVLEtBQUs7QUFBQSxNQUNwQyxPQUFPO0FBQ0h6SyxjQUFNbUosTUFBTSx3Q0FBd0NvQixJQUFJLElBQUk7QUFBQSxNQUNoRTtBQUFBLElBQ0osU0FBU0ksR0FBRztBQUNSTixjQUFRbEIsTUFBTXdCLENBQUM7QUFDZjNLLFlBQU1tSixNQUFNLDRCQUE0QjtBQUFBLElBQzVDLFVBQUM7QUFDRzNELGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxRQUFNb0YseUJBQXlCLE9BQU81RCxhQUF1QjtBQUN6RCxRQUFJLENBQUN0QyxTQUFTekMsV0FBVztBQUNyQmpDLFlBQU02SyxLQUFLLGtDQUFrQztBQUM3QztBQUFBLElBQ0o7QUFDQXJGLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNd0UsT0FBTyxNQUFNekosUUFBa0JJLG9CQUFvQndHLFVBQVVILFNBQVN0RCxFQUFFO0FBQzlFLFVBQUlzRyxLQUFLL0gsY0FBY3lDLFNBQVN6QyxXQUFXO0FBQ3ZDakMsY0FBTW1KLE1BQU0sbURBQW1EO0FBQy9EM0QsbUJBQVcsS0FBSztBQUNoQjtBQUFBLE1BQ0o7QUFDQSxZQUFNbUIsYUFBYXFELEtBQUtwRCxRQUFRaEQsUUFBUW9HLEtBQUs5SCxlQUFlO0FBQzVEeUMsa0JBQVksQ0FBQTJELFVBQVM7QUFBQSxRQUNqQixHQUFHQTtBQUFBQSxRQUNIdEcsYUFBYWdJLEtBQUt0RztBQUFBQSxRQUNsQnNELFVBQVU7QUFBQSxVQUNOdEQsSUFBSXNHLEtBQUt0RztBQUFBQSxVQUNUb0gsa0JBQWtCZCxLQUFLYyxvQkFBb0I1RCxPQUFPOEMsS0FBS3RHLEVBQUU7QUFBQSxVQUN6RHFILGVBQWVmLEtBQUtlO0FBQUFBLFVBQ3BCOUQsaUJBQWlCK0MsS0FBSy9DO0FBQUFBLFFBQzFCO0FBQUEsUUFDQWhGLFdBQVcrSCxLQUFLL0g7QUFBQUEsUUFDaEJDLGFBQWF5RTtBQUFBQSxRQUNiNUUsUUFBUWlJLEtBQUtqSSxVQUFVdUcsTUFBTXZHLFVBQVU7QUFBQSxRQUN2Q0ssYUFBYTRILEtBQUs1SCxlQUFla0csTUFBTWxHLGVBQWU7QUFBQSxRQUN0RE0sZUFBZXNILEtBQUt0SCxpQkFBaUI7QUFBQSxRQUNyQ0csc0JBQXNCO0FBQUEsTUFDMUIsRUFBRTtBQUNGbUQsMkJBQXFCZ0UsS0FBSy9DLG1CQUFtQkMsT0FBTzhDLEtBQUt0RyxFQUFFLENBQUM7QUFDNUQxRCxZQUFNbUssUUFBUSxzQkFBc0I7QUFBQSxJQUN4QyxTQUFTQyxLQUFLO0FBQ1ZDLGNBQVFsQixNQUFNaUIsR0FBRztBQUNqQnBLLFlBQU1tSixNQUFNLDRCQUE0QjtBQUFBLElBQzVDLFVBQUM7QUFDRzNELGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxRQUFNd0YsMkJBQTJCLFlBQVk7QUFDekMsUUFBSSxDQUFDdEcsU0FBU3pDLFdBQVc7QUFDckJqQyxZQUFNNkssS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxJQUNKO0FBQ0EsVUFBTU4sT0FBT3hFLGtCQUFrQnlFLEtBQUs7QUFDcEMsUUFBSSxDQUFDRCxNQUFNO0FBQ1B2SyxZQUFNdUosS0FBSyxpQ0FBaUM7QUFDNUM7QUFBQSxJQUNKO0FBQ0EvRCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsWUFBTWlGLFFBQVEsTUFBTWhLLGNBQXdCRSxvQkFBb0J3RyxVQUFVLENBQUMsRUFBRXVELFdBQVcsbUJBQW1CZCxPQUFPVyxLQUFLLENBQUMsQ0FBQztBQUN6SCxVQUFJRSxPQUFPO0FBQ1AsY0FBTUcsdUJBQXVCSCxLQUFLO0FBQUEsTUFDdEMsT0FBTztBQUNIekssY0FBTW1KLE1BQU0sMkNBQTJDO0FBQUEsTUFDM0Q7QUFBQSxJQUNKLFNBQVN3QixHQUFHO0FBQ1JOLGNBQVFsQixNQUFNd0IsQ0FBQztBQUNmM0ssWUFBTW1KLE1BQU0sNEJBQTRCO0FBQUEsSUFDNUMsVUFBQztBQUNHM0QsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU15Rix3QkFBd0JBLENBQUNDLGFBQWtCO0FBQzdDLFFBQUlyRixrQkFBa0IsVUFBVTtBQUM1QmtFLDJCQUFxQm1CLFFBQXFCO0FBQUEsSUFDOUMsT0FBTztBQUNITiw2QkFBdUJNLFFBQW9CO0FBQUEsSUFDL0M7QUFDQXBGLHFCQUFpQixJQUFJO0FBQ3JCSixtQkFBZSxLQUFLO0FBQUEsRUFDeEI7QUFFQSxRQUFNeUYsZ0JBQWdCQSxNQUFNdkcsU0FBUyxDQUFBMEQsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRSxHQUFHakgsYUFBYXdELFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDdkcsUUFBTXFHLG1CQUFtQkEsQ0FBQ3ZHLFdBQW1CRCxTQUFTLENBQUEwRCxTQUFTQSxLQUFLbkYsU0FBUyxJQUFJbUYsS0FBS1gsT0FBTyxDQUFBTSxNQUFLQSxFQUFFcEQsV0FBV0EsTUFBTSxJQUFJeUQsSUFBSztBQUM5SCxRQUFNK0MsbUJBQW1CQSxDQUFDeEcsUUFBZ0J5RyxPQUF3QzFCLFVBQTJCO0FBQ3pHaEYsYUFBUyxDQUFBMEQsU0FBUUEsS0FBSy9FLElBQUksQ0FBQTBFLE1BQU1BLEVBQUVwRCxXQUFXQSxTQUFTLEVBQUUsR0FBR29ELEdBQUcsQ0FBQ3FELEtBQUssR0FBRzFCLE1BQU0sSUFBSTNCLENBQUUsQ0FBQztBQUFBLEVBQ3hGO0FBRUEsUUFBTXNELHNCQUFzQixZQUFZO0FBQ3BDLFFBQUk3RyxTQUFTNUMsU0FBUyxVQUFVO0FBQzVCOUIsWUFBTXVKLEtBQUssc0RBQXNEO0FBQ2pFO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQzdFLFNBQVMxQyxhQUFhO0FBQ3ZCaEMsWUFBTTZLLEtBQUssNENBQTRDO0FBQ3ZEO0FBQUEsSUFDSjtBQUVBckYsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNBLFlBQU13QixXQUFXLE1BQU16RyxRQUFrQkksb0JBQW9Cd0csVUFBVXpDLFNBQVMxQyxXQUFXO0FBRzNGLFVBQUl3SixpQkFBaUI7QUFFckIsVUFBSWhFLE1BQU1DLFFBQVFULFNBQVNsRSxLQUFLLEtBQUtrRSxTQUFTbEUsTUFBTUssU0FBUyxHQUFHO0FBQzVEcUkseUJBQWlCeEUsU0FBU2xFLE1BQU1pRixPQUFPLENBQUMwRCxLQUFhMUUsT0FBWTtBQUM3RCxjQUFJLE9BQU9BLEdBQUc2QyxVQUFVLFNBQVUsUUFBTzZCLE1BQU0xSCxPQUFPZ0QsR0FBRzZDLEtBQUs7QUFDOUQsZ0JBQU04QixNQUFNM0gsT0FBT2dELEdBQUd0RixRQUFRLEtBQUs7QUFDbkMsZ0JBQU1rSyxPQUFPNUgsT0FBT2dELEdBQUdyRixVQUFVLEtBQUs7QUFDdEMsaUJBQU8rSixNQUFNQyxNQUFNQztBQUFBQSxRQUN2QixHQUFHLENBQUM7QUFBQSxNQUNSLFdBQVduRSxNQUFNQyxRQUFTVCxTQUFpQjRFLFFBQVEsS0FBTTVFLFNBQWlCNEUsU0FBU3pJLFNBQVMsR0FBRztBQUMzRixjQUFNeUksV0FBWTVFLFNBQWlCNEU7QUFDbkNKLHlCQUFpQkksU0FBUzdELE9BQU8sQ0FBQzBELEtBQUtJLE1BQU1KLE9BQU8xSCxPQUFPOEgsRUFBRXBLLFFBQVEsS0FBSyxNQUFNc0MsT0FBTzhILEVBQUVDLFVBQVUsS0FBSyxJQUFJLENBQUM7QUFBQSxNQUNqSCxXQUFXLE9BQU85RSxTQUFTdkUsaUJBQWlCLFVBQVU7QUFDbEQrSSx5QkFBaUJ6SCxPQUFPaUQsU0FBU3ZFLFlBQVksS0FBSztBQUFBLE1BQ3REO0FBRUEsVUFBSStJLGtCQUFrQixHQUFHO0FBQ3JCeEwsY0FBTW1KLE1BQU0scUVBQXFFO0FBQ2pGO0FBQUEsTUFDSjtBQUVBLFlBQU00QyxZQUFzQjtBQUFBLFFBQ3hCLEdBQUcxSztBQUFBQSxRQUNId0QsUUFBUUMsT0FBT0MsV0FBVztBQUFBLFFBQzFCeEQsYUFBYTtBQUFBLFFBQ2JFLFVBQVU7QUFBQSxRQUNWQyxZQUFZOEo7QUFBQUEsUUFDWjdKLHFCQUFxQjtBQUFBLFFBQ3JCQyxPQUFPO0FBQUEsUUFDUDZILGdCQUFnQjtBQUFBLE1BQ3BCO0FBQ0E3RSxlQUFTLENBQUNtSCxTQUFTLENBQUM7QUFFcEIsWUFBTUMsV0FBYWhGLFNBQWlCaUYsaUJBQWlCO0FBQ3JELFVBQUl6RSxNQUFNQyxRQUFRdUUsUUFBUSxLQUFLQSxTQUFTN0ksU0FBUyxHQUFHO0FBQ2hELGNBQU11RSxRQUFRc0UsU0FBU3JFLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsYUFBYSxDQUFDO0FBQ25ELGNBQU1DLFFBQVFrRSxTQUFTckUsT0FBTyxDQUFBQyxNQUFLQSxFQUFFQyxhQUFhLENBQUM7QUFFbkQzQyx3QkFBZ0J3QyxNQUFNbkUsSUFBSSxDQUFBcUUsT0FBTTtBQUFBLFVBQzVCbkUsUUFBUW1FLEVBQUVuRTtBQUFBQSxVQUNWRSxVQUFVaUUsRUFBRWpFO0FBQUFBLFVBQ1pFLE1BQU0rRCxFQUFFL0Q7QUFBQUEsVUFDUkMsUUFBUUMsT0FBTzZELEVBQUU5RCxNQUFNLEtBQUs7QUFBQSxRQUNoQyxFQUFFLENBQUM7QUFFSHNCLDBCQUFrQjBDLE1BQU12RSxJQUFJLENBQUFxRSxPQUFNO0FBQUEsVUFDOUIvQyxRQUFRQyxPQUFPQyxXQUFXO0FBQUEsVUFDMUJ0QixRQUFRbUUsRUFBRW5FO0FBQUFBLFVBQ1ZFLFVBQVVpRSxFQUFFakUsWUFBWWlFLEVBQUVwRSxLQUFLSSxRQUFRO0FBQUEsVUFDdkNFLFFBQVFDLE9BQU82RCxFQUFFOUQsTUFBTSxLQUFLO0FBQUEsUUFDaEMsRUFBRSxDQUFDO0FBQUEsTUFDUCxPQUFPO0FBQ0hvQix3QkFBZ0IsRUFBRTtBQUNsQkUsMEJBQWtCLEVBQUU7QUFBQSxNQUN4QjtBQUVBVCxrQkFBWSxDQUFBMkQsVUFBUztBQUFBLFFBQ2pCLEdBQUdBO0FBQUFBLFFBQ0h2RixtQkFBb0JpRSxTQUFpQmpFLHFCQUFxQnVGLEtBQUt2RixxQkFBcUI7QUFBQSxNQUN4RixFQUFFO0FBRUYvQyxZQUFNbUssUUFBUSwyREFBMkQ7QUFBQSxJQUM3RSxTQUFTaEIsT0FBTztBQUNaa0IsY0FBUWxCLE1BQU1BLEtBQUs7QUFDbkJuSixZQUFNbUosTUFBTSw0REFBNEQ7QUFBQSxJQUM1RSxVQUFDO0FBQ0czRCxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTTBHLHlCQUF5QnRNLFFBQVEsTUFBTTtBQUN6QyxRQUFJc0QsWUFBWUMsV0FBVyxHQUFHO0FBQzFCLFlBQU1GLFdBQVdILE1BQU1pRixPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlqRSxPQUFPa0UsRUFBRXhHLFFBQVEsSUFBSXNDLE9BQU9rRSxFQUFFdkcsVUFBVSxHQUFHLENBQUM7QUFDeEYsWUFBTXFCLG9CQUFvQjJCLFNBQVMzQixxQkFBcUI7QUFDeEQsYUFBT0Msd0JBQXdCQyxVQUFVRixtQkFBbUJHLFdBQVc7QUFBQSxJQUMzRTtBQUNBLFdBQU8rQjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ25DLE9BQU80QixTQUFTM0IsbUJBQW1CRyxhQUFhK0IsWUFBWSxDQUFDO0FBRWpFLFFBQU1rSCxhQUFhLFlBQVk7QUFDM0IsUUFBSSxDQUFDekgsU0FBU3pDLFdBQVc7QUFDckJqQyxZQUFNNkssS0FBSywwQkFBMEI7QUFDckM7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDbkcsU0FBUzFDLGFBQWE7QUFDdkJoQyxZQUFNNkssS0FBSyx3QkFBd0I7QUFDbkM7QUFBQSxJQUNKO0FBQ0EsUUFBSS9ILE1BQU1LLFdBQVcsS0FBS0wsTUFBTXNKLEtBQUssQ0FBQXJGLE9BQU0sQ0FBQ0EsR0FBR3hGLGFBQWFpSixLQUFLLENBQUMsR0FBRztBQUNqRXhLLFlBQU02SyxLQUFLLG1DQUFtQztBQUM5QztBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNuRyxTQUFTM0MsUUFBUTtBQUNsQi9CLFlBQU02SyxLQUFLLDBCQUEwQjtBQUNyQztBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNuRyxTQUFTMkgsZ0JBQWdCN0IsS0FBSyxHQUFHO0FBQ2xDeEssWUFBTTZLLEtBQUssMENBQTBDO0FBQ3JEO0FBQUEsSUFDSjtBQUVBLFVBQU15QixhQUFheEosTUFBTVMsSUFBSSxDQUFDd0QsSUFBSXdGLFFBQVE7QUFDdEMsWUFBTSxFQUFFMUgsUUFBUTRFLGdCQUFnQixHQUFHK0MsS0FBSyxJQUFJekY7QUFDNUMsYUFBTztBQUFBLFFBQ0gsR0FBR3lGO0FBQUFBLFFBQ0hsTCxhQUFhaUwsTUFBTTtBQUFBLFFBQ25CLEdBQUk5QyxnQkFBZ0IvRixNQUFNLFFBQVEsRUFBRStJLHVCQUF1QmhELGVBQWUvRixHQUFHO0FBQUEsTUFDakY7QUFBQSxJQUNKLENBQUM7QUFDRCxVQUFNZ0osYUFBYVIsdUJBQ2R2RSxPQUFPLENBQUFDLE1BQUs3RCxPQUFPNkQsRUFBRTlELE1BQU0sSUFBSSxDQUFDLEVBQ2hDUCxJQUFJLENBQUFxRSxPQUFNLEVBQUUsR0FBR0EsR0FBR0MsVUFBVSxFQUFXLEVBQUU7QUFFOUMsVUFBTThFLGFBQWF4SCxlQUNkd0MsT0FBTyxDQUFBZSxNQUFLQSxFQUFFakYsVUFBVSxRQUFRTSxPQUFPMkUsRUFBRTVFLE1BQU0sSUFBSSxDQUFDLEVBQ3BEUCxJQUFJLENBQUFtRixPQUFNO0FBQUEsTUFDUGpGLFFBQVFpRixFQUFFakY7QUFBQUEsTUFDVkUsVUFBVStFLEVBQUUvRSxZQUFZO0FBQUEsTUFDeEJFLE1BQU07QUFBQSxNQUNOQyxRQUFRNEUsRUFBRTVFO0FBQUFBLE1BQ1YrRCxVQUFVO0FBQUEsSUFDZCxFQUFFO0FBRU4sVUFBTStFLFVBQTBDO0FBQUEsTUFDNUMsR0FBR2xJO0FBQUFBLE1BQ0g1QyxNQUFNNEMsU0FBUzVDLFFBQVE7QUFBQSxNQUN2QnVLLGdCQUFnQjNILFNBQVMySCxlQUFlN0IsS0FBSztBQUFBLE1BQzdDekksUUFBUTJDLFNBQVMzQyxVQUFVO0FBQUEsTUFDM0JDLGFBQWEwQyxTQUFTMUM7QUFBQUEsTUFDdEJDLFdBQVd5QyxTQUFTekM7QUFBQUEsTUFDcEJFLGFBQWF1QyxTQUFTdkMsZUFBZThIO0FBQUFBLE1BQ3JDL0gsYUFBYXdDLFNBQVN4QyxlQUFlK0g7QUFBQUEsTUFDckM3SCxhQUFhc0MsU0FBU3RDLGVBQWU7QUFBQSxNQUNyQ0MsWUFBWXFDLFNBQVNyQyxlQUFjLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3hFQyxjQUFjOEYsaUJBQWlCSTtBQUFBQSxNQUMvQmpHLGVBQWVnQyxTQUFTaEMsaUJBQWlCO0FBQUEsTUFDekNmLHFCQUFxQitDLFNBQVMvQyx1QkFBdUI7QUFBQSxNQUNyRGdCLFFBQVErQixTQUFTL0IsVUFBVTtBQUFBLE1BQzNCQyxPQUFPOEIsU0FBUzlCLFNBQVM7QUFBQSxNQUN6QmlLLFNBQVM7QUFBQSxNQUNUOUosbUJBQW1CMkIsU0FBUzNCLHFCQUFxQjtBQUFBLE1BQ2pERixzQkFBc0I7QUFBQSxNQUN0QkMsT0FBT3dKO0FBQUFBLE1BQ1AxSyxPQUFPLENBQUMsR0FBRzhLLFlBQVksR0FBR0MsVUFBVTtBQUFBLElBQ3hDO0FBRUEsUUFBSTtBQUNBLFlBQU1HLFFBQVEsTUFBTXRJLFNBQVNvSSxPQUF5QztBQUN0RSxVQUFJRSxPQUFPO0FBQ1A5TSxjQUFNbUssUUFBUSwyQkFBMkI7QUFDekNqRyxpQkFBUzlDLGtCQUFrQlYsbUNBQW1DcU0sU0FBUyxDQUFDO0FBQUEsTUFDNUU7QUFBQSxJQUNKLFNBQVNwQyxHQUFHO0FBQ1IzSyxZQUFNbUosTUFBTSxtQkFBbUI7QUFBQSxJQUNuQztBQUFBLEVBQ0o7QUFFQSxNQUFJNUUsWUFBYSxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUV2QyxRQUFNeUksYUFBYTtBQUNuQixRQUFNQyxzQkFBc0J2SSxTQUFTekMsWUFDL0IsRUFBRSxHQUFHdEIscUJBQXFCdU0sZ0JBQWdCLEVBQUVqTCxXQUFXeUMsU0FBU3pDLFVBQVUsRUFBRSxJQUM1RXRCO0FBRU4sU0FDSSx1QkFBQyxTQUFJLFdBQVUsK0RBQ1Q0RTtBQUFBQSxrQkFBYWQsV0FDWCx1QkFBQyxTQUFJLFdBQVUsOEdBQ1g7QUFBQSw2QkFBQyxhQUFVLFdBQVUsK0NBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxVQUFLLFdBQVUscUNBQW9DLDZCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsU0FGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHSix1QkFBQyxRQUFHLFdBQVUsdUNBQ1ROLG1CQUFTLFdBQVcsMEJBQTBCLGVBQWVPLFNBQVMySCxrQkFBa0IzSSxFQUFFLE1BRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyx5Q0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxPQUFPZ0IsU0FBUzJILGtCQUFrQjtBQUFBLFlBQ2xDLFVBQVUsQ0FBQTFCLE1BQUtoRyxZQUFZLENBQUEyRCxVQUFTLEVBQUUsR0FBR0EsTUFBTStELGdCQUFnQjFCLEVBQUV3QyxPQUFPdkQsTUFBTSxFQUFFO0FBQUEsWUFDaEYsV0FBV29EO0FBQUFBLFlBQ1gsYUFBWTtBQUFBLFlBQVksY0FBYTtBQUFBO0FBQUEsVUFMekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzhDO0FBQUEsV0FQbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLG9CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU90SSxTQUFTNUMsUUFBUTtBQUFBLFlBQ3hCLFVBQVUsQ0FBQTZJLE1BQUtoRyxZQUFZLENBQUEyRCxVQUFTLEVBQUUsR0FBR0EsTUFBTXhHLE1BQU02SSxFQUFFd0MsT0FBT3ZELE1BQTRCLEVBQUU7QUFBQSxZQUM1RixXQUFXb0Q7QUFBQUEsWUFFWDtBQUFBLHFDQUFDLFlBQU8sT0FBTSxTQUFRLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QjtBQUFBLGNBQzVCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHVCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBO0FBQUE7QUFBQSxVQU5sQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLHlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU90SSxTQUFTM0MsVUFBVTtBQUFBLFlBQzFCLFVBQVUsQ0FBQTRJLE1BQUtoRyxZQUFZLENBQUEyRCxVQUFTLEVBQUUsR0FBR0EsTUFBTXZHLFFBQVE0SSxFQUFFd0MsT0FBT3ZELE1BQU0sRUFBRTtBQUFBLFlBQ3hFLFdBQVdvRDtBQUFBQSxZQUVYO0FBQUEscUNBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUE7QUFBQTtBQUFBLFVBUnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBV3RJLFNBQVN2QyxlQUFlO0FBQUEsWUFDbkMsV0FBV3VDLFNBQVN4QyxlQUFlO0FBQUEsWUFDbkMsY0FBYyxDQUFDa0wsTUFBTXpJLFlBQVksQ0FBQTJELFVBQVMsRUFBRSxHQUFHQSxNQUFNbkcsYUFBYWlMLEtBQUssR0FBRyxFQUFFO0FBQUEsWUFDNUUsY0FBYzlDO0FBQUFBLFlBQ2QsZUFBZSxNQUFNO0FBQUUxRSw2QkFBZWhGLHVCQUE0QztBQUFHa0YsK0JBQWlCLFFBQVE7QUFBR0osNkJBQWUsSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUN2SSxjQUFjb0U7QUFBQUE7QUFBQUEsVUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTRCO0FBQUEsV0FSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLGlDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsUUFDNUUsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFVBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVcvRDtBQUFBQSxjQUNYLFdBQVdyQixTQUFTMUMsY0FBZTBDLFNBQVNzQyxVQUFVQyxrQkFBa0IsZUFBZXZDLFNBQVNzQyxVQUFVQyxlQUFlLEtBQUssY0FBY3ZDLFNBQVMxQyxXQUFXLEtBQU07QUFBQSxjQUN0SyxjQUFjLENBQUNvTCxNQUFNcEgscUJBQXFCb0gsS0FBSyxFQUFFO0FBQUEsY0FDakQsY0FBY3BDO0FBQUFBLGNBQ2QsZUFBZSxNQUFNO0FBQUVwRiwrQkFBZXFILG1CQUF3QztBQUFHbkgsaUNBQWlCLFVBQVU7QUFBR0osK0JBQWUsSUFBSTtBQUFBLGNBQUc7QUFBQSxjQUNySSxjQUFjLE1BQU07QUFBRWYsNEJBQVksQ0FBQTJELFVBQVMsRUFBRSxHQUFHQSxNQUFNdEcsYUFBYSxHQUFHZ0YsVUFBVWlELE9BQVUsRUFBRTtBQUFHckYseUJBQVMsQ0FBQyxFQUFFLEdBQUd2RCxhQUFhd0QsUUFBUUMsT0FBT0MsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUFHaUIscUNBQXFCLEVBQUU7QUFBQSxjQUFHO0FBQUEsY0FDdEwsVUFBVSxDQUFDdEIsU0FBU3pDO0FBQUFBO0FBQUFBLFlBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9rQyxLQVJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsU0FBU3NKO0FBQUFBLGNBQ1QsVUFBVSxDQUFDN0csU0FBUzFDLGVBQWUwQyxTQUFTNUMsU0FBUyxZQUFZeUQsYUFBYWQ7QUFBQUEsY0FDOUUsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBQWdEO0FBQUE7QUFBQSxZQUwxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxXQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLE9BQU9DLFNBQVNyQyxjQUFjO0FBQUEsWUFDOUIsVUFBVSxDQUFBc0ksTUFBS2hHLFlBQVksQ0FBQTJELFVBQVMsRUFBRSxHQUFHQSxNQUFNakcsWUFBWXNJLEVBQUV3QyxPQUFPdkQsTUFBTSxFQUFFO0FBQUEsWUFDNUUsV0FBV29EO0FBQUFBLFlBQVksY0FBYTtBQUFBO0FBQUEsVUFKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTZDO0FBQUEsV0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLHFCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQU07QUFBQSxZQUNOLE9BQU90SSxTQUFTOUIsU0FBUztBQUFBLFlBQ3pCLFVBQVUsQ0FBQStILE1BQUtoRyxZQUFZLENBQUEyRCxVQUFTLEVBQUUsR0FBR0EsTUFBTTFGLE9BQU8rSCxFQUFFd0MsT0FBT3ZELFNBQVMsS0FBSyxFQUFFO0FBQUEsWUFDL0UsV0FBV29EO0FBQUFBLFlBQVksY0FBYTtBQUFBO0FBQUEsVUFKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTZDO0FBQUEsV0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0F0Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVGQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDBDQUF5QyxxQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFNBQUksV0FBVSxxQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1FQUFrRSwyQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUsd0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSx3QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxRQUFHLFdBQVUsb0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQSxhQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWmxLLGdCQUFNUztBQUFBQSxVQUFJLENBQUM4SixRQUNSLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsYUFDVjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxPQUFPQSxJQUFJOUw7QUFBQUEsa0JBQ1gsVUFBVSxDQUFBb0osTUFBS1UsaUJBQWlCZ0MsSUFBSXhJLFFBQVEsZUFBZThGLEVBQUV3QyxPQUFPdkQsS0FBSztBQUFBLGtCQUN6RSxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUF1QixjQUFhO0FBQUE7QUFBQSxnQkFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS3lEO0FBQUEsY0FDeER5RCxJQUFJNUQsZ0JBQWdCRSxTQUNqQix1QkFBQyxTQUFJLFdBQVUsZ0VBQ1g7QUFBQSx1Q0FBQyxVQUFJO0FBQUE7QUFBQSxrQkFDb0IwRCxJQUFJNUQsZUFBZUUsTUFBTTJEO0FBQUFBLGtCQUFhO0FBQUEsa0JBQVlELElBQUk1RCxlQUFlRSxNQUFNNEQsZ0JBQWdCO0FBQUEsa0JBQU07QUFBQSxrQkFBWUYsSUFBSTVELGVBQWVFLE1BQU02RCxvQkFBb0I7QUFBQSxxQkFEbkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTNELHFCQUFxQndELElBQUl4SSxNQUFNLEdBQUcsV0FBVSxtQ0FBa0MsT0FBTSxpQkFBZ0IsaUJBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBJO0FBQUEsbUJBSjlJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsd0JBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxLQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU93SSxJQUFJNUw7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFBZ00sUUFBT3BDLGlCQUFpQmdDLElBQUl4SSxRQUFRLFlBQVk0SSxHQUFHO0FBQUEsZ0JBQzdELFdBQVU7QUFBQTtBQUFBLGNBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2dGLEtBTnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx3QkFDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxPQUFPSixJQUFJM0w7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFBK0wsUUFBT3BDLGlCQUFpQmdDLElBQUl4SSxRQUFRLGNBQWM0SSxHQUFHO0FBQUEsZ0JBQy9ELFdBQVU7QUFBQTtBQUFBLGNBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWdGLEtBTHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw0Q0FBNEN4TSxzQkFBWThDLE9BQU9zSixJQUFJNUwsUUFBUSxJQUFJc0MsT0FBT3NKLElBQUkzTCxVQUFVLEdBQUcsVUFBVSxLQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSTtBQUFBLFlBQ2pJLHVCQUFDLFFBQUcsV0FBVSxpREFDVjtBQUFBLHFDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTJILHFCQUFxQmdFLElBQUl4SSxNQUFNLEdBQUcsV0FBVSw2Q0FBNEMsT0FBTSwyQkFBMEIsVUFBVSxDQUFDSCxTQUFTekMsV0FDN0ssaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNbUosaUJBQWlCaUMsSUFBSXhJLE1BQU0sR0FBRyxXQUFVLG1DQUFrQyxPQUFNLGVBQWMsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRLEtBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThJO0FBQUEsaUJBSmxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQXhDS3dJLElBQUl4SSxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBO0FBQUEsUUFDSCxLQTVDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsV0F2REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdEQSxLQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMERBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTc0csZUFBZSxXQUFVLHVKQUNwRDtBQUFBLCtCQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBQUc7QUFBQSxXQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0VBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdURBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLG1DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsUUFDckUsdUJBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHNEQUFxRCw2Q0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxVQUNuRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsT0FBT3pHLFNBQVMzQjtBQUFBQSxjQUNoQixVQUFVLENBQUEwSyxRQUFPOUksWUFBWSxDQUFBMkQsVUFBUyxFQUFFLEdBQUdBLE1BQU12RixtQkFBbUIwSyxPQUFPLEVBQUUsRUFBRTtBQUFBLGNBQy9FLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUttQjtBQUFBLGFBUHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0M3RSxnQkFBZ0J6RixTQUFTLElBQ3RCLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Y7QUFBQSxZQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRjtBQUFBLFlBQ25GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsZUFIcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnlGLDBCQUFnQnJGO0FBQUFBLFlBQUksQ0FBQ0MsS0FBSytJLFFBQ3ZCLHVCQUFDLFFBQ0c7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsOENBQThDL0ksY0FBSUcsWUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUU7QUFBQSxjQUN6RSx1QkFBQyxRQUFHLFdBQVUsOENBQThDekMsNEJBQWtCc0MsR0FBRyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRjtBQUFBLGNBQ25GLHVCQUFDLFFBQUcsV0FBVSxnQ0FDVE4sc0JBQVlDLFNBQVMsS0FBSyxPQUFPSyxJQUFJQyxXQUFXLFdBQzdDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxPQUFPRCxJQUFJTTtBQUFBQSxrQkFDWCxVQUFVLENBQUEySixRQUFPcEYsNkJBQTZCN0UsSUFBSUMsUUFBa0JnSyxPQUFPLENBQUM7QUFBQSxrQkFDNUUsV0FBVTtBQUFBO0FBQUEsZ0JBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSWdGLElBR2hGLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJ4TSxzQkFBWXVDLElBQUlNLFFBQVEsVUFBVSxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRSxLQVQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsaUJBZEtOLElBQUlDLFVBQVU4SSxLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsVUFDSCxLQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMkNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUV6RSx1QkFBQyxTQUFJLFdBQVUsc0NBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMENBQXlDLDRCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLFVBQ2xFbEgsZ0JBQWdCbEMsV0FBVyxJQUN4Qix1QkFBQyxPQUFFLFdBQVUseUJBQXdCLGlEQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRSxJQUV0RSxtQ0FDSTtBQUFBLG1DQUFDLFNBQUksV0FBVSxhQUNWZ0MseUJBQWU1QjtBQUFBQSxjQUFJLENBQUM4SixRQUNqQix1QkFBQyxTQUFxQixXQUFVLHVDQUM1QjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE9BQU9BLElBQUk1SixVQUFVO0FBQUEsb0JBQ3JCLFVBQVUsQ0FBQ2tILE1BQU07QUFDYiw0QkFBTStDLE1BQU0vQyxFQUFFd0MsT0FBT3ZEO0FBQ3JCLDBCQUFJLENBQUM4RCxLQUFLO0FBQ050SSwwQ0FBa0IsQ0FBQWtELFNBQVFBLEtBQUsvRSxJQUFJLENBQUFtRixNQUFLQSxFQUFFN0QsV0FBV3dJLElBQUl4SSxTQUFTLEVBQUUsR0FBRzZELEdBQUdqRixRQUFRLE1BQU1FLFVBQVUsS0FBSyxJQUFJK0UsQ0FBQyxDQUFDO0FBQzdHO0FBQUEsc0JBQ0o7QUFDQSw0QkFBTWxGLE1BQU02QixnQkFBZ0JzSSxLQUFLLENBQUEvRixNQUFLQSxFQUFFbEUsT0FBT0ssT0FBTzJKLEdBQUcsQ0FBQztBQUMxRCwwQkFBSSxDQUFDbEssSUFBSztBQUNWLDRCQUFNb0ssY0FBY3pJLGVBQWVpSCxLQUFLLENBQUExRCxNQUFLQSxFQUFFN0QsV0FBV3dJLElBQUl4SSxVQUFVNkQsRUFBRWpGLFdBQVdELElBQUlFLEVBQUU7QUFDM0YsMEJBQUlrSyxhQUFhO0FBQ2I1Tiw4QkFBTTZLLEtBQUssMERBQTBEO0FBQ3JFO0FBQUEsc0JBQ0o7QUFDQXpGLHdDQUFrQixDQUFBa0QsU0FBUUEsS0FBSy9FO0FBQUFBLHdCQUFJLENBQUFtRixNQUMvQkEsRUFBRTdELFdBQVd3SSxJQUFJeEksU0FBUyxFQUFFLEdBQUc2RCxHQUFHakYsUUFBUUQsSUFBSUUsSUFBSUMsVUFBVUgsSUFBSUksS0FBSyxJQUFJOEU7QUFBQUEsc0JBQzdFLENBQUM7QUFBQSxvQkFDTDtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLHFDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzQztBQUFBLHNCQUNyQ3JELGdCQUFnQjlCO0FBQUFBLHdCQUFJLENBQUNDLFFBQ2xCLHVCQUFDLFlBQW9CLE9BQU9BLElBQUlFLElBQUksVUFBVXlCLGVBQWVpSCxLQUFLLENBQUExRCxNQUFLQSxFQUFFN0QsV0FBV3dJLElBQUl4SSxVQUFVNkQsRUFBRWpGLFdBQVdELElBQUlFLEVBQUUsR0FDaEhGLGNBQUlJLFFBRElKLElBQUlFLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDSDtBQUFBO0FBQUE7QUFBQSxrQkExQkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTJCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE9BQU8ySixJQUFJdko7QUFBQUEsc0JBQ1gsVUFBVSxDQUFBMkosUUFBT3JJLGtCQUFrQixDQUFBa0QsU0FBUUEsS0FBSy9FO0FBQUFBLHdCQUFJLENBQUFtRixNQUNoREEsRUFBRTdELFdBQVd3SSxJQUFJeEksU0FBUyxFQUFFLEdBQUc2RCxHQUFHNUUsUUFBUTJKLE9BQU8sRUFBRSxJQUFJL0U7QUFBQUEsc0JBQzNELENBQUM7QUFBQSxzQkFDRCxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBO0FBQUEsb0JBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNbUI7QUFBQSxrQkFFbkI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTXRELGtCQUFrQixDQUFBa0QsU0FBUUEsS0FBS1gsT0FBTyxDQUFBZSxNQUFLQSxFQUFFN0QsV0FBV3dJLElBQUl4SSxNQUFNLENBQUM7QUFBQSxzQkFDbEYsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVE7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQTlDTXdJLElBQUl4SSxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0NBO0FBQUEsWUFDSCxLQWxETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1EQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNTyxrQkFBa0IsQ0FBQWtELFNBQVEsQ0FBQyxHQUFHQSxNQUFNLEVBQUV6RCxRQUFRQyxPQUFPQyxXQUFXLEdBQUd0QixRQUFRLE1BQU1FLFVBQVUsTUFBTUcsUUFBUSxFQUFFLENBQUMsQ0FBQztBQUFBLGdCQUM1SCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTREQTtBQUFBLGFBakVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRUE7QUFBQSxXQWxISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUhBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUscURBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBaUI3QyxzQkFBWXNILGlCQUFpQnRGLFVBQVUsVUFBVSxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLGFBQWxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUw7QUFBQSxRQUN6TCx1QkFBQyxTQUFJLFdBQVUsOENBQTZDO0FBQUEsaUNBQUMsVUFBSyw4Q0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQU8sdUJBQUMsVUFBTWhDLHNCQUFZc0gsaUJBQWlCeEYscUJBQXFCLEdBQUcsVUFBVSxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0w7QUFBQSxRQUN0TCx1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFlBQUc5QixZQUFZc0gsaUJBQWlCQyxZQUFZLFVBQVU7QUFBQSxlQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLGFBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEw7QUFBQSxRQUM5TCx1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFlBQUd2SCxZQUFZc0gsaUJBQWlCRSxtQkFBbUIsVUFBVTtBQUFBLGVBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsYUFBak07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TTtBQUFBLFFBQ3hNLHVCQUFDLFNBQUksV0FBVSwyQ0FBMEM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMkJBQTBCLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQU8sdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnhILHNCQUFZc0gsaUJBQWlCSSxPQUFPLFVBQVUsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxhQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9OO0FBQUEsV0FMeE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0EzSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRIQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsNkJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNekUsU0FBUzlDLGtCQUFrQlYsbUNBQW1DcU0sU0FBUyxDQUFDLEdBQUcsV0FBVSxxSEFBb0gsd0JBQTlPO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc1A7QUFBQSxNQUN0UCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTWixZQUFZLFVBQVU1RyxhQUFhZCxRQUFRLFdBQVUsMEtBQ2hGO0FBQUEsK0JBQUMsVUFBTyxXQUFVLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUFHO0FBQUEsV0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVDZ0IsZUFBZUUsZUFDWix1QkFBQyxlQUFZLFFBQVFGLGFBQWEsU0FBUyxNQUFNO0FBQUVDLHFCQUFlLEtBQUs7QUFBR0ksdUJBQWlCLElBQUk7QUFBQSxJQUFHLEdBQUcsVUFBVW1GLHVCQUF1QixRQUFRdEYsZUFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSjtBQUFBLElBRzdKTSxrQkFDRyx1QkFBQyxTQUFJLFdBQVUsdUVBQ1gsaUNBQUMsU0FBSSxXQUFVLDZFQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQywyQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFFBQzdFLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFQyw0QkFBa0IsS0FBSztBQUFHRSxrQ0FBd0IsSUFBSTtBQUFHSSxpQ0FBdUIsSUFBSTtBQUFBLFFBQUcsR0FBRyxXQUFVLHFDQUFvQyxpQkFBL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnTDtBQUFBLFdBRnBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNWQyxtQ0FDRyx1QkFBQyxTQUFJLFdBQVUseUNBQXdDLGlDQUFDLGFBQVUsV0FBVSwwQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRCxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFILElBQ3JISixvQkFBb0JsRCxXQUFXLElBQy9CLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsOERBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0YsSUFFeEYsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxtRUFBa0UseUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlGO0FBQUEsWUFDekYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSx1QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUN2Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0Usb0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFDcEYsdUJBQUMsUUFBRyxXQUFVLG9CQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsZUFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWmtELDhCQUFvQjlDO0FBQUFBLFlBQUksQ0FBQ3NLLE9BQ3RCLHVCQUFDLFFBQ0c7QUFBQSxxQ0FBQyxRQUFHLFdBQVUscUJBQXFCQSxhQUFHbEUsT0FBTzJELGdCQUFnQixPQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLFFBQUcsV0FBVSxxQkFBcUJPLGFBQUdsRSxPQUFPNEQsZ0JBQWdCLE9BQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ00sYUFBR2xFLFFBQVExSSxZQUFZOEMsT0FBTzhKLEdBQUdsRSxNQUFNQyxLQUFLLEdBQUcsVUFBVSxJQUFJLE9BQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStHO0FBQUEsY0FDL0csdUJBQUMsUUFBRyxXQUFVLHFCQUFxQmlFLGFBQUdsRSxPQUFPNkQsb0JBQW9CLE9BQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckUsdUJBQUMsUUFBRyxXQUFVLGFBQ1YsaUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNaEUsa0JBQWtCcUUsRUFBRSxHQUFHLFdBQVUsNkRBQTRELDJCQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2SSxLQURqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEtBLEdBQUduSyxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxVQUNILEtBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUNDNkMsdUJBQ0csdUJBQUMsY0FBVyxNQUFNQSxxQkFBcUIsY0FBYyxDQUFDdUgsTUFBTS9FLG9CQUFvQitFLENBQUMsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFdBMUIzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBLEtBbENSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxTQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBLEtBM0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0Q0E7QUFBQSxPQTdWUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1ZBO0FBRVI7QUFBRTdKLEdBOTFCV0QsZ0NBQThCO0FBQUEsVUFDeEJqRSxXQUNFRCxhQUdrQ1EsYUFDYkEsV0FBVztBQUFBO0FBQUF5TixLQU54Qy9KO0FBQThCLElBQUErSjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlQ2FsbGJhY2siLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInRvYXN0IiwiRmFTYXZlIiwiRmFTcGlubmVyIiwiRmFQbHVzIiwiRmFUcmFzaCIsIkZhTW9uZXlDaGVja0FsdCIsInVzZUNydWRJdGVtIiwiZ2V0QnlJZCIsImdldEFsbCIsInNlYXJjaEJ5RmllbGQiLCJub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnIiwiY29tcHJhc01vZHVsZUNvbmZpZyIsInByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIiwiUmVsYXRpb25hbElucHV0IiwiRGVjaW1hbElucHV0IiwiU2VhcmNoTW9kYWwiLCJMb2FkaW5nU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiZm9ybWF0VGF4UmF0ZUNlbGwiLCJQYWdpbmF0aW9uIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJkZWZhdWx0SXRlbSIsImxpbmVfbnVtYmVyIiwiZGVzY3JpcHRpb24iLCJjb25jZXB0X2NvZGUiLCJxdWFudGl0eSIsInVuaXRfcHJpY2UiLCJkaXNjb3VudF9wZXJjZW50YWdlIiwidGF4ZXMiLCJkZWZhdWx0SW5pdGlhbCIsInR5cGUiLCJzZXJpZXMiLCJwdXJjaGFzZV9pZCIsInZlbmRvcl9pZCIsInZlbmRvcl9uYW1lIiwidmVuZG9yX2NvZGUiLCJjdXJyZW5jeV9pZCIsImlzc3VlX2RhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvdGFsX2Ftb3VudCIsImV4Y2hhbmdlX3JhdGUiLCJzdGF0dXMiLCJub3RlcyIsImhhc19pdGVtX2xldmVsX3RheGVzIiwiaXRlbXMiLCJ3aXRob3V0dGF4X2Ftb3VudCIsImNhbGN1bGF0ZU5vdGVMZXZlbFRheGVzIiwic3VidG90YWwiLCJ2ZW5kb3JUYXhlcyIsImxlbmd0aCIsInRheEJhc2UiLCJNYXRoIiwibWF4IiwibWFwIiwidGF4IiwidGF4X2lkIiwiaWQiLCJ0YXhfbmFtZSIsIm5hbWUiLCJyYXRlIiwiYW1vdW50IiwiTnVtYmVyIiwiTm90YXNGaW5hbmNpZXJhc0NvbXByYUZvcm1QYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsIm1vZGUiLCJpdGVtIiwibG9hZGVkRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nRGF0YSIsInNhdmVJdGVtIiwic2F2aW5nIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldEl0ZW1zIiwidGVtcElkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInNldFZlbmRvclRheGVzIiwiYXBwbGllZFRheGVzIiwic2V0QXBwbGllZFRheGVzIiwicGVyY2VwdGlvblJvd3MiLCJzZXRQZXJjZXB0aW9uUm93cyIsInBlcmNlcHRpb25UYXhlcyIsInNldFBlcmNlcHRpb25UYXhlcyIsImlzTG9hZGluZyIsInNldExvYWRpbmciLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwibW9kYWxDb25maWciLCJzZXRNb2RhbENvbmZpZyIsImVkaXRpbmdUYXJnZXQiLCJzZXRFZGl0aW5nVGFyZ2V0IiwicHVyY2hhc2VDb2RlSW5wdXQiLCJzZXRQdXJjaGFzZUNvZGVJbnB1dCIsImNoZWNrTW9kYWxPcGVuIiwic2V0Q2hlY2tNb2RhbE9wZW4iLCJjaGVja01vZGFsSXRlbVRlbXBJZCIsInNldENoZWNrTW9kYWxJdGVtVGVtcElkIiwiZGVsaXZlcmVkQ2hlY2tzTGlzdCIsInNldERlbGl2ZXJlZENoZWNrc0xpc3QiLCJkZWxpdmVyZWRDaGVja3NNZXRhIiwic2V0RGVsaXZlcmVkQ2hlY2tzTWV0YSIsImxvYWRpbmdEZWxpdmVyZWRDaGVja3MiLCJzZXRMb2FkaW5nRGVsaXZlcmVkQ2hlY2tzIiwidmVuZG9yTmFtZSIsInZlbmRvciIsInZlbmRvckNvZGUiLCJsb2FkZWRJdGVtcyIsIml0IiwicHVyY2hhc2UiLCJkb2N1bWVudF9udW1iZXIiLCJTdHJpbmciLCJlbmRwb2ludCIsInRoZW4iLCJ2IiwicmVsYXRlZFRheGVzIiwiY2F0Y2giLCJBcnJheSIsImlzQXJyYXkiLCJ0eXBlMSIsImZpbHRlciIsInQiLCJ0YXhfdHlwZSIsInR5cGUyIiwicmVkdWNlIiwicyIsImkiLCJjYWxjdWxhdGVkIiwicmVzIiwiZGF0YSIsImhhbmRsZVVwZGF0ZUFwcGxpZWRUYXhBbW91bnQiLCJwcmV2IiwiY2FsY3VsYXRlZFRvdGFscyIsInRvdGFsVGF4ZXMiLCJwZXJjZXBjaW9uZXNUb3RhbCIsInIiLCJ0b3RhbCIsImFnZ3JlZ2F0ZWRUYXhlcyIsImFwcGxpZWQiLCJ0YXhfdHlwZV9sYWJlbCIsImxvYWREZWxpdmVyZWRDaGVja3MiLCJwYWdlVXJsIiwicmVxIiwibWV0YSIsImVycm9yIiwiZmluYWxseSIsImhhbmRsZU9wZW5DaGVja01vZGFsIiwiaXRlbVRlbXBJZCIsImluZm8iLCJoYW5kbGVTZWxlY3RDaGVjayIsImRlbGl2ZXJlZENoZWNrIiwiY2hlY2tWYWx1ZSIsImNoZWNrIiwidmFsdWUiLCJoYW5kbGVDbGVhckl0ZW1DaGVjayIsImNsZWFyRm9ybSIsImhhbmRsZVZlbmRvclNlbGVjdGVkIiwiZnVsbCIsInVuZGVmaW5lZCIsInNlcmllIiwic3VjY2VzcyIsImVyciIsImNvbnNvbGUiLCJoYW5kbGVWZW5kb3JDb2RlU3VibWl0IiwiY29kZSIsInRyaW0iLCJmb3VuZCIsImZpZWxkTmFtZSIsImUiLCJoYW5kbGVQdXJjaGFzZVNlbGVjdGVkIiwid2FybiIsImludGVybmFsX3ZvdWNoZXIiLCJwdXJjaGFzZV9kYXRlIiwiaGFuZGxlUHVyY2hhc2VDb2RlU3VibWl0IiwiaGFuZGxlU2VsZWN0RnJvbU1vZGFsIiwic2VsZWN0ZWQiLCJoYW5kbGVBZGRJdGVtIiwiaGFuZGxlUmVtb3ZlSXRlbSIsImhhbmRsZVVwZGF0ZUl0ZW0iLCJmaWVsZCIsImhhbmRsZUFubnVsUHVyY2hhc2UiLCJiYXNlSXRlbXNUb3RhbCIsInN1bSIsInF0eSIsInVuaXQiLCJwcm9kdWN0cyIsInAiLCJwcmljZV9jb3N0IiwiYW5udWxJdGVtIiwicmF3VGF4ZXMiLCJhcHBsaWVkX3RheGVzIiwiYXBwbGllZFRheGVzRm9yUGF5bG9hZCIsImhhbmRsZVNhdmUiLCJzb21lIiwidm91Y2hlcl9udW1iZXIiLCJjbGVhbkl0ZW1zIiwiaWR4IiwicmVzdCIsInBheW1lbnRfb3JkZXJfaXRlbV9pZCIsInRheGVzVHlwZTEiLCJ0YXhlc1R5cGUyIiwicGF5bG9hZCIsImNvbmNlcHQiLCJzYXZlZCIsImJhc2VSb3V0ZSIsImlucHV0U3R5bGUiLCJwdXJjaGFzZU1vZGFsQ29uZmlnIiwiaW5pdGlhbEZpbHRlcnMiLCJ0YXJnZXQiLCJjIiwicm93IiwiY2hlY2tfbnVtYmVyIiwiY2hlY2tfaG9sZGVyIiwicmVmZXJlbmNlX251bWJlciIsIm51bSIsInZhbCIsImZpbmQiLCJhbHJlYWR5VXNlZCIsImRjIiwidSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzRmluYW5jaWVyYXNDb21wcmFGb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFTcGlubmVyLCBGYVBsdXMsIEZhVHJhc2gsIEZhTW9uZXlDaGVja0FsdCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgZ2V0QnlJZCwgZ2V0QWxsLCBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnLCB0eXBlIFB1cmNoYXNlRmluYW5jaWFsTm90ZSwgdHlwZSBQdXJjaGFzZUZpbmFuY2lhbE5vdGVJdGVtIH0gZnJvbSAnLi4vbm90YXNfZmluYW5jaWVyYXNfY29tcHJhLmNvbmZpZyc7XG5pbXBvcnQgeyBjb21wcmFzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vY29tcHJhcy9jb21wcmFzLmNvbmZpZyc7XG5pbXBvcnQgdHlwZSB7IFB1cmNoYXNlIH0gZnJvbSAnLi4vLi4vY29tcHJhcy9jb21wcmFzLmNvbmZpZyc7XG5pbXBvcnQgeyBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBQcm92ZWVkb3IgfSBmcm9tICcuLi8uLi9wcm92ZWVkb3Jlcy9wcm92ZWVkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgZm9ybWF0VGF4UmF0ZUNlbGwgfSBmcm9tICcuLi8uLi8uLi91dGlscy90YXhEaXNwbGF5JztcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB0eXBlIHsgQXBwbGllZFRheCwgUmVsYXRlZFRheCB9IGZyb20gJy4uLy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQgdHlwZSB7IFRheCB9IGZyb20gJy4uLy4uL2ltcHVlc3Rvcy9pbXB1ZXN0b3MuY29uZmlnJztcbmltcG9ydCB0eXBlIHsgUGFnaW5hdGVkUmVzcG9uc2UgfSBmcm9tICcuLi8uLi8uLi9pbnRlcmZhY2VzL0FwaSc7XG5pbXBvcnQgeyBQYWdpbmF0aW9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUGFnaW5hdGlvbic7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuY29uc3QgZGVmYXVsdEl0ZW06IFB1cmNoYXNlRmluYW5jaWFsTm90ZUl0ZW0gPSB7XG4gICAgbGluZV9udW1iZXI6IDEsXG4gICAgZGVzY3JpcHRpb246ICcnLFxuICAgIGNvbmNlcHRfY29kZTogJ05PVEEtRklOQU5DSUVSQScsXG4gICAgcXVhbnRpdHk6IDEsXG4gICAgdW5pdF9wcmljZTogMCxcbiAgICBkaXNjb3VudF9wZXJjZW50YWdlOiAwLFxuICAgIHRheGVzOiBbXSxcbn07XG5cbmNvbnN0IGRlZmF1bHRJbml0aWFsOiBQYXJ0aWFsPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4gPSB7XG4gICAgdHlwZTogJ0RFQklUJyxcbiAgICBzZXJpZXM6ICdCJyxcbiAgICBwdXJjaGFzZV9pZDogMCxcbiAgICB2ZW5kb3JfaWQ6IDAsXG4gICAgdmVuZG9yX25hbWU6ICcnLFxuICAgIHZlbmRvcl9jb2RlOiAnJyxcbiAgICBjdXJyZW5jeV9pZDogMSxcbiAgICBpc3N1ZV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICB0b3RhbF9hbW91bnQ6IDAsXG4gICAgZXhjaGFuZ2VfcmF0ZTogMSxcbiAgICBkaXNjb3VudF9wZXJjZW50YWdlOiAwLFxuICAgIHN0YXR1czogJ0RSQUZUJyxcbiAgICBub3RlczogbnVsbCxcbiAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsXG4gICAgaXRlbXM6IFtdLFxuICAgIHRheGVzOiBbXSxcbiAgICB3aXRob3V0dGF4X2Ftb3VudDogMCxcbn07XG5cbi8qKiDDjXRlbSBkZSBjaGVxdWUgZW50cmVnYWRvIChkZWxpdmVyZWQtY2hlY2tzIEFQSSkgKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGVsaXZlcmVkQ2hlY2tJdGVtIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIGNoZWNrOiB7XG4gICAgICAgIGlkOiBudW1iZXI7XG4gICAgICAgIGNoZWNrX251bWJlcjogc3RyaW5nO1xuICAgICAgICBjaGVja19kYXRlOiBzdHJpbmc7XG4gICAgICAgIGNoZWNrX2R1ZV9kYXRlOiBzdHJpbmc7XG4gICAgICAgIGNoZWNrX2hvbGRlcjogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgcmVmZXJlbmNlX251bWJlcjogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgdmFsdWU6IG51bWJlcjtcbiAgICAgICAgYmFua19uYW1lOiBzdHJpbmcgfCBudWxsO1xuICAgIH0gfCBudWxsO1xuICAgIHZlbmRvcjogeyBpZDogbnVtYmVyOyBuYW1lOiBzdHJpbmc7IHZlbmRvcl9jb2RlPzogc3RyaW5nIH0gfCBudWxsO1xuICAgIHBheW1lbnRfb3JkZXI6IHsgaWQ6IG51bWJlcjsgcGF5bWVudF9vcmRlcl9udW1iZXI6IHN0cmluZzsgcGF5bWVudF9kYXRlOiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbnR5cGUgRm9ybUl0ZW0gPSBQdXJjaGFzZUZpbmFuY2lhbE5vdGVJdGVtICYgeyB0ZW1wSWQ6IHN0cmluZzsgZGVsaXZlcmVkQ2hlY2s/OiBEZWxpdmVyZWRDaGVja0l0ZW0gfCBudWxsIH07XG5cbmZ1bmN0aW9uIGNhbGN1bGF0ZU5vdGVMZXZlbFRheGVzKHN1YnRvdGFsOiBudW1iZXIsIHdpdGhvdXR0YXhfYW1vdW50OiBudW1iZXIsIHZlbmRvclRheGVzOiBSZWxhdGVkVGF4W10pOiBBcHBsaWVkVGF4W10ge1xuICAgIGlmICghdmVuZG9yVGF4ZXMgfHwgdmVuZG9yVGF4ZXMubGVuZ3RoID09PSAwKSByZXR1cm4gW107XG4gICAgY29uc3QgdGF4QmFzZSA9IE1hdGgubWF4KDAsIHN1YnRvdGFsIC0gd2l0aG91dHRheF9hbW91bnQpO1xuICAgIHJldHVybiB2ZW5kb3JUYXhlcy5tYXAodGF4ID0+ICh7XG4gICAgICAgIHRheF9pZDogdGF4LmlkLFxuICAgICAgICB0YXhfbmFtZTogdGF4Lm5hbWUsXG4gICAgICAgIHJhdGU6IHRheC5yYXRlLFxuICAgICAgICBhbW91bnQ6IHRheEJhc2UgKiAoTnVtYmVyKHRheC5yYXRlKSAvIDEwMCksXG4gICAgfSkpO1xufVxuXG5leHBvcnQgY29uc3QgTm90YXNGaW5hbmNpZXJhc0NvbXByYUZvcm1QYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCB7IGl0ZW06IGxvYWRlZERhdGEsIGxvYWRpbmc6IGxvYWRpbmdEYXRhIH0gPSB1c2VDcnVkSXRlbTxQdXJjaGFzZUZpbmFuY2lhbE5vdGU+KG5vdGFzRmluYW5jaWVyYXNDb21wcmFNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtLCBsb2FkaW5nOiBzYXZpbmcgfSA9IHVzZUNydWRJdGVtPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4obm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZTxQYXJ0aWFsPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4+KGRlZmF1bHRJbml0aWFsKTtcbiAgICBjb25zdCBbaXRlbXMsIHNldEl0ZW1zXSA9IHVzZVN0YXRlPEZvcm1JdGVtW10+KCgpID0+IFt7IC4uLmRlZmF1bHRJdGVtLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfV0pO1xuICAgIGNvbnN0IFt2ZW5kb3JUYXhlcywgc2V0VmVuZG9yVGF4ZXNdID0gdXNlU3RhdGU8UmVsYXRlZFRheFtdPihbXSk7XG4gICAgY29uc3QgW2FwcGxpZWRUYXhlcywgc2V0QXBwbGllZFRheGVzXSA9IHVzZVN0YXRlPEFwcGxpZWRUYXhbXT4oW10pO1xuICAgIGNvbnN0IFtwZXJjZXB0aW9uUm93cywgc2V0UGVyY2VwdGlvblJvd3NdID0gdXNlU3RhdGU8eyB0ZW1wSWQ6IHN0cmluZzsgdGF4X2lkOiBudW1iZXIgfCBudWxsOyB0YXhfbmFtZTogc3RyaW5nIHwgbnVsbDsgYW1vdW50OiBudW1iZXIgfVtdPihbXSk7XG4gICAgY29uc3QgW3BlcmNlcHRpb25UYXhlcywgc2V0UGVyY2VwdGlvblRheGVzXSA9IHVzZVN0YXRlPFRheFtdPihbXSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21vZGFsQ29uZmlnLCBzZXRNb2RhbENvbmZpZ10gPSB1c2VTdGF0ZTxNb2R1bGVDb25maWc8YW55PiB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPCd2ZW5kb3InIHwgJ3B1cmNoYXNlJyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtwdXJjaGFzZUNvZGVJbnB1dCwgc2V0UHVyY2hhc2VDb2RlSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjaGVja01vZGFsT3Blbiwgc2V0Q2hlY2tNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjaGVja01vZGFsSXRlbVRlbXBJZCwgc2V0Q2hlY2tNb2RhbEl0ZW1UZW1wSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2RlbGl2ZXJlZENoZWNrc0xpc3QsIHNldERlbGl2ZXJlZENoZWNrc0xpc3RdID0gdXNlU3RhdGU8RGVsaXZlcmVkQ2hlY2tJdGVtW10+KFtdKTtcbiAgICBjb25zdCBbZGVsaXZlcmVkQ2hlY2tzTWV0YSwgc2V0RGVsaXZlcmVkQ2hlY2tzTWV0YV0gPSB1c2VTdGF0ZTxQYWdpbmF0ZWRSZXNwb25zZTxEZWxpdmVyZWRDaGVja0l0ZW0+WydtZXRhJ10gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZ0RlbGl2ZXJlZENoZWNrcywgc2V0TG9hZGluZ0RlbGl2ZXJlZENoZWNrc10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobW9kZSA9PT0gJ2VkaXQnICYmIGxvYWRlZERhdGEpIHtcbiAgICAgICAgICAgIGNvbnN0IHZlbmRvck5hbWUgPSBsb2FkZWREYXRhLnZlbmRvcl9uYW1lID8/IChsb2FkZWREYXRhLnZlbmRvciBhcyBhbnkpPy5uYW1lID8/ICcnO1xuICAgICAgICAgICAgY29uc3QgdmVuZG9yQ29kZSA9IGxvYWRlZERhdGEudmVuZG9yX2NvZGUgPz8gKGxvYWRlZERhdGEudmVuZG9yIGFzIGFueSk/LnZlbmRvcl9jb2RlID8/ICcnO1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRJbml0aWFsLFxuICAgICAgICAgICAgICAgIC4uLmxvYWRlZERhdGEsXG4gICAgICAgICAgICAgICAgdmVuZG9yX25hbWU6IHZlbmRvck5hbWUsXG4gICAgICAgICAgICAgICAgdmVuZG9yX2NvZGU6IHZlbmRvckNvZGUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IGxvYWRlZEl0ZW1zID0gKGxvYWRlZERhdGEuaXRlbXMgfHwgW10pLmxlbmd0aFxuICAgICAgICAgICAgICAgID8gKGxvYWRlZERhdGEuaXRlbXMgfHwgW10pLm1hcChpdCA9PiAoeyAuLi5pdCwgY29uY2VwdF9jb2RlOiBpdC5jb25jZXB0X2NvZGUgfHwgJ05PVEEtRklOQU5DSUVSQScsIHF1YW50aXR5OiBpdC5xdWFudGl0eSA/PyAxLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfSBhcyBGb3JtSXRlbSkpXG4gICAgICAgICAgICAgICAgOiBbeyAuLi5kZWZhdWx0SXRlbSwgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpIH1dO1xuICAgICAgICAgICAgc2V0SXRlbXMobG9hZGVkSXRlbXMpO1xuICAgICAgICAgICAgc2V0UHVyY2hhc2VDb2RlSW5wdXQobG9hZGVkRGF0YS5wdXJjaGFzZT8uZG9jdW1lbnRfbnVtYmVyID8/IFN0cmluZyhsb2FkZWREYXRhLnB1cmNoYXNlX2lkID8/ICcnKSk7XG4gICAgICAgICAgICBpZiAobG9hZGVkRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgICAgICBnZXRCeUlkPFByb3ZlZWRvcj4ocHJvdmVlZG9yZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGxvYWRlZERhdGEudmVuZG9yX2lkKVxuICAgICAgICAgICAgICAgICAgICAudGhlbih2ID0+IHNldFZlbmRvclRheGVzKHYucmVsYXRlZFRheGVzIHx8IFtdKSlcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNldFZlbmRvclRheGVzKFtdKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9hZGVkRGF0YS50YXhlcyAmJiBBcnJheS5pc0FycmF5KGxvYWRlZERhdGEudGF4ZXMpICYmIGxvYWRlZERhdGEudGF4ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUxID0gKGxvYWRlZERhdGEudGF4ZXMgYXMgKEFwcGxpZWRUYXggJiB7IHRheF90eXBlPzogbnVtYmVyIH0pW10pLmZpbHRlcih0ID0+IHQudGF4X3R5cGUgIT09IDIpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUyID0gKGxvYWRlZERhdGEudGF4ZXMgYXMgKEFwcGxpZWRUYXggJiB7IHRheF90eXBlPzogbnVtYmVyIH0pW10pLmZpbHRlcih0ID0+IHQudGF4X3R5cGUgPT09IDIpO1xuXG4gICAgICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKHR5cGUxLm1hcCgodCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB0LnRheF9pZCxcbiAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHQudGF4X25hbWUsXG4gICAgICAgICAgICAgICAgICAgIHJhdGU6IHQucmF0ZSxcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpIHx8IDAsXG4gICAgICAgICAgICAgICAgfSkpKTtcblxuICAgICAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHR5cGUyLm1hcCgodCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICB0YXhfaWQ6IHQudGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSA/PyB0LnRheD8ubmFtZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCkgfHwgMCxcbiAgICAgICAgICAgICAgICB9KSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW21vZGUsIGxvYWRlZERhdGFdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpZCkgcmV0dXJuO1xuICAgICAgICBpZiAodmVuZG9yVGF4ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2ZW5kb3JUYXhlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXModmVuZG9yVGF4ZXMubWFwKHQgPT4gKHtcbiAgICAgICAgICAgICAgICB0YXhfaWQ6IHQuaWQsXG4gICAgICAgICAgICAgICAgdGF4X25hbWU6IHQubmFtZSxcbiAgICAgICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICAgICAgYW1vdW50OiAwLFxuICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgfVxuICAgIH0sIFtpZCwgdmVuZG9yVGF4ZXNdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpZCB8fCB2ZW5kb3JUYXhlcy5sZW5ndGggIT09IDEpIHJldHVybjtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgIGNvbnN0IHdpdGhvdXR0YXhfYW1vdW50ID0gZm9ybURhdGEud2l0aG91dHRheF9hbW91bnQgPz8gMDtcbiAgICAgICAgY29uc3QgY2FsY3VsYXRlZCA9IGNhbGN1bGF0ZU5vdGVMZXZlbFRheGVzKHN1YnRvdGFsLCB3aXRob3V0dGF4X2Ftb3VudCwgdmVuZG9yVGF4ZXMpO1xuICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoY2FsY3VsYXRlZCk7XG4gICAgfSwgW2lkLCBpdGVtcywgZm9ybURhdGEud2l0aG91dHRheF9hbW91bnQsIHZlbmRvclRheGVzXSk7XG5cbiAgICAvLyBDYXJnYXIgaW1wdWVzdG9zIGRlIHRpcG8gcGVyY2VwY2nDs24gKHRheF90eXBlIDIpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZ2V0QWxsPFRheD4oJ3RheGVzJywgeyB0eXBlOiAnMicgfSlcbiAgICAgICAgICAgIC50aGVuKHJlcyA9PiBzZXRQZXJjZXB0aW9uVGF4ZXMocmVzLmRhdGEgfHwgW10pKVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNldFBlcmNlcHRpb25UYXhlcyhbXSkpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZUFwcGxpZWRUYXhBbW91bnQgPSAodGF4X2lkOiBudW1iZXIsIGFtb3VudDogbnVtYmVyKSA9PiB7XG4gICAgICAgIHNldEFwcGxpZWRUYXhlcyhwcmV2ID0+IHByZXYubWFwKHQgPT4gdC50YXhfaWQgPT09IHRheF9pZCA/IHsgLi4udCwgYW1vdW50IH0gOiB0KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgIGNvbnN0IHdpdGhvdXR0YXhfYW1vdW50ID0gZm9ybURhdGEud2l0aG91dHRheF9hbW91bnQgPz8gMDtcbiAgICAgICAgY29uc3QgdG90YWxUYXhlcyA9IHZlbmRvclRheGVzLmxlbmd0aCA9PT0gMVxuICAgICAgICAgICAgPyBjYWxjdWxhdGVOb3RlTGV2ZWxUYXhlcyhzdWJ0b3RhbCwgd2l0aG91dHRheF9hbW91bnQsIHZlbmRvclRheGVzKS5yZWR1Y2UoKHMsIHQpID0+IHMgKyBOdW1iZXIodC5hbW91bnQpLCAwKVxuICAgICAgICAgICAgOiBhcHBsaWVkVGF4ZXMucmVkdWNlKChzLCB0KSA9PiBzICsgKE51bWJlcih0LmFtb3VudCkgfHwgMCksIDApO1xuICAgICAgICBjb25zdCBwZXJjZXBjaW9uZXNUb3RhbCA9IHBlcmNlcHRpb25Sb3dzLnJlZHVjZSgocywgcikgPT4gcyArIChOdW1iZXIoci5hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3QgdG90YWwgPSBzdWJ0b3RhbCArIHRvdGFsVGF4ZXMgKyBwZXJjZXBjaW9uZXNUb3RhbDtcbiAgICAgICAgcmV0dXJuIHsgc3VidG90YWwsIHdpdGhvdXR0YXhfYW1vdW50LCB0b3RhbFRheGVzLCBwZXJjZXBjaW9uZXNUb3RhbCwgdG90YWwgfTtcbiAgICB9LCBbaXRlbXMsIGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50LCB2ZW5kb3JUYXhlcywgYXBwbGllZFRheGVzLCBwZXJjZXB0aW9uUm93c10pO1xuXG4gICAgY29uc3QgYWdncmVnYXRlZFRheGVzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN1YnRvdGFsID0gaXRlbXMucmVkdWNlKChzLCBpKSA9PiBzICsgTnVtYmVyKGkucXVhbnRpdHkpICogTnVtYmVyKGkudW5pdF9wcmljZSksIDApO1xuICAgICAgICBjb25zdCB3aXRob3V0dGF4X2Ftb3VudCA9IGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50ID8/IDA7XG4gICAgICAgIGlmICh2ZW5kb3JUYXhlcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgIGNvbnN0IGFwcGxpZWQgPSBjYWxjdWxhdGVOb3RlTGV2ZWxUYXhlcyhzdWJ0b3RhbCwgd2l0aG91dHRheF9hbW91bnQsIHZlbmRvclRheGVzKTtcbiAgICAgICAgICAgIHJldHVybiBhcHBsaWVkLm1hcCh0ID0+ICh7XG4gICAgICAgICAgICAgICAgdGF4X2lkOiB0LnRheF9pZCxcbiAgICAgICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSxcbiAgICAgICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhcHBsaWVkVGF4ZXMubWFwKHQgPT4gKHtcbiAgICAgICAgICAgIHRheF9pZDogdC50YXhfaWQsXG4gICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSxcbiAgICAgICAgICAgIHRheF90eXBlOiB0LnRheF90eXBlLFxuICAgICAgICAgICAgdGF4X3R5cGVfbGFiZWw6IHQudGF4X3R5cGVfbGFiZWwsXG4gICAgICAgICAgICB0YXg6IHQudGF4LFxuICAgICAgICAgICAgcmF0ZTogdC5yYXRlLFxuICAgICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpLFxuICAgICAgICB9KSk7XG4gICAgfSwgW2l0ZW1zLCBmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCwgdmVuZG9yVGF4ZXMsIGFwcGxpZWRUYXhlc10pO1xuXG4gICAgY29uc3QgbG9hZERlbGl2ZXJlZENoZWNrcyA9IHVzZUNhbGxiYWNrKChwYWdlVXJsPzogc3RyaW5nKSA9PiB7XG4gICAgICAgIGlmICghcGFnZVVybCAmJiAhZm9ybURhdGEudmVuZG9yX2lkKSByZXR1cm47XG4gICAgICAgIHNldExvYWRpbmdEZWxpdmVyZWRDaGVja3ModHJ1ZSk7XG4gICAgICAgIGNvbnN0IHJlcSA9IHBhZ2VVcmxcbiAgICAgICAgICAgID8gZ2V0QWxsPERlbGl2ZXJlZENoZWNrSXRlbT4ocGFnZVVybClcbiAgICAgICAgICAgIDogZ2V0QWxsPERlbGl2ZXJlZENoZWNrSXRlbT4oJ3BheW1lbnQtb3JkZXJzL2RlbGl2ZXJlZC1jaGVja3MnLCB7IHZlbmRvcl9pZDogZm9ybURhdGEudmVuZG9yX2lkISB9KTtcbiAgICAgICAgcmVxXG4gICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgIHNldERlbGl2ZXJlZENoZWNrc0xpc3QocmVzLmRhdGEgfHwgW10pO1xuICAgICAgICAgICAgICAgIHNldERlbGl2ZXJlZENoZWNrc01ldGEocmVzLm1ldGEgPz8gbnVsbCk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIGNoZXF1ZXMgZW50cmVnYWRvcy4nKTtcbiAgICAgICAgICAgICAgICBzZXREZWxpdmVyZWRDaGVja3NMaXN0KFtdKTtcbiAgICAgICAgICAgICAgICBzZXREZWxpdmVyZWRDaGVja3NNZXRhKG51bGwpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmdEZWxpdmVyZWRDaGVja3MoZmFsc2UpKTtcbiAgICB9LCBbZm9ybURhdGEudmVuZG9yX2lkXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWNoZWNrTW9kYWxPcGVuIHx8ICFmb3JtRGF0YS52ZW5kb3JfaWQpIHJldHVybjtcbiAgICAgICAgbG9hZERlbGl2ZXJlZENoZWNrcygpO1xuICAgIH0sIFtjaGVja01vZGFsT3BlbiwgZm9ybURhdGEudmVuZG9yX2lkLCBsb2FkRGVsaXZlcmVkQ2hlY2tzXSk7XG5cbiAgICBjb25zdCBoYW5kbGVPcGVuQ2hlY2tNb2RhbCA9IChpdGVtVGVtcElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKCFmb3JtRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oJ1NlbGVjY2lvbmUgcHJpbWVybyB1biBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0Q2hlY2tNb2RhbEl0ZW1UZW1wSWQoaXRlbVRlbXBJZCk7XG4gICAgICAgIHNldENoZWNrTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RDaGVjayA9IChkZWxpdmVyZWRDaGVjazogRGVsaXZlcmVkQ2hlY2tJdGVtKSA9PiB7XG4gICAgICAgIGlmICghY2hlY2tNb2RhbEl0ZW1UZW1wSWQpIHJldHVybjtcbiAgICAgICAgY29uc3QgY2hlY2tWYWx1ZSA9IGRlbGl2ZXJlZENoZWNrLmNoZWNrPy52YWx1ZSAhPSBudWxsID8gTnVtYmVyKGRlbGl2ZXJlZENoZWNrLmNoZWNrLnZhbHVlKSA6IDA7XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXQgPT5cbiAgICAgICAgICAgIGl0LnRlbXBJZCA9PT0gY2hlY2tNb2RhbEl0ZW1UZW1wSWRcbiAgICAgICAgICAgICAgICA/IHsgLi4uaXQsIGRlbGl2ZXJlZENoZWNrLCBxdWFudGl0eTogMSwgdW5pdF9wcmljZTogY2hlY2tWYWx1ZSB9XG4gICAgICAgICAgICAgICAgOiBpdFxuICAgICAgICApKTtcbiAgICAgICAgc2V0Q2hlY2tNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICBzZXRDaGVja01vZGFsSXRlbVRlbXBJZChudWxsKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQ2xlYXJJdGVtQ2hlY2sgPSAoaXRlbVRlbXBJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXQgPT4gaXQudGVtcElkID09PSBpdGVtVGVtcElkID8geyAuLi5pdCwgZGVsaXZlcmVkQ2hlY2s6IG51bGwgfSA6IGl0KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGNsZWFyRm9ybSA9ICgpID0+IHtcbiAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5kZWZhdWx0SW5pdGlhbCB9KTtcbiAgICAgICAgc2V0SXRlbXMoW3sgLi4uZGVmYXVsdEl0ZW0sIHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSB9XSk7XG4gICAgICAgIHNldFZlbmRvclRheGVzKFtdKTtcbiAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgc2V0UGVyY2VwdGlvblJvd3MoW10pO1xuICAgICAgICBzZXRQdXJjaGFzZUNvZGVJbnB1dCgnJyk7XG4gICAgICAgIHNldENoZWNrTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgc2V0Q2hlY2tNb2RhbEl0ZW1UZW1wSWQobnVsbCk7XG4gICAgICAgIHNldERlbGl2ZXJlZENoZWNrc0xpc3QoW10pO1xuICAgICAgICBzZXREZWxpdmVyZWRDaGVja3NNZXRhKG51bGwpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVWZW5kb3JTZWxlY3RlZCA9IGFzeW5jICh2ZW5kb3I6IFByb3ZlZWRvcikgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZnVsbCA9IGF3YWl0IGdldEJ5SWQ8UHJvdmVlZG9yPihwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgdmVuZG9yLmlkKTtcbiAgICAgICAgICAgIGNvbnN0IHRheGVzID0gZnVsbC5yZWxhdGVkVGF4ZXMgfHwgW107XG4gICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyh0YXhlcyk7XG4gICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGZ1bGwuaWQsXG4gICAgICAgICAgICAgICAgdmVuZG9yX25hbWU6IGZ1bGwubmFtZSB8fCAnJyxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfY29kZTogZnVsbC52ZW5kb3JfY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBwdXJjaGFzZV9pZDogMCxcbiAgICAgICAgICAgICAgICBwdXJjaGFzZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHNlcmllczogZnVsbC5zZXJpZSA/PyBwcmV2Py5zZXJpZXMgPz8gJ0InLFxuICAgICAgICAgICAgICAgIGN1cnJlbmN5X2lkOiBwcmV2Py5jdXJyZW5jeV9pZCA/PyAxLFxuICAgICAgICAgICAgICAgIGV4Y2hhbmdlX3JhdGU6IHByZXY/LmV4Y2hhbmdlX3JhdGUgPz8gMSxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIHNldEl0ZW1zKFt7IC4uLmRlZmF1bHRJdGVtLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfV0pO1xuICAgICAgICAgICAgc2V0UHVyY2hhc2VDb2RlSW5wdXQoJycpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnUHJvdmVlZG9yIHNlbGVjY2lvbmFkby4gRWxpamEgbGEgY29tcHJhLicpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjYXJnYXIgZWwgcHJvdmVlZG9yLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlVmVuZG9yQ29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY29kZSA9IGZvcm1EYXRhLnZlbmRvcl9jb2RlPy50cmltKCk7XG4gICAgICAgIGlmICghY29kZSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbygnSW5ncmVzZSBlbCBjw7NkaWdvIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxQcm92ZWVkb3I+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBbeyBmaWVsZE5hbWU6ICd2ZW5kb3JfY29kZScsIHZhbHVlOiBjb2RlIH1dKTtcbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVZlbmRvclNlbGVjdGVkKGZvdW5kKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyBwcm92ZWVkb3IgY29uIGPDs2RpZ28gXCIke2NvZGV9XCIuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIHByb3ZlZWRvci4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVB1cmNoYXNlU2VsZWN0ZWQgPSBhc3luYyAocHVyY2hhc2U6IFB1cmNoYXNlKSA9PiB7XG4gICAgICAgIGlmICghZm9ybURhdGEudmVuZG9yX2lkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdTZWxlY2Npb25lIHByaW1lcm8gdW4gcHJvdmVlZG9yLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmdWxsID0gYXdhaXQgZ2V0QnlJZDxQdXJjaGFzZT4oY29tcHJhc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgcHVyY2hhc2UuaWQpO1xuICAgICAgICAgICAgaWYgKGZ1bGwudmVuZG9yX2lkICE9PSBmb3JtRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTGEgY29tcHJhIG5vIHBlcnRlbmVjZSBhbCBwcm92ZWVkb3Igc2VsZWNjaW9uYWRvLicpO1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHZlbmRvck5hbWUgPSBmdWxsLnZlbmRvcj8ubmFtZSB8fCBmdWxsLnZlbmRvcl9uYW1lIHx8ICcnO1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgcHVyY2hhc2VfaWQ6IGZ1bGwuaWQsXG4gICAgICAgICAgICAgICAgcHVyY2hhc2U6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6IGZ1bGwuaWQsXG4gICAgICAgICAgICAgICAgICAgIGludGVybmFsX3ZvdWNoZXI6IGZ1bGwuaW50ZXJuYWxfdm91Y2hlciB8fCBTdHJpbmcoZnVsbC5pZCksXG4gICAgICAgICAgICAgICAgICAgIHB1cmNoYXNlX2RhdGU6IGZ1bGwucHVyY2hhc2VfZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRfbnVtYmVyOiBmdWxsLmRvY3VtZW50X251bWJlcixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHZlbmRvcl9pZDogZnVsbC52ZW5kb3JfaWQsXG4gICAgICAgICAgICAgICAgdmVuZG9yX25hbWU6IHZlbmRvck5hbWUsXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBmdWxsLnNlcmllcyB8fCBwcmV2Py5zZXJpZXMgfHwgJ0InLFxuICAgICAgICAgICAgICAgIGN1cnJlbmN5X2lkOiBmdWxsLmN1cnJlbmN5X2lkID8/IHByZXY/LmN1cnJlbmN5X2lkID8/IDEsXG4gICAgICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogZnVsbC5leGNoYW5nZV9yYXRlID8/IDEsXG4gICAgICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IHRydWUsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzZXRQdXJjaGFzZUNvZGVJbnB1dChmdWxsLmRvY3VtZW50X251bWJlciB8fCBTdHJpbmcoZnVsbC5pZCkpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnQ29tcHJhIHNlbGVjY2lvbmFkYS4nKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIGxhIGNvbXByYS4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVB1cmNoYXNlQ29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFmb3JtRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ1NlbGVjY2lvbmUgcHJpbWVybyB1biBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY29kZSA9IHB1cmNoYXNlQ29kZUlucHV0LnRyaW0oKTtcbiAgICAgICAgaWYgKCFjb2RlKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKCdJbmdyZXNlIGVsIG7Dum1lcm8gZGUgbGEgY29tcHJhLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8UHVyY2hhc2U+KGNvbXByYXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogJ2RvY3VtZW50X251bWJlcicsIHZhbHVlOiBjb2RlIH1dKTtcbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVB1cmNoYXNlU2VsZWN0ZWQoZm91bmQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgZW5jb250csOzIHVuYSBjb21wcmEgY29uIGVzZSBuw7ptZXJvLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGJ1c2NhciBsYSBjb21wcmEuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RGcm9tTW9kYWwgPSAoc2VsZWN0ZWQ6IGFueSkgPT4ge1xuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ3ZlbmRvcicpIHtcbiAgICAgICAgICAgIGhhbmRsZVZlbmRvclNlbGVjdGVkKHNlbGVjdGVkIGFzIFByb3ZlZWRvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBoYW5kbGVQdXJjaGFzZVNlbGVjdGVkKHNlbGVjdGVkIGFzIFB1cmNoYXNlKTtcbiAgICAgICAgfVxuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KG51bGwpO1xuICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUFkZEl0ZW0gPSAoKSA9PiBzZXRJdGVtcyhwcmV2ID0+IFsuLi5wcmV2LCB7IC4uLmRlZmF1bHRJdGVtLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfV0pO1xuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUl0ZW0gPSAodGVtcElkOiBzdHJpbmcpID0+IHNldEl0ZW1zKHByZXYgPT4gKHByZXYubGVuZ3RoID4gMSA/IHByZXYuZmlsdGVyKGkgPT4gaS50ZW1wSWQgIT09IHRlbXBJZCkgOiBwcmV2KSk7XG4gICAgY29uc3QgaGFuZGxlVXBkYXRlSXRlbSA9ICh0ZW1wSWQ6IHN0cmluZywgZmllbGQ6IGtleW9mIFB1cmNoYXNlRmluYW5jaWFsTm90ZUl0ZW0sIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2Lm1hcChpID0+IChpLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5pLCBbZmllbGRdOiB2YWx1ZSB9IDogaSkpKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQW5udWxQdXJjaGFzZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKGZvcm1EYXRhLnR5cGUgIT09ICdDUkVESVQnKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKCdMYSBhbnVsYWNpw7NuIHNvbG8gYXBsaWNhIHBhcmEgbm90YXMgZGUgdGlwbyBjcsOpZGl0by4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWZvcm1EYXRhLnB1cmNoYXNlX2lkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdTZWxlY2Npb25lIHByaW1lcm8gdW5hIGNvbXByYSBwYXJhIGFudWxhci4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBwdXJjaGFzZSA9IGF3YWl0IGdldEJ5SWQ8UHVyY2hhc2U+KGNvbXByYXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGZvcm1EYXRhLnB1cmNoYXNlX2lkKTtcblxuICAgICAgICAgICAgLy8gQ2FsY3VsYXIgdG90YWwgYmFzZSBkZSDDrXRlbXMgZGUgbGEgY29tcHJhXG4gICAgICAgICAgICBsZXQgYmFzZUl0ZW1zVG90YWwgPSAwO1xuXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwdXJjaGFzZS5pdGVtcykgJiYgcHVyY2hhc2UuaXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGJhc2VJdGVtc1RvdGFsID0gcHVyY2hhc2UuaXRlbXMucmVkdWNlKChzdW06IG51bWJlciwgaXQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGl0LnZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIHN1bSArIE51bWJlcihpdC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHF0eSA9IE51bWJlcihpdC5xdWFudGl0eSkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdW5pdCA9IE51bWJlcihpdC51bml0X3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3VtICsgcXR5ICogdW5pdDtcbiAgICAgICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSgocHVyY2hhc2UgYXMgYW55KS5wcm9kdWN0cykgJiYgKHB1cmNoYXNlIGFzIGFueSkucHJvZHVjdHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByb2R1Y3RzID0gKHB1cmNoYXNlIGFzIGFueSkucHJvZHVjdHMgYXMgQXJyYXk8eyBxdWFudGl0eTogbnVtYmVyOyBwcmljZV9jb3N0OiBudW1iZXIgfT47XG4gICAgICAgICAgICAgICAgYmFzZUl0ZW1zVG90YWwgPSBwcm9kdWN0cy5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgKE51bWJlcihwLnF1YW50aXR5KSB8fCAwKSAqIChOdW1iZXIocC5wcmljZV9jb3N0KSB8fCAwKSwgMCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBwdXJjaGFzZS50b3RhbF9hbW91bnQgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgYmFzZUl0ZW1zVG90YWwgPSBOdW1iZXIocHVyY2hhc2UudG90YWxfYW1vdW50KSB8fCAwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoYmFzZUl0ZW1zVG90YWwgPD0gMCkge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBmdWUgcG9zaWJsZSBjYWxjdWxhciBlbCB0b3RhbCBkZSDDrXRlbXMgZGUgbGEgY29tcHJhIHBhcmEgYW51bGFyLicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgYW5udWxJdGVtOiBGb3JtSXRlbSA9IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0SXRlbSxcbiAgICAgICAgICAgICAgICB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdBTlVMQUNJT04gVE9UQUwnLFxuICAgICAgICAgICAgICAgIHF1YW50aXR5OiAxLFxuICAgICAgICAgICAgICAgIHVuaXRfcHJpY2U6IGJhc2VJdGVtc1RvdGFsLFxuICAgICAgICAgICAgICAgIGRpc2NvdW50X3BlcmNlbnRhZ2U6IDAsXG4gICAgICAgICAgICAgICAgdGF4ZXM6IFtdLFxuICAgICAgICAgICAgICAgIGRlbGl2ZXJlZENoZWNrOiBudWxsLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNldEl0ZW1zKFthbm51bEl0ZW1dKTtcblxuICAgICAgICAgICAgY29uc3QgcmF3VGF4ZXMgPSAoKHB1cmNoYXNlIGFzIGFueSkuYXBwbGllZF90YXhlcyA/PyBbXSkgYXMgKEFwcGxpZWRUYXggJiB7IHRheF90eXBlPzogbnVtYmVyIH0pW107XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShyYXdUYXhlcykgJiYgcmF3VGF4ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUxID0gcmF3VGF4ZXMuZmlsdGVyKHQgPT4gdC50YXhfdHlwZSAhPT0gMik7XG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZTIgPSByYXdUYXhlcy5maWx0ZXIodCA9PiB0LnRheF90eXBlID09PSAyKTtcblxuICAgICAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyh0eXBlMS5tYXAodCA9PiAoe1xuICAgICAgICAgICAgICAgICAgICB0YXhfaWQ6IHQudGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcmF0ZTogdC5yYXRlLFxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCkgfHwgMCxcbiAgICAgICAgICAgICAgICB9KSkpO1xuXG4gICAgICAgICAgICAgICAgc2V0UGVyY2VwdGlvblJvd3ModHlwZTIubWFwKHQgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICB0YXhfaWQ6IHQudGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSA/PyB0LnRheD8ubmFtZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCkgfHwgMCxcbiAgICAgICAgICAgICAgICB9KSkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKFtdKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgd2l0aG91dHRheF9hbW91bnQ6IChwdXJjaGFzZSBhcyBhbnkpLndpdGhvdXR0YXhfYW1vdW50ID8/IHByZXYud2l0aG91dHRheF9hbW91bnQgPz8gMCxcbiAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnRGF0b3MgZGUgYW51bGFjacOzbiBjYXJnYWRvcyBkZXNkZSBsYSBjb21wcmEgc2VsZWNjaW9uYWRhLicpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBjYXJnYXIgbGEgaW5mb3JtYWNpw7NuIGRlIGxhIGNvbXByYSBwYXJhIGFudWxhci4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGFwcGxpZWRUYXhlc0ZvclBheWxvYWQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKHZlbmRvclRheGVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgICAgICBjb25zdCB3aXRob3V0dGF4X2Ftb3VudCA9IGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50ID8/IDA7XG4gICAgICAgICAgICByZXR1cm4gY2FsY3VsYXRlTm90ZUxldmVsVGF4ZXMoc3VidG90YWwsIHdpdGhvdXR0YXhfYW1vdW50LCB2ZW5kb3JUYXhlcyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFwcGxpZWRUYXhlcztcbiAgICB9LCBbaXRlbXMsIGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50LCB2ZW5kb3JUYXhlcywgYXBwbGllZFRheGVzXSk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWZvcm1EYXRhLnZlbmRvcl9pZCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybignU2VsZWNjaW9uZSB1biBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5wdXJjaGFzZV9pZCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybignU2VsZWNjaW9uZSB1bmEgY29tcHJhLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDAgfHwgaXRlbXMuc29tZShpdCA9PiAhaXQuZGVzY3JpcHRpb24/LnRyaW0oKSkpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0NhZGEgw610ZW0gZGViZSB0ZW5lciBkZXNjcmlwY2nDs24uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5zZXJpZXMpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0xhIHNlcmllIGVzIG9ibGlnYXRvcmlhLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZm9ybURhdGEudm91Y2hlcl9udW1iZXI/LnRyaW0oKSkge1xuICAgICAgICAgICAgdG9hc3Qud2FybignRWwgbsO6bWVybyBkZSBjb21wcm9iYW50ZSBlcyBvYmxpZ2F0b3Jpby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNsZWFuSXRlbXMgPSBpdGVtcy5tYXAoKGl0LCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHsgdGVtcElkLCBkZWxpdmVyZWRDaGVjaywgLi4ucmVzdCB9ID0gaXQ7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnJlc3QsXG4gICAgICAgICAgICAgICAgbGluZV9udW1iZXI6IGlkeCArIDEsXG4gICAgICAgICAgICAgICAgLi4uKGRlbGl2ZXJlZENoZWNrPy5pZCAhPSBudWxsICYmIHsgcGF5bWVudF9vcmRlcl9pdGVtX2lkOiBkZWxpdmVyZWRDaGVjay5pZCB9KSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB0YXhlc1R5cGUxID0gYXBwbGllZFRheGVzRm9yUGF5bG9hZFxuICAgICAgICAgICAgLmZpbHRlcih0ID0+IE51bWJlcih0LmFtb3VudCkgPiAwKVxuICAgICAgICAgICAgLm1hcCh0ID0+ICh7IC4uLnQsIHRheF90eXBlOiAxIGFzIGNvbnN0IH0pKTtcblxuICAgICAgICBjb25zdCB0YXhlc1R5cGUyID0gcGVyY2VwdGlvblJvd3NcbiAgICAgICAgICAgIC5maWx0ZXIociA9PiByLnRheF9pZCAhPSBudWxsICYmIE51bWJlcihyLmFtb3VudCkgPiAwKVxuICAgICAgICAgICAgLm1hcChyID0+ICh7XG4gICAgICAgICAgICAgICAgdGF4X2lkOiByLnRheF9pZCEsXG4gICAgICAgICAgICAgICAgdGF4X25hbWU6IHIudGF4X25hbWUgPz8gJycsXG4gICAgICAgICAgICAgICAgcmF0ZTogMCxcbiAgICAgICAgICAgICAgICBhbW91bnQ6IHIuYW1vdW50LFxuICAgICAgICAgICAgICAgIHRheF90eXBlOiAyIGFzIGNvbnN0LFxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IFBhcnRpYWw8UHVyY2hhc2VGaW5hbmNpYWxOb3RlPiA9IHtcbiAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxuICAgICAgICAgICAgdHlwZTogZm9ybURhdGEudHlwZSB8fCAnREVCSVQnLFxuICAgICAgICAgICAgdm91Y2hlcl9udW1iZXI6IGZvcm1EYXRhLnZvdWNoZXJfbnVtYmVyLnRyaW0oKSxcbiAgICAgICAgICAgIHNlcmllczogZm9ybURhdGEuc2VyaWVzIHx8ICdCJyxcbiAgICAgICAgICAgIHB1cmNoYXNlX2lkOiBmb3JtRGF0YS5wdXJjaGFzZV9pZCxcbiAgICAgICAgICAgIHZlbmRvcl9pZDogZm9ybURhdGEudmVuZG9yX2lkLFxuICAgICAgICAgICAgdmVuZG9yX2NvZGU6IGZvcm1EYXRhLnZlbmRvcl9jb2RlID8/IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIHZlbmRvcl9uYW1lOiBmb3JtRGF0YS52ZW5kb3JfbmFtZSA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgICBjdXJyZW5jeV9pZDogZm9ybURhdGEuY3VycmVuY3lfaWQgPz8gMSxcbiAgICAgICAgICAgIGlzc3VlX2RhdGU6IGZvcm1EYXRhLmlzc3VlX2RhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgICAgICAgICB0b3RhbF9hbW91bnQ6IGNhbGN1bGF0ZWRUb3RhbHMudG90YWwsXG4gICAgICAgICAgICBleGNoYW5nZV9yYXRlOiBmb3JtRGF0YS5leGNoYW5nZV9yYXRlID8/IDEsXG4gICAgICAgICAgICBkaXNjb3VudF9wZXJjZW50YWdlOiBmb3JtRGF0YS5kaXNjb3VudF9wZXJjZW50YWdlID8/IDAsXG4gICAgICAgICAgICBzdGF0dXM6IGZvcm1EYXRhLnN0YXR1cyB8fCAnRFJBRlQnLFxuICAgICAgICAgICAgbm90ZXM6IGZvcm1EYXRhLm5vdGVzID8/IG51bGwsXG4gICAgICAgICAgICBjb25jZXB0OiBudWxsLFxuICAgICAgICAgICAgd2l0aG91dHRheF9hbW91bnQ6IGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50ID8/IDAsXG4gICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsXG4gICAgICAgICAgICBpdGVtczogY2xlYW5JdGVtcyxcbiAgICAgICAgICAgIHRheGVzOiBbLi4udGF4ZXNUeXBlMSwgLi4udGF4ZXNUeXBlMl0sXG4gICAgICAgIH07XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHNhdmVkID0gYXdhaXQgc2F2ZUl0ZW0ocGF5bG9hZCBhcyBQYXJ0aWFsPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4pO1xuICAgICAgICAgICAgaWYgKHNhdmVkKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnTm90YSBGaW5hbmNpZXJhIGd1YXJkYWRhLicpO1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG5vdGFzRmluYW5jaWVyYXNDb21wcmFNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBndWFyZGFyLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nRGF0YSkgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcblxuICAgIGNvbnN0IGlucHV0U3R5bGUgPSBcIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc20gZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCI7XG4gICAgY29uc3QgcHVyY2hhc2VNb2RhbENvbmZpZyA9IGZvcm1EYXRhLnZlbmRvcl9pZFxuICAgICAgICA/IHsgLi4uY29tcHJhc01vZHVsZUNvbmZpZywgaW5pdGlhbEZpbHRlcnM6IHsgdmVuZG9yX2lkOiBmb3JtRGF0YS52ZW5kb3JfaWQgfSB9XG4gICAgICAgIDogY29tcHJhc01vZHVsZUNvbmZpZztcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LTYgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgIHsoaXNMb2FkaW5nIHx8IHNhdmluZykgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTUwIGJnLXdoaXRlLzgwIHJvdW5kZWQtbGcgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmFja2Ryb3AtYmx1ci1bMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1pbmRpZ28tNjAwIGFuaW1hdGUtc3BpbiBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+UHJvY2VzYW5kby4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgIHttb2RlID09PSAnY3JlYXRlJyA/ICdOdWV2YSBOb3RhIEZpbmFuY2llcmEnIDogYEVkaXRhciBOb3RhICR7Zm9ybURhdGEudm91Y2hlcl9udW1iZXIgfHwgaWR9YH1cbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TsO6bWVybyBkZSBjb21wcm9iYW50ZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS52b3VjaGVyX251bWJlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgdm91Y2hlcl9udW1iZXI6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IDcwMDk5XCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlRpcG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHlwZSB8fCAnREVCSVQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB0eXBlOiBlLnRhcmdldC52YWx1ZSBhcyAnREVCSVQnIHwgJ0NSRURJVCcgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dFN0eWxlfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiREVCSVRcIj5Ew6liaXRvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1JFRElUXCI+Q3LDqWRpdG88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5TZXJpZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2VyaWVzIHx8ICdCJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgc2VyaWVzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBXCI+QTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJcIj5CPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1wiPkM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJYXCI+WDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UHJvdmVlZG9yICgqKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEudmVuZG9yX2NvZGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnZlbmRvcl9uYW1lIHx8IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhjKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHZlbmRvcl9jb2RlOiBjIHx8ICcnIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17aGFuZGxlVmVuZG9yQ29kZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IHsgc2V0TW9kYWxDb25maWcocHJvdmVlZG9yZXNNb2R1bGVDb25maWcgYXMgTW9kdWxlQ29uZmlnPGFueT4pOyBzZXRFZGl0aW5nVGFyZ2V0KCd2ZW5kb3InKTsgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9e2NsZWFyRm9ybX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk7CuiBkZSBGYWN0dXJhICgqKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17cHVyY2hhc2VDb2RlSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEucHVyY2hhc2VfaWQgPyAoZm9ybURhdGEucHVyY2hhc2U/LmRvY3VtZW50X251bWJlciA/IGBOwrogRmFjdHVyYTogJHtmb3JtRGF0YS5wdXJjaGFzZT8uZG9jdW1lbnRfbnVtYmVyfWAgOiBgSUQgY29tcHJhOiAke2Zvcm1EYXRhLnB1cmNoYXNlX2lkfWApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gc2V0UHVyY2hhc2VDb2RlSW5wdXQoYyA/PyAnJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17aGFuZGxlUHVyY2hhc2VDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiB7IHNldE1vZGFsQ29uZmlnKHB1cmNoYXNlTW9kYWxDb25maWcgYXMgTW9kdWxlQ29uZmlnPGFueT4pOyBzZXRFZGl0aW5nVGFyZ2V0KCdwdXJjaGFzZScpOyBzZXRJc01vZGFsT3Blbih0cnVlKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcHVyY2hhc2VfaWQ6IDAsIHB1cmNoYXNlOiB1bmRlZmluZWQgfSkpOyBzZXRJdGVtcyhbeyAuLi5kZWZhdWx0SXRlbSwgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpIH1dKTsgc2V0UHVyY2hhc2VDb2RlSW5wdXQoJycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZvcm1EYXRhLnZlbmRvcl9pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQW5udWxQdXJjaGFzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZvcm1EYXRhLnB1cmNoYXNlX2lkIHx8IGZvcm1EYXRhLnR5cGUgIT09ICdDUkVESVQnIHx8IGlzTG9hZGluZyB8fCBzYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgdGV4dC1yZWQtNzAwIGJnLXJlZC01MCBob3ZlcjpiZy1yZWQtMTAwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkdlbmVyYXIgbm90YSBwYXJhIGFudWxhY2nDs24gdG90YWwgZGUgbGEgY29tcHJhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbnVsYXJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIEVtaXNpw7NuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuaXNzdWVfZGF0ZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgaXNzdWVfZGF0ZTogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dFN0eWxlfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tM1wiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Tm90YXM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIG5vdGVzOiBlLnRhcmdldC52YWx1ZSB8fCBudWxsIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTRcIj7DjXRlbXM8L2gzPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5EZXNjcmlwY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+U3VidG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHctMTBcIj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtcy5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyb3cudGVtcElkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cm93LmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVVcGRhdGVJdGVtKHJvdy50ZW1wSWQsICdkZXNjcmlwdGlvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpcGNpw7NuIGRlbCDDrXRlbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jvdy5kZWxpdmVyZWRDaGVjaz8uY2hlY2sgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlIHJlY2liaWRvIE5vLiB7cm93LmRlbGl2ZXJlZENoZWNrLmNoZWNrLmNoZWNrX251bWJlcn0sIENsaWVudGU6IHtyb3cuZGVsaXZlcmVkQ2hlY2suY2hlY2suY2hlY2tfaG9sZGVyID8/ICdOL0EnfS4gRmFjdHVyYToge3Jvdy5kZWxpdmVyZWRDaGVjay5jaGVjay5yZWZlcmVuY2VfbnVtYmVyID8/ICdOL0EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlQ2xlYXJJdGVtQ2hlY2socm93LnRlbXBJZCl9IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDBcIiB0aXRsZT1cIlF1aXRhciBjaGVxdWVcIj7DlzwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3cucXVhbnRpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlVXBkYXRlSXRlbShyb3cudGVtcElkLCAncXVhbnRpdHknLCBudW0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIwIHB4LTIgcHktMSB0ZXh0LXJpZ2h0IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cm93LnVuaXRfcHJpY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlVXBkYXRlSXRlbShyb3cudGVtcElkLCAndW5pdF9wcmljZScsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMzIgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1tZWRpdW1cIj57Zm9ybWF0VmFsdWUoTnVtYmVyKHJvdy5xdWFudGl0eSkgKiBOdW1iZXIocm93LnVuaXRfcHJpY2UpLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5DaGVja01vZGFsKHJvdy50ZW1wSWQpfSBjbGFzc05hbWU9XCJwLTEgdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMFwiIHRpdGxlPVwiQXNvY2lhciBjaGVxdWUgcmVjaWJpZG9cIiBkaXNhYmxlZD17IWZvcm1EYXRhLnZlbmRvcl9pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYU1vbmV5Q2hlY2tBbHQgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVJdGVtKHJvdy50ZW1wSWQpfSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwXCIgdGl0bGU9XCJRdWl0YXIgw610ZW1cIj48RmFUcmFzaCAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQWRkSXRlbX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiBtdC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ncmF5LTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYVBsdXMgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gQcOxYWRpciDDrXRlbVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIHAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIGFwbGljYWRvczwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+VmFsb3IgTm8gR3JhdmFkbyAobm8gZ3JhdmFkbyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEud2l0aG91dHRheF9hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHdpdGhvdXR0YXhfYW1vdW50OiBudW0gPz8gMCB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSB0ZXh0LXJpZ2h0IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5JbXB1ZXN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5UYXNhICglKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdncmVnYXRlZFRheGVzLm1hcCgodGF4LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0YXgudGF4X2lkID8/IGlkeH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNtOnBsLTZcIj57dGF4LnRheF9uYW1lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VGF4UmF0ZUNlbGwodGF4KX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZlbmRvclRheGVzLmxlbmd0aCA+IDEgJiYgdHlwZW9mIHRheC50YXhfaWQgPT09ICdudW1iZXInID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGF4LmFtb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVBcHBsaWVkVGF4QW1vdW50KHRheC50YXhfaWQgYXMgbnVtYmVyLCBudW0gPz8gMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjQgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgaW1wdWVzdG9zIGFwbGljYWRvcy48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBtdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBtYi0yXCI+UGVyY2VwY2lvbmVzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uVGF4ZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBwZXJjZXBjaW9uZXMgY29uZmlndXJhZGFzLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uUm93cy5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyb3cudGVtcElkfSBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cm93LnRheF9pZCA/PyAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHByZXYgPT4gcHJldi5tYXAociA9PiByLnRlbXBJZCA9PT0gcm93LnRlbXBJZCA/IHsgLi4uciwgdGF4X2lkOiBudWxsLCB0YXhfbmFtZTogbnVsbCB9IDogcikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRheCA9IHBlcmNlcHRpb25UYXhlcy5maW5kKHQgPT4gdC5pZCA9PT0gTnVtYmVyKHZhbCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGF4KSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWxyZWFkeVVzZWQgPSBwZXJjZXB0aW9uUm93cy5zb21lKHIgPT4gci50ZW1wSWQgIT09IHJvdy50ZW1wSWQgJiYgci50YXhfaWQgPT09IHRheC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFscmVhZHlVc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0VzYSBwZXJjZXBjacOzbiB5YSBlc3TDoSBlbiBsYSBsaXN0YS4gTm8gc2UgcHVlZGUgcmVwZXRpci4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYubWFwKHIgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgci50ZW1wSWQgPT09IHJvdy50ZW1wSWQgPyB7IC4uLnIsIHRheF9pZDogdGF4LmlkLCB0YXhfbmFtZTogdGF4Lm5hbWUgfSA6IHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yIHctZnVsbCBweC0yIHB5LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjY2lvbmUgcGVyY2VwY2nDs248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uVGF4ZXMubWFwKCh0YXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dGF4LmlkfSB2YWx1ZT17dGF4LmlkfSBkaXNhYmxlZD17cGVyY2VwdGlvblJvd3Muc29tZShyID0+IHIudGVtcElkICE9PSByb3cudGVtcElkICYmIHIudGF4X2lkID09PSB0YXguaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RheC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Jvdy5hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYubWFwKHIgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgci50ZW1wSWQgPT09IHJvdy50ZW1wSWQgPyB7IC4uLnIsIGFtb3VudDogbnVtID8/IDAgfSA6IHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYuZmlsdGVyKHIgPT4gci50ZW1wSWQgIT09IHJvdy50ZW1wSWQpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwIHAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJRdWl0YXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGVyY2VwdGlvblJvd3MocHJldiA9PiBbLi4ucHJldiwgeyB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksIHRheF9pZDogbnVsbCwgdGF4X25hbWU6IG51bGwsIGFtb3VudDogMCB9XSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIG10LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyYXktNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEFncmVnYXIgcGVyY2VwY2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlN1YnRvdGFsOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj48c3Bhbj5WYWxvciBObyBHcmF2YWRvIChubyBncmF2YWRvKTo8L3NwYW4+PHNwYW4+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMud2l0aG91dHRheF9hbW91bnQgPz8gMCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc21cIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+SW1wdWVzdG9zOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5QZXJjZXBjaW9uZXM6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj4rIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnBlcmNlcGNpb25lc1RvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gcHQtMiBib3JkZXItdCBtdC0yXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbDo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtaW5kaWdvLTYwMFwiPntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGhvdmVyOmJnLWdyYXktNTBcIj5DYW5jZWxhcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVNhdmV9IGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgc2F2aW5nfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYVNhdmUgY2xhc3NOYW1lPVwibXItMlwiIC8+IEd1YXJkYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiB7IHNldElzTW9kYWxPcGVuKGZhbHNlKTsgc2V0RWRpdGluZ1RhcmdldChudWxsKTsgfX0gb25TZWxlY3Q9e2hhbmRsZVNlbGVjdEZyb21Nb2RhbH0gY29uZmlnPXttb2RhbENvbmZpZ30gLz5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtjaGVja01vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cteGwgbWF4LXctM3hsIHctZnVsbCBtYXgtaC1bODB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYm9yZGVyLWIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlNlbGVjY2lvbmFyIGNoZXF1ZSByZWNpYmlkbzwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRDaGVja01vZGFsT3BlbihmYWxzZSk7IHNldENoZWNrTW9kYWxJdGVtVGVtcElkKG51bGwpOyBzZXREZWxpdmVyZWRDaGVja3NNZXRhKG51bGwpOyB9fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIj7DlzwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBvdmVyZmxvdy1hdXRvIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nRGVsaXZlcmVkQ2hlY2tzID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LThcIj48RmFTcGlubmVyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1pbmRpZ28tNjAwIGFuaW1hdGUtc3BpblwiIC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGRlbGl2ZXJlZENoZWNrc0xpc3QubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgcHktNFwiPk5vIGhheSBjaGVxdWVzIGVudHJlZ2Fkb3MgcGFyYSBlc3RlIHByb3ZlZWRvci48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gYm9yZGVyIHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5OwrogQ2hlcXVlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5UaXR1bGFyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+VmFsb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlJlZi48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3LTI0XCI+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RlbGl2ZXJlZENoZWNrc0xpc3QubWFwKChkYykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ZGMuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbVwiPntkYy5jaGVjaz8uY2hlY2tfbnVtYmVyID8/ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbVwiPntkYy5jaGVjaz8uY2hlY2tfaG9sZGVyID8/ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+e2RjLmNoZWNrID8gZm9ybWF0VmFsdWUoTnVtYmVyKGRjLmNoZWNrLnZhbHVlKSwgJ2N1cnJlbmN5JykgOiAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj57ZGMuY2hlY2s/LnJlZmVyZW5jZV9udW1iZXIgPz8gJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RDaGVjayhkYyl9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPlNlbGVjY2lvbmFyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RlbGl2ZXJlZENoZWNrc01ldGEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdpbmF0aW9uIG1ldGE9e2RlbGl2ZXJlZENoZWNrc01ldGF9IG9uUGFnZUNoYW5nZT17KHUpID0+IGxvYWREZWxpdmVyZWRDaGVja3ModSl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL25vdGFzX2ZpbmFuY2llcmFzX2NvbXByYS9wYWdlcy9Ob3Rhc0ZpbmFuY2llcmFzQ29tcHJhRm9ybVBhZ2UudHN4In0=