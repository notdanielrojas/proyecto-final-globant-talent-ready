import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/remitos/pages/RemitosFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/remitos/pages/RemitosFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Link, useNavigate, useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, search, searchByField } from "/src/services/apiService.ts";
import {
  remitosModuleConfig,
  formatRemitoOriginInvoice,
  DEFAULT_REMITO_SERIES,
  REMITO_SERIES_OPTIONS
} from "/src/features/remitos/remitos.config.tsx";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const EMPTY_REMITO_ITEM = {
  id: 0,
  sales_invoice_item_id: 0,
  invoice_quantity: 0,
  product_id: 0,
  product_sku: "",
  product_name: "",
  quantity: 0,
  pending_to_deliver: 0
};
const defaultInitialData = {
  id: 0,
  remito_number: "",
  series: DEFAULT_REMITO_SERIES,
  delivery_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  status: "Draft",
  sales_invoice_id: null,
  client_id: null,
  transport_id: null,
  delivery_address: null,
  observations: null,
  items: []
};
export const RemitosFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const [searchParams] = useSearchParams();
  const initialInvoiceId = searchParams.get("invoiceId");
  const [isInitialLoading, setIsInitialLoading] = useState(
    mode === "edit" || mode === "create" && !!initialInvoiceId
  );
  const { item: loadedData, loading: loadingData, error } = useCrudItem(remitosModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(remitosModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState([]);
  const [loadingInvoiceData, setLoadingInvoiceData] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const fetchInvoicePendingItems = useCallback(
    async (invoiceId) => {
      const endpoint = `${salesInvoicesModuleConfig.endpoint}/${invoiceId}/pending-items`;
      const url = `${endpoint}`;
      const apiResponse = await search(url);
      return apiResponse;
    },
    []
  );
  const loadInvoiceData = useCallback(async (invoiceId) => {
    setLoadingInvoiceData(true);
    try {
      const apiResponse = await fetchInvoicePendingItems(invoiceId);
      const initialItems = apiResponse.items.filter((i) => i.quantity_pending > 0).map((i) => {
        const pending_to_deliver = i.quantity_pending;
        return {
          ...EMPTY_REMITO_ITEM,
          sales_invoice_item_id: i.sales_invoice_item_id,
          product_id: i.product_id,
          product_sku: i.product_sku,
          product_name: i.product_name,
          invoice_quantity: i.quantity_invoiced,
          pending_to_deliver,
          quantity: pending_to_deliver
        };
      });
      if (initialItems.length === 0) {
        toast.warn("La factura seleccionada ya fue remitida completamente.");
        setFormData(defaultInitialData);
        setItems([]);
        return;
      }
      const invoiceDetail = await getById(salesInvoicesModuleConfig.endpoint, invoiceId);
      setFormData((prev) => ({
        ...prev,
        sales_invoice_id: invoiceId || apiResponse.sales_invoice?.id,
        invoice_number: apiResponse.invoice_number,
        sales_invoice: {
          id: invoiceId,
          invoice_number: invoiceDetail.invoice_number,
          series: invoiceDetail.series,
          afip_pos: invoiceDetail.afip_pos
        },
        client_id: apiResponse.client_id,
        client_name: apiResponse.client_name,
        transport_id: apiResponse.transport?.id || apiResponse.transport_id || null,
        transport_code: apiResponse.transport?.code || null,
        transport_name: apiResponse.transport?.name || null,
        delivery_address: apiResponse.delivery_address,
        observations: apiResponse.notes,
        items: initialItems
      }));
      setItems(initialItems);
    } catch (error2) {
      toast.error("Error al cargar la factura o sus pendientes.");
      console.error(error2);
      setFormData(defaultInitialData);
      setItems([]);
    } finally {
      setLoadingInvoiceData(false);
      setIsInitialLoading(false);
    }
  }, [fetchInvoicePendingItems]);
  const hydrateEditDataWithPending = useCallback(
    async (remito) => {
      if (!remito.sales_invoice_id) {
        console.warn("Remito sin sales_invoice_id; no se pueden calcular pendientes desde backend.");
        const safeItems = remito.items.map((item) => {
          const pending_to_deliver = item.quantity || 0;
          return {
            ...item,
            invoice_quantity: item.invoice_quantity ?? 0,
            pending_to_deliver,
            quantity: pending_to_deliver
          };
        });
        setItems(safeItems);
        setFormData(remito);
        setIsInitialLoading(false);
        return;
      }
      setLoadingInvoiceData(true);
      try {
        const apiResponse = await fetchInvoicePendingItems(remito.sales_invoice_id);
        const backendMap = /* @__PURE__ */ new Map();
        for (const bi of apiResponse.items) {
          backendMap.set(bi.sales_invoice_item_id, bi);
        }
        const mergedItems = remito.items.map((remitoItem) => {
          const backendItem = backendMap.get(remitoItem.sales_invoice_item_id);
          if (!backendItem) {
            const pending_to_deliver2 = remitoItem.quantity || 0;
            return {
              ...remitoItem,
              invoice_quantity: remitoItem.invoice_quantity ?? 0,
              pending_to_deliver: pending_to_deliver2,
              quantity: pending_to_deliver2
            };
          }
          const qtyActualRemito = remitoItem.quantity || 0;
          const pendingBackend = backendItem.quantity_pending || 0;
          const pending_to_deliver = qtyActualRemito + pendingBackend;
          return {
            ...remitoItem,
            invoice_quantity: backendItem.quantity_invoiced,
            pending_to_deliver,
            quantity: pending_to_deliver
          };
        });
        const hydratedData = {
          ...defaultInitialData,
          ...remito,
          client_name: remito.client?.name ?? remito.client_name,
          invoice_number: remito.sales_invoice?.invoice_number != null ? String(remito.sales_invoice.invoice_number) : remito.invoice_number,
          sales_invoice: remito.sales_invoice ? {
            id: remito.sales_invoice.id,
            invoice_number: remito.sales_invoice.invoice_number,
            series: remito.sales_invoice.series,
            afip_pos: remito.sales_invoice.afip_pos
          } : remito.sales_invoice_id ? {
            id: remito.sales_invoice_id,
            invoice_number: remito.invoice_number ?? ""
          } : null,
          sales_invoice_id: remito.sales_invoice?.id ?? remito.sales_invoice_id ?? 0,
          transport_code: remito.transport_code || remito.transport?.code || null,
          transport_name: remito.transport_name || remito.transport?.name || null,
          items: mergedItems
        };
        setFormData(hydratedData);
        setItems(mergedItems);
      } catch (err) {
        console.error("Error al obtener pendientes en edición:", err);
        toast.error("Error al obtener pendientes de la factura para este remito.");
        const fallbackItems = remito.items.map((item) => {
          const pending_to_deliver = item.quantity || 0;
          return {
            ...item,
            invoice_quantity: item.invoice_quantity ?? 0,
            pending_to_deliver,
            quantity: pending_to_deliver
          };
        });
        setFormData(remito);
        setItems(fallbackItems);
      } finally {
        setLoadingInvoiceData(false);
        setIsInitialLoading(false);
      }
    },
    [fetchInvoicePendingItems]
  );
  useEffect(() => {
    if (mode === "create" && initialInvoiceId && !formData.sales_invoice_id) {
      const idToLoad = Number(initialInvoiceId);
      if (!isNaN(idToLoad) && idToLoad > 0) {
        loadInvoiceData(idToLoad);
      } else {
        setIsInitialLoading(false);
      }
    }
  }, [mode, initialInvoiceId, loadInvoiceData, formData.sales_invoice_id]);
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      hydrateEditDataWithPending(loadedData);
    } else if (mode === "create") {
      if (!initialInvoiceId && isInitialLoading) {
        setIsInitialLoading(false);
      } else if (!initialInvoiceId && !formData.sales_invoice_id) {
        setFormData(defaultInitialData);
        setItems([]);
      }
    }
  }, [mode, loadedData, isInitialLoading, initialInvoiceId, hydrateEditDataWithPending]);
  const applyHeaderSelection = (field, selectedItem) => {
    if (field !== "transport") return;
    setFormData((prev) => ({
      ...prev,
      transport_id: selectedItem?.id || null,
      transport_code: selectedItem?.code || null,
      transport_name: selectedItem?.name || null
    }));
  };
  const handleHeaderCodeSubmit = async (field) => {
    if (field !== "transport") return;
    const codeValue = formData.transport_code;
    if (!codeValue) return;
    const { endpoint, relationalFields } = transportesModuleConfig;
    if (!relationalFields) return toast.error(`Configuración relacional faltante para ${field}`);
    try {
      const item = await searchByField(endpoint, [{ fieldName: relationalFields.codeField, value: codeValue }]);
      if (item) {
        applyHeaderSelection(field, item);
        toast.success(`'${item[relationalFields.nameField]}' seleccionado.`);
      } else {
        toast.error(`No se encontró transporte con el código "${codeValue}".`);
      }
    } catch (err) {
      console.error("Error al buscar por código:", err);
      toast.error("Error al buscar transporte por código.");
    }
  };
  const handleInvoiceCodeSubmit = async () => {
    const codeValue = formData.invoice_number;
    if (!codeValue) return;
    setIsInitialLoading(true);
    setLoadingInvoiceData(true);
    try {
      const result = await searchByField(
        salesInvoicesModuleConfig.endpoint,
        [{ fieldName: "invoice_number", value: codeValue }]
      );
      if (result) {
        await loadInvoiceData(result.id);
      } else {
        toast.error(`No se encontró ninguna factura con el número "${codeValue}".`);
        setFormData(defaultInitialData);
        setItems([]);
      }
    } catch (error2) {
      console.error(error2);
      toast.error("Error al buscar la factura por número.");
      setFormData(defaultInitialData);
      setItems([]);
    } finally {
      setLoadingInvoiceData(false);
      setIsInitialLoading(false);
    }
  };
  const handleSelectInvoice = (selectedItem) => {
    setIsInitialLoading(true);
    loadInvoiceData(selectedItem.id);
  };
  const handleSelectModal = (selectedItem) => {
    if (!editingTarget) return;
    if (editingTarget === "sales_invoice") {
      handleSelectInvoice(selectedItem);
    } else if (editingTarget === "transport") {
      applyHeaderSelection("transport", selectedItem);
    }
    setIsModalOpen(false);
  };
  const handleGenericChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  const handleClearTransport = () => {
    setFormData((prev) => ({
      ...prev,
      transport_id: null,
      transport_code: void 0,
      transport_name: void 0
    }));
  };
  const handleSave = async () => {
    if (!formData.sales_invoice_id) {
      toast.error("Debe seleccionar una factura de origen.");
      return;
    }
    if (items.length === 0) {
      toast.error("El remito no tiene productos.");
      return;
    }
    if (items.every((item) => (item.quantity || 0) === 0)) {
      toast.error("Al menos un producto debe tener una cantidad mayor a cero.");
      return;
    }
    if (!formData.delivery_date) {
      toast.error("Debe especificar una Fecha de Entrega.");
      return;
    }
    if (!formData.delivery_address) {
      toast.error("Debe especificar una Dirección de Entrega.");
      return;
    }
    const cleanItems = items.filter((item) => (item.quantity || 0) > 0).map((item) => {
      const { invoice_quantity: _inv, pending_to_deliver: _pen, ...rest } = item;
      return rest;
    });
    const {
      client_name: _cName,
      client_code: _cCode,
      transport_name: _tName,
      transport_code: _tCode,
      invoice_number: _invNum,
      ...headerPayload
    } = formData;
    const dataToSend = {
      ...headerPayload,
      items: cleanItems
    };
    try {
      await saveItem(dataToSend);
      toast.success(`Remito ${mode === "create" ? "creado" : "actualizado"} con éxito.`);
      navigate(getListReturnPath(remitosModuleConfig.baseRoute));
    } catch (apiError) {
      toast.error(`Error al guardar: ${apiError.message || "Error desconocido"}`);
    }
  };
  if (mode === "create" && !formData.sales_invoice_id && !loadingInvoiceData && !isInitialLoading) {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-8 bg-white rounded-lg shadow-xl max-w-lg mx-auto", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-900 mb-4", children: "Paso 1: Seleccionar Factura de Origen" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 512,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-6", children: "Todo remito debe partir de una Factura de Venta existente." }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 513,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: formData.invoice_number || "",
            nameValue: formData.invoice_number || "Buscar Factura...",
            onCodeChange: (newCode) => handleGenericChange({ target: { name: "invoice_number", value: newCode } }),
            onCodeSubmit: handleInvoiceCodeSubmit,
            onSearchClick: () => {
              setEditingTarget("sales_invoice");
              setModalConfig(salesInvoicesModuleConfig);
              setIsModalOpen(true);
            },
            onClearClick: () => {
              setFormData(defaultInitialData);
              setItems([]);
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 514,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 511,
        columnNumber: 17
      }, this),
      isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
        SearchModal,
        {
          isOpen: isModalOpen,
          onClose: () => setIsModalOpen(false),
          onSelect: handleSelectModal,
          config: modalConfig
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 534,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 510,
      columnNumber: 7
    }, this);
  }
  if (loadingData || loadingInvoiceData || mode === "create" && isInitialLoading) {
    return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 547,
      columnNumber: 12
    }, this);
  }
  if (error && mode === "edit") {
    return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
      "Error al cargar datos: ",
      error
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 550,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? `Crear Remito para Factura ${formatRemitoOriginInvoice(formData)}` : `Editando Remito #${formData.remito_number || id}` }, void 0, false, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 555,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Factura Origen" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 566,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-base font-semibold", children: Number(formData.sales_invoice_id) > 0 && (formData.sales_invoice || formData.invoice_number) ? /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: `/facturas-de-venta/${formData.sales_invoice_id}`,
              className: "text-indigo-600 hover:text-indigo-800 hover:underline",
              children: formatRemitoOriginInvoice(formData)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 570,
              columnNumber: 15
            },
            this
          ) : formData.invoice_number || formData.sales_invoice ? /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: formatRemitoOriginInvoice(formData) }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 577,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: "—" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 579,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 567,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 565,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 584,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-base text-gray-900", children: formData.client_name || "N/A" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 585,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 583,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 564,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha de Entrega (*)" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 593,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              name: "delivery_date",
              value: formData.delivery_date?.split("T")[0] || "",
              onChange: handleGenericChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 594,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 592,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 603,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "series",
              value: formData.series || DEFAULT_REMITO_SERIES,
              onChange: handleGenericChange,
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm bg-white",
              children: REMITO_SERIES_OPTIONS.map(
                (opt) => /* @__PURE__ */ jsxDEV("option", { value: opt.value, children: opt.label }, opt.value, false, {
                  fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                  lineNumber: 611,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 604,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 602,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 591,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Transporte" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 619,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.transport_code || "",
              nameValue: formData.transport_name || formData.transport?.name || "",
              onCodeChange: (newCode) => handleGenericChange({ target: { name: "transport_code", value: newCode } }),
              onCodeSubmit: () => handleHeaderCodeSubmit("transport"),
              onSearchClick: () => {
                setEditingTarget("transport");
                setModalConfig(transportesModuleConfig);
                setIsModalOpen(true);
              },
              onClearClick: handleClearTransport
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 620,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 618,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Dirección Entrega (*)" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 636,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-base text-gray-900", children: formData.delivery_address || "N/A" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 637,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 635,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 617,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Observaciones" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 645,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            name: "observations",
            rows: 4,
            value: formData.observations || "",
            onChange: handleGenericChange,
            autoComplete: "off",
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 646,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 644,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 643,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 562,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Detalle de Productos a Entregar" }, void 0, false, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 659,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-2/5", children: "Artículo" }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 665,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Cant. facturada" }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 666,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Cant. a remitir" }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 667,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 664,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 663,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map(
            (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                  fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                  lineNumber: 674,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                  "(",
                  item.product_sku,
                  ")"
                ] }, void 0, true, {
                  fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                  lineNumber: 675,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                lineNumber: 673,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-right text-sm", children: formatValue(item.invoice_quantity, "number") }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                lineNumber: 677,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-right text-sm font-medium text-gray-900", children: formatValue(item.quantity, "number") }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
                lineNumber: 680,
                columnNumber: 37
              }, this)
            ] }, item.sales_invoice_item_id || item.product_id, true, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 672,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
            lineNumber: 670,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 662,
          columnNumber: 21
        }, this),
        items.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-4 text-center text-gray-500", children: "No hay productos pendientes de remitir en esta factura." }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 689,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 661,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 658,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => navigate(getListReturnPath(remitosModuleConfig.baseRoute)),
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
          children: "Cancelar"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 696,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: saving || items.length === 0 || loadingInvoiceData,
          className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:opacity-60",
          children: [
            saving || loadingInvoiceData ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 710,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
              lineNumber: 712,
              columnNumber: 11
            }, this),
            "Guardar Remito"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
          lineNumber: 703,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
      lineNumber: 695,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: () => setIsModalOpen(false),
        onSelect: handleSelectModal,
        config: modalConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
        lineNumber: 720,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/remitos/pages/RemitosFormPage.tsx",
    lineNumber: 554,
    columnNumber: 5
  }, this);
};
_s(RemitosFormPage, "x4JiC+JhR1rh2wZ1gPCzNChkmn0=", false, function() {
  return [useParams, useNavigate, useSearchParams, useCrudItem, useCrudItem];
});
_c = RemitosFormPage;
var _c;
$RefreshReg$(_c, "RemitosFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/remitos/pages/RemitosFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/remitos/pages/RemitosFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMGVZLG1CQUVRLGNBRlI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeGVaLFNBQVNBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUNqRCxTQUFTQyxNQUFNQyxhQUFhQyxXQUFXQyx1QkFBdUI7QUFDOUQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxpQkFBaUI7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFNBQVNDLFFBQVFDLHFCQUFxQjtBQUcvQztBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BR0c7QUFFUCxTQUFTQyxpQ0FBb0Q7QUFFN0QsU0FBU0MsK0JBQStCO0FBS3hDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyx5QkFBeUI7QUE2Q2xDLE1BQU1DLG9CQUFnQztBQUFBLEVBQ2xDQyxJQUFJO0FBQUEsRUFDSkMsdUJBQXVCO0FBQUEsRUFDdkJDLGtCQUFrQjtBQUFBLEVBQ2xCQyxZQUFZO0FBQUEsRUFDWkMsYUFBYTtBQUFBLEVBQ2JDLGNBQWM7QUFBQSxFQUNkQyxVQUFVO0FBQUEsRUFDVkMsb0JBQW9CO0FBQ3hCO0FBRUEsTUFBTUMscUJBQXNDO0FBQUEsRUFDeENSLElBQUk7QUFBQSxFQUNKUyxlQUFlO0FBQUEsRUFDZkMsUUFBUXBCO0FBQUFBLEVBQ1JxQixnQkFBZSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNwREMsUUFBUTtBQUFBLEVBQ1JDLGtCQUFrQjtBQUFBLEVBQ2xCQyxXQUFXO0FBQUEsRUFDWEMsY0FBYztBQUFBLEVBQ2RDLGtCQUFrQjtBQUFBLEVBQ2xCQyxjQUFjO0FBQUEsRUFDZEMsT0FBTztBQUNYO0FBSU8sYUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFdkIsR0FBRyxJQUFJckIsVUFBMEI7QUFDekMsUUFBTTZDLFdBQVc5QyxZQUFZO0FBQzdCLFFBQU0rQyxPQUFPekIsS0FBSyxTQUFTO0FBRTNCLFFBQU0sQ0FBQzBCLFlBQVksSUFBSTlDLGdCQUFnQjtBQUN2QyxRQUFNK0MsbUJBQW1CRCxhQUFhRSxJQUFJLFdBQVc7QUFFckQsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJeEQ7QUFBQUEsSUFDNUNtRCxTQUFTLFVBQVdBLFNBQVMsWUFBWSxDQUFDLENBQUNFO0FBQUFBLEVBQy9DO0FBRUEsUUFBTSxFQUFFSSxNQUFNQyxZQUFZQyxTQUFTQyxhQUFhQyxNQUFNLElBQUluRCxZQUFvQkkscUJBQXFCWSxFQUFFO0FBQ3JHLFFBQU0sRUFBRW9DLFVBQVVILFNBQVNJLE9BQU8sSUFBSXJELFlBQW9CSSxxQkFBcUJZLEVBQUU7QUFFakYsUUFBTSxDQUFDc0MsVUFBVUMsV0FBVyxJQUFJakUsU0FBMEJrQyxrQkFBa0I7QUFDNUUsUUFBTSxDQUFDYSxPQUFPbUIsUUFBUSxJQUFJbEUsU0FBdUIsRUFBRTtBQUNuRCxRQUFNLENBQUNtRSxvQkFBb0JDLHFCQUFxQixJQUFJcEUsU0FBUyxLQUFLO0FBR2xFLFFBQU0sQ0FBQ3FFLGFBQWFDLGNBQWMsSUFBSXRFLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN1RSxhQUFhQyxjQUFjLElBQUl4RSxTQUFtQyxJQUFJO0FBQzdFLFFBQU0sQ0FBQ3lFLGVBQWVDLGdCQUFnQixJQUFJMUUsU0FBK0IsSUFBSTtBQUc3RSxRQUFNMkUsMkJBQTJCekU7QUFBQUEsSUFDN0IsT0FBTzBFLGNBQW1EO0FBQ3RELFlBQU1DLFdBQVcsR0FBRzNELDBCQUEwQjJELFFBQVEsSUFBSUQsU0FBUztBQUNuRSxZQUFNRSxNQUFNLEdBQUdELFFBQVE7QUFDdkIsWUFBTUUsY0FBYyxNQUFNbkUsT0FBMkJrRSxHQUFHO0FBQ3hELGFBQU9DO0FBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsRUFDSjtBQUlBLFFBQU1DLGtCQUFrQjlFLFlBQVksT0FBTzBFLGNBQXNCO0FBQzdEUiwwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0EsWUFBTVcsY0FBYyxNQUFNSix5QkFBeUJDLFNBQVM7QUFFNUQsWUFBTUssZUFBNkJGLFlBQVloQyxNQUMxQ21DLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsbUJBQW1CLENBQUMsRUFDbENDLElBQUksQ0FBQ0YsTUFBMEM7QUFDNUMsY0FBTWxELHFCQUFxQmtELEVBQUVDO0FBQzdCLGVBQU87QUFBQSxVQUNILEdBQUczRDtBQUFBQSxVQUNIRSx1QkFBdUJ3RCxFQUFFeEQ7QUFBQUEsVUFDekJFLFlBQVlzRCxFQUFFdEQ7QUFBQUEsVUFDZEMsYUFBYXFELEVBQUVyRDtBQUFBQSxVQUNmQyxjQUFjb0QsRUFBRXBEO0FBQUFBLFVBQ2hCSCxrQkFBa0J1RCxFQUFFRztBQUFBQSxVQUNwQnJEO0FBQUFBLFVBQ0FELFVBQVVDO0FBQUFBLFFBQ2Q7QUFBQSxNQUNKLENBQUM7QUFFTCxVQUFJZ0QsYUFBYU0sV0FBVyxHQUFHO0FBQzNCaEYsY0FBTWlGLEtBQUssd0RBQXdEO0FBQ25FdkIsb0JBQVkvQixrQkFBa0I7QUFDOUJnQyxpQkFBUyxFQUFFO0FBQ1g7QUFBQSxNQUNKO0FBRUEsWUFBTXVCLGdCQUFnQixNQUFNOUUsUUFBc0JPLDBCQUEwQjJELFVBQVVELFNBQVM7QUFFL0ZYLGtCQUFZLENBQUN5QixVQUEyQjtBQUFBLFFBQ3BDLEdBQUdBO0FBQUFBLFFBQ0hoRCxrQkFBa0JrQyxhQUFhRyxZQUFZWSxlQUFlakU7QUFBQUEsUUFDMURrRSxnQkFBZ0JiLFlBQVlhO0FBQUFBLFFBQzVCRCxlQUFlO0FBQUEsVUFDWGpFLElBQUlrRDtBQUFBQSxVQUNKZ0IsZ0JBQWdCSCxjQUFjRztBQUFBQSxVQUM5QnhELFFBQVFxRCxjQUFjckQ7QUFBQUEsVUFDdEJ5RCxVQUFVSixjQUFjSTtBQUFBQSxRQUM1QjtBQUFBLFFBQ0FsRCxXQUFXb0MsWUFBWXBDO0FBQUFBLFFBQ3ZCbUQsYUFBYWYsWUFBWWU7QUFBQUEsUUFDekJsRCxjQUFjbUMsWUFBWWdCLFdBQVdyRSxNQUFNcUQsWUFBWW5DLGdCQUFnQjtBQUFBLFFBQ3ZFb0QsZ0JBQWdCakIsWUFBWWdCLFdBQVdFLFFBQVE7QUFBQSxRQUMvQ0MsZ0JBQWdCbkIsWUFBWWdCLFdBQVdJLFFBQVE7QUFBQSxRQUMvQ3RELGtCQUFrQmtDLFlBQVlsQztBQUFBQSxRQUM5QkMsY0FBY2lDLFlBQVlxQjtBQUFBQSxRQUMxQnJELE9BQU9rQztBQUFBQSxNQUNYLEVBQUU7QUFDRmYsZUFBU2UsWUFBWTtBQUFBLElBQ3pCLFNBQVNwQixRQUFPO0FBQ1p0RCxZQUFNc0QsTUFBTSw4Q0FBOEM7QUFDMUR3QyxjQUFReEMsTUFBTUEsTUFBSztBQUNuQkksa0JBQVkvQixrQkFBa0I7QUFDOUJnQyxlQUFTLEVBQUU7QUFBQSxJQUNmLFVBQUM7QUFDR0UsNEJBQXNCLEtBQUs7QUFDM0JaLDBCQUFvQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNKLEdBQUcsQ0FBQ21CLHdCQUF3QixDQUFDO0FBRzdCLFFBQU0yQiw2QkFBNkJwRztBQUFBQSxJQUMvQixPQUFPcUcsV0FBbUI7QUFFdEIsVUFBSSxDQUFDQSxPQUFPN0Qsa0JBQWtCO0FBRTFCMkQsZ0JBQVFiLEtBQUssOEVBQThFO0FBRTNGLGNBQU1nQixZQUFZRCxPQUFPeEQsTUFBTXNDLElBQUksQ0FBQTVCLFNBQVE7QUFDdkMsZ0JBQU14QixxQkFBcUJ3QixLQUFLekIsWUFBWTtBQUM1QyxpQkFBTztBQUFBLFlBQ0gsR0FBR3lCO0FBQUFBLFlBQ0g3QixrQkFBa0I2QixLQUFLN0Isb0JBQW9CO0FBQUEsWUFDM0NLO0FBQUFBLFlBQ0FELFVBQVVDO0FBQUFBLFVBQ2Q7QUFBQSxRQUNKLENBQUM7QUFDRGlDLGlCQUFTc0MsU0FBUztBQUNsQnZDLG9CQUFZc0MsTUFBTTtBQUNsQi9DLDRCQUFvQixLQUFLO0FBQ3pCO0FBQUEsTUFDSjtBQUVBWSw0QkFBc0IsSUFBSTtBQUMxQixVQUFJO0FBQ0EsY0FBTVcsY0FBYyxNQUFNSix5QkFBeUI0QixPQUFPN0QsZ0JBQWdCO0FBRzFFLGNBQU0rRCxhQUFhLG9CQUFJQyxJQUFvQztBQUMzRCxtQkFBV0MsTUFBTTVCLFlBQVloQyxPQUFPO0FBQ2hDMEQscUJBQVdHLElBQUlELEdBQUdoRix1QkFBdUJnRixFQUFFO0FBQUEsUUFDL0M7QUFFQSxjQUFNRSxjQUE0Qk4sT0FBT3hELE1BQU1zQyxJQUFJLENBQUF5QixlQUFjO0FBQzdELGdCQUFNQyxjQUFjTixXQUFXbkQsSUFBSXdELFdBQVduRixxQkFBcUI7QUFFbkUsY0FBSSxDQUFDb0YsYUFBYTtBQUNkLGtCQUFNOUUsc0JBQXFCNkUsV0FBVzlFLFlBQVk7QUFDbEQsbUJBQU87QUFBQSxjQUNILEdBQUc4RTtBQUFBQSxjQUNIbEYsa0JBQWtCa0YsV0FBV2xGLG9CQUFvQjtBQUFBLGNBQ2pESztBQUFBQSxjQUNBRCxVQUFVQztBQUFBQSxZQUNkO0FBQUEsVUFDSjtBQUVBLGdCQUFNK0Usa0JBQWtCRixXQUFXOUUsWUFBWTtBQUMvQyxnQkFBTWlGLGlCQUFpQkYsWUFBWTNCLG9CQUFvQjtBQUN2RCxnQkFBTW5ELHFCQUFxQitFLGtCQUFrQkM7QUFFN0MsaUJBQU87QUFBQSxZQUNILEdBQUdIO0FBQUFBLFlBQ0hsRixrQkFBa0JtRixZQUFZekI7QUFBQUEsWUFDOUJyRDtBQUFBQSxZQUNBRCxVQUFVQztBQUFBQSxVQUNkO0FBQUEsUUFDSixDQUFDO0FBR0QsY0FBTWlGLGVBQXVCO0FBQUEsVUFDekIsR0FBR2hGO0FBQUFBLFVBQ0gsR0FBR3FFO0FBQUFBLFVBQ0hULGFBQWFTLE9BQU9ZLFFBQVFoQixRQUFRSSxPQUFPVDtBQUFBQSxVQUMzQ0YsZ0JBQ0lXLE9BQU9aLGVBQWVDLGtCQUFrQixPQUNsQ3dCLE9BQU9iLE9BQU9aLGNBQWNDLGNBQWMsSUFDMUNXLE9BQU9YO0FBQUFBLFVBQ2pCRCxlQUFlWSxPQUFPWixnQkFDaEI7QUFBQSxZQUNFakUsSUFBSTZFLE9BQU9aLGNBQWNqRTtBQUFBQSxZQUN6QmtFLGdCQUFnQlcsT0FBT1osY0FBY0M7QUFBQUEsWUFDckN4RCxRQUFRbUUsT0FBT1osY0FBY3ZEO0FBQUFBLFlBQzdCeUQsVUFBVVUsT0FBT1osY0FBY0U7QUFBQUEsVUFDbkMsSUFDRVUsT0FBTzdELG1CQUNMO0FBQUEsWUFDSWhCLElBQUk2RSxPQUFPN0Q7QUFBQUEsWUFDWGtELGdCQUFnQlcsT0FBT1gsa0JBQWtCO0FBQUEsVUFDN0MsSUFDQTtBQUFBLFVBQ1JsRCxrQkFBa0I2RCxPQUFPWixlQUFlakUsTUFBTTZFLE9BQU83RCxvQkFBb0I7QUFBQSxVQUN6RXNELGdCQUFnQk8sT0FBT1Asa0JBQWtCTyxPQUFPUixXQUFXRSxRQUFRO0FBQUEsVUFDbkVDLGdCQUFnQkssT0FBT0wsa0JBQWtCSyxPQUFPUixXQUFXSSxRQUFRO0FBQUEsVUFDbkVwRCxPQUFPOEQ7QUFBQUEsUUFDWDtBQUVBNUMsb0JBQVlpRCxZQUFZO0FBQ3hCaEQsaUJBQVMyQyxXQUFXO0FBQUEsTUFDeEIsU0FBU1EsS0FBSztBQUNWaEIsZ0JBQVF4QyxNQUFNLDJDQUEyQ3dELEdBQUc7QUFDNUQ5RyxjQUFNc0QsTUFBTSw2REFBNkQ7QUFFekUsY0FBTXlELGdCQUE4QmYsT0FBT3hELE1BQU1zQyxJQUFJLENBQUE1QixTQUFRO0FBQ3pELGdCQUFNeEIscUJBQXFCd0IsS0FBS3pCLFlBQVk7QUFDNUMsaUJBQU87QUFBQSxZQUNILEdBQUd5QjtBQUFBQSxZQUNIN0Isa0JBQWtCNkIsS0FBSzdCLG9CQUFvQjtBQUFBLFlBQzNDSztBQUFBQSxZQUNBRCxVQUFVQztBQUFBQSxVQUNkO0FBQUEsUUFDSixDQUFDO0FBQ0RnQyxvQkFBWXNDLE1BQU07QUFDbEJyQyxpQkFBU29ELGFBQWE7QUFBQSxNQUMxQixVQUFDO0FBQ0dsRCw4QkFBc0IsS0FBSztBQUMzQlosNEJBQW9CLEtBQUs7QUFBQSxNQUM3QjtBQUFBLElBQ0o7QUFBQSxJQUNBLENBQUNtQix3QkFBd0I7QUFBQSxFQUM3QjtBQUdBMUUsWUFBVSxNQUFNO0FBQ1osUUFBSWtELFNBQVMsWUFBWUUsb0JBQW9CLENBQUNXLFNBQVN0QixrQkFBa0I7QUFDckUsWUFBTTZFLFdBQVdDLE9BQU9uRSxnQkFBZ0I7QUFDeEMsVUFBSSxDQUFDb0UsTUFBTUYsUUFBUSxLQUFLQSxXQUFXLEdBQUc7QUFDbEN2Qyx3QkFBZ0J1QyxRQUFRO0FBQUEsTUFDNUIsT0FBTztBQUNIL0QsNEJBQW9CLEtBQUs7QUFBQSxNQUM3QjtBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsQ0FBQ0wsTUFBTUUsa0JBQWtCMkIsaUJBQWlCaEIsU0FBU3RCLGdCQUFnQixDQUFDO0FBR3ZFekMsWUFBVSxNQUFNO0FBQ1osUUFBSWtELFNBQVMsVUFBVU8sWUFBWTtBQUUvQjRDLGlDQUEyQjVDLFVBQW9CO0FBQUEsSUFDbkQsV0FBV1AsU0FBUyxVQUFVO0FBQzFCLFVBQUksQ0FBQ0Usb0JBQW9CRSxrQkFBa0I7QUFDdkNDLDRCQUFvQixLQUFLO0FBQUEsTUFDN0IsV0FBVyxDQUFDSCxvQkFBb0IsQ0FBQ1csU0FBU3RCLGtCQUFrQjtBQUN4RHVCLG9CQUFZL0Isa0JBQWtCO0FBQzlCZ0MsaUJBQVMsRUFBRTtBQUFBLE1BQ2Y7QUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUNmLE1BQU1PLFlBQVlILGtCQUFrQkYsa0JBQWtCaUQsMEJBQTBCLENBQUM7QUFJckYsUUFBTW9CLHVCQUF1QkEsQ0FBQ0MsT0FBb0JDLGlCQUFzQjtBQUNwRSxRQUFJRCxVQUFVLFlBQWE7QUFFM0IxRCxnQkFBWSxDQUFBeUIsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0g5QyxjQUFjZ0YsY0FBY2xHLE1BQU07QUFBQSxNQUNsQ3NFLGdCQUFnQjRCLGNBQWMzQixRQUFRO0FBQUEsTUFDdENDLGdCQUFnQjBCLGNBQWN6QixRQUFRO0FBQUEsSUFDMUMsRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNMEIseUJBQXlCLE9BQU9GLFVBQXVCO0FBQ3pELFFBQUlBLFVBQVUsWUFBYTtBQUUzQixVQUFNRyxZQUFZOUQsU0FBU2dDO0FBQzNCLFFBQUksQ0FBQzhCLFVBQVc7QUFFaEIsVUFBTSxFQUFFakQsVUFBVWtELGlCQUFpQixJQUFJNUc7QUFDdkMsUUFBSSxDQUFDNEcsaUJBQWtCLFFBQU94SCxNQUFNc0QsTUFBTSwwQ0FBMEM4RCxLQUFLLEVBQUU7QUFFM0YsUUFBSTtBQUNBLFlBQU1sRSxPQUFPLE1BQU01QyxjQUFtQmdFLFVBQVUsQ0FBQyxFQUFFbUQsV0FBV0QsaUJBQWlCRSxXQUFxQkMsT0FBT0osVUFBVSxDQUFDLENBQUM7QUFDdkgsVUFBSXJFLE1BQU07QUFDTmlFLDZCQUFxQkMsT0FBT2xFLElBQUk7QUFDaENsRCxjQUFNNEgsUUFBUSxJQUFJMUUsS0FBS3NFLGlCQUFpQkssU0FBbUIsQ0FBQyxpQkFBaUI7QUFBQSxNQUNqRixPQUFPO0FBQ0g3SCxjQUFNc0QsTUFBTSw0Q0FBNENpRSxTQUFTLElBQUk7QUFBQSxNQUN6RTtBQUFBLElBQ0osU0FBU1QsS0FBSztBQUNWaEIsY0FBUXhDLE1BQU0sK0JBQStCd0QsR0FBRztBQUNoRDlHLFlBQU1zRCxNQUFNLHdDQUF3QztBQUFBLElBQ3hEO0FBQUEsRUFDSjtBQUVBLFFBQU13RSwwQkFBMEIsWUFBWTtBQUN4QyxVQUFNUCxZQUFZOUQsU0FBUzRCO0FBQzNCLFFBQUksQ0FBQ2tDLFVBQVc7QUFFaEJ0RSx3QkFBb0IsSUFBSTtBQUN4QlksMEJBQXNCLElBQUk7QUFFMUIsUUFBSTtBQUNBLFlBQU1rRSxTQUFTLE1BQU16SDtBQUFBQSxRQUNqQkssMEJBQTBCMkQ7QUFBQUEsUUFDMUIsQ0FBQyxFQUFFbUQsV0FBVyxrQkFBa0JFLE9BQU9KLFVBQVUsQ0FBQztBQUFBLE1BQ3REO0FBRUEsVUFBSVEsUUFBUTtBQUVSLGNBQU10RCxnQkFBZ0JzRCxPQUFPNUcsRUFBRTtBQUFBLE1BQ25DLE9BQU87QUFDSG5CLGNBQU1zRCxNQUFNLGlEQUFpRGlFLFNBQVMsSUFBSTtBQUMxRTdELG9CQUFZL0Isa0JBQWtCO0FBQzlCZ0MsaUJBQVMsRUFBRTtBQUFBLE1BQ2Y7QUFBQSxJQUNKLFNBQVNMLFFBQU87QUFDWndDLGNBQVF4QyxNQUFNQSxNQUFLO0FBQ25CdEQsWUFBTXNELE1BQU0sd0NBQXdDO0FBQ3BESSxrQkFBWS9CLGtCQUFrQjtBQUM5QmdDLGVBQVMsRUFBRTtBQUFBLElBQ2YsVUFBQztBQUNHRSw0QkFBc0IsS0FBSztBQUMzQlosMEJBQW9CLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0o7QUFFQSxRQUFNK0Usc0JBQXNCQSxDQUFDWCxpQkFBK0I7QUFDeERwRSx3QkFBb0IsSUFBSTtBQUN4QndCLG9CQUFnQjRDLGFBQWFsRyxFQUFFO0FBQUEsRUFDbkM7QUFFQSxRQUFNOEcsb0JBQW9CQSxDQUFDWixpQkFBc0I7QUFDN0MsUUFBSSxDQUFDbkQsY0FBZTtBQUVwQixRQUFJQSxrQkFBa0IsaUJBQWlCO0FBQ25DOEQsMEJBQW9CWCxZQUE0QjtBQUFBLElBQ3BELFdBQVduRCxrQkFBa0IsYUFBYTtBQUN0Q2lELDJCQUFxQixhQUFhRSxZQUFZO0FBQUEsSUFDbEQ7QUFDQXRELG1CQUFlLEtBQUs7QUFBQSxFQUN4QjtBQUVBLFFBQU1tRSxzQkFBc0JBLENBQUNDLE1BQXFGO0FBQzlHLFVBQU0sRUFBRXZDLE1BQU0rQixNQUFNLElBQUlRLEVBQUVDO0FBQzFCMUUsZ0JBQVksQ0FBQ3lCLFVBQTJCLEVBQUUsR0FBR0EsTUFBTSxDQUFDUyxJQUFJLEdBQUcrQixNQUFNLEVBQUU7QUFBQSxFQUN2RTtBQUVBLFFBQU1VLHVCQUF1QkEsTUFBTTtBQUMvQjNFLGdCQUFZLENBQUF5QixVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSDlDLGNBQWM7QUFBQSxNQUNkb0QsZ0JBQWdCNkM7QUFBQUEsTUFDaEIzQyxnQkFBZ0IyQztBQUFBQSxJQUNwQixFQUFFO0FBQUEsRUFDTjtBQUVBLFFBQU1DLGFBQWEsWUFBWTtBQUMzQixRQUFJLENBQUM5RSxTQUFTdEIsa0JBQWtCO0FBQzVCbkMsWUFBTXNELE1BQU0seUNBQXlDO0FBQ3JEO0FBQUEsSUFDSjtBQUNBLFFBQUlkLE1BQU13QyxXQUFXLEdBQUc7QUFDcEJoRixZQUFNc0QsTUFBTSwrQkFBK0I7QUFDM0M7QUFBQSxJQUNKO0FBQ0EsUUFBSWQsTUFBTWdHLE1BQU0sQ0FBQXRGLFVBQVNBLEtBQUt6QixZQUFZLE9BQU8sQ0FBQyxHQUFHO0FBQ2pEekIsWUFBTXNELE1BQU0sNERBQTREO0FBQ3hFO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQ0csU0FBUzNCLGVBQWU7QUFDekI5QixZQUFNc0QsTUFBTSx3Q0FBd0M7QUFDcEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDRyxTQUFTbkIsa0JBQWtCO0FBQzVCdEMsWUFBTXNELE1BQU0sNENBQTRDO0FBQ3hEO0FBQUEsSUFDSjtBQUVBLFVBQU1tRixhQUFhakcsTUFDZG1DLE9BQU8sQ0FBQXpCLFVBQVNBLEtBQUt6QixZQUFZLEtBQUssQ0FBQyxFQUN2Q3FELElBQUksQ0FBQTVCLFNBQVE7QUFDVCxZQUFNLEVBQUU3QixrQkFBa0JxSCxNQUFNaEgsb0JBQW9CaUgsTUFBTSxHQUFHQyxLQUFLLElBQUkxRjtBQUN0RSxhQUFPMEY7QUFBQUEsSUFDWCxDQUFDO0FBRUwsVUFBTTtBQUFBLE1BQ0ZyRCxhQUFhc0Q7QUFBQUEsTUFBUUMsYUFBYUM7QUFBQUEsTUFDbENwRCxnQkFBZ0JxRDtBQUFBQSxNQUFRdkQsZ0JBQWdCd0Q7QUFBQUEsTUFDeEM1RCxnQkFBZ0I2RDtBQUFBQSxNQUNoQixHQUFHQztBQUFBQSxJQUNQLElBQUkxRjtBQUVKLFVBQU0yRixhQUE4QjtBQUFBLE1BQ2hDLEdBQUdEO0FBQUFBLE1BQ0gzRyxPQUFPaUc7QUFBQUEsSUFDWDtBQUVBLFFBQUk7QUFDQSxZQUFNbEYsU0FBUzZGLFVBQW9CO0FBQ25DcEosWUFBTTRILFFBQVEsVUFBVWhGLFNBQVMsV0FBVyxXQUFXLGFBQWEsYUFBYTtBQUNqRkQsZUFBUzFCLGtCQUFrQlYsb0JBQW9COEksU0FBUyxDQUFDO0FBQUEsSUFDN0QsU0FBU0MsVUFBZTtBQUNwQnRKLFlBQU1zRCxNQUFNLHFCQUFxQmdHLFNBQVNDLFdBQVcsbUJBQW1CLEVBQUU7QUFBQSxJQUM5RTtBQUFBLEVBQ0o7QUFHQSxNQUFJM0csU0FBUyxZQUFZLENBQUNhLFNBQVN0QixvQkFBb0IsQ0FBQ3lCLHNCQUFzQixDQUFDWixrQkFBa0I7QUFDN0YsV0FDSSxtQ0FDSTtBQUFBLDZCQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0Q0FBMkMscURBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxRQUM5Rix1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLDBFQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsUUFDNUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVdTLFNBQVM0QixrQkFBa0I7QUFBQSxZQUN0QyxXQUFXNUIsU0FBUzRCLGtCQUFrQjtBQUFBLFlBQ3RDLGNBQWMsQ0FBQ21FLFlBQ1h0QixvQkFBb0IsRUFBRUUsUUFBUSxFQUFFeEMsTUFBTSxrQkFBa0IrQixPQUFPNkIsUUFBUSxFQUFFLENBQXdDO0FBQUEsWUFFckgsY0FBYzFCO0FBQUFBLFlBQ2QsZUFBZSxNQUFNO0FBQ2pCM0QsK0JBQWlCLGVBQWU7QUFDaENGLDZCQUFldEQseUJBQXlCO0FBQ3hDb0QsNkJBQWUsSUFBSTtBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxjQUFjLE1BQU07QUFDaEJMLDBCQUFZL0Isa0JBQWtCO0FBQzlCZ0MsdUJBQVMsRUFBRTtBQUFBLFlBQ2Y7QUFBQTtBQUFBLFVBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZU07QUFBQSxXQWxCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsTUFFQ0csZUFBZUUsZUFDWjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csUUFBUUY7QUFBQUEsVUFDUixTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFVBQ25DLFVBQVVrRTtBQUFBQSxVQUNWLFFBQVFqRTtBQUFBQTtBQUFBQSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUl3QjtBQUFBLFNBNUJoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsRUFFUjtBQUdBLE1BQUlYLGVBQWVPLHNCQUF1QmhCLFNBQVMsWUFBWUksa0JBQW1CO0FBQzlFLFdBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDMUI7QUFDQSxNQUFJTSxTQUFTVixTQUFTLFFBQVE7QUFDMUIsV0FBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLE1BQXdCVTtBQUFBQSxTQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsRUFDdkU7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLDJCQUFDLFFBQUcsV0FBVSx1Q0FDVFYsbUJBQVMsV0FDSiw2QkFBNkJwQywwQkFBMEJpRCxRQUFRLENBQUMsS0FDaEUsb0JBQW9CQSxTQUFTN0IsaUJBQWlCVCxFQUFFLE1BSDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUVYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsU0FBSSxXQUFVLGdDQUNWOEYsaUJBQU94RCxTQUFTdEIsZ0JBQWdCLElBQUksTUFDcENzQixTQUFTMkIsaUJBQWlCM0IsU0FBUzRCLGtCQUNoQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBSSxzQkFBc0I1QixTQUFTdEIsZ0JBQWdCO0FBQUEsY0FDbkQsV0FBVTtBQUFBLGNBRVQzQixvQ0FBMEJpRCxRQUFRO0FBQUE7QUFBQSxZQUp2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQSxJQUNBQSxTQUFTNEIsa0JBQWtCNUIsU0FBUzJCLGdCQUNwQyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCNUUsb0NBQTBCaUQsUUFBUSxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRSxJQUVyRSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQyxLQVp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsVUFDbEUsdUJBQUMsT0FBRSxXQUFVLGdDQUNSQSxtQkFBUzhCLGVBQWUsU0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsb0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU85QixTQUFTM0IsZUFBZUcsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsY0FDaEQsVUFBVWlHO0FBQUFBLGNBQ1YsY0FBYTtBQUFBLGNBQU0sV0FBVTtBQUFBO0FBQUEsWUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FIO0FBQUEsYUFQekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNwRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsT0FBT3pFLFNBQVM1QixVQUFVcEI7QUFBQUEsY0FDMUIsVUFBVXlIO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVR4SCxnQ0FBc0JvRTtBQUFBQSxnQkFBSSxDQUFDMkUsUUFDeEIsdUJBQUMsWUFBdUIsT0FBT0EsSUFBSTlCLE9BQVE4QixjQUFJQyxTQUFsQ0QsSUFBSTlCLE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsY0FDeEQ7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDBCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXbEUsU0FBU2dDLGtCQUFrQjtBQUFBLGNBQ3RDLFdBQVdoQyxTQUFTa0Msa0JBQWtCbEMsU0FBUytCLFdBQVdJLFFBQVE7QUFBQSxjQUNsRSxjQUFjLENBQUM0RCxZQUNYdEIsb0JBQW9CLEVBQUVFLFFBQVEsRUFBRXhDLE1BQU0sa0JBQWtCK0IsT0FBTzZCLFFBQVEsRUFBRSxDQUF3QztBQUFBLGNBRXJILGNBQWMsTUFBTWxDLHVCQUF1QixXQUFXO0FBQUEsY0FDdEQsZUFBZSxNQUFNO0FBQ2pCbkQsaUNBQWlCLFdBQVc7QUFDNUJGLCtCQUFlckQsdUJBQXVCO0FBQ3RDbUQsK0JBQWUsSUFBSTtBQUFBLGNBQ3ZCO0FBQUEsY0FDQSxjQUFjc0U7QUFBQUE7QUFBQUEsWUFabEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWXVDO0FBQUEsYUFkM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMscUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsT0FBRSxXQUFVLGdDQUNSNUUsbUJBQVNuQixvQkFBb0IsU0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNYLGlDQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLE9BQU9tQixTQUFTbEIsZ0JBQWdCO0FBQUEsWUFDaEMsVUFBVTJGO0FBQUFBLFlBQ1YsY0FBYTtBQUFBLFlBQU0sV0FBVTtBQUFBO0FBQUEsVUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3FIO0FBQUEsV0FQekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0E1Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZGQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLG9EQUFtRCwrQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRztBQUFBLE1BRWhHLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsd0ZBQXVGLHdCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RztBQUFBLFlBQzdHLHVCQUFDLFFBQUcsV0FBVSxtRkFBa0YsK0JBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStHO0FBQUEsWUFDL0csdUJBQUMsUUFBRyxXQUFVLG1GQUFrRiwrQkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0c7QUFBQSxlQUhuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaMUYsZ0JBQU1zQztBQUFBQSxZQUFJLENBQUM1QixTQUNSLHVCQUFDLFFBQ0c7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsK0JBQ1Y7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNkJBQTZCQSxlQUFLMUIsZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsZ0JBQzlELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGtCQUFFMEIsS0FBSzNCO0FBQUFBLGtCQUFZO0FBQUEscUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsbUJBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxrREFDVFAsc0JBQVlrQyxLQUFLN0Isa0JBQWtCLFFBQVEsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDRFQUNUTCxzQkFBWWtDLEtBQUt6QixVQUFVLFFBQVEsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVZLeUIsS0FBSzlCLHlCQUF5QjhCLEtBQUs1QixZQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsVUFDSCxLQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQ2tCLE1BQU13QyxXQUFXLEtBQ2QsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyx1RUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFdBNUI5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsU0FqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTXJDLFNBQVMxQixrQkFBa0JWLG9CQUFvQjhJLFNBQVMsQ0FBQztBQUFBLFVBQ3hFLFdBQVU7QUFBQSxVQUE0STtBQUFBO0FBQUEsUUFIMUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTZDtBQUFBQSxVQUNULFVBQVUvRSxVQUFVaEIsTUFBTXdDLFdBQVcsS0FBS3BCO0FBQUFBLFVBQzFDLFdBQVU7QUFBQSxVQUVUSjtBQUFBQSxzQkFBVUkscUJBQ1AsdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRCxJQUVoRCx1QkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFDbkM7QUFBQTtBQUFBO0FBQUEsUUFWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLFNBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUdDRSxlQUFlRSxlQUNaO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRRjtBQUFBQSxRQUNSLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsUUFDbkMsVUFBVWtFO0FBQUFBLFFBQ1YsUUFBUWpFO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXdCO0FBQUEsT0ExS2hDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2S0E7QUFFUjtBQUFFdEIsR0E5bEJXRCxpQkFBZTtBQUFBLFVBQ1QzQyxXQUNFRCxhQUdNRSxpQkFPbUNJLGFBQ3BCQSxXQUFXO0FBQUE7QUFBQXdKLEtBYnhDbEg7QUFBZSxJQUFBa0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ1c2VTZWFyY2hQYXJhbXMiLCJ0b2FzdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsInVzZUNydWRJdGVtIiwiZ2V0QnlJZCIsInNlYXJjaCIsInNlYXJjaEJ5RmllbGQiLCJyZW1pdG9zTW9kdWxlQ29uZmlnIiwiZm9ybWF0UmVtaXRvT3JpZ2luSW52b2ljZSIsIkRFRkFVTFRfUkVNSVRPX1NFUklFUyIsIlJFTUlUT19TRVJJRVNfT1BUSU9OUyIsInNhbGVzSW52b2ljZXNNb2R1bGVDb25maWciLCJ0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyIsIlJlbGF0aW9uYWxJbnB1dCIsIlNlYXJjaE1vZGFsIiwiTG9hZGluZ1NwaW5uZXIiLCJmb3JtYXRWYWx1ZSIsImdldExpc3RSZXR1cm5QYXRoIiwiRU1QVFlfUkVNSVRPX0lURU0iLCJpZCIsInNhbGVzX2ludm9pY2VfaXRlbV9pZCIsImludm9pY2VfcXVhbnRpdHkiLCJwcm9kdWN0X2lkIiwicHJvZHVjdF9za3UiLCJwcm9kdWN0X25hbWUiLCJxdWFudGl0eSIsInBlbmRpbmdfdG9fZGVsaXZlciIsImRlZmF1bHRJbml0aWFsRGF0YSIsInJlbWl0b19udW1iZXIiLCJzZXJpZXMiLCJkZWxpdmVyeV9kYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzdGF0dXMiLCJzYWxlc19pbnZvaWNlX2lkIiwiY2xpZW50X2lkIiwidHJhbnNwb3J0X2lkIiwiZGVsaXZlcnlfYWRkcmVzcyIsIm9ic2VydmF0aW9ucyIsIml0ZW1zIiwiUmVtaXRvc0Zvcm1QYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsIm1vZGUiLCJzZWFyY2hQYXJhbXMiLCJpbml0aWFsSW52b2ljZUlkIiwiZ2V0IiwiaXNJbml0aWFsTG9hZGluZyIsInNldElzSW5pdGlhbExvYWRpbmciLCJpdGVtIiwibG9hZGVkRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nRGF0YSIsImVycm9yIiwic2F2ZUl0ZW0iLCJzYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0SXRlbXMiLCJsb2FkaW5nSW52b2ljZURhdGEiLCJzZXRMb2FkaW5nSW52b2ljZURhdGEiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwibW9kYWxDb25maWciLCJzZXRNb2RhbENvbmZpZyIsImVkaXRpbmdUYXJnZXQiLCJzZXRFZGl0aW5nVGFyZ2V0IiwiZmV0Y2hJbnZvaWNlUGVuZGluZ0l0ZW1zIiwiaW52b2ljZUlkIiwiZW5kcG9pbnQiLCJ1cmwiLCJhcGlSZXNwb25zZSIsImxvYWRJbnZvaWNlRGF0YSIsImluaXRpYWxJdGVtcyIsImZpbHRlciIsImkiLCJxdWFudGl0eV9wZW5kaW5nIiwibWFwIiwicXVhbnRpdHlfaW52b2ljZWQiLCJsZW5ndGgiLCJ3YXJuIiwiaW52b2ljZURldGFpbCIsInByZXYiLCJzYWxlc19pbnZvaWNlIiwiaW52b2ljZV9udW1iZXIiLCJhZmlwX3BvcyIsImNsaWVudF9uYW1lIiwidHJhbnNwb3J0IiwidHJhbnNwb3J0X2NvZGUiLCJjb2RlIiwidHJhbnNwb3J0X25hbWUiLCJuYW1lIiwibm90ZXMiLCJjb25zb2xlIiwiaHlkcmF0ZUVkaXREYXRhV2l0aFBlbmRpbmciLCJyZW1pdG8iLCJzYWZlSXRlbXMiLCJiYWNrZW5kTWFwIiwiTWFwIiwiYmkiLCJzZXQiLCJtZXJnZWRJdGVtcyIsInJlbWl0b0l0ZW0iLCJiYWNrZW5kSXRlbSIsInF0eUFjdHVhbFJlbWl0byIsInBlbmRpbmdCYWNrZW5kIiwiaHlkcmF0ZWREYXRhIiwiY2xpZW50IiwiU3RyaW5nIiwiZXJyIiwiZmFsbGJhY2tJdGVtcyIsImlkVG9Mb2FkIiwiTnVtYmVyIiwiaXNOYU4iLCJhcHBseUhlYWRlclNlbGVjdGlvbiIsImZpZWxkIiwic2VsZWN0ZWRJdGVtIiwiaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCIsImNvZGVWYWx1ZSIsInJlbGF0aW9uYWxGaWVsZHMiLCJmaWVsZE5hbWUiLCJjb2RlRmllbGQiLCJ2YWx1ZSIsInN1Y2Nlc3MiLCJuYW1lRmllbGQiLCJoYW5kbGVJbnZvaWNlQ29kZVN1Ym1pdCIsInJlc3VsdCIsImhhbmRsZVNlbGVjdEludm9pY2UiLCJoYW5kbGVTZWxlY3RNb2RhbCIsImhhbmRsZUdlbmVyaWNDaGFuZ2UiLCJlIiwidGFyZ2V0IiwiaGFuZGxlQ2xlYXJUcmFuc3BvcnQiLCJ1bmRlZmluZWQiLCJoYW5kbGVTYXZlIiwiZXZlcnkiLCJjbGVhbkl0ZW1zIiwiX2ludiIsIl9wZW4iLCJyZXN0IiwiX2NOYW1lIiwiY2xpZW50X2NvZGUiLCJfY0NvZGUiLCJfdE5hbWUiLCJfdENvZGUiLCJfaW52TnVtIiwiaGVhZGVyUGF5bG9hZCIsImRhdGFUb1NlbmQiLCJiYXNlUm91dGUiLCJhcGlFcnJvciIsIm1lc3NhZ2UiLCJuZXdDb2RlIiwib3B0IiwibGFiZWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZW1pdG9zRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFycyAqL1xuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgRmFTYXZlLCBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaCwgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuXG4vLyBNw7NkdWxvcyBkZWwgUmVtaXRvXG5pbXBvcnQge1xuICAgIHJlbWl0b3NNb2R1bGVDb25maWcsXG4gICAgZm9ybWF0UmVtaXRvT3JpZ2luSW52b2ljZSxcbiAgICBERUZBVUxUX1JFTUlUT19TRVJJRVMsXG4gICAgUkVNSVRPX1NFUklFU19PUFRJT05TLFxuICAgIHR5cGUgUmVtaXRvLFxuICAgIHR5cGUgUmVtaXRvSXRlbSxcbn0gZnJvbSAnLi4vcmVtaXRvcy5jb25maWcnO1xuLy8gRmFjdHVyYXMgKE9yaWdlbilcbmltcG9ydCB7IHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcsIHR5cGUgU2FsZXNJbnZvaWNlIH0gZnJvbSAnLi4vLi4vZmFjdHVyYXNfdmVudGEvZmFjdHVyYXNfdmVudGEuY29uZmlnJztcbi8vIENsaWVudGVzIHkgVHJhbnNwb3J0ZVxuaW1wb3J0IHsgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi90cmFuc3BvcnRlcy90cmFuc3BvcnRlcy5jb25maWcnO1xuXG5cblxuLy8gQ29tcG9uZW50ZXMgY29tdW5lc1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IFNlYXJjaE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLy8gLS0tIE5VRVZBUyBJTlRFUkZBQ0VTIERFTCBCQUNLRU5EIChQQVJBIE1BUEVPKSAtLS1cblxuaW50ZXJmYWNlIFNpbXBsZVRyYW5zcG9ydCB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBjb2RlOiBzdHJpbmc7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIFtrZXk6IHN0cmluZ106IGFueTtcbn1cblxuaW50ZXJmYWNlIFNpbXBsZVNhbGVzSW52b2ljZSB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBpbnZvaWNlX251bWJlcjogc3RyaW5nO1xuICAgIFtrZXk6IHN0cmluZ106IGFueTtcbn1cblxuaW50ZXJmYWNlIFNhbGVzSW52b2ljZVJlbWl0b0l0ZW0ge1xuICAgIHNhbGVzX2ludm9pY2VfaXRlbV9pZDogbnVtYmVyO1xuICAgIHByb2R1Y3RfaWQ6IG51bWJlcjtcbiAgICBwcm9kdWN0X3NrdTogc3RyaW5nO1xuICAgIHByb2R1Y3RfbmFtZTogc3RyaW5nO1xuICAgIHF1YW50aXR5X2ludm9pY2VkOiBudW1iZXI7XG4gICAgcXVhbnRpdHlfZGVsaXZlcmVkOiBudW1iZXI7XG4gICAgcXVhbnRpdHlfcGVuZGluZzogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgU2FsZXNJbnZvaWNlUmVtaXRvIHtcbiAgICBjbGllbnRfaWQ6IG51bWJlcjtcbiAgICBjbGllbnRfbmFtZTogc3RyaW5nO1xuICAgIHRyYW5zcG9ydF9pZDogbnVtYmVyO1xuICAgIC8vIOKchSBBQ1RVQUxJWkFETzogRWwgb2JqZXRvIHRyYW5zcG9ydCBjb21wbGV0b1xuICAgIHRyYW5zcG9ydD86IFNpbXBsZVRyYW5zcG9ydDtcbiAgICBzYWxlc19pbnZvaWNlPzogU2ltcGxlU2FsZXNJbnZvaWNlO1xuICAgIGRlbGl2ZXJ5X2FkZHJlc3M6IHN0cmluZztcbiAgICBpbnZvaWNlX251bWJlcjogc3RyaW5nO1xuICAgIG5vdGVzOiBzdHJpbmcgfCBudWxsO1xuICAgIGl0ZW1zOiBTYWxlc0ludm9pY2VSZW1pdG9JdGVtW107XG59XG5cbi8vIC0tLSBUSVBPUyBZIERBVE9TIELDgVNJQ09TIC0tLVxuXG50eXBlIEVkaXRpbmdUYXJnZXQgPSAnc2FsZXNfaW52b2ljZScgfCAndHJhbnNwb3J0JztcbnR5cGUgSGVhZGVyRmllbGQgPSAndHJhbnNwb3J0JzsgLy8gVXNhbW9zIGVzdGUgdGlwbyBwYXJhIGVsIGhhbmRsZXIgZGUgY8OzZGlnb1xuXG5jb25zdCBFTVBUWV9SRU1JVE9fSVRFTTogUmVtaXRvSXRlbSA9IHtcbiAgICBpZDogMCxcbiAgICBzYWxlc19pbnZvaWNlX2l0ZW1faWQ6IDAsXG4gICAgaW52b2ljZV9xdWFudGl0eTogMCxcbiAgICBwcm9kdWN0X2lkOiAwLFxuICAgIHByb2R1Y3Rfc2t1OiAnJyxcbiAgICBwcm9kdWN0X25hbWU6ICcnLFxuICAgIHF1YW50aXR5OiAwLFxuICAgIHBlbmRpbmdfdG9fZGVsaXZlcjogMCxcbn07XG5cbmNvbnN0IGRlZmF1bHRJbml0aWFsRGF0YTogUGFydGlhbDxSZW1pdG8+ID0ge1xuICAgIGlkOiAwLFxuICAgIHJlbWl0b19udW1iZXI6ICcnLFxuICAgIHNlcmllczogREVGQVVMVF9SRU1JVE9fU0VSSUVTLFxuICAgIGRlbGl2ZXJ5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgIHN0YXR1czogJ0RyYWZ0JyxcbiAgICBzYWxlc19pbnZvaWNlX2lkOiBudWxsLFxuICAgIGNsaWVudF9pZDogbnVsbCxcbiAgICB0cmFuc3BvcnRfaWQ6IG51bGwsXG4gICAgZGVsaXZlcnlfYWRkcmVzczogbnVsbCxcbiAgICBvYnNlcnZhdGlvbnM6IG51bGwsXG4gICAgaXRlbXM6IFtdLFxufTtcblxuLy8gLS0tIENPTVBPTkVOVEUgUFJJTkNJUEFMIC0tLVxuXG5leHBvcnQgY29uc3QgUmVtaXRvc0Zvcm1QYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICAgIGNvbnN0IGluaXRpYWxJbnZvaWNlSWQgPSBzZWFyY2hQYXJhbXMuZ2V0KCdpbnZvaWNlSWQnKTtcblxuICAgIGNvbnN0IFtpc0luaXRpYWxMb2FkaW5nLCBzZXRJc0luaXRpYWxMb2FkaW5nXSA9IHVzZVN0YXRlKFxuICAgICAgICBtb2RlID09PSAnZWRpdCcgfHwgKG1vZGUgPT09ICdjcmVhdGUnICYmICEhaW5pdGlhbEludm9pY2VJZClcbiAgICApO1xuXG4gICAgY29uc3QgeyBpdGVtOiBsb2FkZWREYXRhLCBsb2FkaW5nOiBsb2FkaW5nRGF0YSwgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFJlbWl0bz4ocmVtaXRvc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IHsgc2F2ZUl0ZW0sIGxvYWRpbmc6IHNhdmluZyB9ID0gdXNlQ3J1ZEl0ZW08UmVtaXRvPihyZW1pdG9zTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPFBhcnRpYWw8UmVtaXRvPj4oZGVmYXVsdEluaXRpYWxEYXRhKTtcbiAgICBjb25zdCBbaXRlbXMsIHNldEl0ZW1zXSA9IHVzZVN0YXRlPFJlbWl0b0l0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nSW52b2ljZURhdGEsIHNldExvYWRpbmdJbnZvaWNlRGF0YV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBFc3RhZG9zIGRlIE1vZGFsZXNcbiAgICBjb25zdCBbaXNNb2RhbE9wZW4sIHNldElzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbW9kYWxDb25maWcsIHNldE1vZGFsQ29uZmlnXSA9IHVzZVN0YXRlPE1vZHVsZUNvbmZpZzxhbnk+IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2VkaXRpbmdUYXJnZXQsIHNldEVkaXRpbmdUYXJnZXRdID0gdXNlU3RhdGU8RWRpdGluZ1RhcmdldCB8IG51bGw+KG51bGwpO1xuXG4gICAgLy8g8J+UtCBOVUVWTzogY2FjaGUgZGUgaXRlbXMgcGVuZGllbnRlcyBwb3IgaW52b2ljZSBwYXJhIHJldXRpbGl6YXIgZW4gY3JlYXRlIC8gZWRpdFxuICAgIGNvbnN0IGZldGNoSW52b2ljZVBlbmRpbmdJdGVtcyA9IHVzZUNhbGxiYWNrKFxuICAgICAgICBhc3luYyAoaW52b2ljZUlkOiBudW1iZXIpOiBQcm9taXNlPFNhbGVzSW52b2ljZVJlbWl0bz4gPT4ge1xuICAgICAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBgJHtzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmVuZHBvaW50fS8ke2ludm9pY2VJZH0vcGVuZGluZy1pdGVtc2A7XG4gICAgICAgICAgICBjb25zdCB1cmwgPSBgJHtlbmRwb2ludH1gO1xuICAgICAgICAgICAgY29uc3QgYXBpUmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8U2FsZXNJbnZvaWNlUmVtaXRvPih1cmwpIGFzIHVua25vd24gYXMgU2FsZXNJbnZvaWNlUmVtaXRvO1xuICAgICAgICAgICAgcmV0dXJuIGFwaVJlc3BvbnNlO1xuICAgICAgICB9LFxuICAgICAgICBbXVxuICAgICk7XG5cbiAgICAvLyAtLS0gTMOTR0lDQSBERSBDQVJHQSBERSBGQUNUVVJBIEVOIENSRUFURSAtLS1cblxuICAgIGNvbnN0IGxvYWRJbnZvaWNlRGF0YSA9IHVzZUNhbGxiYWNrKGFzeW5jIChpbnZvaWNlSWQ6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBhcGlSZXNwb25zZSA9IGF3YWl0IGZldGNoSW52b2ljZVBlbmRpbmdJdGVtcyhpbnZvaWNlSWQpO1xuXG4gICAgICAgICAgICBjb25zdCBpbml0aWFsSXRlbXM6IFJlbWl0b0l0ZW1bXSA9IGFwaVJlc3BvbnNlLml0ZW1zXG4gICAgICAgICAgICAgICAgLmZpbHRlcihpID0+IGkucXVhbnRpdHlfcGVuZGluZyA+IDApXG4gICAgICAgICAgICAgICAgLm1hcCgoaTogU2FsZXNJbnZvaWNlUmVtaXRvSXRlbSk6IFJlbWl0b0l0ZW0gPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nX3RvX2RlbGl2ZXIgPSBpLnF1YW50aXR5X3BlbmRpbmc7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5FTVBUWV9SRU1JVE9fSVRFTSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhbGVzX2ludm9pY2VfaXRlbV9pZDogaS5zYWxlc19pbnZvaWNlX2l0ZW1faWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2lkOiBpLnByb2R1Y3RfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X3NrdTogaS5wcm9kdWN0X3NrdSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogaS5wcm9kdWN0X25hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnZvaWNlX3F1YW50aXR5OiBpLnF1YW50aXR5X2ludm9pY2VkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ190b19kZWxpdmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVhbnRpdHk6IHBlbmRpbmdfdG9fZGVsaXZlcixcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKGluaXRpYWxJdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICB0b2FzdC53YXJuKCdMYSBmYWN0dXJhIHNlbGVjY2lvbmFkYSB5YSBmdWUgcmVtaXRpZGEgY29tcGxldGFtZW50ZS4nKTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShkZWZhdWx0SW5pdGlhbERhdGEpO1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKFtdKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IGludm9pY2VEZXRhaWwgPSBhd2FpdCBnZXRCeUlkPFNhbGVzSW52b2ljZT4oc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgaW52b2ljZUlkKTtcblxuICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXY6IFBhcnRpYWw8UmVtaXRvPikgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIHNhbGVzX2ludm9pY2VfaWQ6IGludm9pY2VJZCB8fCBhcGlSZXNwb25zZS5zYWxlc19pbnZvaWNlPy5pZCxcbiAgICAgICAgICAgICAgICBpbnZvaWNlX251bWJlcjogYXBpUmVzcG9uc2UuaW52b2ljZV9udW1iZXIsXG4gICAgICAgICAgICAgICAgc2FsZXNfaW52b2ljZToge1xuICAgICAgICAgICAgICAgICAgICBpZDogaW52b2ljZUlkLFxuICAgICAgICAgICAgICAgICAgICBpbnZvaWNlX251bWJlcjogaW52b2ljZURldGFpbC5pbnZvaWNlX251bWJlcixcbiAgICAgICAgICAgICAgICAgICAgc2VyaWVzOiBpbnZvaWNlRGV0YWlsLnNlcmllcyxcbiAgICAgICAgICAgICAgICAgICAgYWZpcF9wb3M6IGludm9pY2VEZXRhaWwuYWZpcF9wb3MsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IGFwaVJlc3BvbnNlLmNsaWVudF9pZCxcbiAgICAgICAgICAgICAgICBjbGllbnRfbmFtZTogYXBpUmVzcG9uc2UuY2xpZW50X25hbWUsXG4gICAgICAgICAgICAgICAgdHJhbnNwb3J0X2lkOiBhcGlSZXNwb25zZS50cmFuc3BvcnQ/LmlkIHx8IGFwaVJlc3BvbnNlLnRyYW5zcG9ydF9pZCB8fCBudWxsLFxuICAgICAgICAgICAgICAgIHRyYW5zcG9ydF9jb2RlOiBhcGlSZXNwb25zZS50cmFuc3BvcnQ/LmNvZGUgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICB0cmFuc3BvcnRfbmFtZTogYXBpUmVzcG9uc2UudHJhbnNwb3J0Py5uYW1lIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgZGVsaXZlcnlfYWRkcmVzczogYXBpUmVzcG9uc2UuZGVsaXZlcnlfYWRkcmVzcyxcbiAgICAgICAgICAgICAgICBvYnNlcnZhdGlvbnM6IGFwaVJlc3BvbnNlLm5vdGVzLFxuICAgICAgICAgICAgICAgIGl0ZW1zOiBpbml0aWFsSXRlbXMsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhpbml0aWFsSXRlbXMpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBsYSBmYWN0dXJhIG8gc3VzIHBlbmRpZW50ZXMuJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhbXSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEoZmFsc2UpO1xuICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbZmV0Y2hJbnZvaWNlUGVuZGluZ0l0ZW1zXSk7XG5cbiAgICAvLyDwn5S0IE5VRVZPOiBMw5NHSUNBIERFIENBUkdBIERFIFBFTkRJRU5URVMgRU4gTU9ETyBFRElDScOTTlxuICAgIGNvbnN0IGh5ZHJhdGVFZGl0RGF0YVdpdGhQZW5kaW5nID0gdXNlQ2FsbGJhY2soXG4gICAgICAgIGFzeW5jIChyZW1pdG86IFJlbWl0bykgPT4ge1xuICAgICAgICAgICAgLy8gTmVjZXNpdGFtb3Mgc2FsZXNfaW52b2ljZV9pZCBwYXJhIHBvZGVyIHByZWd1bnRhciBhbCBiYWNrZW5kXG4gICAgICAgICAgICBpZiAoIXJlbWl0by5zYWxlc19pbnZvaWNlX2lkKSB7XG4gICAgICAgICAgICAgICAgLy8gQ2FzbyByYXJvLCBwZXJvIG1lam9yIG5vIHJvbXBlclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignUmVtaXRvIHNpbiBzYWxlc19pbnZvaWNlX2lkOyBubyBzZSBwdWVkZW4gY2FsY3VsYXIgcGVuZGllbnRlcyBkZXNkZSBiYWNrZW5kLicpO1xuICAgICAgICAgICAgICAgIC8vIEVuIGVzdGUgY2FzbywgcGVybWl0aW1vcyBzw7NsbyBlZGl0YXIgbG8gcXVlIHlhIHRpZW5lXG4gICAgICAgICAgICAgICAgY29uc3Qgc2FmZUl0ZW1zID0gcmVtaXRvLml0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuZGluZ190b19kZWxpdmVyID0gaXRlbS5xdWFudGl0eSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VfcXVhbnRpdHk6IGl0ZW0uaW52b2ljZV9xdWFudGl0eSA/PyAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ190b19kZWxpdmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVhbnRpdHk6IHBlbmRpbmdfdG9fZGVsaXZlcixcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBzZXRJdGVtcyhzYWZlSXRlbXMpO1xuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHJlbWl0byk7XG4gICAgICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEodHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFwaVJlc3BvbnNlID0gYXdhaXQgZmV0Y2hJbnZvaWNlUGVuZGluZ0l0ZW1zKHJlbWl0by5zYWxlc19pbnZvaWNlX2lkKTtcblxuICAgICAgICAgICAgICAgIC8vIMONbmRpY2UgcG9yIHNhbGVzX2ludm9pY2VfaXRlbV9pZFxuICAgICAgICAgICAgICAgIGNvbnN0IGJhY2tlbmRNYXAgPSBuZXcgTWFwPG51bWJlciwgU2FsZXNJbnZvaWNlUmVtaXRvSXRlbT4oKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGJpIG9mIGFwaVJlc3BvbnNlLml0ZW1zKSB7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tlbmRNYXAuc2V0KGJpLnNhbGVzX2ludm9pY2VfaXRlbV9pZCwgYmkpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IG1lcmdlZEl0ZW1zOiBSZW1pdG9JdGVtW10gPSByZW1pdG8uaXRlbXMubWFwKHJlbWl0b0l0ZW0gPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBiYWNrZW5kSXRlbSA9IGJhY2tlbmRNYXAuZ2V0KHJlbWl0b0l0ZW0uc2FsZXNfaW52b2ljZV9pdGVtX2lkKTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAoIWJhY2tlbmRJdGVtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nX3RvX2RlbGl2ZXIgPSByZW1pdG9JdGVtLnF1YW50aXR5IHx8IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnJlbWl0b0l0ZW0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW52b2ljZV9xdWFudGl0eTogcmVtaXRvSXRlbS5pbnZvaWNlX3F1YW50aXR5ID8/IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ190b19kZWxpdmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1YW50aXR5OiBwZW5kaW5nX3RvX2RlbGl2ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcXR5QWN0dWFsUmVtaXRvID0gcmVtaXRvSXRlbS5xdWFudGl0eSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nQmFja2VuZCA9IGJhY2tlbmRJdGVtLnF1YW50aXR5X3BlbmRpbmcgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuZGluZ190b19kZWxpdmVyID0gcXR5QWN0dWFsUmVtaXRvICsgcGVuZGluZ0JhY2tlbmQ7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnJlbWl0b0l0ZW0sXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnZvaWNlX3F1YW50aXR5OiBiYWNrZW5kSXRlbS5xdWFudGl0eV9pbnZvaWNlZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdfdG9fZGVsaXZlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1YW50aXR5OiBwZW5kaW5nX3RvX2RlbGl2ZXIsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAvLyBBY3R1YWxpemFtb3MgdGFtYmnDqW4gbG9zIGNhbXBvcyBkZSBjYWJlY2VyYSBkZXJpdmFkb3MgZGUgbGEgZmFjdHVyYVxuICAgICAgICAgICAgICAgIGNvbnN0IGh5ZHJhdGVkRGF0YTogUmVtaXRvID0ge1xuICAgICAgICAgICAgICAgICAgICAuLi5kZWZhdWx0SW5pdGlhbERhdGEgYXMgUmVtaXRvLFxuICAgICAgICAgICAgICAgICAgICAuLi5yZW1pdG8sXG4gICAgICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiByZW1pdG8uY2xpZW50Py5uYW1lID8/IHJlbWl0by5jbGllbnRfbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgaW52b2ljZV9udW1iZXI6XG4gICAgICAgICAgICAgICAgICAgICAgICByZW1pdG8uc2FsZXNfaW52b2ljZT8uaW52b2ljZV9udW1iZXIgIT0gbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gU3RyaW5nKHJlbWl0by5zYWxlc19pbnZvaWNlLmludm9pY2VfbnVtYmVyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVtaXRvLmludm9pY2VfbnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICBzYWxlc19pbnZvaWNlOiByZW1pdG8uc2FsZXNfaW52b2ljZVxuICAgICAgICAgICAgICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHJlbWl0by5zYWxlc19pbnZvaWNlLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VfbnVtYmVyOiByZW1pdG8uc2FsZXNfaW52b2ljZS5pbnZvaWNlX251bWJlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJpZXM6IHJlbWl0by5zYWxlc19pbnZvaWNlLnNlcmllcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZmlwX3BvczogcmVtaXRvLnNhbGVzX2ludm9pY2UuYWZpcF9wb3MsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHJlbWl0by5zYWxlc19pbnZvaWNlX2lkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogcmVtaXRvLnNhbGVzX2ludm9pY2VfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VfbnVtYmVyOiByZW1pdG8uaW52b2ljZV9udW1iZXIgPz8gJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzX2ludm9pY2VfaWQ6IHJlbWl0by5zYWxlc19pbnZvaWNlPy5pZCA/PyByZW1pdG8uc2FsZXNfaW52b2ljZV9pZCA/PyAwLFxuICAgICAgICAgICAgICAgICAgICB0cmFuc3BvcnRfY29kZTogcmVtaXRvLnRyYW5zcG9ydF9jb2RlIHx8IHJlbWl0by50cmFuc3BvcnQ/LmNvZGUgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0X25hbWU6IHJlbWl0by50cmFuc3BvcnRfbmFtZSB8fCByZW1pdG8udHJhbnNwb3J0Py5uYW1lIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBtZXJnZWRJdGVtcyxcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoaHlkcmF0ZWREYXRhKTtcbiAgICAgICAgICAgICAgICBzZXRJdGVtcyhtZXJnZWRJdGVtcyk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBvYnRlbmVyIHBlbmRpZW50ZXMgZW4gZWRpY2nDs246JywgZXJyKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgb2J0ZW5lciBwZW5kaWVudGVzIGRlIGxhIGZhY3R1cmEgcGFyYSBlc3RlIHJlbWl0by4nKTtcbiAgICAgICAgICAgICAgICAvLyBGYWxsYmFjazogYWwgbWVub3MgY2FyZ2Ftb3MgbG8gcXVlIHRyYWUgZWwgcmVtaXRvIHNpbiB0b3F1ZXRlYXIgbG9zIGzDrW1pdGVzXG4gICAgICAgICAgICAgICAgY29uc3QgZmFsbGJhY2tJdGVtczogUmVtaXRvSXRlbVtdID0gcmVtaXRvLml0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuZGluZ190b19kZWxpdmVyID0gaXRlbS5xdWFudGl0eSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VfcXVhbnRpdHk6IGl0ZW0uaW52b2ljZV9xdWFudGl0eSA/PyAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ190b19kZWxpdmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVhbnRpdHk6IHBlbmRpbmdfdG9fZGVsaXZlcixcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShyZW1pdG8pO1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKGZhbGxiYWNrSXRlbXMpO1xuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHNldElzSW5pdGlhbExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbZmV0Y2hJbnZvaWNlUGVuZGluZ0l0ZW1zXVxuICAgICk7XG5cbiAgICAvLyBFZmVjdG8gMTogQ2FyZ2EgaW5pY2lhbCBiYXNhZGEgZW4gUXVlcnkgUGFyYW1ldGVyIChzb2xvIGVuIG1vZG8gJ2NyZWF0ZScpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1vZGUgPT09ICdjcmVhdGUnICYmIGluaXRpYWxJbnZvaWNlSWQgJiYgIWZvcm1EYXRhLnNhbGVzX2ludm9pY2VfaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGlkVG9Mb2FkID0gTnVtYmVyKGluaXRpYWxJbnZvaWNlSWQpO1xuICAgICAgICAgICAgaWYgKCFpc05hTihpZFRvTG9hZCkgJiYgaWRUb0xvYWQgPiAwKSB7XG4gICAgICAgICAgICAgICAgbG9hZEludm9pY2VEYXRhKGlkVG9Mb2FkKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbbW9kZSwgaW5pdGlhbEludm9pY2VJZCwgbG9hZEludm9pY2VEYXRhLCBmb3JtRGF0YS5zYWxlc19pbnZvaWNlX2lkXSk7XG5cbiAgICAvLyBFZmVjdG8gMjogQ2FyZ2EgZW4gbW9kbyAnZWRpdCcgeSBjb250cm9sIGRlIGVzdGFkbyBwb3IgZGVmZWN0b1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChtb2RlID09PSAnZWRpdCcgJiYgbG9hZGVkRGF0YSkge1xuICAgICAgICAgICAgLy8gQXF1w60gZGVsZWdhbW9zIGFsIGhlbHBlciBxdWUgYWRlbcOhcyBwaWRlIHBlbmRpZW50ZXMgYWwgYmFja2VuZFxuICAgICAgICAgICAgaHlkcmF0ZUVkaXREYXRhV2l0aFBlbmRpbmcobG9hZGVkRGF0YSBhcyBSZW1pdG8pO1xuICAgICAgICB9IGVsc2UgaWYgKG1vZGUgPT09ICdjcmVhdGUnKSB7XG4gICAgICAgICAgICBpZiAoIWluaXRpYWxJbnZvaWNlSWQgJiYgaXNJbml0aWFsTG9hZGluZykge1xuICAgICAgICAgICAgICAgIHNldElzSW5pdGlhbExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICghaW5pdGlhbEludm9pY2VJZCAmJiAhZm9ybURhdGEuc2FsZXNfaW52b2ljZV9pZCkge1xuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW21vZGUsIGxvYWRlZERhdGEsIGlzSW5pdGlhbExvYWRpbmcsIGluaXRpYWxJbnZvaWNlSWQsIGh5ZHJhdGVFZGl0RGF0YVdpdGhQZW5kaW5nXSk7XG5cbiAgICAvLyAtLS0gTUFORUpBRE9SRVMgLS0tXG5cbiAgICBjb25zdCBhcHBseUhlYWRlclNlbGVjdGlvbiA9IChmaWVsZDogSGVhZGVyRmllbGQsIHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG4gICAgICAgIGlmIChmaWVsZCAhPT0gJ3RyYW5zcG9ydCcpIHJldHVybjtcblxuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgdHJhbnNwb3J0X2lkOiBzZWxlY3RlZEl0ZW0/LmlkIHx8IG51bGwsXG4gICAgICAgICAgICB0cmFuc3BvcnRfY29kZTogc2VsZWN0ZWRJdGVtPy5jb2RlIHx8IG51bGwsXG4gICAgICAgICAgICB0cmFuc3BvcnRfbmFtZTogc2VsZWN0ZWRJdGVtPy5uYW1lIHx8IG51bGwsXG4gICAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCA9IGFzeW5jIChmaWVsZDogSGVhZGVyRmllbGQpID0+IHtcbiAgICAgICAgaWYgKGZpZWxkICE9PSAndHJhbnNwb3J0JykgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IGNvZGVWYWx1ZSA9IGZvcm1EYXRhLnRyYW5zcG9ydF9jb2RlO1xuICAgICAgICBpZiAoIWNvZGVWYWx1ZSkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHsgZW5kcG9pbnQsIHJlbGF0aW9uYWxGaWVsZHMgfSA9IHRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnO1xuICAgICAgICBpZiAoIXJlbGF0aW9uYWxGaWVsZHMpIHJldHVybiB0b2FzdC5lcnJvcihgQ29uZmlndXJhY2nDs24gcmVsYWNpb25hbCBmYWx0YW50ZSBwYXJhICR7ZmllbGR9YCk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogcmVsYXRpb25hbEZpZWxkcy5jb2RlRmllbGQgYXMgc3RyaW5nLCB2YWx1ZTogY29kZVZhbHVlIH1dKTtcbiAgICAgICAgICAgIGlmIChpdGVtKSB7XG4gICAgICAgICAgICAgICAgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZmllbGQsIGl0ZW0pO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCcke2l0ZW1bcmVsYXRpb25hbEZpZWxkcy5uYW1lRmllbGQgYXMgc3RyaW5nXX0nIHNlbGVjY2lvbmFkby5gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyB0cmFuc3BvcnRlIGNvbiBlbCBjw7NkaWdvIFwiJHtjb2RlVmFsdWV9XCIuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGJ1c2NhciBwb3IgY8OzZGlnbzpcIiwgZXJyKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRXJyb3IgYWwgYnVzY2FyIHRyYW5zcG9ydGUgcG9yIGPDs2RpZ28uXCIpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUludm9pY2VDb2RlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb2RlVmFsdWUgPSBmb3JtRGF0YS5pbnZvaWNlX251bWJlcjtcbiAgICAgICAgaWYgKCFjb2RlVmFsdWUpIHJldHVybjtcblxuICAgICAgICBzZXRJc0luaXRpYWxMb2FkaW5nKHRydWUpO1xuICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEodHJ1ZSk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8U2FsZXNJbnZvaWNlPihcbiAgICAgICAgICAgICAgICBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ2ludm9pY2VfbnVtYmVyJywgdmFsdWU6IGNvZGVWYWx1ZSB9XVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIC8vIFJldXRpbGl6YW1vcyBsYSBtaXNtYSBsw7NnaWNhIHF1ZSBjdWFuZG8gc2Ugc2VsZWNjaW9uYSBkZXNkZSBlbCBtb2RhbFxuICAgICAgICAgICAgICAgIGF3YWl0IGxvYWRJbnZvaWNlRGF0YShyZXN1bHQuaWQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihgTm8gc2UgZW5jb250csOzIG5pbmd1bmEgZmFjdHVyYSBjb24gZWwgbsO6bWVybyBcIiR7Y29kZVZhbHVlfVwiLmApO1xuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGJ1c2NhciBsYSBmYWN0dXJhIHBvciBuw7ptZXJvLlwiKTtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhbXSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nSW52b2ljZURhdGEoZmFsc2UpO1xuICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0SW52b2ljZSA9IChzZWxlY3RlZEl0ZW06IFNhbGVzSW52b2ljZSkgPT4ge1xuICAgICAgICBzZXRJc0luaXRpYWxMb2FkaW5nKHRydWUpO1xuICAgICAgICBsb2FkSW52b2ljZURhdGEoc2VsZWN0ZWRJdGVtLmlkKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0TW9kYWwgPSAoc2VsZWN0ZWRJdGVtOiBhbnkpID0+IHtcbiAgICAgICAgaWYgKCFlZGl0aW5nVGFyZ2V0KSByZXR1cm47XG5cbiAgICAgICAgaWYgKGVkaXRpbmdUYXJnZXQgPT09ICdzYWxlc19pbnZvaWNlJykge1xuICAgICAgICAgICAgaGFuZGxlU2VsZWN0SW52b2ljZShzZWxlY3RlZEl0ZW0gYXMgU2FsZXNJbnZvaWNlKTtcbiAgICAgICAgfSBlbHNlIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAndHJhbnNwb3J0Jykge1xuICAgICAgICAgICAgYXBwbHlIZWFkZXJTZWxlY3Rpb24oJ3RyYW5zcG9ydCcsIHNlbGVjdGVkSXRlbSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVHZW5lcmljQ2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MU2VsZWN0RWxlbWVudCB8IEhUTUxUZXh0QXJlYUVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xuICAgICAgICBzZXRGb3JtRGF0YSgocHJldjogUGFydGlhbDxSZW1pdG8+KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQ2xlYXJUcmFuc3BvcnQgPSAoKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICB0cmFuc3BvcnRfaWQ6IG51bGwsXG4gICAgICAgICAgICB0cmFuc3BvcnRfY29kZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgdHJhbnNwb3J0X25hbWU6IHVuZGVmaW5lZCxcbiAgICAgICAgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWZvcm1EYXRhLnNhbGVzX2ludm9pY2VfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRGViZSBzZWxlY2Npb25hciB1bmEgZmFjdHVyYSBkZSBvcmlnZW4uXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRWwgcmVtaXRvIG5vIHRpZW5lIHByb2R1Y3Rvcy5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGl0ZW1zLmV2ZXJ5KGl0ZW0gPT4gKGl0ZW0ucXVhbnRpdHkgfHwgMCkgPT09IDApKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkFsIG1lbm9zIHVuIHByb2R1Y3RvIGRlYmUgdGVuZXIgdW5hIGNhbnRpZGFkIG1heW9yIGEgY2Vyby5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5kZWxpdmVyeV9kYXRlKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkRlYmUgZXNwZWNpZmljYXIgdW5hIEZlY2hhIGRlIEVudHJlZ2EuXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZm9ybURhdGEuZGVsaXZlcnlfYWRkcmVzcykge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJEZWJlIGVzcGVjaWZpY2FyIHVuYSBEaXJlY2Npw7NuIGRlIEVudHJlZ2EuXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgY2xlYW5JdGVtcyA9IGl0ZW1zXG4gICAgICAgICAgICAuZmlsdGVyKGl0ZW0gPT4gKGl0ZW0ucXVhbnRpdHkgfHwgMCkgPiAwKVxuICAgICAgICAgICAgLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGludm9pY2VfcXVhbnRpdHk6IF9pbnYsIHBlbmRpbmdfdG9fZGVsaXZlcjogX3BlbiwgLi4ucmVzdCB9ID0gaXRlbTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdDtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGNsaWVudF9uYW1lOiBfY05hbWUsIGNsaWVudF9jb2RlOiBfY0NvZGUsXG4gICAgICAgICAgICB0cmFuc3BvcnRfbmFtZTogX3ROYW1lLCB0cmFuc3BvcnRfY29kZTogX3RDb2RlLFxuICAgICAgICAgICAgaW52b2ljZV9udW1iZXI6IF9pbnZOdW0sXG4gICAgICAgICAgICAuLi5oZWFkZXJQYXlsb2FkXG4gICAgICAgIH0gPSBmb3JtRGF0YTtcblxuICAgICAgICBjb25zdCBkYXRhVG9TZW5kOiBQYXJ0aWFsPFJlbWl0bz4gPSB7XG4gICAgICAgICAgICAuLi5oZWFkZXJQYXlsb2FkLFxuICAgICAgICAgICAgaXRlbXM6IGNsZWFuSXRlbXMgYXMgYW55LFxuICAgICAgICB9O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBzYXZlSXRlbShkYXRhVG9TZW5kIGFzIFJlbWl0byk7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBSZW1pdG8gJHttb2RlID09PSAnY3JlYXRlJyA/ICdjcmVhZG8nIDogJ2FjdHVhbGl6YWRvJ30gY29uIMOpeGl0by5gKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHJlbWl0b3NNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH0gY2F0Y2ggKGFwaUVycm9yOiBhbnkpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKGBFcnJvciBhbCBndWFyZGFyOiAke2FwaUVycm9yLm1lc3NhZ2UgfHwgJ0Vycm9yIGRlc2Nvbm9jaWRvJ31gKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBDb25kaWNpw7NuIGRlIHJlbmRlcml6YWRvIGRlbCBzZWxlY3RvciBkZSBmYWN0dXJhXG4gICAgaWYgKG1vZGUgPT09ICdjcmVhdGUnICYmICFmb3JtRGF0YS5zYWxlc19pbnZvaWNlX2lkICYmICFsb2FkaW5nSW52b2ljZURhdGEgJiYgIWlzSW5pdGlhbExvYWRpbmcpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cteGwgbWF4LXctbGcgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgbWItNFwiPlBhc28gMTogU2VsZWNjaW9uYXIgRmFjdHVyYSBkZSBPcmlnZW48L2gyPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG1iLTZcIj5Ub2RvIHJlbWl0byBkZWJlIHBhcnRpciBkZSB1bmEgRmFjdHVyYSBkZSBWZW50YSBleGlzdGVudGUuPC9wPlxuICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLmludm9pY2VfbnVtYmVyIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5pbnZvaWNlX251bWJlciB8fCAnQnVzY2FyIEZhY3R1cmEuLi4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVHZW5lcmljQ2hhbmdlKHsgdGFyZ2V0OiB7IG5hbWU6ICdpbnZvaWNlX251bWJlcicsIHZhbHVlOiBuZXdDb2RlIH0gfSBhcyBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PilcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17aGFuZGxlSW52b2ljZUNvZGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1RhcmdldCgnc2FsZXNfaW52b2ljZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vZGFsQ29uZmlnKHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogTW9kYWwgcGFyYSBiw7pzcXVlZGEgZGUgZmFjdHVyYSAqL31cbiAgICAgICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8U2VhcmNoTW9kYWxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17aGFuZGxlU2VsZWN0TW9kYWx9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25maWc9e21vZGFsQ29uZmlnfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDb25kaWNpw7NuIGRlIGNhcmdhIHkgZXJyb3JcbiAgICBpZiAobG9hZGluZ0RhdGEgfHwgbG9hZGluZ0ludm9pY2VEYXRhIHx8IChtb2RlID09PSAnY3JlYXRlJyAmJiBpc0luaXRpYWxMb2FkaW5nKSkge1xuICAgICAgICByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIH1cbiAgICBpZiAoZXJyb3IgJiYgbW9kZSA9PT0gJ2VkaXQnKSB7XG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBkYXRvczoge2Vycm9yfTwvZGl2PjtcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02XCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZSdcbiAgICAgICAgICAgICAgICAgICAgPyBgQ3JlYXIgUmVtaXRvIHBhcmEgRmFjdHVyYSAke2Zvcm1hdFJlbWl0b09yaWdpbkludm9pY2UoZm9ybURhdGEpfWBcbiAgICAgICAgICAgICAgICAgICAgOiBgRWRpdGFuZG8gUmVtaXRvICMke2Zvcm1EYXRhLnJlbWl0b19udW1iZXIgfHwgaWR9YH1cbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gREVUQUxMRVMgREUgQ0FCRUNFUkEgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC02XCI+XG4gICAgICAgICAgICAgICAgey8qIENvbHVtbmEgMSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmFjdHVyYSBPcmlnZW48L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihmb3JtRGF0YS5zYWxlc19pbnZvaWNlX2lkKSA+IDAgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZm9ybURhdGEuc2FsZXNfaW52b2ljZSB8fCBmb3JtRGF0YS5pbnZvaWNlX251bWJlcikgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9mYWN0dXJhcy1kZS12ZW50YS8ke2Zvcm1EYXRhLnNhbGVzX2ludm9pY2VfaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFJlbWl0b09yaWdpbkludm9pY2UoZm9ybURhdGEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGZvcm1EYXRhLmludm9pY2VfbnVtYmVyIHx8IGZvcm1EYXRhLnNhbGVzX2ludm9pY2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDBcIj57Zm9ybWF0UmVtaXRvT3JpZ2luSW52b2ljZShmb3JtRGF0YSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj7igJQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5DbGllbnRlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY2xpZW50X25hbWUgfHwgJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIDIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIGRlIEVudHJlZ2EgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVsaXZlcnlfZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRlbGl2ZXJ5X2RhdGU/LnNwbGl0KCdUJylbMF0gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdlbmVyaWNDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5TZXJpZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzZXJpZXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zZXJpZXMgfHwgREVGQVVMVF9SRU1JVE9fU0VSSUVTfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHZW5lcmljQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc20gYmctd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtSRU1JVE9fU0VSSUVTX09QVElPTlMubWFwKChvcHQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e29wdC52YWx1ZX0gdmFsdWU9e29wdC52YWx1ZX0+e29wdC5sYWJlbH08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogQ29sdW1uYSAzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5UcmFuc3BvcnRlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLnRyYW5zcG9ydF9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEudHJhbnNwb3J0X25hbWUgfHwgZm9ybURhdGEudHJhbnNwb3J0Py5uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUdlbmVyaWNDaGFuZ2UoeyB0YXJnZXQ6IHsgbmFtZTogJ3RyYW5zcG9ydF9jb2RlJywgdmFsdWU6IG5ld0NvZGUgfSB9IGFzIFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ3RyYW5zcG9ydCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1RhcmdldCgndHJhbnNwb3J0Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vZGFsQ29uZmlnKHRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9e2hhbmRsZUNsZWFyVHJhbnNwb3J0fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RGlyZWNjacOzbiBFbnRyZWdhICgqKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmRlbGl2ZXJ5X2FkZHJlc3MgfHwgJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIDQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk9ic2VydmFjaW9uZXM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm9ic2VydmF0aW9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17NH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEub2JzZXJ2YXRpb25zIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHZW5lcmljQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBUQUJMQSBERSDDjVRFTVMgKENBTlRJREFERVMpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwIG1iLTRcIj5EZXRhbGxlIGRlIFByb2R1Y3RvcyBhIEVudHJlZ2FyPC9oMz5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdy0yLzVcIj5BcnTDrWN1bG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkNhbnQuIGZhY3R1cmFkYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+Q2FudC4gYSByZW1pdGlyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uc2FsZXNfaW52b2ljZV9pdGVtX2lkIHx8IGl0ZW0ucHJvZHVjdF9pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e2l0ZW0ucHJvZHVjdF9uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPih7aXRlbS5wcm9kdWN0X3NrdX0pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXJpZ2h0IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoaXRlbS5pbnZvaWNlX3F1YW50aXR5LCAnbnVtYmVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtLnF1YW50aXR5LCAnbnVtYmVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cblxuICAgICAgICAgICAgICAgICAgICB7aXRlbXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwLTQgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCc+Tm8gaGF5IHByb2R1Y3RvcyBwZW5kaWVudGVzIGRlIHJlbWl0aXIgZW4gZXN0YSBmYWN0dXJhLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQm90b25lcyBkZSBHdWFyZGFyL0NhbmNlbGFyIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgocmVtaXRvc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCBpdGVtcy5sZW5ndGggPT09IDAgfHwgbG9hZGluZ0ludm9pY2VEYXRhfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyZWVuLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgfHwgbG9hZGluZ0ludm9pY2VEYXRhID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdy01IGgtNSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgR3VhcmRhciBSZW1pdG9cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTW9kYWxlcyAqL31cbiAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiBtb2RhbENvbmZpZyAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9e2hhbmRsZVNlbGVjdE1vZGFsfVxuICAgICAgICAgICAgICAgICAgICBjb25maWc9e21vZGFsQ29uZmlnfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3JlbWl0b3MvcGFnZXMvUmVtaXRvc0Zvcm1QYWdlLnRzeCJ9