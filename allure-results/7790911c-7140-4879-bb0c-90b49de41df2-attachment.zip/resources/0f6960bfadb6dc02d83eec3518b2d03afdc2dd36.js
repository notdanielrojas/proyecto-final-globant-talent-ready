import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ItemTaxModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/ItemTaxModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { FaSave, FaTimes } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { computeSalesAppliedTaxes } from "/src/utils/salesRelatedTaxComputation.ts";
const SummaryRow = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: label }, void 0, false, {
    fileName: "/app/src/components/common/ItemTaxModal.tsx",
    lineNumber: 41,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: value }, void 0, false, {
    fileName: "/app/src/components/common/ItemTaxModal.tsx",
    lineNumber: 42,
    columnNumber: 9
  }, this)
] }, void 0, true, {
  fileName: "/app/src/components/common/ItemTaxModal.tsx",
  lineNumber: 40,
  columnNumber: 1
}, this);
_c = SummaryRow;
export const ItemTaxModal = ({
  isOpen,
  onClose,
  onSave,
  item,
  clientTaxes,
  clientTaxCondition
}) => {
  _s();
  const [appliedTaxes, setAppliedTaxes] = useState(item.taxes || []);
  const taxBase = useMemo(() => {
    const quantity = Number(item.quantity) || 0;
    const price = Number(item.unit_price) || 0;
    const discountAmount = Number(item.discount_amount) || 0;
    const subtotal = quantity * price;
    return subtotal - discountAmount;
  }, [item]);
  useEffect(() => {
    if (!clientTaxes || clientTaxes.length === 0) {
      setAppliedTaxes([]);
      return;
    }
    setAppliedTaxes(computeSalesAppliedTaxes({
      netBase: taxBase,
      clientTaxCondition,
      taxes: clientTaxes
    }));
  }, [taxBase, clientTaxes, clientTaxCondition]);
  const totalTaxes = useMemo(() => {
    return appliedTaxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
  }, [appliedTaxes]);
  const totalItem = taxBase + totalTaxes;
  const handleSave = () => {
    onSave(appliedTaxes);
    onClose();
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-xl w-full max-w-lg p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-3 border-b", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: [
        "Impuestos del Ítem: ",
        item.product_name
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 102,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "text-gray-400 hover:text-gray-600", children: /* @__PURE__ */ jsxDEV(FaTimes, {}, void 0, false, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 106,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 105,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ItemTaxModal.tsx",
      lineNumber: 101,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 rounded-lg", children: [
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Cantidad:", value: item.quantity }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 113,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Precio Unit.:", value: formatValue(item.unit_price, "currency") }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 114,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Subtotal Ítem:", value: formatValue(Number(item.quantity) * Number(item.unit_price), "currency") }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 115,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Descuento (Monto):", value: `- ${formatValue(item.discount_amount, "currency")}` }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 117,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Base Imponible Ítem:", value: formatValue(taxBase, "currency") }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 118,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 112,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800 mb-2", children: "Impuestos Aplicados" }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 123,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/components/common/ItemTaxModal.tsx",
              lineNumber: 128,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/components/common/ItemTaxModal.tsx",
              lineNumber: 129,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Monto" }, void 0, false, {
              fileName: "/app/src/components/common/ItemTaxModal.tsx",
              lineNumber: 130,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/ItemTaxModal.tsx",
            lineNumber: 127,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/components/common/ItemTaxModal.tsx",
            lineNumber: 126,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
            appliedTaxes.map(
              (tax) => /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-700", children: tax.tax_name }, void 0, false, {
                  fileName: "/app/src/components/common/ItemTaxModal.tsx",
                  lineNumber: 136,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500 text-right", children: tax.rate }, void 0, false, {
                  fileName: "/app/src/components/common/ItemTaxModal.tsx",
                  lineNumber: 137,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500 text-right", children: formatValue(tax.amount, "currency") }, void 0, false, {
                  fileName: "/app/src/components/common/ItemTaxModal.tsx",
                  lineNumber: 138,
                  columnNumber: 45
                }, this)
              ] }, tax.tax_id, true, {
                fileName: "/app/src/components/common/ItemTaxModal.tsx",
                lineNumber: 135,
                columnNumber: 19
              }, this)
            ),
            appliedTaxes.length === 0 && /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 3, className: "px-4 py-3 text-sm text-center text-gray-500", children: "No hay impuestos aplicados (Cliente no configurado)." }, void 0, false, {
              fileName: "/app/src/components/common/ItemTaxModal.tsx",
              lineNumber: 143,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/components/common/ItemTaxModal.tsx",
              lineNumber: 142,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/ItemTaxModal.tsx",
            lineNumber: 133,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 125,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 124,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 122,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 rounded-lg", children: [
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Total Impuestos Ítem:", value: formatValue(totalTaxes, "currency") }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 155,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "border-t my-2" }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 156,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(SummaryRow, { label: "Total Final Ítem (Inc. Imp):", value: /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-indigo-600", children: formatValue(totalItem, "currency") }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 157,
          columnNumber: 81
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 157,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 154,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ItemTaxModal.tsx",
      lineNumber: 110,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 mt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onClose, className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 162,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, className: "px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
        /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2 inline" }, void 0, false, {
          fileName: "/app/src/components/common/ItemTaxModal.tsx",
          lineNumber: 166,
          columnNumber: 25
        }, this),
        "Aceptar y Guardar"
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ItemTaxModal.tsx",
        lineNumber: 165,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ItemTaxModal.tsx",
      lineNumber: 161,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/ItemTaxModal.tsx",
    lineNumber: 100,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/common/ItemTaxModal.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this);
};
_s(ItemTaxModal, "WpgkLirBXnMUXNrrmlB+GzDB098=");
_c2 = ItemTaxModal;
var _c, _c2;
$RefreshReg$(_c, "SummaryRow");
$RefreshReg$(_c2, "ItemTaxModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/ItemTaxModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/ItemTaxModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCUixPQUFPQSxTQUFTQyxVQUFVQyxXQUFXQyxlQUFlO0FBQ3BELFNBQVNDLFFBQVFDLGVBQWU7QUFHaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGdDQUFnQztBQWF6QyxNQUFNQyxhQUFhQSxDQUFDLEVBQUVDLE9BQU9DLE1BQWlELE1BQzFFLHVCQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLHlCQUFDLFVBQUssV0FBVSxxQ0FBcUNELG1CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJEO0FBQUEsRUFDM0QsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q0MsbUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkQ7QUFBQSxLQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDRkMsS0FMSUg7QUFPQyxhQUFNSSxlQUE0Q0EsQ0FBQztBQUFBLEVBQ3REQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNKLE1BQU07QUFBQUMsS0FBQTtBQUdGLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJcEIsU0FBdUJlLEtBQUtNLFNBQVMsRUFBRTtBQUcvRSxRQUFNQyxVQUFVcEIsUUFBUSxNQUFNO0FBQzFCLFVBQU1xQixXQUFXQyxPQUFPVCxLQUFLUSxRQUFRLEtBQUs7QUFDMUMsVUFBTUUsUUFBUUQsT0FBT1QsS0FBS1csVUFBVSxLQUFLO0FBRXpDLFVBQU1DLGlCQUFpQkgsT0FBT1QsS0FBS2EsZUFBZSxLQUFLO0FBRXZELFVBQU1DLFdBQVdOLFdBQVdFO0FBRTVCLFdBQU9JLFdBQVdGO0FBQUFBLEVBQ3RCLEdBQUcsQ0FBQ1osSUFBSSxDQUFDO0FBR1RkLFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ2UsZUFBZUEsWUFBWWMsV0FBVyxHQUFHO0FBQzFDVixzQkFBZ0IsRUFBRTtBQUNsQjtBQUFBLElBQ0o7QUFDQUEsb0JBQWdCZCx5QkFBeUI7QUFBQSxNQUNyQ3lCLFNBQVNUO0FBQUFBLE1BQ1RMO0FBQUFBLE1BQ0FJLE9BQU9MO0FBQUFBLElBQ1gsQ0FBQyxDQUFDO0FBQUEsRUFFTixHQUFHLENBQUNNLFNBQVNOLGFBQWFDLGtCQUFrQixDQUFDO0FBRzdDLFFBQU1lLGFBQWE5QixRQUFRLE1BQU07QUFDN0IsV0FBT2lCLGFBQWFjLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTVYsT0FBT1csSUFBSUMsTUFBTSxHQUFHLENBQUM7QUFBQSxFQUN4RSxHQUFHLENBQUNqQixZQUFZLENBQUM7QUFFakIsUUFBTWtCLFlBQVlmLFVBQVVVO0FBRTVCLFFBQU1NLGFBQWFBLE1BQU07QUFDckJ4QixXQUFPSyxZQUFZO0FBQ25CTixZQUFRO0FBQUEsRUFDWjtBQUVBLE1BQUksQ0FBQ0QsT0FBUSxRQUFPO0FBRXBCLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLG9GQUNYLGlDQUFDLFNBQUksV0FBVSxxREFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxtREFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrQ0FBNkM7QUFBQTtBQUFBLFFBQ2xDRyxLQUFLd0I7QUFBQUEsV0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFNBQVMxQixTQUFTLFdBQVUscUNBQ2hDLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrQkFFWDtBQUFBLDZCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLCtCQUFDLGNBQVcsT0FBTSxhQUFZLE9BQU9FLEtBQUtRLFlBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRCx1QkFBQyxjQUFXLE9BQU0saUJBQWdCLE9BQU9sQixZQUFZVSxLQUFLVyxZQUFZLFVBQVUsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFFBQ2xGLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsT0FBT3JCLFlBQVltQixPQUFPVCxLQUFLUSxRQUFRLElBQUlDLE9BQU9ULEtBQUtXLFVBQVUsR0FBRyxVQUFVLEtBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxRQUVuSCx1QkFBQyxjQUFXLE9BQU0sc0JBQXFCLE9BQU8sS0FBS3JCLFlBQVlVLEtBQUthLGlCQUFpQixVQUFVLENBQUMsTUFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRztBQUFBLFFBQ25HLHVCQUFDLGNBQVcsT0FBTSx3QkFBdUIsT0FBT3ZCLFlBQVlpQixTQUFTLFVBQVUsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBTnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BR0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUcsV0FBVSwwQ0FBeUMsbUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEU7QUFBQSxRQUMxRSx1QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxtRUFBa0Usd0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSx3QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQSxZQUN6Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBSDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pIO0FBQUFBLHlCQUFhcUI7QUFBQUEsY0FBSSxDQUFBTCxRQUNkLHVCQUFDLFFBQ0c7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsbUNBQW1DQSxjQUFJTSxZQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RDtBQUFBLGdCQUM5RCx1QkFBQyxRQUFHLFdBQVUsOENBQThDTixjQUFJTyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRTtBQUFBLGdCQUNyRSx1QkFBQyxRQUFHLFdBQVUsOENBQThDckMsc0JBQVk4QixJQUFJQyxRQUFRLFVBQVUsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0c7QUFBQSxtQkFIM0ZELElBQUlRLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLFlBQ0g7QUFBQSxZQUNBeEIsYUFBYVcsV0FBVyxLQUNyQix1QkFBQyxRQUNHLGlDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsK0NBQTZDLG9FQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBYlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkEsS0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFdBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLCtCQUFDLGNBQVcsT0FBTSx5QkFBd0IsT0FBT3pCLFlBQVkyQixZQUFZLFVBQVUsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBQ3JGLHVCQUFDLFNBQUksV0FBVSxtQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFDL0IsdUJBQUMsY0FBVyxPQUFNLGdDQUErQixPQUFPLHVCQUFDLFVBQUssV0FBVSxxQ0FBcUMzQixzQkFBWWdDLFdBQVcsVUFBVSxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGLEtBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0o7QUFBQSxXQUg1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTeEIsU0FBUyxXQUFVLHFIQUFtSCx3QkFBcks7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTeUIsWUFBWSxXQUFVLGtJQUNqRDtBQUFBLCtCQUFDLFVBQU8sV0FBVSx5QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBO0FBQUEsV0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0VBLEtBdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3RUE7QUFFUjtBQUFFcEIsR0EvSFdQLGNBQXlDO0FBQUFpQyxNQUF6Q2pDO0FBQXlDLElBQUFELElBQUFrQztBQUFBQyxhQUFBbkMsSUFBQTtBQUFBbUMsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwiRmFTYXZlIiwiRmFUaW1lcyIsImZvcm1hdFZhbHVlIiwiY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzIiwiU3VtbWFyeVJvdyIsImxhYmVsIiwidmFsdWUiLCJfYyIsIkl0ZW1UYXhNb2RhbCIsImlzT3BlbiIsIm9uQ2xvc2UiLCJvblNhdmUiLCJpdGVtIiwiY2xpZW50VGF4ZXMiLCJjbGllbnRUYXhDb25kaXRpb24iLCJfcyIsImFwcGxpZWRUYXhlcyIsInNldEFwcGxpZWRUYXhlcyIsInRheGVzIiwidGF4QmFzZSIsInF1YW50aXR5IiwiTnVtYmVyIiwicHJpY2UiLCJ1bml0X3ByaWNlIiwiZGlzY291bnRBbW91bnQiLCJkaXNjb3VudF9hbW91bnQiLCJzdWJ0b3RhbCIsImxlbmd0aCIsIm5ldEJhc2UiLCJ0b3RhbFRheGVzIiwicmVkdWNlIiwic3VtIiwidGF4IiwiYW1vdW50IiwidG90YWxJdGVtIiwiaGFuZGxlU2F2ZSIsInByb2R1Y3RfbmFtZSIsIm1hcCIsInRheF9uYW1lIiwicmF0ZSIsInRheF9pZCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJdGVtVGF4TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9tb2R1bGVzL3BlZGlkb3NfdmVudGEvY29tcG9uZW50cy9JdGVtVGF4TW9kYWwudHN4XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFUaW1lcyB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB0eXBlIHsgQXBwbGllZFRheCwgUmVsYXRlZFRheCB9IGZyb20gJy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQgdHlwZSB7IFNhbGVzT3JkZXJJdGVtIH0gZnJvbSAnLi4vLi4vZmVhdHVyZXMvcGVkaWRvc192ZW50YS9wZWRpZG9zX3ZlbnRhX2NvbmZpZyc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzIH0gZnJvbSAnLi4vLi4vdXRpbHMvc2FsZXNSZWxhdGVkVGF4Q29tcHV0YXRpb24nO1xuXG5cbmludGVyZmFjZSBJdGVtVGF4TW9kYWxQcm9wcyB7XG4gICAgaXNPcGVuOiBib29sZWFuO1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gICAgb25TYXZlOiAodGF4ZXM6IEFwcGxpZWRUYXhbXSkgPT4gdm9pZDtcbiAgICBpdGVtOiBTYWxlc09yZGVySXRlbTtcbiAgICBjbGllbnRUYXhlczogUmVsYXRlZFRheFtdO1xuICAgIGNsaWVudFRheENvbmRpdGlvbj86IHN0cmluZyB8IG51bGw7XG59XG5cbi8vIENvbXBvbmVudGUgcGFyYSB1bmEgZmlsYSBkZSB0b3RhbFxuY29uc3QgU3VtbWFyeVJvdyA9ICh7IGxhYmVsLCB2YWx1ZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBSZWFjdC5SZWFjdE5vZGUgfSkgPT4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTJcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj57dmFsdWV9PC9zcGFuPlxuICAgIDwvZGl2PlxuKTtcblxuZXhwb3J0IGNvbnN0IEl0ZW1UYXhNb2RhbDogUmVhY3QuRkM8SXRlbVRheE1vZGFsUHJvcHM+ID0gKHtcbiAgICBpc09wZW4sXG4gICAgb25DbG9zZSxcbiAgICBvblNhdmUsXG4gICAgaXRlbSxcbiAgICBjbGllbnRUYXhlcyxcbiAgICBjbGllbnRUYXhDb25kaXRpb24sXG59KSA9PiB7XG5cbiAgICAvLyBFc3RhZG8gbG9jYWwgcGFyYSBsb3MgaW1wdWVzdG9zIGRlIGVzdGUgw610ZW0gKHVzYSBBcHBsaWVkVGF4KVxuICAgIGNvbnN0IFthcHBsaWVkVGF4ZXMsIHNldEFwcGxpZWRUYXhlc10gPSB1c2VTdGF0ZTxBcHBsaWVkVGF4W10+KGl0ZW0udGF4ZXMgfHwgW10pO1xuXG4gICAgLy8gMS4gQ2FsY3VsYXIgbGEgYmFzZSBpbXBvbmlibGUgZGVsIMONVEVNIChFc3RhIGzDs2dpY2EgZXN0YWJhIGJpZW4pXG4gICAgY29uc3QgdGF4QmFzZSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBxdWFudGl0eSA9IE51bWJlcihpdGVtLnF1YW50aXR5KSB8fCAwO1xuICAgICAgICBjb25zdCBwcmljZSA9IE51bWJlcihpdGVtLnVuaXRfcHJpY2UpIHx8IDA7XG4gICAgICAgIC8vIC0tLSBNT0RJRklDQURPOiBVc2Ftb3MgZGlzY291bnRfYW1vdW50IChub21pbmFsKSAtLS1cbiAgICAgICAgY29uc3QgZGlzY291bnRBbW91bnQgPSBOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDA7XG5cbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBxdWFudGl0eSAqIHByaWNlO1xuICAgICAgICAvLyBMYSBiYXNlIGltcG9uaWJsZSBlcyBzdWJ0b3RhbCBNRU5PUyBlbCBkZXNjdWVudG8gbm9taW5hbFxuICAgICAgICByZXR1cm4gc3VidG90YWwgLSBkaXNjb3VudEFtb3VudDtcbiAgICB9LCBbaXRlbV0pO1xuXG4gICAgLy8gMi4gUmVjYWxjdWxhciBpbXB1ZXN0b3MgKEzDs2dpY2EgZGUgbWFwZW8gY29ycmVnaWRhIGdyYWNpYXMgYSB0aSlcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWNsaWVudFRheGVzIHx8IGNsaWVudFRheGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgICAgIG5ldEJhc2U6IHRheEJhc2UsXG4gICAgICAgICAgICBjbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICB0YXhlczogY2xpZW50VGF4ZXMsXG4gICAgICAgIH0pKTtcblxuICAgIH0sIFt0YXhCYXNlLCBjbGllbnRUYXhlcywgY2xpZW50VGF4Q29uZGl0aW9uXSk7XG5cbiAgICAvLyAzLiBDYWxjdWxhciB0b3RhbGVzIChFc3RhIGzDs2dpY2EgZXN0YWJhIGJpZW4pXG4gICAgY29uc3QgdG90YWxUYXhlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICByZXR1cm4gYXBwbGllZFRheGVzLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG4gICAgfSwgW2FwcGxpZWRUYXhlc10pO1xuXG4gICAgY29uc3QgdG90YWxJdGVtID0gdGF4QmFzZSArIHRvdGFsVGF4ZXM7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gKCkgPT4ge1xuICAgICAgICBvblNhdmUoYXBwbGllZFRheGVzKTtcbiAgICAgICAgb25DbG9zZSgpO1xuICAgIH07XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXNtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXhsIHctZnVsbCBtYXgtdy1sZyBwLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi0zIGJvcmRlci1iXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBJbXB1ZXN0b3MgZGVsIMONdGVtOiB7aXRlbS5wcm9kdWN0X25hbWV9XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFUaW1lcyAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFJlc3VtZW4gZGUgY8OhbGN1bG8gZGVsIMOtdGVtICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1ncmF5LTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Um93IGxhYmVsPVwiQ2FudGlkYWQ6XCIgdmFsdWU9e2l0ZW0ucXVhbnRpdHl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeVJvdyBsYWJlbD1cIlByZWNpbyBVbml0LjpcIiB2YWx1ZT17Zm9ybWF0VmFsdWUoaXRlbS51bml0X3ByaWNlLCAnY3VycmVuY3knKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Um93IGxhYmVsPVwiU3VidG90YWwgw410ZW06XCIgdmFsdWU9e2Zvcm1hdFZhbHVlKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpLCAnY3VycmVuY3knKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gTU9ESUZJQ0FETzogTW9zdHJhbW9zIGRlc2N1ZW50byBub21pbmFsIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Um93IGxhYmVsPVwiRGVzY3VlbnRvIChNb250byk6XCIgdmFsdWU9e2AtICR7Zm9ybWF0VmFsdWUoaXRlbS5kaXNjb3VudF9hbW91bnQsICdjdXJyZW5jeScpfWB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeVJvdyBsYWJlbD1cIkJhc2UgSW1wb25pYmxlIMONdGVtOlwiIHZhbHVlPXtmb3JtYXRWYWx1ZSh0YXhCYXNlLCAnY3VycmVuY3knKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFRhYmxhIGRlIEltcHVlc3RvcyBBcGxpY2Fkb3MgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIG1iLTJcIj5JbXB1ZXN0b3MgQXBsaWNhZG9zPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkltcHVlc3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlRhc2EgKCUpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPk1vbnRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBsaWVkVGF4ZXMubWFwKHRheCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dGF4LnRheF9pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+e3RheC50YXhfbmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LXJpZ2h0XCI+e3RheC5yYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtcmlnaHRcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXBwbGllZFRheGVzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17M30gY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gaGF5IGltcHVlc3RvcyBhcGxpY2Fkb3MgKENsaWVudGUgbm8gY29uZmlndXJhZG8pLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIEZpbmFsIGRlbCDDjXRlbSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeVJvdyBsYWJlbD1cIlRvdGFsIEltcHVlc3RvcyDDjXRlbTpcIiB2YWx1ZT17Zm9ybWF0VmFsdWUodG90YWxUYXhlcywgJ2N1cnJlbmN5Jyl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IG15LTJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Um93IGxhYmVsPVwiVG90YWwgRmluYWwgw410ZW0gKEluYy4gSW1wKTpcIiB2YWx1ZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+e2Zvcm1hdFZhbHVlKHRvdGFsSXRlbSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBtdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlU2F2ZX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFTYXZlIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiBpbmxpbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWNlcHRhciB5IEd1YXJkYXJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL0l0ZW1UYXhNb2RhbC50c3gifQ==