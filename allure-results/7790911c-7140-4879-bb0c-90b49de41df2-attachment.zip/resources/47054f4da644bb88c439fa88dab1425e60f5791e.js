import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FaCheckCircle, FaTimesCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const planDeCuentasModuleConfig = {
  endpoint: "chart-accounts",
  moduleName: "Plan de Cuentas",
  moduleNamePlural: "Planes de Cuentas",
  baseRoute: "/plan-de-cuentas",
  detail: {
    displayNameKey: "name"
  },
  list: {
    columns: [
      { header: "Código", accessor: "code" },
      { header: "Nombre", accessor: "name" },
      { header: "Nivel", accessor: "level" },
      {
        header: "Saldo",
        accessor: "balance",
        render: (item) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-right", children: parseFloat(item.balance).toLocaleString("es-AR", { style: "currency", currency: "ARS" }) }, void 0, false, {
          fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
          lineNumber: 46,
          columnNumber: 7
        }, this)
      },
      {
        header: "Ajustable",
        accessor: "is_ajustable",
        render: (item) => item.is_ajustable ? /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-500" }, void 0, false, {
          fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
          lineNumber: 55,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "text-red-500" }, void 0, false, {
          fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
          lineNumber: 56,
          columnNumber: 7
        }, this)
      },
      {
        header: "Movimientos",
        accessor: "moviments",
        render: (item) => item.moviments ? /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-500" }, void 0, false, {
          fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
          lineNumber: 62,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "text-red-500" }, void 0, false, {
          fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
          lineNumber: 63,
          columnNumber: 7
        }, this)
      }
    ]
  },
  form: {
    block: [
      {
        name: "Datos de la cuenta contable",
        fields: [
          { name: "code", label: "Código", type: "text", placeholder: "Ej: 100100" },
          { name: "name", label: "Nombre de la Cuenta", type: "text", placeholder: "Ej: DISPONIBILIDADES" },
          {
            name: "related_to",
            label: "Relacionado a",
            type: "relational",
            relationalConfig: {
              // @ts-ignore - Self-referential: se asignará después de la definición del objeto
              moduleConfig: null,
              codeField: "related_to_code",
              // ✅ Debe ser 'code' para buscar/leer del objeto relacionado
              nameField: "related_to_name"
              // ✅ Debe ser 'name' para buscar/leer del objeto relacionado
              // Nota: GenericFormPage guardará en formData.code y formData.name
              // Interceptamos en las páginas para preservar los valores originales
            },
            render: (item) => item.parent?.name || item.parent_name || item.related_to_name || "-"
          },
          // ✅ Removido el campo 'level' del formulario
          { name: "account_code", label: "Código de Cuenta", type: "text", placeholder: "Ej: 001" },
          { name: "columna_balance", label: "Columna de Balance", type: "number" },
          {
            name: "is_ajustable",
            label: "Es Ajustable",
            type: "select",
            options: [
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.is_ajustable ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.is_ajustable ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
              lineNumber: 100,
              columnNumber: 9
            }, this),
            valueType: "boolean"
          },
          {
            name: "moviments",
            label: "Permite Movimientos",
            type: "select",
            options: [
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.moviments ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.moviments ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx",
              lineNumber: 114,
              columnNumber: 9
            }, this),
            valueType: "boolean"
          }
        ]
      }
    ]
  },
  relationalFields: {
    idField: "id",
    codeField: "related_to_code",
    nameField: "related_to_name"
  },
  /** Claves con las que cada ítem del plan de cuentas viene en la API (al listar/seleccionar). */
  listItemCodeKey: "code",
  listItemNameKey: "name"
};
const relatedToField = planDeCuentasModuleConfig.form.block[0]?.fields?.find((f) => f.name === "related_to");
if (relatedToField && relatedToField.relationalConfig) {
  relatedToField.relationalConfig.moduleConfig = planDeCuentasModuleConfig;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNvQjtBQTVDcEIsU0FBU0EsZUFBZUMscUJBQXFCO0FBeUJ0QyxhQUFNQyw0QkFBeUQ7QUFBQSxFQUNsRUMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaQyxrQkFBa0I7QUFBQSxFQUNsQkMsV0FBVztBQUFBLEVBRVhDLFFBQVE7QUFBQSxJQUNKQyxnQkFBZ0I7QUFBQSxFQUNwQjtBQUFBLEVBRUFDLE1BQU07QUFBQSxJQUNGQyxTQUFTO0FBQUEsTUFDTCxFQUFFQyxRQUFRLFVBQVVDLFVBQVUsT0FBTztBQUFBLE1BQ3JDLEVBQUVELFFBQVEsVUFBVUMsVUFBVSxPQUFPO0FBQUEsTUFDckMsRUFBRUQsUUFBUSxTQUFTQyxVQUFVLFFBQVE7QUFBQSxNQUNyQztBQUFBLFFBQ0lELFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsUUFBUUEsQ0FBQ0MsU0FDTCx1QkFBQyxVQUFLLFdBQVUsd0JBQ1hDLHFCQUFXRCxLQUFLRSxPQUFPLEVBQUVDLGVBQWUsU0FBUyxFQUFFQyxPQUFPLFlBQVlDLFVBQVUsTUFBTSxDQUFDLEtBRDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRVI7QUFBQSxNQUNBO0FBQUEsUUFDSVIsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLTSxlQUNqQix1QkFBQyxpQkFBYyxXQUFVLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLElBQ3pDLHVCQUFDLGlCQUFjLFdBQVUsa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxNQUNqRDtBQUFBLE1BQ0E7QUFBQSxRQUNJVCxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtPLFlBQ2pCLHVCQUFDLGlCQUFjLFdBQVUsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUMsSUFDekMsdUJBQUMsaUJBQWMsV0FBVSxrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLE1BQ2pEO0FBQUEsSUFBQztBQUFBLEVBRVQ7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsT0FBTztBQUFBLE1BQ0g7QUFBQSxRQUNJQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFVBQ0osRUFBRUQsTUFBTSxRQUFRRSxPQUFPLFVBQVVDLE1BQU0sUUFBUUMsYUFBYSxhQUFhO0FBQUEsVUFDekUsRUFBRUosTUFBTSxRQUFRRSxPQUFPLHVCQUF1QkMsTUFBTSxRQUFRQyxhQUFhLHVCQUF1QjtBQUFBLFVBQ2hHO0FBQUEsWUFDSUosTUFBTTtBQUFBLFlBQ05FLE9BQU87QUFBQSxZQUNQQyxNQUFNO0FBQUEsWUFDTkUsa0JBQWtCO0FBQUE7QUFBQSxjQUVkQyxjQUFjO0FBQUEsY0FDZEMsV0FBVztBQUFBO0FBQUEsY0FDWEMsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR2Y7QUFBQSxZQUNBbkIsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS21CLFFBQVFULFFBQVFWLEtBQUtvQixlQUFlcEIsS0FBS3FCLG1CQUFtQjtBQUFBLFVBQ3ZGO0FBQUE7QUFBQSxVQUVBLEVBQUVYLE1BQU0sZ0JBQWdCRSxPQUFPLG9CQUFvQkMsTUFBTSxRQUFRQyxhQUFhLFVBQVU7QUFBQSxVQUN4RixFQUFFSixNQUFNLG1CQUFtQkUsT0FBTyxzQkFBc0JDLE1BQU0sU0FBUztBQUFBLFVBQ3ZFO0FBQUEsWUFDSUgsTUFBTTtBQUFBLFlBQWdCRSxPQUFPO0FBQUEsWUFDN0JDLE1BQU07QUFBQSxZQUNOUyxTQUFTO0FBQUEsY0FDTCxFQUFFQyxPQUFPLEtBQUtYLE9BQU8sS0FBSztBQUFBLGNBQzFCLEVBQUVXLE9BQU8sS0FBS1gsT0FBTyxLQUFLO0FBQUEsWUFBQztBQUFBLFlBRS9CYixRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUtNLGVBQWUsZ0NBQWdDLHlCQUF5QixJQUMxSk4sZUFBS00sZUFBZSxPQUFPLFFBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVKa0IsV0FBVztBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDSWQsTUFBTTtBQUFBLFlBQWFFLE9BQU87QUFBQSxZQUMxQkMsTUFBTTtBQUFBLFlBQ05TLFNBQVM7QUFBQSxjQUNMLEVBQUVDLE9BQU8sS0FBS1gsT0FBTyxLQUFLO0FBQUEsY0FDMUIsRUFBRVcsT0FBTyxLQUFLWCxPQUFPLEtBQUs7QUFBQSxZQUFDO0FBQUEsWUFFL0JiLFFBQVFBLENBQUNDLFNBQ0wsdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUEsS0FBS08sWUFBWSxnQ0FBZ0MseUJBQXlCLElBQ3ZKUCxlQUFLTyxZQUFZLE9BQU8sUUFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUppQixXQUFXO0FBQUEsVUFDZjtBQUFBLFFBQUM7QUFBQSxNQUVUO0FBQUEsSUFBQztBQUFBLEVBRVQ7QUFBQSxFQUNBQyxrQkFBa0I7QUFBQSxJQUNkQyxTQUFTO0FBQUEsSUFDVFQsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxFQUNmO0FBQUE7QUFBQSxFQUVBUyxpQkFBaUI7QUFBQSxFQUNqQkMsaUJBQWlCO0FBQ3JCO0FBR0EsTUFBTUMsaUJBQWlCekMsMEJBQTBCb0IsS0FBS0MsTUFBTSxDQUFDLEdBQUdFLFFBQVFtQixLQUFLLENBQUFDLE1BQUtBLEVBQUVyQixTQUFTLFlBQVk7QUFDekcsSUFBSW1CLGtCQUFrQkEsZUFBZWQsa0JBQWtCO0FBQ25EYyxpQkFBZWQsaUJBQWlCQyxlQUFlNUI7QUFDbkQiLCJuYW1lcyI6WyJGYUNoZWNrQ2lyY2xlIiwiRmFUaW1lc0NpcmNsZSIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJlbmRwb2ludCIsIm1vZHVsZU5hbWUiLCJtb2R1bGVOYW1lUGx1cmFsIiwiYmFzZVJvdXRlIiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJsaXN0IiwiY29sdW1ucyIsImhlYWRlciIsImFjY2Vzc29yIiwicmVuZGVyIiwiaXRlbSIsInBhcnNlRmxvYXQiLCJiYWxhbmNlIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiaXNfYWp1c3RhYmxlIiwibW92aW1lbnRzIiwiZm9ybSIsImJsb2NrIiwibmFtZSIsImZpZWxkcyIsImxhYmVsIiwidHlwZSIsInBsYWNlaG9sZGVyIiwicmVsYXRpb25hbENvbmZpZyIsIm1vZHVsZUNvbmZpZyIsImNvZGVGaWVsZCIsIm5hbWVGaWVsZCIsInBhcmVudCIsInBhcmVudF9uYW1lIiwicmVsYXRlZF90b19uYW1lIiwib3B0aW9ucyIsInZhbHVlIiwidmFsdWVUeXBlIiwicmVsYXRpb25hbEZpZWxkcyIsImlkRmllbGQiLCJsaXN0SXRlbUNvZGVLZXkiLCJsaXN0SXRlbU5hbWVLZXkiLCJyZWxhdGVkVG9GaWVsZCIsImZpbmQiLCJmIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInBsYW5fZGVfY3VlbnRhcy5jb25maWcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZVwiO1xuaW1wb3J0IHsgRmFDaGVja0NpcmNsZSwgRmFUaW1lc0NpcmNsZSB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcblxuLy8gMS4gRGVmaW5pbW9zIGxhIGludGVyZmF6IGJhc2FkYSBlbiBsYSByZXNwdWVzdGEgZGUgbGEgQVBJXG5leHBvcnQgaW50ZXJmYWNlIFBsYW5EZUN1ZW50YXMge1xuICAgIGlkOiBudW1iZXI7XG4gICAgY29kZTogc3RyaW5nO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICByZWxhdGVkX3RvOiBudW1iZXIgfCBudWxsOyAvLyDinIUgQ2FtYmlhZG8gZGUgc3RyaW5nIGEgbnVtYmVyIHwgbnVsbFxuICAgIGxldmVsOiBudW1iZXI7XG4gICAgYmFsYW5jZTogc3RyaW5nO1xuICAgIGlzX2FqdXN0YWJsZTogYm9vbGVhbjtcbiAgICBtb3ZpbWVudHM6IGJvb2xlYW47XG4gICAgYWNjb3VudF9jb2RlOiBzdHJpbmc7XG4gICAgY29sdW1uYV9iYWxhbmNlOiBudW1iZXI7XG4gICAgLy8g4pyFIENhbXBvcyBwYXJhIFJlbGF0aW9uYWxJbnB1dCAoc2VsZi1yZWZlcmVudGlhbClcbiAgICByZWxhdGVkX3RvX2NvZGU/OiBzdHJpbmc7XG4gICAgcmVsYXRlZF90b19uYW1lPzogc3RyaW5nO1xuICAgIC8vIOKchSBPYmpldG8gcmVsYWNpb25hbCAodmllbmUgZGVsIGJhY2tlbmQpXG4gICAgcGFyZW50PzogUGxhbkRlQ3VlbnRhcztcbiAgICBwYXJlbnRfaWQ/OiBudW1iZXI7XG4gICAgcGFyZW50X2NvZGU/OiBzdHJpbmc7XG4gICAgcGFyZW50X25hbWU/OiBzdHJpbmc7XG59XG5cbi8vIDIuIENyZWFtb3MgbGEgY29uZmlndXJhY2nDs24gY29tcGxldGEgcGFyYSBlbCBtw7NkdWxvXG5leHBvcnQgY29uc3QgcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZzogTW9kdWxlQ29uZmlnPFBsYW5EZUN1ZW50YXM+ID0ge1xuICAgIGVuZHBvaW50OiAnY2hhcnQtYWNjb3VudHMnLFxuICAgIG1vZHVsZU5hbWU6ICdQbGFuIGRlIEN1ZW50YXMnLFxuICAgIG1vZHVsZU5hbWVQbHVyYWw6ICdQbGFuZXMgZGUgQ3VlbnRhcycsXG4gICAgYmFzZVJvdXRlOiAnL3BsYW4tZGUtY3VlbnRhcycsXG5cbiAgICBkZXRhaWw6IHtcbiAgICAgICAgZGlzcGxheU5hbWVLZXk6ICduYW1lJyxcbiAgICB9LFxuXG4gICAgbGlzdDoge1xuICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0PDs2RpZ28nLCBhY2Nlc3NvcjogJ2NvZGUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ05vbWJyZScsIGFjY2Vzc29yOiAnbmFtZScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnTml2ZWwnLCBhY2Nlc3NvcjogJ2xldmVsJyB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1NhbGRvJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ2JhbGFuY2UnLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJzZUZsb2F0KGl0ZW0uYmFsYW5jZSkudG9Mb2NhbGVTdHJpbmcoJ2VzLUFSJywgeyBzdHlsZTogJ2N1cnJlbmN5JywgY3VycmVuY3k6ICdBUlMnIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdBanVzdGFibGUnLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAnaXNfYWp1c3RhYmxlJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmlzX2FqdXN0YWJsZVxuICAgICAgICAgICAgICAgICAgICA/IDxGYUNoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgOiA8RmFUaW1lc0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIiAvPlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdNb3ZpbWllbnRvcycsXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6ICdtb3ZpbWVudHMnLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ubW92aW1lbnRzXG4gICAgICAgICAgICAgICAgICAgID8gPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA6IDxGYVRpbWVzQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiIC8+XG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG5cbiAgICBmb3JtOiB7XG4gICAgICAgIGJsb2NrOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJEYXRvcyBkZSBsYSBjdWVudGEgY29udGFibGVcIixcbiAgICAgICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnY29kZScsIGxhYmVsOiAnQ8OzZGlnbycsIHR5cGU6ICd0ZXh0JywgcGxhY2Vob2xkZXI6ICdFajogMTAwMTAwJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICduYW1lJywgbGFiZWw6ICdOb21icmUgZGUgbGEgQ3VlbnRhJywgdHlwZTogJ3RleHQnLCBwbGFjZWhvbGRlcjogJ0VqOiBESVNQT05JQklMSURBREVTJyB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAncmVsYXRlZF90bycsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1JlbGFjaW9uYWRvIGEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3JlbGF0aW9uYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbENvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgLSBTZWxmLXJlZmVyZW50aWFsOiBzZSBhc2lnbmFyw6EgZGVzcHXDqXMgZGUgbGEgZGVmaW5pY2nDs24gZGVsIG9iamV0b1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZHVsZUNvbmZpZzogbnVsbCBhcyBhbnksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAncmVsYXRlZF90b19jb2RlJywgLy8g4pyFIERlYmUgc2VyICdjb2RlJyBwYXJhIGJ1c2Nhci9sZWVyIGRlbCBvYmpldG8gcmVsYWNpb25hZG9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICdyZWxhdGVkX3RvX25hbWUnICAvLyDinIUgRGViZSBzZXIgJ25hbWUnIHBhcmEgYnVzY2FyL2xlZXIgZGVsIG9iamV0byByZWxhY2lvbmFkb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5vdGE6IEdlbmVyaWNGb3JtUGFnZSBndWFyZGFyw6EgZW4gZm9ybURhdGEuY29kZSB5IGZvcm1EYXRhLm5hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbnRlcmNlcHRhbW9zIGVuIGxhcyBww6FnaW5hcyBwYXJhIHByZXNlcnZhciBsb3MgdmFsb3JlcyBvcmlnaW5hbGVzXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5wYXJlbnQ/Lm5hbWUgfHwgaXRlbS5wYXJlbnRfbmFtZSB8fCBpdGVtLnJlbGF0ZWRfdG9fbmFtZSB8fCAnLSdcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgLy8g4pyFIFJlbW92aWRvIGVsIGNhbXBvICdsZXZlbCcgZGVsIGZvcm11bGFyaW9cbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnYWNjb3VudF9jb2RlJywgbGFiZWw6ICdDw7NkaWdvIGRlIEN1ZW50YScsIHR5cGU6ICd0ZXh0JywgcGxhY2Vob2xkZXI6ICdFajogMDAxJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdjb2x1bW5hX2JhbGFuY2UnLCBsYWJlbDogJ0NvbHVtbmEgZGUgQmFsYW5jZScsIHR5cGU6ICdudW1iZXInIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdpc19hanVzdGFibGUnLCBsYWJlbDogJ0VzIEFqdXN0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnc2VsZWN0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMCcsIGxhYmVsOiAnTm8nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzEnLCBsYWJlbDogJ1NpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXRlbS5pc19hanVzdGFibGUgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmlzX2FqdXN0YWJsZSA/ICdTw60nIDogJ05vJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiAnYm9vbGVhbicsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdtb3ZpbWVudHMnLCBsYWJlbDogJ1Blcm1pdGUgTW92aW1pZW50b3MnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzAnLCBsYWJlbDogJ05vJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICcxJywgbGFiZWw6ICdTaScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0ubW92aW1lbnRzID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5tb3ZpbWVudHMgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogJ2Jvb2xlYW4nLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH0sXG4gICAgcmVsYXRpb25hbEZpZWxkczoge1xuICAgICAgICBpZEZpZWxkOiAnaWQnLFxuICAgICAgICBjb2RlRmllbGQ6ICdyZWxhdGVkX3RvX2NvZGUnLFxuICAgICAgICBuYW1lRmllbGQ6ICdyZWxhdGVkX3RvX25hbWUnLFxuICAgIH0sXG4gICAgLyoqIENsYXZlcyBjb24gbGFzIHF1ZSBjYWRhIMOtdGVtIGRlbCBwbGFuIGRlIGN1ZW50YXMgdmllbmUgZW4gbGEgQVBJIChhbCBsaXN0YXIvc2VsZWNjaW9uYXIpLiAqL1xuICAgIGxpc3RJdGVtQ29kZUtleTogJ2NvZGUnLFxuICAgIGxpc3RJdGVtTmFtZUtleTogJ25hbWUnLFxufTtcblxuLy8g4pyFIEFzaWduYXIgZWwgbW9kdWxlQ29uZmlnIGFsIGNhbXBvIHJlbGF0ZWRfdG8gZGVzcHXDqXMgZGUgbGEgZGVmaW5pY2nDs24gcGFyYSBldml0YXIgcmVmZXJlbmNpYSBjaXJjdWxhclxuY29uc3QgcmVsYXRlZFRvRmllbGQgPSBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLmZvcm0uYmxvY2tbMF0/LmZpZWxkcz8uZmluZChmID0+IGYubmFtZSA9PT0gJ3JlbGF0ZWRfdG8nKTtcbmlmIChyZWxhdGVkVG9GaWVsZCAmJiByZWxhdGVkVG9GaWVsZC5yZWxhdGlvbmFsQ29uZmlnKSB7XG4gICAgcmVsYXRlZFRvRmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWcgPSBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wbGFuX2RlX2N1ZW50YXMvcGxhbl9kZV9jdWVudGFzLmNvbmZpZy50c3gifQ==