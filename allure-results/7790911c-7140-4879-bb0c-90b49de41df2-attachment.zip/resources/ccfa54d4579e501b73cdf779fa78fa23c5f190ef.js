import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/leads/pages/LeadsEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/leads/pages/LeadsEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { LeadsFormPage } from "/src/features/leads/pages/LeadsFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { leadsModuleConfig } from "/src/features/leads/leads.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { update } from "/src/services/apiService.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const LeadsEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: lead, loading, error } = useCrudItem(leadsModuleConfig, id);
  const handleSave = async (data) => {
    try {
      await update(leadsModuleConfig.endpoint, id, data);
      toast.success("Lead actualizado con éxito");
      navigate(getListReturnPath(leadsModuleConfig.baseRoute));
    } catch (error2) {
      toast.error("Error al actualizar el lead");
      console.error(error2);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsEditPage.tsx",
    lineNumber: 46,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsEditPage.tsx",
    lineNumber: 47,
    columnNumber: 21
  }, this);
  if (!lead) return /* @__PURE__ */ jsxDEV("div", { children: "Lead no encontrado." }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsEditPage.tsx",
    lineNumber: 48,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    LeadsFormPage,
    {
      mode: "edit",
      initialData: lead,
      onSave: handleSave,
      loading,
      error
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/leads/pages/LeadsEditPage.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
};
_s(LeadsEditPage, "XxIt5YdoJeCfXNHa7+Vndq3wqak=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = LeadsEditPage;
var _c;
$RefreshReg$(_c, "LeadsEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/leads/pages/LeadsEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/leads/pages/LeadsEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6QnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUFvQztBQUM3QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNLEVBQUVDLEdBQUcsSUFBSVgsVUFBMEI7QUFDekMsUUFBTVksV0FBV1gsWUFBWTtBQUM3QixRQUFNLEVBQUVZLE1BQU1DLE1BQU1DLFNBQVNDLE1BQU0sSUFBSWIsWUFBa0JDLG1CQUFtQk8sRUFBRTtBQUU5RSxRQUFNTSxhQUFhLE9BQU9DLFNBQWU7QUFDckMsUUFBSTtBQUNBLFlBQU1YLE9BQWFILGtCQUFrQmUsVUFBVVIsSUFBS08sSUFBSTtBQUN4RFosWUFBTWMsUUFBUSw0QkFBNEI7QUFDMUNSLGVBQVNKLGtCQUFrQkosa0JBQWtCaUIsU0FBUyxDQUFDO0FBQUEsSUFDM0QsU0FBU0wsUUFBTztBQUNaVixZQUFNVSxNQUFNLDZCQUE2QjtBQUN6Q00sY0FBUU4sTUFBTUEsTUFBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUVBLE1BQUlELFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsS0FBTSxRQUFPLHVCQUFDLFNBQUksbUNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QjtBQUUxQyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTCxhQUFhQTtBQUFBQSxNQUNiLFFBQVFHO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUE7QUFBQSxJQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtpQjtBQUd6QjtBQUFFUCxHQTdCV0QsZUFBYTtBQUFBLFVBQ1BULFdBQ0VDLGFBQ3NCRSxXQUFXO0FBQUE7QUFBQW9CLEtBSHpDZDtBQUFhLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxlYWRzRm9ybVBhZ2UiLCJ1c2VDcnVkSXRlbSIsImxlYWRzTW9kdWxlQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJ0b2FzdCIsInVwZGF0ZSIsImdldExpc3RSZXR1cm5QYXRoIiwiTGVhZHNFZGl0UGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJsZWFkIiwibG9hZGluZyIsImVycm9yIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJlbmRwb2ludCIsInN1Y2Nlc3MiLCJiYXNlUm91dGUiLCJjb25zb2xlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZHNFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBMZWFkc0Zvcm1QYWdlIH0gZnJvbSAnLi9MZWFkc0Zvcm1QYWdlJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgbGVhZHNNb2R1bGVDb25maWcsIHR5cGUgTGVhZCB9IGZyb20gJy4uL2xlYWRzLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyB1cGRhdGUgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgTGVhZHNFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbTogbGVhZCwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPExlYWQ+KGxlYWRzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IExlYWQpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHVwZGF0ZTxMZWFkPihsZWFkc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgaWQhLCBkYXRhKTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0xlYWQgYWN0dWFsaXphZG8gY29uIMOpeGl0bycpO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobGVhZHNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYWN0dWFsaXphciBlbCBsZWFkJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFsZWFkKSByZXR1cm4gPGRpdj5MZWFkIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPExlYWRzRm9ybVBhZ2VcbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtsZWFkfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGVycm9yPXtlcnJvcn1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGVhZHMvcGFnZXMvTGVhZHNFZGl0UGFnZS50c3gifQ==