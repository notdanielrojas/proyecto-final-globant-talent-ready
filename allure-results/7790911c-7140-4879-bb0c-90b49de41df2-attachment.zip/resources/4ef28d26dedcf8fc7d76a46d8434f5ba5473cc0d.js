import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ProductHistoryModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/ProductHistoryModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useCrud } from "/src/hooks/useCrud.ts";
import { GenericTable } from "/src/components/common/GenericTable.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
const HistoryContent = ({
  moduleConfig,
  productId,
  clientId,
  columns
}) => {
  _s();
  const initialParams = useMemo(() => ({
    product_id: productId,
    client_id: clientId,
    per_page: 5
    // ✅ Limitar a 10 registros por página para mantener la estructura del modal
  }), [productId, clientId]);
  const {
    response,
    loading,
    handlePageChange,
    handleSort,
    sortBy,
    sortDirection
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } = useCrud(moduleConfig, initialParams);
  const data = response?.data ?? [];
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/components/common/ProductHistoryModal.tsx",
    lineNumber: 72,
    columnNumber: 23
  }, this);
  if (!loading && data.length === 0) {
    return /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-500 py-8", children: "No se encontraron registros históricos." }, void 0, false, {
      fileName: "/app/src/components/common/ProductHistoryModal.tsx",
      lineNumber: 75,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(
    GenericTable,
    {
      data,
      columns,
      baseRoute: "",
      onSort: handleSort,
      sortBy,
      sortDirection,
      paginationMeta: response?.meta ?? null,
      onPageChange: handlePageChange,
      onRowClick: () => {
      },
      disableEdit: true,
      disableActions: true
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/ProductHistoryModal.tsx",
      lineNumber: 79,
      columnNumber: 5
    },
    this
  );
};
_s(HistoryContent, "Q0wjpdw6Jro2OAPH4QQEp28obGM=", false, function() {
  return [useCrud];
});
_c = HistoryContent;
const createHistoryModuleConfig = (endpoint) => ({
  endpoint,
  moduleName: "Historial",
  moduleNamePlural: "Historial",
  baseRoute: "",
  detail: { displayNameKey: "id" },
  list: { columns: [] },
  form: { block: [] }
});
export const ProductHistoryModal = ({
  isOpen,
  onClose,
  title,
  endpoint,
  productId,
  clientId,
  columns
}) => {
  _s2();
  const moduleConfig = useMemo(() => createHistoryModuleConfig(endpoint), [endpoint]);
  if (!isOpen) return null;
  return (
    // Overlay y fondo oscuro
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-30 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity", children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "relative w-full max-w-7xl p-6 bg-white rounded-lg shadow-xl",
        onClick: (e) => e.stopPropagation(),
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-3 border-b", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-900", children: title }, void 0, false, {
              fileName: "/app/src/components/common/ProductHistoryModal.tsx",
              lineNumber: 144,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: onClose,
                className: "p-1 text-gray-400 rounded-full hover:bg-gray-100 hover:text-gray-600",
                children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
                  fileName: "/app/src/components/common/ProductHistoryModal.tsx",
                  lineNumber: 149,
                  columnNumber: 104
                }, this) }, void 0, false, {
                  fileName: "/app/src/components/common/ProductHistoryModal.tsx",
                  lineNumber: 149,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/common/ProductHistoryModal.tsx",
                lineNumber: 145,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/components/common/ProductHistoryModal.tsx",
            lineNumber: 143,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: productId ? /* @__PURE__ */ jsxDEV(
            HistoryContent,
            {
              moduleConfig,
              productId,
              clientId,
              columns
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/ProductHistoryModal.tsx",
              lineNumber: 158,
              columnNumber: 11
            },
            this
          ) : (
            // Muestra esto si el modal se abre por error sin ID
            /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
              fileName: "/app/src/components/common/ProductHistoryModal.tsx",
              lineNumber: 166,
              columnNumber: 11
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/components/common/ProductHistoryModal.tsx",
            lineNumber: 154,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4 mt-4 border-t", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
              children: "Cerrar"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/ProductHistoryModal.tsx",
              lineNumber: 172,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/components/common/ProductHistoryModal.tsx",
            lineNumber: 171,
            columnNumber: 17
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/common/ProductHistoryModal.tsx",
        lineNumber: 138,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/common/ProductHistoryModal.tsx",
      lineNumber: 136,
      columnNumber: 5
    }, this)
  );
};
_s2(ProductHistoryModal, "QS1HuLklzPInqV8oYpHwn4ICGx0=");
_c2 = ProductHistoryModal;
var _c, _c2;
$RefreshReg$(_c, "HistoryContent");
$RefreshReg$(_c2, "ProductHistoryModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/ProductHistoryModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/ProductHistoryModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0R3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuRHhCLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsZUFBZTtBQUV4QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBcUIvQixNQUFNQyxpQkFBaUIsQ0FBd0I7QUFBQSxFQUMzQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU1DLGdCQUFnQlYsUUFBUSxPQUFPO0FBQUEsSUFDakNXLFlBQVlMO0FBQUFBLElBQ1pNLFdBQVdMO0FBQUFBLElBQ1hNLFVBQVU7QUFBQTtBQUFBLEVBQ2QsSUFBSSxDQUFDUCxXQUFXQyxRQUFRLENBQUM7QUFJekIsUUFBTTtBQUFBLElBQ0ZPO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLEVBRUosSUFBSWxCLFFBQVdJLGNBQWNLLGFBQW9CO0FBRWpELFFBQU1VLE9BQU9OLFVBQVVNLFFBQVE7QUFFL0IsTUFBSUwsUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUVuQyxNQUFJLENBQUNBLFdBQVdLLEtBQUtDLFdBQVcsR0FBRztBQUMvQixXQUFPLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsdURBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUY7QUFBQSxFQUNoRztBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBVTtBQUFBLE1BQ1YsUUFBUUo7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGdCQUFnQkgsVUFBVVEsUUFBUTtBQUFBLE1BQ2xDLGNBQWNOO0FBQUFBLE1BQ2QsWUFBWSxNQUFNO0FBQUEsTUFBRTtBQUFBLE1BQ3BCLGFBQWE7QUFBQSxNQUNiLGdCQUFnQjtBQUFBO0FBQUEsSUFYcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV3lCO0FBR2pDO0FBR0FQLEdBbERNTCxnQkFBYztBQUFBLFVBc0JaSCxPQUFPO0FBQUE7QUFBQXNCLEtBdEJUbkI7QUErRE4sTUFBTW9CLDRCQUE0QkEsQ0FBQ0MsY0FBeUM7QUFBQSxFQUN4RUE7QUFBQUEsRUFDQUMsWUFBWTtBQUFBLEVBQ1pDLGtCQUFrQjtBQUFBLEVBQ2xCQyxXQUFXO0FBQUEsRUFDWEMsUUFBUSxFQUFFQyxnQkFBZ0IsS0FBSztBQUFBLEVBQy9CQyxNQUFNLEVBQUV2QixTQUFTLEdBQUc7QUFBQSxFQUNwQndCLE1BQU0sRUFBRUMsT0FBTyxHQUFHO0FBQ3RCO0FBRU8sYUFBTUMsc0JBQXNCLENBQXdCO0FBQUEsRUFDdkRDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FaO0FBQUFBLEVBQ0FuQjtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUN5QixNQUFNO0FBQUE4QixNQUFBO0FBRy9CLFFBQU1qQyxlQUFlTCxRQUFRLE1BQU13QiwwQkFBMEJDLFFBQVEsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFbEYsTUFBSSxDQUFDVSxPQUFRLFFBQU87QUFFcEI7QUFBQTtBQUFBLElBRUksdUJBQUMsU0FBSSxXQUFVLDJHQUVYO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxXQUFVO0FBQUEsUUFDVixTQUFTLENBQUNJLE1BQU1BLEVBQUVDLGdCQUFnQjtBQUFBLFFBR2xDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUNYO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHVDQUF1Q0gsbUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTRDtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUFZLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsMEJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGLEtBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZLO0FBQUE7QUFBQSxjQUpqTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLFFBR1Y5QixzQkFDRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0c7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQTtBQUFBLFlBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXFCO0FBQUE7QUFBQSxZQUlyQix1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsZUFadkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFTOEI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBbUg7QUFBQTtBQUFBLFlBSGpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBO0FBQUE7QUFBQSxNQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEwQ0EsS0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBO0FBRVI7QUFBRUUsSUFoRVdKLHFCQUFtQjtBQUFBTyxNQUFuQlA7QUFBbUIsSUFBQVgsSUFBQWtCO0FBQUFDLGFBQUFuQixJQUFBO0FBQUFtQixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZUNydWQiLCJHZW5lcmljVGFibGUiLCJMb2FkaW5nU3Bpbm5lciIsIkhpc3RvcnlDb250ZW50IiwibW9kdWxlQ29uZmlnIiwicHJvZHVjdElkIiwiY2xpZW50SWQiLCJjb2x1bW5zIiwiX3MiLCJpbml0aWFsUGFyYW1zIiwicHJvZHVjdF9pZCIsImNsaWVudF9pZCIsInBlcl9wYWdlIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiZGF0YSIsImxlbmd0aCIsIm1ldGEiLCJfYyIsImNyZWF0ZUhpc3RvcnlNb2R1bGVDb25maWciLCJlbmRwb2ludCIsIm1vZHVsZU5hbWUiLCJtb2R1bGVOYW1lUGx1cmFsIiwiYmFzZVJvdXRlIiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJsaXN0IiwiZm9ybSIsImJsb2NrIiwiUHJvZHVjdEhpc3RvcnlNb2RhbCIsImlzT3BlbiIsIm9uQ2xvc2UiLCJ0aXRsZSIsIl9zMiIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEhpc3RvcnlNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RIaXN0b3J5TW9kYWwudHN4XG5pbXBvcnQgeyB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHR5cGUgeyBDb2x1bW5EZWZpbml0aW9uLCBNb2R1bGVDb25maWcgfSBmcm9tICcuL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBHZW5lcmljVGFibGUgfSBmcm9tICcuL0dlbmVyaWNUYWJsZSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL3VpL0xvYWRpbmdTcGlubmVyJztcblxuLy8gSW50ZXJmYXogZ2Vuw6lyaWNhIHBhcmEgbG9zIGl0ZW1zIGRlbCBoaXN0b3JpYWxcbmludGVyZmFjZSBIaXN0b3J5SXRlbSB7XG4gICAgaWQ6IG51bWJlciB8IHN0cmluZztcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIFtrZXk6IHN0cmluZ106IGFueTtcbn1cblxuLy8gUHJvcHMgcGFyYSBlbCBOVUVWTyBjb21wb25lbnRlIGludGVybm9cbmludGVyZmFjZSBIaXN0b3J5Q29udGVudFByb3BzPFQ+IHtcbiAgICBtb2R1bGVDb25maWc6IE1vZHVsZUNvbmZpZzxUPjtcbiAgICBwcm9kdWN0SWQ6IG51bWJlcjtcbiAgICBjbGllbnRJZDogbnVtYmVyO1xuICAgIGNvbHVtbnM6IENvbHVtbkRlZmluaXRpb248VD5bXTtcbn1cblxuLyoqXG4gKiBDb21wb25lbnRlIGludGVybm8gcXVlIFPDjSBsbGFtYSBhbCBob29rIHVzZUNydWQuXG4gKiBTb2xvIHNlIHJlbmRlcml6YSBjdWFuZG8gZXN0YW1vcyBzZWd1cm9zIGRlIHRlbmVyIHVuIHByb2R1Y3RJZC5cbiAqL1xuY29uc3QgSGlzdG9yeUNvbnRlbnQgPSA8VCBleHRlbmRzIEhpc3RvcnlJdGVtPih7XG4gICAgbW9kdWxlQ29uZmlnLFxuICAgIHByb2R1Y3RJZCxcbiAgICBjbGllbnRJZCxcbiAgICBjb2x1bW5zXG59OiBIaXN0b3J5Q29udGVudFByb3BzPFQ+KSA9PiB7XG4gICAgY29uc3QgaW5pdGlhbFBhcmFtcyA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxuICAgICAgICBjbGllbnRfaWQ6IGNsaWVudElkLFxuICAgICAgICBwZXJfcGFnZTogNSwgLy8g4pyFIExpbWl0YXIgYSAxMCByZWdpc3Ryb3MgcG9yIHDDoWdpbmEgcGFyYSBtYW50ZW5lciBsYSBlc3RydWN0dXJhIGRlbCBtb2RhbFxuICAgIH0pLCBbcHJvZHVjdElkLCBjbGllbnRJZF0pO1xuXG4gICAgLy8gRWwgaG9vayBzZSBsbGFtYSBBUVXDjSwgY29uIGxvcyBmaWx0cm9zIGluaWNpYWxlcyBjb3JyZWN0b3MuXG4gICAgLy8gRXN0byBzZSBlamVjdXRhcsOhIFVOQSBTT0xBIFZFWi5cbiAgICBjb25zdCB7XG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgICBsb2FkaW5nLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgfSA9IHVzZUNydWQ8VD4obW9kdWxlQ29uZmlnLCBpbml0aWFsUGFyYW1zIGFzIGFueSk7XG5cbiAgICBjb25zdCBkYXRhID0gcmVzcG9uc2U/LmRhdGEgPz8gW107XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcblxuICAgIGlmICghbG9hZGluZyAmJiBkYXRhLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCBweS04XCI+Tm8gc2UgZW5jb250cmFyb24gcmVnaXN0cm9zIGhpc3TDs3JpY29zLjwvcD47XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNUYWJsZVxuICAgICAgICAgICAgZGF0YT17ZGF0YX1cbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XG4gICAgICAgICAgICBiYXNlUm91dGU9XCJcIiAvLyBObyBoYXkgbmF2ZWdhY2nDs25cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIHBhZ2luYXRpb25NZXRhPXtyZXNwb25zZT8ubWV0YSA/PyBudWxsfVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Sb3dDbGljaz17KCkgPT4geyB9fSAvLyBObyBoYWNlciBuYWRhIGFsIGhhY2VyIGNsaWNcbiAgICAgICAgICAgIGRpc2FibGVFZGl0PXt0cnVlfSAvLyBPY3VsdGFyIGJvdMOzbiBkZSBlZGl0YXJcbiAgICAgICAgICAgIGRpc2FibGVBY3Rpb25zPXt0cnVlfVxuICAgICAgICAvPlxuICAgICk7XG59O1xuXG5cbi8vIFByb3BzIHF1ZSBlbCBtb2RhbCBuZWNlc2l0YVxuaW50ZXJmYWNlIFByb2R1Y3RIaXN0b3J5TW9kYWxQcm9wczxUPiB7XG4gICAgaXNPcGVuOiBib29sZWFuO1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBlbmRwb2ludDogc3RyaW5nOyAvLyBFbCBlbmRwb2ludCBiYXNlIChlajogJ3Byb2R1Y3RzL3ByaWNlLWxpc3QnKVxuICAgIHByb2R1Y3RJZDogbnVtYmVyO1xuICAgIGNsaWVudElkOiBudW1iZXI7IC8vIEVsIElEIGRlbCBwcm9kdWN0byBhIGZpbHRyYXJcbiAgICBjb2x1bW5zOiBDb2x1bW5EZWZpbml0aW9uPFQ+W107XG59XG5cbi8vIENyZWFtb3MgdW5hIFwiY29uZmlndXJhY2nDs24gZmFsc2FcIiBxdWUgZWwgaG9vayB1c2VDcnVkIG5lY2VzaXRhXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuY29uc3QgY3JlYXRlSGlzdG9yeU1vZHVsZUNvbmZpZyA9IChlbmRwb2ludDogc3RyaW5nKTogTW9kdWxlQ29uZmlnPGFueT4gPT4gKHtcbiAgICBlbmRwb2ludDogZW5kcG9pbnQsXG4gICAgbW9kdWxlTmFtZTogJ0hpc3RvcmlhbCcsXG4gICAgbW9kdWxlTmFtZVBsdXJhbDogJ0hpc3RvcmlhbCcsXG4gICAgYmFzZVJvdXRlOiAnJyxcbiAgICBkZXRhaWw6IHsgZGlzcGxheU5hbWVLZXk6ICdpZCcgfSxcbiAgICBsaXN0OiB7IGNvbHVtbnM6IFtdIH0sXG4gICAgZm9ybTogeyBibG9jazogW10gfVxufSk7XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SGlzdG9yeU1vZGFsID0gPFQgZXh0ZW5kcyBIaXN0b3J5SXRlbT4oe1xuICAgIGlzT3BlbixcbiAgICBvbkNsb3NlLFxuICAgIHRpdGxlLFxuICAgIGVuZHBvaW50LFxuICAgIHByb2R1Y3RJZCxcbiAgICBjbGllbnRJZCxcbiAgICBjb2x1bW5zLFxufTogUHJvZHVjdEhpc3RvcnlNb2RhbFByb3BzPFQ+KSA9PiB7XG5cbiAgICAvLyBFbCBtb2RhbCBhaG9yYSBzb2xvIGNyZWEgbGEgY29uZmlnXG4gICAgY29uc3QgbW9kdWxlQ29uZmlnID0gdXNlTWVtbygoKSA9PiBjcmVhdGVIaXN0b3J5TW9kdWxlQ29uZmlnKGVuZHBvaW50KSwgW2VuZHBvaW50XSk7XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAvLyBPdmVybGF5IHkgZm9uZG8gb3NjdXJvXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXNtIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxuICAgICAgICAgICAgey8qIENvbnRlbmVkb3IgZGVsIE1vZGFsICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy03eGwgcC02IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXhsXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0gLy8gRXZpdGEgcXVlIHNlIGNpZXJyZSBhbCBoYWNlciBjbGljIGFkZW50cm9cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7LyogQ2FiZWNlcmEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItMyBib3JkZXItYlwiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj57dGl0bGV9PC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LWdyYXktNDAwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTYgaC02XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIiAvPjwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb250ZW5pZG8gKFRhYmxhKSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFJlbmRlcml6YWRvIGNvbmRpY2lvbmFsICovfVxuICAgICAgICAgICAgICAgICAgICB7LyogU29sbyByZW5kZXJpemFtb3MgZWwgY29udGVuaWRvICh5IGxsYW1hbW9zIGFsIGhvb2spIHNpIHRlbmVtb3MgZWwgSUQgKi99XG4gICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0SWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8SGlzdG9yeUNvbnRlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVDb25maWc9e21vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWQ9e3Byb2R1Y3RJZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGllbnRJZD17Y2xpZW50SWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBNdWVzdHJhIGVzdG8gc2kgZWwgbW9kYWwgc2UgYWJyZSBwb3IgZXJyb3Igc2luIElEXG4gICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTQgbXQtNCBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RIaXN0b3J5TW9kYWwudHN4In0=