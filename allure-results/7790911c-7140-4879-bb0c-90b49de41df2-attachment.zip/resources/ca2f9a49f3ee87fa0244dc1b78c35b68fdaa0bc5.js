import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/vendedores/pages/VendedoresEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/vendedores/pages/VendedoresEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import __vite__cjsImport9_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport9_react["useMemo"];
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const VendedoresEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error, saveItem } = useCrudItem(vendedoresModuleConfig, id);
  const initialData = useMemo(() => {
    if (!item) return void 0;
    return {
      ...item,
      district_name: item.district_name || ""
    };
  }, [item]);
  const handleSave = async (data) => {
    const updatedItem = await saveItem(data);
    if (updatedItem) {
      toast.info(`Vendedor actualizado con éxito!`);
      navigate(getListReturnPath(vendedoresModuleConfig.baseRoute));
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresEditPage.tsx",
    lineNumber: 52,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresEditPage.tsx",
    lineNumber: 53,
    columnNumber: 21
  }, this);
  if (!initialData) return /* @__PURE__ */ jsxDEV("div", { children: "Vendedor no encontrado." }, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresEditPage.tsx",
    lineNumber: 54,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: vendedoresModuleConfig,
      initialData,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/vendedores/pages/VendedoresEditPage.tsx",
      lineNumber: 57,
      columnNumber: 5
    },
    this
  );
};
_s(VendedoresEditPage, "BVwHB5b24FKzcV5TZJoWvyMK804=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = VendedoresEditPage;
var _c;
$RefreshReg$(_c, "VendedoresEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/vendedores/pages/VendedoresEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/vendedores/pages/VendedoresEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0N3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoQ3hCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsOEJBQTZDO0FBQ3RELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxxQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUNwQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVgsVUFBMEI7QUFDekMsUUFBTVksV0FBV1gsWUFBWTtBQUM3QixRQUFNLEVBQUVZLE1BQU1DLFNBQVNDLE9BQU9DLFNBQVMsSUFBSVosWUFBc0JELHdCQUF3QlEsRUFBRTtBQUUzRixRQUFNTSxjQUFjVixRQUFRLE1BQU07QUFDOUIsUUFBSSxDQUFDTSxLQUFNLFFBQU9LO0FBR2xCLFdBQU87QUFBQSxNQUNILEdBQUdMO0FBQUFBLE1BQ0hNLGVBQWVOLEtBQUtNLGlCQUFpQjtBQUFBLElBQ3pDO0FBQUEsRUFDSixHQUFHLENBQUNOLElBQUksQ0FBQztBQUVULFFBQU1PLGFBQWEsT0FBT0MsU0FBbUI7QUFDekMsVUFBTUMsY0FBYyxNQUFNTixTQUFTSyxJQUFJO0FBQ3ZDLFFBQUlDLGFBQWE7QUFDYmpCLFlBQU1rQixLQUFLLGlDQUFpQztBQUM1Q1gsZUFBU0osa0JBQWtCTCx1QkFBdUJxQixTQUFTLENBQUM7QUFBQSxJQUNoRTtBQUFBLEVBQ0o7QUFFQSxNQUFJVixRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNFLFlBQWEsUUFBTyx1QkFBQyxTQUFJLHVDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEI7QUFFckQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUWQ7QUFBQUEsTUFDUjtBQUFBLE1BQ0EsUUFBUWlCO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJZTtBQUd2QjtBQUFFVixHQW5DV0Qsb0JBQWtCO0FBQUEsVUFDWlQsV0FDRUMsYUFDMEJHLFdBQVc7QUFBQTtBQUFBcUIsS0FIN0NoQjtBQUFrQixJQUFBZ0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwidmVuZGVkb3Jlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJMb2FkaW5nU3Bpbm5lciIsInVzZU1lbW8iLCJnZXRMaXN0UmV0dXJuUGF0aCIsIlZlbmRlZG9yZXNFZGl0UGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJsb2FkaW5nIiwiZXJyb3IiLCJzYXZlSXRlbSIsImluaXRpYWxEYXRhIiwidW5kZWZpbmVkIiwiZGlzdHJpY3RfbmFtZSIsImhhbmRsZVNhdmUiLCJkYXRhIiwidXBkYXRlZEl0ZW0iLCJpbmZvIiwiYmFzZVJvdXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVmVuZGVkb3Jlc0VkaXRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljRm9ybVBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVBhZ2UnO1xuaW1wb3J0IHsgdmVuZGVkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBWZW5kZWRvciB9IGZyb20gJy4uL3ZlbmRlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgVmVuZGVkb3Jlc0VkaXRQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBpdGVtLCBsb2FkaW5nLCBlcnJvciwgc2F2ZUl0ZW0gfSA9IHVzZUNydWRJdGVtPFZlbmRlZG9yPih2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBpbml0aWFsRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIWl0ZW0pIHJldHVybiB1bmRlZmluZWQ7XG5cbiAgICAgICAgLy8gQ3JlYW1vcyBlbCBjYW1wbyAnZGlzdHJpY3RfbmFtZScgcXVlIGVsIGZvcm11bGFyaW8gZ2Vuw6lyaWNvIGVzcGVyYVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgIGRpc3RyaWN0X25hbWU6IGl0ZW0uZGlzdHJpY3RfbmFtZSB8fCAnJyxcbiAgICAgICAgfTtcbiAgICB9LCBbaXRlbV0pO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBWZW5kZWRvcikgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkSXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAodXBkYXRlZEl0ZW0pIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oYFZlbmRlZG9yIGFjdHVhbGl6YWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aCh2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWluaXRpYWxEYXRhKSByZXR1cm4gPGRpdj5WZW5kZWRvciBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17dmVuZGVkb3Jlc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsRGF0YX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3ZlbmRlZG9yZXMvcGFnZXMvVmVuZGVkb3Jlc0VkaXRQYWdlLnRzeCJ9