import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/NavDropdownPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/NavDropdownPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
export const NavDropdownPanel = ({ items, onNavigate }) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "min-w-[240px] py-2 bg-white rounded-lg shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-0.5", children: items.map(
    (item) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
      NavLink,
      {
        to: item.path,
        onClick: onNavigate,
        className: ({ isActive }) => `flex items-start gap-3 px-4 py-2.5 text-left transition-colors hover:bg-gray-50 ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-700"}`,
        children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex-shrink-0 mt-0.5 text-indigo-600", children: item.icon }, void 0, false, {
            fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
            lineNumber: 48,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium block", children: item.label }, void 0, false, {
              fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
              lineNumber: 52,
              columnNumber: 33
            }, this),
            item.description && /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 block mt-0.5", children: item.description }, void 0, false, {
              fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
              lineNumber: 54,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
            lineNumber: 51,
            columnNumber: 29
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
        lineNumber: 41,
        columnNumber: 25
      },
      this
    ) }, item.path, false, {
      fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
      lineNumber: 40,
      columnNumber: 9
    }, this)
  ) }, void 0, false, {
    fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
    lineNumber: 38,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/layouts/NavDropdownPanel.tsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
};
_c = NavDropdownPanel;
var _c;
$RefreshReg$(_c, "NavDropdownPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/NavDropdownPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/NavDropdownPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEI0Qjs7Ozs7Ozs7Ozs7Ozs7OztBQTNCNUIsU0FBU0EsZUFBZTtBQWNqQixhQUFNQyxtQkFBbUJBLENBQUMsRUFBRUMsT0FBT0MsV0FBa0MsTUFBTTtBQUM5RSxTQUNJLHVCQUFDLFNBQUksV0FBVSwyRUFDWCxpQ0FBQyxRQUFHLFdBQVUsZUFDVEQsZ0JBQU1FO0FBQUFBLElBQUksQ0FBQ0MsU0FDUix1QkFBQyxRQUNHO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxJQUFJQSxLQUFLQztBQUFBQSxRQUNULFNBQVNIO0FBQUFBLFFBQ1QsV0FBVyxDQUFDLEVBQUVJLFNBQVMsTUFDbkIsbUZBQW1GQSxXQUFXLGlDQUFpQyxlQUFlO0FBQUEsUUFHbEo7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0NBQ1hGLGVBQUtHLFFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGtCQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFCQUFxQkgsZUFBS0ksU0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUMvQ0osS0FBS0ssZUFDRix1QkFBQyxVQUFLLFdBQVUsc0NBQ1hMLGVBQUtLLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBO0FBQUE7QUFBQSxNQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFrQkEsS0FuQktMLEtBQUtDLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLEVBQ0gsS0F2Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQSxLQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJBO0FBRVI7QUFBRUssS0E5QldWO0FBQWdCLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOYXZMaW5rIiwiTmF2RHJvcGRvd25QYW5lbCIsIml0ZW1zIiwib25OYXZpZ2F0ZSIsIm1hcCIsIml0ZW0iLCJwYXRoIiwiaXNBY3RpdmUiLCJpY29uIiwibGFiZWwiLCJkZXNjcmlwdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5hdkRyb3Bkb3duUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTmF2TGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuXG5leHBvcnQgaW50ZXJmYWNlIE5hdkRyb3Bkb3duSXRlbSB7XG4gICAgcGF0aDogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgaWNvbjogUmVhY3ROb2RlO1xuICAgIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgTmF2RHJvcGRvd25QYW5lbFByb3BzIHtcbiAgICBpdGVtczogTmF2RHJvcGRvd25JdGVtW107XG4gICAgb25OYXZpZ2F0ZT86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBOYXZEcm9wZG93blBhbmVsID0gKHsgaXRlbXMsIG9uTmF2aWdhdGUgfTogTmF2RHJvcGRvd25QYW5lbFByb3BzKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMjQwcHhdIHB5LTIgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMC41XCI+XG4gICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpdGVtLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17aXRlbS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uTmF2aWdhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1zdGFydCBnYXAtMyBweC00IHB5LTIuNSB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctZ3JheS01MCAke2lzQWN0aXZlID8gJ2JnLWluZGlnby01MCB0ZXh0LWluZGlnby03MDAnIDogJ3RleHQtZ3JheS03MDAnfWBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBtdC0wLjUgdGV4dC1pbmRpZ28tNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmljb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIGJsb2NrXCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgYmxvY2sgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZEcm9wZG93blBhbmVsLnRzeCJ9