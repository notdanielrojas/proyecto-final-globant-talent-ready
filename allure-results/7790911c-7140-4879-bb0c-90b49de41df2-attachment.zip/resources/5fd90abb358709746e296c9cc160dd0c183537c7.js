import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/fractionings/pages/FractioningListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/fractionings/pages/FractioningListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { fractioningsModuleConfig } from "/src/features/fractionings/fractionings.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const FractioningListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(fractioningsModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/fractionings/pages/FractioningListPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: fractioningsModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/fractionings/pages/FractioningListPage.tsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
};
_s(FractioningListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = FractioningListPage;
var _c;
$RefreshReg$(_c, "FractioningListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/fractionings/pages/FractioningListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/fractionings/pages/FractioningListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxnQ0FBa0Q7QUFDM0QsU0FBU0MsZUFBZTtBQUN4QixTQUFTQywrQkFBK0I7QUFFakMsYUFBTUMsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFFckMsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSWYsUUFBcUJELDBCQUEwQkUsd0JBQXdCLENBQUM7QUFFNUUsTUFBSU0sTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBR3ZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFSO0FBQUFBLE1BQ1Isb0JBQW9CSztBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFDLFFBQVE7QUFBQSxNQUNqQyxpQkFBaUJELGFBQWFFLGFBQWE7QUFBQSxNQUMzQyxlQUFlRixhQUFhRyxXQUFXO0FBQUEsTUFDdkMsdUJBQXVCO0FBQUE7QUFBQSxJQWYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFlZ0M7QUFHeEM7QUFBRWYsR0F2Q1dELHFCQUFtQjtBQUFBLFVBZXhCRixPQUFPO0FBQUE7QUFBQW1CLEtBZkZqQjtBQUFtQixJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkdlbmVyaWNMaXN0UGFnZSIsImZyYWN0aW9uaW5nc01vZHVsZUNvbmZpZyIsInVzZUNydWQiLCJnZXREZWZhdWx0TGlzdERhdGVSYW5nZSIsIkZyYWN0aW9uaW5nTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJ0ZXJtIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZyYWN0aW9uaW5nTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBmcmFjdGlvbmluZ3NNb2R1bGVDb25maWcsIHR5cGUgRnJhY3Rpb25pbmcgfSBmcm9tICcuLi9mcmFjdGlvbmluZ3MuY29uZmlnLnRzeCc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuXG5leHBvcnQgY29uc3QgRnJhY3Rpb25pbmdMaXN0UGFnZSA9ICgpID0+IHtcbiAgICAvLyBVc2Ftb3MgbnVlc3RybyBob29rIGdlbsOpcmljbyBwYXJhIHRvZGEgbGEgbMOzZ2ljYSBkZSBkYXRvc1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGlzQXBwZW5kaW5nLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgZGVsZXRlSXRlbSxcbiAgICAgICAgaGFuZGxlU29ydCxcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVMb2FkTW9yZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8RnJhY3Rpb25pbmc+KGZyYWN0aW9uaW5nc01vZHVsZUNvbmZpZywgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UoKSk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICAvLyBQYXNhbW9zIGxhIGNvbmZpZ3VyYWNpw7NuIHkgbG9zIGRhdG9zIGFsIGNvbXBvbmVudGUgZ2Vuw6lyaWNvXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxGcmFjdGlvbmluZz5cbiAgICAgICAgICAgIGNvbmZpZz17ZnJhY3Rpb25pbmdzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX0gLy8gPC0tIEhhYmlsaXRhbW9zIGxhIGZ1bmNpw7NuIGRlIGJvcnJhZG9cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2ZyYWN0aW9uaW5ncy9wYWdlcy9GcmFjdGlvbmluZ0xpc3RQYWdlLnRzeCJ9