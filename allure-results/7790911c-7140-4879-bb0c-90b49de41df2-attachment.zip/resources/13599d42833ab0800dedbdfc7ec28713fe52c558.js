import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bancos/pages/BancosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/bancos/pages/BancosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { bancosModuleConfig } from "/src/features/bancos/bancos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const BancosDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: banco, loading, error } = useCrudItem(bancosModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del banco..." }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosDetailPage.tsx",
    lineNumber: 29,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 21
  }, this);
  if (!banco) return /* @__PURE__ */ jsxDEV("div", { children: "Banco no encontrado." }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 22
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: bancosModuleConfig, item: banco }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(BancosDetailPage, "KkgrhHq4aDVapZiPNEOzezDmbt0=", false, function() {
  return [useParams, useCrudItem];
});
_c = BancosDetailPage;
var _c;
$RefreshReg$(_c, "BancosDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/bancos/pages/BancosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/bancos/pages/BancosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDBCQUFzQztBQUMvQyxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsT0FBT0MsU0FBU0MsTUFBTSxJQUFJUCxZQUFtQkQsb0JBQW9CSSxFQUFFO0FBRWpGLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLDZDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0M7QUFDdEQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsTUFBTyxRQUFPLHVCQUFDLFNBQUksb0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QjtBQUU1QyxTQUFPLHVCQUFDLHFCQUFrQixRQUFRTixvQkFBb0IsTUFBTU0sU0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyRDtBQUN0RTtBQUFFSCxHQVRXRCxrQkFBZ0I7QUFBQSxVQUNWSixXQUN5QkcsV0FBVztBQUFBO0FBQUFRLEtBRjFDUDtBQUFnQixJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiR2VuZXJpY0RldGFpbFBhZ2UiLCJiYW5jb3NNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIkJhbmNvc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwiaXRlbSIsImJhbmNvIiwibG9hZGluZyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmFuY29zRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljRGV0YWlsUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNEZXRhaWxQYWdlJztcbmltcG9ydCB7IGJhbmNvc01vZHVsZUNvbmZpZywgdHlwZSBCYW5jbyB9IGZyb20gJy4uL2JhbmNvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5cbmV4cG9ydCBjb25zdCBCYW5jb3NEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW06IGJhbmNvLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08QmFuY28+KGJhbmNvc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2PkNhcmdhbmRvIGRldGFsbGUgZGVsIGJhbmNvLi4uPC9kaXY+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWJhbmNvKSByZXR1cm4gPGRpdj5CYW5jbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXtiYW5jb3NNb2R1bGVDb25maWd9IGl0ZW09e2JhbmNvfSAvPjtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2JhbmNvcy9wYWdlcy9CYW5jb3NEZXRhaWxQYWdlLnRzeCJ9