import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bancos/pages/BancosEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/bancos/pages/BancosEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { bancosModuleConfig } from "/src/features/bancos/bancos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
export const BancosEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: banco, loading, error, saveItem } = useCrudItem(bancosModuleConfig, id);
  const handleSave = async (data) => {
    const saved = await saveItem(data);
    if (saved) {
      toast.info(`Banco actualizado con éxito!`);
      navigate("/bancos");
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del banco..." }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosEditPage.tsx",
    lineNumber: 39,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosEditPage.tsx",
    lineNumber: 40,
    columnNumber: 21
  }, this);
  if (!banco) return /* @__PURE__ */ jsxDEV("div", { children: "Banco no encontrado." }, void 0, false, {
    fileName: "/app/src/features/bancos/pages/BancosEditPage.tsx",
    lineNumber: 41,
    columnNumber: 22
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: bancosModuleConfig,
      initialData: banco,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/bancos/pages/BancosEditPage.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
};
_s(BancosEditPage, "OBj2K3JXXeixKxLvz6uzZDfL3wQ=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = BancosEditPage;
var _c;
$RefreshReg$(_c, "BancosEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/bancos/pages/BancosEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/bancos/pages/BancosEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuQnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsMEJBQXNDO0FBQy9DLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBRWYsYUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxHQUFHLElBQUlSLFVBQTBCO0FBQ3pDLFFBQU1TLFdBQVdSLFlBQVk7QUFDN0IsUUFBTSxFQUFFUyxNQUFNQyxPQUFPQyxTQUFTQyxPQUFPQyxTQUFTLElBQUlWLFlBQW1CRCxvQkFBb0JLLEVBQUU7QUFFM0YsUUFBTU8sYUFBYSxPQUFPQyxTQUFnQjtBQUN0QyxVQUFNQyxRQUFRLE1BQU1ILFNBQVNFLElBQUk7QUFDakMsUUFBSUMsT0FBTztBQUNQWixZQUFNYSxLQUFLLDhCQUE4QjtBQUN6Q1QsZUFBUyxTQUFTO0FBQUEsSUFDdEI7QUFBQSxFQUNKO0FBRUEsTUFBSUcsUUFBUyxRQUFPLHVCQUFDLFNBQUksMkNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnQztBQUNwRCxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDRixNQUFPLFFBQU8sdUJBQUMsU0FBSSxvQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlCO0FBRTVDLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFSO0FBQUFBLE1BQ1IsYUFBYVE7QUFBQUEsTUFDYixRQUFRSTtBQUFBQSxNQUNSLE1BQUs7QUFBQTtBQUFBLElBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWU7QUFHdkI7QUFBRVIsR0F6QldELGdCQUFjO0FBQUEsVUFDUk4sV0FDRUMsYUFDaUNHLFdBQVc7QUFBQTtBQUFBZSxLQUhwRGI7QUFBYyxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJiYW5jb3NNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInRvYXN0IiwiQmFuY29zRWRpdFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJpdGVtIiwiYmFuY28iLCJsb2FkaW5nIiwiZXJyb3IiLCJzYXZlSXRlbSIsImhhbmRsZVNhdmUiLCJkYXRhIiwic2F2ZWQiLCJpbmZvIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmFuY29zRWRpdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyBiYW5jb3NNb2R1bGVDb25maWcsIHR5cGUgQmFuY28gfSBmcm9tICcuLi9iYW5jb3MuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5cbmV4cG9ydCBjb25zdCBCYW5jb3NFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbTogYmFuY28sIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08QmFuY28+KGJhbmNvc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBCYW5jbykgPT4ge1xuICAgICAgICBjb25zdCBzYXZlZCA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAoc2F2ZWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oYEJhbmNvIGFjdHVhbGl6YWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2JhbmNvcycpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkYXRvcyBkZWwgYmFuY28uLi48L2Rpdj47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghYmFuY28pIHJldHVybiA8ZGl2PkJhbmNvIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgY29uZmlnPXtiYW5jb3NNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17YmFuY299XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiZWRpdFwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2JhbmNvcy9wYWdlcy9CYW5jb3NFZGl0UGFnZS50c3gifQ==