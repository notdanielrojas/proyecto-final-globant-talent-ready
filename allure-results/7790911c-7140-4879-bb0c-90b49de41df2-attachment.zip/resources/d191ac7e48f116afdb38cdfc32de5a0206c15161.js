import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/reportes/ReportFooterSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/reportes/ReportFooterSection.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { formatValue } from "/src/utils/formatters.ts";
function formatFooterLineValue(value, format, moneySymbol = "$") {
  switch (format) {
    case "money":
      return /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-gray-900", children: formatValue(value, "currency", { moneySymbol }) }, void 0, false, {
        fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
        lineNumber: 26,
        columnNumber: 14
      }, this);
    case "number":
      return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 tabular-nums", children: formatValue(value, "number") }, void 0, false, {
        fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
        lineNumber: 28,
        columnNumber: 14
      }, this);
    default:
      return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900", children: String(value ?? "") }, void 0, false, {
        fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
        lineNumber: 30,
        columnNumber: 14
      }, this);
  }
}
export function ReportFooterSection({
  footer,
  moneySymbol = "$"
}) {
  const blocks = footer.blocks || [];
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: blocks.map((block, bi) => {
    if (block.type !== "summary_lines") return null;
    const b = block;
    const lines = b.lines || [];
    if (lines.length === 0) return null;
    return /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: lines.map(
      (line, li) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 text-sm",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: line.label }, void 0, false, {
              fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
              lineNumber: 58,
              columnNumber: 37
            }, this),
            formatFooterLineValue(line.value, line.format, moneySymbol)
          ]
        },
        li,
        true,
        {
          fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
          lineNumber: 54,
          columnNumber: 15
        },
        this
      )
    ) }, bi, false, {
      fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
      lineNumber: 52,
      columnNumber: 13
    }, this);
  }) }, void 0, false, {
    fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
    lineNumber: 45,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/features/reportes/ReportFooterSection.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
}
_c = ReportFooterSection;
var _c;
$RefreshReg$(_c, "ReportFooterSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/reportes/ReportFooterSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/reportes/ReportFooterSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTW1COzs7Ozs7Ozs7Ozs7Ozs7O0FBTm5CLFNBQVNBLG1CQUF3QztBQUdqRCxTQUFTQyxzQkFBc0JDLE9BQXdCQyxRQUFpQkMsY0FBOEIsS0FBSztBQUN2RyxVQUFRRCxRQUFNO0FBQUEsSUFDVixLQUFLO0FBQ0QsYUFBTyx1QkFBQyxVQUFLLFdBQVUsMkJBQTJCSCxzQkFBWUUsT0FBTyxZQUFZLEVBQUVFLFlBQVksQ0FBQyxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJGO0FBQUEsSUFDdEcsS0FBSztBQUNELGFBQU8sdUJBQUMsVUFBSyxXQUFVLDhCQUE4Qkosc0JBQVlFLE9BQU8sUUFBUSxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsSUFDdEY7QUFDSSxhQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJHLGlCQUFPSCxTQUFTLEVBQUUsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLEVBQ3BFO0FBQ0o7QUFFTyxnQkFBU0ksb0JBQW9CO0FBQUEsRUFDaENDO0FBQUFBLEVBQ0FILGNBQWM7QUFJbEIsR0FBRztBQUNDLFFBQU1JLFNBQVNELE9BQU9DLFVBQVU7QUFFaEMsU0FDSSx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsU0FBSSxXQUFVLGFBQ1ZBLGlCQUFPQyxJQUFJLENBQUNDLE9BQU9DLE9BQU87QUFDdkIsUUFBSUQsTUFBTUUsU0FBUyxnQkFBaUIsUUFBTztBQUMzQyxVQUFNQyxJQUFJSDtBQUNWLFVBQU1JLFFBQVFELEVBQUVDLFNBQVM7QUFDekIsUUFBSUEsTUFBTUMsV0FBVyxFQUFHLFFBQU87QUFDL0IsV0FDSSx1QkFBQyxTQUFhLFdBQVUsZUFDbkJELGdCQUFNTDtBQUFBQSxNQUFJLENBQUNPLE1BQU1DLE9BQ2Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVHLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDZCQUE2QkQsZUFBS0UsU0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUN2RGpCLHNCQUFzQmUsS0FBS2QsT0FBT2MsS0FBS2IsUUFBUUMsV0FBVztBQUFBO0FBQUE7QUFBQSxRQUp0RGE7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxJQUNILEtBVEtOLElBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsRUFFUixDQUFDLEtBbkJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkEsS0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVSO0FBQUNRLEtBbENlYjtBQUFtQixJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiZm9ybWF0VmFsdWUiLCJmb3JtYXRGb290ZXJMaW5lVmFsdWUiLCJ2YWx1ZSIsImZvcm1hdCIsIm1vbmV5U3ltYm9sIiwiU3RyaW5nIiwiUmVwb3J0Rm9vdGVyU2VjdGlvbiIsImZvb3RlciIsImJsb2NrcyIsIm1hcCIsImJsb2NrIiwiYmkiLCJ0eXBlIiwiYiIsImxpbmVzIiwibGVuZ3RoIiwibGluZSIsImxpIiwibGFiZWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZXBvcnRGb290ZXJTZWN0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JtYXRWYWx1ZSwgdHlwZSBDdXJyZW5jeVN5bWJvbCB9IGZyb20gJy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHR5cGUgeyBSZXBvcnRGb290ZXJCbG9ja1N1bW1hcnlMaW5lcywgUmVwb3J0Rm9vdGVyTWV0YSB9IGZyb20gJy4vcmVwb3J0Rm9vdGVyLnR5cGVzJztcblxuZnVuY3Rpb24gZm9ybWF0Rm9vdGVyTGluZVZhbHVlKHZhbHVlOiBzdHJpbmcgfCBudW1iZXIsIGZvcm1hdD86IHN0cmluZywgbW9uZXlTeW1ib2w6IEN1cnJlbmN5U3ltYm9sID0gJyQnKSB7XG4gICAgc3dpdGNoIChmb3JtYXQpIHtcbiAgICAgICAgY2FzZSAnbW9uZXknOlxuICAgICAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWdyYXktOTAwXCI+e2Zvcm1hdFZhbHVlKHZhbHVlLCAnY3VycmVuY3knLCB7IG1vbmV5U3ltYm9sIH0pfTwvc3Bhbj47XG4gICAgICAgIGNhc2UgJ251bWJlcic6XG4gICAgICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCB0YWJ1bGFyLW51bXNcIj57Zm9ybWF0VmFsdWUodmFsdWUsICdudW1iZXInKX08L3NwYW4+O1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDBcIj57U3RyaW5nKHZhbHVlID8/ICcnKX08L3NwYW4+O1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlcG9ydEZvb3RlclNlY3Rpb24oe1xuICAgIGZvb3RlcixcbiAgICBtb25leVN5bWJvbCA9ICckJyxcbn06IHtcbiAgICBmb290ZXI6IFJlcG9ydEZvb3Rlck1ldGE7XG4gICAgbW9uZXlTeW1ib2w/OiBDdXJyZW5jeVN5bWJvbDtcbn0pIHtcbiAgICBjb25zdCBibG9ja3MgPSBmb290ZXIuYmxvY2tzIHx8IFtdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy1ncmF5LTUwIHB4LTQgcHktMyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAge2Jsb2Nrcy5tYXAoKGJsb2NrLCBiaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2sudHlwZSAhPT0gJ3N1bW1hcnlfbGluZXMnKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYiA9IGJsb2NrIGFzIFJlcG9ydEZvb3RlckJsb2NrU3VtbWFyeUxpbmVzO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBsaW5lcyA9IGIubGluZXMgfHwgW107XG4gICAgICAgICAgICAgICAgICAgIGlmIChsaW5lcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2JpfSBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5lcy5tYXAoKGxpbmUsIGxpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bGl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gZ2FwLXgtNCBnYXAteS0xIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+e2xpbmUubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEZvb3RlckxpbmVWYWx1ZShsaW5lLnZhbHVlLCBsaW5lLmZvcm1hdCwgbW9uZXlTeW1ib2wpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3JlcG9ydGVzL1JlcG9ydEZvb3RlclNlY3Rpb24udHN4In0=