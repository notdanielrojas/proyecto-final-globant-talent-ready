import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const usuariosModuleConfig = {
  endpoint: "users",
  moduleName: "Usuario",
  moduleNamePlural: "Usuarios",
  baseRoute: "/configuracion/usuarios",
  detail: {
    displayNameKey: "name"
  },
  list: {
    columns: [
      { header: "Nombre", accessor: "name" },
      { header: "Email", accessor: "email" },
      { header: "Teléfono", accessor: "phone" },
      {
        header: "Perfil",
        accessor: "role_id",
        // Renderizamos el nombre del primer rol en el array
        render: (item) => /* @__PURE__ */ jsxDEV("span", { className: "px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800", children: item.roles && item.roles.length > 0 ? item.roles[0].name : "Sin Perfil" }, void 0, false, {
          fileName: "/app/src/features/usuarios/usuarios.config.tsx",
          lineNumber: 40,
          columnNumber: 7
        }, this)
      }
      // Notar que omitimos deliberadamente la columna 'password'
    ]
  },
  form: {
    block: [
      {
        name: "Datos del usuario",
        fields: [
          { name: "name", label: "Nombre Completo", type: "text", placeholder: "Nombre y Apellido" },
          { name: "email", label: "Email", type: "email" },
          { name: "password", label: "Nueva Contraseña", type: "password", placeholder: "Indique la contraseña" },
          { name: "password_confirmation", label: "Confirmar Contraseña", type: "password", placeholder: "Repita la nueva contraseña" },
          { name: "phone", label: "Teléfono", type: "text" },
          {
            // El campo ahora se llama 'role_id' para coincidir con la API
            name: "role_id",
            label: "Perfil",
            type: "select",
            // Las opciones ahora se cargarán dinámicamente, por lo que dejamos esto vacío
            options: []
          }
        ]
      }
    ]
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNvQjtBQXBCYixhQUFNQSx1QkFBOEM7QUFBQSxFQUN2REMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaQyxrQkFBa0I7QUFBQSxFQUNsQkMsV0FBVztBQUFBLEVBRVhDLFFBQVE7QUFBQSxJQUNKQyxnQkFBZ0I7QUFBQSxFQUNwQjtBQUFBLEVBRUFDLE1BQU07QUFBQSxJQUNGQyxTQUFTO0FBQUEsTUFDTCxFQUFFQyxRQUFRLFVBQVVDLFVBQVUsT0FBTztBQUFBLE1BQ3JDLEVBQUVELFFBQVEsU0FBU0MsVUFBVSxRQUFRO0FBQUEsTUFDckMsRUFBRUQsUUFBUSxZQUFZQyxVQUFVLFFBQVE7QUFBQSxNQUN4QztBQUFBLFFBQ0lELFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUE7QUFBQSxRQUVWQyxRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVSwrRkFDWEEsZUFBS0MsU0FBU0QsS0FBS0MsTUFBTUMsU0FBUyxJQUFJRixLQUFLQyxNQUFNLENBQUMsRUFBRUUsT0FBTyxnQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFUjtBQUFBO0FBQUEsSUFDQTtBQUFBLEVBRVI7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsT0FBTztBQUFBLE1BQ0g7QUFBQSxRQUNJRixNQUFNO0FBQUEsUUFDTkcsUUFBUTtBQUFBLFVBQ0osRUFBRUgsTUFBTSxRQUFRSSxPQUFPLG1CQUFtQkMsTUFBTSxRQUFRQyxhQUFhLG9CQUFvQjtBQUFBLFVBQ3pGLEVBQUVOLE1BQU0sU0FBU0ksT0FBTyxTQUFTQyxNQUFNLFFBQVE7QUFBQSxVQUMvQyxFQUFFTCxNQUFNLFlBQVlJLE9BQU8sb0JBQW9CQyxNQUFNLFlBQVlDLGFBQWEsd0JBQXdCO0FBQUEsVUFDdEcsRUFBRU4sTUFBTSx5QkFBeUJJLE9BQU8sd0JBQXdCQyxNQUFNLFlBQVlDLGFBQWEsNkJBQTZCO0FBQUEsVUFDNUgsRUFBRU4sTUFBTSxTQUFTSSxPQUFPLFlBQVlDLE1BQU0sT0FBTztBQUFBLFVBQ2pEO0FBQUE7QUFBQSxZQUVJTCxNQUFNO0FBQUEsWUFDTkksT0FBTztBQUFBLFlBQ1BDLE1BQU07QUFBQTtBQUFBLFlBRU5FLFNBQVM7QUFBQSxVQUNiO0FBQUEsUUFBQztBQUFBLE1BRVQ7QUFBQSxJQUFDO0FBQUEsRUFHVDtBQUNKIiwibmFtZXMiOlsidXN1YXJpb3NNb2R1bGVDb25maWciLCJlbmRwb2ludCIsIm1vZHVsZU5hbWUiLCJtb2R1bGVOYW1lUGx1cmFsIiwiYmFzZVJvdXRlIiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJsaXN0IiwiY29sdW1ucyIsImhlYWRlciIsImFjY2Vzc29yIiwicmVuZGVyIiwiaXRlbSIsInJvbGVzIiwibGVuZ3RoIiwibmFtZSIsImZvcm0iLCJibG9jayIsImZpZWxkcyIsImxhYmVsIiwidHlwZSIsInBsYWNlaG9sZGVyIiwib3B0aW9ucyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJ1c3Vhcmlvcy5jb25maWcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB0eXBlIHsgUHJvZmlsZSB9IGZyb20gJy4uL3Byb2ZpbGVzL3Byb2ZpbGVzLmNvbmZpZyc7XG5cblxuLy8gMi4gRGVmaW5pbW9zIGxhICdmb3JtYScgZGUgdW4gVXN1YXJpb1xuZXhwb3J0IGludGVyZmFjZSBVc3VhcmlvIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBlbWFpbDogc3RyaW5nO1xuICAgIHBhc3N3b3JkPzogc3RyaW5nOyAvLyBIYWNlbW9zIGxhIGNvbnRyYXNlw7FhIG9wY2lvbmFsIHBhcmEgbm8gdGVuZXIgcXVlIG1hbmVqYXJsYSBzaWVtcHJlXG4gICAgcGFzc3dvcmRfY29uZmlybWF0aW9uPzogc3RyaW5nOyAvLyBIYWNlbW9zIGxhIGNvbnRyYXNlw7FhIG9wY2lvbmFsIHBhcmEgbm8gdGVuZXIgcXVlIG1hbmVqYXJsYSBzaWVtcHJlXG4gICAgcGhvbmU6IHN0cmluZztcbiAgICByb2xlX2lkOiBudW1iZXI7XG4gICAgcm9sZXM6IFByb2ZpbGVbXTsgLy8gTGEgQVBJIGFob3JhIGRldnVlbHZlIHVuIGFycmF5IGRlICdyb2xlcydcbiAgICBwZXJtaXNzaW9ucz86IHN0cmluZ1tdOyAvLyDinIUgUGVybWlzb3MgZGVsIHVzdWFyaW9cbn1cblxuXG4vLyA0LiBDcmVhbW9zIGxhIGNvbmZpZ3VyYWNpw7NuIGNvbXBsZXRhIHBhcmEgZWwgbcOzZHVsbyBkZSBVc3Vhcmlvc1xuZXhwb3J0IGNvbnN0IHVzdWFyaW9zTW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8VXN1YXJpbz4gPSB7XG4gICAgZW5kcG9pbnQ6ICd1c2VycycsXG4gICAgbW9kdWxlTmFtZTogJ1VzdWFyaW8nLFxuICAgIG1vZHVsZU5hbWVQbHVyYWw6ICdVc3VhcmlvcycsXG4gICAgYmFzZVJvdXRlOiAnL2NvbmZpZ3VyYWNpb24vdXN1YXJpb3MnLFxuXG4gICAgZGV0YWlsOiB7XG4gICAgICAgIGRpc3BsYXlOYW1lS2V5OiAnbmFtZScsXG4gICAgfSxcblxuICAgIGxpc3Q6IHtcbiAgICAgICAgY29sdW1uczogW1xuICAgICAgICAgICAgeyBoZWFkZXI6ICdOb21icmUnLCBhY2Nlc3NvcjogJ25hbWUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0VtYWlsJywgYWNjZXNzb3I6ICdlbWFpbCcgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnVGVsw6lmb25vJywgYWNjZXNzb3I6ICdwaG9uZScgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdQZXJmaWwnLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAncm9sZV9pZCcsXG4gICAgICAgICAgICAgICAgLy8gUmVuZGVyaXphbW9zIGVsIG5vbWJyZSBkZWwgcHJpbWVyIHJvbCBlbiBlbCBhcnJheVxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucm9sZXMgJiYgaXRlbS5yb2xlcy5sZW5ndGggPiAwID8gaXRlbS5yb2xlc1swXS5uYW1lIDogJ1NpbiBQZXJmaWwnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8vIE5vdGFyIHF1ZSBvbWl0aW1vcyBkZWxpYmVyYWRhbWVudGUgbGEgY29sdW1uYSAncGFzc3dvcmQnXG4gICAgICAgIF0sXG4gICAgfSxcblxuICAgIGZvcm06IHtcbiAgICAgICAgYmxvY2s6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIkRhdG9zIGRlbCB1c3VhcmlvXCIsXG4gICAgICAgICAgICAgICAgZmllbGRzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ25hbWUnLCBsYWJlbDogJ05vbWJyZSBDb21wbGV0bycsIHR5cGU6ICd0ZXh0JywgcGxhY2Vob2xkZXI6ICdOb21icmUgeSBBcGVsbGlkbycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnZW1haWwnLCBsYWJlbDogJ0VtYWlsJywgdHlwZTogJ2VtYWlsJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdwYXNzd29yZCcsIGxhYmVsOiAnTnVldmEgQ29udHJhc2XDsWEnLCB0eXBlOiAncGFzc3dvcmQnLCBwbGFjZWhvbGRlcjogJ0luZGlxdWUgbGEgY29udHJhc2XDsWEnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ3Bhc3N3b3JkX2NvbmZpcm1hdGlvbicsIGxhYmVsOiAnQ29uZmlybWFyIENvbnRyYXNlw7FhJywgdHlwZTogJ3Bhc3N3b3JkJywgcGxhY2Vob2xkZXI6ICdSZXBpdGEgbGEgbnVldmEgY29udHJhc2XDsWEnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ3Bob25lJywgbGFiZWw6ICdUZWzDqWZvbm8nLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRWwgY2FtcG8gYWhvcmEgc2UgbGxhbWEgJ3JvbGVfaWQnIHBhcmEgY29pbmNpZGlyIGNvbiBsYSBBUElcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdyb2xlX2lkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnUGVyZmlsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdzZWxlY3QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gTGFzIG9wY2lvbmVzIGFob3JhIHNlIGNhcmdhcsOhbiBkaW7DoW1pY2FtZW50ZSwgcG9yIGxvIHF1ZSBkZWphbW9zIGVzdG8gdmFjw61vXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBbXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuXG4gICAgfVxufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3VzdWFyaW9zL3VzdWFyaW9zLmNvbmZpZy50c3gifQ==