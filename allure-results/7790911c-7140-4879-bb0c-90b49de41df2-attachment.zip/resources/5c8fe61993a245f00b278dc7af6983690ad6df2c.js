import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/vendedores/pages/VendedoresDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/vendedores/pages/VendedoresDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
export const VendedoresDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error } = useCrudItem(vendedoresModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Vendedor no encontrado." }, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: vendedoresModuleConfig, item }, void 0, false, {
    fileName: "/app/src/features/vendedores/pages/VendedoresDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(VendedoresDetailPage, "6YQMcrxNTGjd60HB6xOhIbiA4BI=", false, function() {
  return [useParams, useCrudItem];
});
_c = VendedoresDetailPage;
var _c;
$RefreshReg$(_c, "VendedoresDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/vendedores/pages/VendedoresDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/vendedores/pages/VendedoresDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDhCQUE2QztBQUN0RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBRXhCLGFBQU1DLHVCQUF1QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RDLFFBQU0sRUFBRUMsR0FBRyxJQUFJUCxVQUEwQjtBQUN6QyxRQUFNLEVBQUVRLE1BQU1DLFNBQVNDLE1BQU0sSUFBSVAsWUFBc0JELHdCQUF3QkssRUFBRTtBQUVqRixNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHVDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEI7QUFFOUMsU0FBTyx1QkFBQyxxQkFBa0IsUUFBUU4sd0JBQXdCLFFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEQ7QUFDekU7QUFBRUksR0FUV0Qsc0JBQW9CO0FBQUEsVUFDZEwsV0FDa0JHLFdBQVc7QUFBQTtBQUFBUSxLQUZuQ047QUFBb0IsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwidmVuZGVkb3Jlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiTG9hZGluZ1NwaW5uZXIiLCJWZW5kZWRvcmVzRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJpdGVtIiwibG9hZGluZyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVmVuZGVkb3Jlc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLCB0eXBlIFZlbmRlZG9yIH0gZnJvbSAnLi4vdmVuZGVkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuXG5leHBvcnQgY29uc3QgVmVuZGVkb3Jlc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbSwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFZlbmRlZG9yPih2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFpdGVtKSByZXR1cm4gPGRpdj5WZW5kZWRvciBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXt2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnfSBpdGVtPXtpdGVtfSAvPjtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy92ZW5kZWRvcmVzL3BhZ2VzL1ZlbmRlZG9yZXNEZXRhaWxQYWdlLnRzeCJ9