import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrud } from "/src/hooks/useCrud.ts";
import { cobranzasModuleConfig } from "/src/features/cobranzas/cobranzas.config.tsx";
import { GenericTable } from "/src/components/common/GenericTable.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
const COBRANZAS_RESUMEN_COLUMNS = [
  { header: "Fecha", accessor: "collection_date", format: "date", sortField: "collection_date" },
  { header: "Valor", accessor: "total_amount", format: "currency" },
  { header: "Nº Recibo", accessor: "collection_number" }
];
function ClienteCobranzasModalBody({ clientId }) {
  _s();
  const navigate = useNavigate();
  const {
    response,
    loading,
    error,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange
  } = useCrud(cobranzasModuleConfig, {
    term: "",
    startDate: "",
    endDate: "",
    client_id: String(clientId)
  });
  const data = response?.data ?? [];
  const handleRowClick = (item) => {
    navigate(`${cobranzasModuleConfig.baseRoute}/${item.id}`);
  };
  if (error) {
    return /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-600", children: error }, void 0, false, {
      fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
      lineNumber: 58,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "py-12 flex justify-center", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
    lineNumber: 65,
    columnNumber: 21
  }, this) }, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
    lineNumber: 64,
    columnNumber: 7
  }, this) : data.length > 0 ? /* @__PURE__ */ jsxDEV(
    GenericTable,
    {
      data,
      columns: COBRANZAS_RESUMEN_COLUMNS,
      baseRoute: cobranzasModuleConfig.baseRoute,
      onSort: handleSort,
      sortBy,
      sortDirection,
      paginationMeta: response?.meta ?? null,
      onPageChange: handlePageChange,
      disableActions: true,
      onRowClick: handleRowClick
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
      lineNumber: 68,
      columnNumber: 7
    },
    this
  ) : /* @__PURE__ */ jsxDEV("p", { className: "py-8 text-center text-sm text-gray-500", children: "No hay cobranzas registradas para este cliente." }, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
    lineNumber: 81,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(ClienteCobranzasModalBody, "jvZRPF3FfO+THFRLyiVoVbr97NI=", false, function() {
  return [useNavigate, useCrud];
});
_c = ClienteCobranzasModalBody;
export function ClienteCobranzasModal({ isOpen, onClose, clientId }) {
  _s2();
  const resolvedClientId = useMemo(
    () => clientId != null && clientId > 0 ? clientId : null,
    [clientId]
  );
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black bg-opacity-50",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "cliente-cobranzas-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-6 py-4 border-b border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { id: "cliente-cobranzas-modal-title", className: "text-lg font-medium text-gray-900", children: "Pagos" }, void 0, false, {
                fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
                lineNumber: 114,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  className: "px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50",
                  children: "Cerrar"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
                  lineNumber: 117,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
              lineNumber: 113,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-y-auto flex-1", children: resolvedClientId ? /* @__PURE__ */ jsxDEV(ClienteCobranzasModalBody, { clientId: resolvedClientId }, resolvedClientId, false, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
              lineNumber: 127,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Este pedido no tiene un cliente asociado." }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
              lineNumber: 129,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
              lineNumber: 125,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
          lineNumber: 109,
          columnNumber: 13
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx",
      lineNumber: 103,
      columnNumber: 5
    },
    this
  );
}
_s2(ClienteCobranzasModal, "FKs8jMlfE26hWM04TJ2ACLhxAMc=");
_c2 = ClienteCobranzasModal;
var _c, _c2;
$RefreshReg$(_c, "ClienteCobranzasModalBody");
$RefreshReg$(_c2, "ClienteCobranzasModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NlLFNBSVAsVUFKTzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0Q2YsU0FBU0EsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyw2QkFBbUQ7QUFFNUQsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUUvQixNQUFNQyw0QkFBaUU7QUFBQSxFQUNuRSxFQUFFQyxRQUFRLFNBQVNDLFVBQVUsbUJBQW1CQyxRQUFRLFFBQVFDLFdBQVcsa0JBQWtCO0FBQUEsRUFDN0YsRUFBRUgsUUFBUSxTQUFTQyxVQUFVLGdCQUFnQkMsUUFBUSxXQUFXO0FBQUEsRUFDaEUsRUFBRUYsUUFBUSxhQUFhQyxVQUFVLG9CQUFvQjtBQUFDO0FBRzFELFNBQVNHLDBCQUEwQixFQUFFQyxTQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDbkUsUUFBTUMsV0FBV2IsWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFDRmM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJbkIsUUFBeUJDLHVCQUF1QjtBQUFBLElBQ2hEbUIsTUFBTTtBQUFBLElBQ05DLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsV0FBV0MsT0FBT2QsUUFBUTtBQUFBLEVBQzlCLENBQUM7QUFFRCxRQUFNZSxPQUFPWixVQUFVWSxRQUFRO0FBRS9CLFFBQU1DLGlCQUFpQkEsQ0FBQ0MsU0FBMEI7QUFDOUNmLGFBQVMsR0FBR1gsc0JBQXNCMkIsU0FBUyxJQUFJRCxLQUFLRSxFQUFFLEVBQUU7QUFBQSxFQUM1RDtBQUVBLE1BQUlkLE9BQU87QUFDUCxXQUFPLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JBLG1CQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsRUFDdEQ7QUFFQSxTQUNJLG1DQUNLRCxvQkFDRyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1gsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxJQUNBVyxLQUFLSyxTQUFTLElBQ2Q7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHO0FBQUEsTUFDQSxTQUFTMUI7QUFBQUEsTUFDVCxXQUFXSCxzQkFBc0IyQjtBQUFBQSxNQUNqQyxRQUFRWjtBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0EsZ0JBQWdCSCxVQUFVa0IsUUFBUTtBQUFBLE1BQ2xDLGNBQWNaO0FBQUFBLE1BQ2Q7QUFBQSxNQUNBLFlBQVlPO0FBQUFBO0FBQUFBLElBVmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVUrQixJQUcvQix1QkFBQyxPQUFFLFdBQVUsMENBQXlDLCtEQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFHLEtBbkI3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRVI7QUFBQ2YsR0FuRFFGLDJCQUF5QjtBQUFBLFVBQ2JWLGFBU2JDLE9BQU87QUFBQTtBQUFBZ0MsS0FWTnZCO0FBNERGLGdCQUFTd0Isc0JBQXNCLEVBQUVDLFFBQVFDLFNBQVN6QixTQUFxQyxHQUFHO0FBQUEwQixNQUFBO0FBQzdGLFFBQU1DLG1CQUFtQnZDO0FBQUFBLElBQ3JCLE1BQU9ZLFlBQVksUUFBUUEsV0FBVyxJQUFJQSxXQUFXO0FBQUEsSUFDckQsQ0FBQ0EsUUFBUTtBQUFBLEVBQ2I7QUFFQSxNQUFJLENBQUN3QixPQUFRLFFBQU87QUFFcEIsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csV0FBVTtBQUFBLE1BQ1YsTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsbUJBQWdCO0FBQUEsTUFFaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFdBQVU7QUFBQSxVQUNWLFNBQVMsQ0FBQUksTUFBS0EsRUFBRUMsZ0JBQWdCO0FBQUEsVUFFaEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsd0VBQ1g7QUFBQSxxQ0FBQyxRQUFHLElBQUcsaUNBQWdDLFdBQVUscUNBQW1DLHFCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBU0o7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUEyRztBQUFBO0FBQUEsZ0JBSHpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNWRSw2QkFDRyx1QkFBQyw2QkFBaUQsVUFBVUEsb0JBQTVCQSxrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkUsSUFFN0UsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix5REFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEUsS0FKdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBO0FBQUE7QUFBQSxRQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUF1QkE7QUFBQTtBQUFBLElBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQThCQTtBQUVSO0FBQUNELElBekNlSCx1QkFBcUI7QUFBQU8sTUFBckJQO0FBQXFCLElBQUFELElBQUFRO0FBQUFDLGFBQUFULElBQUE7QUFBQVMsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VOYXZpZ2F0ZSIsInVzZUNydWQiLCJjb2JyYW56YXNNb2R1bGVDb25maWciLCJHZW5lcmljVGFibGUiLCJMb2FkaW5nU3Bpbm5lciIsIkNPQlJBTlpBU19SRVNVTUVOX0NPTFVNTlMiLCJoZWFkZXIiLCJhY2Nlc3NvciIsImZvcm1hdCIsInNvcnRGaWVsZCIsIkNsaWVudGVDb2JyYW56YXNNb2RhbEJvZHkiLCJjbGllbnRJZCIsIl9zIiwibmF2aWdhdGUiLCJyZXNwb25zZSIsImxvYWRpbmciLCJlcnJvciIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiY2xpZW50X2lkIiwiU3RyaW5nIiwiZGF0YSIsImhhbmRsZVJvd0NsaWNrIiwiaXRlbSIsImJhc2VSb3V0ZSIsImlkIiwibGVuZ3RoIiwibWV0YSIsIl9jIiwiQ2xpZW50ZUNvYnJhbnphc01vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsIl9zMiIsInJlc29sdmVkQ2xpZW50SWQiLCJlIiwic3RvcFByb3BhZ2F0aW9uIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudGVDb2JyYW56YXNNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBjb2JyYW56YXNNb2R1bGVDb25maWcsIHR5cGUgQ3VzdG9tZXJQYXltZW50IH0gZnJvbSAnLi4vLi4vY29icmFuemFzL2NvYnJhbnphcy5jb25maWcnO1xuaW1wb3J0IHR5cGUgeyBDb2x1bW5EZWZpbml0aW9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IEdlbmVyaWNUYWJsZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNUYWJsZSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuXG5jb25zdCBDT0JSQU5aQVNfUkVTVU1FTl9DT0xVTU5TOiBDb2x1bW5EZWZpbml0aW9uPEN1c3RvbWVyUGF5bWVudD5bXSA9IFtcbiAgICB7IGhlYWRlcjogJ0ZlY2hhJywgYWNjZXNzb3I6ICdjb2xsZWN0aW9uX2RhdGUnLCBmb3JtYXQ6ICdkYXRlJywgc29ydEZpZWxkOiAnY29sbGVjdGlvbl9kYXRlJyB9LFxuICAgIHsgaGVhZGVyOiAnVmFsb3InLCBhY2Nlc3NvcjogJ3RvdGFsX2Ftb3VudCcsIGZvcm1hdDogJ2N1cnJlbmN5JyB9LFxuICAgIHsgaGVhZGVyOiAnTsK6IFJlY2libycsIGFjY2Vzc29yOiAnY29sbGVjdGlvbl9udW1iZXInIH0sXG5dO1xuXG5mdW5jdGlvbiBDbGllbnRlQ29icmFuemFzTW9kYWxCb2R5KHsgY2xpZW50SWQgfTogeyBjbGllbnRJZDogbnVtYmVyIH0pIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIGhhbmRsZVNvcnQsXG4gICAgICAgIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbixcbiAgICAgICAgaGFuZGxlUGFnZUNoYW5nZSxcbiAgICB9ID0gdXNlQ3J1ZDxDdXN0b21lclBheW1lbnQ+KGNvYnJhbnphc01vZHVsZUNvbmZpZywge1xuICAgICAgICB0ZXJtOiAnJyxcbiAgICAgICAgc3RhcnREYXRlOiAnJyxcbiAgICAgICAgZW5kRGF0ZTogJycsXG4gICAgICAgIGNsaWVudF9pZDogU3RyaW5nKGNsaWVudElkKSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGRhdGEgPSByZXNwb25zZT8uZGF0YSA/PyBbXTtcblxuICAgIGNvbnN0IGhhbmRsZVJvd0NsaWNrID0gKGl0ZW06IEN1c3RvbWVyUGF5bWVudCkgPT4ge1xuICAgICAgICBuYXZpZ2F0ZShgJHtjb2JyYW56YXNNb2R1bGVDb25maWcuYmFzZVJvdXRlfS8ke2l0ZW0uaWR9YCk7XG4gICAgfTtcblxuICAgIGlmIChlcnJvcikge1xuICAgICAgICByZXR1cm4gPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3J9PC9wPjtcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xMiBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkaW5nU3Bpbm5lciAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IGRhdGEubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8R2VuZXJpY1RhYmxlPEN1c3RvbWVyUGF5bWVudD5cbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZGF0YX1cbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Q09CUkFOWkFTX1JFU1VNRU5fQ09MVU1OU31cbiAgICAgICAgICAgICAgICAgICAgYmFzZVJvdXRlPXtjb2JyYW56YXNNb2R1bGVDb25maWcuYmFzZVJvdXRlfVxuICAgICAgICAgICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICBwYWdpbmF0aW9uTWV0YT17cmVzcG9uc2U/Lm1ldGEgPz8gbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlQWN0aW9uc1xuICAgICAgICAgICAgICAgICAgICBvblJvd0NsaWNrPXtoYW5kbGVSb3dDbGlja31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweS04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBjb2JyYW56YXMgcmVnaXN0cmFkYXMgcGFyYSBlc3RlIGNsaWVudGUuPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC8+XG4gICAgKTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDbGllbnRlQ29icmFuemFzTW9kYWxQcm9wcyB7XG4gICAgaXNPcGVuOiBib29sZWFuO1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gICAgLyoqIElkIGRlbCBjbGllbnRlIGRlbCBwZWRpZG87IHNpIGVzIG51bGwgZWwgbW9kYWwgbm8gY2FyZ2EgbGlzdGFkbyAqL1xuICAgIGNsaWVudElkOiBudW1iZXIgfCBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2xpZW50ZUNvYnJhbnphc01vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCBjbGllbnRJZCB9OiBDbGllbnRlQ29icmFuemFzTW9kYWxQcm9wcykge1xuICAgIGNvbnN0IHJlc29sdmVkQ2xpZW50SWQgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiAoY2xpZW50SWQgIT0gbnVsbCAmJiBjbGllbnRJZCA+IDAgPyBjbGllbnRJZCA6IG51bGwpLFxuICAgICAgICBbY2xpZW50SWRdXG4gICAgKTtcblxuICAgIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiXG4gICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cImNsaWVudGUtY29icmFuemFzLW1vZGFsLXRpdGxlXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXhsIHctZnVsbCBtYXgtdy00eGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtlID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgaWQ9XCJjbGllbnRlLWNvYnJhbnphcy1tb2RhbC10aXRsZVwiIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUGFnb3NcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ2VycmFyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IG92ZXJmbG93LXktYXV0byBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAge3Jlc29sdmVkQ2xpZW50SWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2xpZW50ZUNvYnJhbnphc01vZGFsQm9keSBrZXk9e3Jlc29sdmVkQ2xpZW50SWR9IGNsaWVudElkPXtyZXNvbHZlZENsaWVudElkfSAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+RXN0ZSBwZWRpZG8gbm8gdGllbmUgdW4gY2xpZW50ZSBhc29jaWFkby48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYXV0b3JpemFjaW9uX3BlZGlkb3MvY29tcG9uZW50cy9DbGllbnRlQ29icmFuemFzTW9kYWwudHN4In0=