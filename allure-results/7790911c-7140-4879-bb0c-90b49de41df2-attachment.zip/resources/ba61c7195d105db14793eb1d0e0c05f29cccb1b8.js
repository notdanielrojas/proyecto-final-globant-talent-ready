import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ProductMovementsTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/ProductMovementsTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { search } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { renderSignedStockQuantity } from "/src/utils/stockMovementQuantity.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { FaFilter } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { renderStockMovementVoucherLink } from "/src/utils/renders.tsx";
export const ProductMovementsTab = ({ entityId, endpoint }) => {
  _s();
  const [movements, setMovements] = useState([]);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
  const [dateRange, setDateRange] = useState({ from: oneMonthAgo, to: today });
  const fetchMovements = useCallback(async (pageUrl) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("start_date", dateRange.from);
      params.set("end_date", dateRange.to);
      params.set("product_id", entityId.toString());
      if (pageUrl) {
        const page = new URL(pageUrl, "http://localhost").searchParams.get("page") || "1";
        params.set("page", page);
      }
      const url = `${endpoint}?${params.toString()}`;
      const response = await search(url);
      setMovements(response.data);
      setPaginationMeta(response.meta);
    } catch (error) {
      toast.error("Error al cargar los movimientos de stock.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [endpoint, entityId, dateRange.from, dateRange.to]);
  useEffect(() => {
    fetchMovements();
  }, [fetchMovements]);
  const handlePageChange = (url) => {
    fetchMovements(url);
  };
  const handleFilterSubmit = (e) => {
    e.preventDefault();
    fetchMovements();
  };
  const columns = [
    { key: "movement_date", label: "Fecha" },
    { key: "movement_code", label: "Tipo" },
    { key: "document", label: "Nº Documento" },
    { key: "entity", label: "Cliente/Proveedor" },
    { key: "quantity", label: "Cantidad" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleFilterSubmit, autoComplete: "off", className: "flex items-end gap-4 mb-4 p-4 bg-gray-50 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_from", className: "block text-sm font-medium text-gray-700", children: "Desde" }, void 0, false, {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 114,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_from",
            value: dateRange.from,
            onChange: (e) => setDateRange((prev) => ({ ...prev, from: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/ProductMovementsTab.tsx",
            lineNumber: 115,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ProductMovementsTab.tsx",
        lineNumber: 113,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_to", className: "block text-sm font-medium text-gray-700", children: "Hasta" }, void 0, false, {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 123,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_to",
            value: dateRange.to,
            onChange: (e) => setDateRange((prev) => ({ ...prev, to: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/ProductMovementsTab.tsx",
            lineNumber: 124,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ProductMovementsTab.tsx",
        lineNumber: 122,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(FaFilter, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 135,
              columnNumber: 21
            }, this),
            " Filtrar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 131,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ProductMovementsTab.tsx",
      lineNumber: 112,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/ProductMovementsTab.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: columns.map(
          (col) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: `py-3.5 px-3 text-left text-sm font-semibold text-gray-900 ${col.key === "quantity" ? "text-right" : ""}`, children: col.label }, col.key, false, {
            fileName: "/app/src/components/common/ProductMovementsTab.tsx",
            lineNumber: 148,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 146,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 145,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: movements.map(
          (mov) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: formatValue(mov.movement_date, "date") }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 157,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: mov.movement_code === "A" ? "Entrada" : mov.movement_code === "B" || mov.movement_code === "F" || mov.movement_code === "S" ? "Salida" : mov.movement_code ?? "-" }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 158,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: renderStockMovementVoucherLink(mov) }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 159,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: mov.client_name || mov.vendor_name }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 162,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-semibold", children: renderSignedStockQuantity(mov.movement_code, mov.quantity, { emphasizeEntrada: true }) }, void 0, false, {
              fileName: "/app/src/components/common/ProductMovementsTab.tsx",
              lineNumber: 163,
              columnNumber: 41
            }, this)
          ] }, mov.id, true, {
            fileName: "/app/src/components/common/ProductMovementsTab.tsx",
            lineNumber: 156,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 154,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ProductMovementsTab.tsx",
        lineNumber: 144,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/ProductMovementsTab.tsx",
        lineNumber: 143,
        columnNumber: 21
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          meta: paginationMeta,
          onPageChange: handlePageChange
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/ProductMovementsTab.tsx",
          lineNumber: 170,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ProductMovementsTab.tsx",
      lineNumber: 142,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/ProductMovementsTab.tsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
};
_s(ProductMovementsTab, "Us3Hh2W6syNzNbrbwGeICxjuaOM=");
_c = ProductMovementsTab;
var _c;
$RefreshReg$(_c, "ProductMovementsTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/ProductMovementsTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/ProductMovementsTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEZvQixTQTRCSixVQTVCSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3RnBCLFNBQVNBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUNqRCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGlDQUFpQztBQUMxQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxzQ0FBc0M7QUFxQnhDLGFBQU1DLHNCQUFzQkEsQ0FBQyxFQUFFQyxVQUFVQyxTQUFtQyxNQUFNO0FBQUFDLEtBQUE7QUFDckYsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUloQixTQUEwQixFQUFFO0FBQzlELFFBQU0sQ0FBQ2lCLGdCQUFnQkMsaUJBQWlCLElBQUlsQixTQUEwRCxJQUFJO0FBQzFHLFFBQU0sQ0FBQ21CLFNBQVNDLFVBQVUsSUFBSXBCLFNBQVMsS0FBSztBQUU1QyxRQUFNcUIsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTUMsY0FBYyxJQUFJSCxLQUFLQSxLQUFLSSxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJLEVBQUVILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM5RixRQUFNLENBQUNHLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsRUFBRTZCLE1BQU1KLGFBQWFLLElBQUlULE1BQU0sQ0FBQztBQUUzRSxRQUFNVSxpQkFBaUI3QixZQUFZLE9BQU84QixZQUFxQjtBQUMzRFosZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUVBLFlBQU1hLFNBQVMsSUFBSUMsZ0JBQWdCO0FBQ25DRCxhQUFPRSxJQUFJLGNBQWNSLFVBQVVFLElBQUk7QUFDdkNJLGFBQU9FLElBQUksWUFBWVIsVUFBVUcsRUFBRTtBQUNuQ0csYUFBT0UsSUFBSSxjQUFjdkIsU0FBU3dCLFNBQVMsQ0FBQztBQUU1QyxVQUFJSixTQUFTO0FBQ1QsY0FBTUssT0FBTyxJQUFJQyxJQUFJTixTQUFTLGtCQUFrQixFQUFFTyxhQUFhQyxJQUFJLE1BQU0sS0FBSztBQUM5RVAsZUFBT0UsSUFBSSxRQUFRRSxJQUFJO0FBQUEsTUFDM0I7QUFFQSxZQUFNSSxNQUFNLEdBQUc1QixRQUFRLElBQUlvQixPQUFPRyxTQUFTLENBQUM7QUFFNUMsWUFBTU0sV0FBVyxNQUFNdEMsT0FBc0JxQyxHQUFHO0FBQ2hEekIsbUJBQWEwQixTQUFTQyxJQUFJO0FBQzFCekIsd0JBQWtCd0IsU0FBU0UsSUFBSTtBQUFBLElBRW5DLFNBQVNDLE9BQU87QUFDWjFDLFlBQU0wQyxNQUFNLDJDQUEyQztBQUN2REMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCLFVBQUM7QUFDR3pCLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0osR0FBRyxDQUFDUCxVQUFVRCxVQUFVZSxVQUFVRSxNQUFNRixVQUFVRyxFQUFFLENBQUM7QUFFckQ3QixZQUFVLE1BQU07QUFDWjhCLG1CQUFlO0FBQUEsRUFDbkIsR0FBRyxDQUFDQSxjQUFjLENBQUM7QUFFbkIsUUFBTWdCLG1CQUFtQkEsQ0FBQ04sUUFBZ0I7QUFDdENWLG1CQUFlVSxHQUFHO0FBQUEsRUFDdEI7QUFFQSxRQUFNTyxxQkFBcUJBLENBQUNDLE1BQXVCO0FBQy9DQSxNQUFFQyxlQUFlO0FBQ2pCbkIsbUJBQWU7QUFBQSxFQUNuQjtBQUdBLFFBQU1vQixVQUFVO0FBQUEsSUFDWixFQUFFQyxLQUFLLGlCQUFpQkMsT0FBTyxRQUFRO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxpQkFBaUJDLE9BQU8sT0FBTztBQUFBLElBQ3RDLEVBQUVELEtBQUssWUFBWUMsT0FBTyxlQUFlO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxVQUFVQyxPQUFPLG9CQUFvQjtBQUFBLElBQzVDLEVBQUVELEtBQUssWUFBWUMsT0FBTyxXQUFXO0FBQUEsRUFBQztBQUcxQyxTQUNJLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsMkJBQUMsVUFBSyxVQUFVTCxvQkFBb0IsY0FBYSxPQUFNLFdBQVUsOERBQzdEO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxhQUFZLFdBQVUsMkNBQTBDLHFCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFDcEY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNILE9BQU9yQixVQUFVRTtBQUFBQSxZQUNqQixVQUFVLENBQUFvQixNQUFLckIsYUFBYSxDQUFBMEIsVUFBUyxFQUFFLEdBQUdBLE1BQU16QixNQUFNb0IsRUFBRU0sT0FBT0MsTUFBTSxFQUFFO0FBQUEsWUFDdkUsV0FBVTtBQUFBLFlBQXFGLGNBQWE7QUFBQTtBQUFBLFVBTGhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxSDtBQUFBLFdBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxXQUFVLFdBQVUsMkNBQTBDLHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNILE9BQU83QixVQUFVRztBQUFBQSxZQUNqQixVQUFVLENBQUFtQixNQUFLckIsYUFBYSxDQUFBMEIsVUFBUyxFQUFFLEdBQUdBLE1BQU14QixJQUFJbUIsRUFBRU0sT0FBT0MsTUFBTSxFQUFFO0FBQUEsWUFDckUsV0FBVTtBQUFBLFlBQXFGLGNBQWE7QUFBQTtBQUFBLFVBTGhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxSDtBQUFBLFdBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsSUFFQ3JDLFVBQ0csdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLElBRWYsbUNBQ0k7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDSWdDLGtCQUFRTTtBQUFBQSxVQUFJLENBQUFDLFFBQ1QsdUJBQUMsUUFBaUIsT0FBTSxPQUFNLFdBQVcsNkRBQTZEQSxJQUFJTixRQUFRLGFBQWEsZUFBZSxFQUFFLElBQzNJTSxjQUFJTCxTQURBSyxJQUFJTixLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNILEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pyQyxvQkFBVTBDO0FBQUFBLFVBQUksQ0FBQ0UsUUFDWix1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhDQUE4Q3RELHNCQUFZc0QsSUFBSUMsZUFBZSxNQUFNLEtBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HO0FBQUEsWUFDbkcsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQkQsY0FBSUUsa0JBQWtCLE1BQU0sWUFBWUYsSUFBSUUsa0JBQWtCLE9BQU9GLElBQUlFLGtCQUFrQixPQUFPRixJQUFJRSxrQkFBa0IsTUFBTSxXQUFZRixJQUFJRSxpQkFBaUIsT0FBbE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdU07QUFBQSxZQUN2TSx1QkFBQyxRQUFHLFdBQVUscUJBQ1RuRCx5Q0FBK0JpRCxHQUFVLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxxQkFBcUJBLGNBQUlHLGVBQWVILElBQUlJLGVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3pELG9DQUEwQnFELElBQUlFLGVBQWVGLElBQUlLLFVBQVUsRUFBRUMsa0JBQWtCLEtBQUssQ0FBQyxLQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSjtBQUFBLGVBUDlJTixJQUFJTyxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxRQUNILEtBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQSxLQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFDQ2pELGtCQUNHO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFNQTtBQUFBQSxVQUNOLGNBQWM4QjtBQUFBQTtBQUFBQSxRQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUM7QUFBQSxTQTlCM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLE9BaEVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRUE7QUFFUjtBQUFFakMsR0FoSVdILHFCQUFtQjtBQUFBd0QsS0FBbkJ4RDtBQUFtQixJQUFBd0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJ0b2FzdCIsInNlYXJjaCIsImZvcm1hdFZhbHVlIiwicmVuZGVyU2lnbmVkU3RvY2tRdWFudGl0eSIsIkxvYWRpbmdTcGlubmVyIiwiUGFnaW5hdGlvbiIsIkZhRmlsdGVyIiwicmVuZGVyU3RvY2tNb3ZlbWVudFZvdWNoZXJMaW5rIiwiUHJvZHVjdE1vdmVtZW50c1RhYiIsImVudGl0eUlkIiwiZW5kcG9pbnQiLCJfcyIsIm1vdmVtZW50cyIsInNldE1vdmVtZW50cyIsInBhZ2luYXRpb25NZXRhIiwic2V0UGFnaW5hdGlvbk1ldGEiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJvbmVNb250aEFnbyIsIm5vdyIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsImZyb20iLCJ0byIsImZldGNoTW92ZW1lbnRzIiwicGFnZVVybCIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNldCIsInRvU3RyaW5nIiwicGFnZSIsIlVSTCIsInNlYXJjaFBhcmFtcyIsImdldCIsInVybCIsInJlc3BvbnNlIiwiZGF0YSIsIm1ldGEiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlRmlsdGVyU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwiY29sdW1ucyIsImtleSIsImxhYmVsIiwicHJldiIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiY29sIiwibW92IiwibW92ZW1lbnRfZGF0ZSIsIm1vdmVtZW50X2NvZGUiLCJjbGllbnRfbmFtZSIsInZlbmRvcl9uYW1lIiwicXVhbnRpdHkiLCJlbXBoYXNpemVFbnRyYWRhIiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9kdWN0TW92ZW1lbnRzVGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgc2VhcmNoIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgdHlwZSB7IFBhZ2luYXRlZFJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy9BcGknO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHJlbmRlclNpZ25lZFN0b2NrUXVhbnRpdHkgfSBmcm9tICcuLi8uLi91dGlscy9zdG9ja01vdmVtZW50UXVhbnRpdHknO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBQYWdpbmF0aW9uIH0gZnJvbSAnLi9QYWdpbmF0aW9uJztcbmltcG9ydCB7IEZhRmlsdGVyIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgcmVuZGVyU3RvY2tNb3ZlbWVudFZvdWNoZXJMaW5rIH0gZnJvbSAnLi4vLi4vdXRpbHMvcmVuZGVycyc7IC8vIEFzdW1vIHF1ZSBlc3RlIGhlbHBlciBleGlzdGVcblxuLy8gLS0tIFRJUE9TIChFc3BlY8OtZmljb3MgZGUgUHJvZHVjdG8pIC0tLVxuXG5pbnRlcmZhY2UgU3RvY2tNb3ZlbWVudCB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBtb3ZlbWVudF9kYXRlOiBzdHJpbmc7XG4gICAgbW92ZW1lbnRfY29kZT86ICdBJyB8ICdCJyB8ICdGJyB8IHN0cmluZzsgLy8gRW50cmFkYS9TYWxpZGFcbiAgICBxdWFudGl0eT86IHN0cmluZztcbiAgICBjbGllbnRfbmFtZT86IHN0cmluZztcbiAgICB2ZW5kb3JfbmFtZT86IHN0cmluZztcbiAgICBwdXJjaGFzZV9pZD86IG51bWJlcjtcbiAgICBwdXJjaGFzZV9kb2N1bWVudF9udW1iZXI/OiBzdHJpbmc7XG4gICAgLy8gT3Ryb3MgY2FtcG9zIHF1ZSBwdWVkYSB0ZW5lci4uLlxufVxuXG5pbnRlcmZhY2UgUHJvZHVjdE1vdmVtZW50c1RhYlByb3BzIHtcbiAgICBlbnRpdHlJZDogc3RyaW5nIHwgbnVtYmVyO1xuICAgIGVuZHBvaW50OiBzdHJpbmc7IC8vIEVqOiAnc3RvY2stbW92ZW1lbnRzJ1xufVxuXG5leHBvcnQgY29uc3QgUHJvZHVjdE1vdmVtZW50c1RhYiA9ICh7IGVudGl0eUlkLCBlbmRwb2ludCB9OiBQcm9kdWN0TW92ZW1lbnRzVGFiUHJvcHMpID0+IHtcbiAgICBjb25zdCBbbW92ZW1lbnRzLCBzZXRNb3ZlbWVudHNdID0gdXNlU3RhdGU8U3RvY2tNb3ZlbWVudFtdPihbXSk7XG4gICAgY29uc3QgW3BhZ2luYXRpb25NZXRhLCBzZXRQYWdpbmF0aW9uTWV0YV0gPSB1c2VTdGF0ZTxQYWdpbmF0ZWRSZXNwb25zZTxTdG9ja01vdmVtZW50PlsnbWV0YSddIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICBjb25zdCBvbmVNb250aEFnbyA9IG5ldyBEYXRlKERhdGUubm93KCkgLSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUoeyBmcm9tOiBvbmVNb250aEFnbywgdG86IHRvZGF5IH0pO1xuXG4gICAgY29uc3QgZmV0Y2hNb3ZlbWVudHMgPSB1c2VDYWxsYmFjayhhc3luYyAocGFnZVVybD86IHN0cmluZykgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gLS0tIEzDk0dJQ0EgUEFSQSBQUk9EVUNUT1MgLS0tXG4gICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XG4gICAgICAgICAgICBwYXJhbXMuc2V0KCdzdGFydF9kYXRlJywgZGF0ZVJhbmdlLmZyb20pO1xuICAgICAgICAgICAgcGFyYW1zLnNldCgnZW5kX2RhdGUnLCBkYXRlUmFuZ2UudG8pO1xuICAgICAgICAgICAgcGFyYW1zLnNldCgncHJvZHVjdF9pZCcsIGVudGl0eUlkLnRvU3RyaW5nKCkpO1xuXG4gICAgICAgICAgICBpZiAocGFnZVVybCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhZ2UgPSBuZXcgVVJMKHBhZ2VVcmwsICdodHRwOi8vbG9jYWxob3N0Jykuc2VhcmNoUGFyYW1zLmdldCgncGFnZScpIHx8ICcxJztcbiAgICAgICAgICAgICAgICBwYXJhbXMuc2V0KCdwYWdlJywgcGFnZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHVybCA9IGAke2VuZHBvaW50fT8ke3BhcmFtcy50b1N0cmluZygpfWA7XG5cbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgc2VhcmNoPFN0b2NrTW92ZW1lbnQ+KHVybCk7XG4gICAgICAgICAgICBzZXRNb3ZlbWVudHMocmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICBzZXRQYWdpbmF0aW9uTWV0YShyZXNwb25zZS5tZXRhKTtcblxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBsb3MgbW92aW1pZW50b3MgZGUgc3RvY2suJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW2VuZHBvaW50LCBlbnRpdHlJZCwgZGF0ZVJhbmdlLmZyb20sIGRhdGVSYW5nZS50b10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZmV0Y2hNb3ZlbWVudHMoKTtcbiAgICB9LCBbZmV0Y2hNb3ZlbWVudHNdKTtcblxuICAgIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgZmV0Y2hNb3ZlbWVudHModXJsKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRmlsdGVyU3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGZldGNoTW92ZW1lbnRzKCk7XG4gICAgfTtcblxuICAgIC8vIENvbHVtbmFzIFN0b2NrXG4gICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgeyBrZXk6ICdtb3ZlbWVudF9kYXRlJywgbGFiZWw6ICdGZWNoYScgfSxcbiAgICAgICAgeyBrZXk6ICdtb3ZlbWVudF9jb2RlJywgbGFiZWw6ICdUaXBvJyB9LFxuICAgICAgICB7IGtleTogJ2RvY3VtZW50JywgbGFiZWw6ICdOwrogRG9jdW1lbnRvJyB9LFxuICAgICAgICB7IGtleTogJ2VudGl0eScsIGxhYmVsOiAnQ2xpZW50ZS9Qcm92ZWVkb3InIH0sXG4gICAgICAgIHsga2V5OiAncXVhbnRpdHknLCBsYWJlbDogJ0NhbnRpZGFkJyB9LFxuICAgIF07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTZcIj5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVGaWx0ZXJTdWJtaXR9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGdhcC00IG1iLTQgcC00IGJnLWdyYXktNTAgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImRhdGVfZnJvbVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkRlc2RlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVfZnJvbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0ZVJhbmdlLmZyb219XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREYXRlUmFuZ2UocHJldiA9PiAoeyAuLi5wcmV2LCBmcm9tOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImRhdGVfdG9cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5IYXN0YTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlX3RvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlUmFuZ2UudG99XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREYXRlUmFuZ2UocHJldiA9PiAoeyAuLi5wcmV2LCB0bzogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEZhRmlsdGVyIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEZpbHRyYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPExvYWRpbmdTcGlubmVyIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29sdW1ucy5tYXAoY29sID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGgga2V5PXtjb2wua2V5fSBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT17YHB5LTMuNSBweC0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCAke2NvbC5rZXkgPT09ICdxdWFudGl0eScgPyAndGV4dC1yaWdodCcgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb3ZlbWVudHMubWFwKChtb3YpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e21vdi5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPntmb3JtYXRWYWx1ZShtb3YubW92ZW1lbnRfZGF0ZSwgJ2RhdGUnKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbVwiPnttb3YubW92ZW1lbnRfY29kZSA9PT0gJ0EnID8gJ0VudHJhZGEnIDogbW92Lm1vdmVtZW50X2NvZGUgPT09ICdCJyB8fCBtb3YubW92ZW1lbnRfY29kZSA9PT0gJ0YnIHx8IG1vdi5tb3ZlbWVudF9jb2RlID09PSAnUycgPyAnU2FsaWRhJyA6IChtb3YubW92ZW1lbnRfY29kZSA/PyAnLScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJTdG9ja01vdmVtZW50Vm91Y2hlckxpbmsobW92IGFzIGFueSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj57bW92LmNsaWVudF9uYW1lIHx8IG1vdi52ZW5kb3JfbmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtc2VtaWJvbGRcIj57cmVuZGVyU2lnbmVkU3RvY2tRdWFudGl0eShtb3YubW92ZW1lbnRfY29kZSwgbW92LnF1YW50aXR5LCB7IGVtcGhhc2l6ZUVudHJhZGE6IHRydWUgfSl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge3BhZ2luYXRpb25NZXRhICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdpbmF0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0YT17cGFnaW5hdGlvbk1ldGF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0TW92ZW1lbnRzVGFiLnRzeCJ9