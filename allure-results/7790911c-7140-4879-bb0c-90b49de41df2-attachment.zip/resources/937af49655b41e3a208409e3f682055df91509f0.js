import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/compras/pages/ComprasFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/compras/pages/ComprasFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaPlus, FaSave, FaSpinner, FaTrash, FaSearch, FaExternalLinkAlt, FaPencilAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useModal } from "/src/context/ModalContext.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, search, create, update, getAll } from "/src/services/apiService.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { comprasModuleConfig } from "/src/features/compras/compras.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { articulosModuleConfig, articulosItemSearchFilters } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { formatDateForInput, formatValue } from "/src/utils/formatters.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import {} from "/src/types/appliedTaxes.ts";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import {} from "/src/features/impuestos/impuestos.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const filterVendorTaxesTypeGeneral = (taxes) => (taxes ?? []).filter((t) => t.type === 1);
const addDays = (date, days) => {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
};
const currentMonthPadded = () => String((/* @__PURE__ */ new Date()).getMonth() + 1).padStart(2, "0");
const currentYear = () => (/* @__PURE__ */ new Date()).getFullYear();
export const ComprasFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: initialPurchase, loading: loadingInitial, loading } = useCrudItem(comprasModuleConfig, id);
  const { showConfirmationModal } = useModal();
  const [header, setHeader] = useState({
    purchase_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    due_date: formatDateForInput(addDays(/* @__PURE__ */ new Date(), 7)),
    series: "B",
    vendor_id: null,
    vendor_code_input: "",
    vendor_name: null,
    currency_id: null,
    currency_code: "",
    currency_name: null,
    document_number: "",
    internal_voucher: "",
    delivery_note: "",
    withouttax_amount: 0,
    discount: 0,
    exchange_rate: 0,
    imputation_month: currentMonthPadded(),
    imputation_year: currentYear()
  });
  const [vendorTaxes, setVendorTaxes] = useState([]);
  const [items, setItems] = useState([]);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [isSingleTaxAmountEditable, setIsSingleTaxAmountEditable] = useState(false);
  const [perceptionRows, setPerceptionRows] = useState([]);
  const [perceptionTaxes, setPerceptionTaxes] = useState([]);
  const [productItems, setProductItems] = useState([]);
  const [isFetchingMovements, setIsFetchingMovements] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [invoiceImageFile, setInvoiceImageFile] = useState(null);
  const [modalConfig, setModalConfig] = useState(null);
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const initialItem100301Loaded = useRef(false);
  const skipInitialEditTaxRecalcRef = useRef(!!id);
  const editTaxBaselineRef = useRef(null);
  useEffect(() => {
    if (mode === "edit" && initialPurchase) {
      skipInitialEditTaxRecalcRef.current = true;
      editTaxBaselineRef.current = null;
      setHeader({
        purchase_date: initialPurchase.purchase_date,
        due_date: formatDateForInput(new Date(initialPurchase.due_date)),
        series: initialPurchase.series || "B",
        vendor_id: initialPurchase.vendor_id,
        vendor_code_input: initialPurchase.vendor?.vendor_code || "",
        vendor_name: initialPurchase.vendor?.name || null,
        currency_id: initialPurchase.currency_id,
        currency_code: initialPurchase.currency_code || "",
        currency_name: initialPurchase.currency_name || null,
        document_number: initialPurchase.document_number,
        internal_voucher: initialPurchase.internal_voucher || "",
        delivery_note: initialPurchase.delivery_note || "",
        withouttax_amount: initialPurchase.withouttax_amount || 0,
        discount: initialPurchase.discount || 0,
        exchange_rate: initialPurchase.exchange_rate || 0,
        imputation_month: initialPurchase.imputation_month ?? currentMonthPadded(),
        imputation_year: initialPurchase.imputation_year ?? currentYear()
      });
      setItems(initialPurchase.items.map((i) => ({ ...i, tempId: crypto.randomUUID(), chart_code_input: i.chart_account_code })));
      const loadedProducts = initialPurchase.products?.map((prod) => ({
        tempId: crypto.randomUUID(),
        product_id: prod.product_id,
        product_code: prod.product_code || "",
        // Usamos 'product_code' (SKU)
        product_name: prod.product_name,
        quantity: Number(prod.quantity),
        price_cost: Number(prod.price_cost)
      })) || [];
      setProductItems(loadedProducts);
      const fetchVendorTaxes = async () => {
        try {
          if (initialPurchase.vendor?.relatedTaxes) {
            setVendorTaxes(filterVendorTaxesTypeGeneral(initialPurchase.vendor.relatedTaxes));
          } else {
            const fullVendor = await getById("vendors", initialPurchase.vendor_id);
            setVendorTaxes(filterVendorTaxesTypeGeneral(fullVendor.relatedTaxes || []));
          }
        } catch (error) {
          console.error("Failed to fetch vendor taxes on edit:", error);
          toast.error("No se pudieron cargar los impuestos del proveedor para la edición.");
        }
      };
      fetchVendorTaxes();
      const taxesType1 = (initialPurchase.applied_taxes || []).filter((t) => t.tax_type === 1);
      const taxesType2 = (initialPurchase.applied_taxes || []).filter((t) => t.tax_type === 2);
      setAppliedTaxes(taxesType1);
      setPerceptionRows(taxesType2.map((t) => ({
        tempId: crypto.randomUUID(),
        tax_id: t.tax_id,
        tax_name: t.tax_name ?? t.tax?.name ?? null,
        amount: Number(t.amount) || 0
      })));
    }
  }, [mode, initialPurchase]);
  useEffect(() => {
    getAll("taxes", { type: "2" }).then((res) => setPerceptionTaxes(res.data || [])).catch(() => setPerceptionTaxes([]));
  }, []);
  useEffect(() => {
    if (id || initialItem100301Loaded.current) return;
    if (items.length > 0) return;
    initialItem100301Loaded.current = true;
    search(`${planDeCuentasModuleConfig.endpoint}?code=100301`).then((response) => {
      if (response.data.length > 0) {
        const account = response.data[0];
        setItems([{
          tempId: crypto.randomUUID(),
          legacy_chart_account_code: account.id,
          chart_account_name: account.name,
          chart_code_input: "100301",
          value: 0
        }]);
      }
    }).catch(() => {
      initialItem100301Loaded.current = false;
    });
  }, [id, items.length]);
  const subtotal = useMemo(() => {
    return items.reduce((sum, item) => sum + (Number(item.value) || 0), 0);
  }, [items]);
  useEffect(() => {
    if (id) return;
    if (vendorTaxes.length === 0) {
      setAppliedTaxes([]);
      return;
    }
    if (vendorTaxes.length > 1) {
      setAppliedTaxes(vendorTaxes.map((t) => ({
        tax_id: t.id,
        tax_name: t.name,
        rate: t.rate,
        amount: 0
      })));
    }
  }, [id, vendorTaxes]);
  useEffect(() => {
    if (vendorTaxes.length !== 1 || isSingleTaxAmountEditable) return;
    const inputs = {
      subtotal,
      discount: header.discount || 0,
      withouttax: header.withouttax_amount || 0
    };
    if (id) {
      if (skipInitialEditTaxRecalcRef.current) {
        skipInitialEditTaxRecalcRef.current = false;
        editTaxBaselineRef.current = inputs;
        return;
      }
      if (editTaxBaselineRef.current !== null) {
        const prev = editTaxBaselineRef.current;
        if (prev.subtotal === inputs.subtotal && prev.discount === inputs.discount && prev.withouttax === inputs.withouttax) {
          return;
        }
      }
      editTaxBaselineRef.current = inputs;
    }
    const taxBase = inputs.subtotal - inputs.discount;
    const calculatedTaxes = vendorTaxes.map((tax) => ({
      tax_id: tax.id,
      tax_name: tax.name,
      rate: tax.rate,
      amount: taxBase * (tax.rate / 100)
    }));
    setAppliedTaxes(calculatedTaxes);
  }, [id, subtotal, header.discount, header.withouttax_amount, vendorTaxes, isSingleTaxAmountEditable]);
  const totals = useMemo(() => {
    const taxTotal = appliedTaxes.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0);
    const percepcionesTotal = perceptionRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
    const withouttax = header.withouttax_amount || 0;
    const grandTotal = subtotal - (header.discount || 0) + withouttax + taxTotal + percepcionesTotal;
    return { subtotal, taxTotal, percepcionesTotal, grandTotal };
  }, [subtotal, appliedTaxes, perceptionRows, header.discount, header.withouttax_amount]);
  const handleHeaderChange = (field, value) => {
    setHeader((prev) => ({ ...prev, [field]: value }));
  };
  const handleRequestEditSingleTax = () => {
    showConfirmationModal({
      title: "Modificar importe de impuesto",
      message: "¿Desea editar manualmente el importe del impuesto? Dejará de actualizarse automáticamente al cambiar subtotales, descuentos o valor no gravado.",
      onConfirm: () => setIsSingleTaxAmountEditable(true)
    });
  };
  const handleSelectVendor = async (vendor) => {
    setIsSingleTaxAmountEditable(false);
    skipInitialEditTaxRecalcRef.current = false;
    editTaxBaselineRef.current = null;
    setHeader({
      ...header,
      vendor_id: vendor.id,
      vendor_name: vendor.name,
      vendor_code_input: vendor.vendor_code || ""
    });
    try {
      const fullVendor = await getById("vendors", vendor.id);
      setVendorTaxes(filterVendorTaxesTypeGeneral(fullVendor.taxes || []));
      setAppliedTaxes([]);
      const days = Number(fullVendor.payment_condition) || 0;
      setHeader((prev) => ({
        ...prev,
        due_date: formatDateForInput(addDays(/* @__PURE__ */ new Date(), days)),
        series: fullVendor.serie ?? prev.series ?? "B"
      }));
    } catch {
      toast.error("No se pudieron cargar los impuestos del proveedor.");
      setVendorTaxes([]);
    }
  };
  const handleSelectCurrency = async (currency) => {
    setHeader({
      ...header,
      currency_id: currency.id,
      currency_name: currency.name,
      currency_code: currency.code,
      exchange_rate: Number(currency.exchange_rate) || 0
    });
  };
  const handleVendorCodeSubmit = async () => {
    const code = header.vendor_code_input;
    if (!code) {
      toast.info("Ingrese un código de proveedor para buscar.");
      return;
    }
    try {
      const response = await search(`${proveedoresModuleConfig.endpoint}?vendor_code=${code}`);
      if (response.data.length > 0) {
        handleSelectVendor(response.data[0]);
      } else {
        toast.error("Proveedor no encontrado con ese código.");
        setHeader((prev) => ({ ...prev, vendor_id: null, vendor_name: null }));
      }
    } catch (error) {
      console.log(error);
      toast.error("Error al buscar proveedor.");
    }
  };
  const handleCurrencyCodeSubmit = async () => {
    const code = header.currency_code;
    if (!code) {
      toast.info("Ingrese un código de moneda para buscar.");
      return;
    }
    try {
      const response = await search(`${monedasModuleConfig.endpoint}?code=${code}`);
      if (response.data.length > 0) {
        handleSelectCurrency(response.data[0]);
      } else {
        toast.error("Moneda no encontrada con ese código.");
        setHeader((prev) => ({ ...prev, vendor_id: null, vendor_name: null }));
      }
    } catch (error) {
      console.log(error);
      toast.error("Error al buscar proveedor.");
    }
  };
  const handleAddItem = () => setItems((prev) => [...prev, { tempId: crypto.randomUUID(), legacy_chart_account_code: null, value: 0 }]);
  const handleRemoveItem = (tempId) => setItems((prev) => prev.filter((i) => i.tempId !== tempId));
  const handleUpdateItem = (tempId, field, value) => {
    setItems((prev) => prev.map((i) => i.tempId === tempId ? { ...i, [field]: value } : i));
  };
  const handleAccountCodeSubmit = async (tempId) => {
    const item = items.find((i) => i.tempId === tempId);
    const code = item?.chart_code_input;
    if (!code) return toast.info("Ingrese un código de cuenta para buscar.");
    try {
      const response = await search(`${planDeCuentasModuleConfig.endpoint}?code=${code}`);
      if (response.data.length > 0) {
        const account = response.data[0];
        handleUpdateItem(tempId, "legacy_chart_account_code", account.id);
        handleUpdateItem(tempId, "chart_account_name", account.name);
        handleUpdateItem(tempId, "chart_code_input", account.code || String(account.id));
      } else {
        toast.error("Cuenta no encontrada con ese código.");
        handleUpdateItem(tempId, "legacy_chart_account_code", null);
        handleUpdateItem(tempId, "chart_account_name", "");
      }
    } catch (error) {
      toast.error("Error al buscar la cuenta contable.");
      console.error(error);
    }
  };
  const handleFetchStockMovements = async () => {
    if (!header.vendor_id) {
      toast.info("Seleccione un proveedor antes de buscar por remito.");
      return;
    }
    setIsFetchingMovements(true);
    setProductItems([]);
    try {
      const endpoint = `stock-movements?delivery_note=${encodeURIComponent(header.delivery_note)}&vendor_id=${header.vendor_id}`;
      const response = await search(endpoint);
      const list = Array.isArray(response?.data) ? response.data : Array.isArray(response) ? response : [];
      if (list.length === 0) {
        toast.info("No se encontraron movimientos de stock para ese remito y proveedor.");
        setIsFetchingMovements(false);
        return;
      }
      toast.info(`Cargando ${list.length} productos del remito...`);
      const newProductItems = [];
      for (const movement of list) {
        let cost = 0;
        let productId = null;
        const sku = movement.sku ?? movement.product_code ?? "";
        if (sku) {
          try {
            const prodResponse = await search(`${articulosModuleConfig.endpoint}?sku=${encodeURIComponent(sku)}`);
            const prodList = Array.isArray(prodResponse?.data) ? prodResponse.data : Array.isArray(prodResponse) ? prodResponse : [];
            if (prodList.length > 0) {
              cost = Number(prodList[0].cost_price) || 0;
              productId = prodList[0].id;
            }
          } catch (e) {
            console.error("Error fetching cost_price", e);
          }
        }
        newProductItems.push({
          tempId: crypto.randomUUID(),
          product_id: productId,
          product_code: sku,
          product_name: movement.product_name ?? movement.name ?? null,
          quantity: Number(movement.quantity) || 0,
          price_cost: cost
        });
      }
      setProductItems(newProductItems);
      try {
        const productsTotal = newProductItems.reduce((sum, p) => sum + (Number(p.quantity) || 0) * (Number(p.price_cost) || 0), 0);
        setItems((prev) => {
          const idx = prev.findIndex((i) => i.chart_code_input === "100301");
          if (idx === -1) return prev;
          return prev.map((item, i) => i === idx ? { ...item, value: productsTotal } : item);
        });
      } catch (e) {
        console.error("Error actualizando ítem 100301:", e);
      }
    } catch (error) {
      toast.error("Error al buscar los movimientos de stock.");
      console.error(error);
    } finally {
      setIsFetchingMovements(false);
    }
  };
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const allowedTypes = ["image/jpeg", "image/png", "application/pdf", "image/jpg"];
      const maxSize = 5120 * 1024;
      if (!allowedTypes.includes(file.type)) {
        toast.error("Tipo de archivo no permitido. Solo JPG, JPEG, PNG o PDF.");
        e.target.value = "";
        setInvoiceImageFile(null);
        return;
      }
      if (file.size > maxSize) {
        toast.error("El archivo excede el tamaño máximo de 5MB.");
        e.target.value = "";
        setInvoiceImageFile(null);
        return;
      }
      setInvoiceImageFile(file);
    } else {
      setInvoiceImageFile(null);
    }
  };
  const handleViewFile = async () => {
    if (!initialPurchase?.id) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el archivo.");
      return;
    }
    setIsLoadingFile(true);
    try {
      await finishPdfPreview(session, `/purchases/${initialPurchase.id}/file`);
    } catch (error) {
      if (!session.window.closed) session.window.close();
      console.error("Error al obtener el archivo:", error);
      toast.error("No se pudo abrir el archivo adjunto.");
    } finally {
      setIsLoadingFile(false);
    }
  };
  const handleSave = async () => {
    if (!header.vendor_id || !header.document_number || !header.currency_id) {
      toast.error("Proveedor, Nº de Factura, Remito y Moneda son obligatorios.");
      return;
    }
    if (!header.series) {
      toast.error("La serie es obligatoria.");
      return;
    }
    if (items.length === 0 || items.some((i) => !i.legacy_chart_account_code || i.value <= 0)) {
      toast.error("Debe añadir al menos un ítem con cuenta contable y valor válido.");
      return;
    }
    const productsTotal = productItems.reduce((sum, p) => {
      const qty = Number(p.quantity) || 0;
      const cost = Number(p.price_cost) || 0;
      return sum + qty * cost;
    }, 0);
    const itemsTotal = subtotal;
    if (productItems.length > 0) {
      const prodRounded = Math.round(productsTotal * 100);
      const itemsRounded = Math.round(itemsTotal * 100);
      if (prodRounded !== itemsRounded) {
        toast.error(
          `El total de productos debe ser igual al total de los ítems contables. Total productos: ${formatValue(productsTotal, "currency")} - Total ítems: ${formatValue(itemsTotal, "currency")}`
        );
        return;
      }
    }
    const cleanItems = items.map((item, index) => {
      const { tempId, chart_account_name, ...rest } = item;
      if (tempId === void 0) console.log("Ignoring tempId");
      if (chart_account_name === void 0) console.log("Ignoring chart_account_name");
      return {
        ...rest,
        item_number: index + 1
        // Add the item_number based on index
      };
    });
    const taxesType1 = appliedTaxes.filter((tax) => tax.amount > 0).map((tax) => ({ tax_id: tax.tax_id, amount: tax.amount, rate: tax.rate, tax_type: 1 }));
    const taxesType2 = perceptionRows.filter((r) => r.tax_id != null && r.amount > 0).map((r) => ({ tax_id: r.tax_id, amount: r.amount, rate: 0, tax_type: 2 }));
    const cleanTaxes = [...taxesType1, ...taxesType2];
    const cleanProducts = productItems.map((item, index) => {
      const { tempId, ...rest } = item;
      return {
        ...rest,
        item_number: index + 1
      };
    });
    const payload = {
      ...header,
      items: cleanItems,
      taxes: cleanTaxes,
      products: cleanProducts,
      total_amount: totals.grandTotal
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(payload));
    if (invoiceImageFile) {
      formData.append("invoice_image", invoiceImageFile);
    }
    try {
      if (mode === "create") {
        await create(comprasModuleConfig.endpoint, formData);
        toast.success("Compra creada con éxito");
      } else {
        await update(comprasModuleConfig.endpoint, id, formData);
        toast.success("Compra actualizada con éxito");
      }
      navigate(getListReturnPath(comprasModuleConfig.baseRoute));
    } catch (error) {
      const errorMsg = error.response?.data?.message || error.message || "Error al guardar la compra";
      toast.error(errorMsg);
    }
  };
  const openModal = (target, config) => {
    setEditingTarget(target);
    const isProductItem = typeof target === "object" && target?.type === "product_item";
    setModalConfig(
      isProductItem ? { ...config, initialFilters: articulosItemSearchFilters } : config
    );
    setIsModalOpen(true);
  };
  const handleAddProductItem = () => {
    setProductItems(
      (prev) => [
        ...prev,
        {
          tempId: crypto.randomUUID(),
          product_id: null,
          product_code: "",
          product_name: null,
          quantity: 1,
          price_cost: 0
        }
      ]
    );
  };
  const handleRemoveProductItem = (tempId) => setProductItems((prev) => prev.filter((i) => i.tempId !== tempId));
  const handleUpdateProductItem = (tempId, field, value) => {
    setProductItems((prev) => prev.map((i) => i.tempId === tempId ? { ...i, [field]: value } : i));
  };
  const handleSelectProduct = (tempId, product) => {
    setProductItems((prev) => prev.map(
      (i) => i.tempId === tempId ? {
        ...i,
        product_id: product.id,
        product_code: product.sku,
        // Usamos 'sku'
        product_name: product.name,
        price_cost: Number(product.cost_price) || 0
        // ¡Usamos el cost_price!
      } : i
    ));
  };
  const handleAddPerceptionRow = () => {
    setPerceptionRows((prev) => [...prev, { tempId: crypto.randomUUID(), tax_id: null, tax_name: null, amount: 0 }]);
  };
  const handleRemovePerceptionRow = (tempId) => {
    setPerceptionRows((prev) => prev.filter((r) => r.tempId !== tempId));
  };
  const handleUpdatePerceptionRow = (tempId, field, value) => {
    setPerceptionRows((prev) => prev.map((r) => r.tempId === tempId ? { ...r, [field]: value } : r));
  };
  const handleSelectPerceptionTax = (tempId, tax) => {
    const alreadyUsed = perceptionRows.some((r) => r.tempId !== tempId && r.tax_id === tax.id);
    if (alreadyUsed) {
      toast.warn("Esa percepción ya está en la lista. No se puede repetir.");
      return;
    }
    setPerceptionRows((prev) => prev.map(
      (r) => r.tempId === tempId ? { ...r, tax_id: tax.id, tax_name: tax.name } : r
    ));
  };
  const handleUpdateAppliedTaxAmount = (tax_id, amount) => {
    setAppliedTaxes((prev) => prev.map((t) => t.tax_id === tax_id ? { ...t, amount } : t));
  };
  const handleProductCodeSubmit = async (tempId) => {
    const item = productItems.find((i) => i.tempId === tempId);
    const code = item?.product_code;
    if (!code) return toast.info("Ingrese un código de producto (SKU)");
    try {
      const response = await search(`${articulosModuleConfig.endpoint}?sku=${code}`);
      if (response.data.length > 0) {
        handleSelectProduct(tempId, response.data[0]);
      } else {
        toast.error("Producto no encontrado con ese SKU.");
      }
    } catch (error) {
      console.error(error);
      toast.error("Error al buscar producto.");
    }
  };
  const handleSelectModal = (selected) => {
    if (!editingTarget) {
      setIsModalOpen(false);
      return;
    }
    if (editingTarget === "vendor") {
      handleSelectVendor(selected);
    } else if (editingTarget === "currency") {
      handleSelectCurrency(selected);
    } else if (typeof editingTarget === "object" && editingTarget.type === "item") {
      const account = selected;
      const itemToUpdate = items.find((i) => i.tempId === editingTarget.tempId);
      if (itemToUpdate?.tempId) {
        handleUpdateItem(itemToUpdate.tempId, "legacy_chart_account_code", account.id);
        handleUpdateItem(itemToUpdate.tempId, "chart_account_name", account.name);
        handleUpdateItem(itemToUpdate.tempId, "chart_code_input", account.code || String(account.id));
      }
    } else if (typeof editingTarget === "object" && editingTarget.type === "product_item") {
      const product = selected;
      handleSelectProduct(editingTarget.tempId, product);
    }
    setIsModalOpen(false);
  };
  if (loadingInitial) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
    lineNumber: 753,
    columnNumber: 30
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Ingreso de Comprobante de Compra" : `Editando Compra #${id}` }, void 0, false, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 757,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 md:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Fecha de Compra ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 762,
            columnNumber: 100
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 762,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "date", value: header.purchase_date, onChange: (e) => handleHeaderChange("purchase_date", e.target.value), className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm", autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 763,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 761,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha de Vencimiento" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 766,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "date", value: header.due_date, onChange: (e) => handleHeaderChange("due_date", e.target.value), className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm", autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 767,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 765,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Proveedor ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 770,
            columnNumber: 94
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 770,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: header.vendor_code_input || "",
            nameValue: header.vendor_name,
            onCodeChange: (newCode) => {
              handleHeaderChange("vendor_code_input", newCode);
              handleHeaderChange("vendor_id", null);
              handleHeaderChange("vendor_name", null);
              setVendorTaxes([]);
              setIsSingleTaxAmountEditable(false);
              skipInitialEditTaxRecalcRef.current = false;
              editTaxBaselineRef.current = null;
            },
            onCodeSubmit: handleVendorCodeSubmit,
            onSearchClick: () => openModal("vendor", proveedoresModuleConfig),
            onClearClick: () => {
              handleHeaderChange("vendor_id", null);
              handleHeaderChange("vendor_name", null);
              handleHeaderChange("vendor_code_input", "");
              setVendorTaxes([]);
              setIsSingleTaxAmountEditable(false);
              skipInitialEditTaxRecalcRef.current = false;
              editTaxBaselineRef.current = null;
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 771,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 769,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Nº de Factura ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 797,
            columnNumber: 98
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 797,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: header.document_number,
            onChange: (e) => handleHeaderChange("document_number", e.target.value),
            className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 798,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 796,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Serie ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 803,
            columnNumber: 90
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 803,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: header.series || "B",
            onChange: (e) => handleHeaderChange("series", e.target.value),
            className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 809,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 810,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 811,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "X", children: "X" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 812,
                columnNumber: 29
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 804,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 802,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Remito" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 816,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: header.delivery_note, onChange: (e) => handleHeaderChange("delivery_note", e.target.value), className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm", autoComplete: "off" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 818,
            columnNumber: 29
          }, this),
          header.vendor_id && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleFetchStockMovements,
              disabled: isFetchingMovements,
              className: "absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 hover:text-indigo-600 disabled:cursor-not-allowed",
              children: isFetchingMovements ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 825,
                columnNumber: 60
              }, this) : /* @__PURE__ */ jsxDEV(FaSearch, {}, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 825,
                columnNumber: 101
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 820,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 817,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 815,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Moneda ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 832,
            columnNumber: 91
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 832,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: header.currency_code || "",
            nameValue: header.currency_name || "",
            onCodeChange: (newCode) => {
              handleHeaderChange("currency_code", newCode);
              handleHeaderChange("currency_id", null);
              handleHeaderChange("currency_name", null);
            },
            onCodeSubmit: handleCurrencyCodeSubmit,
            onSearchClick: () => openModal("currency", monedasModuleConfig),
            onClearClick: () => {
              handleHeaderChange("currency_id", null);
              handleHeaderChange("currency_name", null);
              handleHeaderChange("currency_code", "");
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 833,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 831,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo de cambio" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 853,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          DecimalInput,
          {
            name: "exchange_rate",
            value: header.exchange_rate,
            onChange: (num) => handleHeaderChange("exchange_rate", num),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 854,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 852,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Mes de imputación" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 862,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: header.imputation_month,
            onChange: (e) => handleHeaderChange("imputation_month", e.target.value),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            children: Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, "0")).map(
              (m) => /* @__PURE__ */ jsxDEV("option", { value: m, children: m }, m, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 869,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 863,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 861,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Año de imputación" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 874,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: header.imputation_year,
            onChange: (e) => handleHeaderChange("imputation_year", Number(e.target.value)),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            children: Array.from({ length: currentYear() - 2025 + 1 }, (_, i) => 2025 + i).map(
              (y) => /* @__PURE__ */ jsxDEV("option", { value: y, children: y }, y, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 881,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 875,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 873,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-3", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "invoice_image", className: "block text-sm font-medium text-gray-700", children: "Imagen/PDF de Factura" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 888,
          columnNumber: 25
        }, this),
        mode === "edit" && initialPurchase?.invoice_image_path && /* @__PURE__ */ jsxDEV("div", { className: "mb-2 p-2 bg-blue-50 border border-blue-200 rounded-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-blue-700 mb-1", children: "Archivo actual:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 893,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleViewFile,
              disabled: isLoadingFile,
              className: "inline-flex items-center text-sm text-blue-600 hover:text-blue-800 underline cursor-pointer disabled:opacity-50 disabled:cursor-wait",
              children: [
                /* @__PURE__ */ jsxDEV(FaExternalLinkAlt, { className: "mr-1" }, void 0, false, {
                  fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                  lineNumber: 900,
                  columnNumber: 37
                }, this),
                isLoadingFile ? "Cargando..." : "Ver archivo actual"
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 894,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 892,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "file",
            id: "invoice_image",
            onChange: handleFileChange,
            autoComplete: "off",
            className: "block w-full mt-1 text-sm text-gray-900 border border-gray-300 rounded-md shadow-sm cursor-pointer focus:outline-none file:mr-4 file:py-2 file:px-4 file:rounded-l-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100",
            accept: ".jpg,.jpeg,.png,.pdf"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 905,
            columnNumber: 25
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: mode === "edit" && initialPurchase?.invoice_image_url ? "Seleccione un nuevo archivo para reemplazar el actual. Opcional. Tipos: JPG, PNG, PDF. Max: 5MB." : "Opcional. Tipos: JPG, PNG, PDF. Max: 5MB." }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 912,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 887,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 760,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 759,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos" }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 923,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Use esta tabla para cargar productos del remito o manualmente. No afecta el subtotal." }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 924,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-2/5", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 929,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cantidad" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 930,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Precio Unit. (Costo)" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 931,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Total" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 932,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 933,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 928,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 927,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: productItems.map(
          (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.product_code || "",
                nameValue: item.product_name || null,
                onCodeChange: (newCode) => {
                  handleUpdateProductItem(item.tempId, "product_code", newCode);
                  handleUpdateProductItem(item.tempId, "product_id", null);
                  handleUpdateProductItem(item.tempId, "product_name", null);
                  handleUpdateProductItem(item.tempId, "price_cost", 0);
                },
                onCodeSubmit: () => handleProductCodeSubmit(item.tempId),
                onSearchClick: () => openModal({ type: "product_item", tempId: item.tempId }, articulosModuleConfig),
                onClearClick: () => {
                  handleUpdateProductItem(item.tempId, "product_id", null);
                  handleUpdateProductItem(item.tempId, "product_name", null);
                  handleUpdateProductItem(item.tempId, "product_code", "");
                  handleUpdateProductItem(item.tempId, "price_cost", 0);
                },
                mask: "sku",
                enableAutocomplete: true,
                autocompleteConfig: {
                  endpoint: articulosModuleConfig.endpoint,
                  codeField: "sku",
                  nameField: "name",
                  searchParams: articulosItemSearchFilters,
                  onSelect: (product) => {
                    handleSelectProduct(item.tempId, product);
                  }
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 941,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 939,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: item.quantity, onChange: (num) => handleUpdateProductItem(item.tempId, "quantity", num), className: "w-24 px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 972,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 971,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: item.price_cost, onChange: (num) => handleUpdateProductItem(item.tempId, "price_cost", num), className: "w-32 px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 975,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 974,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-900 text-right", children: formatValue((item.quantity || 0) * (item.price_cost || 0), "currency") }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 977,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveProductItem(item.tempId), className: "text-red-500 hover:text-red-700", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 981,
              columnNumber: 147
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 981,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 980,
              columnNumber: 37
            }, this)
          ] }, item.tempId, true, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 938,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 936,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 926,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 925,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleAddProductItem, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 988,
          columnNumber: 216
        }, this),
        "Añadir Producto"
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 988,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 922,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg bg-gray-50", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Ítems" }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 992,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-3/5", children: "Cuenta Contable" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 997,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Valor" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 998,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 999,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 996,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 995,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map(
          (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.chart_code_input || "",
                nameValue: item.chart_account_name || null,
                onCodeChange: (newCode) => {
                  handleUpdateItem(item.tempId, "legacy_chart_account_code", null);
                  handleUpdateItem(item.tempId, "chart_account_name", "");
                  handleUpdateItem(item.tempId, "chart_code_input", newCode);
                },
                onCodeSubmit: () => handleAccountCodeSubmit(item.tempId),
                onSearchClick: () => openModal({ type: "item", tempId: item.tempId }, planDeCuentasModuleConfig),
                onClearClick: () => {
                  handleUpdateItem(item.tempId, "legacy_chart_account_code", null);
                  handleUpdateItem(item.tempId, "chart_account_name", "");
                  handleUpdateItem(item.tempId, "chart_code_input", "");
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 1006,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1005,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: item.value, onChange: (num) => handleUpdateItem(item.tempId, "value", num), className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1024,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1023,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveItem(item.tempId), className: "text-red-500 hover:text-red-700", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1027,
              columnNumber: 140
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1027,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1026,
              columnNumber: 37
            }, this)
          ] }, item.tempId, true, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1004,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1002,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 994,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 993,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleAddItem, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1034,
          columnNumber: 209
        }, this),
        "Añadir Ítem"
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 1034,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 991,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Impuestos y Descuentos" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1040,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 col-span-2", children: "Valor No Gravado (-)" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1042,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              value: header.withouttax_amount,
              onChange: (num) => handleHeaderChange("withouttax_amount", num),
              className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1043,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1041,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 col-span-2", children: "Descuento (-)" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1050,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              value: header.discount,
              onChange: (num) => handleHeaderChange("discount", num),
              className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1051,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1049,
          columnNumber: 21
        }, this),
        !header.vendor_id ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 pt-2", children: "Seleccione un proveedor para calcular sus impuestos." }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1058,
          columnNumber: 11
        }, this) : vendorTaxes.length > 0 ? appliedTaxes.map((tax) => {
          const isTaxAmountEditable = vendorTaxes.length > 1 || isSingleTaxAmountEditable;
          return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-medium text-gray-700 col-span-2", children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%)"
            ] }, void 0, true, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1064,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: isTaxAmountEditable ? /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                value: tax.amount,
                onChange: (num) => handleUpdateAppliedTaxAmount(tax.tax_id, num ?? 0),
                className: "w-full flex-1 px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 1067,
                columnNumber: 19
              },
              this
            ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "flex-1 w-full px-2 py-1 text-right text-gray-800 bg-gray-100 rounded-md", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 1074,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: handleRequestEditSingleTax,
                  "aria-label": "Editar importe de impuesto",
                  className: "p-1.5 text-gray-500 hover:text-indigo-600 rounded-md hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500",
                  children: /* @__PURE__ */ jsxDEV(FaPencilAlt, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                    lineNumber: 1083,
                    columnNumber: 53
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                  lineNumber: 1077,
                  columnNumber: 49
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1073,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1065,
              columnNumber: 37
            }, this)
          ] }, tax.tax_id, true, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1063,
            columnNumber: 15
          }, this);
        }) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 pt-2", children: "El proveedor seleccionado no tiene impuestos configurados." }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1092,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 mt-4 border-t border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium text-gray-800 mb-2", children: "Percepciones" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1095,
            columnNumber: 25
          }, this),
          perceptionTaxes.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No hay percepciones configuradas." }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1097,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: perceptionRows.map(
              (row) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: row.tax_id ?? "",
                    onChange: (e) => {
                      const val = e.target.value;
                      if (!val) {
                        handleUpdatePerceptionRow(row.tempId, "tax_id", null);
                        handleUpdatePerceptionRow(row.tempId, "tax_name", null);
                        return;
                      }
                      const tax = perceptionTaxes.find((t) => t.id === Number(val));
                      if (tax) handleSelectPerceptionTax(row.tempId, tax);
                    },
                    className: "col-span-2 w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm sm:text-sm",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccione percepción" }, void 0, false, {
                        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                        lineNumber: 1117,
                        columnNumber: 49
                      }, this),
                      perceptionTaxes.map(
                        (tax) => /* @__PURE__ */ jsxDEV("option", { value: tax.id, disabled: perceptionRows.some((r) => r.tempId !== row.tempId && r.tax_id === tax.id), children: tax.name }, tax.id, false, {
                          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                          lineNumber: 1119,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                    lineNumber: 1103,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    DecimalInput,
                    {
                      value: row.amount,
                      onChange: (num) => handleUpdatePerceptionRow(row.tempId, "amount", num),
                      className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm sm:text-sm",
                      placeholder: "0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                      lineNumber: 1125,
                      columnNumber: 49
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemovePerceptionRow(row.tempId), className: "text-red-500 hover:text-red-700 p-1", title: "Quitar", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                    lineNumber: 1131,
                    columnNumber: 188
                  }, this) }, void 0, false, {
                    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                    lineNumber: 1131,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                  lineNumber: 1124,
                  columnNumber: 45
                }, this)
              ] }, row.tempId, true, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 1102,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1100,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddPerceptionRow, className: "inline-flex items-center px-3 py-2 mt-2 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700", children: [
              /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
                lineNumber: 1137,
                columnNumber: 37
              }, this),
              " Agregar percepción"
            ] }, void 0, true, {
              fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
              lineNumber: 1136,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1099,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1094,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 1039,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 border rounded-lg space-y-2 flex flex-col justify-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1144,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1144,
            columnNumber: 90
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1144,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-gray-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Valor No Gravado (no gravado):" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1145,
            columnNumber: 81
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(header.withouttax_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1145,
            columnNumber: 125
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1145,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-red-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Descuento:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1146,
            columnNumber: 80
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: [
            "- ",
            formatValue(header.discount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1146,
            columnNumber: 104
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1146,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Impuestos:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1147,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.taxTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1147,
            columnNumber: 91
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1147,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Percepciones:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1148,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.percepcionesTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1148,
            columnNumber: 94
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1148,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold text-lg border-t pt-2 mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "TOTAL:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1149,
            columnNumber: 96
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.grandTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
            lineNumber: 1149,
            columnNumber: 116
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1149,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 1143,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 1037,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(comprasModuleConfig.baseRoute)), className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 1154,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: loading, className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-green-400", children: [
        loading ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1156,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
          lineNumber: 1156,
          columnNumber: 86
        }, this),
        "Guardar Compra"
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
        lineNumber: 1155,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 1153,
      columnNumber: 13
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => setIsModalOpen(false), onSelect: handleSelectModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
      lineNumber: 1162,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/compras/pages/ComprasFormPage.tsx",
    lineNumber: 756,
    columnNumber: 5
  }, this);
};
_s(ComprasFormPage, "Z585z3egqLveAHR0ig2q2b6bjEQ=", false, function() {
  return [useParams, useNavigate, useCrudItem, useModal];
});
_c = ComprasFormPage;
var _c;
$RefreshReg$(_c, "ComprasFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/compras/pages/ComprasFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/compras/pages/ComprasFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNnRCK0IsU0FnVWEsVUFoVWI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBM3RCL0IsU0FBU0EsVUFBVUMsV0FBV0MsU0FBU0MsY0FBYztBQUNyRCxTQUFTQyxhQUFhQyxpQkFBaUI7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxRQUFRQyxXQUFXQyxTQUFTQyxVQUFVQyxtQkFBbUJDLG1CQUFtQjtBQUM3RixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFNBQVNDLFFBQVFDLFFBQVFDLFFBQVFDLGNBQWM7QUFDeEQsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFDbEQsU0FBU0MsMkJBQTZEO0FBQ3RFLFNBQXlCQywrQkFBK0I7QUFDeEQsU0FBU0MsaUNBQXFEO0FBQzlELFNBQXdCQyx1QkFBdUJDLGtDQUFrQztBQUNqRixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxvQkFBb0JDLG1CQUFtQjtBQUNoRCxTQUFTQyxzQkFBc0I7QUFDL0IsZUFBOEQ7QUFDOUQsU0FBU0MsMkJBQXdDO0FBQ2pELGVBQXlCO0FBQ3pCLFNBQVNDLHlCQUF5QjtBQW1CbEMsTUFBTUMsK0JBQStCQSxDQUFDQyxXQUNqQ0EsU0FBUyxJQUFJQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFNBQVMsQ0FBQztBQVU1QyxNQUFNQyxVQUFVQSxDQUFDQyxNQUFZQyxTQUF1QjtBQUNoRCxRQUFNQyxTQUFTLElBQUlDLEtBQUtILElBQUk7QUFDNUJFLFNBQU9FLFFBQVFGLE9BQU9HLFFBQVEsSUFBSUosSUFBSTtBQUN0QyxTQUFPQztBQUNYO0FBRUEsTUFBTUkscUJBQXFCQSxNQUFNQyxRQUFPLG9CQUFJSixLQUFLLEdBQUVLLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2xGLE1BQU1DLGNBQWNBLE9BQU0sb0JBQUlQLEtBQUssR0FBRVEsWUFBWTtBQUUxQyxhQUFNQyxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLEVBQUVDLEdBQUcsSUFBSW5ELFVBQTBCO0FBQ3pDLFFBQU1vRCxXQUFXckQsWUFBWTtBQUM3QixRQUFNc0QsT0FBT0YsS0FBSyxTQUFTO0FBSTNCLFFBQU0sRUFBRUcsTUFBTUMsaUJBQWlCQyxTQUFTQyxnQkFBZ0JELFFBQVEsSUFBSTlDLFlBQXNCUSxxQkFBcUJpQyxFQUFFO0FBQ2pILFFBQU0sRUFBRU8sc0JBQXNCLElBQUlqRCxTQUFTO0FBRTNDLFFBQU0sQ0FBQ2tELFFBQVFDLFNBQVMsSUFBSWpFLFNBQVM7QUFBQSxJQUNqQ2tFLGdCQUFlLG9CQUFJckIsS0FBSyxHQUFFc0IsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDcERDLFVBQVV0QyxtQkFBbUJVLFFBQVEsb0JBQUlJLEtBQUssR0FBRyxDQUFDLENBQUM7QUFBQSxJQUNuRHlCLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsbUJBQW1CO0FBQUEsSUFDbkJDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsSUFDbEJDLGVBQWU7QUFBQSxJQUNmQyxtQkFBbUI7QUFBQSxJQUNuQkMsVUFBVTtBQUFBLElBQ1ZDLGVBQWU7QUFBQSxJQUNmQyxrQkFBa0JuQyxtQkFBbUI7QUFBQSxJQUNyQ29DLGlCQUFpQmhDLFlBQVk7QUFBQSxFQUNqQyxDQUFDO0FBQ0QsUUFBTSxDQUFDaUMsYUFBYUMsY0FBYyxJQUFJdEYsU0FBc0IsRUFBRTtBQUM5RCxRQUFNLENBQUN1RixPQUFPQyxRQUFRLElBQUl4RixTQUFvQyxFQUFFO0FBRWhFLFFBQU0sQ0FBQ3lGLGNBQWNDLGVBQWUsSUFBSTFGLFNBQXVCLEVBQUU7QUFDakUsUUFBTSxDQUFDMkYsMkJBQTJCQyw0QkFBNEIsSUFBSTVGLFNBQVMsS0FBSztBQUNoRixRQUFNLENBQUM2RixnQkFBZ0JDLGlCQUFpQixJQUFJOUYsU0FBMEIsRUFBRTtBQUN4RSxRQUFNLENBQUMrRixpQkFBaUJDLGtCQUFrQixJQUFJaEcsU0FBZ0IsRUFBRTtBQUVoRSxRQUFNLENBQUNpRyxjQUFjQyxlQUFlLElBQUlsRyxTQUFnQyxFQUFFO0FBQzFFLFFBQU0sQ0FBQ21HLHFCQUFxQkMsc0JBQXNCLElBQUlwRyxTQUFTLEtBQUs7QUFFcEUsUUFBTSxDQUFDcUcsYUFBYUMsY0FBYyxJQUFJdEcsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3VHLGVBQWVDLGdCQUFnQixJQUFJeEcsU0FBK0IsSUFBSTtBQUU3RSxRQUFNLENBQUN5RyxrQkFBa0JDLG1CQUFtQixJQUFJMUcsU0FBc0IsSUFBSTtBQUMxRSxRQUFNLENBQUMyRyxhQUFhQyxjQUFjLElBQUk1RyxTQUFjLElBQUk7QUFDeEQsUUFBTSxDQUFDNkcsZUFBZUMsZ0JBQWdCLElBQUk5RyxTQUFTLEtBQUs7QUFDeEQsUUFBTStHLDBCQUEwQjVHLE9BQU8sS0FBSztBQUU1QyxRQUFNNkcsOEJBQThCN0csT0FBTyxDQUFDLENBQUNxRCxFQUFFO0FBQy9DLFFBQU15RCxxQkFBcUI5RyxPQUEwRSxJQUFJO0FBRXpHRixZQUFVLE1BQU07QUFDWixRQUFJeUQsU0FBUyxVQUFVRSxpQkFBaUI7QUFDcENvRCxrQ0FBNEJFLFVBQVU7QUFDdENELHlCQUFtQkMsVUFBVTtBQUM3QmpELGdCQUFVO0FBQUEsUUFDTkMsZUFBZU4sZ0JBQWdCTTtBQUFBQSxRQUMvQkcsVUFBVXRDLG1CQUFtQixJQUFJYyxLQUFLZSxnQkFBZ0JTLFFBQVEsQ0FBQztBQUFBLFFBQy9EQyxRQUFRVixnQkFBZ0JVLFVBQVU7QUFBQSxRQUNsQ0MsV0FBV1gsZ0JBQWdCVztBQUFBQSxRQUMzQkMsbUJBQW1CWixnQkFBZ0J1RCxRQUFRQyxlQUFlO0FBQUEsUUFDMUQzQyxhQUFhYixnQkFBZ0J1RCxRQUFRRSxRQUFRO0FBQUEsUUFDN0MzQyxhQUFhZCxnQkFBZ0JjO0FBQUFBLFFBQzdCQyxlQUFlZixnQkFBZ0JlLGlCQUFpQjtBQUFBLFFBQ2hEQyxlQUFlaEIsZ0JBQWdCZ0IsaUJBQWlCO0FBQUEsUUFDaERDLGlCQUFpQmpCLGdCQUFnQmlCO0FBQUFBLFFBQ2pDQyxrQkFBa0JsQixnQkFBZ0JrQixvQkFBb0I7QUFBQSxRQUN0REMsZUFBZW5CLGdCQUFnQm1CLGlCQUFpQjtBQUFBLFFBQ2hEQyxtQkFBbUJwQixnQkFBZ0JvQixxQkFBcUI7QUFBQSxRQUN4REMsVUFBVXJCLGdCQUFnQnFCLFlBQVk7QUFBQSxRQUN0Q0MsZUFBZXRCLGdCQUFnQnNCLGlCQUFpQjtBQUFBLFFBQ2hEQyxrQkFBa0J2QixnQkFBZ0J1QixvQkFBb0JuQyxtQkFBbUI7QUFBQSxRQUN6RW9DLGlCQUFpQnhCLGdCQUFnQndCLG1CQUFtQmhDLFlBQVk7QUFBQSxNQUNwRSxDQUFDO0FBQ0RvQyxlQUFTNUIsZ0JBQWdCMkIsTUFBTStCLElBQUksQ0FBQUMsT0FBTSxFQUFFLEdBQUdBLEdBQUdDLFFBQVFDLE9BQU9DLFdBQVcsR0FBR0Msa0JBQWtCSixFQUFFSyxtQkFBbUIsRUFBRSxDQUFDO0FBRXhILFlBQU1DLGlCQUFpQmpFLGdCQUFnQmtFLFVBQVVSLElBQUksQ0FBQ1MsVUFBK0I7QUFBQSxRQUNqRlAsUUFBUUMsT0FBT0MsV0FBVztBQUFBLFFBQzFCTSxZQUFZRCxLQUFLQztBQUFBQSxRQUNqQkMsY0FBY0YsS0FBS0UsZ0JBQWdCO0FBQUE7QUFBQSxRQUNuQ0MsY0FBY0gsS0FBS0c7QUFBQUEsUUFDbkJDLFVBQVVDLE9BQU9MLEtBQUtJLFFBQVE7QUFBQSxRQUM5QkUsWUFBWUQsT0FBT0wsS0FBS00sVUFBVTtBQUFBLE1BQ3RDLEVBQUUsS0FBSztBQUNQbkMsc0JBQWdCMkIsY0FBYztBQUU5QixZQUFNUyxtQkFBbUIsWUFBWTtBQUNqQyxZQUFJO0FBRUEsY0FBSTFFLGdCQUFnQnVELFFBQVFvQixjQUFjO0FBQ3RDakQsMkJBQWVsRCw2QkFBNkJ3QixnQkFBZ0J1RCxPQUFPb0IsWUFBWSxDQUFDO0FBQUEsVUFDcEYsT0FBTztBQUVILGtCQUFNQyxhQUFhLE1BQU14SCxRQUFtRCxXQUFXNEMsZ0JBQWdCVyxTQUFTO0FBQ2hIZSwyQkFBZWxELDZCQUE2Qm9HLFdBQVdELGdCQUFnQixFQUFFLENBQUM7QUFBQSxVQUM5RTtBQUFBLFFBQ0osU0FBU0UsT0FBTztBQUNaQyxrQkFBUUQsTUFBTSx5Q0FBeUNBLEtBQUs7QUFDNURuSSxnQkFBTW1JLE1BQU0sb0VBQW9FO0FBQUEsUUFDcEY7QUFBQSxNQUNKO0FBRUFILHVCQUFpQjtBQUdqQixZQUFNSyxjQUFjL0UsZ0JBQWdCZ0YsaUJBQWlCLElBQUl0RyxPQUFPLENBQUNDLE1BQWtCQSxFQUFFc0csYUFBYSxDQUFDO0FBQ25HLFlBQU1DLGNBQWNsRixnQkFBZ0JnRixpQkFBaUIsSUFBSXRHLE9BQU8sQ0FBQ0MsTUFBa0JBLEVBQUVzRyxhQUFhLENBQUM7QUFDbkduRCxzQkFBZ0JpRCxVQUFVO0FBQzFCN0Msd0JBQWtCZ0QsV0FBV3hCLElBQUksQ0FBQy9FLE9BQW1CO0FBQUEsUUFDakRpRixRQUFRQyxPQUFPQyxXQUFXO0FBQUEsUUFDMUJxQixRQUFReEcsRUFBRXdHO0FBQUFBLFFBQ1ZDLFVBQVV6RyxFQUFFeUcsWUFBWXpHLEVBQUUwRyxLQUFLNUIsUUFBUTtBQUFBLFFBQ3ZDNkIsUUFBUWQsT0FBTzdGLEVBQUUyRyxNQUFNLEtBQUs7QUFBQSxNQUNoQyxFQUFFLENBQUM7QUFBQSxJQUNQO0FBQUEsRUFDSixHQUFHLENBQUN4RixNQUFNRSxlQUFlLENBQUM7QUFHMUIzRCxZQUFVLE1BQU07QUFDWm1CLFdBQVksU0FBUyxFQUFFb0IsTUFBTSxJQUFJLENBQUMsRUFDN0IyRyxLQUFLLENBQUFDLFFBQU9wRCxtQkFBbUJvRCxJQUFJQyxRQUFRLEVBQUUsQ0FBQyxFQUM5Q0MsTUFBTSxNQUFNdEQsbUJBQW1CLEVBQUUsQ0FBQztBQUFBLEVBQzNDLEdBQUcsRUFBRTtBQUdML0YsWUFBVSxNQUFNO0FBQ1osUUFBSXVELE1BQU11RCx3QkFBd0JHLFFBQVM7QUFDM0MsUUFBSTNCLE1BQU1nRSxTQUFTLEVBQUc7QUFDdEJ4Qyw0QkFBd0JHLFVBQVU7QUFDbENqRyxXQUFzQixHQUFHUSwwQkFBMEIrSCxRQUFRLGNBQWMsRUFDcEVMLEtBQUssQ0FBQ00sYUFBYTtBQUNoQixVQUFJQSxTQUFTSixLQUFLRSxTQUFTLEdBQUc7QUFDMUIsY0FBTUcsVUFBVUQsU0FBU0osS0FBSyxDQUFDO0FBQy9CN0QsaUJBQVMsQ0FBQztBQUFBLFVBQ05nQyxRQUFRQyxPQUFPQyxXQUFXO0FBQUEsVUFDMUJpQywyQkFBMkJELFFBQVFsRztBQUFBQSxVQUNuQ29HLG9CQUFvQkYsUUFBUXJDO0FBQUFBLFVBQzVCTSxrQkFBa0I7QUFBQSxVQUNsQmtDLE9BQU87QUFBQSxRQUNYLENBQUMsQ0FBQztBQUFBLE1BQ047QUFBQSxJQUNKLENBQUMsRUFDQVAsTUFBTSxNQUFNO0FBQ1R2Qyw4QkFBd0JHLFVBQVU7QUFBQSxJQUN0QyxDQUFDO0FBQUEsRUFDVCxHQUFHLENBQUMxRCxJQUFJK0IsTUFBTWdFLE1BQU0sQ0FBQztBQUdyQixRQUFNTyxXQUFXNUosUUFBUSxNQUFNO0FBQzNCLFdBQU9xRixNQUFNd0UsT0FBTyxDQUFDQyxLQUFLckcsU0FBU3FHLE9BQU81QixPQUFPekUsS0FBS2tHLEtBQUssS0FBSyxJQUFJLENBQUM7QUFBQSxFQUN6RSxHQUFHLENBQUN0RSxLQUFLLENBQUM7QUFJVnRGLFlBQVUsTUFBTTtBQUNaLFFBQUl1RCxHQUFJO0FBQ1IsUUFBSTZCLFlBQVlrRSxXQUFXLEdBQUc7QUFDMUI3RCxzQkFBZ0IsRUFBRTtBQUNsQjtBQUFBLElBQ0o7QUFDQSxRQUFJTCxZQUFZa0UsU0FBUyxHQUFHO0FBQ3hCN0Qsc0JBQWdCTCxZQUFZaUMsSUFBSSxDQUFBL0UsT0FBTTtBQUFBLFFBQ2xDd0csUUFBUXhHLEVBQUVpQjtBQUFBQSxRQUNWd0YsVUFBVXpHLEVBQUU4RTtBQUFBQSxRQUNaNEMsTUFBTTFILEVBQUUwSDtBQUFBQSxRQUNSZixRQUFRO0FBQUEsTUFDWixFQUFFLENBQUM7QUFBQSxJQUNQO0FBQUEsRUFDSixHQUFHLENBQUMxRixJQUFJNkIsV0FBVyxDQUFDO0FBSXBCcEYsWUFBVSxNQUFNO0FBQ1osUUFBSW9GLFlBQVlrRSxXQUFXLEtBQUs1RCwwQkFBMkI7QUFFM0QsVUFBTXVFLFNBQVM7QUFBQSxNQUNYSjtBQUFBQSxNQUNBN0UsVUFBVWpCLE9BQU9pQixZQUFZO0FBQUEsTUFDN0JrRixZQUFZbkcsT0FBT2dCLHFCQUFxQjtBQUFBLElBQzVDO0FBRUEsUUFBSXhCLElBQUk7QUFDSixVQUFJd0QsNEJBQTRCRSxTQUFTO0FBQ3JDRixvQ0FBNEJFLFVBQVU7QUFDdENELDJCQUFtQkMsVUFBVWdEO0FBQzdCO0FBQUEsTUFDSjtBQUNBLFVBQUlqRCxtQkFBbUJDLFlBQVksTUFBTTtBQUNyQyxjQUFNa0QsT0FBT25ELG1CQUFtQkM7QUFDaEMsWUFDSWtELEtBQUtOLGFBQWFJLE9BQU9KLFlBQ3pCTSxLQUFLbkYsYUFBYWlGLE9BQU9qRixZQUN6Qm1GLEtBQUtELGVBQWVELE9BQU9DLFlBQzdCO0FBQ0U7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUNBbEQseUJBQW1CQyxVQUFVZ0Q7QUFBQUEsSUFDakM7QUFFQSxVQUFNRyxVQUFVSCxPQUFPSixXQUFXSSxPQUFPakY7QUFDekMsVUFBTXFGLGtCQUFrQmpGLFlBQVlpQyxJQUFJLENBQUEyQixTQUFRO0FBQUEsTUFDNUNGLFFBQVFFLElBQUl6RjtBQUFBQSxNQUNad0YsVUFBVUMsSUFBSTVCO0FBQUFBLE1BQ2Q0QyxNQUFNaEIsSUFBSWdCO0FBQUFBLE1BQ1ZmLFFBQVFtQixXQUFXcEIsSUFBSWdCLE9BQU87QUFBQSxJQUNsQyxFQUFFO0FBQ0Z2RSxvQkFBZ0I0RSxlQUFlO0FBQUEsRUFDbkMsR0FBRyxDQUFDOUcsSUFBSXNHLFVBQVU5RixPQUFPaUIsVUFBVWpCLE9BQU9nQixtQkFBbUJLLGFBQWFNLHlCQUF5QixDQUFDO0FBR3BHLFFBQU00RSxTQUFTckssUUFBUSxNQUFNO0FBQ3pCLFVBQU1zSyxXQUFXL0UsYUFBYXNFLE9BQU8sQ0FBQ0MsS0FBS2YsUUFBUWUsT0FBTzVCLE9BQU9hLElBQUlDLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDckYsVUFBTXVCLG9CQUFvQjVFLGVBQWVrRSxPQUFPLENBQUNDLEtBQUtVLE1BQU1WLE9BQU81QixPQUFPc0MsRUFBRXhCLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDNUYsVUFBTWlCLGFBQWFuRyxPQUFPZ0IscUJBQXFCO0FBQy9DLFVBQU0yRixhQUFhYixZQUFZOUYsT0FBT2lCLFlBQVksS0FBS2tGLGFBQWFLLFdBQVdDO0FBQy9FLFdBQU8sRUFBRVgsVUFBVVUsVUFBVUMsbUJBQW1CRSxXQUFXO0FBQUEsRUFDL0QsR0FBRyxDQUFDYixVQUFVckUsY0FBY0ksZ0JBQWdCN0IsT0FBT2lCLFVBQVVqQixPQUFPZ0IsaUJBQWlCLENBQUM7QUFFdEYsUUFBTTRGLHFCQUFxQkEsQ0FBQ0MsT0FBNEJoQixVQUFlO0FBQ25FNUYsY0FBVSxDQUFBbUcsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1MsS0FBSyxHQUFHaEIsTUFBTSxFQUFFO0FBQUEsRUFDbkQ7QUFFQSxRQUFNaUIsNkJBQTZCQSxNQUFNO0FBQ3JDL0csMEJBQXNCO0FBQUEsTUFDbEJnSCxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFdBQVdBLE1BQU1yRiw2QkFBNkIsSUFBSTtBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTXNGLHFCQUFxQixPQUFPL0QsV0FBc0I7QUFDcER2QixpQ0FBNkIsS0FBSztBQUNsQ29CLGdDQUE0QkUsVUFBVTtBQUN0Q0QsdUJBQW1CQyxVQUFVO0FBQzdCakQsY0FBVTtBQUFBLE1BQ04sR0FBR0Q7QUFBQUEsTUFDSE8sV0FBVzRDLE9BQU8zRDtBQUFBQSxNQUNsQmlCLGFBQWEwQyxPQUFPRTtBQUFBQSxNQUNwQjdDLG1CQUFtQjJDLE9BQU9DLGVBQWU7QUFBQSxJQUM3QyxDQUFDO0FBQ0QsUUFBSTtBQUNBLFlBQU1vQixhQUFhLE1BQU14SCxRQUE0QyxXQUFXbUcsT0FBTzNELEVBQUU7QUFDekY4QixxQkFBZWxELDZCQUE2Qm9HLFdBQVduRyxTQUFTLEVBQUUsQ0FBQztBQUNuRXFELHNCQUFnQixFQUFFO0FBQ2xCLFlBQU0vQyxPQUFPeUYsT0FBT0ksV0FBVzJDLGlCQUFpQixLQUFLO0FBQ3JEbEgsZ0JBQVUsQ0FBQW1HLFVBQVM7QUFBQSxRQUNmLEdBQUdBO0FBQUFBLFFBQ0gvRixVQUFVdEMsbUJBQW1CVSxRQUFRLG9CQUFJSSxLQUFLLEdBQUdGLElBQUksQ0FBQztBQUFBLFFBQ3REMkIsUUFBUWtFLFdBQVc0QyxTQUFTaEIsS0FBSzlGLFVBQVU7QUFBQSxNQUMvQyxFQUFFO0FBQUEsSUFDTixRQUFRO0FBQ0poRSxZQUFNbUksTUFBTSxvREFBb0Q7QUFDaEVuRCxxQkFBZSxFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNKO0FBRUEsUUFBTStGLHVCQUF1QixPQUFPQyxhQUFxQjtBQUNyRHJILGNBQVU7QUFBQSxNQUNOLEdBQUdEO0FBQUFBLE1BQVFVLGFBQWE0RyxTQUFTOUg7QUFBQUEsTUFDakNvQixlQUFlMEcsU0FBU2pFO0FBQUFBLE1BQ3hCMUMsZUFBZTJHLFNBQVNDO0FBQUFBLE1BQ3hCckcsZUFBZWtELE9BQU9rRCxTQUFTcEcsYUFBYSxLQUFLO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNc0cseUJBQXlCLFlBQVk7QUFDdkMsVUFBTUQsT0FBT3ZILE9BQU9RO0FBQ3BCLFFBQUksQ0FBQytHLE1BQU07QUFDUGpMLFlBQU1tTCxLQUFLLDZDQUE2QztBQUN4RDtBQUFBLElBQ0o7QUFDQSxRQUFJO0FBRUEsWUFBTWhDLFdBQVcsTUFBTXhJLE9BQWtCLEdBQUdPLHdCQUF3QmdJLFFBQVEsZ0JBQWdCK0IsSUFBSSxFQUFFO0FBQ2xHLFVBQUk5QixTQUFTSixLQUFLRSxTQUFTLEdBQUc7QUFDMUIyQiwyQkFBbUJ6QixTQUFTSixLQUFLLENBQUMsQ0FBQztBQUFBLE1BQ3ZDLE9BQU87QUFDSC9JLGNBQU1tSSxNQUFNLHlDQUF5QztBQUNyRHhFLGtCQUFVLENBQUFtRyxVQUFTLEVBQUUsR0FBR0EsTUFBTTdGLFdBQVcsTUFBTUUsYUFBYSxLQUFLLEVBQUU7QUFBQSxNQUN2RTtBQUFBLElBQ0osU0FBU2dFLE9BQU87QUFDWkMsY0FBUWdELElBQUlqRCxLQUFLO0FBQ2pCbkksWUFBTW1JLE1BQU0sNEJBQTRCO0FBQUEsSUFDNUM7QUFBQSxFQUNKO0FBRUEsUUFBTWtELDJCQUEyQixZQUFZO0FBQ3pDLFVBQU1KLE9BQU92SCxPQUFPVztBQUNwQixRQUFJLENBQUM0RyxNQUFNO0FBQ1BqTCxZQUFNbUwsS0FBSywwQ0FBMEM7QUFDckQ7QUFBQSxJQUNKO0FBQ0EsUUFBSTtBQUVBLFlBQU1oQyxXQUFXLE1BQU14SSxPQUFlLEdBQUdpQixvQkFBb0JzSCxRQUFRLFNBQVMrQixJQUFJLEVBQUU7QUFDcEYsVUFBSTlCLFNBQVNKLEtBQUtFLFNBQVMsR0FBRztBQUMxQjhCLDZCQUFxQjVCLFNBQVNKLEtBQUssQ0FBQyxDQUFDO0FBQUEsTUFDekMsT0FBTztBQUNIL0ksY0FBTW1JLE1BQU0sc0NBQXNDO0FBQ2xEeEUsa0JBQVUsQ0FBQW1HLFVBQVMsRUFBRSxHQUFHQSxNQUFNN0YsV0FBVyxNQUFNRSxhQUFhLEtBQUssRUFBRTtBQUFBLE1BQ3ZFO0FBQUEsSUFDSixTQUFTZ0UsT0FBTztBQUNaQyxjQUFRZ0QsSUFBSWpELEtBQUs7QUFDakJuSSxZQUFNbUksTUFBTSw0QkFBNEI7QUFBQSxJQUM1QztBQUFBLEVBQ0o7QUFHQSxRQUFNbUQsZ0JBQWdCQSxNQUFNcEcsU0FBUyxDQUFBNEUsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRTVDLFFBQVFDLE9BQU9DLFdBQVcsR0FBR2lDLDJCQUEyQixNQUFNRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO0FBQ2xJLFFBQU1nQyxtQkFBbUJBLENBQUNyRSxXQUFtQmhDLFNBQVMsQ0FBQTRFLFNBQVFBLEtBQUs5SCxPQUFPLENBQUFpRixNQUFLQSxFQUFFQyxXQUFXQSxNQUFNLENBQUM7QUFDbkcsUUFBTXNFLG1CQUFtQkEsQ0FBQ3RFLFFBQWdCcUQsT0FBc0NoQixVQUFlO0FBQzNGckUsYUFBUyxDQUFBNEUsU0FBUUEsS0FBSzlDLElBQUksQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV0EsU0FBUyxFQUFFLEdBQUdELEdBQUcsQ0FBQ3NELEtBQUssR0FBR2hCLE1BQU0sSUFBSXRDLENBQUMsQ0FBQztBQUFBLEVBQ3RGO0FBRUEsUUFBTXdFLDBCQUEwQixPQUFPdkUsV0FBbUI7QUFDdEQsVUFBTTdELE9BQU80QixNQUFNeUcsS0FBSyxDQUFBekUsTUFBS0EsRUFBRUMsV0FBV0EsTUFBTTtBQUNoRCxVQUFNK0QsT0FBTzVILE1BQU1nRTtBQUNuQixRQUFJLENBQUM0RCxLQUFNLFFBQU9qTCxNQUFNbUwsS0FBSywwQ0FBMEM7QUFDdkUsUUFBSTtBQUNBLFlBQU1oQyxXQUFXLE1BQU14SSxPQUEwQyxHQUFHUSwwQkFBMEIrSCxRQUFRLFNBQVMrQixJQUFJLEVBQUU7QUFDckgsVUFBSTlCLFNBQVNKLEtBQUtFLFNBQVMsR0FBRztBQUMxQixjQUFNRyxVQUFVRCxTQUFTSixLQUFLLENBQUM7QUFDL0J5Qyx5QkFBaUJ0RSxRQUFRLDZCQUE2QmtDLFFBQVFsRyxFQUFFO0FBQ2hFc0kseUJBQWlCdEUsUUFBUSxzQkFBc0JrQyxRQUFRckMsSUFBSTtBQUMzRHlFLHlCQUFpQnRFLFFBQVEsb0JBQW9Ca0MsUUFBUTZCLFFBQVF0SSxPQUFPeUcsUUFBUWxHLEVBQUUsQ0FBQztBQUFBLE1BQ25GLE9BQU87QUFDSGxELGNBQU1tSSxNQUFNLHNDQUFzQztBQUNsRHFELHlCQUFpQnRFLFFBQVEsNkJBQTZCLElBQUk7QUFDMURzRSx5QkFBaUJ0RSxRQUFRLHNCQUFzQixFQUFFO0FBQUEsTUFDckQ7QUFBQSxJQUNKLFNBQVNpQixPQUFPO0FBQUVuSSxZQUFNbUksTUFBTSxxQ0FBcUM7QUFBR0MsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQUc7QUFBQSxFQUNoRztBQUVBLFFBQU13RCw0QkFBNEIsWUFBWTtBQVExQyxRQUFJLENBQUNqSSxPQUFPTyxXQUFXO0FBQ25CakUsWUFBTW1MLEtBQUsscURBQXFEO0FBQ2hFO0FBQUEsSUFDSjtBQUNBckYsMkJBQXVCLElBQUk7QUFDM0JGLG9CQUFnQixFQUFFO0FBQ2xCLFFBQUk7QUFDQSxZQUFNc0QsV0FBVyxpQ0FBaUMwQyxtQkFBbUJsSSxPQUFPZSxhQUFhLENBQUMsY0FBY2YsT0FBT08sU0FBUztBQUN4SCxZQUFNa0YsV0FBVyxNQUFNeEksT0FBWXVJLFFBQVE7QUFDM0MsWUFBTTJDLE9BQU9DLE1BQU1DLFFBQVE1QyxVQUFVSixJQUFJLElBQUlJLFNBQVNKLE9BQVErQyxNQUFNQyxRQUFRNUMsUUFBUSxJQUFJQSxXQUFXO0FBQ25HLFVBQUkwQyxLQUFLNUMsV0FBVyxHQUFHO0FBQ25CakosY0FBTW1MLEtBQUsscUVBQXFFO0FBQ2hGckYsK0JBQXVCLEtBQUs7QUFDNUI7QUFBQSxNQUNKO0FBRUE5RixZQUFNbUwsS0FBSyxZQUFZVSxLQUFLNUMsTUFBTSwwQkFBMEI7QUFFNUQsWUFBTStDLGtCQUF5QztBQUUvQyxpQkFBV0MsWUFBWUosTUFBTTtBQUN6QixZQUFJSyxPQUFPO0FBQ1gsWUFBSUMsWUFBWTtBQUNoQixjQUFNQyxNQUFNSCxTQUFTRyxPQUFPSCxTQUFTdEUsZ0JBQWdCO0FBQ3JELFlBQUl5RSxLQUFLO0FBQ0wsY0FBSTtBQUNBLGtCQUFNQyxlQUFlLE1BQU0xTCxPQUFpQixHQUFHUyxzQkFBc0I4SCxRQUFRLFFBQVEwQyxtQkFBbUJRLEdBQUcsQ0FBQyxFQUFFO0FBQzlHLGtCQUFNRSxXQUFXUixNQUFNQyxRQUFRTSxjQUFjdEQsSUFBSSxJQUFJc0QsYUFBYXRELE9BQVErQyxNQUFNQyxRQUFRTSxZQUFZLElBQUlBLGVBQWU7QUFDdkgsZ0JBQUlDLFNBQVNyRCxTQUFTLEdBQUc7QUFDckJpRCxxQkFBT3BFLE9BQU93RSxTQUFTLENBQUMsRUFBRUMsVUFBVSxLQUFLO0FBQ3pDSiwwQkFBWUcsU0FBUyxDQUFDLEVBQUVwSjtBQUFBQSxZQUM1QjtBQUFBLFVBQ0osU0FBU3NKLEdBQUc7QUFBRXBFLG9CQUFRRCxNQUFNLDZCQUE2QnFFLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDakU7QUFFQVIsd0JBQWdCUyxLQUFLO0FBQUEsVUFDakJ2RixRQUFRQyxPQUFPQyxXQUFXO0FBQUEsVUFDMUJNLFlBQVl5RTtBQUFBQSxVQUNaeEUsY0FBY3lFO0FBQUFBLFVBQ2R4RSxjQUFjcUUsU0FBU3JFLGdCQUFnQnFFLFNBQVNsRixRQUFRO0FBQUEsVUFDeERjLFVBQVVDLE9BQU9tRSxTQUFTcEUsUUFBUSxLQUFLO0FBQUEsVUFDdkNFLFlBQVltRTtBQUFBQSxRQUNoQixDQUFDO0FBQUEsTUFDTDtBQUNBdEcsc0JBQWdCb0csZUFBZTtBQUUvQixVQUFJO0FBQ0EsY0FBTVUsZ0JBQWdCVixnQkFBZ0J2QyxPQUFPLENBQUNDLEtBQUtpRCxNQUFNakQsT0FBTzVCLE9BQU82RSxFQUFFOUUsUUFBUSxLQUFLLE1BQU1DLE9BQU82RSxFQUFFNUUsVUFBVSxLQUFLLElBQUksQ0FBQztBQUN6SDdDLGlCQUFTLENBQUM0RSxTQUFTO0FBQ2YsZ0JBQU04QyxNQUFNOUMsS0FBSytDLFVBQVUsQ0FBQzVGLE1BQU9BLEVBQThCSSxxQkFBcUIsUUFBUTtBQUM5RixjQUFJdUYsUUFBUSxHQUFJLFFBQU85QztBQUN2QixpQkFBT0EsS0FBSzlDLElBQUksQ0FBQzNELE1BQU00RCxNQUFPQSxNQUFNMkYsTUFBTSxFQUFFLEdBQUd2SixNQUFNa0csT0FBT21ELGNBQWMsSUFBSXJKLElBQUs7QUFBQSxRQUN2RixDQUFDO0FBQUEsTUFDTCxTQUFTbUosR0FBRztBQUNScEUsZ0JBQVFELE1BQU0sbUNBQW1DcUUsQ0FBQztBQUFBLE1BQ3REO0FBQUEsSUFDSixTQUFTckUsT0FBTztBQUNabkksWUFBTW1JLE1BQU0sMkNBQTJDO0FBQ3ZEQyxjQUFRRCxNQUFNQSxLQUFLO0FBQUEsSUFDdkIsVUFBQztBQUNHckMsNkJBQXVCLEtBQUs7QUFBQSxJQUNoQztBQUFBLEVBQ0o7QUFHQSxRQUFNZ0gsbUJBQW1CQSxDQUFDTixNQUEyQztBQUNqRSxRQUFJQSxFQUFFTyxPQUFPQyxTQUFTUixFQUFFTyxPQUFPQyxNQUFNLENBQUMsR0FBRztBQUNyQyxZQUFNQyxPQUFPVCxFQUFFTyxPQUFPQyxNQUFNLENBQUM7QUFDN0IsWUFBTUUsZUFBZSxDQUFDLGNBQWMsYUFBYSxtQkFBbUIsV0FBVztBQUMvRSxZQUFNQyxVQUFVLE9BQU87QUFHdkIsVUFBSSxDQUFDRCxhQUFhRSxTQUFTSCxLQUFLL0ssSUFBSSxHQUFHO0FBQ25DbEMsY0FBTW1JLE1BQU0sMERBQTBEO0FBQ3RFcUUsVUFBRU8sT0FBT3hELFFBQVE7QUFDakJuRCw0QkFBb0IsSUFBSTtBQUN4QjtBQUFBLE1BQ0o7QUFHQSxVQUFJNkcsS0FBS0ksT0FBT0YsU0FBUztBQUNyQm5OLGNBQU1tSSxNQUFNLDRDQUE0QztBQUN4RHFFLFVBQUVPLE9BQU94RCxRQUFRO0FBQ2pCbkQsNEJBQW9CLElBQUk7QUFDeEI7QUFBQSxNQUNKO0FBRUFBLDBCQUFvQjZHLElBQUk7QUFBQSxJQUM1QixPQUFPO0FBQ0g3RywwQkFBb0IsSUFBSTtBQUFBLElBQzVCO0FBQUEsRUFDSjtBQUdBLFFBQU1rSCxpQkFBaUIsWUFBWTtBQUMvQixRQUFJLENBQUNoSyxpQkFBaUJKLEdBQUk7QUFFMUIsVUFBTXFLLFVBQVV4TSxnQkFBZ0I7QUFDaEMsUUFBSSxDQUFDd00sU0FBUztBQUNWdk4sWUFBTW1JLE1BQU0sa0RBQWtEO0FBQzlEO0FBQUEsSUFDSjtBQUVBM0IscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNBLFlBQU14RixpQkFBaUJ1TSxTQUFTLGNBQWNqSyxnQkFBZ0JKLEVBQUUsT0FBTztBQUFBLElBQzNFLFNBQVNpRixPQUFPO0FBQ1osVUFBSSxDQUFDb0YsUUFBUUMsT0FBT0MsT0FBUUYsU0FBUUMsT0FBT0UsTUFBTTtBQUNqRHRGLGNBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EbkksWUFBTW1JLE1BQU0sc0NBQXNDO0FBQUEsSUFDdEQsVUFBQztBQUNHM0IsdUJBQWlCLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0o7QUFFQSxRQUFNbUgsYUFBYSxZQUFZO0FBQzNCLFFBQUksQ0FBQ2pLLE9BQU9PLGFBQWEsQ0FBQ1AsT0FBT2EsbUJBQWdELENBQUNiLE9BQU9VLGFBQWE7QUFDbEdwRSxZQUFNbUksTUFBTSw2REFBNkQ7QUFDekU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDekUsT0FBT00sUUFBUTtBQUNoQmhFLFlBQU1tSSxNQUFNLDBCQUEwQjtBQUN0QztBQUFBLElBQ0o7QUFDQSxRQUFJbEQsTUFBTWdFLFdBQVcsS0FBS2hFLE1BQU0ySSxLQUFLLENBQUEzRyxNQUFLLENBQUNBLEVBQUVvQyw2QkFBNkJwQyxFQUFFc0MsU0FBUyxDQUFDLEdBQUc7QUFDckZ2SixZQUFNbUksTUFBTSxrRUFBa0U7QUFDOUU7QUFBQSxJQUNKO0FBR0EsVUFBTXVFLGdCQUFnQi9HLGFBQWE4RCxPQUFPLENBQUNDLEtBQUtpRCxNQUFNO0FBQ2xELFlBQU1rQixNQUFNL0YsT0FBTzZFLEVBQUU5RSxRQUFRLEtBQUs7QUFDbEMsWUFBTXFFLE9BQU9wRSxPQUFPNkUsRUFBRTVFLFVBQVUsS0FBSztBQUNyQyxhQUFPMkIsTUFBTW1FLE1BQU0zQjtBQUFBQSxJQUN2QixHQUFHLENBQUM7QUFFSixVQUFNNEIsYUFBYXRFO0FBR25CLFFBQUk3RCxhQUFhc0QsU0FBUyxHQUFHO0FBQ3pCLFlBQU04RSxjQUFjQyxLQUFLQyxNQUFNdkIsZ0JBQWdCLEdBQUc7QUFDbEQsWUFBTXdCLGVBQWVGLEtBQUtDLE1BQU1ILGFBQWEsR0FBRztBQUVoRCxVQUFJQyxnQkFBZ0JHLGNBQWM7QUFDOUJsTyxjQUFNbUk7QUFBQUEsVUFDRiwwRkFDb0J6RyxZQUFZZ0wsZUFBZSxVQUFVLENBQUMsbUJBQzFDaEwsWUFBWW9NLFlBQVksVUFBVSxDQUFDO0FBQUEsUUFDdkQ7QUFDQTtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBRUEsVUFBTUssYUFBYWxKLE1BQU0rQixJQUFJLENBQUMzRCxNQUFNK0ssVUFBVTtBQUMxQyxZQUFNLEVBQUVsSCxRQUFRb0Msb0JBQW9CLEdBQUcrRSxLQUFLLElBQUloTDtBQUNoRCxVQUFJNkQsV0FBV29ILE9BQVdsRyxTQUFRZ0QsSUFBSSxpQkFBaUI7QUFDdkQsVUFBSTlCLHVCQUF1QmdGLE9BQVdsRyxTQUFRZ0QsSUFBSSw2QkFBNkI7QUFDL0UsYUFBTztBQUFBLFFBQ0gsR0FBR2lEO0FBQUFBLFFBQ0hFLGFBQWFILFFBQVE7QUFBQTtBQUFBLE1BQ3pCO0FBQUEsSUFDSixDQUFDO0FBRUQsVUFBTS9GLGFBQWFsRCxhQUNkbkQsT0FBTyxDQUFBMkcsUUFBT0EsSUFBSUMsU0FBUyxDQUFDLEVBQzVCNUIsSUFBSSxDQUFBMkIsU0FBUSxFQUFFRixRQUFRRSxJQUFJRixRQUFRRyxRQUFRRCxJQUFJQyxRQUFRZSxNQUFNaEIsSUFBSWdCLE1BQU1wQixVQUFVLEVBQVcsRUFBRTtBQUNsRyxVQUFNQyxhQUFhakQsZUFDZHZELE9BQU8sQ0FBQW9JLE1BQUtBLEVBQUUzQixVQUFVLFFBQVEyQixFQUFFeEIsU0FBUyxDQUFDLEVBQzVDNUIsSUFBSSxDQUFBb0QsT0FBTSxFQUFFM0IsUUFBUTJCLEVBQUUzQixRQUFTRyxRQUFRd0IsRUFBRXhCLFFBQVFlLE1BQU0sR0FBR3BCLFVBQVUsRUFBVyxFQUFFO0FBQ3RGLFVBQU1pRyxhQUFhLENBQUMsR0FBR25HLFlBQVksR0FBR0csVUFBVTtBQUdoRCxVQUFNaUcsZ0JBQWdCOUksYUFBYXFCLElBQUksQ0FBQzNELE1BQU0rSyxVQUFVO0FBRXBELFlBQU0sRUFBRWxILFFBQVEsR0FBR21ILEtBQUssSUFBSWhMO0FBQzVCLGFBQU87QUFBQSxRQUNILEdBQUdnTDtBQUFBQSxRQUNIRSxhQUFhSCxRQUFRO0FBQUEsTUFDekI7QUFBQSxJQUNKLENBQUM7QUFFRCxVQUFNTSxVQUFVO0FBQUEsTUFDWixHQUFHaEw7QUFBQUEsTUFDSHVCLE9BQU9rSjtBQUFBQSxNQUNQcE0sT0FBT3lNO0FBQUFBLE1BQ1BoSCxVQUFVaUg7QUFBQUEsTUFDVkUsY0FBYzFFLE9BQU9JO0FBQUFBLElBQ3pCO0FBRUEsVUFBTXVFLFdBQVcsSUFBSUMsU0FBUztBQUM5QkQsYUFBU0UsT0FBTyxRQUFRQyxLQUFLQyxVQUFVTixPQUFPLENBQUM7QUFFL0MsUUFBSXZJLGtCQUFrQjtBQUNsQnlJLGVBQVNFLE9BQU8saUJBQWlCM0ksZ0JBQWdCO0FBQUEsSUFDckQ7QUFHQSxRQUFJO0FBQ0EsVUFBSS9DLFNBQVMsVUFBVTtBQUVuQixjQUFNeEMsT0FBaUJLLG9CQUFvQmlJLFVBQVUwRixRQUFRO0FBQzdENU8sY0FBTWlQLFFBQVEseUJBQXlCO0FBQUEsTUFDM0MsT0FBTztBQUtILGNBQU1wTyxPQUFpQkksb0JBQW9CaUksVUFBVWhHLElBQUswTCxRQUFRO0FBQ2xFNU8sY0FBTWlQLFFBQVEsOEJBQThCO0FBQUEsTUFDaEQ7QUFDQTlMLGVBQVN0QixrQkFBa0JaLG9CQUFvQmlPLFNBQVMsQ0FBQztBQUFBLElBQzdELFNBQVMvRyxPQUFZO0FBRWpCLFlBQU1nSCxXQUFXaEgsTUFBTWdCLFVBQVVKLE1BQU0yQixXQUFXdkMsTUFBTXVDLFdBQVc7QUFDbkUxSyxZQUFNbUksTUFBTWdILFFBQVE7QUFBQSxJQUN4QjtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxZQUFZQSxDQUFDckMsUUFBdUJzQyxXQUFnQjtBQUN0RG5KLHFCQUFpQjZHLE1BQU07QUFDdkIsVUFBTXVDLGdCQUFnQixPQUFPdkMsV0FBVyxZQUFZQSxRQUFRN0ssU0FBUztBQUNyRW9FO0FBQUFBLE1BQWVnSixnQkFDVCxFQUFFLEdBQUdELFFBQVFFLGdCQUFnQmxPLDJCQUEyQixJQUN4RGdPO0FBQUFBLElBQ047QUFDQXJKLG1CQUFlLElBQUk7QUFBQSxFQUN2QjtBQUdBLFFBQU13Six1QkFBdUJBLE1BQU07QUFDL0I1SjtBQUFBQSxNQUFnQixDQUFBa0UsU0FBUTtBQUFBLFFBQ3BCLEdBQUdBO0FBQUFBLFFBQ0g7QUFBQSxVQUNJNUMsUUFBUUMsT0FBT0MsV0FBVztBQUFBLFVBQzFCTSxZQUFZO0FBQUEsVUFDWkMsY0FBYztBQUFBLFVBQ2RDLGNBQWM7QUFBQSxVQUNkQyxVQUFVO0FBQUEsVUFDVkUsWUFBWTtBQUFBLFFBQ2hCO0FBQUEsTUFBQztBQUFBLElBQ0o7QUFBQSxFQUNMO0FBQ0EsUUFBTTBILDBCQUEwQkEsQ0FBQ3ZJLFdBQW1CdEIsZ0JBQWdCLENBQUFrRSxTQUFRQSxLQUFLOUgsT0FBTyxDQUFBaUYsTUFBS0EsRUFBRUMsV0FBV0EsTUFBTSxDQUFDO0FBQ2pILFFBQU13SSwwQkFBMEJBLENBQUN4SSxRQUFnQnFELE9BQWtDaEIsVUFBZTtBQUM5RjNELG9CQUFnQixDQUFBa0UsU0FBUUEsS0FBSzlDLElBQUksQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV0EsU0FBUyxFQUFFLEdBQUdELEdBQUcsQ0FBQ3NELEtBQUssR0FBR2hCLE1BQU0sSUFBSXRDLENBQUMsQ0FBQztBQUFBLEVBQzdGO0FBR0EsUUFBTTBJLHNCQUFzQkEsQ0FBQ3pJLFFBQWdCMEksWUFBc0I7QUFDL0RoSyxvQkFBZ0IsQ0FBQWtFLFNBQVFBLEtBQUs5QztBQUFBQSxNQUFJLENBQUFDLE1BQzdCQSxFQUFFQyxXQUFXQSxTQUNQO0FBQUEsUUFDRSxHQUFHRDtBQUFBQSxRQUNIUyxZQUFZa0ksUUFBUTFNO0FBQUFBLFFBQ3BCeUUsY0FBY2lJLFFBQVF4RDtBQUFBQTtBQUFBQSxRQUN0QnhFLGNBQWNnSSxRQUFRN0k7QUFBQUEsUUFDdEJnQixZQUFZRCxPQUFPOEgsUUFBUXJELFVBQVUsS0FBSztBQUFBO0FBQUEsTUFDOUMsSUFDRXRGO0FBQUFBLElBQ1YsQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNNEkseUJBQXlCQSxNQUFNO0FBQ2pDckssc0JBQWtCLENBQUFzRSxTQUFRLENBQUMsR0FBR0EsTUFBTSxFQUFFNUMsUUFBUUMsT0FBT0MsV0FBVyxHQUFHcUIsUUFBUSxNQUFNQyxVQUFVLE1BQU1FLFFBQVEsRUFBRSxDQUFDLENBQUM7QUFBQSxFQUNqSDtBQUNBLFFBQU1rSCw0QkFBNEJBLENBQUM1SSxXQUFtQjtBQUNsRDFCLHNCQUFrQixDQUFBc0UsU0FBUUEsS0FBSzlILE9BQU8sQ0FBQW9JLE1BQUtBLEVBQUVsRCxXQUFXQSxNQUFNLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU02SSw0QkFBNEJBLENBQUM3SSxRQUFnQnFELE9BQTRCaEIsVUFBa0M7QUFDN0cvRCxzQkFBa0IsQ0FBQXNFLFNBQVFBLEtBQUs5QyxJQUFJLENBQUFvRCxNQUFLQSxFQUFFbEQsV0FBV0EsU0FBUyxFQUFFLEdBQUdrRCxHQUFHLENBQUNHLEtBQUssR0FBR2hCLE1BQU0sSUFBSWEsQ0FBQyxDQUFDO0FBQUEsRUFDL0Y7QUFDQSxRQUFNNEYsNEJBQTRCQSxDQUFDOUksUUFBZ0J5QixRQUFhO0FBQzVELFVBQU1zSCxjQUFjMUssZUFBZXFJLEtBQUssQ0FBQXhELE1BQUtBLEVBQUVsRCxXQUFXQSxVQUFVa0QsRUFBRTNCLFdBQVdFLElBQUl6RixFQUFFO0FBQ3ZGLFFBQUkrTSxhQUFhO0FBQ2JqUSxZQUFNa1EsS0FBSywwREFBMEQ7QUFDckU7QUFBQSxJQUNKO0FBQ0ExSyxzQkFBa0IsQ0FBQXNFLFNBQVFBLEtBQUs5QztBQUFBQSxNQUFJLENBQUFvRCxNQUMvQkEsRUFBRWxELFdBQVdBLFNBQVMsRUFBRSxHQUFHa0QsR0FBRzNCLFFBQVFFLElBQUl6RixJQUFJd0YsVUFBVUMsSUFBSTVCLEtBQUssSUFBSXFEO0FBQUFBLElBQ3pFLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTStGLCtCQUErQkEsQ0FBQzFILFFBQWdCRyxXQUFtQjtBQUNyRXhELG9CQUFnQixDQUFBMEUsU0FBUUEsS0FBSzlDLElBQUksQ0FBQS9FLE1BQUtBLEVBQUV3RyxXQUFXQSxTQUFTLEVBQUUsR0FBR3hHLEdBQUcyRyxPQUFPLElBQUkzRyxDQUFDLENBQUM7QUFBQSxFQUNyRjtBQUdBLFFBQU1tTywwQkFBMEIsT0FBT2xKLFdBQW1CO0FBQ3RELFVBQU03RCxPQUFPc0MsYUFBYStGLEtBQUssQ0FBQXpFLE1BQUtBLEVBQUVDLFdBQVdBLE1BQU07QUFDdkQsVUFBTStELE9BQU81SCxNQUFNc0U7QUFDbkIsUUFBSSxDQUFDc0QsS0FBTSxRQUFPakwsTUFBTW1MLEtBQUsscUNBQXFDO0FBQ2xFLFFBQUk7QUFFQSxZQUFNaEMsV0FBVyxNQUFNeEksT0FBaUIsR0FBR1Msc0JBQXNCOEgsUUFBUSxRQUFRK0IsSUFBSSxFQUFFO0FBQ3ZGLFVBQUk5QixTQUFTSixLQUFLRSxTQUFTLEdBQUc7QUFDMUIwRyw0QkFBb0J6SSxRQUFRaUMsU0FBU0osS0FBSyxDQUFDLENBQUM7QUFBQSxNQUNoRCxPQUFPO0FBQ0gvSSxjQUFNbUksTUFBTSxxQ0FBcUM7QUFBQSxNQUNyRDtBQUFBLElBQ0osU0FBU0EsT0FBTztBQUFFQyxjQUFRRCxNQUFNQSxLQUFLO0FBQUduSSxZQUFNbUksTUFBTSwyQkFBMkI7QUFBQSxJQUFHO0FBQUEsRUFDdEY7QUFFQSxRQUFNa0ksb0JBQW9CQSxDQUFDQyxhQUFrQjtBQUN6QyxRQUFJLENBQUNySyxlQUFlO0FBQ2hCRCxxQkFBZSxLQUFLO0FBQ3BCO0FBQUEsSUFDSjtBQUVBLFFBQUlDLGtCQUFrQixVQUFVO0FBQzVCMkUseUJBQW1CMEYsUUFBUTtBQUFBLElBQy9CLFdBQVdySyxrQkFBa0IsWUFBWTtBQUNyQzhFLDJCQUFxQnVGLFFBQVE7QUFBQSxJQUNqQyxXQUFXLE9BQU9ySyxrQkFBa0IsWUFBWUEsY0FBYy9ELFNBQVMsUUFBUTtBQUMzRSxZQUFNa0gsVUFBVWtIO0FBQ2hCLFlBQU1DLGVBQWV0TCxNQUFNeUcsS0FBSyxDQUFBekUsTUFBS0EsRUFBRUMsV0FBV2pCLGNBQWNpQixNQUFNO0FBQ3RFLFVBQUlxSixjQUFjckosUUFBUTtBQUN0QnNFLHlCQUFpQitFLGFBQWFySixRQUFRLDZCQUE2QmtDLFFBQVFsRyxFQUFFO0FBQzdFc0kseUJBQWlCK0UsYUFBYXJKLFFBQVEsc0JBQXNCa0MsUUFBUXJDLElBQUk7QUFDeEV5RSx5QkFBaUIrRSxhQUFhckosUUFBUSxvQkFBb0JrQyxRQUFRNkIsUUFBUXRJLE9BQU95RyxRQUFRbEcsRUFBRSxDQUFDO0FBQUEsTUFDaEc7QUFBQSxJQUNKLFdBRVMsT0FBTytDLGtCQUFrQixZQUFZQSxjQUFjL0QsU0FBUyxnQkFBZ0I7QUFDakYsWUFBTTBOLFVBQVVVO0FBQ2hCWCwwQkFBb0IxSixjQUFjaUIsUUFBUTBJLE9BQU87QUFBQSxJQUNyRDtBQUNBNUosbUJBQWUsS0FBSztBQUFBLEVBQ3hCO0FBRUEsTUFBSXhDLGVBQWdCLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBRTFDLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHNEQUNYO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHVDQUF1Q0osbUJBQVMsV0FBVyxxQ0FBcUMsb0JBQW9CRixFQUFFLE1BQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUk7QUFBQSxJQUV2SSx1QkFBQyxTQUFJLFdBQVUseUJBQ1gsaUNBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEM7QUFBQTtBQUFBLFVBQWdCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxhQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtIO0FBQUEsUUFDbEgsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT1EsT0FBT0UsZUFBZSxVQUFVLENBQUE0SSxNQUFLbEMsbUJBQW1CLGlCQUFpQmtDLEVBQUVPLE9BQU94RCxLQUFLLEdBQUcsV0FBVSxpSkFBZ0osY0FBYSxTQUEzUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdTO0FBQUEsV0FGcFM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxvQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBQy9FLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU83RixPQUFPSyxVQUFVLFVBQVUsQ0FBQXlJLE1BQUtsQyxtQkFBbUIsWUFBWWtDLEVBQUVPLE9BQU94RCxLQUFLLEdBQUcsV0FBVSxpSkFBZ0osY0FBYSxTQUFqUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNSO0FBQUEsV0FGMVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsVUFBVSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsYUFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFFBQzVHO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFXN0YsT0FBT1EscUJBQXFCO0FBQUEsWUFDdkMsV0FBV1IsT0FBT1M7QUFBQUEsWUFDbEIsY0FBYyxDQUFDcU0sWUFBWTtBQUN2QmxHLGlDQUFtQixxQkFBcUJrRyxPQUFPO0FBQy9DbEcsaUNBQW1CLGFBQWEsSUFBSTtBQUNwQ0EsaUNBQW1CLGVBQWUsSUFBSTtBQUN0Q3RGLDZCQUFlLEVBQUU7QUFDakJNLDJDQUE2QixLQUFLO0FBQ2xDb0IsMENBQTRCRSxVQUFVO0FBQ3RDRCxpQ0FBbUJDLFVBQVU7QUFBQSxZQUNqQztBQUFBLFlBQ0EsY0FBY3NFO0FBQUFBLFlBQ2QsZUFBZSxNQUFNa0UsVUFBVSxVQUFVbE8sdUJBQXVCO0FBQUEsWUFDaEUsY0FBYyxNQUFNO0FBQ2hCb0osaUNBQW1CLGFBQWEsSUFBSTtBQUNwQ0EsaUNBQW1CLGVBQWUsSUFBSTtBQUN0Q0EsaUNBQW1CLHFCQUFxQixFQUFFO0FBQzFDdEYsNkJBQWUsRUFBRTtBQUNqQk0sMkNBQTZCLEtBQUs7QUFDbENvQiwwQ0FBNEJFLFVBQVU7QUFDdENELGlDQUFtQkMsVUFBVTtBQUFBLFlBQ2pDO0FBQUE7QUFBQSxVQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQk07QUFBQSxXQXhCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsVUFBYyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsYUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFFBQ2hIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBTSxNQUFLO0FBQUEsWUFBTyxPQUFPbEQsT0FBT2E7QUFBQUEsWUFDN0IsVUFBVSxDQUFBaUksTUFBS2xDLG1CQUFtQixtQkFBbUJrQyxFQUFFTyxPQUFPeEQsS0FBSztBQUFBLFlBQ25FLFdBQVU7QUFBQSxZQUFnSixjQUFhO0FBQUE7QUFBQSxVQUYzSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0w7QUFBQSxXQUpwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSxVQUFNLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxhQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdHO0FBQUEsUUFDeEc7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU83RixPQUFPTSxVQUFVO0FBQUEsWUFDeEIsVUFBVSxDQUFBd0ksTUFBS2xDLG1CQUFtQixVQUFVa0MsRUFBRU8sT0FBT3hELEtBQUs7QUFBQSxZQUMxRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ25CLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ25CLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ25CLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBO0FBQUE7QUFBQSxVQVJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxzQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFLHVCQUFDLFNBQUksV0FBVSxZQUNYO0FBQUEsaUNBQUMsV0FBTSxNQUFLLFFBQU8sT0FBTzdGLE9BQU9lLGVBQWUsVUFBVSxDQUFBK0gsTUFBS2xDLG1CQUFtQixpQkFBaUJrQyxFQUFFTyxPQUFPeEQsS0FBSyxHQUFHLFdBQVUsaUpBQWdKLGNBQWEsU0FBM1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ1M7QUFBQSxVQUMvUjdGLE9BQU9PLGFBQ0o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVMwSDtBQUFBQSxjQUNULFVBQVU5RjtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVUQSxnQ0FBc0IsdUJBQUMsYUFBVSxXQUFVLGtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQyxJQUFNLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUztBQUFBO0FBQUEsWUFMN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQVRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsVUFBTyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsYUFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFFBQ3pHO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFXbkMsT0FBT1csaUJBQWlCO0FBQUEsWUFDbkMsV0FBV1gsT0FBT1ksaUJBQWlCO0FBQUEsWUFDbkMsY0FBYyxDQUFDa00sWUFBWTtBQUN2QmxHLGlDQUFtQixpQkFBaUJrRyxPQUFPO0FBQzNDbEcsaUNBQW1CLGVBQWUsSUFBSTtBQUN0Q0EsaUNBQW1CLGlCQUFpQixJQUFJO0FBQUEsWUFFNUM7QUFBQSxZQUNBLGNBQWNlO0FBQUFBLFlBQ2QsZUFBZSxNQUFNK0QsVUFBVSxZQUFZeE4sbUJBQW1CO0FBQUEsWUFDOUQsY0FBYyxNQUFNO0FBQ2hCMEksaUNBQW1CLGVBQWUsSUFBSTtBQUN0Q0EsaUNBQW1CLGlCQUFpQixJQUFJO0FBQ3hDQSxpQ0FBbUIsaUJBQWlCLEVBQUU7QUFBQSxZQUUxQztBQUFBO0FBQUEsVUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZ0JNO0FBQUEsV0FsQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxRQUN6RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsT0FBTzVHLE9BQU9rQjtBQUFBQSxZQUNkLFVBQVUsQ0FBQTZMLFFBQU9uRyxtQkFBbUIsaUJBQWlCbUcsR0FBRztBQUFBLFlBQ3hELFdBQVU7QUFBQTtBQUFBLFVBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWtHO0FBQUEsV0FOdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzVFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFPL00sT0FBT21CO0FBQUFBLFlBQ2QsVUFBVSxDQUFBMkgsTUFBS2xDLG1CQUFtQixvQkFBb0JrQyxFQUFFTyxPQUFPeEQsS0FBSztBQUFBLFlBQ3BFLFdBQVU7QUFBQSxZQUVUdUMsZ0JBQU00RSxLQUFLLEVBQUV6SCxRQUFRLEdBQUcsR0FBRyxDQUFDMEgsR0FBRzFKLE1BQU10RSxPQUFPc0UsSUFBSSxDQUFDLEVBQUVwRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUVtRTtBQUFBQSxjQUFJLENBQUM0SixNQUN2RSx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxZQUNoQztBQUFBO0FBQUEsVUFQTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzVFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFPbE4sT0FBT29CO0FBQUFBLFlBQ2QsVUFBVSxDQUFBMEgsTUFBS2xDLG1CQUFtQixtQkFBbUJ4QyxPQUFPMEUsRUFBRU8sT0FBT3hELEtBQUssQ0FBQztBQUFBLFlBQzNFLFdBQVU7QUFBQSxZQUVUdUMsZ0JBQU00RSxLQUFLLEVBQUV6SCxRQUFRbkcsWUFBWSxJQUFJLE9BQU8sRUFBRSxHQUFHLENBQUM2TixHQUFHMUosTUFBTSxPQUFPQSxDQUFDLEVBQUVEO0FBQUFBLGNBQUksQ0FBQzZKLE1BQ3ZFLHVCQUFDLFlBQWUsT0FBT0EsR0FBSUEsZUFBZEEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLFlBQ2hDO0FBQUE7QUFBQSxVQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sU0FBUSxpQkFBZ0IsV0FBVSwyQ0FBeUMscUNBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0N6TixTQUFTLFVBQVVFLGlCQUFpQndOLHNCQUNqQyx1QkFBQyxTQUFJLFdBQVUseURBQ1g7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsOEJBQTZCLCtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3pEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFTeEQ7QUFBQUEsY0FDVCxVQUFVL0c7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLHFCQUFrQixXQUFVLFVBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DO0FBQUEsZ0JBQ2xDQSxnQkFBZ0IsZ0JBQWdCO0FBQUE7QUFBQTtBQUFBLFlBUHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVKO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSCxVQUFVdUc7QUFBQUEsWUFDVixjQUFhO0FBQUEsWUFBTSxXQUFVO0FBQUEsWUFDN0IsUUFBTztBQUFBO0FBQUEsVUFMWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLaUM7QUFBQSxRQUVqQyx1QkFBQyxPQUFFLFdBQVUsOEJBQ1IxSixtQkFBUyxVQUFVRSxpQkFBaUJ5TixvQkFDL0IscUdBQ0EsK0NBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQTtBQUFBLFNBN0pKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4SkEsS0EvSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdLQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyx5QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLE1BQzNELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IscUdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEg7QUFBQSxNQUMxSCx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxnRkFBK0Usd0JBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFHO0FBQUEsVUFDckcsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCx3QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELG9DQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLFVBQzlGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsUUFBRyxXQUFVLHVDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFMdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pwTCx1QkFBYXFCO0FBQUFBLFVBQUksQ0FBQzNELFNBQ2YsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FFVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVdBLEtBQUtzRSxnQkFBZ0I7QUFBQSxnQkFDaEMsV0FBV3RFLEtBQUt1RSxnQkFBZ0I7QUFBQSxnQkFDaEMsY0FBYyxDQUFDNEksWUFBWTtBQUN2QmQsMENBQXdCck0sS0FBSzZELFFBQVMsZ0JBQWdCc0osT0FBTztBQUM3RGQsMENBQXdCck0sS0FBSzZELFFBQVMsY0FBYyxJQUFJO0FBQ3hEd0ksMENBQXdCck0sS0FBSzZELFFBQVMsZ0JBQWdCLElBQUk7QUFDMUR3SSwwQ0FBd0JyTSxLQUFLNkQsUUFBUyxjQUFjLENBQUM7QUFBQSxnQkFDekQ7QUFBQSxnQkFDQSxjQUFjLE1BQU1rSix3QkFBd0IvTSxLQUFLNkQsTUFBTztBQUFBLGdCQUN4RCxlQUFlLE1BQU1rSSxVQUFVLEVBQUVsTixNQUFNLGdCQUFnQmdGLFFBQVE3RCxLQUFLNkQsT0FBUSxHQUFHOUYscUJBQXFCO0FBQUEsZ0JBQ3BHLGNBQWMsTUFBTTtBQUNoQnNPLDBDQUF3QnJNLEtBQUs2RCxRQUFTLGNBQWMsSUFBSTtBQUN4RHdJLDBDQUF3QnJNLEtBQUs2RCxRQUFTLGdCQUFnQixJQUFJO0FBQzFEd0ksMENBQXdCck0sS0FBSzZELFFBQVMsZ0JBQWdCLEVBQUU7QUFDeER3SSwwQ0FBd0JyTSxLQUFLNkQsUUFBUyxjQUFjLENBQUM7QUFBQSxnQkFDekQ7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsb0JBQW9CO0FBQUEsZ0JBQ3BCLG9CQUFvQjtBQUFBLGtCQUNoQmdDLFVBQVU5SCxzQkFBc0I4SDtBQUFBQSxrQkFDaEM4SCxXQUFXO0FBQUEsa0JBQ1hDLFdBQVc7QUFBQSxrQkFDWEMsY0FBYzdQO0FBQUFBLGtCQUNkOFAsVUFBVUEsQ0FBQ3ZCLFlBQVk7QUFDbkJELHdDQUFvQnRNLEtBQUs2RCxRQUFTMEksT0FBTztBQUFBLGtCQUM3QztBQUFBLGdCQUNKO0FBQUE7QUFBQSxjQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUEyQk0sS0E3QlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNWLGlDQUFDLGdCQUFhLE9BQU92TSxLQUFLd0UsVUFBVSxVQUFVLENBQUE0SSxRQUFPZix3QkFBd0JyTSxLQUFLNkQsUUFBUyxZQUFZdUosR0FBRyxHQUFHLFdBQVUsc0ZBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlNLEtBRDdNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNWLGlDQUFDLGdCQUFhLE9BQU9wTixLQUFLMEUsWUFBWSxVQUFVLENBQUEwSSxRQUFPZix3QkFBd0JyTSxLQUFLNkQsUUFBUyxjQUFjdUosR0FBRyxHQUFHLFdBQVUsc0ZBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZNLEtBRGpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FDVC9PLHVCQUFhMkIsS0FBS3dFLFlBQVksTUFBTXhFLEtBQUswRSxjQUFjLElBQUksVUFBVSxLQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUscUNBQ1YsaUNBQUMsWUFBTyxTQUFTLE1BQU0wSCx3QkFBd0JwTSxLQUFLNkQsTUFBTyxHQUFHLFdBQVUsbUNBQWtDLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUSxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSCxLQUR6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUE1Q0s3RCxLQUFLNkQsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZDQTtBQUFBLFFBQ0gsS0FoREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlEQTtBQUFBLFdBM0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0REEsS0E3REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThEQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxTQUFTc0ksc0JBQXNCLFdBQVUsdUpBQXNKO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBQTFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeVA7QUFBQSxTQWxFN1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1FQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG9DQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyxxQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RDtBQUFBLE1BQ3ZELHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdGQUErRSwrQkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxVQUM1Ryx1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFFBQUcsV0FBVSx1Q0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLGFBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNadkssZ0JBQU0rQjtBQUFBQSxVQUFJLENBQUMzRCxTQUNSLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFZQSxLQUFpQ2dFLG9CQUFvQjtBQUFBLGdCQUNqRSxXQUFXaEUsS0FBS2lHLHNCQUFzQjtBQUFBLGdCQUN0QyxjQUFjLENBQUNrSCxZQUFZO0FBQ3ZCaEYsbUNBQWlCbkksS0FBSzZELFFBQVMsNkJBQTZCLElBQUk7QUFDaEVzRSxtQ0FBaUJuSSxLQUFLNkQsUUFBUyxzQkFBc0IsRUFBRTtBQUN2RHNFLG1DQUFpQm5JLEtBQUs2RCxRQUFTLG9CQUEwQ3NKLE9BQU87QUFBQSxnQkFDcEY7QUFBQSxnQkFDQSxjQUFjLE1BQU0vRSx3QkFBd0JwSSxLQUFLNkQsTUFBTztBQUFBLGdCQUN4RCxlQUFlLE1BQU1rSSxVQUFVLEVBQUVsTixNQUFNLFFBQVFnRixRQUFRN0QsS0FBSzZELE9BQVEsR0FBVS9GLHlCQUF5QjtBQUFBLGdCQUN2RyxjQUFjLE1BQU07QUFDaEJxSyxtQ0FBaUJuSSxLQUFLNkQsUUFBUyw2QkFBNkIsSUFBSTtBQUNoRXNFLG1DQUFpQm5JLEtBQUs2RCxRQUFTLHNCQUFzQixFQUFFO0FBQ3ZEc0UsbUNBQWlCbkksS0FBSzZELFFBQVMsb0JBQTBDLEVBQUU7QUFBQSxnQkFDL0U7QUFBQTtBQUFBLGNBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY00sS0FmVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1YsaUNBQUMsZ0JBQWEsT0FBTzdELEtBQUtrRyxPQUFPLFVBQVUsQ0FBQWtILFFBQU9qRixpQkFBaUJuSSxLQUFLNkQsUUFBUyxTQUFTdUosR0FBRyxHQUFHLFdBQVUseUpBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStQLEtBRG5RO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxxQ0FDVixpQ0FBQyxZQUFPLFNBQVMsTUFBTWxGLGlCQUFpQmxJLEtBQUs2RCxNQUFPLEdBQUcsV0FBVSxtQ0FBa0MsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFRLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThHLEtBRGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXhCSzdELEtBQUs2RCxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsUUFDSCxLQTVCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsV0FyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQSxLQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFNBQVNvRSxlQUFlLFdBQVUsdUpBQXNKO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBQW5PO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOE87QUFBQSxTQTNDbFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUVYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlEQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyxzQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFLHVCQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLGlDQUFDLFdBQU0sV0FBVSxzREFBcUQsb0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsVUFDMUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU81SCxPQUFPZ0I7QUFBQUEsY0FDZCxVQUFVLENBQUErTCxRQUFPbkcsbUJBQW1CLHFCQUFxQm1HLEdBQUc7QUFBQSxjQUM1RCxXQUFVO0FBQUE7QUFBQSxZQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdtSztBQUFBLGFBTHZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHNEQUFxRCw2QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csT0FBTy9NLE9BQU9pQjtBQUFBQSxjQUNkLFVBQVUsQ0FBQThMLFFBQU9uRyxtQkFBbUIsWUFBWW1HLEdBQUc7QUFBQSxjQUNuRCxXQUFVO0FBQUE7QUFBQSxZQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdtSztBQUFBLGFBTHZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0MsQ0FBQy9NLE9BQU9PLFlBQ0wsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixvRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RixJQUM5RmMsWUFBWWtFLFNBQVMsSUFDckI5RCxhQUFhNkIsSUFBSSxDQUFBMkIsUUFBTztBQUNwQixnQkFBTXlJLHNCQUFzQnJNLFlBQVlrRSxTQUFTLEtBQUs1RDtBQUN0RCxpQkFDSSx1QkFBQyxTQUFxQixXQUFVLHVDQUM1QjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzREFBc0RzRDtBQUFBQSxrQkFBSUQ7QUFBQUEsY0FBUztBQUFBLGNBQUdDLElBQUlnQjtBQUFBQSxjQUFLO0FBQUEsaUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFDakcsdUJBQUMsU0FBSSxXQUFVLDJCQUNWeUgsZ0NBQ0c7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFPekksSUFBSUM7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFBNkgsUUFBT04sNkJBQTZCeEgsSUFBSUYsUUFBUWdJLE9BQU8sQ0FBQztBQUFBLGdCQUNsRSxXQUFVO0FBQUE7QUFBQSxjQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcwSyxJQUcxSyxtQ0FDSTtBQUFBLHFDQUFDLFVBQUssV0FBVSwyRUFDWC9PLHNCQUFZaUgsSUFBSUMsUUFBUSxVQUFVLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTNEI7QUFBQUEsa0JBQ1QsY0FBVztBQUFBLGtCQUNYLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxlQUFZLFdBQVUsaUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUE7QUFBQSxnQkFOeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBLEtBcEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsZUF4Qk03QixJQUFJRixRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsUUFFUixDQUFDLElBRUQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwwRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFFBRXhHLHVCQUFDLFNBQUksV0FBVSxzQ0FDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQ0FBeUMsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbEVoRCxnQkFBZ0J3RCxXQUFXLElBQ3hCLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsaURBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFLElBRXRFLG1DQUNJO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGFBQ1YxRCx5QkFBZXlCO0FBQUFBLGNBQUksQ0FBQ3FLLFFBQ2pCLHVCQUFDLFNBQXFCLFdBQVUsdUNBQzVCO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csT0FBT0EsSUFBSTVJLFVBQVU7QUFBQSxvQkFDckIsVUFBVSxDQUFDK0QsTUFBTTtBQUNiLDRCQUFNOEUsTUFBTTlFLEVBQUVPLE9BQU94RDtBQUNyQiwwQkFBSSxDQUFDK0gsS0FBSztBQUNOdkIsa0RBQTBCc0IsSUFBSW5LLFFBQVEsVUFBVSxJQUFJO0FBQ3BENkksa0RBQTBCc0IsSUFBSW5LLFFBQVEsWUFBWSxJQUFJO0FBQ3REO0FBQUEsc0JBQ0o7QUFDQSw0QkFBTXlCLE1BQU1sRCxnQkFBZ0JpRyxLQUFLLENBQUF6SixNQUFLQSxFQUFFaUIsT0FBTzRFLE9BQU93SixHQUFHLENBQUM7QUFDMUQsMEJBQUkzSSxJQUFLcUgsMkJBQTBCcUIsSUFBSW5LLFFBQVF5QixHQUFHO0FBQUEsb0JBQ3REO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBQ3JDbEQsZ0JBQWdCdUI7QUFBQUEsd0JBQUksQ0FBQzJCLFFBQ2xCLHVCQUFDLFlBQW9CLE9BQU9BLElBQUl6RixJQUFJLFVBQVVxQyxlQUFlcUksS0FBSyxDQUFBeEQsTUFBS0EsRUFBRWxELFdBQVdtSyxJQUFJbkssVUFBVWtELEVBQUUzQixXQUFXRSxJQUFJekYsRUFBRSxHQUNoSHlGLGNBQUk1QixRQURJNEIsSUFBSXpGLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDSDtBQUFBO0FBQUE7QUFBQSxrQkFuQkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQW9CQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE9BQU9tTyxJQUFJekk7QUFBQUEsc0JBQ1gsVUFBVSxDQUFBNkgsUUFBT1YsMEJBQTBCc0IsSUFBSW5LLFFBQVEsVUFBVXVKLEdBQUc7QUFBQSxzQkFDcEUsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQTtBQUFBLG9CQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSW1CO0FBQUEsa0JBRW5CLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTVgsMEJBQTBCdUIsSUFBSW5LLE1BQU0sR0FBRyxXQUFVLHVDQUFzQyxPQUFNLFVBQVMsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFRLEtBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNKO0FBQUEscUJBUDFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxtQkE5Qk1tSyxJQUFJbkssUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStCQTtBQUFBLFlBQ0gsS0FsQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0E7QUFBQSxZQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMySSx3QkFBd0IsV0FBVSx1SkFDN0Q7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FBRztBQUFBLGlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxhQTdDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsV0F0R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDJFQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQU1uTyxzQkFBWXVJLE9BQU9ULFVBQVUsVUFBVSxLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLGFBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEg7QUFBQSxRQUM1SCx1QkFBQyxTQUFJLFdBQVUsOENBQTZDO0FBQUEsaUNBQUMsVUFBSyw4Q0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQU05SCxzQkFBWWdDLE9BQU9nQixtQkFBbUIsVUFBVSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBQWpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0s7QUFBQSxRQUN4Syx1QkFBQyxTQUFJLFdBQVUsNkNBQTRDO0FBQUEsaUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQUdoRCxZQUFZZ0MsT0FBT2lCLFVBQVUsVUFBVTtBQUFBLGVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFBckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0STtBQUFBLFFBQzVJLHVCQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSxpQ0FBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBTztBQUFBLFVBQUMsdUJBQUMsVUFBTWpELHNCQUFZdUksT0FBT0MsVUFBVSxVQUFVLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsYUFBdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SDtBQUFBLFFBQzdILHVCQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSxpQ0FBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFBTztBQUFBLFVBQUMsdUJBQUMsVUFBTXhJLHNCQUFZdUksT0FBT0UsbUJBQW1CLFVBQVUsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxhQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlJO0FBQUEsUUFDekksdUJBQUMsU0FBSSxXQUFVLDZEQUE0RDtBQUFBLGlDQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQU16SSxzQkFBWXVJLE9BQU9JLFlBQVksVUFBVSxLQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLGFBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0o7QUFBQSxXQU41SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWpISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0hBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1sSCxTQUFTdEIsa0JBQWtCWixvQkFBb0JpTyxTQUFTLENBQUMsR0FBRyxXQUFVLDhJQUE2SSx3QkFBeFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnUTtBQUFBLE1BQ2hRLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVN2QixZQUFZLFVBQVVwSyxTQUFTLFdBQVUsK0tBQ25FQTtBQUFBQSxrQkFBVSx1QkFBQyxhQUFVLFdBQVUsK0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0QsSUFBTSx1QkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUFHO0FBQUEsV0FEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVDd0MsZUFDRyx1QkFBQyxlQUFZLFFBQVFBLGFBQWEsU0FBUyxNQUFNQyxlQUFlLEtBQUssR0FBRyxVQUFVcUssbUJBQW1CLFFBQVFoSyxlQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlIO0FBQUEsT0F0WmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3WkE7QUFFUjtBQUFFcEQsR0E3akNXRCxpQkFBZTtBQUFBLFVBQ1RqRCxXQUNFRCxhQUttRFcsYUFDbENELFFBQVE7QUFBQTtBQUFBK1EsS0FSakN2TztBQUFlLElBQUF1TztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ0b2FzdCIsIkZhUGx1cyIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhVHJhc2giLCJGYVNlYXJjaCIsIkZhRXh0ZXJuYWxMaW5rQWx0IiwiRmFQZW5jaWxBbHQiLCJ1c2VNb2RhbCIsInVzZUNydWRJdGVtIiwiZ2V0QnlJZCIsInNlYXJjaCIsImNyZWF0ZSIsInVwZGF0ZSIsImdldEFsbCIsImJlZ2luUGRmUHJldmlldyIsImZpbmlzaFBkZlByZXZpZXciLCJjb21wcmFzTW9kdWxlQ29uZmlnIiwicHJvdmVlZG9yZXNNb2R1bGVDb25maWciLCJwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMiLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsImZvcm1hdERhdGVGb3JJbnB1dCIsImZvcm1hdFZhbHVlIiwiTG9hZGluZ1NwaW5uZXIiLCJtb25lZGFzTW9kdWxlQ29uZmlnIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJmaWx0ZXJWZW5kb3JUYXhlc1R5cGVHZW5lcmFsIiwidGF4ZXMiLCJmaWx0ZXIiLCJ0IiwidHlwZSIsImFkZERheXMiLCJkYXRlIiwiZGF5cyIsInJlc3VsdCIsIkRhdGUiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsImN1cnJlbnRNb250aFBhZGRlZCIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJjdXJyZW50WWVhciIsImdldEZ1bGxZZWFyIiwiQ29tcHJhc0Zvcm1QYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwibW9kZSIsIml0ZW0iLCJpbml0aWFsUHVyY2hhc2UiLCJsb2FkaW5nIiwibG9hZGluZ0luaXRpYWwiLCJzaG93Q29uZmlybWF0aW9uTW9kYWwiLCJoZWFkZXIiLCJzZXRIZWFkZXIiLCJwdXJjaGFzZV9kYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImR1ZV9kYXRlIiwic2VyaWVzIiwidmVuZG9yX2lkIiwidmVuZG9yX2NvZGVfaW5wdXQiLCJ2ZW5kb3JfbmFtZSIsImN1cnJlbmN5X2lkIiwiY3VycmVuY3lfY29kZSIsImN1cnJlbmN5X25hbWUiLCJkb2N1bWVudF9udW1iZXIiLCJpbnRlcm5hbF92b3VjaGVyIiwiZGVsaXZlcnlfbm90ZSIsIndpdGhvdXR0YXhfYW1vdW50IiwiZGlzY291bnQiLCJleGNoYW5nZV9yYXRlIiwiaW1wdXRhdGlvbl9tb250aCIsImltcHV0YXRpb25feWVhciIsInZlbmRvclRheGVzIiwic2V0VmVuZG9yVGF4ZXMiLCJpdGVtcyIsInNldEl0ZW1zIiwiYXBwbGllZFRheGVzIiwic2V0QXBwbGllZFRheGVzIiwiaXNTaW5nbGVUYXhBbW91bnRFZGl0YWJsZSIsInNldElzU2luZ2xlVGF4QW1vdW50RWRpdGFibGUiLCJwZXJjZXB0aW9uUm93cyIsInNldFBlcmNlcHRpb25Sb3dzIiwicGVyY2VwdGlvblRheGVzIiwic2V0UGVyY2VwdGlvblRheGVzIiwicHJvZHVjdEl0ZW1zIiwic2V0UHJvZHVjdEl0ZW1zIiwiaXNGZXRjaGluZ01vdmVtZW50cyIsInNldElzRmV0Y2hpbmdNb3ZlbWVudHMiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJpbnZvaWNlSW1hZ2VGaWxlIiwic2V0SW52b2ljZUltYWdlRmlsZSIsIm1vZGFsQ29uZmlnIiwic2V0TW9kYWxDb25maWciLCJpc0xvYWRpbmdGaWxlIiwic2V0SXNMb2FkaW5nRmlsZSIsImluaXRpYWxJdGVtMTAwMzAxTG9hZGVkIiwic2tpcEluaXRpYWxFZGl0VGF4UmVjYWxjUmVmIiwiZWRpdFRheEJhc2VsaW5lUmVmIiwiY3VycmVudCIsInZlbmRvciIsInZlbmRvcl9jb2RlIiwibmFtZSIsIm1hcCIsImkiLCJ0ZW1wSWQiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiY2hhcnRfY29kZV9pbnB1dCIsImNoYXJ0X2FjY291bnRfY29kZSIsImxvYWRlZFByb2R1Y3RzIiwicHJvZHVjdHMiLCJwcm9kIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfY29kZSIsInByb2R1Y3RfbmFtZSIsInF1YW50aXR5IiwiTnVtYmVyIiwicHJpY2VfY29zdCIsImZldGNoVmVuZG9yVGF4ZXMiLCJyZWxhdGVkVGF4ZXMiLCJmdWxsVmVuZG9yIiwiZXJyb3IiLCJjb25zb2xlIiwidGF4ZXNUeXBlMSIsImFwcGxpZWRfdGF4ZXMiLCJ0YXhfdHlwZSIsInRheGVzVHlwZTIiLCJ0YXhfaWQiLCJ0YXhfbmFtZSIsInRheCIsImFtb3VudCIsInRoZW4iLCJyZXMiLCJkYXRhIiwiY2F0Y2giLCJsZW5ndGgiLCJlbmRwb2ludCIsInJlc3BvbnNlIiwiYWNjb3VudCIsImxlZ2FjeV9jaGFydF9hY2NvdW50X2NvZGUiLCJjaGFydF9hY2NvdW50X25hbWUiLCJ2YWx1ZSIsInN1YnRvdGFsIiwicmVkdWNlIiwic3VtIiwicmF0ZSIsImlucHV0cyIsIndpdGhvdXR0YXgiLCJwcmV2IiwidGF4QmFzZSIsImNhbGN1bGF0ZWRUYXhlcyIsInRvdGFscyIsInRheFRvdGFsIiwicGVyY2VwY2lvbmVzVG90YWwiLCJyIiwiZ3JhbmRUb3RhbCIsImhhbmRsZUhlYWRlckNoYW5nZSIsImZpZWxkIiwiaGFuZGxlUmVxdWVzdEVkaXRTaW5nbGVUYXgiLCJ0aXRsZSIsIm1lc3NhZ2UiLCJvbkNvbmZpcm0iLCJoYW5kbGVTZWxlY3RWZW5kb3IiLCJwYXltZW50X2NvbmRpdGlvbiIsInNlcmllIiwiaGFuZGxlU2VsZWN0Q3VycmVuY3kiLCJjdXJyZW5jeSIsImNvZGUiLCJoYW5kbGVWZW5kb3JDb2RlU3VibWl0IiwiaW5mbyIsImxvZyIsImhhbmRsZUN1cnJlbmN5Q29kZVN1Ym1pdCIsImhhbmRsZUFkZEl0ZW0iLCJoYW5kbGVSZW1vdmVJdGVtIiwiaGFuZGxlVXBkYXRlSXRlbSIsImhhbmRsZUFjY291bnRDb2RlU3VibWl0IiwiZmluZCIsImhhbmRsZUZldGNoU3RvY2tNb3ZlbWVudHMiLCJlbmNvZGVVUklDb21wb25lbnQiLCJsaXN0IiwiQXJyYXkiLCJpc0FycmF5IiwibmV3UHJvZHVjdEl0ZW1zIiwibW92ZW1lbnQiLCJjb3N0IiwicHJvZHVjdElkIiwic2t1IiwicHJvZFJlc3BvbnNlIiwicHJvZExpc3QiLCJjb3N0X3ByaWNlIiwiZSIsInB1c2giLCJwcm9kdWN0c1RvdGFsIiwicCIsImlkeCIsImZpbmRJbmRleCIsImhhbmRsZUZpbGVDaGFuZ2UiLCJ0YXJnZXQiLCJmaWxlcyIsImZpbGUiLCJhbGxvd2VkVHlwZXMiLCJtYXhTaXplIiwiaW5jbHVkZXMiLCJzaXplIiwiaGFuZGxlVmlld0ZpbGUiLCJzZXNzaW9uIiwid2luZG93IiwiY2xvc2VkIiwiY2xvc2UiLCJoYW5kbGVTYXZlIiwic29tZSIsInF0eSIsIml0ZW1zVG90YWwiLCJwcm9kUm91bmRlZCIsIk1hdGgiLCJyb3VuZCIsIml0ZW1zUm91bmRlZCIsImNsZWFuSXRlbXMiLCJpbmRleCIsInJlc3QiLCJ1bmRlZmluZWQiLCJpdGVtX251bWJlciIsImNsZWFuVGF4ZXMiLCJjbGVhblByb2R1Y3RzIiwicGF5bG9hZCIsInRvdGFsX2Ftb3VudCIsImZvcm1EYXRhIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsImVycm9yTXNnIiwib3Blbk1vZGFsIiwiY29uZmlnIiwiaXNQcm9kdWN0SXRlbSIsImluaXRpYWxGaWx0ZXJzIiwiaGFuZGxlQWRkUHJvZHVjdEl0ZW0iLCJoYW5kbGVSZW1vdmVQcm9kdWN0SXRlbSIsImhhbmRsZVVwZGF0ZVByb2R1Y3RJdGVtIiwiaGFuZGxlU2VsZWN0UHJvZHVjdCIsInByb2R1Y3QiLCJoYW5kbGVBZGRQZXJjZXB0aW9uUm93IiwiaGFuZGxlUmVtb3ZlUGVyY2VwdGlvblJvdyIsImhhbmRsZVVwZGF0ZVBlcmNlcHRpb25Sb3ciLCJoYW5kbGVTZWxlY3RQZXJjZXB0aW9uVGF4IiwiYWxyZWFkeVVzZWQiLCJ3YXJuIiwiaGFuZGxlVXBkYXRlQXBwbGllZFRheEFtb3VudCIsImhhbmRsZVByb2R1Y3RDb2RlU3VibWl0IiwiaGFuZGxlU2VsZWN0TW9kYWwiLCJzZWxlY3RlZCIsIml0ZW1Ub1VwZGF0ZSIsIm5ld0NvZGUiLCJudW0iLCJmcm9tIiwiXyIsIm0iLCJ5IiwiaW52b2ljZV9pbWFnZV9wYXRoIiwiaW52b2ljZV9pbWFnZV91cmwiLCJjb2RlRmllbGQiLCJuYW1lRmllbGQiLCJzZWFyY2hQYXJhbXMiLCJvblNlbGVjdCIsImlzVGF4QW1vdW50RWRpdGFibGUiLCJyb3ciLCJ2YWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wcmFzRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFycyAqL1xuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVBsdXMsIEZhU2F2ZSwgRmFTcGlubmVyLCBGYVRyYXNoLCBGYVNlYXJjaCwgRmFFeHRlcm5hbExpbmtBbHQsIEZhUGVuY2lsQWx0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgdXNlTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0L01vZGFsQ29udGV4dCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaCwgY3JlYXRlLCB1cGRhdGUsIGdldEFsbCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgYmVnaW5QZGZQcmV2aWV3LCBmaW5pc2hQZGZQcmV2aWV3IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvYmxvYkhlbHBlcic7XG5pbXBvcnQgeyBjb21wcmFzTW9kdWxlQ29uZmlnLCB0eXBlIFB1cmNoYXNlLCB0eXBlIFB1cmNoYXNlSXRlbSB9IGZyb20gJy4uL2NvbXByYXMuY29uZmlnJztcbmltcG9ydCB7IHR5cGUgUHJvdmVlZG9yLCBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL3Byb3ZlZWRvcmVzL3Byb3ZlZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLCB0eXBlIFBsYW5EZUN1ZW50YXMgfSBmcm9tICcuLi8uLi9wbGFuX2RlX2N1ZW50YXMvcGxhbl9kZV9jdWVudGFzLmNvbmZpZyc7XG5pbXBvcnQgeyB0eXBlIEFydGljdWxvLCBhcnRpY3Vsb3NNb2R1bGVDb25maWcsIGFydGljdWxvc0l0ZW1TZWFyY2hGaWx0ZXJzIH0gZnJvbSAnLi4vLi4vYXJ0aWN1bG9zL2FydGljdWxvcy5jb25maWcnOyAvLyDinIUgMS4gSW1wb3J0YW1vcyBBcnRpY3Vsb3NcbmltcG9ydCB7IFJlbGF0aW9uYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JlbGF0aW9uYWxJbnB1dCc7XG5pbXBvcnQgeyBEZWNpbWFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9EZWNpbWFsSW5wdXQnO1xuaW1wb3J0IHsgU2VhcmNoTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9TZWFyY2hNb2RhbCc7XG5pbXBvcnQgeyBmb3JtYXREYXRlRm9ySW5wdXQsIGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgdHlwZSBBcHBsaWVkVGF4LCB0eXBlIFJlbGF0ZWRUYXggYXMgVmVuZG9yVGF4IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzJztcbmltcG9ydCB7IG1vbmVkYXNNb2R1bGVDb25maWcsIHR5cGUgTW9uZWRhIH0gZnJvbSAnLi4vLi4vbW9uZWRhcy9tb25lZGFzLmNvbmZpZyc7XG5pbXBvcnQgeyB0eXBlIFRheCB9IGZyb20gJy4uLy4uL2ltcHVlc3Rvcy9pbXB1ZXN0b3MuY29uZmlnJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5pbnRlcmZhY2UgUHJvZHVjdFB1cmNoYXNlSXRlbSB7XG4gICAgdGVtcElkOiBzdHJpbmc7XG4gICAgcHJvZHVjdF9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICBwcm9kdWN0X2NvZGU6IHN0cmluZzsgLy8gUGFyYSBlbCBpbnB1dCAoc2t1KVxuICAgIHByb2R1Y3RfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBxdWFudGl0eTogbnVtYmVyO1xuICAgIHByaWNlX2Nvc3Q6IG51bWJlcjsgLy8gRWwgJ2Nvc3RfcHJpY2UnIGRlbCBwcm9kdWN0b1xufVxuXG5pbnRlcmZhY2UgUGVyY2VwdGlvblJvdyB7XG4gICAgdGVtcElkOiBzdHJpbmc7XG4gICAgdGF4X2lkOiBudW1iZXIgfCBudWxsO1xuICAgIHRheF9uYW1lOiBzdHJpbmcgfCBudWxsO1xuICAgIGFtb3VudDogbnVtYmVyO1xufVxuXG4vKiogSW1wdWVzdG9zIGRlbCBwcm92ZWVkb3IgYXBsaWNhYmxlcyBhbCBibG9xdWUgSVZBIGRlIGNvbXByYXM6IHNvbG8gY2F0w6Fsb2dvIHRpcG8gMSAoR2VuZXJhbCkuICovXG5jb25zdCBmaWx0ZXJWZW5kb3JUYXhlc1R5cGVHZW5lcmFsID0gKHRheGVzOiBWZW5kb3JUYXhbXSB8IG51bGwgfCB1bmRlZmluZWQpOiBWZW5kb3JUYXhbXSA9PlxuICAgICh0YXhlcyA/PyBbXSkuZmlsdGVyKCh0KSA9PiB0LnR5cGUgPT09IDEpO1xuXG50eXBlIEFjY291bnRpbmdJdGVtV2l0aElucHV0ID0gUHVyY2hhc2VJdGVtICYge1xuICAgIGNoYXJ0X2NvZGVfaW5wdXQ/OiBzdHJpbmc7XG59O1xuXG50eXBlIEVkaXRpbmdUYXJnZXQgPSAndmVuZG9yJyB8ICdjdXJyZW5jeSdcbiAgICB8IHsgdHlwZTogJ2l0ZW0nOyB0ZW1wSWQ6IHN0cmluZyB9IC8vIFBhcmEgbGEgdGFibGEgY29udGFibGUgKG9yaWdpbmFsKVxuICAgIHwgeyB0eXBlOiAncHJvZHVjdF9pdGVtJzsgdGVtcElkOiBzdHJpbmcgfTsgLy8gUGFyYSBsYSBudWV2YSB0YWJsYSBkZSBwcm9kdWN0b3NcblxuY29uc3QgYWRkRGF5cyA9IChkYXRlOiBEYXRlLCBkYXlzOiBudW1iZXIpOiBEYXRlID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRGF0ZShkYXRlKTtcbiAgICByZXN1bHQuc2V0RGF0ZShyZXN1bHQuZ2V0RGF0ZSgpICsgZGF5cyk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbmNvbnN0IGN1cnJlbnRNb250aFBhZGRlZCA9ICgpID0+IFN0cmluZyhuZXcgRGF0ZSgpLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xuY29uc3QgY3VycmVudFllYXIgPSAoKSA9PiBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCk7XG5cbmV4cG9ydCBjb25zdCBDb21wcmFzRm9ybVBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBtb2RlID0gaWQgPyAnZWRpdCcgOiAnY3JlYXRlJztcblxuICAgIC8vIOKchSBDT1JSRUNDScOTTjogVW5pZmljYW1vcyBsYSBsbGFtYWRhIGFsIGhvb2suIEFob3JhICdzYXZlSXRlbScgeSAnbG9hZGluZydcbiAgICAvLyBwcm92aWVuZW4gZGUgbGEgbWlzbWEgaW5zdGFuY2lhIHF1ZSB5YSBjb25vY2UgZWwgJ2lkJyBwYXJhIGVsIG1vZG8gZGUgZWRpY2nDs24uXG4gICAgY29uc3QgeyBpdGVtOiBpbml0aWFsUHVyY2hhc2UsIGxvYWRpbmc6IGxvYWRpbmdJbml0aWFsLCBsb2FkaW5nIH0gPSB1c2VDcnVkSXRlbTxQdXJjaGFzZT4oY29tcHJhc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IHsgc2hvd0NvbmZpcm1hdGlvbk1vZGFsIH0gPSB1c2VNb2RhbCgpO1xuXG4gICAgY29uc3QgW2hlYWRlciwgc2V0SGVhZGVyXSA9IHVzZVN0YXRlKHtcbiAgICAgICAgcHVyY2hhc2VfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgICAgIGR1ZV9kYXRlOiBmb3JtYXREYXRlRm9ySW5wdXQoYWRkRGF5cyhuZXcgRGF0ZSgpLCA3KSksXG4gICAgICAgIHNlcmllczogJ0InLFxuICAgICAgICB2ZW5kb3JfaWQ6IG51bGwgYXMgbnVtYmVyIHwgbnVsbCxcbiAgICAgICAgdmVuZG9yX2NvZGVfaW5wdXQ6ICcnLFxuICAgICAgICB2ZW5kb3JfbmFtZTogbnVsbCBhcyBzdHJpbmcgfCBudWxsLFxuICAgICAgICBjdXJyZW5jeV9pZDogbnVsbCBhcyBudW1iZXIgfCBudWxsLFxuICAgICAgICBjdXJyZW5jeV9jb2RlOiAnJyxcbiAgICAgICAgY3VycmVuY3lfbmFtZTogbnVsbCBhcyBzdHJpbmcgfCBudWxsLFxuICAgICAgICBkb2N1bWVudF9udW1iZXI6ICcnLFxuICAgICAgICBpbnRlcm5hbF92b3VjaGVyOiAnJyxcbiAgICAgICAgZGVsaXZlcnlfbm90ZTogJycsXG4gICAgICAgIHdpdGhvdXR0YXhfYW1vdW50OiAwLFxuICAgICAgICBkaXNjb3VudDogMCxcbiAgICAgICAgZXhjaGFuZ2VfcmF0ZTogMCxcbiAgICAgICAgaW1wdXRhdGlvbl9tb250aDogY3VycmVudE1vbnRoUGFkZGVkKCksXG4gICAgICAgIGltcHV0YXRpb25feWVhcjogY3VycmVudFllYXIoKSxcbiAgICB9KTtcbiAgICBjb25zdCBbdmVuZG9yVGF4ZXMsIHNldFZlbmRvclRheGVzXSA9IHVzZVN0YXRlPFZlbmRvclRheFtdPihbXSk7XG4gICAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZTxBY2NvdW50aW5nSXRlbVdpdGhJbnB1dFtdPihbXSk7IC8vIExpc3RhIGNvbnRhYmxlXG5cbiAgICBjb25zdCBbYXBwbGllZFRheGVzLCBzZXRBcHBsaWVkVGF4ZXNdID0gdXNlU3RhdGU8QXBwbGllZFRheFtdPihbXSk7XG4gICAgY29uc3QgW2lzU2luZ2xlVGF4QW1vdW50RWRpdGFibGUsIHNldElzU2luZ2xlVGF4QW1vdW50RWRpdGFibGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtwZXJjZXB0aW9uUm93cywgc2V0UGVyY2VwdGlvblJvd3NdID0gdXNlU3RhdGU8UGVyY2VwdGlvblJvd1tdPihbXSk7XG4gICAgY29uc3QgW3BlcmNlcHRpb25UYXhlcywgc2V0UGVyY2VwdGlvblRheGVzXSA9IHVzZVN0YXRlPFRheFtdPihbXSk7XG5cbiAgICBjb25zdCBbcHJvZHVjdEl0ZW1zLCBzZXRQcm9kdWN0SXRlbXNdID0gdXNlU3RhdGU8UHJvZHVjdFB1cmNoYXNlSXRlbVtdPihbXSk7XG4gICAgY29uc3QgW2lzRmV0Y2hpbmdNb3ZlbWVudHMsIHNldElzRmV0Y2hpbmdNb3ZlbWVudHNdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2VkaXRpbmdUYXJnZXQsIHNldEVkaXRpbmdUYXJnZXRdID0gdXNlU3RhdGU8RWRpdGluZ1RhcmdldCB8IG51bGw+KG51bGwpO1xuXG4gICAgY29uc3QgW2ludm9pY2VJbWFnZUZpbGUsIHNldEludm9pY2VJbWFnZUZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFttb2RhbENvbmZpZywgc2V0TW9kYWxDb25maWddID0gdXNlU3RhdGU8YW55PihudWxsKTtcbiAgICBjb25zdCBbaXNMb2FkaW5nRmlsZSwgc2V0SXNMb2FkaW5nRmlsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgaW5pdGlhbEl0ZW0xMDAzMDFMb2FkZWQgPSB1c2VSZWYoZmFsc2UpO1xuICAgIC8qKiBFbiBlZGljacOzbjogZXZpdGEgcmVjYWxjdWxhciBpbXB1ZXN0byBhbCBjYXJnYXI7IHNvbG8gcmVjYWxjdWxhIHNpIGNhbWJpYSBsYSBiYXNlIGltcG9uaWJsZS4gKi9cbiAgICBjb25zdCBza2lwSW5pdGlhbEVkaXRUYXhSZWNhbGNSZWYgPSB1c2VSZWYoISFpZCk7XG4gICAgY29uc3QgZWRpdFRheEJhc2VsaW5lUmVmID0gdXNlUmVmPHsgc3VidG90YWw6IG51bWJlcjsgZGlzY291bnQ6IG51bWJlcjsgd2l0aG91dHRheDogbnVtYmVyIH0gfCBudWxsPihudWxsKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChtb2RlID09PSAnZWRpdCcgJiYgaW5pdGlhbFB1cmNoYXNlKSB7XG4gICAgICAgICAgICBza2lwSW5pdGlhbEVkaXRUYXhSZWNhbGNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgICBlZGl0VGF4QmFzZWxpbmVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICBzZXRIZWFkZXIoe1xuICAgICAgICAgICAgICAgIHB1cmNoYXNlX2RhdGU6IGluaXRpYWxQdXJjaGFzZS5wdXJjaGFzZV9kYXRlLFxuICAgICAgICAgICAgICAgIGR1ZV9kYXRlOiBmb3JtYXREYXRlRm9ySW5wdXQobmV3IERhdGUoaW5pdGlhbFB1cmNoYXNlLmR1ZV9kYXRlKSksXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBpbml0aWFsUHVyY2hhc2Uuc2VyaWVzIHx8ICdCJyxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGluaXRpYWxQdXJjaGFzZS52ZW5kb3JfaWQsXG4gICAgICAgICAgICAgICAgdmVuZG9yX2NvZGVfaW5wdXQ6IGluaXRpYWxQdXJjaGFzZS52ZW5kb3I/LnZlbmRvcl9jb2RlIHx8ICcnLFxuICAgICAgICAgICAgICAgIHZlbmRvcl9uYW1lOiBpbml0aWFsUHVyY2hhc2UudmVuZG9yPy5uYW1lIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgY3VycmVuY3lfaWQ6IGluaXRpYWxQdXJjaGFzZS5jdXJyZW5jeV9pZCxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeV9jb2RlOiBpbml0aWFsUHVyY2hhc2UuY3VycmVuY3lfY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeV9uYW1lOiBpbml0aWFsUHVyY2hhc2UuY3VycmVuY3lfbmFtZSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIGRvY3VtZW50X251bWJlcjogaW5pdGlhbFB1cmNoYXNlLmRvY3VtZW50X251bWJlcixcbiAgICAgICAgICAgICAgICBpbnRlcm5hbF92b3VjaGVyOiBpbml0aWFsUHVyY2hhc2UuaW50ZXJuYWxfdm91Y2hlciB8fCAnJyxcbiAgICAgICAgICAgICAgICBkZWxpdmVyeV9ub3RlOiBpbml0aWFsUHVyY2hhc2UuZGVsaXZlcnlfbm90ZSB8fCAnJyxcbiAgICAgICAgICAgICAgICB3aXRob3V0dGF4X2Ftb3VudDogaW5pdGlhbFB1cmNoYXNlLndpdGhvdXR0YXhfYW1vdW50IHx8IDAsXG4gICAgICAgICAgICAgICAgZGlzY291bnQ6IGluaXRpYWxQdXJjaGFzZS5kaXNjb3VudCB8fCAwLFxuICAgICAgICAgICAgICAgIGV4Y2hhbmdlX3JhdGU6IGluaXRpYWxQdXJjaGFzZS5leGNoYW5nZV9yYXRlIHx8IDAsXG4gICAgICAgICAgICAgICAgaW1wdXRhdGlvbl9tb250aDogaW5pdGlhbFB1cmNoYXNlLmltcHV0YXRpb25fbW9udGggPz8gY3VycmVudE1vbnRoUGFkZGVkKCksXG4gICAgICAgICAgICAgICAgaW1wdXRhdGlvbl95ZWFyOiBpbml0aWFsUHVyY2hhc2UuaW1wdXRhdGlvbl95ZWFyID8/IGN1cnJlbnRZZWFyKCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNldEl0ZW1zKGluaXRpYWxQdXJjaGFzZS5pdGVtcy5tYXAoaSA9PiAoeyAuLi5pLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksIGNoYXJ0X2NvZGVfaW5wdXQ6IGkuY2hhcnRfYWNjb3VudF9jb2RlIH0pKSk7XG5cbiAgICAgICAgICAgIGNvbnN0IGxvYWRlZFByb2R1Y3RzID0gaW5pdGlhbFB1cmNoYXNlLnByb2R1Y3RzPy5tYXAoKHByb2QpOiBQcm9kdWN0UHVyY2hhc2VJdGVtID0+ICh7XG4gICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2QucHJvZHVjdF9pZCxcbiAgICAgICAgICAgICAgICBwcm9kdWN0X2NvZGU6IHByb2QucHJvZHVjdF9jb2RlIHx8ICcnLCAvLyBVc2Ftb3MgJ3Byb2R1Y3RfY29kZScgKFNLVSlcbiAgICAgICAgICAgICAgICBwcm9kdWN0X25hbWU6IHByb2QucHJvZHVjdF9uYW1lLFxuICAgICAgICAgICAgICAgIHF1YW50aXR5OiBOdW1iZXIocHJvZC5xdWFudGl0eSksXG4gICAgICAgICAgICAgICAgcHJpY2VfY29zdDogTnVtYmVyKHByb2QucHJpY2VfY29zdClcbiAgICAgICAgICAgIH0pKSB8fCBbXTtcbiAgICAgICAgICAgIHNldFByb2R1Y3RJdGVtcyhsb2FkZWRQcm9kdWN0cyk7XG4gICAgICAgICAgICAvLyDinIUgQ09SUkVDQ0nDk046IFNlIGFzZWd1cmEgZGUgY2FyZ2FyIGxvcyBpbXB1ZXN0b3MgZGVsIHByb3ZlZWRvciBhbCBlZGl0YXIuXG4gICAgICAgICAgICBjb25zdCBmZXRjaFZlbmRvclRheGVzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFByaW1lcm8sIHVzYW1vcyBsb3MgaW1wdWVzdG9zIHF1ZSB5YSB2aWVuZW4gZW4gZWwgb2JqZXRvLCBzaSBleGlzdGVuLlxuICAgICAgICAgICAgICAgICAgICBpZiAoaW5pdGlhbFB1cmNoYXNlLnZlbmRvcj8ucmVsYXRlZFRheGVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhmaWx0ZXJWZW5kb3JUYXhlc1R5cGVHZW5lcmFsKGluaXRpYWxQdXJjaGFzZS52ZW5kb3IucmVsYXRlZFRheGVzKSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTaSBubyB2aWVuZW4sIGxvcyBidXNjYW1vcyBleHBsw61jaXRhbWVudGUuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmdWxsVmVuZG9yID0gYXdhaXQgZ2V0QnlJZDxQcm92ZWVkb3IgJiB7IHJlbGF0ZWRUYXhlczogVmVuZG9yVGF4W10gfT4oJ3ZlbmRvcnMnLCBpbml0aWFsUHVyY2hhc2UudmVuZG9yX2lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZlbmRvclRheGVzKGZpbHRlclZlbmRvclRheGVzVHlwZUdlbmVyYWwoZnVsbFZlbmRvci5yZWxhdGVkVGF4ZXMgfHwgW10pKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggdmVuZG9yIHRheGVzIG9uIGVkaXQ6XCIsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJObyBzZSBwdWRpZXJvbiBjYXJnYXIgbG9zIGltcHVlc3RvcyBkZWwgcHJvdmVlZG9yIHBhcmEgbGEgZWRpY2nDs24uXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIGZldGNoVmVuZG9yVGF4ZXMoKTtcblxuICAgICAgICAgICAgLy8gYXBwbGllZF90YXhlcyB0cmFlIEltcHVlc3RvcyAodGF4X3R5cGUgMSkgeSBQZXJjZXBjaW9uZXMgKHRheF90eXBlIDIpXG4gICAgICAgICAgICBjb25zdCB0YXhlc1R5cGUxID0gKGluaXRpYWxQdXJjaGFzZS5hcHBsaWVkX3RheGVzIHx8IFtdKS5maWx0ZXIoKHQ6IEFwcGxpZWRUYXgpID0+IHQudGF4X3R5cGUgPT09IDEpO1xuICAgICAgICAgICAgY29uc3QgdGF4ZXNUeXBlMiA9IChpbml0aWFsUHVyY2hhc2UuYXBwbGllZF90YXhlcyB8fCBbXSkuZmlsdGVyKCh0OiBBcHBsaWVkVGF4KSA9PiB0LnRheF90eXBlID09PSAyKTtcbiAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyh0YXhlc1R5cGUxKTtcbiAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHRheGVzVHlwZTIubWFwKCh0OiBBcHBsaWVkVGF4KSA9PiAoe1xuICAgICAgICAgICAgICAgIHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICAgICAgICAgICAgICB0YXhfaWQ6IHQudGF4X2lkLFxuICAgICAgICAgICAgICAgIHRheF9uYW1lOiB0LnRheF9uYW1lID8/IHQudGF4Py5uYW1lID8/IG51bGwsXG4gICAgICAgICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpIHx8IDAsXG4gICAgICAgICAgICB9KSkpO1xuICAgICAgICB9XG4gICAgfSwgW21vZGUsIGluaXRpYWxQdXJjaGFzZV0pO1xuXG4gICAgLy8gQ2FyZ2FyIGltcHVlc3RvcyB0aXBvIDIgKFBlcmNlcGNpb25lcykgcGFyYSBlbCBzZWxlY3RvclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGdldEFsbDxUYXg+KCd0YXhlcycsIHsgdHlwZTogJzInIH0pXG4gICAgICAgICAgICAudGhlbihyZXMgPT4gc2V0UGVyY2VwdGlvblRheGVzKHJlcy5kYXRhIHx8IFtdKSlcbiAgICAgICAgICAgIC5jYXRjaCgoKSA9PiBzZXRQZXJjZXB0aW9uVGF4ZXMoW10pKTtcbiAgICB9LCBbXSk7XG5cbiAgICAvLyBQcmVjYXJnYXIgw610ZW0gY29uIGN1ZW50YSAxMDAzMDEgc29sbyBlbiBjcmVhY2nDs24gKHVuYSB2ZXopXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlkIHx8IGluaXRpYWxJdGVtMTAwMzAxTG9hZGVkLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgaWYgKGl0ZW1zLmxlbmd0aCA+IDApIHJldHVybjtcbiAgICAgICAgaW5pdGlhbEl0ZW0xMDAzMDFMb2FkZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHNlYXJjaDxQbGFuRGVDdWVudGFzPihgJHtwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLmVuZHBvaW50fT9jb2RlPTEwMDMwMWApXG4gICAgICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFjY291bnQgPSByZXNwb25zZS5kYXRhWzBdO1xuICAgICAgICAgICAgICAgICAgICBzZXRJdGVtcyhbe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGVnYWN5X2NoYXJ0X2FjY291bnRfY29kZTogYWNjb3VudC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYXJ0X2FjY291bnRfbmFtZTogYWNjb3VudC5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hhcnRfY29kZV9pbnB1dDogJzEwMDMwMScsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogMCxcbiAgICAgICAgICAgICAgICAgICAgfV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgICAgICAgIGluaXRpYWxJdGVtMTAwMzAxTG9hZGVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtpZCwgaXRlbXMubGVuZ3RoXSk7XG5cbiAgICAvLyDinIUgUEFTTyAxOiBDYWxjdWxhbW9zIGVsIHN1YnRvdGFsIGRlIGZvcm1hIGluZGVwZW5kaWVudGVcbiAgICBjb25zdCBzdWJ0b3RhbCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICByZXR1cm4gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS52YWx1ZSkgfHwgMCksIDApO1xuICAgIH0sIFtpdGVtc10pO1xuXG4gICAgLy8gRWZlY3RvIEE6IGVuIGNyZWFjacOzbiwgdmFjw61hIG8gaW5pY2lhbGl6YSBmaWxhcyBkZSBpbXB1ZXN0by4gQ29uIHZhcmlvcyBpbXB1ZXN0b3MsIGZpbGFzIGVuIDAgcGFyYSBlZGljacOzbiBtYW51YWwuXG4gICAgLy8gRW4gZWRpY2nDs24gbm8gY29ycmU6IG5vIHBpc2Ftb3MgYXBwbGllZFRheGVzICh2YWxvcmVzIGRlbCBzZXJ2aWRvciBvIGFqdXN0ZXMgZGVsIHVzdWFyaW8pLlxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpZCkgcmV0dXJuO1xuICAgICAgICBpZiAodmVuZG9yVGF4ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2ZW5kb3JUYXhlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXModmVuZG9yVGF4ZXMubWFwKHQgPT4gKHtcbiAgICAgICAgICAgICAgICB0YXhfaWQ6IHQuaWQsXG4gICAgICAgICAgICAgICAgdGF4X25hbWU6IHQubmFtZSxcbiAgICAgICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICAgICAgYW1vdW50OiAwLFxuICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgfVxuICAgIH0sIFtpZCwgdmVuZG9yVGF4ZXNdKTtcblxuICAgIC8vIEVmZWN0byBCOiBjb24gdW4gw7puaWNvIGltcHVlc3RvLCByZWNhbGN1bGEgYWwgdmFyaWFyIHN1YnRvdGFsL2Rlc2N1ZW50by9ubyBncmF2YWRvLlxuICAgIC8vIEVuIGVkaWNpw7NuOiBubyByZWNhbGN1bGEgYWwgaGlkcmF0YXIgKGNvbnNlcnZhIGFwcGxpZWRfdGF4ZXMgZGVsIHNlcnZpZG9yKTsgc8OtIHNpIGVsIHVzdWFyaW8gY2FtYmlhIGxhIGJhc2UuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHZlbmRvclRheGVzLmxlbmd0aCAhPT0gMSB8fCBpc1NpbmdsZVRheEFtb3VudEVkaXRhYmxlKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgaW5wdXRzID0ge1xuICAgICAgICAgICAgc3VidG90YWwsXG4gICAgICAgICAgICBkaXNjb3VudDogaGVhZGVyLmRpc2NvdW50IHx8IDAsXG4gICAgICAgICAgICB3aXRob3V0dGF4OiBoZWFkZXIud2l0aG91dHRheF9hbW91bnQgfHwgMCxcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoaWQpIHtcbiAgICAgICAgICAgIGlmIChza2lwSW5pdGlhbEVkaXRUYXhSZWNhbGNSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIHNraXBJbml0aWFsRWRpdFRheFJlY2FsY1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgZWRpdFRheEJhc2VsaW5lUmVmLmN1cnJlbnQgPSBpbnB1dHM7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGVkaXRUYXhCYXNlbGluZVJlZi5jdXJyZW50ICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcHJldiA9IGVkaXRUYXhCYXNlbGluZVJlZi5jdXJyZW50O1xuICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgcHJldi5zdWJ0b3RhbCA9PT0gaW5wdXRzLnN1YnRvdGFsICYmXG4gICAgICAgICAgICAgICAgICAgIHByZXYuZGlzY291bnQgPT09IGlucHV0cy5kaXNjb3VudCAmJlxuICAgICAgICAgICAgICAgICAgICBwcmV2LndpdGhvdXR0YXggPT09IGlucHV0cy53aXRob3V0dGF4XG4gICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlZGl0VGF4QmFzZWxpbmVSZWYuY3VycmVudCA9IGlucHV0cztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHRheEJhc2UgPSBpbnB1dHMuc3VidG90YWwgLSBpbnB1dHMuZGlzY291bnQ7XG4gICAgICAgIGNvbnN0IGNhbGN1bGF0ZWRUYXhlcyA9IHZlbmRvclRheGVzLm1hcCh0YXggPT4gKHtcbiAgICAgICAgICAgIHRheF9pZDogdGF4LmlkLFxuICAgICAgICAgICAgdGF4X25hbWU6IHRheC5uYW1lLFxuICAgICAgICAgICAgcmF0ZTogdGF4LnJhdGUsXG4gICAgICAgICAgICBhbW91bnQ6IHRheEJhc2UgKiAodGF4LnJhdGUgLyAxMDApLFxuICAgICAgICB9KSk7XG4gICAgICAgIHNldEFwcGxpZWRUYXhlcyhjYWxjdWxhdGVkVGF4ZXMpO1xuICAgIH0sIFtpZCwgc3VidG90YWwsIGhlYWRlci5kaXNjb3VudCwgaGVhZGVyLndpdGhvdXR0YXhfYW1vdW50LCB2ZW5kb3JUYXhlcywgaXNTaW5nbGVUYXhBbW91bnRFZGl0YWJsZV0pO1xuXG5cbiAgICBjb25zdCB0b3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3QgdGF4VG90YWwgPSBhcHBsaWVkVGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgKE51bWJlcih0YXguYW1vdW50KSB8fCAwKSwgMCk7XG4gICAgICAgIGNvbnN0IHBlcmNlcGNpb25lc1RvdGFsID0gcGVyY2VwdGlvblJvd3MucmVkdWNlKChzdW0sIHIpID0+IHN1bSArIChOdW1iZXIoci5hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3Qgd2l0aG91dHRheCA9IGhlYWRlci53aXRob3V0dGF4X2Ftb3VudCB8fCAwO1xuICAgICAgICBjb25zdCBncmFuZFRvdGFsID0gc3VidG90YWwgLSAoaGVhZGVyLmRpc2NvdW50IHx8IDApICsgd2l0aG91dHRheCArIHRheFRvdGFsICsgcGVyY2VwY2lvbmVzVG90YWw7XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0YXhUb3RhbCwgcGVyY2VwY2lvbmVzVG90YWwsIGdyYW5kVG90YWwgfTtcbiAgICB9LCBbc3VidG90YWwsIGFwcGxpZWRUYXhlcywgcGVyY2VwdGlvblJvd3MsIGhlYWRlci5kaXNjb3VudCwgaGVhZGVyLndpdGhvdXR0YXhfYW1vdW50XSk7XG5cbiAgICBjb25zdCBoYW5kbGVIZWFkZXJDaGFuZ2UgPSAoZmllbGQ6IGtleW9mIHR5cGVvZiBoZWFkZXIsIHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgc2V0SGVhZGVyKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZXF1ZXN0RWRpdFNpbmdsZVRheCA9ICgpID0+IHtcbiAgICAgICAgc2hvd0NvbmZpcm1hdGlvbk1vZGFsKHtcbiAgICAgICAgICAgIHRpdGxlOiAnTW9kaWZpY2FyIGltcG9ydGUgZGUgaW1wdWVzdG8nLFxuICAgICAgICAgICAgbWVzc2FnZTogJ8K/RGVzZWEgZWRpdGFyIG1hbnVhbG1lbnRlIGVsIGltcG9ydGUgZGVsIGltcHVlc3RvPyBEZWphcsOhIGRlIGFjdHVhbGl6YXJzZSBhdXRvbcOhdGljYW1lbnRlIGFsIGNhbWJpYXIgc3VidG90YWxlcywgZGVzY3VlbnRvcyBvIHZhbG9yIG5vIGdyYXZhZG8uJyxcbiAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4gc2V0SXNTaW5nbGVUYXhBbW91bnRFZGl0YWJsZSh0cnVlKSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdFZlbmRvciA9IGFzeW5jICh2ZW5kb3I6IFByb3ZlZWRvcikgPT4ge1xuICAgICAgICBzZXRJc1NpbmdsZVRheEFtb3VudEVkaXRhYmxlKGZhbHNlKTtcbiAgICAgICAgc2tpcEluaXRpYWxFZGl0VGF4UmVjYWxjUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgZWRpdFRheEJhc2VsaW5lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRIZWFkZXIoe1xuICAgICAgICAgICAgLi4uaGVhZGVyLFxuICAgICAgICAgICAgdmVuZG9yX2lkOiB2ZW5kb3IuaWQsXG4gICAgICAgICAgICB2ZW5kb3JfbmFtZTogdmVuZG9yLm5hbWUsXG4gICAgICAgICAgICB2ZW5kb3JfY29kZV9pbnB1dDogdmVuZG9yLnZlbmRvcl9jb2RlIHx8ICcnLFxuICAgICAgICB9KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxWZW5kb3IgPSBhd2FpdCBnZXRCeUlkPFByb3ZlZWRvciAmIHsgdGF4ZXM6IFZlbmRvclRheFtdIH0+KCd2ZW5kb3JzJywgdmVuZG9yLmlkKTtcbiAgICAgICAgICAgIHNldFZlbmRvclRheGVzKGZpbHRlclZlbmRvclRheGVzVHlwZUdlbmVyYWwoZnVsbFZlbmRvci50YXhlcyB8fCBbXSkpO1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgIGNvbnN0IGRheXMgPSBOdW1iZXIoZnVsbFZlbmRvci5wYXltZW50X2NvbmRpdGlvbikgfHwgMDtcbiAgICAgICAgICAgIHNldEhlYWRlcihwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICBkdWVfZGF0ZTogZm9ybWF0RGF0ZUZvcklucHV0KGFkZERheXMobmV3IERhdGUoKSwgZGF5cykpLFxuICAgICAgICAgICAgICAgIHNlcmllczogZnVsbFZlbmRvci5zZXJpZSA/PyBwcmV2LnNlcmllcyA/PyAnQicsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZGllcm9uIGNhcmdhciBsb3MgaW1wdWVzdG9zIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0Q3VycmVuY3kgPSBhc3luYyAoY3VycmVuY3k6IE1vbmVkYSkgPT4ge1xuICAgICAgICBzZXRIZWFkZXIoe1xuICAgICAgICAgICAgLi4uaGVhZGVyLCBjdXJyZW5jeV9pZDogY3VycmVuY3kuaWQsXG4gICAgICAgICAgICBjdXJyZW5jeV9uYW1lOiBjdXJyZW5jeS5uYW1lLFxuICAgICAgICAgICAgY3VycmVuY3lfY29kZTogY3VycmVuY3kuY29kZSxcbiAgICAgICAgICAgIGV4Y2hhbmdlX3JhdGU6IE51bWJlcihjdXJyZW5jeS5leGNoYW5nZV9yYXRlKSB8fCAwXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVWZW5kb3JDb2RlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb2RlID0gaGVhZGVyLnZlbmRvcl9jb2RlX2lucHV0O1xuICAgICAgICBpZiAoIWNvZGUpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oJ0luZ3Jlc2UgdW4gY8OzZGlnbyBkZSBwcm92ZWVkb3IgcGFyYSBidXNjYXIuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIEFzdW1pbW9zIHF1ZSBsYSBBUEkgcHVlZGUgYnVzY2FyIHBvciAnY29kZScuIEFqdXN0YSAnY29kZT0ke2NvZGV9JyBzaSBlbCBwYXJhbSBlcyBvdHJvLlxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8UHJvdmVlZG9yPihgJHtwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZy5lbmRwb2ludH0/dmVuZG9yX2NvZGU9JHtjb2RlfWApO1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGhhbmRsZVNlbGVjdFZlbmRvcihyZXNwb25zZS5kYXRhWzBdKTsgLy8gVXNhbW9zIGVsIHByaW1lciByZXN1bHRhZG9cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1Byb3ZlZWRvciBubyBlbmNvbnRyYWRvIGNvbiBlc2UgY8OzZGlnby4nKTtcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXIocHJldiA9PiAoeyAuLi5wcmV2LCB2ZW5kb3JfaWQ6IG51bGwsIHZlbmRvcl9uYW1lOiBudWxsIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvdmVlZG9yLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUN1cnJlbmN5Q29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY29kZSA9IGhlYWRlci5jdXJyZW5jeV9jb2RlO1xuICAgICAgICBpZiAoIWNvZGUpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oJ0luZ3Jlc2UgdW4gY8OzZGlnbyBkZSBtb25lZGEgcGFyYSBidXNjYXIuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIEFzdW1pbW9zIHF1ZSBsYSBBUEkgcHVlZGUgYnVzY2FyIHBvciAnY29kZScuIEFqdXN0YSAnY29kZT0ke2NvZGV9JyBzaSBlbCBwYXJhbSBlcyBvdHJvLlxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8TW9uZWRhPihgJHttb25lZGFzTW9kdWxlQ29uZmlnLmVuZHBvaW50fT9jb2RlPSR7Y29kZX1gKTtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVTZWxlY3RDdXJyZW5jeShyZXNwb25zZS5kYXRhWzBdKTsgLy8gVXNhbW9zIGVsIHByaW1lciByZXN1bHRhZG9cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ01vbmVkYSBubyBlbmNvbnRyYWRhIGNvbiBlc2UgY8OzZGlnby4nKTtcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXIocHJldiA9PiAoeyAuLi5wcmV2LCB2ZW5kb3JfaWQ6IG51bGwsIHZlbmRvcl9uYW1lOiBudWxsIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvdmVlZG9yLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSA1LiBIYW5kbGVycyBwYXJhIGxhIExJU1RBIENPTlRBQkxFIChsb3MgJ2l0ZW1zJyBvcmlnaW5hbGVzKVxuICAgIGNvbnN0IGhhbmRsZUFkZEl0ZW0gPSAoKSA9PiBzZXRJdGVtcyhwcmV2ID0+IFsuLi5wcmV2LCB7IHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSwgbGVnYWN5X2NoYXJ0X2FjY291bnRfY29kZTogbnVsbCwgdmFsdWU6IDAgfV0pO1xuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUl0ZW0gPSAodGVtcElkOiBzdHJpbmcpID0+IHNldEl0ZW1zKHByZXYgPT4gcHJldi5maWx0ZXIoaSA9PiBpLnRlbXBJZCAhPT0gdGVtcElkKSk7XG4gICAgY29uc3QgaGFuZGxlVXBkYXRlSXRlbSA9ICh0ZW1wSWQ6IHN0cmluZywgZmllbGQ6IGtleW9mIEFjY291bnRpbmdJdGVtV2l0aElucHV0LCB2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaSA9PiBpLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5pLCBbZmllbGRdOiB2YWx1ZSB9IDogaSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBY2NvdW50Q29kZVN1Ym1pdCA9IGFzeW5jICh0ZW1wSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0gaXRlbXMuZmluZChpID0+IGkudGVtcElkID09PSB0ZW1wSWQpO1xuICAgICAgICBjb25zdCBjb2RlID0gaXRlbT8uY2hhcnRfY29kZV9pbnB1dDtcbiAgICAgICAgaWYgKCFjb2RlKSByZXR1cm4gdG9hc3QuaW5mbygnSW5ncmVzZSB1biBjw7NkaWdvIGRlIGN1ZW50YSBwYXJhIGJ1c2Nhci4nKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgc2VhcmNoPFBsYW5EZUN1ZW50YXMgJiB7IGNvZGU/OiBzdHJpbmcgfT4oYCR7cGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZy5lbmRwb2ludH0/Y29kZT0ke2NvZGV9YCk7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYWNjb3VudCA9IHJlc3BvbnNlLmRhdGFbMF07XG4gICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlSXRlbSh0ZW1wSWQsICdsZWdhY3lfY2hhcnRfYWNjb3VudF9jb2RlJywgYWNjb3VudC5pZCk7XG4gICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlSXRlbSh0ZW1wSWQsICdjaGFydF9hY2NvdW50X25hbWUnLCBhY2NvdW50Lm5hbWUpO1xuICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0odGVtcElkLCAnY2hhcnRfY29kZV9pbnB1dCcsIGFjY291bnQuY29kZSB8fCBTdHJpbmcoYWNjb3VudC5pZCkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignQ3VlbnRhIG5vIGVuY29udHJhZGEgY29uIGVzZSBjw7NkaWdvLicpO1xuICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0odGVtcElkLCAnbGVnYWN5X2NoYXJ0X2FjY291bnRfY29kZScsIG51bGwpO1xuICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0odGVtcElkLCAnY2hhcnRfYWNjb3VudF9uYW1lJywgJycpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikgeyB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIGxhIGN1ZW50YSBjb250YWJsZS4nKTsgY29uc29sZS5lcnJvcihlcnJvcik7IH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRmV0Y2hTdG9ja01vdmVtZW50cyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy9EZWphIGRlIHNlciBvYmxpZ2F0b3JpbyBlbCByZW1pdG9cbiAgICAgICAgLypcbiAgICAgICAgaWYgKCFoZWFkZXIuZGVsaXZlcnlfbm90ZSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbygnUG9yIGZhdm9yLCBpbmdyZXNlIHVuIG7Dum1lcm8gZGUgcmVtaXRvIHBhcmEgYnVzY2FyLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgICovXG4gICAgICAgIGlmICghaGVhZGVyLnZlbmRvcl9pZCkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbygnU2VsZWNjaW9uZSB1biBwcm92ZWVkb3IgYW50ZXMgZGUgYnVzY2FyIHBvciByZW1pdG8uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNGZXRjaGluZ01vdmVtZW50cyh0cnVlKTtcbiAgICAgICAgc2V0UHJvZHVjdEl0ZW1zKFtdKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYHN0b2NrLW1vdmVtZW50cz9kZWxpdmVyeV9ub3RlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGhlYWRlci5kZWxpdmVyeV9ub3RlKX0mdmVuZG9yX2lkPSR7aGVhZGVyLnZlbmRvcl9pZH1gO1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8YW55PihlbmRwb2ludCk7XG4gICAgICAgICAgICBjb25zdCBsaXN0ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZT8uZGF0YSkgPyByZXNwb25zZS5kYXRhIDogKEFycmF5LmlzQXJyYXkocmVzcG9uc2UpID8gcmVzcG9uc2UgOiBbXSk7XG4gICAgICAgICAgICBpZiAobGlzdC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5pbmZvKCdObyBzZSBlbmNvbnRyYXJvbiBtb3ZpbWllbnRvcyBkZSBzdG9jayBwYXJhIGVzZSByZW1pdG8geSBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICAgICAgc2V0SXNGZXRjaGluZ01vdmVtZW50cyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0b2FzdC5pbmZvKGBDYXJnYW5kbyAke2xpc3QubGVuZ3RofSBwcm9kdWN0b3MgZGVsIHJlbWl0by4uLmApO1xuXG4gICAgICAgICAgICBjb25zdCBuZXdQcm9kdWN0SXRlbXM6IFByb2R1Y3RQdXJjaGFzZUl0ZW1bXSA9IFtdO1xuXG4gICAgICAgICAgICBmb3IgKGNvbnN0IG1vdmVtZW50IG9mIGxpc3QpIHtcbiAgICAgICAgICAgICAgICBsZXQgY29zdCA9IDA7XG4gICAgICAgICAgICAgICAgbGV0IHByb2R1Y3RJZCA9IG51bGw7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2t1ID0gbW92ZW1lbnQuc2t1ID8/IG1vdmVtZW50LnByb2R1Y3RfY29kZSA/PyAnJztcbiAgICAgICAgICAgICAgICBpZiAoc2t1KSB7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9kUmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8QXJ0aWN1bG8+KGAke2FydGljdWxvc01vZHVsZUNvbmZpZy5lbmRwb2ludH0/c2t1PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNrdSl9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9kTGlzdCA9IEFycmF5LmlzQXJyYXkocHJvZFJlc3BvbnNlPy5kYXRhKSA/IHByb2RSZXNwb25zZS5kYXRhIDogKEFycmF5LmlzQXJyYXkocHJvZFJlc3BvbnNlKSA/IHByb2RSZXNwb25zZSA6IFtdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9kTGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29zdCA9IE51bWJlcihwcm9kTGlzdFswXS5jb3N0X3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RJZCA9IHByb2RMaXN0WzBdLmlkO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7IGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb3N0X3ByaWNlXCIsIGUpOyB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgbmV3UHJvZHVjdEl0ZW1zLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9jb2RlOiBza3UsXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogbW92ZW1lbnQucHJvZHVjdF9uYW1lID8/IG1vdmVtZW50Lm5hbWUgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgcXVhbnRpdHk6IE51bWJlcihtb3ZlbWVudC5xdWFudGl0eSkgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgcHJpY2VfY29zdDogY29zdCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNldFByb2R1Y3RJdGVtcyhuZXdQcm9kdWN0SXRlbXMpO1xuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByb2R1Y3RzVG90YWwgPSBuZXdQcm9kdWN0SXRlbXMucmVkdWNlKChzdW0sIHApID0+IHN1bSArIChOdW1iZXIocC5xdWFudGl0eSkgfHwgMCkgKiAoTnVtYmVyKHAucHJpY2VfY29zdCkgfHwgMCksIDApO1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKChwcmV2KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlkeCA9IHByZXYuZmluZEluZGV4KChpKSA9PiAoaSBhcyBBY2NvdW50aW5nSXRlbVdpdGhJbnB1dCkuY2hhcnRfY29kZV9pbnB1dCA9PT0gJzEwMDMwMScpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaWR4ID09PSAtMSkgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwcmV2Lm1hcCgoaXRlbSwgaSkgPT4gKGkgPT09IGlkeCA/IHsgLi4uaXRlbSwgdmFsdWU6IHByb2R1Y3RzVG90YWwgfSA6IGl0ZW0pKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWN0dWFsaXphbmRvIMOtdGVtIDEwMDMwMTpcIiwgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIGxvcyBtb3ZpbWllbnRvcyBkZSBzdG9jay4nKTtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNGZXRjaGluZ01vdmVtZW50cyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gNC4gTlVFVk8gSEFORExFUiBQQVJBIEVMIEFSQ0hJVk9cbiAgICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGlmIChlLnRhcmdldC5maWxlcyAmJiBlLnRhcmdldC5maWxlc1swXSkge1xuICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgICAgICAgICAgY29uc3QgYWxsb3dlZFR5cGVzID0gWydpbWFnZS9qcGVnJywgJ2ltYWdlL3BuZycsICdhcHBsaWNhdGlvbi9wZGYnLCAnaW1hZ2UvanBnJ107XG4gICAgICAgICAgICBjb25zdCBtYXhTaXplID0gNTEyMCAqIDEwMjQ7IC8vIDVNQiAoY29tbyBkZWZpbmlzdGUgZW4gTGFyYXZlbClcblxuICAgICAgICAgICAgLy8gVmFsaWRhbW9zIHRpcG9cbiAgICAgICAgICAgIGlmICghYWxsb3dlZFR5cGVzLmluY2x1ZGVzKGZpbGUudHlwZSkpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignVGlwbyBkZSBhcmNoaXZvIG5vIHBlcm1pdGlkby4gU29sbyBKUEcsIEpQRUcsIFBORyBvIFBERi4nKTtcbiAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9ICcnOyAvLyBMaW1waWFtb3MgZWwgaW5wdXRcbiAgICAgICAgICAgICAgICBzZXRJbnZvaWNlSW1hZ2VGaWxlKG51bGwpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gVmFsaWRhbW9zIHRhbWHDsW9cbiAgICAgICAgICAgIGlmIChmaWxlLnNpemUgPiBtYXhTaXplKSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIGFyY2hpdm8gZXhjZWRlIGVsIHRhbWHDsW8gbcOheGltbyBkZSA1TUIuJyk7XG4gICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPSAnJzsgLy8gTGltcGlhbW9zIGVsIGlucHV0XG4gICAgICAgICAgICAgICAgc2V0SW52b2ljZUltYWdlRmlsZShudWxsKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldEludm9pY2VJbWFnZUZpbGUoZmlsZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRJbnZvaWNlSW1hZ2VGaWxlKG51bGwpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSBIYW5kbGVyIHBhcmEgYWJyaXIgZWwgYXJjaGl2byBhZGp1bnRvXG4gICAgY29uc3QgaGFuZGxlVmlld0ZpbGUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghaW5pdGlhbFB1cmNoYXNlPy5pZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBhcmNoaXZvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNMb2FkaW5nRmlsZSh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9wdXJjaGFzZXMvJHtpbml0aWFsUHVyY2hhc2UuaWR9L2ZpbGVgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIG9idGVuZXIgZWwgYXJjaGl2bzpcIiwgZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gYWJyaXIgZWwgYXJjaGl2byBhZGp1bnRvLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNMb2FkaW5nRmlsZShmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFoZWFkZXIudmVuZG9yX2lkIHx8ICFoZWFkZXIuZG9jdW1lbnRfbnVtYmVyIC8qfHwgIWhlYWRlci5kZWxpdmVyeV9ub3RlKi8gfHwgIWhlYWRlci5jdXJyZW5jeV9pZCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJQcm92ZWVkb3IsIE7CuiBkZSBGYWN0dXJhLCBSZW1pdG8geSBNb25lZGEgc29uIG9ibGlnYXRvcmlvcy5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFoZWFkZXIuc2VyaWVzKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkxhIHNlcmllIGVzIG9ibGlnYXRvcmlhLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXRlbXMubGVuZ3RoID09PSAwIHx8IGl0ZW1zLnNvbWUoaSA9PiAhaS5sZWdhY3lfY2hhcnRfYWNjb3VudF9jb2RlIHx8IGkudmFsdWUgPD0gMCkpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRGViZSBhw7FhZGlyIGFsIG1lbm9zIHVuIMOtdGVtIGNvbiBjdWVudGEgY29udGFibGUgeSB2YWxvciB2w6FsaWRvLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOKchSBOVUVWQSBWQUxJREFDScOTTjogdG90YWwgZGUgcHJvZHVjdG9zIHZzIHRvdGFsIGRlIMOtdGVtcyBjb250YWJsZXNcbiAgICAgICAgY29uc3QgcHJvZHVjdHNUb3RhbCA9IHByb2R1Y3RJdGVtcy5yZWR1Y2UoKHN1bSwgcCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcXR5ID0gTnVtYmVyKHAucXVhbnRpdHkpIHx8IDA7XG4gICAgICAgICAgICBjb25zdCBjb3N0ID0gTnVtYmVyKHAucHJpY2VfY29zdCkgfHwgMDtcbiAgICAgICAgICAgIHJldHVybiBzdW0gKyBxdHkgKiBjb3N0O1xuICAgICAgICB9LCAwKTtcblxuICAgICAgICBjb25zdCBpdGVtc1RvdGFsID0gc3VidG90YWw7IC8vIG8gdG90YWxzLnN1YnRvdGFsLCBlcyBlbCBtaXNtbyB2YWxvclxuXG4gICAgICAgIC8vIFNvbG8gdmFsaWRhbW9zIHNpIGhheSBhbCBtZW5vcyB1biBwcm9kdWN0byBjYXJnYWRvXG4gICAgICAgIGlmIChwcm9kdWN0SXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgcHJvZFJvdW5kZWQgPSBNYXRoLnJvdW5kKHByb2R1Y3RzVG90YWwgKiAxMDApO1xuICAgICAgICAgICAgY29uc3QgaXRlbXNSb3VuZGVkID0gTWF0aC5yb3VuZChpdGVtc1RvdGFsICogMTAwKTtcblxuICAgICAgICAgICAgaWYgKHByb2RSb3VuZGVkICE9PSBpdGVtc1JvdW5kZWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihcbiAgICAgICAgICAgICAgICAgICAgXCJFbCB0b3RhbCBkZSBwcm9kdWN0b3MgZGViZSBzZXIgaWd1YWwgYWwgdG90YWwgZGUgbG9zIMOtdGVtcyBjb250YWJsZXMuIFwiICtcbiAgICAgICAgICAgICAgICAgICAgYFRvdGFsIHByb2R1Y3RvczogJHtmb3JtYXRWYWx1ZShwcm9kdWN0c1RvdGFsLCAnY3VycmVuY3knKX0gLSBgICtcbiAgICAgICAgICAgICAgICAgICAgYFRvdGFsIMOtdGVtczogJHtmb3JtYXRWYWx1ZShpdGVtc1RvdGFsLCAnY3VycmVuY3knKX1gXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjbGVhbkl0ZW1zID0gaXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgeyB0ZW1wSWQsIGNoYXJ0X2FjY291bnRfbmFtZSwgLi4ucmVzdCB9ID0gaXRlbTtcbiAgICAgICAgICAgIGlmICh0ZW1wSWQgPT09IHVuZGVmaW5lZCkgY29uc29sZS5sb2coJ0lnbm9yaW5nIHRlbXBJZCcpO1xuICAgICAgICAgICAgaWYgKGNoYXJ0X2FjY291bnRfbmFtZSA9PT0gdW5kZWZpbmVkKSBjb25zb2xlLmxvZygnSWdub3JpbmcgY2hhcnRfYWNjb3VudF9uYW1lJyk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnJlc3QsXG4gICAgICAgICAgICAgICAgaXRlbV9udW1iZXI6IGluZGV4ICsgMSwgLy8gQWRkIHRoZSBpdGVtX251bWJlciBiYXNlZCBvbiBpbmRleFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgdGF4ZXNUeXBlMSA9IGFwcGxpZWRUYXhlc1xuICAgICAgICAgICAgLmZpbHRlcih0YXggPT4gdGF4LmFtb3VudCA+IDApXG4gICAgICAgICAgICAubWFwKHRheCA9PiAoeyB0YXhfaWQ6IHRheC50YXhfaWQsIGFtb3VudDogdGF4LmFtb3VudCwgcmF0ZTogdGF4LnJhdGUsIHRheF90eXBlOiAxIGFzIGNvbnN0IH0pKTtcbiAgICAgICAgY29uc3QgdGF4ZXNUeXBlMiA9IHBlcmNlcHRpb25Sb3dzXG4gICAgICAgICAgICAuZmlsdGVyKHIgPT4gci50YXhfaWQgIT0gbnVsbCAmJiByLmFtb3VudCA+IDApXG4gICAgICAgICAgICAubWFwKHIgPT4gKHsgdGF4X2lkOiByLnRheF9pZCEsIGFtb3VudDogci5hbW91bnQsIHJhdGU6IDAsIHRheF90eXBlOiAyIGFzIGNvbnN0IH0pKTtcbiAgICAgICAgY29uc3QgY2xlYW5UYXhlcyA9IFsuLi50YXhlc1R5cGUxLCAuLi50YXhlc1R5cGUyXTtcblxuICAgICAgICAvLyDinIUgTlVFVk86IExpbXBpYW1vcyBsYSBsaXN0YSBkZSBwcm9kdWN0b3MgcGFyYSBlbnZpYXJsYVxuICAgICAgICBjb25zdCBjbGVhblByb2R1Y3RzID0gcHJvZHVjdEl0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgIC8vIExpbXBpYW1vcyBsb3MgY2FtcG9zIHRlbXBvcmFsZXMgZGUgVUkgKHRlbXBJZClcbiAgICAgICAgICAgIGNvbnN0IHsgdGVtcElkLCAuLi5yZXN0IH0gPSBpdGVtO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGl0ZW1fbnVtYmVyOiBpbmRleCArIDEsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICAgICAgLi4uaGVhZGVyLFxuICAgICAgICAgICAgaXRlbXM6IGNsZWFuSXRlbXMsXG4gICAgICAgICAgICB0YXhlczogY2xlYW5UYXhlcyxcbiAgICAgICAgICAgIHByb2R1Y3RzOiBjbGVhblByb2R1Y3RzLFxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiB0b3RhbHMuZ3JhbmRUb3RhbCxcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RhdGEnLCBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG5cbiAgICAgICAgaWYgKGludm9pY2VJbWFnZUZpbGUpIHtcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW52b2ljZV9pbWFnZScsIGludm9pY2VJbWFnZUZpbGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gNS4gVXNhbW9zICdhcGlTZXJ2aWNlLmNyZWF0ZScgbyAnYXBpU2VydmljZS51cGRhdGUnIHF1ZSBtYW5lamFuIEZvcm1EYXRhXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAobW9kZSA9PT0gJ2NyZWF0ZScpIHtcbiAgICAgICAgICAgICAgICAvLyBZYSBubyB1c2Ftb3MgY3JlYXRlSXRlbShwYXlsb2FkKVxuICAgICAgICAgICAgICAgIGF3YWl0IGNyZWF0ZTxGb3JtRGF0YT4oY29tcHJhc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgZm9ybURhdGEpO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0NvbXByYSBjcmVhZGEgY29uIMOpeGl0bycpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBZYSBubyB1c2Ftb3MgdXBkYXRlSXRlbShpZCEsIHBheWxvYWQpXG4gICAgICAgICAgICAgICAgLy8gTm90YTogRWwgYXBpU2VydmljZS51cGRhdGUgZGViZSBtYW5lamFyICdtdWx0aXBhcnQnIHkgZWwgbcOpdG9kbyBQVVQvUEFUQ0guXG4gICAgICAgICAgICAgICAgLy8gU2kgdXNhIFBPU1QgcGFyYSBzaW11bGFyIFBVVCwgcXVpesOhcyBuZWNlc2l0ZSBmb3JtRGF0YS5hcHBlbmQoJ19tZXRob2QnLCAnUFVUJyk7XG4gICAgICAgICAgICAgICAgLy8gQXN1bW8gcXVlIG51ZXN0cm8gJ3VwZGF0ZScgc2VydmljZSB5YSBsbyBtYW5lamEgY29ycmVjdGFtZW50ZS5cbiAgICAgICAgICAgICAgICBhd2FpdCB1cGRhdGU8Rm9ybURhdGE+KGNvbXByYXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGlkISwgZm9ybURhdGEpO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0NvbXByYSBhY3R1YWxpemFkYSBjb24gw6l4aXRvJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChjb21wcmFzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgICAgICAvLyAuLi4gKG1hbmVqbyBkZSBlcnJvciBzaW4gY2FtYmlvcylcbiAgICAgICAgICAgIGNvbnN0IGVycm9yTXNnID0gZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgZXJyb3IubWVzc2FnZSB8fCAnRXJyb3IgYWwgZ3VhcmRhciBsYSBjb21wcmEnO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoZXJyb3JNc2cpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9wZW5Nb2RhbCA9ICh0YXJnZXQ6IEVkaXRpbmdUYXJnZXQsIGNvbmZpZzogYW55KSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdUYXJnZXQodGFyZ2V0KTtcbiAgICAgICAgY29uc3QgaXNQcm9kdWN0SXRlbSA9IHR5cGVvZiB0YXJnZXQgPT09ICdvYmplY3QnICYmIHRhcmdldD8udHlwZSA9PT0gJ3Byb2R1Y3RfaXRlbSc7XG4gICAgICAgIHNldE1vZGFsQ29uZmlnKGlzUHJvZHVjdEl0ZW1cbiAgICAgICAgICAgID8geyAuLi5jb25maWcsIGluaXRpYWxGaWx0ZXJzOiBhcnRpY3Vsb3NJdGVtU2VhcmNoRmlsdGVycyB9XG4gICAgICAgICAgICA6IGNvbmZpZ1xuICAgICAgICApO1xuICAgICAgICBzZXRJc01vZGFsT3Blbih0cnVlKTtcbiAgICB9O1xuXG4gICAgLy8g4pyFIDkuIEhBTkRMRVJTIFBBUkEgTEEgKk5VRVZBKiBUQUJMQSBERSBQUk9EVUNUT1NcbiAgICBjb25zdCBoYW5kbGVBZGRQcm9kdWN0SXRlbSA9ICgpID0+IHtcbiAgICAgICAgc2V0UHJvZHVjdEl0ZW1zKHByZXYgPT4gW1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgICAgICAgICAgcHJvZHVjdF9pZDogbnVsbCxcbiAgICAgICAgICAgICAgICBwcm9kdWN0X2NvZGU6ICcnLFxuICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogbnVsbCxcbiAgICAgICAgICAgICAgICBxdWFudGl0eTogMSxcbiAgICAgICAgICAgICAgICBwcmljZV9jb3N0OiAwXG4gICAgICAgICAgICB9XG4gICAgICAgIF0pO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlUHJvZHVjdEl0ZW0gPSAodGVtcElkOiBzdHJpbmcpID0+IHNldFByb2R1Y3RJdGVtcyhwcmV2ID0+IHByZXYuZmlsdGVyKGkgPT4gaS50ZW1wSWQgIT09IHRlbXBJZCkpO1xuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZVByb2R1Y3RJdGVtID0gKHRlbXBJZDogc3RyaW5nLCBmaWVsZDoga2V5b2YgUHJvZHVjdFB1cmNoYXNlSXRlbSwgdmFsdWU6IGFueSkgPT4ge1xuICAgICAgICBzZXRQcm9kdWN0SXRlbXMocHJldiA9PiBwcmV2Lm1hcChpID0+IGkudGVtcElkID09PSB0ZW1wSWQgPyB7IC4uLmksIFtmaWVsZF06IHZhbHVlIH0gOiBpKSk7XG4gICAgfTtcblxuICAgIC8vIFNldGVhIGVsIHByb2R1Y3RvIGVuIGxhIGZpbGEgZGUgbGEgdGFibGEgZGUgcHJvZHVjdG9zXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0UHJvZHVjdCA9ICh0ZW1wSWQ6IHN0cmluZywgcHJvZHVjdDogQXJ0aWN1bG8pID0+IHtcbiAgICAgICAgc2V0UHJvZHVjdEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaSA9PlxuICAgICAgICAgICAgaS50ZW1wSWQgPT09IHRlbXBJZFxuICAgICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgICAuLi5pLFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LmlkLFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2NvZGU6IHByb2R1Y3Quc2t1LCAvLyBVc2Ftb3MgJ3NrdSdcbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9uYW1lOiBwcm9kdWN0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHByaWNlX2Nvc3Q6IE51bWJlcihwcm9kdWN0LmNvc3RfcHJpY2UpIHx8IDAsIC8vIMKhVXNhbW9zIGVsIGNvc3RfcHJpY2UhXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDogaVxuICAgICAgICApKTtcbiAgICB9O1xuXG4gICAgLy8gUGVyY2VwY2lvbmVzOiBhZ3JlZ2FyIC8gcXVpdGFyIC8gYWN0dWFsaXphciBmaWxhOyBubyByZXBldGlyIHRheF9pZFxuICAgIGNvbnN0IGhhbmRsZUFkZFBlcmNlcHRpb25Sb3cgPSAoKSA9PiB7XG4gICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHByZXYgPT4gWy4uLnByZXYsIHsgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCB0YXhfaWQ6IG51bGwsIHRheF9uYW1lOiBudWxsLCBhbW91bnQ6IDAgfV0pO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlUGVyY2VwdGlvblJvdyA9ICh0ZW1wSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYuZmlsdGVyKHIgPT4gci50ZW1wSWQgIT09IHRlbXBJZCkpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlVXBkYXRlUGVyY2VwdGlvblJvdyA9ICh0ZW1wSWQ6IHN0cmluZywgZmllbGQ6IGtleW9mIFBlcmNlcHRpb25Sb3csIHZhbHVlOiBudW1iZXIgfCBzdHJpbmcgfCBudWxsKSA9PiB7XG4gICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHByZXYgPT4gcHJldi5tYXAociA9PiByLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5yLCBbZmllbGRdOiB2YWx1ZSB9IDogcikpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlU2VsZWN0UGVyY2VwdGlvblRheCA9ICh0ZW1wSWQ6IHN0cmluZywgdGF4OiBUYXgpID0+IHtcbiAgICAgICAgY29uc3QgYWxyZWFkeVVzZWQgPSBwZXJjZXB0aW9uUm93cy5zb21lKHIgPT4gci50ZW1wSWQgIT09IHRlbXBJZCAmJiByLnRheF9pZCA9PT0gdGF4LmlkKTtcbiAgICAgICAgaWYgKGFscmVhZHlVc2VkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdFc2EgcGVyY2VwY2nDs24geWEgZXN0w6EgZW4gbGEgbGlzdGEuIE5vIHNlIHB1ZWRlIHJlcGV0aXIuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0UGVyY2VwdGlvblJvd3MocHJldiA9PiBwcmV2Lm1hcChyID0+XG4gICAgICAgICAgICByLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5yLCB0YXhfaWQ6IHRheC5pZCwgdGF4X25hbWU6IHRheC5uYW1lIH0gOiByXG4gICAgICAgICkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVVcGRhdGVBcHBsaWVkVGF4QW1vdW50ID0gKHRheF9pZDogbnVtYmVyLCBhbW91bnQ6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRBcHBsaWVkVGF4ZXMocHJldiA9PiBwcmV2Lm1hcCh0ID0+IHQudGF4X2lkID09PSB0YXhfaWQgPyB7IC4uLnQsIGFtb3VudCB9IDogdCkpO1xuICAgIH07XG5cbiAgICAvLyBCdXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ29cbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0Q29kZVN1Ym1pdCA9IGFzeW5jICh0ZW1wSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0gcHJvZHVjdEl0ZW1zLmZpbmQoaSA9PiBpLnRlbXBJZCA9PT0gdGVtcElkKTtcbiAgICAgICAgY29uc3QgY29kZSA9IGl0ZW0/LnByb2R1Y3RfY29kZTtcbiAgICAgICAgaWYgKCFjb2RlKSByZXR1cm4gdG9hc3QuaW5mbygnSW5ncmVzZSB1biBjw7NkaWdvIGRlIHByb2R1Y3RvIChTS1UpJyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyDinIUgQnVzY2FyIGNvbiBlbCBmb3JtYXRvIGRlIG3DoXNjYXJhIChpbmNsdXllIHB1bnRvcylcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgc2VhcmNoPEFydGljdWxvPihgJHthcnRpY3Vsb3NNb2R1bGVDb25maWcuZW5kcG9pbnR9P3NrdT0ke2NvZGV9YCk7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgaGFuZGxlU2VsZWN0UHJvZHVjdCh0ZW1wSWQsIHJlc3BvbnNlLmRhdGFbMF0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignUHJvZHVjdG8gbm8gZW5jb250cmFkbyBjb24gZXNlIFNLVS4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHsgY29uc29sZS5lcnJvcihlcnJvcik7IHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvZHVjdG8uJyk7IH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0TW9kYWwgPSAoc2VsZWN0ZWQ6IGFueSkgPT4ge1xuICAgICAgICBpZiAoIWVkaXRpbmdUYXJnZXQpIHtcbiAgICAgICAgICAgIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAndmVuZG9yJykge1xuICAgICAgICAgICAgaGFuZGxlU2VsZWN0VmVuZG9yKHNlbGVjdGVkKTtcbiAgICAgICAgfSBlbHNlIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAnY3VycmVuY3knKSB7XG4gICAgICAgICAgICBoYW5kbGVTZWxlY3RDdXJyZW5jeShzZWxlY3RlZCk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGVkaXRpbmdUYXJnZXQgPT09ICdvYmplY3QnICYmIGVkaXRpbmdUYXJnZXQudHlwZSA9PT0gJ2l0ZW0nKSB7XG4gICAgICAgICAgICBjb25zdCBhY2NvdW50ID0gc2VsZWN0ZWQgYXMgUGxhbkRlQ3VlbnRhcztcbiAgICAgICAgICAgIGNvbnN0IGl0ZW1Ub1VwZGF0ZSA9IGl0ZW1zLmZpbmQoaSA9PiBpLnRlbXBJZCA9PT0gZWRpdGluZ1RhcmdldC50ZW1wSWQpOyAvLyBCdXNjYW1vcyBwb3IgSURcbiAgICAgICAgICAgIGlmIChpdGVtVG9VcGRhdGU/LnRlbXBJZCkge1xuICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0oaXRlbVRvVXBkYXRlLnRlbXBJZCwgJ2xlZ2FjeV9jaGFydF9hY2NvdW50X2NvZGUnLCBhY2NvdW50LmlkKTtcbiAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVJdGVtKGl0ZW1Ub1VwZGF0ZS50ZW1wSWQsICdjaGFydF9hY2NvdW50X25hbWUnLCBhY2NvdW50Lm5hbWUpO1xuICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0oaXRlbVRvVXBkYXRlLnRlbXBJZCwgJ2NoYXJ0X2NvZGVfaW5wdXQnLCBhY2NvdW50LmNvZGUgfHwgU3RyaW5nKGFjY291bnQuaWQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyDinIUgTlVFVkEgTMOTR0lDQTogUGFyYSBzZWxlY2Npb25hciB1biBwcm9kdWN0byBlbiBsYSB0YWJsYSBkZSBwcm9kdWN0b3NcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGVkaXRpbmdUYXJnZXQgPT09ICdvYmplY3QnICYmIGVkaXRpbmdUYXJnZXQudHlwZSA9PT0gJ3Byb2R1Y3RfaXRlbScpIHtcbiAgICAgICAgICAgIGNvbnN0IHByb2R1Y3QgPSBzZWxlY3RlZCBhcyBBcnRpY3VsbztcbiAgICAgICAgICAgIGhhbmRsZVNlbGVjdFByb2R1Y3QoZWRpdGluZ1RhcmdldC50ZW1wSWQsIHByb2R1Y3QpO1xuICAgICAgICB9XG4gICAgICAgIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmdJbml0aWFsKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+e21vZGUgPT09ICdjcmVhdGUnID8gJ0luZ3Jlc28gZGUgQ29tcHJvYmFudGUgZGUgQ29tcHJhJyA6IGBFZGl0YW5kbyBDb21wcmEgIyR7aWR9YH08L2gxPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBtZDpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIGRlIENvbXByYSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiB2YWx1ZT17aGVhZGVyLnB1cmNoYXNlX2RhdGV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgncHVyY2hhc2VfZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmVjaGEgZGUgVmVuY2ltaWVudG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgdmFsdWU9e2hlYWRlci5kdWVfZGF0ZX0gb25DaGFuZ2U9e2UgPT4gaGFuZGxlSGVhZGVyQ2hhbmdlKCdkdWVfZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UHJvdmVlZG9yIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2hlYWRlci52ZW5kb3JfY29kZV9pbnB1dCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2hlYWRlci52ZW5kb3JfbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhuZXdDb2RlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUhlYWRlckNoYW5nZSgndmVuZG9yX2NvZGVfaW5wdXQnLCBuZXdDb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSGVhZGVyQ2hhbmdlKCd2ZW5kb3JfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSGVhZGVyQ2hhbmdlKCd2ZW5kb3JfbmFtZScsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldElzU2luZ2xlVGF4QW1vdW50RWRpdGFibGUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBza2lwSW5pdGlhbEVkaXRUYXhSZWNhbGNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0VGF4QmFzZWxpbmVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZVZlbmRvckNvZGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gb3Blbk1vZGFsKCd2ZW5kb3InLCBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUhlYWRlckNoYW5nZSgndmVuZG9yX2lkJywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUhlYWRlckNoYW5nZSgndmVuZG9yX25hbWUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSGVhZGVyQ2hhbmdlKCd2ZW5kb3JfY29kZV9pbnB1dCcsICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmVuZG9yVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJc1NpbmdsZVRheEFtb3VudEVkaXRhYmxlKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2tpcEluaXRpYWxFZGl0VGF4UmVjYWxjUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdFRheEJhc2VsaW5lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5OwrogZGUgRmFjdHVyYSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17aGVhZGVyLmRvY3VtZW50X251bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVIZWFkZXJDaGFuZ2UoJ2RvY3VtZW50X251bWJlcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5TZXJpZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hlYWRlci5zZXJpZXMgfHwgJ0InfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgnc2VyaWVzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgbXQtMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFcIj5BPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJcIj5CPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNcIj5DPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlhcIj5YPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UmVtaXRvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17aGVhZGVyLmRlbGl2ZXJ5X25vdGV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgnZGVsaXZlcnlfbm90ZScsIGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aGVhZGVyLnZlbmRvcl9pZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUZldGNoU3RvY2tNb3ZlbWVudHN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNGZXRjaGluZ01vdmVtZW50c31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWluZGlnby02MDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRmV0Y2hpbmdNb3ZlbWVudHMgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIC8+IDogPEZhU2VhcmNoIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TW9uZWRhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2hlYWRlci5jdXJyZW5jeV9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aGVhZGVyLmN1cnJlbmN5X25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVIZWFkZXJDaGFuZ2UoJ2N1cnJlbmN5X2NvZGUnLCBuZXdDb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSGVhZGVyQ2hhbmdlKCdjdXJyZW5jeV9pZCcsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVIZWFkZXJDaGFuZ2UoJ2N1cnJlbmN5X25hbWUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9zZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZUN1cnJlbmN5Q29kZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBvcGVuTW9kYWwoJ2N1cnJlbmN5JywgbW9uZWRhc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUhlYWRlckNoYW5nZSgnY3VycmVuY3lfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSGVhZGVyQ2hhbmdlKCdjdXJyZW5jeV9uYW1lJywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUhlYWRlckNoYW5nZSgnY3VycmVuY3lfY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9zZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlRpcG8gZGUgY2FtYmlvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZXhjaGFuZ2VfcmF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hlYWRlci5leGNoYW5nZV9yYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlSGVhZGVyQ2hhbmdlKCdleGNoYW5nZV9yYXRlJywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk1lcyBkZSBpbXB1dGFjacOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hlYWRlci5pbXB1dGF0aW9uX21vbnRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgnaW1wdXRhdGlvbl9tb250aCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogMTIgfSwgKF8sIGkpID0+IFN0cmluZyhpICsgMSkucGFkU3RhcnQoMiwgJzAnKSkubWFwKChtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXttfSB2YWx1ZT17bX0+e219PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+QcOxbyBkZSBpbXB1dGFjacOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hlYWRlci5pbXB1dGF0aW9uX3llYXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlSGVhZGVyQ2hhbmdlKCdpbXB1dGF0aW9uX3llYXInLCBOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogY3VycmVudFllYXIoKSAtIDIwMjUgKyAxIH0sIChfLCBpKSA9PiAyMDI1ICsgaSkubWFwKCh5KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt5fSB2YWx1ZT17eX0+e3l9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIDMuIENBTVBPICdpbnZvaWNlX2ltYWdlJyBDT04gRU5MQUNFIEFMIEFSQ0hJVk8gRVhJU1RFTlRFICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaW52b2ljZV9pbWFnZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEltYWdlbi9QREYgZGUgRmFjdHVyYVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttb2RlID09PSAnZWRpdCcgJiYgaW5pdGlhbFB1cmNoYXNlPy5pbnZvaWNlX2ltYWdlX3BhdGggJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBwLTIgYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsdWUtNzAwIG1iLTFcIj5BcmNoaXZvIGFjdHVhbDo8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVmlld0ZpbGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nRmlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXNtIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itd2FpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUV4dGVybmFsTGlua0FsdCBjbGFzc05hbWU9XCJtci0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmdGaWxlID8gJ0NhcmdhbmRvLi4uJyA6ICdWZXIgYXJjaGl2byBhY3R1YWwnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnZvaWNlX2ltYWdlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgbXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBjdXJzb3ItcG9pbnRlciBmb2N1czpvdXRsaW5lLW5vbmUgZmlsZTptci00IGZpbGU6cHktMiBmaWxlOnB4LTQgZmlsZTpyb3VuZGVkLWwtbWQgZmlsZTpib3JkZXItMCBmaWxlOnRleHQtc20gZmlsZTpmb250LXNlbWlib2xkIGZpbGU6YmctaW5kaWdvLTUwIGZpbGU6dGV4dC1pbmRpZ28tNzAwIGhvdmVyOmZpbGU6YmctaW5kaWdvLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmpwZywuanBlZywucG5nLC5wZGZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21vZGUgPT09ICdlZGl0JyAmJiBpbml0aWFsUHVyY2hhc2U/Lmludm9pY2VfaW1hZ2VfdXJsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1NlbGVjY2lvbmUgdW4gbnVldm8gYXJjaGl2byBwYXJhIHJlZW1wbGF6YXIgZWwgYWN0dWFsLiBPcGNpb25hbC4gVGlwb3M6IEpQRywgUE5HLCBQREYuIE1heDogNU1CLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnT3BjaW9uYWwuIFRpcG9zOiBKUEcsIFBORywgUERGLiBNYXg6IDVNQi4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlByb2R1Y3RvczwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VXNlIGVzdGEgdGFibGEgcGFyYSBjYXJnYXIgcHJvZHVjdG9zIGRlbCByZW1pdG8gbyBtYW51YWxtZW50ZS4gTm8gYWZlY3RhIGVsIHN1YnRvdGFsLjwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNiB3LTIvNVwiPlByb2R1Y3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnRpZGFkPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlByZWNpbyBVbml0LiAoQ29zdG8pPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB5LTMuNSBwbC0zIHByLTQgc206cHItNlwiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb2R1Y3RJdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbS50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBFc3RlIGVzIGVsIFJlbGF0aW9uYWxJbnB1dCBwYXJhIFBST0RVQ1RPUy4gVXNhIGxhIHByb3AgJ2Rpc3BsYXlWYWx1ZScgb3JpZ2luYWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2l0ZW0ucHJvZHVjdF9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2l0ZW0ucHJvZHVjdF9uYW1lIHx8IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZVByb2R1Y3RJdGVtKGl0ZW0udGVtcElkISwgJ3Byb2R1Y3RfY29kZScsIG5ld0NvZGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUHJvZHVjdEl0ZW0oaXRlbS50ZW1wSWQhLCAncHJvZHVjdF9pZCcsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUHJvZHVjdEl0ZW0oaXRlbS50ZW1wSWQhLCAncHJvZHVjdF9uYW1lJywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVQcm9kdWN0SXRlbShpdGVtLnRlbXBJZCEsICdwcmljZV9jb3N0JywgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlUHJvZHVjdENvZGVTdWJtaXQoaXRlbS50ZW1wSWQhKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gb3Blbk1vZGFsKHsgdHlwZTogJ3Byb2R1Y3RfaXRlbScsIHRlbXBJZDogaXRlbS50ZW1wSWQhIH0sIGFydGljdWxvc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUHJvZHVjdEl0ZW0oaXRlbS50ZW1wSWQhLCAncHJvZHVjdF9pZCcsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUHJvZHVjdEl0ZW0oaXRlbS50ZW1wSWQhLCAncHJvZHVjdF9uYW1lJywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVQcm9kdWN0SXRlbShpdGVtLnRlbXBJZCEsICdwcm9kdWN0X2NvZGUnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVQcm9kdWN0SXRlbShpdGVtLnRlbXBJZCEsICdwcmljZV9jb3N0JywgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hc2s9XCJza3VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmFibGVBdXRvY29tcGxldGU9e3RydWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZUNvbmZpZz17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ6IGFydGljdWxvc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVGaWVsZDogJ3NrdScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICduYW1lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlYXJjaFBhcmFtczogYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdDogKHByb2R1Y3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVTZWxlY3RQcm9kdWN0KGl0ZW0udGVtcElkISwgcHJvZHVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCB2YWx1ZT17aXRlbS5xdWFudGl0eX0gb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVQcm9kdWN0SXRlbShpdGVtLnRlbXBJZCEsICdxdWFudGl0eScsIG51bSl9IGNsYXNzTmFtZT1cInctMjQgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCB2YWx1ZT17aXRlbS5wcmljZV9jb3N0fSBvbkNoYW5nZT17bnVtID0+IGhhbmRsZVVwZGF0ZVByb2R1Y3RJdGVtKGl0ZW0udGVtcElkISwgJ3ByaWNlX2Nvc3QnLCBudW0pfSBjbGFzc05hbWU9XCJ3LTMyIHB4LTIgcHktMSB0ZXh0LXJpZ2h0IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS05MDAgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZSgoaXRlbS5xdWFudGl0eSB8fCAwKSAqIChpdGVtLnByaWNlX2Nvc3QgfHwgMCksICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVByb2R1Y3RJdGVtKGl0ZW0udGVtcElkISl9IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDBcIj48RmFUcmFzaCAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVBZGRQcm9kdWN0SXRlbX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiBtdC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ncmF5LTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNzAwXCI+PEZhUGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTJcIiAvPkHDsWFkaXIgUHJvZHVjdG88L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXIgcm91bmRlZC1sZyBiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPsONdGVtczwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTYgdy0zLzVcIj5DdWVudGEgQ29udGFibGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+VmFsb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicmVsYXRpdmUgcHktMy41IHBsLTMgcHItNCBzbTpwci02XCI+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtLCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLnRlbXBJZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9eyhpdGVtIGFzIEFjY291bnRpbmdJdGVtV2l0aElucHV0KS5jaGFydF9jb2RlX2lucHV0IHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2l0ZW0uY2hhcnRfYWNjb3VudF9uYW1lIHx8IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0oaXRlbS50ZW1wSWQhLCAnbGVnYWN5X2NoYXJ0X2FjY291bnRfY29kZScsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlSXRlbShpdGVtLnRlbXBJZCEsICdjaGFydF9hY2NvdW50X25hbWUnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVJdGVtKGl0ZW0udGVtcElkISwgJ2NoYXJ0X2NvZGVfaW5wdXQnIGFzIGtleW9mIFB1cmNoYXNlSXRlbSwgbmV3Q29kZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVBY2NvdW50Q29kZVN1Ym1pdChpdGVtLnRlbXBJZCEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBvcGVuTW9kYWwoeyB0eXBlOiAnaXRlbScsIHRlbXBJZDogaXRlbS50ZW1wSWQhIH0gYXMgYW55LCBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVJdGVtKGl0ZW0udGVtcElkISwgJ2xlZ2FjeV9jaGFydF9hY2NvdW50X2NvZGUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZUl0ZW0oaXRlbS50ZW1wSWQhLCAnY2hhcnRfYWNjb3VudF9uYW1lJywgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlSXRlbShpdGVtLnRlbXBJZCEsICdjaGFydF9jb2RlX2lucHV0JyBhcyBrZXlvZiBQdXJjaGFzZUl0ZW0sICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0IHZhbHVlPXtpdGVtLnZhbHVlfSBvbkNoYW5nZT17bnVtID0+IGhhbmRsZVVwZGF0ZUl0ZW0oaXRlbS50ZW1wSWQhLCAndmFsdWUnLCBudW0pfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZUl0ZW0oaXRlbS50ZW1wSWQhKX0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMFwiPjxGYVRyYXNoIC8+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUFkZEl0ZW19IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgbXQtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctZ3JheS02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTcwMFwiPjxGYVBsdXMgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz5Bw7FhZGlyIMONdGVtPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgey8qIOKchSBQQVNPIDM6IFJlZW1wbGF6YW1vcyBlbCBpbnB1dCBwb3IgdW4gdGV4dG8gZGUgc29sbyBsZWN0dXJhICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMiBwLTQgYm9yZGVyIHJvdW5kZWQtbGcgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgeSBEZXNjdWVudG9zPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+VmFsb3IgTm8gR3JhdmFkbyAoLSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtoZWFkZXIud2l0aG91dHRheF9hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVIZWFkZXJDaGFuZ2UoJ3dpdGhvdXR0YXhfYW1vdW50JywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgY29sLXNwYW4tMlwiPkRlc2N1ZW50byAoLSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtoZWFkZXIuZGlzY291bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVIZWFkZXJDaGFuZ2UoJ2Rpc2NvdW50JywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHshaGVhZGVyLnZlbmRvcl9pZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBwdC0yXCI+U2VsZWNjaW9uZSB1biBwcm92ZWVkb3IgcGFyYSBjYWxjdWxhciBzdXMgaW1wdWVzdG9zLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgKSA6IHZlbmRvclRheGVzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBsaWVkVGF4ZXMubWFwKHRheCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNUYXhBbW91bnRFZGl0YWJsZSA9IHZlbmRvclRheGVzLmxlbmd0aCA+IDEgfHwgaXNTaW5nbGVUYXhBbW91bnRFZGl0YWJsZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dGF4LnRheF9pZH0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+e3RheC50YXhfbmFtZX0gKHt0YXgucmF0ZX0lKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUYXhBbW91bnRFZGl0YWJsZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RheC5hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZVVwZGF0ZUFwcGxpZWRUYXhBbW91bnQodGF4LnRheF9pZCwgbnVtID8/IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgtMSBweC0yIHB5LTEgdGV4dC1yaWdodCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSB3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgdGV4dC1ncmF5LTgwMCBiZy1ncmF5LTEwMCByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKHRheC5hbW91bnQsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlcXVlc3RFZGl0U2luZ2xlVGF4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJFZGl0YXIgaW1wb3J0ZSBkZSBpbXB1ZXN0b1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWluZGlnby02MDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGVuY2lsQWx0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHB0LTJcIj5FbCBwcm92ZWVkb3Igc2VsZWNjaW9uYWRvIG5vIHRpZW5lIGltcHVlc3RvcyBjb25maWd1cmFkb3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgbXQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgbWItMlwiPlBlcmNlcGNpb25lczwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cGVyY2VwdGlvblRheGVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgcGVyY2VwY2lvbmVzIGNvbmZpZ3VyYWRhcy48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVyY2VwdGlvblJvd3MubWFwKChyb3cpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cm93LnRlbXBJZH0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Jvdy50YXhfaWQgPz8gJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVQZXJjZXB0aW9uUm93KHJvdy50ZW1wSWQsICd0YXhfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUGVyY2VwdGlvblJvdyhyb3cudGVtcElkLCAndGF4X25hbWUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXggPSBwZXJjZXB0aW9uVGF4ZXMuZmluZCh0ID0+IHQuaWQgPT09IE51bWJlcih2YWwpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGF4KSBoYW5kbGVTZWxlY3RQZXJjZXB0aW9uVGF4KHJvdy50ZW1wSWQsIHRheCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sLXNwYW4tMiB3LWZ1bGwgcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25lIHBlcmNlcGNpw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVyY2VwdGlvblRheGVzLm1hcCgodGF4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3RheC5pZH0gdmFsdWU9e3RheC5pZH0gZGlzYWJsZWQ9e3BlcmNlcHRpb25Sb3dzLnNvbWUociA9PiByLnRlbXBJZCAhPT0gcm93LnRlbXBJZCAmJiByLnRheF9pZCA9PT0gdGF4LmlkKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXgubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3cuYW1vdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlVXBkYXRlUGVyY2VwdGlvblJvdyhyb3cudGVtcElkLCAnYW1vdW50JywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVBlcmNlcHRpb25Sb3cocm93LnRlbXBJZCl9IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDAgcC0xXCIgdGl0bGU9XCJRdWl0YXJcIj48RmFUcmFzaCAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQWRkUGVyY2VwdGlvblJvd30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiBtdC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ncmF5LTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEFncmVnYXIgcGVyY2VwY2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1ncmF5LTUwIGJvcmRlciByb3VuZGVkLWxnIHNwYWNlLXktMiBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPjxzcGFuPlN1YnRvdGFsOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy5zdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPjxzcGFuPlZhbG9yIE5vIEdyYXZhZG8gKG5vIGdyYXZhZG8pOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKGhlYWRlci53aXRob3V0dGF4X2Ftb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+PHNwYW4+RGVzY3VlbnRvOjwvc3Bhbj4gPHNwYW4+LSB7Zm9ybWF0VmFsdWUoaGVhZGVyLmRpc2NvdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPjxzcGFuPkltcHVlc3Rvczo8L3NwYW4+IDxzcGFuPntmb3JtYXRWYWx1ZSh0b3RhbHMudGF4VG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+PHNwYW4+UGVyY2VwY2lvbmVzOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy5wZXJjZXBjaW9uZXNUb3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGZvbnQtYm9sZCB0ZXh0LWxnIGJvcmRlci10IHB0LTIgbXQtMlwiPjxzcGFuPlRPVEFMOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy5ncmFuZFRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChjb21wcmFzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIj5DYW5jZWxhcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVNhdmV9IGRpc2FibGVkPXtsb2FkaW5nfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyZWVuLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpiZy1ncmVlbi00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgQ29tcHJhXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2lzTW9kYWxPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8U2VhcmNoTW9kYWwgaXNPcGVuPXtpc01vZGFsT3Blbn0gb25DbG9zZT17KCkgPT4gc2V0SXNNb2RhbE9wZW4oZmFsc2UpfSBvblNlbGVjdD17aGFuZGxlU2VsZWN0TW9kYWx9IGNvbmZpZz17bW9kYWxDb25maWd9IC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY29tcHJhcy9wYWdlcy9Db21wcmFzRm9ybVBhZ2UudHN4In0=