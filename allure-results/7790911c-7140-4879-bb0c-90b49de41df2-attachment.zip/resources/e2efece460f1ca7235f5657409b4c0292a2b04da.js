import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
const initialValues = {
  code: "",
  name: "",
  related_to: null,
  level: 0,
  is_ajustable: false,
  moviments: false,
  account_code: "",
  columna_balance: 0
};
export const PlanDeCuentasCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(planDeCuentasModuleConfig);
  const handleSave = async (data) => {
    const dataToSave = { ...data };
    delete dataToSave.related_to_code;
    delete dataToSave.related_to_name;
    delete dataToSave.parent;
    delete dataToSave.parent_id;
    delete dataToSave.parent_code;
    delete dataToSave.parent_name;
    const newItem = await saveItem(dataToSave);
    if (newItem) {
      toast.info(`Cuenta creada con éxito!`);
      navigate("/plan-de-cuentas");
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: planDeCuentasModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx",
      lineNumber: 64,
      columnNumber: 5
    },
    this
  );
};
_s(PlanDeCuentasCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = PlanDeCuentasCreatePage;
var _c;
$RefreshReg$(_c, "PlanDeCuentasCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGlDQUFxRDtBQUM5RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUV0QixNQUFNQyxnQkFBd0M7QUFBQSxFQUMxQ0MsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxZQUFZO0FBQUEsRUFDWkMsT0FBTztBQUFBLEVBQ1BDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsY0FBYztBQUFBLEVBQ2RDLGlCQUFpQjtBQUNyQjtBQUVPLGFBQU1DLDBCQUEwQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pDLFFBQU1DLFdBQVdoQixZQUFZO0FBQzdCLFFBQU0sRUFBRWlCLFNBQVMsSUFBSWQsWUFBMkJELHlCQUF5QjtBQUV6RSxRQUFNZ0IsYUFBYSxPQUFPQyxTQUF3QjtBQUM5QyxVQUFNQyxhQUE0QixFQUFFLEdBQUdELEtBQUs7QUFPNUMsV0FBUUMsV0FBbUJDO0FBQzNCLFdBQVFELFdBQW1CRTtBQUMzQixXQUFRRixXQUFtQkc7QUFDM0IsV0FBUUgsV0FBbUJJO0FBQzNCLFdBQVFKLFdBQW1CSztBQUMzQixXQUFRTCxXQUFtQk07QUFFM0IsVUFBTUMsVUFBVSxNQUFNVixTQUFTRyxVQUFVO0FBQ3pDLFFBQUlPLFNBQVM7QUFDVHZCLFlBQU13QixLQUFLLDBCQUEwQjtBQUNyQ1osZUFBUyxrQkFBa0I7QUFBQSxJQUMvQjtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRZDtBQUFBQSxNQUNSLGFBQWFHO0FBQUFBLE1BQ2IsUUFBUWE7QUFBQUEsTUFDUixNQUFLO0FBQUE7QUFBQSxJQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlpQjtBQUd6QjtBQUFFSCxHQWxDV0QseUJBQXVCO0FBQUEsVUFDZmQsYUFDSUcsV0FBVztBQUFBO0FBQUEwQixLQUZ2QmY7QUFBdUIsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwicGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJpbml0aWFsVmFsdWVzIiwiY29kZSIsIm5hbWUiLCJyZWxhdGVkX3RvIiwibGV2ZWwiLCJpc19hanVzdGFibGUiLCJtb3ZpbWVudHMiLCJhY2NvdW50X2NvZGUiLCJjb2x1bW5hX2JhbGFuY2UiLCJQbGFuRGVDdWVudGFzQ3JlYXRlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJzYXZlSXRlbSIsImhhbmRsZVNhdmUiLCJkYXRhIiwiZGF0YVRvU2F2ZSIsInJlbGF0ZWRfdG9fY29kZSIsInJlbGF0ZWRfdG9fbmFtZSIsInBhcmVudCIsInBhcmVudF9pZCIsInBhcmVudF9jb2RlIiwicGFyZW50X25hbWUiLCJuZXdJdGVtIiwiaW5mbyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBsYW5EZUN1ZW50YXNDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcsIHR5cGUgUGxhbkRlQ3VlbnRhcyB9IGZyb20gJy4uL3BsYW5fZGVfY3VlbnRhcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcblxuY29uc3QgaW5pdGlhbFZhbHVlczogUGFydGlhbDxQbGFuRGVDdWVudGFzPiA9IHtcbiAgICBjb2RlOiAnJyxcbiAgICBuYW1lOiAnJyxcbiAgICByZWxhdGVkX3RvOiBudWxsLFxuICAgIGxldmVsOiAwLFxuICAgIGlzX2FqdXN0YWJsZTogZmFsc2UsXG4gICAgbW92aW1lbnRzOiBmYWxzZSxcbiAgICBhY2NvdW50X2NvZGU6ICcnLFxuICAgIGNvbHVtbmFfYmFsYW5jZTogMCxcbn07XG5cbmV4cG9ydCBjb25zdCBQbGFuRGVDdWVudGFzQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08UGxhbkRlQ3VlbnRhcz4ocGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZyk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IFBsYW5EZUN1ZW50YXMpID0+IHtcbiAgICAgICAgY29uc3QgZGF0YVRvU2F2ZTogUGxhbkRlQ3VlbnRhcyA9IHsgLi4uZGF0YSB9O1xuXG4gICAgICAgIC8vIOKchSBOb3RhOiBHZW5lcmljRm9ybVBhZ2UgZ3VhcmRhcsOhIGVuIGNvZGUvbmFtZSBjdWFuZG8gc2VsZWNjaW9uYSByZWxhdGVkX3RvXG4gICAgICAgIC8vIEVuIG1vZG8gY3JlYXRlLCBhc3VtaW1vcyBxdWUgbG9zIHZhbG9yZXMgZmluYWxlcyBlbiBjb2RlL25hbWUgc29uIGxvcyBjb3JyZWN0b3NcbiAgICAgICAgLy8gKGVsIHVzdWFyaW8gcHVlZGUgZXNjcmliaXIgY29kZS9uYW1lIGRlc3B1w6lzIGRlIHNlbGVjY2lvbmFyIHJlbGF0ZWRfdG8gc2kgZXMgbmVjZXNhcmlvKVxuXG4gICAgICAgIC8vIExpbXBpYXIgY2FtcG9zIHJlbGFjaW9uYWxlcyBhbnRlcyBkZSBlbnZpYXJcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkucmVsYXRlZF90b19jb2RlO1xuICAgICAgICBkZWxldGUgKGRhdGFUb1NhdmUgYXMgYW55KS5yZWxhdGVkX3RvX25hbWU7XG4gICAgICAgIGRlbGV0ZSAoZGF0YVRvU2F2ZSBhcyBhbnkpLnBhcmVudDtcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkucGFyZW50X2lkO1xuICAgICAgICBkZWxldGUgKGRhdGFUb1NhdmUgYXMgYW55KS5wYXJlbnRfY29kZTtcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkucGFyZW50X25hbWU7XG5cbiAgICAgICAgY29uc3QgbmV3SXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGFUb1NhdmUpO1xuICAgICAgICBpZiAobmV3SXRlbSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhgQ3VlbnRhIGNyZWFkYSBjb24gw6l4aXRvIWApO1xuICAgICAgICAgICAgbmF2aWdhdGUoJy9wbGFuLWRlLWN1ZW50YXMnKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e3BsYW5EZUN1ZW50YXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFZhbHVlcyBhcyBQbGFuRGVDdWVudGFzfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3BsYW5fZGVfY3VlbnRhcy9wYWdlcy9QbGFuRGVDdWVudGFzQ3JlYXRlUGFnZS50c3gifQ==