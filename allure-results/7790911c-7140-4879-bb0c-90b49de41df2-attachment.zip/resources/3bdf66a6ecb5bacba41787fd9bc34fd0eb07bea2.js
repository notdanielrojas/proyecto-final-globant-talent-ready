import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/MultiSelectDropdown.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/MultiSelectDropdown.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useId = __vite__cjsImport3_react["useId"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { IoChevronDown, IoClose } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
const SEARCH_THRESHOLD = 8;
export const MultiSelectDropdown = ({
  options,
  selected,
  onChange,
  placeholder = "Todos",
  searchable,
  className = ""
}) => {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const containerRef = useRef(null);
  const searchInputRef = useRef(null);
  const listboxId = useId();
  const showSearch = searchable ?? options.length >= SEARCH_THRESHOLD;
  const optionByValue = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const opt of options) {
      map.set(opt.value, opt);
    }
    return map;
  }, [options]);
  const filteredOptions = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return options;
    return options.filter((opt) => opt.label.toLowerCase().includes(term));
  }, [options, searchTerm]);
  const selectedLabels = useMemo(
    () => selected.map((val) => optionByValue.get(val)?.label ?? val),
    [selected, optionByValue]
  );
  useEffect(() => {
    if (!isOpen) {
      setSearchTerm("");
      return;
    }
    if (showSearch) {
      searchInputRef.current?.focus();
    }
  }, [isOpen, showSearch]);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleEscape);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [isOpen]);
  const toggleOption = (value) => {
    if (selected.includes(value)) {
      onChange(selected.filter((v) => v !== value));
    } else {
      onChange([...selected, value]);
    }
  };
  const removeValue = (value, event) => {
    event.stopPropagation();
    onChange(selected.filter((v) => v !== value));
  };
  const clearAll = (event) => {
    event.stopPropagation();
    onChange([]);
  };
  return /* @__PURE__ */ jsxDEV("div", { ref: containerRef, className: `relative ${className}`, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        "aria-haspopup": "listbox",
        "aria-expanded": isOpen,
        "aria-controls": listboxId,
        onClick: () => setIsOpen((prev) => !prev),
        className: `mt-1 flex w-full min-h-[38px] items-center gap-1 rounded-md border border-gray-300 bg-white py-1.5 pl-2 pr-8 text-left shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 sm:text-sm ${isOpen ? "border-indigo-500 ring-1 ring-indigo-500" : ""}`,
        children: [
          selected.length === 0 ? /* @__PURE__ */ jsxDEV("span", { className: "truncate text-gray-400 px-1", children: placeholder }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 139,
            columnNumber: 9
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "flex flex-1 flex-wrap gap-1", children: selected.map(
            (val, idx) => /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: "inline-flex max-w-full items-center gap-0.5 rounded bg-indigo-100 px-1.5 py-0.5 text-xs font-medium text-indigo-800",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: selectedLabels[idx] }, void 0, false, {
                    fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                    lineNumber: 147,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      "aria-label": `Quitar ${selectedLabels[idx]}`,
                      onClick: (e) => removeValue(val, e),
                      className: "shrink-0 rounded p-0.5 hover:bg-indigo-200",
                      children: /* @__PURE__ */ jsxDEV(IoClose, { className: "h-3 w-3" }, void 0, false, {
                        fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                        lineNumber: 154,
                        columnNumber: 37
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                      lineNumber: 148,
                      columnNumber: 33
                    },
                    this
                  )
                ]
              },
              val,
              true,
              {
                fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                lineNumber: 143,
                columnNumber: 11
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 141,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            IoChevronDown,
            {
              className: `pointer-events-none absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 transition-transform ${isOpen ? "rotate-180" : ""}`,
              "aria-hidden": true
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
              lineNumber: 160,
              columnNumber: 17
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
        lineNumber: 128,
        columnNumber: 13
      },
      this
    ),
    isOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: listboxId,
        role: "listbox",
        "aria-multiselectable": "true",
        className: "absolute z-20 mt-1 w-full rounded-md border border-gray-200 bg-white shadow-lg",
        children: [
          showSearch && /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 p-2", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: searchInputRef,
              type: "text",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value),
              placeholder: "Buscar...",
              className: "block w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500",
              onClick: (e) => e.stopPropagation(),
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
              lineNumber: 177,
              columnNumber: 29
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 176,
            columnNumber: 9
          }, this),
          selected.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end border-b border-gray-100 px-2 py-1", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: clearAll,
              className: "text-xs text-indigo-600 hover:text-indigo-800",
              children: "Limpiar selección"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
              lineNumber: 190,
              columnNumber: 29
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 189,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "max-h-48 overflow-y-auto py-1", children: filteredOptions.length === 0 ? /* @__PURE__ */ jsxDEV("li", { className: "px-3 py-2 text-sm text-gray-400 italic", children: "Sin resultados" }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 202,
            columnNumber: 11
          }, this) : filteredOptions.map((opt) => {
            const isSelected = selected.includes(opt.value);
            return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": isSelected,
                onClick: () => toggleOption(opt.value),
                className: `flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-indigo-50 ${isSelected ? "bg-indigo-50 text-indigo-900" : "text-gray-700"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `flex h-4 w-4 shrink-0 items-center justify-center rounded border ${isSelected ? "border-indigo-600 bg-indigo-600 text-white" : "border-gray-300 bg-white"}`,
                      "aria-hidden": true,
                      children: isSelected && /* @__PURE__ */ jsxDEV("svg", { className: "h-3 w-3", viewBox: "0 0 12 12", fill: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { d: "M10.28 2.28a.75.75 0 0 1 0 1.06l-5.25 5.25a.75.75 0 0 1-1.06 0L1.72 6.34a.75.75 0 1 1 1.06-1.06l1.94 1.94 4.72-4.72a.75.75 0 0 1 1.06 0z" }, void 0, false, {
                        fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                        lineNumber: 227,
                        columnNumber: 57
                      }, this) }, void 0, false, {
                        fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                        lineNumber: 226,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                      lineNumber: 217,
                      columnNumber: 45
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: opt.label }, void 0, false, {
                    fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                    lineNumber: 231,
                    columnNumber: 45
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
                lineNumber: 208,
                columnNumber: 41
              },
              this
            ) }, opt.value, false, {
              fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
              lineNumber: 207,
              columnNumber: 15
            }, this);
          }) }, void 0, false, {
            fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
            lineNumber: 200,
            columnNumber: 21
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
        lineNumber: 169,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/components/common/MultiSelectDropdown.tsx",
    lineNumber: 127,
    columnNumber: 5
  }, this);
};
_s(MultiSelectDropdown, "tk5in7IrDvli1up4aVTum2JBvqA=");
_c = MultiSelectDropdown;
var _c;
$RefreshReg$(_c, "MultiSelectDropdown");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/MultiSelectDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/MultiSelectDropdown.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUhvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2SHBCLFNBQVNBLFdBQVdDLE9BQU9DLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUM1RCxTQUFTQyxlQUFlQyxlQUFlO0FBaUJ2QyxNQUFNQyxtQkFBbUI7QUFFbEIsYUFBTUMsc0JBQXNCQSxDQUFDO0FBQUEsRUFDaENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGNBQWM7QUFBQSxFQUNkQztBQUFBQSxFQUNBQyxZQUFZO0FBQ1UsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJYixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDYyxZQUFZQyxhQUFhLElBQUlmLFNBQVMsRUFBRTtBQUMvQyxRQUFNZ0IsZUFBZWpCLE9BQXVCLElBQUk7QUFDaEQsUUFBTWtCLGlCQUFpQmxCLE9BQXlCLElBQUk7QUFDcEQsUUFBTW1CLFlBQVlyQixNQUFNO0FBRXhCLFFBQU1zQixhQUFhVixjQUFjSixRQUFRZSxVQUFVakI7QUFFbkQsUUFBTWtCLGdCQUFnQnZCLFFBQVEsTUFBTTtBQUNoQyxVQUFNd0IsTUFBTSxvQkFBSUMsSUFBK0I7QUFDL0MsZUFBV0MsT0FBT25CLFNBQVM7QUFDdkJpQixVQUFJRyxJQUFJRCxJQUFJRSxPQUFPRixHQUFHO0FBQUEsSUFDMUI7QUFDQSxXQUFPRjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ2pCLE9BQU8sQ0FBQztBQUVaLFFBQU1zQixrQkFBa0I3QixRQUFRLE1BQU07QUFDbEMsVUFBTThCLE9BQU9kLFdBQVdlLEtBQUssRUFBRUMsWUFBWTtBQUMzQyxRQUFJLENBQUNGLEtBQU0sUUFBT3ZCO0FBQ2xCLFdBQU9BLFFBQVEwQixPQUFPLENBQUFQLFFBQU9BLElBQUlRLE1BQU1GLFlBQVksRUFBRUcsU0FBU0wsSUFBSSxDQUFDO0FBQUEsRUFDdkUsR0FBRyxDQUFDdkIsU0FBU1MsVUFBVSxDQUFDO0FBRXhCLFFBQU1vQixpQkFBaUJwQztBQUFBQSxJQUNuQixNQUFNUSxTQUFTZ0IsSUFBSSxDQUFBYSxRQUFPZCxjQUFjZSxJQUFJRCxHQUFHLEdBQUdILFNBQVNHLEdBQUc7QUFBQSxJQUM5RCxDQUFDN0IsVUFBVWUsYUFBYTtBQUFBLEVBQzVCO0FBRUF6QixZQUFVLE1BQU07QUFDWixRQUFJLENBQUNnQixRQUFRO0FBQ1RHLG9CQUFjLEVBQUU7QUFDaEI7QUFBQSxJQUNKO0FBQ0EsUUFBSUksWUFBWTtBQUNaRixxQkFBZW9CLFNBQVNDLE1BQU07QUFBQSxJQUNsQztBQUFBLEVBQ0osR0FBRyxDQUFDMUIsUUFBUU8sVUFBVSxDQUFDO0FBRXZCdkIsWUFBVSxNQUFNO0FBQ1osVUFBTTJDLHFCQUFxQkEsQ0FBQ0MsVUFBc0I7QUFDOUMsVUFBSXhCLGFBQWFxQixXQUFXLENBQUNyQixhQUFhcUIsUUFBUUksU0FBU0QsTUFBTUUsTUFBYyxHQUFHO0FBQzlFN0Isa0JBQVUsS0FBSztBQUFBLE1BQ25CO0FBQUEsSUFDSjtBQUNBLFVBQU04QixlQUFlQSxDQUFDSCxVQUF5QjtBQUMzQyxVQUFJQSxNQUFNSSxRQUFRLFVBQVU7QUFDeEIvQixrQkFBVSxLQUFLO0FBQUEsTUFDbkI7QUFBQSxJQUNKO0FBRUEsUUFBSUQsUUFBUTtBQUNSaUMsZUFBU0MsaUJBQWlCLGFBQWFQLGtCQUFrQjtBQUN6RE0sZUFBU0MsaUJBQWlCLFdBQVdILFlBQVk7QUFBQSxJQUNyRDtBQUVBLFdBQU8sTUFBTTtBQUNURSxlQUFTRSxvQkFBb0IsYUFBYVIsa0JBQWtCO0FBQzVETSxlQUFTRSxvQkFBb0IsV0FBV0osWUFBWTtBQUFBLElBQ3hEO0FBQUEsRUFDSixHQUFHLENBQUMvQixNQUFNLENBQUM7QUFFWCxRQUFNb0MsZUFBZUEsQ0FBQ3RCLFVBQWtCO0FBQ3BDLFFBQUlwQixTQUFTMkIsU0FBU1AsS0FBSyxHQUFHO0FBQzFCbkIsZUFBU0QsU0FBU3lCLE9BQU8sQ0FBQWtCLE1BQUtBLE1BQU12QixLQUFLLENBQUM7QUFBQSxJQUM5QyxPQUFPO0FBQ0huQixlQUFTLENBQUMsR0FBR0QsVUFBVW9CLEtBQUssQ0FBQztBQUFBLElBQ2pDO0FBQUEsRUFDSjtBQUVBLFFBQU13QixjQUFjQSxDQUFDeEIsT0FBZWMsVUFBNEI7QUFDNURBLFVBQU1XLGdCQUFnQjtBQUN0QjVDLGFBQVNELFNBQVN5QixPQUFPLENBQUFrQixNQUFLQSxNQUFNdkIsS0FBSyxDQUFDO0FBQUEsRUFDOUM7QUFFQSxRQUFNMEIsV0FBV0EsQ0FBQ1osVUFBNEI7QUFDMUNBLFVBQU1XLGdCQUFnQjtBQUN0QjVDLGFBQVMsRUFBRTtBQUFBLEVBQ2Y7QUFFQSxTQUNJLHVCQUFDLFNBQUksS0FBS1MsY0FBYyxXQUFXLFlBQVlOLFNBQVMsSUFDcEQ7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsaUJBQWM7QUFBQSxRQUNkLGlCQUFlRTtBQUFBQSxRQUNmLGlCQUFlTTtBQUFBQSxRQUNmLFNBQVMsTUFBTUwsVUFBVSxDQUFBd0MsU0FBUSxDQUFDQSxJQUFJO0FBQUEsUUFDdEMsV0FBVyw2TkFDUHpDLFNBQVMsNkNBQTZDLEVBQUU7QUFBQSxRQUczRE47QUFBQUEsbUJBQVNjLFdBQVcsSUFDakIsdUJBQUMsVUFBSyxXQUFVLCtCQUErQloseUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJELElBRTNELHVCQUFDLFVBQUssV0FBVSwrQkFDWEYsbUJBQVNnQjtBQUFBQSxZQUFJLENBQUNhLEtBQUttQixRQUNoQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVHLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFVBQUssV0FBVSxZQUFZcEIseUJBQWVvQixHQUFHLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEsa0JBQ2hEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE1BQUs7QUFBQSxzQkFDTCxjQUFZLFVBQVVwQixlQUFlb0IsR0FBRyxDQUFDO0FBQUEsc0JBQ3pDLFNBQVMsQ0FBQ0MsTUFBTUwsWUFBWWYsS0FBS29CLENBQUM7QUFBQSxzQkFDbEMsV0FBVTtBQUFBLHNCQUVWLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE0QjtBQUFBO0FBQUEsb0JBTmhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBO0FBQUE7QUFBQSxjQVhLcEI7QUFBQUEsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxVQUNILEtBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBVyw0R0FDUHZCLFNBQVMsZUFBZSxFQUFFO0FBQUEsY0FFOUIsZUFBVztBQUFBO0FBQUEsWUFKZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJZTtBQUFBO0FBQUE7QUFBQSxNQXBDbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0NBO0FBQUEsSUFFQ0EsVUFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csSUFBSU07QUFBQUEsUUFDSixNQUFLO0FBQUEsUUFDTCx3QkFBcUI7QUFBQSxRQUNyQixXQUFVO0FBQUEsUUFFVEM7QUFBQUEsd0JBQ0csdUJBQUMsU0FBSSxXQUFVLGdDQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxLQUFLRjtBQUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9IO0FBQUFBLGNBQ1AsVUFBVSxDQUFDeUMsTUFBTXhDLGNBQWN3QyxFQUFFYixPQUFPaEIsS0FBSztBQUFBLGNBQzdDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLFNBQVMsQ0FBQzZCLE1BQU1BLEVBQUVKLGdCQUFnQjtBQUFBLGNBQUcsY0FBYTtBQUFBO0FBQUEsWUFQdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzJELEtBUi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUdIN0MsU0FBU2MsU0FBUyxLQUNmLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsU0FBU2dDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQStDO0FBQUE7QUFBQSxZQUg3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUdKLHVCQUFDLFFBQUcsV0FBVSxpQ0FDVHpCLDBCQUFnQlAsV0FBVyxJQUN4Qix1QkFBQyxRQUFHLFdBQVUsMENBQXlDLDhCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRSxJQUVyRU8sZ0JBQWdCTCxJQUFJLENBQUNFLFFBQVE7QUFDekIsa0JBQU1nQyxhQUFhbEQsU0FBUzJCLFNBQVNULElBQUlFLEtBQUs7QUFDOUMsbUJBQ0ksdUJBQUMsUUFDRztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsaUJBQWU4QjtBQUFBQSxnQkFDZixTQUFTLE1BQU1SLGFBQWF4QixJQUFJRSxLQUFLO0FBQUEsZ0JBQ3JDLFdBQVcsaUZBQ1A4QixhQUFhLGlDQUFpQyxlQUFlO0FBQUEsZ0JBR2pFO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csV0FBVyxvRUFDUEEsYUFDTSwrQ0FDQSwwQkFBMEI7QUFBQSxzQkFFcEMsZUFBVztBQUFBLHNCQUVWQSx3QkFDRyx1QkFBQyxTQUFJLFdBQVUsV0FBVSxTQUFRLGFBQVksTUFBSyxnQkFDOUMsaUNBQUMsVUFBSyxHQUFFLDhJQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtKLEtBRHRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQTtBQUFBLG9CQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFhQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSxZQUFZaEMsY0FBSVEsU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQTtBQUFBO0FBQUEsY0F2QjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXdCQSxLQXpCS1IsSUFBSUUsT0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFVBRVIsQ0FBQyxLQW5DVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFDQTtBQUFBO0FBQUE7QUFBQSxNQXBFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFxRUE7QUFBQSxPQS9HUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUhBO0FBRVI7QUFBRWYsR0ExTVdQLHFCQUFtQjtBQUFBcUQsS0FBbkJyRDtBQUFtQixJQUFBcUQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZUlkIiwidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwiSW9DaGV2cm9uRG93biIsIklvQ2xvc2UiLCJTRUFSQ0hfVEhSRVNIT0xEIiwiTXVsdGlTZWxlY3REcm9wZG93biIsIm9wdGlvbnMiLCJzZWxlY3RlZCIsIm9uQ2hhbmdlIiwicGxhY2Vob2xkZXIiLCJzZWFyY2hhYmxlIiwiY2xhc3NOYW1lIiwiX3MiLCJpc09wZW4iLCJzZXRJc09wZW4iLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsImNvbnRhaW5lclJlZiIsInNlYXJjaElucHV0UmVmIiwibGlzdGJveElkIiwic2hvd1NlYXJjaCIsImxlbmd0aCIsIm9wdGlvbkJ5VmFsdWUiLCJtYXAiLCJNYXAiLCJvcHQiLCJzZXQiLCJ2YWx1ZSIsImZpbHRlcmVkT3B0aW9ucyIsInRlcm0iLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJmaWx0ZXIiLCJsYWJlbCIsImluY2x1ZGVzIiwic2VsZWN0ZWRMYWJlbHMiLCJ2YWwiLCJnZXQiLCJjdXJyZW50IiwiZm9jdXMiLCJoYW5kbGVDbGlja091dHNpZGUiLCJldmVudCIsImNvbnRhaW5zIiwidGFyZ2V0IiwiaGFuZGxlRXNjYXBlIiwia2V5IiwiZG9jdW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInRvZ2dsZU9wdGlvbiIsInYiLCJyZW1vdmVWYWx1ZSIsInN0b3BQcm9wYWdhdGlvbiIsImNsZWFyQWxsIiwicHJldiIsImlkeCIsImUiLCJpc1NlbGVjdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTXVsdGlTZWxlY3REcm9wZG93bi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VJZCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IElvQ2hldnJvbkRvd24sIElvQ2xvc2UgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIE11bHRpU2VsZWN0T3B0aW9uIHtcbiAgICB2YWx1ZTogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBNdWx0aVNlbGVjdERyb3Bkb3duUHJvcHMge1xuICAgIG9wdGlvbnM6IE11bHRpU2VsZWN0T3B0aW9uW107XG4gICAgc2VsZWN0ZWQ6IHN0cmluZ1tdO1xuICAgIG9uQ2hhbmdlOiAodmFsdWVzOiBzdHJpbmdbXSkgPT4gdm9pZDtcbiAgICBwbGFjZWhvbGRlcj86IHN0cmluZztcbiAgICAvKiogTXVlc3RyYSBidXNjYWRvciBpbnRlcm5vIGN1YW5kbyBoYXkgbXVjaGFzIG9wY2lvbmVzIChwb3IgZGVmZWN0byA+PSA4KS4gKi9cbiAgICBzZWFyY2hhYmxlPzogYm9vbGVhbjtcbiAgICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmNvbnN0IFNFQVJDSF9USFJFU0hPTEQgPSA4O1xuXG5leHBvcnQgY29uc3QgTXVsdGlTZWxlY3REcm9wZG93biA9ICh7XG4gICAgb3B0aW9ucyxcbiAgICBzZWxlY3RlZCxcbiAgICBvbkNoYW5nZSxcbiAgICBwbGFjZWhvbGRlciA9ICdUb2RvcycsXG4gICAgc2VhcmNoYWJsZSxcbiAgICBjbGFzc05hbWUgPSAnJyxcbn06IE11bHRpU2VsZWN0RHJvcGRvd25Qcm9wcykgPT4ge1xuICAgIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3Qgc2VhcmNoSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgbGlzdGJveElkID0gdXNlSWQoKTtcblxuICAgIGNvbnN0IHNob3dTZWFyY2ggPSBzZWFyY2hhYmxlID8/IG9wdGlvbnMubGVuZ3RoID49IFNFQVJDSF9USFJFU0hPTEQ7XG5cbiAgICBjb25zdCBvcHRpb25CeVZhbHVlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8c3RyaW5nLCBNdWx0aVNlbGVjdE9wdGlvbj4oKTtcbiAgICAgICAgZm9yIChjb25zdCBvcHQgb2Ygb3B0aW9ucykge1xuICAgICAgICAgICAgbWFwLnNldChvcHQudmFsdWUsIG9wdCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1hcDtcbiAgICB9LCBbb3B0aW9uc10pO1xuXG4gICAgY29uc3QgZmlsdGVyZWRPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHRlcm0gPSBzZWFyY2hUZXJtLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoIXRlcm0pIHJldHVybiBvcHRpb25zO1xuICAgICAgICByZXR1cm4gb3B0aW9ucy5maWx0ZXIob3B0ID0+IG9wdC5sYWJlbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pKTtcbiAgICB9LCBbb3B0aW9ucywgc2VhcmNoVGVybV0pO1xuXG4gICAgY29uc3Qgc2VsZWN0ZWRMYWJlbHMgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBzZWxlY3RlZC5tYXAodmFsID0+IG9wdGlvbkJ5VmFsdWUuZ2V0KHZhbCk/LmxhYmVsID8/IHZhbCksXG4gICAgICAgIFtzZWxlY3RlZCwgb3B0aW9uQnlWYWx1ZV1cbiAgICApO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFpc09wZW4pIHtcbiAgICAgICAgICAgIHNldFNlYXJjaFRlcm0oJycpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzaG93U2VhcmNoKSB7XG4gICAgICAgICAgICBzZWFyY2hJbnB1dFJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfSwgW2lzT3Blbiwgc2hvd1NlYXJjaF0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQgJiYgIWNvbnRhaW5lclJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCBhcyBOb2RlKSkge1xuICAgICAgICAgICAgICAgIHNldElzT3BlbihmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGhhbmRsZUVzY2FwZSA9IChldmVudDogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChpc09wZW4pIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XG4gICAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlRXNjYXBlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUVzY2FwZSk7XG4gICAgICAgIH07XG4gICAgfSwgW2lzT3Blbl0pO1xuXG4gICAgY29uc3QgdG9nZ2xlT3B0aW9uID0gKHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKHNlbGVjdGVkLmluY2x1ZGVzKHZhbHVlKSkge1xuICAgICAgICAgICAgb25DaGFuZ2Uoc2VsZWN0ZWQuZmlsdGVyKHYgPT4gdiAhPT0gdmFsdWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG9uQ2hhbmdlKFsuLi5zZWxlY3RlZCwgdmFsdWVdKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCByZW1vdmVWYWx1ZSA9ICh2YWx1ZTogc3RyaW5nLCBldmVudDogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgb25DaGFuZ2Uoc2VsZWN0ZWQuZmlsdGVyKHYgPT4gdiAhPT0gdmFsdWUpKTtcbiAgICB9O1xuXG4gICAgY29uc3QgY2xlYXJBbGwgPSAoZXZlbnQ6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIG9uQ2hhbmdlKFtdKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiByZWY9e2NvbnRhaW5lclJlZn0gY2xhc3NOYW1lPXtgcmVsYXRpdmUgJHtjbGFzc05hbWV9YH0+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgYXJpYS1oYXNwb3B1cD1cImxpc3Rib3hcIlxuICAgICAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzT3Blbn1cbiAgICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPXtsaXN0Ym94SWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNPcGVuKHByZXYgPT4gIXByZXYpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG10LTEgZmxleCB3LWZ1bGwgbWluLWgtWzM4cHhdIGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcHktMS41IHBsLTIgcHItOCB0ZXh0LWxlZnQgc2hhZG93LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1pbmRpZ28tNTAwIHNtOnRleHQtc20gJHtcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuID8gJ2JvcmRlci1pbmRpZ28tNTAwIHJpbmctMSByaW5nLWluZGlnby01MDAnIDogJydcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LWdyYXktNDAwIHB4LTFcIj57cGxhY2Vob2xkZXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtd3JhcCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgodmFsLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZhbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggbWF4LXctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSByb3VuZGVkIGJnLWluZGlnby0xMDAgcHgtMS41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntzZWxlY3RlZExhYmVsc1tpZHhdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgUXVpdGFyICR7c2VsZWN0ZWRMYWJlbHNbaWR4XX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHJlbW92ZVZhbHVlKHZhbCwgZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCByb3VuZGVkIHAtMC41IGhvdmVyOmJnLWluZGlnby0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9DbG9zZSBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxJb0NoZXZyb25Eb3duXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgcmlnaHQtMiB0b3AtMS8yIGgtNCB3LTQgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc09wZW4gPyAncm90YXRlLTE4MCcgOiAnJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHtpc09wZW4gJiYgKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgaWQ9e2xpc3Rib3hJZH1cbiAgICAgICAgICAgICAgICAgICAgcm9sZT1cImxpc3Rib3hcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLW11bHRpc2VsZWN0YWJsZT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LTIwIG10LTEgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctbGdcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3Nob3dTZWFyY2ggJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17c2VhcmNoSW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBweC0yIHB5LTEuNSB0ZXh0LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHB4LTIgcHktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NsZWFyQWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTGltcGlhciBzZWxlY2Npw7NuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibWF4LWgtNDggb3ZlcmZsb3cteS1hdXRvIHB5LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE9wdGlvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNDAwIGl0YWxpY1wiPlNpbiByZXN1bHRhZG9zPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRPcHRpb25zLm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZC5pbmNsdWRlcyhvcHQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17b3B0LnZhbHVlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlPVwib3B0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1zZWxlY3RlZD17aXNTZWxlY3RlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlT3B0aW9uKG9wdC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQtc20gaG92ZXI6YmctaW5kaWdvLTUwICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID8gJ2JnLWluZGlnby01MCB0ZXh0LWluZGlnby05MDAnIDogJ3RleHQtZ3JheS03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaC00IHctNCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZCBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1pbmRpZ28tNjAwIGJnLWluZGlnby02MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNTZWxlY3RlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTMgdy0zXCIgdmlld0JveD1cIjAgMCAxMiAxMlwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMC4yOCAyLjI4YS43NS43NSAwIDAgMSAwIDEuMDZsLTUuMjUgNS4yNWEuNzUuNzUgMCAwIDEtMS4wNiAwTDEuNzIgNi4zNGEuNzUuNzUgMCAxIDEgMS4wNi0xLjA2bDEuOTQgMS45NCA0LjcyLTQuNzJhLjc1Ljc1IDAgMCAxIDEuMDYgMHpcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntvcHQubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9NdWx0aVNlbGVjdERyb3Bkb3duLnRzeCJ9