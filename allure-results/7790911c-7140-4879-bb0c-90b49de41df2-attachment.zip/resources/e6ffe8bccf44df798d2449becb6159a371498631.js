import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/proveedores/pages/ProveedoresCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/proveedores/pages/ProveedoresCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { ProveedoresFormPage } from "/src/features/proveedores/pages/ProveedoresFormPage.tsx";
import { search } from "/src/services/apiService.ts";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
const baseProviderValues = {
  name: "",
  cuit: "",
  email: "",
  phone: "",
  legacy_tax_condition: "I",
  serie: "A",
  payment_condition: null,
  account_id: null,
  account_code: null,
  account_name: null,
  relatedTaxes: [],
  taxes: []
};
export const ProveedorCreatePage = () => {
  _s();
  const [initialData, setInitialData] = useState(baseProviderValues);
  const accountLoaded = useRef(false);
  useEffect(() => {
    if (accountLoaded.current) return;
    accountLoaded.current = true;
    search(`${planDeCuentasModuleConfig.endpoint}?code=200101`).then((response) => {
      if (response.data.length > 0) {
        const account = response.data[0];
        setInitialData((prev) => ({
          ...prev,
          account_id: account.id,
          account_code: "200101",
          account_name: account.name
        }));
      }
    }).catch(() => {
      accountLoaded.current = false;
    });
  }, []);
  return /* @__PURE__ */ jsxDEV(
    ProveedoresFormPage,
    {
      mode: "create",
      initialData
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/proveedores/pages/ProveedoresCreatePage.tsx",
      lineNumber: 69,
      columnNumber: 5
    },
    this
  );
};
_s(ProveedorCreatePage, "xmaN2InHyWNAMLxRMWiBR7iVRKo=");
_c = ProveedorCreatePage;
var _c;
$RefreshReg$(_c, "ProveedorCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/proveedores/pages/ProveedoresCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/proveedores/pages/ProveedoresCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpEUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBRTVDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGlDQUFxRDtBQUc5RCxNQUFNQyxxQkFBeUM7QUFBQSxFQUMzQ0MsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLHNCQUFzQjtBQUFBLEVBQ3RCQyxPQUFPO0FBQUEsRUFDUEMsbUJBQW1CO0FBQUEsRUFDbkJDLFlBQVk7QUFBQSxFQUNaQyxjQUFjO0FBQUEsRUFDZEMsY0FBYztBQUFBLEVBQ2RDLGNBQWM7QUFBQSxFQUNkQyxPQUFPO0FBQ1g7QUFFTyxhQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXRCLFNBQTZCTSxrQkFBa0I7QUFDckYsUUFBTWlCLGdCQUFnQnJCLE9BQU8sS0FBSztBQUdsQ0QsWUFBVSxNQUFNO0FBQ1osUUFBSXNCLGNBQWNDLFFBQVM7QUFDM0JELGtCQUFjQyxVQUFVO0FBRXhCcEIsV0FBc0IsR0FBR0MsMEJBQTBCb0IsUUFBUSxjQUFjLEVBQ3BFQyxLQUFLLENBQUNDLGFBQWE7QUFDaEIsVUFBSUEsU0FBU0MsS0FBS0MsU0FBUyxHQUFHO0FBQzFCLGNBQU1DLFVBQVVILFNBQVNDLEtBQUssQ0FBQztBQUMvQk4sdUJBQWUsQ0FBQVMsVUFBUztBQUFBLFVBQ3BCLEdBQUdBO0FBQUFBLFVBQ0hqQixZQUFZZ0IsUUFBUUU7QUFBQUEsVUFDcEJqQixjQUFjO0FBQUEsVUFDZEMsY0FBY2MsUUFBUXZCO0FBQUFBLFFBQzFCLEVBQUU7QUFBQSxNQUNOO0FBQUEsSUFDSixDQUFDLEVBQ0EwQixNQUFNLE1BQU07QUFDVFYsb0JBQWNDLFVBQVU7QUFBQSxJQUM1QixDQUFDO0FBQUEsRUFDVCxHQUFHLEVBQUU7QUFFTCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTDtBQUFBO0FBQUEsSUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFFMEM7QUFHbEQ7QUFBRUosR0FoQ1dELHFCQUFtQjtBQUFBZSxLQUFuQmY7QUFBbUIsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiUHJvdmVlZG9yZXNGb3JtUGFnZSIsInNlYXJjaCIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJiYXNlUHJvdmlkZXJWYWx1ZXMiLCJuYW1lIiwiY3VpdCIsImVtYWlsIiwicGhvbmUiLCJsZWdhY3lfdGF4X2NvbmRpdGlvbiIsInNlcmllIiwicGF5bWVudF9jb25kaXRpb24iLCJhY2NvdW50X2lkIiwiYWNjb3VudF9jb2RlIiwiYWNjb3VudF9uYW1lIiwicmVsYXRlZFRheGVzIiwidGF4ZXMiLCJQcm92ZWVkb3JDcmVhdGVQYWdlIiwiX3MiLCJpbml0aWFsRGF0YSIsInNldEluaXRpYWxEYXRhIiwiYWNjb3VudExvYWRlZCIsImN1cnJlbnQiLCJlbmRwb2ludCIsInRoZW4iLCJyZXNwb25zZSIsImRhdGEiLCJsZW5ndGgiLCJhY2NvdW50IiwicHJldiIsImlkIiwiY2F0Y2giLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm92ZWVkb3Jlc0NyZWF0ZVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBQcm92ZWVkb3IgfSBmcm9tIFwiLi4vcHJvdmVlZG9yZXMuY29uZmlnXCI7XG5pbXBvcnQgeyBQcm92ZWVkb3Jlc0Zvcm1QYWdlIH0gZnJvbSBcIi4vUHJvdmVlZG9yZXNGb3JtUGFnZVwiO1xuaW1wb3J0IHsgc2VhcmNoIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2VcIjtcbmltcG9ydCB7IHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcsIHR5cGUgUGxhbkRlQ3VlbnRhcyB9IGZyb20gXCIuLi8uLi9wbGFuX2RlX2N1ZW50YXMvcGxhbl9kZV9jdWVudGFzLmNvbmZpZ1wiO1xuXG4vLyBWYWxvcmVzIGluaWNpYWxlcyBwYXJhIHVuIHByb3ZlZWRvciBudWV2byB5IHZhY8Otby5cbmNvbnN0IGJhc2VQcm92aWRlclZhbHVlczogUGFydGlhbDxQcm92ZWVkb3I+ID0ge1xuICAgIG5hbWU6ICcnLFxuICAgIGN1aXQ6ICcnLFxuICAgIGVtYWlsOiAnJyxcbiAgICBwaG9uZTogJycsXG4gICAgbGVnYWN5X3RheF9jb25kaXRpb246ICdJJyxcbiAgICBzZXJpZTogJ0EnLFxuICAgIHBheW1lbnRfY29uZGl0aW9uOiBudWxsLFxuICAgIGFjY291bnRfaWQ6IG51bGwsXG4gICAgYWNjb3VudF9jb2RlOiBudWxsLFxuICAgIGFjY291bnRfbmFtZTogbnVsbCxcbiAgICByZWxhdGVkVGF4ZXM6IFtdLFxuICAgIHRheGVzOiBbXSxcbn07XG5cbmV4cG9ydCBjb25zdCBQcm92ZWVkb3JDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IFtpbml0aWFsRGF0YSwgc2V0SW5pdGlhbERhdGFdID0gdXNlU3RhdGU8UGFydGlhbDxQcm92ZWVkb3I+PihiYXNlUHJvdmlkZXJWYWx1ZXMpO1xuICAgIGNvbnN0IGFjY291bnRMb2FkZWQgPSB1c2VSZWYoZmFsc2UpO1xuXG4gICAgLy8gUHJlY2FyZ2FyIGN1ZW50YSBjb250YWJsZSAxMDAzMDEgc29sbyB1bmEgdmV6IGFsIG1vbnRhclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChhY2NvdW50TG9hZGVkLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgYWNjb3VudExvYWRlZC5jdXJyZW50ID0gdHJ1ZTtcblxuICAgICAgICBzZWFyY2g8UGxhbkRlQ3VlbnRhcz4oYCR7cGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZy5lbmRwb2ludH0/Y29kZT0yMDAxMDFgKVxuICAgICAgICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBhY2NvdW50ID0gcmVzcG9uc2UuZGF0YVswXTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SW5pdGlhbERhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY291bnRfaWQ6IGFjY291bnQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NvdW50X2NvZGU6ICcyMDAxMDEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjb3VudF9uYW1lOiBhY2NvdW50Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICBhY2NvdW50TG9hZGVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtdKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxQcm92ZWVkb3Jlc0Zvcm1QYWdlXG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsRGF0YSBhcyBQcm92ZWVkb3J9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wcm92ZWVkb3Jlcy9wYWdlcy9Qcm92ZWVkb3Jlc0NyZWF0ZVBhZ2UudHN4In0=