import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/compras/pages/ComprasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/compras/pages/ComprasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { comprasModuleConfig } from "/src/features/compras/compras.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import __vite__cjsImport9_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport9_react["useMemo"]; const useState = __vite__cjsImport9_react["useState"];
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { formatTaxRateCell } from "/src/utils/taxDisplay.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const ComprasDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: purchase, loading, error } = useCrudItem(comprasModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const totals = useMemo(() => {
    if (!purchase) {
      return { subtotal: 0, taxTotal: 0, percepcionesTotal: 0, discount: 0, withouttax_amount: 0, grandTotal: 0 };
    }
    const subtotal = purchase.items?.reduce((sum, item) => sum + (Number(item.value) || 0), 0) || 0;
    const taxesType1 = (purchase.applied_taxes || []).filter((t) => t.tax_type === 1);
    const taxesType2 = (purchase.applied_taxes || []).filter((t) => t.tax_type === 2);
    const taxTotal = taxesType1.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0);
    const percepcionesTotal = taxesType2.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0);
    const discount = purchase.discount || 0;
    const withouttax_amount = purchase.withouttax_amount || 0;
    const grandTotal = subtotal - discount + withouttax_amount + taxTotal + percepcionesTotal;
    return { subtotal, taxTotal, percepcionesTotal, discount, withouttax_amount, grandTotal };
  }, [purchase]);
  const handlePrint = async () => {
    if (!purchase) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/purchases/${purchase.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const handleViewFile = async () => {
    if (!purchase?.id) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el archivo.");
      return;
    }
    setIsLoadingFile(true);
    try {
      await finishPdfPreview(session, `/purchases/${purchase.id}/file`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al obtener el archivo:", error2);
      toast.error("No se pudo abrir el archivo adjunto.");
    } finally {
      setIsLoadingFile(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
    lineNumber: 103,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
    lineNumber: 104,
    columnNumber: 21
  }, this);
  if (!purchase) return /* @__PURE__ */ jsxDEV("div", { children: "No se encontró la compra." }, void 0, false, {
    fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
    lineNumber: 105,
    columnNumber: 25
  }, this);
  const mainDetails = [
    {
      label: "Proveedor",
      // ✅ CAMBIO: Convertido a 'render' para añadir el Link
      render: () => purchase.vendor ? /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/proveedores/${purchase.vendor.id}`,
          className: "text-indigo-600 hover:text-indigo-800 hover:underline",
          children: purchase.vendor.name
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 113,
          columnNumber: 5
        },
        this
      ) : "N/A"
    },
    { label: "Fecha de Compra", value: formatValue(purchase.purchase_date, "date") },
    { label: "Nº de Factura", value: purchase.document_number },
    { label: "Serie", value: purchase.series || "-" },
    { label: "Remito", value: purchase.delivery_note || "N/A" },
    { label: "Vencimiento", value: formatValue(purchase.due_date, "date") },
    { label: "Saldo", value: formatValue(purchase.balance, "currency") },
    {
      label: "Moneda",
      // ✅ CAMBIO: Convertido a 'render' para añadir el Link
      render: () => purchase.currency_name ? purchase.currency_name : "N/A"
    },
    { label: "Tipo de cambio", value: formatValue(purchase.exchange_rate, "currency") },
    {
      label: "Mes/año de imputación",
      value: purchase.imputation_month && purchase.imputation_year ? `${purchase.imputation_month}/${purchase.imputation_year}` : "N/A"
    },
    // ✅ 2. CAMPO 'Factura Adjunta' usando getFileBlob
    {
      label: "Factura Adjunta",
      render: () => purchase.invoice_image_path ? /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleViewFile,
          disabled: isLoadingFile,
          className: "text-indigo-600 hover:text-indigo-800 hover:underline disabled:opacity-50 disabled:cursor-wait",
          children: isLoadingFile ? "Cargando..." : "Ver Adjunto (JPG/PDF)"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 151,
          columnNumber: 5
        },
        this
      ) : "N/A"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: [
          "Detalle de Compra #",
          purchase.id
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 170,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: `mt-1 text-sm font-semibold ${purchase.status ? "text-green-600" : "text-red-600"}`, children: purchase.status ? "Estado: Activa" : "Estado: Anulada" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 171,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 169,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-3 space-x-3 sm:mt-0", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(comprasModuleConfig.baseRoute)), className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: [
          /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 177,
            columnNumber: 25
          }, this),
          " Volver"
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 176,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: [
              isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 -ml-1 animate-spin" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
                lineNumber: 186,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
                lineNumber: 188,
                columnNumber: 13
              }, this),
              "Imprimir"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 179,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(`${comprasModuleConfig.baseRoute}/${purchase.id}/editar`), className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
          /* @__PURE__ */ jsxDEV(IoPencil, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 194,
            columnNumber: 25
          }, this),
          " Editar"
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 193,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 175,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 168,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-3", children: mainDetails.map(
      (detail) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-sm font-medium text-gray-500", children: detail.label }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 204,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: "render" in detail ? detail.render ? detail.render() : null : detail.value }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 205,
          columnNumber: 29
        }, this)
      ] }, detail.label, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 203,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 200,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 199,
      columnNumber: 13
    }, this),
    purchase.products && purchase.products.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos de la Compra" }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 216,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 221,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cantidad" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 222,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Costo Unit." }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 223,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Total" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 224,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 220,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 219,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: purchase.products.map(
          (prod) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: prod.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${prod.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: prod.product_name }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 232,
              columnNumber: 19
            }, this) : prod.product_name }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 230,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: prod.quantity }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 237,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(prod.price_cost, "currency") }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 238,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(Number(prod.quantity) * Number(prod.price_cost), "currency") }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 239,
              columnNumber: 41
            }, this)
          ] }, prod.id, true, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 229,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 227,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 218,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 217,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 215,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Ítems de la Compra" }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 249,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Cuenta Contable" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 254,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Valor" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 255,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 253,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 252,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: purchase.items?.map(
          (item, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: item.chart_account_name || `Código: ${item.legacy_chart_account_code}` }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 261,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.value, "currency") }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 262,
              columnNumber: 37
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 260,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 258,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 251,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 250,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 248,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Impuestos Aplicados" }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 272,
          columnNumber: 21
        }, this),
        purchase.applied_taxes && purchase.applied_taxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 278,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 279,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 280,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 277,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 276,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: purchase.applied_taxes.map(
            (tax, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
                lineNumber: 286,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatTaxRateCell(tax) }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
                lineNumber: 287,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
                lineNumber: 288,
                columnNumber: 45
              }, this)
            ] }, tax.id || index, true, {
              fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
              lineNumber: 285,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 283,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 275,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-gray-500", children: "No hay impuestos aplicados en esta compra." }, void 0, false, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 295,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 271,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 border rounded-lg space-y-2 flex flex-col justify-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 300,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 300,
            columnNumber: 90
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 300,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-gray-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Valor No Gravado (no gravado):" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 301,
            columnNumber: 81
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.withouttax_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 301,
            columnNumber: 125
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 301,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-red-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Descuento:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 302,
            columnNumber: 80
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: [
            "- ",
            formatValue(totals.discount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 302,
            columnNumber: 104
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 302,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Impuestos:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 303,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.taxTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 303,
            columnNumber: 91
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 303,
          columnNumber: 21
        }, this),
        totals.percepcionesTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Percepciones:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 305,
            columnNumber: 57
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.percepcionesTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 305,
            columnNumber: 84
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 305,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold text-lg border-t pt-2 mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "TOTAL:" }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 307,
            columnNumber: 96
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.grandTotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
            lineNumber: 307,
            columnNumber: 116
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
          lineNumber: 307,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
        lineNumber: 299,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
      lineNumber: 270,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/compras/pages/ComprasDetailPage.tsx",
    lineNumber: 167,
    columnNumber: 5
  }, this);
};
_s(ComprasDetailPage, "o2HbNENS/JeU4T6/TfE5d43/wbU=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ComprasDetailPage;
var _c;
$RefreshReg$(_c, "ComprasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/compras/pages/ComprasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/compras/pages/ComprasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuRnhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDJCQUEwQztBQUNuRCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYUMsVUFBVUMsZUFBZTtBQUMvQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBQ2xELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyx5QkFBeUI7QUFFM0IsYUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxFQUFFQyxHQUFHLElBQUlwQixVQUEwQjtBQUN6QyxRQUFNcUIsV0FBV3BCLFlBQVk7QUFDN0IsUUFBTSxFQUFFcUIsTUFBTUMsVUFBVUMsU0FBU0MsTUFBTSxJQUFJdEIsWUFBc0JDLHFCQUFxQmdCLEVBQUU7QUFHeEYsUUFBTSxDQUFDTSxZQUFZQyxhQUFhLElBQUloQixTQUFTLEtBQUs7QUFFbEQsUUFBTWlCLFNBQVNsQixRQUFRLE1BQU07QUFDekIsUUFBSSxDQUFDYSxVQUFVO0FBQ1gsYUFBTyxFQUFFTSxVQUFVLEdBQUdDLFVBQVUsR0FBR0MsbUJBQW1CLEdBQUdDLFVBQVUsR0FBR0MsbUJBQW1CLEdBQUdDLFlBQVksRUFBRTtBQUFBLElBQzlHO0FBQ0EsVUFBTUwsV0FBV04sU0FBU1ksT0FBT0MsT0FBTyxDQUFDQyxLQUFLZixTQUFTZSxPQUFPQyxPQUFPaEIsS0FBS2lCLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSztBQUM5RixVQUFNQyxjQUFjakIsU0FBU2tCLGlCQUFpQixJQUFJQyxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLGFBQWEsQ0FBQztBQUM5RSxVQUFNQyxjQUFjdEIsU0FBU2tCLGlCQUFpQixJQUFJQyxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLGFBQWEsQ0FBQztBQUM5RSxVQUFNZCxXQUFXVSxXQUFXSixPQUFPLENBQUNDLEtBQUtTLFFBQVFULE9BQU9DLE9BQU9RLElBQUlDLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDbkYsVUFBTWhCLG9CQUFvQmMsV0FBV1QsT0FBTyxDQUFDQyxLQUFLUyxRQUFRVCxPQUFPQyxPQUFPUSxJQUFJQyxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQzVGLFVBQU1mLFdBQVdULFNBQVNTLFlBQVk7QUFDdEMsVUFBTUMsb0JBQW9CVixTQUFTVSxxQkFBcUI7QUFDeEQsVUFBTUMsYUFBYUwsV0FBV0csV0FBV0Msb0JBQW9CSCxXQUFXQztBQUN4RSxXQUFPLEVBQUVGLFVBQVVDLFVBQVVDLG1CQUFtQkMsVUFBVUMsbUJBQW1CQyxXQUFXO0FBQUEsRUFDNUYsR0FBRyxDQUFDWCxRQUFRLENBQUM7QUFHYixRQUFNeUIsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQ3pCLFNBQVU7QUFFZixVQUFNMEIsVUFBVXJDLGdCQUFnQjtBQUNoQyxRQUFJLENBQUNxQyxTQUFTO0FBQ1ZsQyxZQUFNVSxNQUFNLDhDQUE4QztBQUMxRDtBQUFBLElBQ0o7QUFFQUUsa0JBQWMsSUFBSTtBQUNsQixRQUFJO0FBQ0EsWUFBTWQsaUJBQWlCb0MsU0FBUyxjQUFjMUIsU0FBU0gsRUFBRSxNQUFNO0FBQUEsSUFDbkUsU0FBU0ssUUFBTztBQUNaLFVBQUksQ0FBQ3dCLFFBQVFDLE9BQU9DLE9BQVFGLFNBQVFDLE9BQU9FLE1BQU07QUFDakRDLGNBQVE1QixNQUFNLDRCQUE0QkEsTUFBSztBQUMvQ1YsWUFBTVUsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dFLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNLENBQUMyQixlQUFlQyxnQkFBZ0IsSUFBSTVDLFNBQVMsS0FBSztBQUN4RCxRQUFNNkMsaUJBQWlCLFlBQVk7QUFDL0IsUUFBSSxDQUFDakMsVUFBVUgsR0FBSTtBQUVuQixVQUFNNkIsVUFBVXJDLGdCQUFnQjtBQUNoQyxRQUFJLENBQUNxQyxTQUFTO0FBQ1ZsQyxZQUFNVSxNQUFNLGtEQUFrRDtBQUM5RDtBQUFBLElBQ0o7QUFFQThCLHFCQUFpQixJQUFJO0FBQ3JCLFFBQUk7QUFDQSxZQUFNMUMsaUJBQWlCb0MsU0FBUyxjQUFjMUIsU0FBU0gsRUFBRSxPQUFPO0FBQUEsSUFDcEUsU0FBU0ssUUFBTztBQUNaLFVBQUksQ0FBQ3dCLFFBQVFDLE9BQU9DLE9BQVFGLFNBQVFDLE9BQU9FLE1BQU07QUFDakRDLGNBQVE1QixNQUFNLGdDQUFnQ0EsTUFBSztBQUNuRFYsWUFBTVUsTUFBTSxzQ0FBc0M7QUFBQSxJQUN0RCxVQUFDO0FBQ0c4Qix1QkFBaUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDSjtBQUlBLE1BQUkvQixRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLFNBQVUsUUFBTyx1QkFBQyxTQUFJLHlDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFFcEQsUUFBTWtDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLE1BQ0lDLE9BQU87QUFBQTtBQUFBLE1BRVBDLFFBQVFBLE1BQ0pwQyxTQUFTcUMsU0FDTDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csSUFBSSxnQkFBZ0JyQyxTQUFTcUMsT0FBT3hDLEVBQUU7QUFBQSxVQUN0QyxXQUFVO0FBQUEsVUFFVEcsbUJBQVNxQyxPQUFPQztBQUFBQTtBQUFBQSxRQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQSxJQUVBO0FBQUEsSUFHWjtBQUFBLElBQ0EsRUFBRUgsT0FBTyxtQkFBbUJuQixPQUFPOUIsWUFBWWMsU0FBU3VDLGVBQWUsTUFBTSxFQUFFO0FBQUEsSUFDL0UsRUFBRUosT0FBTyxpQkFBaUJuQixPQUFPaEIsU0FBU3dDLGdCQUFnQjtBQUFBLElBQzFELEVBQUVMLE9BQU8sU0FBU25CLE9BQU9oQixTQUFTeUMsVUFBVSxJQUFJO0FBQUEsSUFDaEQsRUFBRU4sT0FBTyxVQUFVbkIsT0FBT2hCLFNBQVMwQyxpQkFBaUIsTUFBTTtBQUFBLElBQzFELEVBQUVQLE9BQU8sZUFBZW5CLE9BQU85QixZQUFZYyxTQUFTMkMsVUFBVSxNQUFNLEVBQUU7QUFBQSxJQUN0RSxFQUFFUixPQUFPLFNBQVNuQixPQUFPOUIsWUFBWWMsU0FBUzRDLFNBQVMsVUFBVSxFQUFFO0FBQUEsSUFDbkU7QUFBQSxNQUNJVCxPQUFPO0FBQUE7QUFBQSxNQUVQQyxRQUFRQSxNQUNKcEMsU0FBUzZDLGdCQUFpQjdDLFNBQVM2QyxnQkFDL0I7QUFBQSxJQUdaO0FBQUEsSUFDQSxFQUFFVixPQUFPLGtCQUFrQm5CLE9BQU85QixZQUFZYyxTQUFTOEMsZUFBZSxVQUFVLEVBQUU7QUFBQSxJQUNsRjtBQUFBLE1BQ0lYLE9BQU87QUFBQSxNQUNQbkIsT0FBT2hCLFNBQVMrQyxvQkFBb0IvQyxTQUFTZ0Qsa0JBQ3ZDLEdBQUdoRCxTQUFTK0MsZ0JBQWdCLElBQUkvQyxTQUFTZ0QsZUFBZSxLQUN4RDtBQUFBLElBQ1Y7QUFBQTtBQUFBLElBRUE7QUFBQSxNQUNJYixPQUFPO0FBQUEsTUFDUEMsUUFBUUEsTUFDSnBDLFNBQVNpRCxxQkFDTDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBU2hCO0FBQUFBLFVBQ1QsVUFBVUY7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVEEsMEJBQWdCLGdCQUFnQjtBQUFBO0FBQUEsUUFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0EsSUFFQTtBQUFBLElBR1o7QUFBQSxFQUFDO0FBR0wsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNERBQ1g7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsVUFBb0IvQixTQUFTSDtBQUFBQSxhQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFDcEYsdUJBQUMsT0FBRSxXQUFXLDhCQUE4QkcsU0FBU2tELFNBQVMsbUJBQW1CLGNBQWMsSUFDMUZsRCxtQkFBU2tELFNBQVMsbUJBQW1CLHFCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsK0JBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNcEQsU0FBU0osa0JBQWtCYixvQkFBb0JzRSxTQUFTLENBQUMsR0FBRyxXQUFVLDhJQUN2RztBQUFBLGlDQUFDLGVBQVksV0FBVSx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUFHO0FBQUEsYUFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUzFCO0FBQUFBLFlBQ1QsVUFBVXRCO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBO0FBQUFBLDJCQUNHLHVCQUFDLGFBQVUsV0FBVSxxQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0QsSUFFdEQsdUJBQUMsV0FBUSxXQUFVLHdCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQzFDO0FBQUE7QUFBQTtBQUFBLFVBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxRQUVBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUwsU0FBUyxHQUFHakIsb0JBQW9Cc0UsU0FBUyxJQUFJbkQsU0FBU0gsRUFBRSxTQUFTLEdBQUcsV0FBVSxzSkFDL0c7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFBRztBQUFBLGFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1gsaUNBQUMsUUFBRyxXQUFVLG1EQUVUcUMsc0JBQVlrQjtBQUFBQSxNQUFJLENBQUFDLFdBQ2IsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBcUNBLGlCQUFPbEIsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFLHVCQUFDLFFBQUcsV0FBVSw4QkFDVCxzQkFBWWtCLFNBQVVBLE9BQU9qQixTQUFTaUIsT0FBT2pCLE9BQU8sSUFBSSxPQUFRaUIsT0FBT3JDLFNBRDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSk1xQyxPQUFPbEIsT0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsSUFDSCxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBR0NuQyxTQUFTc0QsWUFBWXRELFNBQVNzRCxTQUFTQyxTQUFTLEtBQzdDLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0Msc0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUN4RSx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELDJCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsYUFKcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p2RCxtQkFBU3NELFNBQVNGO0FBQUFBLFVBQUksQ0FBQ0ksU0FDcEIsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FDVEEsZUFBS0MsYUFDRix1QkFBQyxRQUFLLElBQUksY0FBY0QsS0FBS0MsVUFBVSxJQUFJLFdBQVUseURBQXlERCxlQUFLRSxnQkFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0ksSUFFaElGLEtBQUtFLGdCQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENGLGVBQUtHLFlBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUUsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3pFLHNCQUFZc0UsS0FBS0ksWUFBWSxVQUFVLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckcsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzFFLHNCQUFZNkIsT0FBT3lDLEtBQUtHLFFBQVEsSUFBSTVDLE9BQU95QyxLQUFLSSxVQUFVLEdBQUcsVUFBVSxLQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSTtBQUFBLGVBVmhJSixLQUFLM0QsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsUUFDSCxLQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkEsS0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLFNBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUdKLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0Msa0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxNQUNwRSx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsK0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxhQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWkcsbUJBQVNZLE9BQU93QztBQUFBQSxVQUFJLENBQUNyRCxNQUFNOEQsVUFDeEIsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FBOEM5RCxlQUFLK0Qsc0JBQXNCLFdBQVcvRCxLQUFLZ0UseUJBQXlCLE1BQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1JO0FBQUEsWUFDbkksdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzdFLHNCQUFZYSxLQUFLaUIsT0FBTyxVQUFVLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsZUFGM0ZqQixLQUFLRixNQUFNZ0UsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0gsS0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQSxLQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyxtQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3BFN0QsU0FBU2tCLGlCQUFpQmxCLFNBQVNrQixjQUFjcUMsU0FBUyxJQUN2RCx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsWUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p2RCxtQkFBU2tCLGNBQWNrQztBQUFBQSxZQUFJLENBQUM3QixLQUFLc0MsVUFDOUIsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSw4Q0FBOEN0QyxjQUFJeUMsWUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUU7QUFBQSxjQUN6RSx1QkFBQyxRQUFHLFdBQVUsOENBQThDdkUsNEJBQWtCOEIsR0FBRyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRjtBQUFBLGNBQ25GLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENyQyxzQkFBWXFDLElBQUlDLFFBQVEsVUFBVSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRztBQUFBLGlCQUgzRkQsSUFBSTFCLE1BQU1nRSxPQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsVUFDSCxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkEsSUFFQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDBEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsV0F4QjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyRUFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSxpQ0FBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNM0Usc0JBQVltQixPQUFPQyxVQUFVLFVBQVUsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxhQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRIO0FBQUEsUUFDNUgsdUJBQUMsU0FBSSxXQUFVLDhDQUE2QztBQUFBLGlDQUFDLFVBQUssOENBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNcEIsc0JBQVltQixPQUFPSyxtQkFBbUIsVUFBVSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBQWpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0s7QUFBQSxRQUN4Syx1QkFBQyxTQUFJLFdBQVUsNkNBQTRDO0FBQUEsaUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQUd4QixZQUFZbUIsT0FBT0ksVUFBVSxVQUFVO0FBQUEsZUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRJO0FBQUEsUUFDNUksdUJBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNdkIsc0JBQVltQixPQUFPRSxVQUFVLFVBQVUsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxhQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZIO0FBQUEsUUFDNUhGLE9BQU9HLG9CQUFvQixLQUN4Qix1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQU10QixzQkFBWW1CLE9BQU9HLG1CQUFtQixVQUFVLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsYUFBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5STtBQUFBLFFBRTdJLHVCQUFDLFNBQUksV0FBVSw2REFBNEQ7QUFBQSxpQ0FBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNdEIsc0JBQVltQixPQUFPTSxZQUFZLFVBQVUsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdKO0FBQUEsV0FSNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0F0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLE9BOUlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErSUE7QUFFUjtBQUFFZixHQXZSV0QsbUJBQWlCO0FBQUEsVUFDWGxCLFdBQ0VDLGFBQzBCRSxXQUFXO0FBQUE7QUFBQXFGLEtBSDdDdEU7QUFBaUIsSUFBQXNFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VDcnVkSXRlbSIsImNvbXByYXNNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QZW5jaWwiLCJJb1ByaW50IiwiZm9ybWF0VmFsdWUiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJiZWdpblBkZlByZXZpZXciLCJmaW5pc2hQZGZQcmV2aWV3IiwiRmFTcGlubmVyIiwidG9hc3QiLCJmb3JtYXRUYXhSYXRlQ2VsbCIsImdldExpc3RSZXR1cm5QYXRoIiwiQ29tcHJhc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJpdGVtIiwicHVyY2hhc2UiLCJsb2FkaW5nIiwiZXJyb3IiLCJpc1ByaW50aW5nIiwic2V0SXNQcmludGluZyIsInRvdGFscyIsInN1YnRvdGFsIiwidGF4VG90YWwiLCJwZXJjZXBjaW9uZXNUb3RhbCIsImRpc2NvdW50Iiwid2l0aG91dHRheF9hbW91bnQiLCJncmFuZFRvdGFsIiwiaXRlbXMiLCJyZWR1Y2UiLCJzdW0iLCJOdW1iZXIiLCJ2YWx1ZSIsInRheGVzVHlwZTEiLCJhcHBsaWVkX3RheGVzIiwiZmlsdGVyIiwidCIsInRheF90eXBlIiwidGF4ZXNUeXBlMiIsInRheCIsImFtb3VudCIsImhhbmRsZVByaW50Iiwic2Vzc2lvbiIsIndpbmRvdyIsImNsb3NlZCIsImNsb3NlIiwiY29uc29sZSIsImlzTG9hZGluZ0ZpbGUiLCJzZXRJc0xvYWRpbmdGaWxlIiwiaGFuZGxlVmlld0ZpbGUiLCJtYWluRGV0YWlscyIsImxhYmVsIiwicmVuZGVyIiwidmVuZG9yIiwibmFtZSIsInB1cmNoYXNlX2RhdGUiLCJkb2N1bWVudF9udW1iZXIiLCJzZXJpZXMiLCJkZWxpdmVyeV9ub3RlIiwiZHVlX2RhdGUiLCJiYWxhbmNlIiwiY3VycmVuY3lfbmFtZSIsImV4Y2hhbmdlX3JhdGUiLCJpbXB1dGF0aW9uX21vbnRoIiwiaW1wdXRhdGlvbl95ZWFyIiwiaW52b2ljZV9pbWFnZV9wYXRoIiwic3RhdHVzIiwiYmFzZVJvdXRlIiwibWFwIiwiZGV0YWlsIiwicHJvZHVjdHMiLCJsZW5ndGgiLCJwcm9kIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfbmFtZSIsInF1YW50aXR5IiwicHJpY2VfY29zdCIsImluZGV4IiwiY2hhcnRfYWNjb3VudF9uYW1lIiwibGVnYWN5X2NoYXJ0X2FjY291bnRfY29kZSIsInRheF9uYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcHJhc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgY29tcHJhc01vZHVsZUNvbmZpZywgdHlwZSBQdXJjaGFzZSB9IGZyb20gJy4uL2NvbXByYXMuY29uZmlnJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9QZW5jaWwsIElvUHJpbnQgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgYmVnaW5QZGZQcmV2aWV3LCBmaW5pc2hQZGZQcmV2aWV3IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvYmxvYkhlbHBlcic7XG5pbXBvcnQgeyBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGZvcm1hdFRheFJhdGVDZWxsIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdGF4RGlzcGxheSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IENvbXByYXNEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBpdGVtOiBwdXJjaGFzZSwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFB1cmNoYXNlPihjb21wcmFzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICAvLyA2LiBOdWV2byBlc3RhZG8gcGFyYSBlbCBib3TDs24gZGUgaW1wcmltaXJcbiAgICBjb25zdCBbaXNQcmludGluZywgc2V0SXNQcmludGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCB0b3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFwdXJjaGFzZSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgc3VidG90YWw6IDAsIHRheFRvdGFsOiAwLCBwZXJjZXBjaW9uZXNUb3RhbDogMCwgZGlzY291bnQ6IDAsIHdpdGhvdXR0YXhfYW1vdW50OiAwLCBncmFuZFRvdGFsOiAwIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBwdXJjaGFzZS5pdGVtcz8ucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS52YWx1ZSkgfHwgMCksIDApIHx8IDA7XG4gICAgICAgIGNvbnN0IHRheGVzVHlwZTEgPSAocHVyY2hhc2UuYXBwbGllZF90YXhlcyB8fCBbXSkuZmlsdGVyKHQgPT4gdC50YXhfdHlwZSA9PT0gMSk7XG4gICAgICAgIGNvbnN0IHRheGVzVHlwZTIgPSAocHVyY2hhc2UuYXBwbGllZF90YXhlcyB8fCBbXSkuZmlsdGVyKHQgPT4gdC50YXhfdHlwZSA9PT0gMik7XG4gICAgICAgIGNvbnN0IHRheFRvdGFsID0gdGF4ZXNUeXBlMS5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyAoTnVtYmVyKHRheC5hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3QgcGVyY2VwY2lvbmVzVG90YWwgPSB0YXhlc1R5cGUyLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIChOdW1iZXIodGF4LmFtb3VudCkgfHwgMCksIDApO1xuICAgICAgICBjb25zdCBkaXNjb3VudCA9IHB1cmNoYXNlLmRpc2NvdW50IHx8IDA7XG4gICAgICAgIGNvbnN0IHdpdGhvdXR0YXhfYW1vdW50ID0gcHVyY2hhc2Uud2l0aG91dHRheF9hbW91bnQgfHwgMDtcbiAgICAgICAgY29uc3QgZ3JhbmRUb3RhbCA9IHN1YnRvdGFsIC0gZGlzY291bnQgKyB3aXRob3V0dGF4X2Ftb3VudCArIHRheFRvdGFsICsgcGVyY2VwY2lvbmVzVG90YWw7XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0YXhUb3RhbCwgcGVyY2VwY2lvbmVzVG90YWwsIGRpc2NvdW50LCB3aXRob3V0dGF4X2Ftb3VudCwgZ3JhbmRUb3RhbCB9O1xuICAgIH0sIFtwdXJjaGFzZV0pO1xuXG4gICAgLy8gNy4gTnVldm8gaGFuZGxlciBwYXJhIGdlbmVyYXIgeSBhYnJpciBlbCBQREZcbiAgICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFwdXJjaGFzZSkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBQREYuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc1ByaW50aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZmluaXNoUGRmUHJldmlldyhzZXNzaW9uLCBgL3B1cmNoYXNlcy8ke3B1cmNoYXNlLmlkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGdlbmVyYXIgZWwgUERGOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBnZW5lcmFyIGVsIGNvbXByb2JhbnRlIFBERi4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzUHJpbnRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSBIYW5kbGVyIHBhcmEgYWJyaXIgZWwgYXJjaGl2byBhZGp1bnRvXG4gICAgY29uc3QgW2lzTG9hZGluZ0ZpbGUsIHNldElzTG9hZGluZ0ZpbGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGhhbmRsZVZpZXdGaWxlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXB1cmNoYXNlPy5pZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBhcmNoaXZvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNMb2FkaW5nRmlsZSh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9wdXJjaGFzZXMvJHtwdXJjaGFzZS5pZH0vZmlsZWApO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgb2J0ZW5lciBlbCBhcmNoaXZvOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBhYnJpciBlbCBhcmNoaXZvIGFkanVudG8uJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc0xvYWRpbmdGaWxlKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cblxuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghcHVyY2hhc2UpIHJldHVybiA8ZGl2Pk5vIHNlIGVuY29udHLDsyBsYSBjb21wcmEuPC9kaXY+O1xuXG4gICAgY29uc3QgbWFpbkRldGFpbHMgPSBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiAnUHJvdmVlZG9yJyxcbiAgICAgICAgICAgIC8vIOKchSBDQU1CSU86IENvbnZlcnRpZG8gYSAncmVuZGVyJyBwYXJhIGHDsWFkaXIgZWwgTGlua1xuICAgICAgICAgICAgcmVuZGVyOiAoKSA9PiAoXG4gICAgICAgICAgICAgICAgcHVyY2hhc2UudmVuZG9yID8gKFxuICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvcHJvdmVlZG9yZXMvJHtwdXJjaGFzZS52ZW5kb3IuaWR9YH0gLy8gQXN1bW8gcnV0YSAvcHJvdmVlZG9yZXMvOmlkXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwdXJjaGFzZS52ZW5kb3IubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICdOL0EnXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuICAgICAgICB7IGxhYmVsOiAnRmVjaGEgZGUgQ29tcHJhJywgdmFsdWU6IGZvcm1hdFZhbHVlKHB1cmNoYXNlLnB1cmNoYXNlX2RhdGUsICdkYXRlJykgfSxcbiAgICAgICAgeyBsYWJlbDogJ07CuiBkZSBGYWN0dXJhJywgdmFsdWU6IHB1cmNoYXNlLmRvY3VtZW50X251bWJlciB9LFxuICAgICAgICB7IGxhYmVsOiAnU2VyaWUnLCB2YWx1ZTogcHVyY2hhc2Uuc2VyaWVzIHx8ICctJyB9LFxuICAgICAgICB7IGxhYmVsOiAnUmVtaXRvJywgdmFsdWU6IHB1cmNoYXNlLmRlbGl2ZXJ5X25vdGUgfHwgJ04vQScgfSxcbiAgICAgICAgeyBsYWJlbDogJ1ZlbmNpbWllbnRvJywgdmFsdWU6IGZvcm1hdFZhbHVlKHB1cmNoYXNlLmR1ZV9kYXRlLCAnZGF0ZScpIH0sXG4gICAgICAgIHsgbGFiZWw6ICdTYWxkbycsIHZhbHVlOiBmb3JtYXRWYWx1ZShwdXJjaGFzZS5iYWxhbmNlLCAnY3VycmVuY3knKSB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBsYWJlbDogJ01vbmVkYScsXG4gICAgICAgICAgICAvLyDinIUgQ0FNQklPOiBDb252ZXJ0aWRvIGEgJ3JlbmRlcicgcGFyYSBhw7FhZGlyIGVsIExpbmtcbiAgICAgICAgICAgIHJlbmRlcjogKCkgPT4gKFxuICAgICAgICAgICAgICAgIHB1cmNoYXNlLmN1cnJlbmN5X25hbWUgPyAocHVyY2hhc2UuY3VycmVuY3lfbmFtZSkgOiAoXG4gICAgICAgICAgICAgICAgICAgICdOL0EnXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuICAgICAgICB7IGxhYmVsOiAnVGlwbyBkZSBjYW1iaW8nLCB2YWx1ZTogZm9ybWF0VmFsdWUocHVyY2hhc2UuZXhjaGFuZ2VfcmF0ZSwgJ2N1cnJlbmN5JykgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgbGFiZWw6ICdNZXMvYcOxbyBkZSBpbXB1dGFjacOzbicsXG4gICAgICAgICAgICB2YWx1ZTogcHVyY2hhc2UuaW1wdXRhdGlvbl9tb250aCAmJiBwdXJjaGFzZS5pbXB1dGF0aW9uX3llYXJcbiAgICAgICAgICAgICAgICA/IGAke3B1cmNoYXNlLmltcHV0YXRpb25fbW9udGh9LyR7cHVyY2hhc2UuaW1wdXRhdGlvbl95ZWFyfWBcbiAgICAgICAgICAgICAgICA6ICdOL0EnLFxuICAgICAgICB9LFxuICAgICAgICAvLyDinIUgMi4gQ0FNUE8gJ0ZhY3R1cmEgQWRqdW50YScgdXNhbmRvIGdldEZpbGVCbG9iXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiAnRmFjdHVyYSBBZGp1bnRhJyxcbiAgICAgICAgICAgIHJlbmRlcjogKCkgPT4gKFxuICAgICAgICAgICAgICAgIHB1cmNoYXNlLmludm9pY2VfaW1hZ2VfcGF0aCA/IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVWaWV3RmlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmdGaWxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmUgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itd2FpdFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmdGaWxlID8gJ0NhcmdhbmRvLi4uJyA6ICdWZXIgQWRqdW50byAoSlBHL1BERiknfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAnTi9BJ1xuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IGJvcmRlci1iIHNtOmZsZXggc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkRldGFsbGUgZGUgQ29tcHJhICN7cHVyY2hhc2UuaWR9PC9oMT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgbXQtMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHtwdXJjaGFzZS5zdGF0dXMgPyAndGV4dC1ncmVlbi02MDAnIDogJ3RleHQtcmVkLTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cHVyY2hhc2Uuc3RhdHVzID8gJ0VzdGFkbzogQWN0aXZhJyA6ICdFc3RhZG86IEFudWxhZGEnfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC0zIHNwYWNlLXgtMyBzbTptdC0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGNvbXByYXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSl9IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvQXJyb3dCYWNrIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+IFZvbHZlclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1ByaW50aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQcmludGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMSBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9QcmludCBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIEltcHJpbWlyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAke2NvbXByYXNNb2R1bGVDb25maWcuYmFzZVJvdXRlfS8ke3B1cmNoYXNlLmlkfS9lZGl0YXJgKX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb1BlbmNpbCBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiAvPiBFZGl0YXJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAteC00IGdhcC15LTYgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIOKchSBDQU1CSU86IEFjdHVhbGl6YWRvIGVsIGxvb3AgZGUgcmVuZGVyaXphZG8gKi99XG4gICAgICAgICAgICAgICAgICAgIHttYWluRGV0YWlscy5tYXAoZGV0YWlsID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkZXRhaWwubGFiZWx9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj57ZGV0YWlsLmxhYmVsfTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsncmVuZGVyJyBpbiBkZXRhaWwgPyAoZGV0YWlsLnJlbmRlciA/IGRldGFpbC5yZW5kZXIoKSA6IG51bGwpIDogZGV0YWlsLnZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7Lyog4pyFIDQuIE5VRVZPIEJMT1FVRTogVGFibGEgZGUgUHJvZHVjdG9zICovfVxuICAgICAgICAgICAge3B1cmNoYXNlLnByb2R1Y3RzICYmIHB1cmNoYXNlLnByb2R1Y3RzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5Qcm9kdWN0b3MgZGUgbGEgQ29tcHJhPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+UHJvZHVjdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DYW50aWRhZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNvc3RvIFVuaXQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+VG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHVyY2hhc2UucHJvZHVjdHMubWFwKChwcm9kKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtwcm9kLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kLnByb2R1Y3RfaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9hcnRpY3Vsb3MvJHtwcm9kLnByb2R1Y3RfaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj57cHJvZC5wcm9kdWN0X25hbWV9PC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZC5wcm9kdWN0X25hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57cHJvZC5xdWFudGl0eX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUocHJvZC5wcmljZV9jb3N0LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUoTnVtYmVyKHByb2QucXVhbnRpdHkpICogTnVtYmVyKHByb2QucHJpY2VfY29zdCksICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj7DjXRlbXMgZGUgbGEgQ29tcHJhPC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkN1ZW50YSBDb250YWJsZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+VmFsb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwdXJjaGFzZS5pdGVtcz8ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNtOnBsLTZcIj57aXRlbS5jaGFydF9hY2NvdW50X25hbWUgfHwgYEPDs2RpZ286ICR7aXRlbS5sZWdhY3lfY2hhcnRfYWNjb3VudF9jb2RlfWB9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUoaXRlbS52YWx1ZSwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIHAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIEFwbGljYWRvczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIHtwdXJjaGFzZS5hcHBsaWVkX3RheGVzICYmIHB1cmNoYXNlLmFwcGxpZWRfdGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5JbXB1ZXN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5UYXNhICglKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHVyY2hhc2UuYXBwbGllZF90YXhlcy5tYXAoKHRheCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0YXguaWQgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+e3RheC50YXhfbmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFRheFJhdGVDZWxsKHRheCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBpbXB1ZXN0b3MgYXBsaWNhZG9zIGVuIGVzdGEgY29tcHJhLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWdyYXktNTAgYm9yZGVyIHJvdW5kZWQtbGcgc3BhY2UteS0yIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+PHNwYW4+U3VidG90YWw6PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLnN1YnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+PHNwYW4+VmFsb3IgTm8gR3JhdmFkbyAobm8gZ3JhdmFkbyk6PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLndpdGhvdXR0YXhfYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj48c3Bhbj5EZXNjdWVudG86PC9zcGFuPiA8c3Bhbj4tIHtmb3JtYXRWYWx1ZSh0b3RhbHMuZGlzY291bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+PHNwYW4+SW1wdWVzdG9zOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy50YXhUb3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7dG90YWxzLnBlcmNlcGNpb25lc1RvdGFsID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc21cIj48c3Bhbj5QZXJjZXBjaW9uZXM6PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLnBlcmNlcGNpb25lc1RvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gZm9udC1ib2xkIHRleHQtbGcgYm9yZGVyLXQgcHQtMiBtdC0yXCI+PHNwYW4+VE9UQUw6PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLmdyYW5kVG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jb21wcmFzL3BhZ2VzL0NvbXByYXNEZXRhaWxQYWdlLnRzeCJ9