import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { getAll } from "/src/services/apiService.ts";
import { createValueMapperRenderer } from "/src/utils/renders.tsx";
import {} from "/src/types/appliedTaxes.ts";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { getAllowedInvoiceSeries, resolveInvoiceSeriesForTaxChange } from "/src/utils/invoiceSeries.ts";
const loadDistricts = async () => {
  const response = await getAll("districts");
  return response.data.map((district) => ({
    value: district.id,
    label: district.name
  }));
};
const taxConditionOptions = [
  { value: "I", label: "IVA Responsable Inscripto" },
  { value: "M", label: "Monotributista" },
  { value: "E", label: "Exento" },
  { value: "C", label: "Consumidor Final" },
  { value: "N", label: "No Responsable" },
  { value: "X", label: "No tributable" }
];
const renderTaxCondition = createValueMapperRenderer(
  taxConditionOptions,
  "legacy_tax_condition"
);
const typeRetentionOptions = [
  { value: "078", label: "078" },
  { value: "094", label: "094" },
  { value: "116", label: "116" },
  { value: "119", label: "119" }
];
const renderTypeRetention = createValueMapperRenderer(
  typeRetentionOptions,
  "vendor_type"
);
export const proveedoresModuleConfig = {
  endpoint: "vendors",
  moduleName: "Proveedor",
  moduleNamePlural: "Proveedores",
  baseRoute: "/proveedores",
  detail: {
    displayNameKey: "name"
  },
  listItemCodeKey: "vendor_code",
  listItemNameKey: "name",
  list: {
    columns: [
      { header: "Código del Proveedor", accessor: "vendor_code" },
      { header: "Razón Social", accessor: "name" },
      { header: "CUIT", accessor: "cuit", render: (item) => item.cuit || "-" },
      {
        header: "Condición IVA",
        accessor: "legacy_tax_condition",
        render: renderTaxCondition
      },
      { header: "Serie de Factura", accessor: "serie", render: (item) => item.serie || "-" },
      { header: "Contacto", accessor: "contact_person", render: (item) => item.contact_person || "-" },
      { header: "Teléfono", accessor: "phone", render: (item) => item.phone || "-" },
      { header: "Email", accessor: "email", render: (item) => item.email || "-" },
      // --- Grupo: Domicilio ---
      { header: "Domicilio", accessor: "address", render: (item) => item.address || "-" },
      { header: "Localidad", accessor: "city", render: (item) => item.city || "-" },
      // --- Grupo: Datos Impositivos y de Pago ---
      { header: "Cond. Pago", accessor: "payment_condition", render: (item) => item.payment_condition != null ? `${item.payment_condition} días` : "-" },
      { header: "Cuenta Contable", accessor: "account_code", render: (item) => item.account_name || item.account_code || "-" },
      {
        header: "Retenciones sobre Ganancias",
        accessor: "do_not_retain",
        render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.do_not_retain ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.do_not_retain ? "Sí" : "No" }, void 0, false, {
          fileName: "/app/src/features/proveedores/proveedores.config.tsx",
          lineNumber: 148,
          columnNumber: 7
        }, this)
      },
      // --- Grupo: Información Adicional ---
      {
        header: "Tipo retención",
        accessor: "vendor_type",
        render: renderTypeRetention
      },
      {
        header: "Es Bolsa",
        accessor: "is_bolsa",
        render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.is_bolsa ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.is_bolsa ? "Sí" : "No" }, void 0, false, {
          fileName: "/app/src/features/proveedores/proveedores.config.tsx",
          lineNumber: 164,
          columnNumber: 7
        }, this)
      }
    ]
  },
  form: {
    block: [{
      name: "Datos del proveedor",
      fields: [
        // --- Grupo: Datos Principales ---
        { name: "name", label: "Razón Social", type: "text", mandatory: true },
        { name: "cuit", label: "CUIT", type: "text", mandatory: (formData) => formData.legacy_tax_condition !== "X", placeholder: "Ej: 30-12345678-9", mask: "cuit" },
        {
          name: "legacy_tax_condition",
          label: "Condición IVA",
          type: "select",
          options: taxConditionOptions,
          render: renderTaxCondition,
          onChangeEffect: (newValue, currentData, updateFormData) => {
            updateFormData({
              serie: resolveInvoiceSeriesForTaxChange(String(newValue), currentData.serie, { includeNoTributable: true })
            });
          }
        },
        {
          name: "serie",
          label: "Serie de Factura",
          type: "select",
          getOptions: (fd) => getAllowedInvoiceSeries(fd.legacy_tax_condition, { includeNoTributable: true }).map((s) => ({ value: s, label: s })),
          readonly: (fd) => getAllowedInvoiceSeries(fd.legacy_tax_condition, { includeNoTributable: true }).length <= 1,
          render: (item) => item.serie || "-"
        },
        { name: "contact_person", label: "Atención / Contacto", type: "text" },
        { name: "phone", label: "Teléfono Principal", type: "text" },
        { name: "phone2", label: "Teléfono Secundario", type: "text" },
        { name: "email", label: "Email", type: "email" }
      ]
    }, {
      name: "Dirección",
      fields: [
        // --- Grupo: Domicilio ---
        { name: "address", label: "Domicilio", type: "text" },
        { name: "zip", label: "Código Postal", type: "text" },
        { name: "city", label: "Localidad", type: "text" },
        {
          name: "district",
          label: "Provincia",
          type: "select",
          loadOptions: loadDistricts,
          render: (item) => item.district_name?.toString() || "-"
        }
      ]
    }, {
      name: "Otros datos",
      fields: [
        // --- Grupo: Datos Impositivos y de Pago ---
        {
          name: "payment_condition",
          label: "Condición de Pago (días)",
          type: "number",
          placeholder: "Ej: 30",
          render: (item) => item.payment_condition != null ? `${item.payment_condition} días` : "-"
        },
        {
          name: "account_id",
          label: "Cuenta Contable",
          type: "relational",
          relationalConfig: {
            moduleConfig: planDeCuentasModuleConfig,
            codeField: "account_code",
            nameField: "account_name"
          },
          render: (item) => item.account_name || item.account_code || "-"
        },
        {
          name: "do_not_retain",
          label: "Retenciones sobre Ganancias",
          type: "select",
          options: [
            { value: "0", label: "No" },
            { value: "1", label: "Si" }
          ],
          valueType: "boolean",
          render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.do_not_retain ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.do_not_retain ? "Sí" : "No" }, void 0, false, {
            fileName: "/app/src/features/proveedores/proveedores.config.tsx",
            lineNumber: 242,
            columnNumber: 9
          }, this)
        },
        // --- Grupo: Información Adicional ---
        {
          label: "Tipo retención",
          type: "select",
          options: typeRetentionOptions,
          name: "vendor_type",
          render: renderTypeRetention
        },
        { name: "concept_code", label: "Código de Concepto", type: "text" },
        { name: "observations", label: "Observaciones", type: "text" }
      ]
    }, {
      name: "Información de pagos",
      fields: [
        { name: "payment_contact_name", label: "Contacto para pagos", type: "text" },
        {
          name: "payment_contact_email",
          label: "Email",
          type: "email",
          render: (item) => {
            const email = item.payment_contact_email;
            if (!email) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
              fileName: "/app/src/features/proveedores/proveedores.config.tsx",
              lineNumber: 268,
              columnNumber: 30
            }, this);
            return /* @__PURE__ */ jsxDEV("a", { href: `mailto:${email}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: email }, void 0, false, {
              fileName: "/app/src/features/proveedores/proveedores.config.tsx",
              lineNumber: 270,
              columnNumber: 13
            }, this);
          }
        },
        { name: "payment_contact_phone", label: "Teléfono", type: "text" },
        {
          name: "payment_portal_url",
          label: "URL portal de pagos",
          type: "text",
          render: (item) => {
            const url = item.payment_portal_url;
            if (!url) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
              fileName: "/app/src/features/proveedores/proveedores.config.tsx",
              lineNumber: 281,
              columnNumber: 28
            }, this);
            return /* @__PURE__ */ jsxDEV("a", { href: url, target: "_blank", rel: "noopener noreferrer", className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: url }, void 0, false, {
              fileName: "/app/src/features/proveedores/proveedores.config.tsx",
              lineNumber: 283,
              columnNumber: 13
            }, this);
          }
        },
        { name: "payment_portal_username", label: "Usuario portal de pagos", type: "text" },
        { name: "payment_portal_password", label: "Clave portal de pagos", type: "text" }
      ]
    }]
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUpvQjtBQW5KcEIsU0FBU0EsY0FBYztBQUV2QixTQUFTQyxpQ0FBaUM7QUFDMUMsZUFBNkM7QUFDN0MsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLHlCQUF5QkMsd0NBQXdDO0FBZ0UxRSxNQUFNQyxnQkFBK0IsWUFBWTtBQUc3QyxRQUFNQyxXQUFXLE1BQU1OLE9BQXFDLFdBQVc7QUFDdkUsU0FBT00sU0FBU0MsS0FBS0MsSUFBSSxDQUFBQyxjQUFhO0FBQUEsSUFDbENDLE9BQU9ELFNBQVNFO0FBQUFBLElBQ2hCQyxPQUFPSCxTQUFTSTtBQUFBQSxFQUNwQixFQUFFO0FBQ047QUFFQSxNQUFNQyxzQkFBc0I7QUFBQSxFQUN4QixFQUFFSixPQUFPLEtBQUtFLE9BQU8sNEJBQTRCO0FBQUEsRUFDakQsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLGlCQUFpQjtBQUFBLEVBQ3RDLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxTQUFTO0FBQUEsRUFDOUIsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLG1CQUFtQjtBQUFBLEVBQ3hDLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxpQkFBaUI7QUFBQSxFQUN0QyxFQUFFRixPQUFPLEtBQUtFLE9BQU8sZ0JBQWdCO0FBQUM7QUFJMUMsTUFBTUcscUJBQXFCZDtBQUFBQSxFQUN2QmE7QUFBQUEsRUFDQTtBQUNKO0FBRUEsTUFBTUUsdUJBQXVCO0FBQUEsRUFDekIsRUFBRU4sT0FBTyxPQUFPRSxPQUFPLE1BQU07QUFBQSxFQUM3QixFQUFFRixPQUFPLE9BQU9FLE9BQU8sTUFBTTtBQUFBLEVBQzdCLEVBQUVGLE9BQU8sT0FBT0UsT0FBTyxNQUFNO0FBQUEsRUFDN0IsRUFBRUYsT0FBTyxPQUFPRSxPQUFPLE1BQU07QUFBQztBQUlsQyxNQUFNSyxzQkFBc0JoQjtBQUFBQSxFQUN4QmU7QUFBQUEsRUFDQTtBQUNKO0FBR08sYUFBTUUsMEJBQW1EO0FBQUEsRUFDNURDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsa0JBQWtCO0FBQUEsRUFDbEJDLFdBQVc7QUFBQSxFQUVYQyxRQUFRO0FBQUEsSUFDSkMsZ0JBQWdCO0FBQUEsRUFDcEI7QUFBQSxFQUNBQyxpQkFBaUI7QUFBQSxFQUNqQkMsaUJBQWlCO0FBQUEsRUFDakJDLE1BQU07QUFBQSxJQUNGQyxTQUFTO0FBQUEsTUFFTCxFQUFFQyxRQUFRLHdCQUF3QkMsVUFBVSxjQUFjO0FBQUEsTUFDMUQsRUFBRUQsUUFBUSxnQkFBZ0JDLFVBQVUsT0FBTztBQUFBLE1BQzNDLEVBQUVELFFBQVEsUUFBUUMsVUFBVSxRQUFRQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLQyxRQUFRLElBQUk7QUFBQSxNQUN2RTtBQUFBLFFBQ0lKLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsUUFBUWhCO0FBQUFBLE1BQ1o7QUFBQSxNQUNBLEVBQUVjLFFBQVEsb0JBQW9CQyxVQUFVLFNBQVNDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtFLFNBQVMsSUFBSTtBQUFBLE1BRXJGLEVBQUVMLFFBQVEsWUFBWUMsVUFBVSxrQkFBa0JDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtHLGtCQUFrQixJQUFJO0FBQUEsTUFDL0YsRUFBRU4sUUFBUSxZQUFZQyxVQUFVLFNBQVNDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtJLFNBQVMsSUFBSTtBQUFBLE1BQzdFLEVBQUVQLFFBQVEsU0FBU0MsVUFBVSxTQUFTQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLSyxTQUFTLElBQUk7QUFBQTtBQUFBLE1BRzFFLEVBQUVSLFFBQVEsYUFBYUMsVUFBVSxXQUFXQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLTSxXQUFXLElBQUk7QUFBQSxNQUNsRixFQUFFVCxRQUFRLGFBQWFDLFVBQVUsUUFBUUMsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS08sUUFBUSxJQUFJO0FBQUE7QUFBQSxNQUc1RSxFQUFFVixRQUFRLGNBQWNDLFVBQVUscUJBQXFCQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLUSxxQkFBcUIsT0FBTyxHQUFHUixLQUFLUSxpQkFBaUIsVUFBVSxJQUFJO0FBQUEsTUFDakosRUFBRVgsUUFBUSxtQkFBbUJDLFVBQVUsZ0JBQWdCQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLUyxnQkFBZ0JULEtBQUtVLGdCQUFnQixJQUFJO0FBQUEsTUFDdkg7QUFBQSxRQUNJYixRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFBLENBQUNDLFNBQ0wsdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUEsS0FBS1csZ0JBQWdCLGdDQUFnQyx5QkFBeUIsSUFDM0pYLGVBQUtXLGdCQUFnQixPQUFPLFFBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRVI7QUFBQTtBQUFBLE1BR0E7QUFBQSxRQUNJZCxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFkO0FBQUFBLE1BQ1o7QUFBQSxNQUNBO0FBQUEsUUFDSVksUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUtZLFdBQVcsZ0NBQWdDLHlCQUF5QixJQUN0SlosZUFBS1ksV0FBVyxPQUFPLFFBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRVI7QUFBQSxJQUFDO0FBQUEsRUFFVDtBQUFBLEVBRUFDLE1BQU07QUFBQSxJQUNGQyxPQUFPLENBQUM7QUFBQSxNQUNKakMsTUFBTTtBQUFBLE1BQ05rQyxRQUFRO0FBQUE7QUFBQSxRQUVKLEVBQUVsQyxNQUFNLFFBQVFELE9BQU8sZ0JBQWdCb0MsTUFBTSxRQUFRQyxXQUFXLEtBQUs7QUFBQSxRQUNyRSxFQUFFcEMsTUFBTSxRQUFRRCxPQUFPLFFBQVFvQyxNQUFNLFFBQVFDLFdBQVdBLENBQUNDLGFBQXdCQSxTQUFTQyx5QkFBeUIsS0FBS0MsYUFBYSxxQkFBcUJDLE1BQU0sT0FBTztBQUFBLFFBQ3ZLO0FBQUEsVUFDSXhDLE1BQU07QUFBQSxVQUF3QkQsT0FBTztBQUFBLFVBQWlCb0MsTUFBTTtBQUFBLFVBQzVETSxTQUFTeEM7QUFBQUEsVUFDVGlCLFFBQVFoQjtBQUFBQSxVQUNSd0MsZ0JBQWdCQSxDQUFDQyxVQUFVQyxhQUFhQyxtQkFBbUI7QUFDdkRBLDJCQUFlO0FBQUEsY0FDWHhCLE9BQU85QixpQ0FBaUN1RCxPQUFPSCxRQUFRLEdBQUdDLFlBQVl2QixPQUFPLEVBQUUwQixxQkFBcUIsS0FBSyxDQUFDO0FBQUEsWUFDOUcsQ0FBQztBQUFBLFVBQ0w7QUFBQSxRQUNKO0FBQUEsUUFDQTtBQUFBLFVBQ0kvQyxNQUFNO0FBQUEsVUFDTkQsT0FBTztBQUFBLFVBQ1BvQyxNQUFNO0FBQUEsVUFDTmEsWUFBWUEsQ0FBQ0MsT0FBTzNELHdCQUF3QjJELEdBQUdYLHNCQUFzQixFQUFFUyxxQkFBcUIsS0FBSyxDQUFDLEVBQzdGcEQsSUFBSSxDQUFBdUQsT0FBTSxFQUFFckQsT0FBT3FELEdBQUduRCxPQUFPbUQsRUFBRSxFQUFFO0FBQUEsVUFDdENDLFVBQVVBLENBQUNGLE9BQU8zRCx3QkFBd0IyRCxHQUFHWCxzQkFBc0IsRUFBRVMscUJBQXFCLEtBQUssQ0FBQyxFQUFFSyxVQUFVO0FBQUEsVUFDNUdsQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLRSxTQUFTO0FBQUEsUUFDcEM7QUFBQSxRQUVBLEVBQUVyQixNQUFNLGtCQUFrQkQsT0FBTyx1QkFBdUJvQyxNQUFNLE9BQU87QUFBQSxRQUNyRSxFQUFFbkMsTUFBTSxTQUFTRCxPQUFPLHNCQUFzQm9DLE1BQU0sT0FBTztBQUFBLFFBQzNELEVBQUVuQyxNQUFNLFVBQVVELE9BQU8sdUJBQXVCb0MsTUFBTSxPQUFPO0FBQUEsUUFDN0QsRUFBRW5DLE1BQU0sU0FBU0QsT0FBTyxTQUFTb0MsTUFBTSxRQUFRO0FBQUEsTUFBQztBQUFBLElBRXhELEdBQUc7QUFBQSxNQUNDbkMsTUFBTTtBQUFBLE1BQ05rQyxRQUFRO0FBQUE7QUFBQSxRQUVKLEVBQUVsQyxNQUFNLFdBQVdELE9BQU8sYUFBYW9DLE1BQU0sT0FBTztBQUFBLFFBQ3BELEVBQUVuQyxNQUFNLE9BQU9ELE9BQU8saUJBQWlCb0MsTUFBTSxPQUFPO0FBQUEsUUFDcEQsRUFBRW5DLE1BQU0sUUFBUUQsT0FBTyxhQUFhb0MsTUFBTSxPQUFPO0FBQUEsUUFDakQ7QUFBQSxVQUNJbkMsTUFBTTtBQUFBLFVBQVlELE9BQU87QUFBQSxVQUFhb0MsTUFBTTtBQUFBLFVBQzVDa0IsYUFBYTdEO0FBQUFBLFVBQ2IwQixRQUFRQSxDQUFDQyxTQUFTQSxLQUFLbUMsZUFBZUMsU0FBUyxLQUFLO0FBQUEsUUFDeEQ7QUFBQSxNQUFDO0FBQUEsSUFFVCxHQUFHO0FBQUEsTUFDQ3ZELE1BQU07QUFBQSxNQUNOa0MsUUFBUTtBQUFBO0FBQUEsUUFFSjtBQUFBLFVBQ0lsQyxNQUFNO0FBQUEsVUFBcUJELE9BQU87QUFBQSxVQUE0Qm9DLE1BQU07QUFBQSxVQUFVSSxhQUFhO0FBQUEsVUFDM0ZyQixRQUFRQSxDQUFDQyxTQUFTQSxLQUFLUSxxQkFBcUIsT0FBTyxHQUFHUixLQUFLUSxpQkFBaUIsVUFBVTtBQUFBLFFBQzFGO0FBQUEsUUFDQTtBQUFBLFVBQ0kzQixNQUFNO0FBQUEsVUFBY0QsT0FBTztBQUFBLFVBQW1Cb0MsTUFBTTtBQUFBLFVBQ3BEcUIsa0JBQWtCO0FBQUEsWUFDZEMsY0FBY3BFO0FBQUFBLFlBQ2RxRSxXQUFXO0FBQUEsWUFDWEMsV0FBVztBQUFBLFVBQ2Y7QUFBQSxVQUNBekMsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS1MsZ0JBQWdCVCxLQUFLVSxnQkFBZ0I7QUFBQSxRQUNoRTtBQUFBLFFBQ0E7QUFBQSxVQUNJN0IsTUFBTTtBQUFBLFVBQWlCRCxPQUFPO0FBQUEsVUFBK0JvQyxNQUFNO0FBQUEsVUFDbkVNLFNBQVM7QUFBQSxZQUNMLEVBQUU1QyxPQUFPLEtBQUtFLE9BQU8sS0FBSztBQUFBLFlBQzFCLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsVUFBQztBQUFBLFVBRS9CNkQsV0FBVztBQUFBLFVBQ1gxQyxRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUtXLGdCQUFnQixnQ0FBZ0MseUJBQXlCLElBQzNKWCxlQUFLVyxnQkFBZ0IsT0FBTyxRQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFFUjtBQUFBO0FBQUEsUUFHQTtBQUFBLFVBQ0kvQixPQUFPO0FBQUEsVUFDUG9DLE1BQU07QUFBQSxVQUNOTSxTQUFTdEM7QUFBQUEsVUFDVEgsTUFBTTtBQUFBLFVBQ05rQixRQUFRZDtBQUFBQSxRQUNaO0FBQUEsUUFDQSxFQUFFSixNQUFNLGdCQUFnQkQsT0FBTyxzQkFBc0JvQyxNQUFNLE9BQU87QUFBQSxRQUVsRSxFQUFFbkMsTUFBTSxnQkFBZ0JELE9BQU8saUJBQWlCb0MsTUFBTSxPQUFPO0FBQUEsTUFBQztBQUFBLElBRXRFLEdBQUc7QUFBQSxNQUNDbkMsTUFBTTtBQUFBLE1BQ05rQyxRQUFRO0FBQUEsUUFDSixFQUFFbEMsTUFBTSx3QkFBd0JELE9BQU8sdUJBQXVCb0MsTUFBTSxPQUFPO0FBQUEsUUFDM0U7QUFBQSxVQUNJbkMsTUFBTTtBQUFBLFVBQXlCRCxPQUFPO0FBQUEsVUFBU29DLE1BQU07QUFBQSxVQUNyRGpCLFFBQVFBLENBQUNDLFNBQVM7QUFDZCxrQkFBTUssUUFBUUwsS0FBSzBDO0FBQ25CLGdCQUFJLENBQUNyQyxNQUFPLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFDcEQsbUJBQ0ksdUJBQUMsT0FBRSxNQUFNLFVBQVVBLEtBQUssSUFBSSxXQUFVLHlEQUNqQ0EsbUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBRVI7QUFBQSxRQUNKO0FBQUEsUUFDQSxFQUFFeEIsTUFBTSx5QkFBeUJELE9BQU8sWUFBWW9DLE1BQU0sT0FBTztBQUFBLFFBQ2pFO0FBQUEsVUFDSW5DLE1BQU07QUFBQSxVQUFzQkQsT0FBTztBQUFBLFVBQXVCb0MsTUFBTTtBQUFBLFVBQ2hFakIsUUFBUUEsQ0FBQ0MsU0FBUztBQUNkLGtCQUFNMkMsTUFBTTNDLEtBQUs0QztBQUNqQixnQkFBSSxDQUFDRCxJQUFLLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFDbEQsbUJBQ0ksdUJBQUMsT0FBRSxNQUFNQSxLQUFLLFFBQU8sVUFBUyxLQUFJLHVCQUFzQixXQUFVLHlEQUM3REEsaUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBRVI7QUFBQSxRQUNKO0FBQUEsUUFDQSxFQUFFOUQsTUFBTSwyQkFBMkJELE9BQU8sMkJBQTJCb0MsTUFBTSxPQUFPO0FBQUEsUUFDbEYsRUFBRW5DLE1BQU0sMkJBQTJCRCxPQUFPLHlCQUF5Qm9DLE1BQU0sT0FBTztBQUFBLE1BQUM7QUFBQSxJQUV6RixDQUFDO0FBQUEsRUFDTDtBQUNKIiwibmFtZXMiOlsiZ2V0QWxsIiwiY3JlYXRlVmFsdWVNYXBwZXJSZW5kZXJlciIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJnZXRBbGxvd2VkSW52b2ljZVNlcmllcyIsInJlc29sdmVJbnZvaWNlU2VyaWVzRm9yVGF4Q2hhbmdlIiwibG9hZERpc3RyaWN0cyIsInJlc3BvbnNlIiwiZGF0YSIsIm1hcCIsImRpc3RyaWN0IiwidmFsdWUiLCJpZCIsImxhYmVsIiwibmFtZSIsInRheENvbmRpdGlvbk9wdGlvbnMiLCJyZW5kZXJUYXhDb25kaXRpb24iLCJ0eXBlUmV0ZW50aW9uT3B0aW9ucyIsInJlbmRlclR5cGVSZXRlbnRpb24iLCJwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyIsImVuZHBvaW50IiwibW9kdWxlTmFtZSIsIm1vZHVsZU5hbWVQbHVyYWwiLCJiYXNlUm91dGUiLCJkZXRhaWwiLCJkaXNwbGF5TmFtZUtleSIsImxpc3RJdGVtQ29kZUtleSIsImxpc3RJdGVtTmFtZUtleSIsImxpc3QiLCJjb2x1bW5zIiwiaGVhZGVyIiwiYWNjZXNzb3IiLCJyZW5kZXIiLCJpdGVtIiwiY3VpdCIsInNlcmllIiwiY29udGFjdF9wZXJzb24iLCJwaG9uZSIsImVtYWlsIiwiYWRkcmVzcyIsImNpdHkiLCJwYXltZW50X2NvbmRpdGlvbiIsImFjY291bnRfbmFtZSIsImFjY291bnRfY29kZSIsImRvX25vdF9yZXRhaW4iLCJpc19ib2xzYSIsImZvcm0iLCJibG9jayIsImZpZWxkcyIsInR5cGUiLCJtYW5kYXRvcnkiLCJmb3JtRGF0YSIsImxlZ2FjeV90YXhfY29uZGl0aW9uIiwicGxhY2Vob2xkZXIiLCJtYXNrIiwib3B0aW9ucyIsIm9uQ2hhbmdlRWZmZWN0IiwibmV3VmFsdWUiLCJjdXJyZW50RGF0YSIsInVwZGF0ZUZvcm1EYXRhIiwiU3RyaW5nIiwiaW5jbHVkZU5vVHJpYnV0YWJsZSIsImdldE9wdGlvbnMiLCJmZCIsInMiLCJyZWFkb25seSIsImxlbmd0aCIsImxvYWRPcHRpb25zIiwiZGlzdHJpY3RfbmFtZSIsInRvU3RyaW5nIiwicmVsYXRpb25hbENvbmZpZyIsIm1vZHVsZUNvbmZpZyIsImNvZGVGaWVsZCIsIm5hbWVGaWVsZCIsInZhbHVlVHlwZSIsInBheW1lbnRfY29udGFjdF9lbWFpbCIsInVybCIsInBheW1lbnRfcG9ydGFsX3VybCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJwcm92ZWVkb3Jlcy5jb25maWcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldEFsbCB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlXCI7XG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZywgT3B0aW9uc0xvYWRlciB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBjcmVhdGVWYWx1ZU1hcHBlclJlbmRlcmVyIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3JlbmRlcnNcIjtcbmltcG9ydCB7IHR5cGUgUmVsYXRlZFRheCBhcyBWZW5kb3JUYXggfSBmcm9tIFwiLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzXCI7XG5pbXBvcnQgeyBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnIH0gZnJvbSBcIi4uL3BsYW5fZGVfY3VlbnRhcy9wbGFuX2RlX2N1ZW50YXMuY29uZmlnXCI7XG5pbXBvcnQgeyBnZXRBbGxvd2VkSW52b2ljZVNlcmllcywgcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JUYXhDaGFuZ2UgfSBmcm9tIFwiLi4vLi4vdXRpbHMvaW52b2ljZVNlcmllc1wiO1xuXG4vLyAxLiBEZWZpbmltb3MgbGEgJ2Zvcm1hJyBkZSB1biBQcm92ZWVkb3Jcbi8qXG5leHBvcnQgaW50ZXJmYWNlIFByb3ZlZWRvciB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgY3VpdDogc3RyaW5nO1xuICAgIGVtYWlsOiBzdHJpbmc7XG4gICAgcGhvbmU6IHN0cmluZztcbiAgICBsZWdhY3lfdGF4X2NvbmRpdGlvbjogJ1Jlc3BvbnNhYmxlIEluc2NyaXB0bycgfCAnTW9ub3RyaWJ1dGlzdGEnIHwgJ0V4ZW50byc7XG59XG4qL1xuXG4vLyBSZWVtcGxhemEgbGEgaW50ZXJmYXogJ1Byb3ZlZWRvcicgZW4gdHUgYXJjaGl2byBwcm92ZWVkb3Jlcy5jb25maWcudHN4XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvdmVlZG9yIHtcbiAgICAvLyAtLS0gSWRlbnRpZmljYWRvcmVzIC0tLVxuICAgIGlkOiBudW1iZXI7IC8vIE1hbnRlbmVtb3MgZWwgSUQgZGUgbGEgQVBJXG4gICAgdmVuZG9yX2NvZGU6IHN0cmluZzsgLy8gUFJPVkVFRE9SXG5cbiAgICAvLyAtLS0gRGF0b3MgUHJpbmNpcGFsZXMgLS0tXG4gICAgbmFtZTogc3RyaW5nOyAvLyBOT01QUk9WXG4gICAgY3VpdDogc3RyaW5nIHwgbnVsbDsgLy8gQ1VJVFxuICAgIHBob25lOiBzdHJpbmcgfCBudWxsOyAvLyBURUxFRk9OT1xuICAgIHBob25lMjogc3RyaW5nIHwgbnVsbDsgLy8gVEVMRUZPTk8yXG4gICAgZW1haWw6IHN0cmluZyB8IG51bGw7IC8vIEVNQUlMXG4gICAgY29udGFjdF9wZXJzb246IHN0cmluZyB8IG51bGw7IC8vIEFURU5DSU9OXG5cbiAgICAvLyAtLS0gRG9taWNpbGlvIC0tLVxuICAgIGFkZHJlc3M6IHN0cmluZyB8IG51bGw7IC8vIERPTUlDSUxJT1xuICAgIHppcDogc3RyaW5nIHwgbnVsbDsgLy8gQ09EUE9TVFxuICAgIGNpdHk6IHN0cmluZyB8IG51bGw7IC8vIExPQ0FMSURBRFxuICAgIGRpc3RyaWN0OiBudW1iZXIgfCBudWxsOyAvLyBQcm92aW5jaWFcbiAgICBkaXN0cmljdF9uYW1lOiBzdHJpbmcgfCBudWxsOyAvLyBQcm92aW5jaWFcblxuICAgIC8vIC0tLSBEYXRvcyBJbXBvc2l0aXZvcyB5IGRlIFBhZ28gLS0tXG4gICAgbGVnYWN5X3RheF9jb25kaXRpb246ICdJJyB8ICdNJyB8ICdFJyB8ICdDJyB8ICdOJyB8IHN0cmluZyB8IG51bGw7IC8vIFRSSUJVVEFcbiAgICBwYXltZW50X2NvbmRpdGlvbjogbnVtYmVyIHwgbnVsbDsgLy8gQ09ORFBBR08gKGTDrWFzKVxuICAgIGFjY291bnRfaWQ6IG51bWJlciB8IG51bGw7IC8vIElEIGN1ZW50YSBjb250YWJsZSAocGFyYSBSZWxhdGlvbmFsSW5wdXQpXG4gICAgYWNjb3VudF9jb2RlOiBzdHJpbmcgfCBudWxsOyAvLyBDVUVOVEEgKGPDs2RpZ28pXG4gICAgYWNjb3VudF9uYW1lOiBzdHJpbmcgfCBudWxsOyAvLyBOb21icmUgY3VlbnRhIChzb2xvIHBhcmEgdmlzdGEvZm9ybSlcbiAgICBkb19ub3RfcmV0YWluOiBib29sZWFuOyAvLyBOT1JFVEVORVJcbiAgICBzZXJpZTogc3RyaW5nIHwgbnVsbDtcblxuICAgIC8vIC0tLSBJbmZvcm1hY2nDs24gZGUgcGFnb3MgLS0tXG4gICAgcGF5bWVudF9jb250YWN0X25hbWU/OiBzdHJpbmcgfCBudWxsO1xuICAgIHBheW1lbnRfY29udGFjdF9lbWFpbD86IHN0cmluZyB8IG51bGw7XG4gICAgcGF5bWVudF9jb250YWN0X3Bob25lPzogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50X3BvcnRhbF91cmw/OiBzdHJpbmcgfCBudWxsO1xuICAgIHBheW1lbnRfcG9ydGFsX3VzZXJuYW1lPzogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50X3BvcnRhbF9wYXNzd29yZD86IHN0cmluZyB8IG51bGw7XG5cbiAgICAvLyAtLS0gQ2FtcG9zIEFkaWNpb25hbGVzIHkgQmFuZGVyYXMgLS0tXG4gICAgdmVuZG9yX3R5cGU6IHN0cmluZyB8IG51bGw7IC8vIFBST1ZUSVBPXG4gICAgY29uY2VwdF9jb2RlOiBzdHJpbmcgfCBudWxsOyAvLyBDT05DRVBUT1xuICAgIGlzX2JvbHNhOiBib29sZWFuOyAvLyBFU19CT0xTQVxuICAgIG9ic2VydmF0aW9uczogc3RyaW5nIHwgbnVsbDsgLy8gT0JTRVJWXG4gICAgcmVsYXRlZFRheGVzPzogVmVuZG9yVGF4W107XG4gICAgdGF4ZXM/OiBudW1iZXJbXTtcbiAgICAvKiogU2FsZG8gYSBmYXZvciBkZWwgcHJvdmVlZG9yIChhbCBjb25zdWx0YXIgZW4gY29udGV4dG8gZGUgw7NyZGVuZXMgZGUgcGFnbykuICovXG4gICAgYWR2YW5jZV9iYWxhbmNlPzogbnVtYmVyO1xufVxuXG5jb25zdCBsb2FkRGlzdHJpY3RzOiBPcHRpb25zTG9hZGVyID0gYXN5bmMgKCkgPT4ge1xuICAgIC8vIEFzdW1pbW9zIHF1ZSBsYSBBUEkgZGV2dWVsdmUgdW4gb2JqZXRvIGNvbiB1bmEgcHJvcGllZGFkICdkYXRhJyBxdWUgZXMgdW4gYXJyYXkuXG4gICAgLy8gWSBxdWUgY2FkYSBvYmpldG8gZGVsIGFycmF5IHRpZW5lICdpZCcgeSAnbmFtZScuIEFqdXN0YSBzaSBlcyBkaWZlcmVudGUuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBnZXRBbGw8eyBpZDogbnVtYmVyOyBuYW1lOiBzdHJpbmcgfT4oJ2Rpc3RyaWN0cycpO1xuICAgIHJldHVybiByZXNwb25zZS5kYXRhLm1hcChkaXN0cmljdCA9PiAoe1xuICAgICAgICB2YWx1ZTogZGlzdHJpY3QuaWQsXG4gICAgICAgIGxhYmVsOiBkaXN0cmljdC5uYW1lXG4gICAgfSkpO1xufTtcblxuY29uc3QgdGF4Q29uZGl0aW9uT3B0aW9ucyA9IFtcbiAgICB7IHZhbHVlOiAnSScsIGxhYmVsOiAnSVZBIFJlc3BvbnNhYmxlIEluc2NyaXB0bycgfSxcbiAgICB7IHZhbHVlOiAnTScsIGxhYmVsOiAnTW9ub3RyaWJ1dGlzdGEnIH0sXG4gICAgeyB2YWx1ZTogJ0UnLCBsYWJlbDogJ0V4ZW50bycgfSxcbiAgICB7IHZhbHVlOiAnQycsIGxhYmVsOiAnQ29uc3VtaWRvciBGaW5hbCcgfSxcbiAgICB7IHZhbHVlOiAnTicsIGxhYmVsOiAnTm8gUmVzcG9uc2FibGUnIH0sXG4gICAgeyB2YWx1ZTogJ1gnLCBsYWJlbDogJ05vIHRyaWJ1dGFibGUnIH0sXG5dO1xuXG4vLyAyLiBDcmVhIGVsIHJlbmRlcmVyIHJldXRpbGl6YWJsZSBhIHBhcnRpciBkZSBlc29zIGluZ3JlZGllbnRlcy5cbmNvbnN0IHJlbmRlclRheENvbmRpdGlvbiA9IGNyZWF0ZVZhbHVlTWFwcGVyUmVuZGVyZXI8UHJvdmVlZG9yPihcbiAgICB0YXhDb25kaXRpb25PcHRpb25zLFxuICAgICdsZWdhY3lfdGF4X2NvbmRpdGlvbidcbik7XG5cbmNvbnN0IHR5cGVSZXRlbnRpb25PcHRpb25zID0gW1xuICAgIHsgdmFsdWU6ICcwNzgnLCBsYWJlbDogJzA3OCcgfSxcbiAgICB7IHZhbHVlOiAnMDk0JywgbGFiZWw6ICcwOTQnIH0sXG4gICAgeyB2YWx1ZTogJzExNicsIGxhYmVsOiAnMTE2JyB9LFxuICAgIHsgdmFsdWU6ICcxMTknLCBsYWJlbDogJzExOScgfSxcbl07XG5cbi8vIDIuIENyZWEgZWwgcmVuZGVyZXIgcmV1dGlsaXphYmxlIGEgcGFydGlyIGRlIGVzb3MgaW5ncmVkaWVudGVzLlxuY29uc3QgcmVuZGVyVHlwZVJldGVudGlvbiA9IGNyZWF0ZVZhbHVlTWFwcGVyUmVuZGVyZXI8UHJvdmVlZG9yPihcbiAgICB0eXBlUmV0ZW50aW9uT3B0aW9ucyxcbiAgICAndmVuZG9yX3R5cGUnXG4pO1xuXG4vLyAzLiBDcmVhbW9zIGxhIGNvbmZpZ3VyYWNpw7NuIGNvbXBsZXRhIHBhcmEgZWwgbcOzZHVsbyBkZSBQcm92ZWVkb3Jlc1xuZXhwb3J0IGNvbnN0IHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8UHJvdmVlZG9yPiA9IHtcbiAgICBlbmRwb2ludDogJ3ZlbmRvcnMnLFxuICAgIG1vZHVsZU5hbWU6ICdQcm92ZWVkb3InLFxuICAgIG1vZHVsZU5hbWVQbHVyYWw6ICdQcm92ZWVkb3JlcycsXG4gICAgYmFzZVJvdXRlOiAnL3Byb3ZlZWRvcmVzJyxcblxuICAgIGRldGFpbDoge1xuICAgICAgICBkaXNwbGF5TmFtZUtleTogJ25hbWUnLFxuICAgIH0sXG4gICAgbGlzdEl0ZW1Db2RlS2V5OiAndmVuZG9yX2NvZGUnLFxuICAgIGxpc3RJdGVtTmFtZUtleTogJ25hbWUnLFxuICAgIGxpc3Q6IHtcbiAgICAgICAgY29sdW1uczogW1xuXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0PDs2RpZ28gZGVsIFByb3ZlZWRvcicsIGFjY2Vzc29yOiAndmVuZG9yX2NvZGUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1JhesOzbiBTb2NpYWwnLCBhY2Nlc3NvcjogJ25hbWUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NVSVQnLCBhY2Nlc3NvcjogJ2N1aXQnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmN1aXQgfHwgJy0nIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaGVhZGVyOiAnQ29uZGljacOzbiBJVkEnLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAnbGVnYWN5X3RheF9jb25kaXRpb24nLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogcmVuZGVyVGF4Q29uZGl0aW9uXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdTZXJpZSBkZSBGYWN0dXJhJywgYWNjZXNzb3I6ICdzZXJpZScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uc2VyaWUgfHwgJy0nIH0sXG5cbiAgICAgICAgICAgIHsgaGVhZGVyOiAnQ29udGFjdG8nLCBhY2Nlc3NvcjogJ2NvbnRhY3RfcGVyc29uJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5jb250YWN0X3BlcnNvbiB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnVGVsw6lmb25vJywgYWNjZXNzb3I6ICdwaG9uZScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucGhvbmUgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0VtYWlsJywgYWNjZXNzb3I6ICdlbWFpbCcsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uZW1haWwgfHwgJy0nIH0sXG5cbiAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRG9taWNpbGlvIC0tLVxuICAgICAgICAgICAgeyBoZWFkZXI6ICdEb21pY2lsaW8nLCBhY2Nlc3NvcjogJ2FkZHJlc3MnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmFkZHJlc3MgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0xvY2FsaWRhZCcsIGFjY2Vzc29yOiAnY2l0eScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uY2l0eSB8fCAnLScgfSxcblxuICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBEYXRvcyBJbXBvc2l0aXZvcyB5IGRlIFBhZ28gLS0tXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NvbmQuIFBhZ28nLCBhY2Nlc3NvcjogJ3BheW1lbnRfY29uZGl0aW9uJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5wYXltZW50X2NvbmRpdGlvbiAhPSBudWxsID8gYCR7aXRlbS5wYXltZW50X2NvbmRpdGlvbn0gZMOtYXNgIDogJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0N1ZW50YSBDb250YWJsZScsIGFjY2Vzc29yOiAnYWNjb3VudF9jb2RlJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5hY2NvdW50X25hbWUgfHwgaXRlbS5hY2NvdW50X2NvZGUgfHwgJy0nIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaGVhZGVyOiAnUmV0ZW5jaW9uZXMgc29icmUgR2FuYW5jaWFzJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ2RvX25vdF9yZXRhaW4nLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0uZG9fbm90X3JldGFpbiA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRvX25vdF9yZXRhaW4gPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBJbmZvcm1hY2nDs24gQWRpY2lvbmFsIC0tLVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1RpcG8gcmV0ZW5jacOzbicsXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6ICd2ZW5kb3JfdHlwZScsXG4gICAgICAgICAgICAgICAgcmVuZGVyOiByZW5kZXJUeXBlUmV0ZW50aW9uXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ0VzIEJvbHNhJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ2lzX2JvbHNhJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtpdGVtLmlzX2JvbHNhID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaXNfYm9sc2EgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuXG4gICAgZm9ybToge1xuICAgICAgICBibG9jazogW3tcbiAgICAgICAgICAgIG5hbWU6IFwiRGF0b3MgZGVsIHByb3ZlZWRvclwiLFxuICAgICAgICAgICAgZmllbGRzOiBbXG4gICAgICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBEYXRvcyBQcmluY2lwYWxlcyAtLS1cbiAgICAgICAgICAgICAgICB7IG5hbWU6ICduYW1lJywgbGFiZWw6ICdSYXrDs24gU29jaWFsJywgdHlwZTogJ3RleHQnLCBtYW5kYXRvcnk6IHRydWUgfSxcbiAgICAgICAgICAgICAgICB7IG5hbWU6ICdjdWl0JywgbGFiZWw6ICdDVUlUJywgdHlwZTogJ3RleHQnLCBtYW5kYXRvcnk6IChmb3JtRGF0YTogUHJvdmVlZG9yKSA9PiBmb3JtRGF0YS5sZWdhY3lfdGF4X2NvbmRpdGlvbiAhPT0gJ1gnLCBwbGFjZWhvbGRlcjogJ0VqOiAzMC0xMjM0NTY3OC05JywgbWFzazogJ2N1aXQnIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnbGVnYWN5X3RheF9jb25kaXRpb24nLCBsYWJlbDogJ0NvbmRpY2nDs24gSVZBJywgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IHRheENvbmRpdGlvbk9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgIHJlbmRlcjogcmVuZGVyVGF4Q29uZGl0aW9uLFxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZUVmZmVjdDogKG5ld1ZhbHVlLCBjdXJyZW50RGF0YSwgdXBkYXRlRm9ybURhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJpZTogcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JUYXhDaGFuZ2UoU3RyaW5nKG5ld1ZhbHVlKSwgY3VycmVudERhdGEuc2VyaWUsIHsgaW5jbHVkZU5vVHJpYnV0YWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdzZXJpZScsXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnU2VyaWUgZGUgRmFjdHVyYScsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdzZWxlY3QnLFxuICAgICAgICAgICAgICAgICAgICBnZXRPcHRpb25zOiAoZmQpID0+IGdldEFsbG93ZWRJbnZvaWNlU2VyaWVzKGZkLmxlZ2FjeV90YXhfY29uZGl0aW9uLCB7IGluY2x1ZGVOb1RyaWJ1dGFibGU6IHRydWUgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAocyA9PiAoeyB2YWx1ZTogcywgbGFiZWw6IHMgfSkpLFxuICAgICAgICAgICAgICAgICAgICByZWFkb25seTogKGZkKSA9PiBnZXRBbGxvd2VkSW52b2ljZVNlcmllcyhmZC5sZWdhY3lfdGF4X2NvbmRpdGlvbiwgeyBpbmNsdWRlTm9UcmlidXRhYmxlOiB0cnVlIH0pLmxlbmd0aCA8PSAxLFxuICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnNlcmllIHx8ICctJyxcbiAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnY29udGFjdF9wZXJzb24nLCBsYWJlbDogJ0F0ZW5jacOzbiAvIENvbnRhY3RvJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAncGhvbmUnLCBsYWJlbDogJ1RlbMOpZm9ubyBQcmluY2lwYWwnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICB7IG5hbWU6ICdwaG9uZTInLCBsYWJlbDogJ1RlbMOpZm9ubyBTZWN1bmRhcmlvJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnZW1haWwnLCBsYWJlbDogJ0VtYWlsJywgdHlwZTogJ2VtYWlsJyB9LFxuICAgICAgICAgICAgXVxuICAgICAgICB9LCB7XG4gICAgICAgICAgICBuYW1lOiBcIkRpcmVjY2nDs25cIixcbiAgICAgICAgICAgIGZpZWxkczogW1xuICAgICAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRG9taWNpbGlvIC0tLVxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ2FkZHJlc3MnLCBsYWJlbDogJ0RvbWljaWxpbycsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ3ppcCcsIGxhYmVsOiAnQ8OzZGlnbyBQb3N0YWwnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICB7IG5hbWU6ICdjaXR5JywgbGFiZWw6ICdMb2NhbGlkYWQnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdkaXN0cmljdCcsIGxhYmVsOiAnUHJvdmluY2lhJywgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRPcHRpb25zOiBsb2FkRGlzdHJpY3RzLFxuICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmRpc3RyaWN0X25hbWU/LnRvU3RyaW5nKCkgfHwgJy0nLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdXG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG5hbWU6IFwiT3Ryb3MgZGF0b3NcIixcbiAgICAgICAgICAgIGZpZWxkczogW1xuICAgICAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRGF0b3MgSW1wb3NpdGl2b3MgeSBkZSBQYWdvIC0tLVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3BheW1lbnRfY29uZGl0aW9uJywgbGFiZWw6ICdDb25kaWNpw7NuIGRlIFBhZ28gKGTDrWFzKScsIHR5cGU6ICdudW1iZXInLCBwbGFjZWhvbGRlcjogJ0VqOiAzMCcsXG4gICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucGF5bWVudF9jb25kaXRpb24gIT0gbnVsbCA/IGAke2l0ZW0ucGF5bWVudF9jb25kaXRpb259IGTDrWFzYCA6ICctJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2FjY291bnRfaWQnLCBsYWJlbDogJ0N1ZW50YSBDb250YWJsZScsIHR5cGU6ICdyZWxhdGlvbmFsJyxcbiAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbENvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgbW9kdWxlQ29uZmlnOiBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnYWNjb3VudF9jb2RlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ2FjY291bnRfbmFtZScsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uYWNjb3VudF9uYW1lIHx8IGl0ZW0uYWNjb3VudF9jb2RlIHx8ICctJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2RvX25vdF9yZXRhaW4nLCBsYWJlbDogJ1JldGVuY2lvbmVzIHNvYnJlIEdhbmFuY2lhcycsIHR5cGU6ICdzZWxlY3QnLFxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMCcsIGxhYmVsOiAnTm8nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMScsIGxhYmVsOiAnU2knIH0sXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogJ2Jvb2xlYW4nLFxuICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXRlbS5kb19ub3RfcmV0YWluID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRvX25vdF9yZXRhaW4gPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogSW5mb3JtYWNpw7NuIEFkaWNpb25hbCAtLS1cbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnVGlwbyByZXRlbmNpw7NuJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IHR5cGVSZXRlbnRpb25PcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAndmVuZG9yX3R5cGUnLFxuICAgICAgICAgICAgICAgICAgICByZW5kZXI6IHJlbmRlclR5cGVSZXRlbnRpb25cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ2NvbmNlcHRfY29kZScsIGxhYmVsOiAnQ8OzZGlnbyBkZSBDb25jZXB0bycsIHR5cGU6ICd0ZXh0JyB9LFxuXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnb2JzZXJ2YXRpb25zJywgbGFiZWw6ICdPYnNlcnZhY2lvbmVzJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICBdXG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG5hbWU6IFwiSW5mb3JtYWNpw7NuIGRlIHBhZ29zXCIsXG4gICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICB7IG5hbWU6ICdwYXltZW50X2NvbnRhY3RfbmFtZScsIGxhYmVsOiAnQ29udGFjdG8gcGFyYSBwYWdvcycsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3BheW1lbnRfY29udGFjdF9lbWFpbCcsIGxhYmVsOiAnRW1haWwnLCB0eXBlOiAnZW1haWwnLFxuICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlbWFpbCA9IGl0ZW0ucGF5bWVudF9jb250YWN0X2VtYWlsO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFlbWFpbCkgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4tPC9zcGFuPjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj17YG1haWx0bzoke2VtYWlsfWB9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudF9jb250YWN0X3Bob25lJywgbGFiZWw6ICdUZWzDqWZvbm8nLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdwYXltZW50X3BvcnRhbF91cmwnLCBsYWJlbDogJ1VSTCBwb3J0YWwgZGUgcGFnb3MnLCB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVybCA9IGl0ZW0ucGF5bWVudF9wb3J0YWxfdXJsO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF1cmwpIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+LTwvc3Bhbj47XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3VybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1cmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ3BheW1lbnRfcG9ydGFsX3VzZXJuYW1lJywgbGFiZWw6ICdVc3VhcmlvIHBvcnRhbCBkZSBwYWdvcycsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ3BheW1lbnRfcG9ydGFsX3Bhc3N3b3JkJywgbGFiZWw6ICdDbGF2ZSBwb3J0YWwgZGUgcGFnb3MnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgIF1cbiAgICAgICAgfV1cbiAgICB9XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvcHJvdmVlZG9yZXMvcHJvdmVlZG9yZXMuY29uZmlnLnRzeCJ9