import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mov_stock/pages/MovStockDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mov_stock/pages/MovStockDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { stockMovementsModuleConfig } from "/src/features/mov_stock/movStock.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const MovStockDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: movement, loading, error } = useCrudItem(stockMovementsModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del movimiento..." }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockDetailPage.tsx",
    lineNumber: 29,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 21
  }, this);
  if (!movement) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento no encontrado." }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 25
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: stockMovementsModuleConfig, item: movement }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(MovStockDetailPage, "z1Bhd3UGhI7LfZmz3s+T8AkEJRQ=", false, function() {
  return [useParams, useCrudItem];
});
_c = MovStockDetailPage;
var _c;
$RefreshReg$(_c, "MovStockDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mov_stock/pages/MovStockDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mov_stock/pages/MovStockDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGtDQUFpRDtBQUMxRCxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMscUJBQXFCQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsVUFBVUMsU0FBU0MsTUFBTSxJQUFJUCxZQUFzQkQsNEJBQTRCSSxFQUFFO0FBRS9GLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGtEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUM7QUFDM0QsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsU0FBVSxRQUFPLHVCQUFDLFNBQUkseUNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4QjtBQUVwRCxTQUFPLHVCQUFDLHFCQUFrQixRQUFRTiw0QkFBNEIsTUFBTU0sWUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzRTtBQUNqRjtBQUFFSCxHQVRXRCxvQkFBa0I7QUFBQSxVQUNaSixXQUM0QkcsV0FBVztBQUFBO0FBQUFRLEtBRjdDUDtBQUFrQixJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiR2VuZXJpY0RldGFpbFBhZ2UiLCJzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiTW92U3RvY2tEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJtb3ZlbWVudCIsImxvYWRpbmciLCJlcnJvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vdlN0b2NrRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljRGV0YWlsUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNEZXRhaWxQYWdlJztcbmltcG9ydCB7IHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLCB0eXBlIE1vdlN0b2NrIH0gZnJvbSAnLi4vbW92U3RvY2suY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuXG5leHBvcnQgY29uc3QgTW92U3RvY2tEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW06IG1vdmVtZW50LCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08TW92U3RvY2s+KHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGV0YWxsZSBkZWwgbW92aW1pZW50by4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFtb3ZlbWVudCkgcmV0dXJuIDxkaXY+TW92aW1pZW50byBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXtzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZ30gaXRlbT17bW92ZW1lbnR9IC8+O1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21vdl9zdG9jay9wYWdlcy9Nb3ZTdG9ja0RldGFpbFBhZ2UudHN4In0=