import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboards/components/ClientBalancesWidget.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/dashboards/components/ClientBalancesWidget.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaUserFriends, FaSpinner, FaExclamationTriangle, FaArrowLeft } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { getAll } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
const MAX_CLIENTS_IN_LIST = 200;
export const ClientBalancesWidget = () => {
  _s();
  const [showList, setShowList] = useState(false);
  const [clientBalances, setClientBalances] = useState([]);
  const [total, setTotal] = useState(void 0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchClientBalances = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await getAll("sales-invoices/client-balances");
        const list = response?.balances ?? (Array.isArray(response) ? response : []);
        const raw = Array.isArray(list) ? list : [];
        const normalized = raw.map((item) => ({
          client_id: item.client_id ?? item.customer_id,
          client_name: item.client_name ?? item.customer_name ?? "",
          total_balance: String(item.total_balance ?? "0")
        }));
        const sorted = [...normalized].sort(
          (a, b) => parseFloat(b.total_balance) - parseFloat(a.total_balance)
        );
        setClientBalances(sorted);
        if (response?.total != null) {
          setTotal(response.total);
        }
      } catch (err) {
        console.error("Error fetching client balances:", err);
        setError("No se pudo cargar el resumen de saldos de clientes.");
        setClientBalances([]);
      } finally {
        setLoading(false);
      }
    };
    fetchClientBalances();
  }, []);
  const handleClientClick = (clientId) => {
    navigate(`/clientes/${clientId}?tab=movements`);
  };
  const displayedBalances = clientBalances.slice(0, MAX_CLIENTS_IN_LIST);
  const renderCardView = () => /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "button",
      tabIndex: 0,
      onClick: () => setShowList(true),
      onKeyDown: (e) => e.key === "Enter" && setShowList(true),
      className: "p-6 bg-white rounded-lg shadow-md h-full cursor-pointer hover:bg-gray-50 transition-colors",
      children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-700", children: "Total Saldo Clientes" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 93,
          columnNumber: 13
        }, this),
        loading && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500", children: "Cargando..." }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 95,
          columnNumber: 25
        }, this),
        error && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 font-semibold text-red-500 flex items-center", children: [
          /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "mr-2" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
            lineNumber: 99,
            columnNumber: 21
          }, this),
          " ",
          error
        ] }, void 0, true, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 98,
          columnNumber: 5
        }, this),
        !loading && !error && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold text-red-600", children: total != null ? formatValue(String(total), "currency") : "Sin datos" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
            lineNumber: 105,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Clic para ver detalle por cliente" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
            lineNumber: 108,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 104,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 86,
      columnNumber: 3
    },
    this
  );
  const renderListView = () => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md flex flex-col", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-gray-200 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 flex items-center", children: [
        /* @__PURE__ */ jsxDEV(FaUserFriends, { className: "mr-3 text-indigo-500" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 118,
          columnNumber: 21
        }, this),
        "Saldos por Cliente"
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
        lineNumber: 117,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setShowList(false),
          className: "text-sm text-indigo-600 hover:text-indigo-800 flex items-center",
          children: [
            /* @__PURE__ */ jsxDEV(FaArrowLeft, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
              lineNumber: 126,
              columnNumber: 21
            }, this),
            " Volver"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 121,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 116,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center p-10", children: /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin text-4xl text-indigo-500" }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 131,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 130,
      columnNumber: 5
    }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "p-4 text-center text-red-500 flex flex-col items-center", children: [
      /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "mb-2" }, void 0, false, {
        fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
        lineNumber: 135,
        columnNumber: 21
      }, this),
      " ",
      error
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 134,
      columnNumber: 5
    }, this) : displayedBalances.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "p-4 text-sm text-center text-gray-500", children: "No hay clientes con saldo pendiente." }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 138,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-y-auto max-h-80", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "px-4 py-2 text-xs text-gray-500", children: [
        "Mostrando los primeros ",
        displayedBalances.length,
        " clientes con más saldo."
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
        lineNumber: 141,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Cliente" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
            lineNumber: 147,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Saldo Total" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
            lineNumber: 148,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 146,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 145,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: displayedBalances.map(
          (client) => /* @__PURE__ */ jsxDEV(
            "tr",
            {
              onClick: () => handleClientClick(client.client_id),
              className: "hover:bg-gray-50 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900", children: client.client_name }, void 0, false, {
                  fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
                  lineNumber: 158,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 whitespace-nowrap text-sm text-right font-semibold text-red-600", children: formatValue(client.total_balance, "currency") }, void 0, false, {
                  fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
                  lineNumber: 159,
                  columnNumber: 37
                }, this)
              ]
            },
            client.client_id,
            true,
            {
              fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
              lineNumber: 153,
              columnNumber: 11
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
          lineNumber: 151,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
        lineNumber: 144,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
      lineNumber: 140,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/dashboards/components/ClientBalancesWidget.tsx",
    lineNumber: 115,
    columnNumber: 3
  }, this);
  return showList ? renderListView() : renderCardView();
};
_s(ClientBalancesWidget, "uQApkv45wgdPod59gVow1Q+3hqs=", false, function() {
  return [useNavigate];
});
_c = ClientBalancesWidget;
var _c;
$RefreshReg$(_c, "ClientBalancesWidget");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/dashboards/components/ClientBalancesWidget.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/dashboards/components/ClientBalancesWidget.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpFWixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWVDLFdBQVdDLHVCQUF1QkMsbUJBQW1CO0FBQzdFLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsbUJBQW1CO0FBYTVCLE1BQU1DLHNCQUFzQjtBQUVyQixhQUFNQyx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQ2EsZ0JBQWdCQyxpQkFBaUIsSUFBSWQsU0FBMEIsRUFBRTtBQUN4RSxRQUFNLENBQUNlLE9BQU9DLFFBQVEsSUFBSWhCLFNBQXNDaUIsTUFBUztBQUN6RSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNvQixPQUFPQyxRQUFRLElBQUlyQixTQUF3QixJQUFJO0FBQ3RELFFBQU1zQixXQUFXckIsWUFBWTtBQUU3QkYsWUFBVSxNQUFNO0FBQ1osVUFBTXdCLHNCQUFzQixZQUFZO0FBQ3BDSixpQkFBVyxJQUFJO0FBQ2ZFLGVBQVMsSUFBSTtBQUNiLFVBQUk7QUFDQSxjQUFNRyxXQUFXLE1BQU1sQixPQUFPLGdDQUFnQztBQUM5RCxjQUFNbUIsT0FBT0QsVUFBVUUsYUFBYUMsTUFBTUMsUUFBUUosUUFBUSxJQUFJQSxXQUFXO0FBQ3pFLGNBQU1LLE1BQU9GLE1BQU1DLFFBQVFILElBQUksSUFBSUEsT0FBTztBQUMxQyxjQUFNSyxhQUE4QkQsSUFBSUUsSUFBSSxDQUFDQyxVQUFVO0FBQUEsVUFDbkRDLFdBQVlELEtBQUtDLGFBQWFELEtBQUtFO0FBQUFBLFVBQ25DQyxhQUFjSCxLQUFLRyxlQUFlSCxLQUFLSSxpQkFBaUI7QUFBQSxVQUN4REMsZUFBZUMsT0FBT04sS0FBS0ssaUJBQWlCLEdBQUc7QUFBQSxRQUNuRCxFQUFFO0FBQ0YsY0FBTUUsU0FBUyxDQUFDLEdBQUdULFVBQVUsRUFBRVU7QUFBQUEsVUFDM0IsQ0FBQ0MsR0FBR0MsTUFBTUMsV0FBV0QsRUFBRUwsYUFBYSxJQUFJTSxXQUFXRixFQUFFSixhQUFhO0FBQUEsUUFDdEU7QUFDQXZCLDBCQUFrQnlCLE1BQU07QUFDeEIsWUFBSWYsVUFBVVQsU0FBUyxNQUFNO0FBQ3pCQyxtQkFBU1EsU0FBU1QsS0FBSztBQUFBLFFBQzNCO0FBQUEsTUFDSixTQUFTNkIsS0FBSztBQUNWQyxnQkFBUXpCLE1BQU0sbUNBQW1Dd0IsR0FBRztBQUNwRHZCLGlCQUFTLHFEQUFxRDtBQUM5RFAsMEJBQWtCLEVBQUU7QUFBQSxNQUN4QixVQUFDO0FBQ0dLLG1CQUFXLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFFQUksd0JBQW9CO0FBQUEsRUFDeEIsR0FBRyxFQUFFO0FBRUwsUUFBTXVCLG9CQUFvQkEsQ0FBQ0MsYUFBcUI7QUFDNUN6QixhQUFTLGFBQWF5QixRQUFRLGdCQUFnQjtBQUFBLEVBQ2xEO0FBRUEsUUFBTUMsb0JBQW9CbkMsZUFBZW9DLE1BQU0sR0FBR3pDLG1CQUFtQjtBQUVyRSxRQUFNMEMsaUJBQWlCQSxNQUNuQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csTUFBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLE1BQ1YsU0FBUyxNQUFNdEMsWUFBWSxJQUFJO0FBQUEsTUFDL0IsV0FBVyxDQUFDdUMsTUFBTUEsRUFBRUMsUUFBUSxXQUFXeEMsWUFBWSxJQUFJO0FBQUEsTUFDdkQsV0FBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUNBQXNDLG9DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFFdkVNLFdBQVcsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQiwyQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBRXhERSxTQUNHLHVCQUFDLE9BQUUsV0FBVSxxREFDVDtBQUFBLGlDQUFDLHlCQUFzQixXQUFVLFVBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFBRztBQUFBLFVBQUVBO0FBQUFBLGFBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0gsQ0FBQ0YsV0FBVyxDQUFDRSxTQUNWLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsaUNBQUMsT0FBRSxXQUFVLG1DQUNSTCxtQkFBUyxPQUFPUixZQUFZK0IsT0FBT3ZCLEtBQUssR0FBRyxVQUFVLElBQUksZUFEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixpREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkU7QUFBQSxhQUovRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQTtBQUFBO0FBQUEsSUF2QlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBeUJBO0FBR0osUUFBTXNDLGlCQUFpQkEsTUFDbkIsdUJBQUMsU0FBSSxXQUFVLCtDQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGtFQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHlEQUNWO0FBQUEsK0JBQUMsaUJBQWMsV0FBVSwwQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBO0FBQUEsV0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNekMsWUFBWSxLQUFLO0FBQUEsVUFDaEMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsVUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUE7QUFBQTtBQUFBLFFBTHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUNDTSxVQUNHLHVCQUFDLFNBQUksV0FBVSx5Q0FDWCxpQ0FBQyxhQUFVLFdBQVUsMkNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQsS0FEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBQ0FFLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNYO0FBQUEsNkJBQUMseUJBQXNCLFdBQVUsVUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQUc7QUFBQSxNQUFFQTtBQUFBQSxTQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFDQTRCLGtCQUFrQk0sV0FBVyxJQUM3Qix1QkFBQyxPQUFFLFdBQVUseUNBQXdDLG9EQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlGLElBRXpGLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLDZCQUFDLE9BQUUsV0FBVSxtQ0FBaUM7QUFBQTtBQUFBLFFBQ2xCTixrQkFBa0JNO0FBQUFBLFFBQU87QUFBQSxXQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQkFDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGtGQUFpRix1QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxVQUN0Ryx1QkFBQyxRQUFHLFdBQVUsbUZBQWtGLDJCQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLGFBRi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaTiw0QkFBa0JqQjtBQUFBQSxVQUFJLENBQUN3QixXQUNwQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsU0FBUyxNQUFNVCxrQkFBa0JTLE9BQU90QixTQUFTO0FBQUEsY0FDakQsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsaUVBQWlFc0IsaUJBQU9wQixlQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRztBQUFBLGdCQUNsRyx1QkFBQyxRQUFHLFdBQVUsNkVBQTZFNUIsc0JBQVlnRCxPQUFPbEIsZUFBZSxVQUFVLEtBQXZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlJO0FBQUE7QUFBQTtBQUFBLFlBTHBJa0IsT0FBT3RCO0FBQUFBLFlBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFFBQ0gsS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsU0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLE9BakRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtREE7QUFHSixTQUFPdEIsV0FBVzBDLGVBQWUsSUFBSUgsZUFBZTtBQUN4RDtBQUFFeEMsR0FuSVdELHNCQUFvQjtBQUFBLFVBTVpSLFdBQVc7QUFBQTtBQUFBdUQsS0FObkIvQztBQUFvQixJQUFBK0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJGYVVzZXJGcmllbmRzIiwiRmFTcGlubmVyIiwiRmFFeGNsYW1hdGlvblRyaWFuZ2xlIiwiRmFBcnJvd0xlZnQiLCJnZXRBbGwiLCJmb3JtYXRWYWx1ZSIsIk1BWF9DTElFTlRTX0lOX0xJU1QiLCJDbGllbnRCYWxhbmNlc1dpZGdldCIsIl9zIiwic2hvd0xpc3QiLCJzZXRTaG93TGlzdCIsImNsaWVudEJhbGFuY2VzIiwic2V0Q2xpZW50QmFsYW5jZXMiLCJ0b3RhbCIsInNldFRvdGFsIiwidW5kZWZpbmVkIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlcnJvciIsInNldEVycm9yIiwibmF2aWdhdGUiLCJmZXRjaENsaWVudEJhbGFuY2VzIiwicmVzcG9uc2UiLCJsaXN0IiwiYmFsYW5jZXMiLCJBcnJheSIsImlzQXJyYXkiLCJyYXciLCJub3JtYWxpemVkIiwibWFwIiwiaXRlbSIsImNsaWVudF9pZCIsImN1c3RvbWVyX2lkIiwiY2xpZW50X25hbWUiLCJjdXN0b21lcl9uYW1lIiwidG90YWxfYmFsYW5jZSIsIlN0cmluZyIsInNvcnRlZCIsInNvcnQiLCJhIiwiYiIsInBhcnNlRmxvYXQiLCJlcnIiLCJjb25zb2xlIiwiaGFuZGxlQ2xpZW50Q2xpY2siLCJjbGllbnRJZCIsImRpc3BsYXllZEJhbGFuY2VzIiwic2xpY2UiLCJyZW5kZXJDYXJkVmlldyIsImUiLCJrZXkiLCJyZW5kZXJMaXN0VmlldyIsImxlbmd0aCIsImNsaWVudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudEJhbGFuY2VzV2lkZ2V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEZhVXNlckZyaWVuZHMsIEZhU3Bpbm5lciwgRmFFeGNsYW1hdGlvblRyaWFuZ2xlLCBGYUFycm93TGVmdCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGdldEFsbCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcblxuaW50ZXJmYWNlIENsaWVudEJhbGFuY2Uge1xuICAgIGNsaWVudF9pZDogbnVtYmVyO1xuICAgIGNsaWVudF9uYW1lOiBzdHJpbmc7XG4gICAgdG90YWxfYmFsYW5jZTogc3RyaW5nO1xufVxuXG50eXBlIENsaWVudEJhbGFuY2VzUmVzcG9uc2UgPSB7XG4gICAgdG90YWw/OiBudW1iZXIgfCBzdHJpbmc7XG4gICAgYmFsYW5jZXM/OiBDbGllbnRCYWxhbmNlW107XG59O1xuXG5jb25zdCBNQVhfQ0xJRU5UU19JTl9MSVNUID0gMjAwO1xuXG5leHBvcnQgY29uc3QgQ2xpZW50QmFsYW5jZXNXaWRnZXQgPSAoKSA9PiB7XG4gICAgY29uc3QgW3Nob3dMaXN0LCBzZXRTaG93TGlzdF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2NsaWVudEJhbGFuY2VzLCBzZXRDbGllbnRCYWxhbmNlc10gPSB1c2VTdGF0ZTxDbGllbnRCYWxhbmNlW10+KFtdKTtcbiAgICBjb25zdCBbdG90YWwsIHNldFRvdGFsXSA9IHVzZVN0YXRlPG51bWJlciB8IHN0cmluZyB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZldGNoQ2xpZW50QmFsYW5jZXMgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZ2V0QWxsKCdzYWxlcy1pbnZvaWNlcy9jbGllbnQtYmFsYW5jZXMnKSBhcyB1bmtub3duIGFzIENsaWVudEJhbGFuY2VzUmVzcG9uc2U7XG4gICAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IHJlc3BvbnNlPy5iYWxhbmNlcyA/PyAoQXJyYXkuaXNBcnJheShyZXNwb25zZSkgPyByZXNwb25zZSA6IFtdKTtcbiAgICAgICAgICAgICAgICBjb25zdCByYXcgPSAoQXJyYXkuaXNBcnJheShsaXN0KSA/IGxpc3QgOiBbXSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcbiAgICAgICAgICAgICAgICBjb25zdCBub3JtYWxpemVkOiBDbGllbnRCYWxhbmNlW10gPSByYXcubWFwKChpdGVtKSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IChpdGVtLmNsaWVudF9pZCA/PyBpdGVtLmN1c3RvbWVyX2lkKSBhcyBudW1iZXIsXG4gICAgICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiAoaXRlbS5jbGllbnRfbmFtZSA/PyBpdGVtLmN1c3RvbWVyX25hbWUgPz8gJycpIGFzIHN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgdG90YWxfYmFsYW5jZTogU3RyaW5nKGl0ZW0udG90YWxfYmFsYW5jZSA/PyAnMCcpLFxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICBjb25zdCBzb3J0ZWQgPSBbLi4ubm9ybWFsaXplZF0uc29ydChcbiAgICAgICAgICAgICAgICAgICAgKGEsIGIpID0+IHBhcnNlRmxvYXQoYi50b3RhbF9iYWxhbmNlKSAtIHBhcnNlRmxvYXQoYS50b3RhbF9iYWxhbmNlKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50QmFsYW5jZXMoc29ydGVkKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2U/LnRvdGFsICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VG90YWwocmVzcG9uc2UudG90YWwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjbGllbnQgYmFsYW5jZXM6XCIsIGVycik7XG4gICAgICAgICAgICAgICAgc2V0RXJyb3IoJ05vIHNlIHB1ZG8gY2FyZ2FyIGVsIHJlc3VtZW4gZGUgc2FsZG9zIGRlIGNsaWVudGVzLicpO1xuICAgICAgICAgICAgICAgIHNldENsaWVudEJhbGFuY2VzKFtdKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgZmV0Y2hDbGllbnRCYWxhbmNlcygpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGhhbmRsZUNsaWVudENsaWNrID0gKGNsaWVudElkOiBudW1iZXIpID0+IHtcbiAgICAgICAgbmF2aWdhdGUoYC9jbGllbnRlcy8ke2NsaWVudElkfT90YWI9bW92ZW1lbnRzYCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGRpc3BsYXllZEJhbGFuY2VzID0gY2xpZW50QmFsYW5jZXMuc2xpY2UoMCwgTUFYX0NMSUVOVFNfSU5fTElTVCk7XG5cbiAgICBjb25zdCByZW5kZXJDYXJkVmlldyA9ICgpID0+IChcbiAgICAgICAgPGRpdlxuICAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiXG4gICAgICAgICAgICB0YWJJbmRleD17MH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dMaXN0KHRydWUpfVxuICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgc2V0U2hvd0xpc3QodHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTYgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgaC1mdWxsIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICA+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5Ub3RhbCBTYWxkbyBDbGllbnRlczwvaDI+XG5cbiAgICAgICAgICAgIHtsb2FkaW5nICYmIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1ncmF5LTUwMFwiPkNhcmdhbmRvLi4uPC9wPn1cblxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNTAwIGZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYUV4Y2xhbWF0aW9uVHJpYW5nbGUgY2xhc3NOYW1lPVwibXItMlwiIC8+IHtlcnJvcn1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsICE9IG51bGwgPyBmb3JtYXRWYWx1ZShTdHJpbmcodG90YWwpLCAnY3VycmVuY3knKSA6ICdTaW4gZGF0b3MnfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0yXCI+Q2xpYyBwYXJhIHZlciBkZXRhbGxlIHBvciBjbGllbnRlPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIGNvbnN0IHJlbmRlckxpc3RWaWV3ID0gKCkgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LW1kIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZhVXNlckZyaWVuZHMgY2xhc3NOYW1lPVwibXItMyB0ZXh0LWluZGlnby01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICBTYWxkb3MgcG9yIENsaWVudGVcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dMaXN0KGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGZsZXggaXRlbXMtY2VudGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGYUFycm93TGVmdCBjbGFzc05hbWU9XCJtci0yXCIgLz4gVm9sdmVyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0xMFwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB0ZXh0LTR4bCB0ZXh0LWluZGlnby01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IGVycm9yID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHRleHQtY2VudGVyIHRleHQtcmVkLTUwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFFeGNsYW1hdGlvblRyaWFuZ2xlIGNsYXNzTmFtZT1cIm1iLTJcIiAvPiB7ZXJyb3J9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogZGlzcGxheWVkQmFsYW5jZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgY2xpZW50ZXMgY29uIHNhbGRvIHBlbmRpZW50ZS48L3A+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteS1hdXRvIG1heC1oLTgwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE1vc3RyYW5kbyBsb3MgcHJpbWVyb3Mge2Rpc3BsYXllZEJhbGFuY2VzLmxlbmd0aH0gY2xpZW50ZXMgY29uIG3DoXMgc2FsZG8uXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBzdGlja3kgdG9wLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5DbGllbnRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5TYWxkbyBUb3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXllZEJhbGFuY2VzLm1hcCgoY2xpZW50KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjbGllbnQuY2xpZW50X2lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2xpZW50Q2xpY2soY2xpZW50LmNsaWVudF9pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57Y2xpZW50LmNsaWVudF9uYW1lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC1yaWdodCBmb250LXNlbWlib2xkIHRleHQtcmVkLTYwMFwiPntmb3JtYXRWYWx1ZShjbGllbnQudG90YWxfYmFsYW5jZSwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgcmV0dXJuIHNob3dMaXN0ID8gcmVuZGVyTGlzdFZpZXcoKSA6IHJlbmRlckNhcmRWaWV3KCk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9kYXNoYm9hcmRzL2NvbXBvbmVudHMvQ2xpZW50QmFsYW5jZXNXaWRnZXQudHN4In0=