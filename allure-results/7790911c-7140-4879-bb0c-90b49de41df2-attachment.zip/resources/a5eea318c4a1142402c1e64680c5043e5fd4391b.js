import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/TaxSelectionBlock.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/TaxSelectionBlock.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { getAll } from "/src/services/apiService.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
const buildGroupQuery = (base, group) => ({
  ...base,
  ...group.queryOverrides ?? {},
  type: String(group.type)
});
const renderTaxGrid = (taxes, selectedIds, onToggle) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4", children: taxes.map(
  (tax) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center h-5", children: /* @__PURE__ */ jsxDEV(
      "input",
      {
        id: `tax-${tax.id}`,
        type: "checkbox",
        checked: selectedIds.includes(tax.id),
        onChange: () => onToggle(tax.id),
        className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
        autoComplete: "off"
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
        lineNumber: 64,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 63,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ml-3 text-sm", children: /* @__PURE__ */ jsxDEV("label", { htmlFor: `tax-${tax.id}`, className: "font-medium text-gray-700", children: [
      tax.name,
      " (",
      tax.rate,
      "%)"
    ] }, void 0, true, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 72,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 71,
      columnNumber: 17
    }, this)
  ] }, tax.id, true, {
    fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
    lineNumber: 62,
    columnNumber: 3
  }, this)
) }, void 0, false, {
  fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
  lineNumber: 60,
  columnNumber: 1
}, this);
export const TaxSelectionBlock = ({
  title,
  filterQuery,
  selectedIds,
  onChange,
  typeGroups
}) => {
  _s();
  const [flatTaxes, setFlatTaxes] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const typeGroupsKey = typeGroups?.length ? JSON.stringify(typeGroups) : "";
  const filterKey = JSON.stringify(filterQuery);
  useEffect(() => {
    const fetchTaxes = async () => {
      setLoading(true);
      try {
        const parsedGroups = typeGroupsKey ? JSON.parse(typeGroupsKey) : [];
        if (parsedGroups.length > 0) {
          const seenIds = /* @__PURE__ */ new Set();
          const nextSections = [];
          for (const group of parsedGroups) {
            const response = await getAll("taxes", buildGroupQuery(filterQuery, group));
            let items = (response.data || []).filter((t) => {
              if (seenIds.has(t.id)) return false;
              seenIds.add(t.id);
              return true;
            });
            if (group.type === 3) {
              items = items.filter((t) => Number(t.rate) > 0);
            }
            nextSections.push({ label: group.label, taxes: items });
          }
          setSections(nextSections);
          setFlatTaxes([]);
        } else {
          const response = await getAll("taxes", filterQuery);
          setFlatTaxes(response.data || []);
          setSections([]);
        }
      } catch (error) {
        console.error("Error fetching taxes", error);
      } finally {
        setLoading(false);
      }
    };
    void fetchTaxes();
  }, [filterKey, typeGroupsKey]);
  const handleCheckboxChange = useCallback(
    (taxId) => {
      if (selectedIds.includes(taxId)) {
        onChange(selectedIds.filter((id) => id !== taxId));
      } else {
        onChange([...selectedIds, taxId]);
      }
    },
    [selectedIds, onChange]
  );
  if (loading) return /* @__PURE__ */ jsxDEV("div", { className: "py-4", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
    lineNumber: 146,
    columnNumber: 45
  }, this) }, void 0, false, {
    fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
    lineNumber: 146,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "pt-8 border-t border-gray-200", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: title }, void 0, false, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 150,
      columnNumber: 13
    }, this),
    sections.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-8", children: sections.map(
      (section) => section.taxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 border-b border-gray-200 pb-2", children: section.label }, void 0, false, {
          fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
          lineNumber: 157,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: renderTaxGrid(section.taxes, selectedIds, handleCheckboxChange) }, void 0, false, {
          fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
          lineNumber: 160,
          columnNumber: 33
        }, this)
      ] }, section.label, true, {
        fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
        lineNumber: 156,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 border-b border-gray-200 pb-2", children: section.label }, void 0, false, {
          fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
          lineNumber: 166,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-500", children: "No hay impuestos en esta categoría." }, void 0, false, {
          fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
          lineNumber: 169,
          columnNumber: 33
        }, this)
      ] }, section.label, true, {
        fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
        lineNumber: 165,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 153,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: renderTaxGrid(flatTaxes, selectedIds, handleCheckboxChange) }, void 0, false, {
      fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
      lineNumber: 175,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/TaxSelectionBlock.tsx",
    lineNumber: 149,
    columnNumber: 5
  }, this);
};
_s(TaxSelectionBlock, "kLoUxQ4+AyVJkWdZWDNFzaX05xM=");
_c = TaxSelectionBlock;
var _c;
$RefreshReg$(_c, "TaxSelectionBlock");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/TaxSelectionBlock.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/TaxSelectionBlock.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzQ3BCLE9BQU9BLFNBQVNDLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUN4RCxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLHNCQUFzQjtBQThCL0IsTUFBTUMsa0JBQWtCQSxDQUFDQyxNQUE4QkMsV0FBaUQ7QUFBQSxFQUNwRyxHQUFHRDtBQUFBQSxFQUNILEdBQUlDLE1BQU1DLGtCQUFrQixDQUFDO0FBQUEsRUFDN0JDLE1BQU1DLE9BQU9ILE1BQU1FLElBQUk7QUFDM0I7QUFFQSxNQUFNRSxnQkFBZ0JBLENBQUNDLE9BQWtCQyxhQUF1QkMsYUFDNUQsdUJBQUMsU0FBSSxXQUFVLHdEQUNWRixnQkFBTUc7QUFBQUEsRUFBSSxDQUFBQyxRQUNQLHVCQUFDLFNBQWlCLFdBQVUsb0JBQ3hCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxJQUFJLE9BQU9BLElBQUlDLEVBQUU7QUFBQSxRQUNqQixNQUFLO0FBQUEsUUFDTCxTQUFTSixZQUFZSyxTQUFTRixJQUFJQyxFQUFFO0FBQUEsUUFDcEMsVUFBVSxNQUFNSCxTQUFTRSxJQUFJQyxFQUFFO0FBQUEsUUFDL0IsV0FBVTtBQUFBLFFBQXdFLGNBQWE7QUFBQTtBQUFBLE1BTG5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt3RyxLQU41RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDWCxpQ0FBQyxXQUFNLFNBQVMsT0FBT0QsSUFBSUMsRUFBRSxJQUFJLFdBQVUsNkJBQ3RDRDtBQUFBQSxVQUFJRztBQUFBQSxNQUFLO0FBQUEsTUFBR0gsSUFBSUk7QUFBQUEsTUFBSztBQUFBLFNBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLE9BYk1KLElBQUlDLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBQ0gsS0FqQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQWtCQTtBQUdHLGFBQU1JLG9CQUFzREEsQ0FBQztBQUFBLEVBQ2hFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBVjtBQUFBQSxFQUNBVztBQUFBQSxFQUNBQztBQUNKLE1BQU07QUFBQUMsS0FBQTtBQUNGLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJMUIsU0FBb0IsRUFBRTtBQUN4RCxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUk1QixTQUF1QixFQUFFO0FBQ3pELFFBQU0sQ0FBQzZCLFNBQVNDLFVBQVUsSUFBSTlCLFNBQVMsSUFBSTtBQUUzQyxRQUFNK0IsZ0JBQWdCUixZQUFZUyxTQUFTQyxLQUFLQyxVQUFVWCxVQUFVLElBQUk7QUFDeEUsUUFBTVksWUFBWUYsS0FBS0MsVUFBVWIsV0FBVztBQUU1Q3RCLFlBQVUsTUFBTTtBQUNaLFVBQU1xQyxhQUFhLFlBQVk7QUFDM0JOLGlCQUFXLElBQUk7QUFDZixVQUFJO0FBQ0EsY0FBTU8sZUFBZU4sZ0JBQ2RFLEtBQUtLLE1BQU1QLGFBQWEsSUFDekI7QUFFTixZQUFJTSxhQUFhTCxTQUFTLEdBQUc7QUFDekIsZ0JBQU1PLFVBQVUsb0JBQUlDLElBQVk7QUFDaEMsZ0JBQU1DLGVBQTZCO0FBRW5DLHFCQUFXcEMsU0FBU2dDLGNBQWM7QUFDOUIsa0JBQU1LLFdBQVcsTUFBTXpDLE9BQWdCLFNBQVNFLGdCQUFnQmtCLGFBQWFoQixLQUFLLENBQUM7QUFDbkYsZ0JBQUlzQyxTQUFTRCxTQUFTRSxRQUFRLElBQUlDLE9BQU8sQ0FBQUMsTUFBSztBQUMxQyxrQkFBSVAsUUFBUVEsSUFBSUQsRUFBRS9CLEVBQUUsRUFBRyxRQUFPO0FBQzlCd0Isc0JBQVFTLElBQUlGLEVBQUUvQixFQUFFO0FBQ2hCLHFCQUFPO0FBQUEsWUFDWCxDQUFDO0FBQ0QsZ0JBQUlWLE1BQU1FLFNBQVMsR0FBRztBQUNsQm9DLHNCQUFRQSxNQUFNRSxPQUFPLENBQUFDLE1BQUtHLE9BQU9ILEVBQUU1QixJQUFJLElBQUksQ0FBQztBQUFBLFlBQ2hEO0FBQ0F1Qix5QkFBYVMsS0FBSyxFQUFFQyxPQUFPOUMsTUFBTThDLE9BQU96QyxPQUFPaUMsTUFBTSxDQUFDO0FBQUEsVUFDMUQ7QUFDQWYsc0JBQVlhLFlBQVk7QUFDeEJmLHVCQUFhLEVBQUU7QUFBQSxRQUNuQixPQUFPO0FBQ0gsZ0JBQU1nQixXQUFXLE1BQU16QyxPQUFnQixTQUFTb0IsV0FBVztBQUMzREssdUJBQWFnQixTQUFTRSxRQUFRLEVBQUU7QUFDaENoQixzQkFBWSxFQUFFO0FBQUEsUUFDbEI7QUFBQSxNQUNKLFNBQVN3QixPQUFPO0FBQ1pDLGdCQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLE1BQy9DLFVBQUM7QUFDR3RCLG1CQUFXLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFDQSxTQUFLTSxXQUFXO0FBQUEsRUFDcEIsR0FBRyxDQUFDRCxXQUFXSixhQUFhLENBQUM7QUFFN0IsUUFBTXVCLHVCQUF1QnhEO0FBQUFBLElBQ3pCLENBQUN5RCxVQUFrQjtBQUNmLFVBQUk1QyxZQUFZSyxTQUFTdUMsS0FBSyxHQUFHO0FBQzdCakMsaUJBQVNYLFlBQVlrQyxPQUFPLENBQUE5QixPQUFNQSxPQUFPd0MsS0FBSyxDQUFDO0FBQUEsTUFDbkQsT0FBTztBQUNIakMsaUJBQVMsQ0FBQyxHQUFHWCxhQUFhNEMsS0FBSyxDQUFDO0FBQUEsTUFDcEM7QUFBQSxJQUNKO0FBQUEsSUFDQSxDQUFDNUMsYUFBYVcsUUFBUTtBQUFBLEVBQzFCO0FBRUEsTUFBSU8sUUFBUyxRQUFPLHVCQUFDLFNBQUksV0FBVSxRQUFPLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZSxLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdDO0FBRTVELFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGlDQUNYO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHFDQUFxQ1QsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUV4RE8sU0FBU0ssU0FBUyxJQUNmLHVCQUFDLFNBQUksV0FBVSxrQkFDVkwsbUJBQVNkO0FBQUFBLE1BQUksQ0FBQTJDLFlBQ1ZBLFFBQVE5QyxNQUFNc0IsU0FBUyxJQUNuQix1QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHVFQUNUd0Isa0JBQVFMLFNBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDVjFDLHdCQUFjK0MsUUFBUTlDLE9BQU9DLGFBQWEyQyxvQkFBb0IsS0FEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FOTUUsUUFBUUwsT0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLElBRUEsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUcsV0FBVSx1RUFDVEssa0JBQVFMLFNBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG1EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsV0FKdkVLLFFBQVFMLE9BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLElBRVIsS0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxRQUFRMUMsd0JBQWNnQixXQUFXZCxhQUFhMkMsb0JBQW9CLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUY7QUFBQSxPQTFCM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVSO0FBQUU5QixHQWxHV0wsbUJBQW1EO0FBQUFzQyxLQUFuRHRDO0FBQW1ELElBQUFzQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiZ2V0QWxsIiwiTG9hZGluZ1NwaW5uZXIiLCJidWlsZEdyb3VwUXVlcnkiLCJiYXNlIiwiZ3JvdXAiLCJxdWVyeU92ZXJyaWRlcyIsInR5cGUiLCJTdHJpbmciLCJyZW5kZXJUYXhHcmlkIiwidGF4ZXMiLCJzZWxlY3RlZElkcyIsIm9uVG9nZ2xlIiwibWFwIiwidGF4IiwiaWQiLCJpbmNsdWRlcyIsIm5hbWUiLCJyYXRlIiwiVGF4U2VsZWN0aW9uQmxvY2siLCJ0aXRsZSIsImZpbHRlclF1ZXJ5Iiwib25DaGFuZ2UiLCJ0eXBlR3JvdXBzIiwiX3MiLCJmbGF0VGF4ZXMiLCJzZXRGbGF0VGF4ZXMiLCJzZWN0aW9ucyIsInNldFNlY3Rpb25zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ0eXBlR3JvdXBzS2V5IiwibGVuZ3RoIiwiSlNPTiIsInN0cmluZ2lmeSIsImZpbHRlcktleSIsImZldGNoVGF4ZXMiLCJwYXJzZWRHcm91cHMiLCJwYXJzZSIsInNlZW5JZHMiLCJTZXQiLCJuZXh0U2VjdGlvbnMiLCJyZXNwb25zZSIsIml0ZW1zIiwiZGF0YSIsImZpbHRlciIsInQiLCJoYXMiLCJhZGQiLCJOdW1iZXIiLCJwdXNoIiwibGFiZWwiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVDaGVja2JveENoYW5nZSIsInRheElkIiwic2VjdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRheFNlbGVjdGlvbkJsb2NrLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy9jb21tb24vVGF4U2VsZWN0aW9uQmxvY2sudHN4XG5pbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRBbGwgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vdWkvTG9hZGluZ1NwaW5uZXInO1xuXG5leHBvcnQgaW50ZXJmYWNlIFRheEl0ZW0ge1xuICAgIGlkOiBudW1iZXI7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIHJhdGU6IG51bWJlcjtcbiAgICB0eXBlPzogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRheFR5cGVHcm91cCB7XG4gICAgdHlwZTogbnVtYmVyO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgLyoqIFBhcsOhbWV0cm9zIGV4dHJhIGRlbCBHRVQgYHRheGVzYCBzb2xvIHBhcmEgZXN0ZSBncnVwbyAocC4gZWouIHBvc2l0aXZlX3JhdGVfb25seSBlbiByZXRlbmNpb25lcykuICovXG4gICAgcXVlcnlPdmVycmlkZXM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xufVxuXG5pbnRlcmZhY2UgVGF4U2VjdGlvbiB7XG4gICAgbGFiZWw6IHN0cmluZztcbiAgICB0YXhlczogVGF4SXRlbVtdO1xufVxuXG5pbnRlcmZhY2UgVGF4U2VsZWN0aW9uQmxvY2tQcm9wcyB7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBmaWx0ZXJRdWVyeTogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgICBzZWxlY3RlZElkczogbnVtYmVyW107XG4gICAgb25DaGFuZ2U6IChpZHM6IG51bWJlcltdKSA9PiB2b2lkO1xuICAgIC8qKiBTaSB0aWVuZSBlbGVtZW50b3MsIHNlIGhhY2UgdW5hIHBldGljacOzbiBwb3IgdGlwbyB5IHNlIG11ZXN0cmFuIHN1YnNlY2Npb25lcyBjb24gdMOtdHVsby4gKi9cbiAgICB0eXBlR3JvdXBzPzogVGF4VHlwZUdyb3VwW107XG59XG5cbmNvbnN0IGJ1aWxkR3JvdXBRdWVyeSA9IChiYXNlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LCBncm91cDogVGF4VHlwZUdyb3VwKTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9PiAoe1xuICAgIC4uLmJhc2UsXG4gICAgLi4uKGdyb3VwLnF1ZXJ5T3ZlcnJpZGVzID8/IHt9KSxcbiAgICB0eXBlOiBTdHJpbmcoZ3JvdXAudHlwZSksXG59KTtcblxuY29uc3QgcmVuZGVyVGF4R3JpZCA9ICh0YXhlczogVGF4SXRlbVtdLCBzZWxlY3RlZElkczogbnVtYmVyW10sIG9uVG9nZ2xlOiAoaWQ6IG51bWJlcikgPT4gdm9pZCkgPT4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNCBtZDpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNFwiPlxuICAgICAgICB7dGF4ZXMubWFwKHRheCA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17dGF4LmlkfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBoLTVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD17YHRheC0ke3RheC5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkSWRzLmluY2x1ZGVzKHRheC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25Ub2dnbGUodGF4LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1pbmRpZ28tNjAwIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2B0YXgtJHt0YXguaWR9YH0gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3RheC5uYW1lfSAoe3RheC5yYXRlfSUpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgPC9kaXY+XG4pO1xuXG5leHBvcnQgY29uc3QgVGF4U2VsZWN0aW9uQmxvY2s6IFJlYWN0LkZDPFRheFNlbGVjdGlvbkJsb2NrUHJvcHM+ID0gKHtcbiAgICB0aXRsZSxcbiAgICBmaWx0ZXJRdWVyeSxcbiAgICBzZWxlY3RlZElkcyxcbiAgICBvbkNoYW5nZSxcbiAgICB0eXBlR3JvdXBzLFxufSkgPT4ge1xuICAgIGNvbnN0IFtmbGF0VGF4ZXMsIHNldEZsYXRUYXhlc10gPSB1c2VTdGF0ZTxUYXhJdGVtW10+KFtdKTtcbiAgICBjb25zdCBbc2VjdGlvbnMsIHNldFNlY3Rpb25zXSA9IHVzZVN0YXRlPFRheFNlY3Rpb25bXT4oW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgY29uc3QgdHlwZUdyb3Vwc0tleSA9IHR5cGVHcm91cHM/Lmxlbmd0aCA/IEpTT04uc3RyaW5naWZ5KHR5cGVHcm91cHMpIDogJyc7XG4gICAgY29uc3QgZmlsdGVyS2V5ID0gSlNPTi5zdHJpbmdpZnkoZmlsdGVyUXVlcnkpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZmV0Y2hUYXhlcyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZEdyb3VwcyA9IHR5cGVHcm91cHNLZXlcbiAgICAgICAgICAgICAgICAgICAgPyAoSlNPTi5wYXJzZSh0eXBlR3JvdXBzS2V5KSBhcyBUYXhUeXBlR3JvdXBbXSlcbiAgICAgICAgICAgICAgICAgICAgOiBbXTtcblxuICAgICAgICAgICAgICAgIGlmIChwYXJzZWRHcm91cHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzZWVuSWRzID0gbmV3IFNldDxudW1iZXI+KCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHRTZWN0aW9uczogVGF4U2VjdGlvbltdID0gW107XG5cbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBncm91cCBvZiBwYXJzZWRHcm91cHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZ2V0QWxsPFRheEl0ZW0+KCd0YXhlcycsIGJ1aWxkR3JvdXBRdWVyeShmaWx0ZXJRdWVyeSwgZ3JvdXApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpdGVtcyA9IChyZXNwb25zZS5kYXRhIHx8IFtdKS5maWx0ZXIodCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlZW5JZHMuaGFzKHQuaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vlbklkcy5hZGQodC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChncm91cC50eXBlID09PSAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXMgPSBpdGVtcy5maWx0ZXIodCA9PiBOdW1iZXIodC5yYXRlKSA+IDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmV4dFNlY3Rpb25zLnB1c2goeyBsYWJlbDogZ3JvdXAubGFiZWwsIHRheGVzOiBpdGVtcyB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzZXRTZWN0aW9ucyhuZXh0U2VjdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICBzZXRGbGF0VGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZ2V0QWxsPFRheEl0ZW0+KCd0YXhlcycsIGZpbHRlclF1ZXJ5KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RmxhdFRheGVzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xuICAgICAgICAgICAgICAgICAgICBzZXRTZWN0aW9ucyhbXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyB0YXhlcycsIGVycm9yKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHZvaWQgZmV0Y2hUYXhlcygpO1xuICAgIH0sIFtmaWx0ZXJLZXksIHR5cGVHcm91cHNLZXldKTtcblxuICAgIGNvbnN0IGhhbmRsZUNoZWNrYm94Q2hhbmdlID0gdXNlQ2FsbGJhY2soXG4gICAgICAgICh0YXhJZDogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRJZHMuaW5jbHVkZXModGF4SWQpKSB7XG4gICAgICAgICAgICAgICAgb25DaGFuZ2Uoc2VsZWN0ZWRJZHMuZmlsdGVyKGlkID0+IGlkICE9PSB0YXhJZCkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBvbkNoYW5nZShbLi4uc2VsZWN0ZWRJZHMsIHRheElkXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFtzZWxlY3RlZElkcywgb25DaGFuZ2VdXG4gICAgKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJweS00XCI+PExvYWRpbmdTcGlubmVyIC8+PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC04IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPnt0aXRsZX08L2gyPlxuXG4gICAgICAgICAgICB7c2VjdGlvbnMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS04XCI+XG4gICAgICAgICAgICAgICAgICAgIHtzZWN0aW9ucy5tYXAoc2VjdGlvbiA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi50YXhlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtzZWN0aW9uLmxhYmVsfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWN0aW9uLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJUYXhHcmlkKHNlY3Rpb24udGF4ZXMsIHNlbGVjdGVkSWRzLCBoYW5kbGVDaGVja2JveENoYW5nZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17c2VjdGlvbi5sYWJlbH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VjdGlvbi5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgaW1wdWVzdG9zIGVuIGVzdGEgY2F0ZWdvcsOtYS48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPntyZW5kZXJUYXhHcmlkKGZsYXRUYXhlcywgc2VsZWN0ZWRJZHMsIGhhbmRsZUNoZWNrYm94Q2hhbmdlKX08L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9UYXhTZWxlY3Rpb25CbG9jay50c3gifQ==