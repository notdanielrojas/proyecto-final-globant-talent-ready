import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { movimientosBancosModuleConfig } from "/src/features/movimientos_bancos/movimientos_bancos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const MovimientosBancosDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: movement, loading, error } = useCrudItem(movimientosBancosModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del movimiento..." }, void 0, false, {
    fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  if (!movement) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento de banco no encontrado." }, void 0, false, {
    fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 25
  }, this);
  const isOriginatedFromCollectionOrPayment = !!movement.source_type && movement.source_id != null && (movement.source_type.includes("Collection") || movement.source_type.includes("PaymentOrder"));
  const renderExtraContent = (item) => {
    if (item.value_type !== "DEPOSITO" || !item.deposited_checks?.length) return null;
    return /* @__PURE__ */ jsxDEV("div", { className: "border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-2 bg-gray-50 rounded-t-md", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: "Cheques depositados" }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
        lineNumber: 45,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
        lineNumber: 44,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Nº Cheque" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 51,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Valor" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 52,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Banco" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 53,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Referencia" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 54,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Fecha venc." }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 55,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
          lineNumber: 50,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
          lineNumber: 49,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: item.deposited_checks.map(
          (c) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: c.collection_id != null ? /* @__PURE__ */ jsxDEV(Link, { to: `/cobranzas/${c.collection_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: c.check_number }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 63,
              columnNumber: 19
            }, this) : c.check_number }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 61,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-right text-gray-900", children: formatValue(Number(c.value), "currency") }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 70,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: c.bank_name ?? "-" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 71,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: c.reference_number ?? "-" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 72,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: c.check_due_date ?? "-" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
              lineNumber: 73,
              columnNumber: 37
            }, this)
          ] }, c.id, true, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
            lineNumber: 60,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
          lineNumber: 58,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
        lineNumber: 48,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
        lineNumber: 47,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(
    GenericDetailPage,
    {
      config: movimientosBancosModuleConfig,
      item: movement,
      hideHeader: false,
      renderExtraContent,
      canEditOverride: !isOriginatedFromCollectionOrPayment
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx",
      lineNumber: 84,
      columnNumber: 5
    },
    this
  );
};
_s(MovimientosBancosDetailPage, "z1Bhd3UGhI7LfZmz3s+T8AkEJRQ=", false, function() {
  return [useParams, useCrudItem];
});
_c = MovimientosBancosDetailPage;
var _c;
$RefreshReg$(_c, "MovimientosBancosDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxXQUFXQyxZQUFZO0FBQ2hDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MscUNBQXdEO0FBQ2pFLFNBQVNDLG1CQUFtQjtBQUVyQixhQUFNQyw4QkFBOEJBLE1BQU07QUFBQUMsS0FBQTtBQUM3QyxRQUFNLEVBQUVDLEdBQUcsSUFBSVIsVUFBMEI7QUFDekMsUUFBTSxFQUFFUyxNQUFNQyxVQUFVQyxTQUFTQyxNQUFNLElBQUlQLFlBQTBCRCwrQkFBK0JJLEVBQUU7QUFFdEcsTUFBSUcsUUFBUyxRQUFPLHVCQUFDLFNBQUksa0RBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1QztBQUMzRCxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDRixTQUFVLFFBQU8sdUJBQUMsU0FBSSxrREFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVDO0FBRTdELFFBQU1HLHNDQUNGLENBQUMsQ0FBQ0gsU0FBU0ksZUFDWEosU0FBU0ssYUFBYSxTQUNyQkwsU0FBU0ksWUFBWUUsU0FBUyxZQUFZLEtBQUtOLFNBQVNJLFlBQVlFLFNBQVMsY0FBYztBQUVoRyxRQUFNQyxxQkFBcUJBLENBQUNSLFNBQXVCO0FBQy9DLFFBQUlBLEtBQUtTLGVBQWUsY0FBYyxDQUFDVCxLQUFLVSxrQkFBa0JDLE9BQVEsUUFBTztBQUM3RSxXQUNJLHVCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSx1RUFDWCxpQ0FBQyxRQUFHLFdBQVUscUNBQW9DLG1DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFLEtBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsbUVBQWtFLHlCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUscUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFDdEYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxRQUFHLFdBQVUsbUVBQWtFLDBCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQzFGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0UsMkJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsYUFML0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pYLGVBQUtVLGlCQUFpQkU7QUFBQUEsVUFBSSxDQUFDQyxNQUN4Qix1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1DQUNUQSxZQUFFQyxpQkFBaUIsT0FDaEIsdUJBQUMsUUFBSyxJQUFJLGNBQWNELEVBQUVDLGFBQWEsSUFBSSxXQUFVLHlEQUNoREQsWUFBRUUsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUVBRixFQUFFRSxnQkFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsOENBQThDckIsc0JBQVlzQixPQUFPSCxFQUFFSSxLQUFLLEdBQUcsVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNKLFlBQUVLLGFBQWEsT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DTCxZQUFFTSxvQkFBb0IsT0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DTixZQUFFTyxrQkFBa0IsT0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxlQWJwRVAsRUFBRWQsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsUUFDSCxLQWpCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsV0E1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQSxLQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBO0FBQUEsU0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9DQTtBQUFBLEVBRVI7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRSjtBQUFBQSxNQUNSLE1BQU1NO0FBQUFBLE1BQ04sWUFBWTtBQUFBLE1BQ1o7QUFBQSxNQUVBLGlCQUFpQixDQUFDRztBQUFBQTtBQUFBQSxJQU50QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNMEQ7QUFHbEU7QUFBRU4sR0FsRVdELDZCQUEyQjtBQUFBLFVBQ3JCTixXQUM0QkssV0FBVztBQUFBO0FBQUF5QixLQUY3Q3hCO0FBQTJCLElBQUF3QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiTGluayIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiZm9ybWF0VmFsdWUiLCJtb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiTW92aW1pZW50b3NCYW5jb3NEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJtb3ZlbWVudCIsImxvYWRpbmciLCJlcnJvciIsImlzT3JpZ2luYXRlZEZyb21Db2xsZWN0aW9uT3JQYXltZW50Iiwic291cmNlX3R5cGUiLCJzb3VyY2VfaWQiLCJpbmNsdWRlcyIsInJlbmRlckV4dHJhQ29udGVudCIsInZhbHVlX3R5cGUiLCJkZXBvc2l0ZWRfY2hlY2tzIiwibGVuZ3RoIiwibWFwIiwiYyIsImNvbGxlY3Rpb25faWQiLCJjaGVja19udW1iZXIiLCJOdW1iZXIiLCJ2YWx1ZSIsImJhbmtfbmFtZSIsInJlZmVyZW5jZV9udW1iZXIiLCJjaGVja19kdWVfZGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vdmltaWVudG9zQmFuY29zRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL21vdmltaWVudG9zX2JhbmNvcy9wYWdlcy9Nb3ZpbWllbnRvc0JhbmNvc0RldGFpbFBhZ2UudHN4XG5pbXBvcnQgeyB1c2VQYXJhbXMsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IG1vdmltaWVudG9zQmFuY29zTW9kdWxlQ29uZmlnLCB0eXBlIEJhbmtNb3ZlbWVudCB9IGZyb20gJy4uL21vdmltaWVudG9zX2JhbmNvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5cbmV4cG9ydCBjb25zdCBNb3ZpbWllbnRvc0JhbmNvc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbTogbW92ZW1lbnQsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxCYW5rTW92ZW1lbnQ+KG1vdmltaWVudG9zQmFuY29zTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGV0YWxsZSBkZWwgbW92aW1pZW50by4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFtb3ZlbWVudCkgcmV0dXJuIDxkaXY+TW92aW1pZW50byBkZSBiYW5jbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IGlzT3JpZ2luYXRlZEZyb21Db2xsZWN0aW9uT3JQYXltZW50ID1cbiAgICAgICAgISFtb3ZlbWVudC5zb3VyY2VfdHlwZSAmJlxuICAgICAgICBtb3ZlbWVudC5zb3VyY2VfaWQgIT0gbnVsbCAmJlxuICAgICAgICAobW92ZW1lbnQuc291cmNlX3R5cGUuaW5jbHVkZXMoJ0NvbGxlY3Rpb24nKSB8fCBtb3ZlbWVudC5zb3VyY2VfdHlwZS5pbmNsdWRlcygnUGF5bWVudE9yZGVyJykpO1xuXG4gICAgY29uc3QgcmVuZGVyRXh0cmFDb250ZW50ID0gKGl0ZW06IEJhbmtNb3ZlbWVudCkgPT4ge1xuICAgICAgICBpZiAoaXRlbS52YWx1ZV90eXBlICE9PSAnREVQT1NJVE8nIHx8ICFpdGVtLmRlcG9zaXRlZF9jaGVja3M/Lmxlbmd0aCkgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCBweS0yIGJnLWdyYXktNTAgcm91bmRlZC10LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5DaGVxdWVzIGRlcG9zaXRhZG9zPC9oND5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPk7CuiBDaGVxdWU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlZhbG9yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkJhbmNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlJlZmVyZW5jaWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+RmVjaGEgdmVuYy48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRlcG9zaXRlZF9jaGVja3MubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2MuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Yy5jb2xsZWN0aW9uX2lkICE9IG51bGwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2NvYnJhbnphcy8ke2MuY29sbGVjdGlvbl9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2MuY2hlY2tfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYy5jaGVja19udW1iZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUoTnVtYmVyKGMudmFsdWUpLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57Yy5iYW5rX25hbWUgPz8gJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntjLnJlZmVyZW5jZV9udW1iZXIgPz8gJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntjLmNoZWNrX2R1ZV9kYXRlID8/ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17bW92aW1pZW50b3NCYW5jb3NNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpdGVtPXttb3ZlbWVudH1cbiAgICAgICAgICAgIGhpZGVIZWFkZXI9e2ZhbHNlfVxuICAgICAgICAgICAgcmVuZGVyRXh0cmFDb250ZW50PXtyZW5kZXJFeHRyYUNvbnRlbnR9XG4gICAgICAgICAgICAvLyBFbCBkZXRhbGxlIGNvbnRyb2xhIGVsIGJvdMOzbiBFZGl0YXIgc2Vnw7puIGVzdGUgZmxhZ1xuICAgICAgICAgICAgY2FuRWRpdE92ZXJyaWRlPXshaXNPcmlnaW5hdGVkRnJvbUNvbGxlY3Rpb25PclBheW1lbnR9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21vdmltaWVudG9zX2JhbmNvcy9wYWdlcy9Nb3ZpbWllbnRvc0JhbmNvc0RldGFpbFBhZ2UudHN4In0=