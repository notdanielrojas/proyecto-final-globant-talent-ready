import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/EntityDetailPageLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/EntityDetailPageLayout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaPencilAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { IoArrowBack } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { AccountMovementsTab } from "/src/components/common/AccountMovementsTab.tsx";
import { VendorMovementsTab } from "/src/components/common/VendorMovementsTab.tsx";
import { ProductMovementsTab } from "/src/components/common/ProductMovementsTab.tsx";
import { ProductHistoryClientTab } from "/src/components/common/ProductHistoryClientTab.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const EntityDetailPageLayout = ({ config, item, entityType, customDetailComponent, tabs }) => {
  _s();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { hasModulePermission } = usePermissions();
  const tabFromUrl = searchParams.get("tab");
  const validTabIds = useMemo(() => tabs.map((t) => t.id), [tabs]);
  const initialTab = tabFromUrl && validTabIds.includes(tabFromUrl) ? tabFromUrl : "details";
  const [activeTab, setActiveTab] = useState(initialTab);
  useEffect(() => {
    const tab = searchParams.get("tab");
    if (tab && validTabIds.includes(tab)) setActiveTab(tab);
  }, [searchParams, validTabIds]);
  const modulePermission = getRequiredPermission(config.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const getTabClassName = (tabId) => {
    return `px-3 py-2 text-sm font-medium rounded-t-md ${activeTab === tabId ? "border-b-2 border-indigo-500 text-indigo-600" : "border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`;
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(config.baseRoute)), className: "p-1 mr-2 text-gray-600 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 89,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 88,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold text-gray-900", children: [
          config.moduleName,
          ": ",
          item[config.detail.displayNameKey] || item.id
        ] }, void 0, true, {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 91,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-3 space-x-3 sm:mt-0 sm:ml-4", children: canEdit && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(`${config.baseRoute}/${item.id}/editar`), className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
        /* @__PURE__ */ jsxDEV(FaPencilAlt, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 98,
          columnNumber: 29
        }, this),
        " Editar"
      ] }, void 0, true, {
        fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
        lineNumber: 97,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
        lineNumber: 95,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
      lineNumber: 86,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("nav", { className: "flex -mb-px space-x-8", "aria-label": "Tabs", children: tabs.map(
      (tab) => /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab(tab.id), className: getTabClassName(tab.id), children: tab.name }, tab.id, false, {
        fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
        lineNumber: 108,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
      lineNumber: 106,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
      lineNumber: 105,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      activeTab === "details" && (customDetailComponent ? customDetailComponent : /* @__PURE__ */ jsxDEV(GenericDetailPage, { config, item, hideHeader: true }, void 0, false, {
        fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
        lineNumber: 118,
        columnNumber: 57
      }, this)),
      activeTab === "movements" && entityType === "client" && /* @__PURE__ */ jsxDEV(
        AccountMovementsTab,
        {
          entityId: item.id,
          endpoint: "customer-accounts"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 123,
          columnNumber: 9
        },
        this
      ),
      activeTab === "movements" && entityType === "provider" && /* @__PURE__ */ jsxDEV(
        VendorMovementsTab,
        {
          entityId: item.id,
          endpoint: "vendor-accounts"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 129,
          columnNumber: 9
        },
        this
      ),
      activeTab === "movements" && entityType === "product" && /* @__PURE__ */ jsxDEV(
        ProductMovementsTab,
        {
          entityId: item.id,
          endpoint: "stock-movements"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 135,
          columnNumber: 9
        },
        this
      ),
      activeTab === "sales_history" && /* @__PURE__ */ jsxDEV(
        ProductHistoryClientTab,
        {
          entityId: item.id,
          endpoint: "latest-products"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
          lineNumber: 141,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
      lineNumber: 116,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/EntityDetailPageLayout.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
};
_s(EntityDetailPageLayout, "lddLOCgSF9xbjZXtwED0/Qx99R0=", false, function() {
  return [useNavigate, useSearchParams, usePermissions];
});
_c = EntityDetailPageLayout;
var _c;
$RefreshReg$(_c, "EntityDetailPageLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/EntityDetailPageLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/EntityDetailPageLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUV3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyRXhCLFNBQVNBLFVBQVVDLFNBQVNDLGlCQUFpQjtBQUM3QyxTQUFTQyxhQUFhQyx1QkFBdUI7QUFDN0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyx5QkFBeUI7QUFFbEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx1QkFBdUJDLCtCQUErQjtBQUMvRCxTQUFTQyx5QkFBeUI7QUF1QjNCLGFBQU1DLHlCQUF5QixDQUF5QixFQUFFQyxRQUFRQyxNQUFNQyxZQUFZQyx1QkFBdUJDLEtBQXFDLE1BQU07QUFBQUMsS0FBQTtBQUN6SixRQUFNQyxXQUFXcEIsWUFBWTtBQUM3QixRQUFNLENBQUNxQixZQUFZLElBQUlwQixnQkFBZ0I7QUFDdkMsUUFBTSxFQUFFcUIsb0JBQW9CLElBQUliLGVBQWU7QUFDL0MsUUFBTWMsYUFBYUYsYUFBYUcsSUFBSSxLQUFLO0FBQ3pDLFFBQU1DLGNBQWMzQixRQUFRLE1BQU1vQixLQUFLUSxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLEVBQUUsR0FBRyxDQUFDVixJQUFJLENBQUM7QUFDL0QsUUFBTVcsYUFBY04sY0FBY0UsWUFBWUssU0FBU1AsVUFBVSxJQUFLQSxhQUFhO0FBQ25GLFFBQU0sQ0FBQ1EsV0FBV0MsWUFBWSxJQUFJbkMsU0FBU2dDLFVBQVU7QUFFckQ5QixZQUFVLE1BQU07QUFDWixVQUFNa0MsTUFBTVosYUFBYUcsSUFBSSxLQUFLO0FBQ2xDLFFBQUlTLE9BQU9SLFlBQVlLLFNBQVNHLEdBQUcsRUFBR0QsY0FBYUMsR0FBRztBQUFBLEVBQzFELEdBQUcsQ0FBQ1osY0FBY0ksV0FBVyxDQUFDO0FBRzlCLFFBQU1TLG1CQUFtQnhCLHNCQUFzQkksT0FBT3FCLFNBQVM7QUFDL0QsUUFBTUMsYUFBYUYsbUJBQW1CdkIsd0JBQXdCdUIsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsVUFBVUQsYUFBYWQsb0JBQW9CYyxZQUFZLE1BQU0sSUFBSTtBQUV2RSxRQUFNRSxrQkFBa0JBLENBQUNDLFVBQWtCO0FBQ3ZDLFdBQU8sOENBQThDUixjQUFjUSxRQUM3RCxpREFDQSx1RkFBdUY7QUFBQSxFQUVqRztBQUdBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHFDQUVYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlFQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsK0JBQUMsWUFBTyxTQUFTLE1BQU1uQixTQUFTUixrQkFBa0JFLE9BQU9xQixTQUFTLENBQUMsR0FBRyxXQUFVLHlEQUM1RSxpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSx1Q0FDVHJCO0FBQUFBLGlCQUFPMEI7QUFBQUEsVUFBVztBQUFBLFVBQUd6QixLQUFLRCxPQUFPMkIsT0FBT0MsY0FBYyxLQUFLM0IsS0FBS2E7QUFBQUEsYUFEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxvREFDVlMscUJBQ0csdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNakIsU0FBUyxHQUFHTixPQUFPcUIsU0FBUyxJQUFJcEIsS0FBS2EsRUFBRSxTQUFTLEdBQUcsV0FBVSxzSkFDOUY7QUFBQSwrQkFBQyxlQUFZLFdBQVUsd0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUFHO0FBQUEsV0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1gsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixjQUFXLFFBQzdDVixlQUFLUTtBQUFBQSxNQUFJLENBQUNPLFFBQ1AsdUJBQUMsWUFBb0IsU0FBUyxNQUFNRCxhQUFhQyxJQUFJTCxFQUFFLEdBQUcsV0FBV1UsZ0JBQWdCTCxJQUFJTCxFQUFFLEdBQ3RGSyxjQUFJVSxRQURJVixJQUFJTCxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUNILEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFHQSx1QkFBQyxTQUNJRztBQUFBQSxvQkFBYyxjQUNYZCx3QkFBd0JBLHdCQUF3Qix1QkFBQyxxQkFBa0IsUUFBZ0IsTUFBWSxZQUFZLFFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUluSGMsY0FBYyxlQUFlZixlQUFlLFlBQ3pDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxVQUFVRCxLQUFLYTtBQUFBQSxVQUNmLFVBQVM7QUFBQTtBQUFBLFFBRmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRWlDO0FBQUEsTUFHcENHLGNBQWMsZUFBZWYsZUFBZSxjQUN6QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csVUFBVUQsS0FBS2E7QUFBQUEsVUFDZixVQUFTO0FBQUE7QUFBQSxRQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUUrQjtBQUFBLE1BR2xDRyxjQUFjLGVBQWVmLGVBQWUsYUFDekM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFVBQVVELEtBQUthO0FBQUFBLFVBQ2YsVUFBUztBQUFBO0FBQUEsUUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFK0I7QUFBQSxNQUdsQ0csY0FBYyxtQkFDWDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csVUFBVWhCLEtBQUthO0FBQUFBLFVBQ2YsVUFBUztBQUFBO0FBQUEsUUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFK0I7QUFBQSxTQTNCdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BOURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErREE7QUFFUjtBQUFFVCxHQTdGV04sd0JBQXNCO0FBQUEsVUFDZGIsYUFDTUMsaUJBQ1NRLGNBQWM7QUFBQTtBQUFBbUMsS0FIckMvQjtBQUFzQixJQUFBK0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZUVmZmVjdCIsInVzZU5hdmlnYXRlIiwidXNlU2VhcmNoUGFyYW1zIiwiRmFQZW5jaWxBbHQiLCJJb0Fycm93QmFjayIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiQWNjb3VudE1vdmVtZW50c1RhYiIsIlZlbmRvck1vdmVtZW50c1RhYiIsIlByb2R1Y3RNb3ZlbWVudHNUYWIiLCJQcm9kdWN0SGlzdG9yeUNsaWVudFRhYiIsInVzZVBlcm1pc3Npb25zIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJnZXRMaXN0UmV0dXJuUGF0aCIsIkVudGl0eURldGFpbFBhZ2VMYXlvdXQiLCJjb25maWciLCJpdGVtIiwiZW50aXR5VHlwZSIsImN1c3RvbURldGFpbENvbXBvbmVudCIsInRhYnMiLCJfcyIsIm5hdmlnYXRlIiwic2VhcmNoUGFyYW1zIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsInRhYkZyb21VcmwiLCJnZXQiLCJ2YWxpZFRhYklkcyIsIm1hcCIsInQiLCJpZCIsImluaXRpYWxUYWIiLCJpbmNsdWRlcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInRhYiIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdCIsImdldFRhYkNsYXNzTmFtZSIsInRhYklkIiwibW9kdWxlTmFtZSIsImRldGFpbCIsImRpc3BsYXlOYW1lS2V5IiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVudGl0eURldGFpbFBhZ2VMYXlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VNZW1vLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBGYVBlbmNpbEFsdCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IElvQXJyb3dCYWNrIH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuL0dlbmVyaWNEZXRhaWxQYWdlJztcbi8vIOKchSBJTVBPUlRBQ0lPTkVTIEFDVFVBTElaQURBU1xuaW1wb3J0IHsgQWNjb3VudE1vdmVtZW50c1RhYiB9IGZyb20gJy4vQWNjb3VudE1vdmVtZW50c1RhYic7XG5pbXBvcnQgeyBWZW5kb3JNb3ZlbWVudHNUYWIgfSBmcm9tICcuL1ZlbmRvck1vdmVtZW50c1RhYic7XG5pbXBvcnQgeyBQcm9kdWN0TW92ZW1lbnRzVGFiIH0gZnJvbSAnLi9Qcm9kdWN0TW92ZW1lbnRzVGFiJztcbmltcG9ydCB7IFByb2R1Y3RIaXN0b3J5Q2xpZW50VGFiIH0gZnJvbSAnLi9Qcm9kdWN0SGlzdG9yeUNsaWVudFRhYic7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLy8gLS0tIFRJUE9TIC0tLVxuXG50eXBlIEVudGl0eVdpdGhJZCA9IHtcbiAgICBpZDogc3RyaW5nIHwgbnVtYmVyO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgW2tleTogc3RyaW5nXTogYW55O1xufTtcblxudHlwZSBFbnRpdHlUYWIgPSB7XG4gICAgaWQ6IHN0cmluZztcbiAgICBuYW1lOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBFbnRpdHlEZXRhaWxQYWdlTGF5b3V0UHJvcHM8VCBleHRlbmRzIEVudGl0eVdpdGhJZD4ge1xuICAgIGNvbmZpZzogTW9kdWxlQ29uZmlnPFQ+O1xuICAgIGl0ZW06IFQ7XG4gICAgZW50aXR5VHlwZTogJ2NsaWVudCcgfCAncHJvZHVjdCcgfCAncHJvdmlkZXInO1xuICAgIGN1c3RvbURldGFpbENvbXBvbmVudD86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgICB0YWJzOiBFbnRpdHlUYWJbXTtcbn1cblxuZXhwb3J0IGNvbnN0IEVudGl0eURldGFpbFBhZ2VMYXlvdXQgPSA8VCBleHRlbmRzIEVudGl0eVdpdGhJZD4oeyBjb25maWcsIGl0ZW0sIGVudGl0eVR5cGUsIGN1c3RvbURldGFpbENvbXBvbmVudCwgdGFicyB9OiBFbnRpdHlEZXRhaWxQYWdlTGF5b3V0UHJvcHM8VD4pID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCB7IGhhc01vZHVsZVBlcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gICAgY29uc3QgdGFiRnJvbVVybCA9IHNlYXJjaFBhcmFtcy5nZXQoJ3RhYicpO1xuICAgIGNvbnN0IHZhbGlkVGFiSWRzID0gdXNlTWVtbygoKSA9PiB0YWJzLm1hcCgodCkgPT4gdC5pZCksIFt0YWJzXSk7XG4gICAgY29uc3QgaW5pdGlhbFRhYiA9ICh0YWJGcm9tVXJsICYmIHZhbGlkVGFiSWRzLmluY2x1ZGVzKHRhYkZyb21VcmwpKSA/IHRhYkZyb21VcmwgOiAnZGV0YWlscyc7XG4gICAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKGluaXRpYWxUYWIpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgdGFiID0gc2VhcmNoUGFyYW1zLmdldCgndGFiJyk7XG4gICAgICAgIGlmICh0YWIgJiYgdmFsaWRUYWJJZHMuaW5jbHVkZXModGFiKSkgc2V0QWN0aXZlVGFiKHRhYik7XG4gICAgfSwgW3NlYXJjaFBhcmFtcywgdmFsaWRUYWJJZHNdKTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihjb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBjYW5FZGl0ID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG5cbiAgICBjb25zdCBnZXRUYWJDbGFzc05hbWUgPSAodGFiSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICByZXR1cm4gYHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJvdW5kZWQtdC1tZCAke2FjdGl2ZVRhYiA9PT0gdGFiSWRcbiAgICAgICAgICAgID8gJ2JvcmRlci1iLTIgYm9yZGVyLWluZGlnby01MDAgdGV4dC1pbmRpZ28tNjAwJ1xuICAgICAgICAgICAgOiAnYm9yZGVyLWItMiBib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgIH1gO1xuICAgIH07XG5cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICB7LyogLS0tIENBQkVDRVJBIChCb3RvbmVzIFZvbHZlci9FZGl0YXIpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGItNCBtYi00IGJvcmRlci1iIHNtOmZsZXggc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChjb25maWcuYmFzZVJvdXRlKSl9IGNsYXNzTmFtZT1cInAtMSBtci0yIHRleHQtZ3JheS02MDAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9BcnJvd0JhY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb25maWcubW9kdWxlTmFtZX06IHtpdGVtW2NvbmZpZy5kZXRhaWwuZGlzcGxheU5hbWVLZXldIHx8IGl0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC0zIHNwYWNlLXgtMyBzbTptdC0wIHNtOm1sLTRcIj5cbiAgICAgICAgICAgICAgICAgICAge2NhbkVkaXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYCR7Y29uZmlnLmJhc2VSb3V0ZX0vJHtpdGVtLmlkfS9lZGl0YXJgKX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQZW5jaWxBbHQgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yIC1tbC0xXCIgLz4gRWRpdGFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIFBFU1RBw5FBUyBERSBOQVZFR0FDScOTTiAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCAtbWItcHggc3BhY2UteC04XCIgYXJpYS1sYWJlbD1cIlRhYnNcIj5cbiAgICAgICAgICAgICAgICAgICAge3RhYnMubWFwKCh0YWIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24ga2V5PXt0YWIuaWR9IG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIuaWQpfSBjbGFzc05hbWU9e2dldFRhYkNsYXNzTmFtZSh0YWIuaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFiLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9uYXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBDT05URU5JRE8gREUgTEFTIFBFU1RBw5FBUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdkZXRhaWxzJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbURldGFpbENvbXBvbmVudCA/IGN1c3RvbURldGFpbENvbXBvbmVudCA6IDxHZW5lcmljRGV0YWlsUGFnZSBjb25maWc9e2NvbmZpZ30gaXRlbT17aXRlbX0gaGlkZUhlYWRlcj17dHJ1ZX0gLz5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgey8qIOKchSBMw5NHSUNBIERFIFJFTkRFUklaQURPIENPTkRJQ0lPTkFMIEFDVFVBTElaQURBICovfVxuICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdtb3ZlbWVudHMnICYmIGVudGl0eVR5cGUgPT09ICdjbGllbnQnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPEFjY291bnRNb3ZlbWVudHNUYWJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkPXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ9J2N1c3RvbWVyLWFjY291bnRzJyAvLyBFbmRwb2ludCBlc3BlY8OtZmljbyBkZSBDbGllbnRlXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnbW92ZW1lbnRzJyAmJiBlbnRpdHlUeXBlID09PSAncHJvdmlkZXInICYmIChcbiAgICAgICAgICAgICAgICAgICAgPFZlbmRvck1vdmVtZW50c1RhYlxuICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5SWQ9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbmRwb2ludD0ndmVuZG9yLWFjY291bnRzJyAvLyBFbmRwb2ludCBkZSBQcm92ZWVkb3JcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdtb3ZlbWVudHMnICYmIGVudGl0eVR5cGUgPT09ICdwcm9kdWN0JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxQcm9kdWN0TW92ZW1lbnRzVGFiXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRpdHlJZD17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZHBvaW50PSdzdG9jay1tb3ZlbWVudHMnIC8vIEVuZHBvaW50IGRlIFByb2R1Y3RvXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnc2FsZXNfaGlzdG9yeScgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8UHJvZHVjdEhpc3RvcnlDbGllbnRUYWJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkPXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ9J2xhdGVzdC1wcm9kdWN0cycgLy8gRW5kcG9pbnQgZGUgUHJvZHVjdG9cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9FbnRpdHlEZXRhaWxQYWdlTGF5b3V0LnRzeCJ9