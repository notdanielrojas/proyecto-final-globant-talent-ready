import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { notasCreditoCompraModuleConfig } from "/src/features/notas_credito_compra/notas_credito_compra.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) return 0;
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const NotasCreditoCompraDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: note, loading, error } = useCrudItem(notasCreditoCompraModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const calculatedTotals = useMemo(() => {
    if (!note) return { subtotal: 0, totalTaxes: 0 };
    const items = note.items || [];
    let subtotal = 0;
    for (const item of items) {
      subtotal += Number(item.quantity) * Number(item.unit_price);
    }
    let totalTaxes = 0;
    if (note.has_item_level_taxes) {
      totalTaxes = items.reduce((sum, item) => sum + getItemTaxTotal(item), 0);
    } else {
      totalTaxes = (note.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
    }
    return { subtotal, totalTaxes };
  }, [note]);
  const aggregatedTaxes = useMemo(() => {
    if (!note) return [];
    const items = note.items || [];
    if (note.has_item_level_taxes) {
      const map = /* @__PURE__ */ new Map();
      for (const item of items) {
        for (const t of item.taxes || []) {
          const key = t.tax_id;
          if (!map.has(key)) map.set(key, { tax_name: t.tax_name ?? "", rate: t.rate, amount: 0 });
          const row = map.get(key);
          row.amount += Number(t.amount);
        }
      }
      return Array.from(map.values());
    }
    return (note.taxes || []).map((t) => ({ tax_name: t.tax_name, rate: t.rate, amount: Number(t.amount) }));
  }, [note]);
  const handlePrint = async () => {
    if (!note) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/purchase-credit-notes/${note.id}/pdf`);
    } catch (err) {
      if (!session.window.closed) session.window.close();
      console.error(err);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
    lineNumber: 98,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la nota de crédito: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
    lineNumber: 99,
    columnNumber: 21
  }, this);
  if (!note) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el documento." }, void 0, false, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
    lineNumber: 100,
    columnNumber: 21
  }, this);
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  const statusStr = String(note.status || "").toUpperCase();
  const statusText = statusStr === "DRAFT" ? "Borrador" : statusStr === "ISSUED" ? "Emitida" : statusStr === "VOID" ? "Anulada" : note.status || "Desconocido";
  const statusClass = statusStr === "DRAFT" ? "bg-yellow-100 text-yellow-800" : statusStr === "ISSUED" ? "bg-green-100 text-green-800" : statusStr === "VOID" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(notasCreditoCompraModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 113,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 112,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "NC Compra: ",
            note.series ? `${note.series}-` : "",
            note.voucher_number
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 116,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${statusClass}`, children: statusText }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 117,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 115,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 111,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handlePrint,
          disabled: isPrinting,
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
          children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 127,
            columnNumber: 39
          }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 127,
            columnNumber: 88
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 121,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 120,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
      lineNumber: 110,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Proveedor" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 134,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: /* @__PURE__ */ jsxDEV(Link, { to: `/proveedores/${note.vendor_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: note.vendor_name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 136,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 135,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 133,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Ref. Compra" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 142,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.purchase_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/compras/${note.purchase_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: note.purchase?.internal_voucher || `ID: ${note.purchase_id}` }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 145,
          columnNumber: 13
        }, this) : "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 143,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 141,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Serie" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 154,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.series || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 155,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 153,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 158,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatValue(note.issue_date, "date") }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 159,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 157,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 162,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.currency?.name ?? note.currency?.currency_name ?? "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 163,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 161,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de Cambio" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 166,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: Number(note.exchange_rate || 1).toFixed(2) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 167,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 165,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
      lineNumber: 132,
      columnNumber: 13
    }, this),
    note.items && note.items.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Ítems de la Nota de Crédito" }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 173,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 178,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 179,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 180,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 181,
            columnNumber: 37
          }, this),
          note.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 182,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 183,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 177,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 176,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: note.items.map((item, index) => {
          const lineSubtotal = Number(item.quantity) * Number(item.unit_price);
          const itemTax = note.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSubtotal + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: item.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${item.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 196,
                columnNumber: 57
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 197,
                columnNumber: 57
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 195,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 201,
                columnNumber: 57
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 202,
                columnNumber: 57
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 200,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 193,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 206,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 207,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 208,
              columnNumber: 45
            }, this),
            note.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(itemTax, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 209,
              columnNumber: 75
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 210,
              columnNumber: 45
            }, this)
          ] }, item.id ?? index, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 192,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 186,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 175,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 174,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
      lineNumber: 172,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Impuestos aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 222,
          columnNumber: 21
        }, this),
        aggregatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 228,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 229,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 230,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 227,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 226,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: aggregatedTaxes.map(
            (tax, idx) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 236,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: tax.rate }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 237,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
                lineNumber: 238,
                columnNumber: 45
              }, this)
            ] }, idx, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 235,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 233,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 225,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 224,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-gray-500", children: "No hay impuestos aplicados en esta nota." }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 245,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 221,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 rounded-lg space-y-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 250,
              columnNumber: 76
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 250,
              columnNumber: 126
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 250,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Impuestos:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 251,
              columnNumber: 76
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 251,
              columnNumber: 127
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 251,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 252,
              columnNumber: 95
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-lg font-bold text-indigo-600`, children: formatValue(note.total_amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
              lineNumber: 252,
              columnNumber: 169
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 252,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 249,
          columnNumber: 21
        }, this),
        note.rejection_reason && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 p-3 rounded border border-red-200 text-sm text-red-800", children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Motivo Rechazo:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 256,
            columnNumber: 29
          }, this),
          " ",
          note.rejection_reason
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 255,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 260,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900 whitespace-pre-wrap", children: note.notes || "-" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
            lineNumber: 261,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
          lineNumber: 259,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
        lineNumber: 248,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
      lineNumber: 220,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx",
    lineNumber: 109,
    columnNumber: 5
  }, this);
};
_s(NotasCreditoCompraDetailPage, "69cmju0yomXyJadVjPaMAOahG2Q=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = NotasCreditoCompraDetailPage;
var _c;
$RefreshReg$(_c, "NotasCreditoCompraDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEV3QixTQXNHNEIsVUF0RzVCOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlFeEIsU0FBU0EsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNDQUE0RjtBQUNyRyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYUMsZUFBZTtBQUNyQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBQ2xELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBaUM7QUFDdEQsTUFBSSxDQUFDQSxLQUFLQyxTQUFTRCxLQUFLQyxNQUFNQyxXQUFXLEVBQUcsUUFBTztBQUNuRCxTQUFPRixLQUFLQyxNQUFNRSxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU1FLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQ3RFO0FBRU8sYUFBTUMsK0JBQStCQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUMsUUFBTSxFQUFFQyxHQUFHLElBQUkzQixVQUEwQjtBQUN6QyxRQUFNNEIsV0FBVzNCLFlBQVk7QUFDN0IsUUFBTSxFQUFFZ0IsTUFBTVksTUFBTUMsU0FBU0MsTUFBTSxJQUFJMUIsWUFBZ0NDLGdDQUFnQ3FCLEVBQUU7QUFDekcsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUk3QixTQUFTLEtBQUs7QUFFbEQsUUFBTThCLG1CQUFtQi9CLFFBQVEsTUFBTTtBQUNuQyxRQUFJLENBQUMwQixLQUFNLFFBQU8sRUFBRU0sVUFBVSxHQUFHQyxZQUFZLEVBQUU7QUFDL0MsVUFBTUMsUUFBUVIsS0FBS1EsU0FBUztBQUM1QixRQUFJRixXQUFXO0FBQ2YsZUFBV2xCLFFBQVFvQixPQUFPO0FBQ3RCRixrQkFBWVosT0FBT04sS0FBS3FCLFFBQVEsSUFBSWYsT0FBT04sS0FBS3NCLFVBQVU7QUFBQSxJQUM5RDtBQUNBLFFBQUlILGFBQWE7QUFDakIsUUFBSVAsS0FBS1csc0JBQXNCO0FBQzNCSixtQkFBYUMsTUFBTWpCLE9BQU8sQ0FBQ0MsS0FBS0osU0FBU0ksTUFBTUwsZ0JBQWdCQyxJQUFJLEdBQUcsQ0FBQztBQUFBLElBQzNFLE9BQU87QUFDSG1CLG9CQUFjUCxLQUFLWCxTQUFTLElBQUlFLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFBQSxJQUNwRjtBQUNBLFdBQU8sRUFBRVcsVUFBVUMsV0FBVztBQUFBLEVBQ2xDLEdBQUcsQ0FBQ1AsSUFBSSxDQUFDO0FBRVQsUUFBTVksa0JBQWtCdEMsUUFBUSxNQUFNO0FBQ2xDLFFBQUksQ0FBQzBCLEtBQU0sUUFBTztBQUNsQixVQUFNUSxRQUFRUixLQUFLUSxTQUFTO0FBQzVCLFFBQUlSLEtBQUtXLHNCQUFzQjtBQUMzQixZQUFNRSxNQUFNLG9CQUFJQyxJQUFnRTtBQUNoRixpQkFBVzFCLFFBQVFvQixPQUFPO0FBQ3RCLG1CQUFXTyxLQUFLM0IsS0FBS0MsU0FBUyxJQUFJO0FBQzlCLGdCQUFNMkIsTUFBTUQsRUFBRUU7QUFDZCxjQUFJLENBQUNKLElBQUlLLElBQUlGLEdBQUcsRUFBR0gsS0FBSU0sSUFBSUgsS0FBSyxFQUFFSSxVQUFVTCxFQUFFSyxZQUFZLElBQUlDLE1BQU1OLEVBQUVNLE1BQU0xQixRQUFRLEVBQUUsQ0FBQztBQUN2RixnQkFBTTJCLE1BQU1ULElBQUlVLElBQUlQLEdBQUc7QUFDdkJNLGNBQUkzQixVQUFVRCxPQUFPcUIsRUFBRXBCLE1BQU07QUFBQSxRQUNqQztBQUFBLE1BQ0o7QUFDQSxhQUFPNkIsTUFBTUMsS0FBS1osSUFBSWEsT0FBTyxDQUFDO0FBQUEsSUFDbEM7QUFDQSxZQUFRMUIsS0FBS1gsU0FBUyxJQUFJd0IsSUFBSSxDQUFBRSxPQUFNLEVBQUVLLFVBQVVMLEVBQUVLLFVBQVVDLE1BQU1OLEVBQUVNLE1BQU0xQixRQUFRRCxPQUFPcUIsRUFBRXBCLE1BQU0sRUFBRSxFQUFFO0FBQUEsRUFDekcsR0FBRyxDQUFDSyxJQUFJLENBQUM7QUFFVCxRQUFNMkIsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQzNCLEtBQU07QUFFWCxVQUFNNEIsVUFBVTdDLGdCQUFnQjtBQUNoQyxRQUFJLENBQUM2QyxTQUFTO0FBQ1YzQyxZQUFNaUIsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFFLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNBLFlBQU1wQixpQkFBaUI0QyxTQUFTLDBCQUEwQjVCLEtBQUtGLEVBQUUsTUFBTTtBQUFBLElBQzNFLFNBQVMrQixLQUFLO0FBQ1YsVUFBSSxDQUFDRCxRQUFRRSxPQUFPQyxPQUFRSCxTQUFRRSxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFRL0IsTUFBTTJCLEdBQUc7QUFDakI1QyxZQUFNaUIsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dFLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFFQSxNQUFJSCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLElBQXFDQTtBQUFBQSxPQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1GO0FBQ3JHLE1BQUksQ0FBQ0YsS0FBTSxRQUFPLHVCQUFDLFNBQUksV0FBVSw2QkFBNEIsNENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUU7QUFFekYsUUFBTWtDLGtCQUFrQjtBQUN4QixRQUFNQyxrQkFBa0I7QUFDeEIsUUFBTUMsWUFBWUMsT0FBT3JDLEtBQUtzQyxVQUFVLEVBQUUsRUFBRUMsWUFBWTtBQUN4RCxRQUFNQyxhQUFhSixjQUFjLFVBQVUsYUFBYUEsY0FBYyxXQUFXLFlBQVlBLGNBQWMsU0FBUyxZQUFZcEMsS0FBS3NDLFVBQVU7QUFDL0ksUUFBTUcsY0FBY0wsY0FBYyxVQUFVLGtDQUFrQ0EsY0FBYyxXQUFXLGdDQUFnQ0EsY0FBYyxTQUFTLDRCQUE0QjtBQUUxTCxTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwrQkFDWDtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNckMsU0FBU2Isa0JBQWtCVCwrQkFBK0JpRSxTQUFTLENBQUMsR0FBRyxXQUFVLG9EQUNwRyxpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsaURBQWdEO0FBQUE7QUFBQSxZQUFZMUMsS0FBSzJDLFNBQVMsR0FBRzNDLEtBQUsyQyxNQUFNLE1BQU07QUFBQSxZQUFJM0MsS0FBSzRDO0FBQUFBLGVBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9JO0FBQUEsVUFDcEksdUJBQUMsVUFBSyxXQUFXLHVEQUF1REgsV0FBVyxJQUFLRCx3QkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTYjtBQUFBQSxVQUNULFVBQVV4QjtBQUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVUQSx1QkFBYSx1QkFBQyxhQUFVLFdBQVUsMEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDLElBQU0sdUJBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUE7QUFBQSxRQU4vRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLFFBQUcsV0FBVSxrRUFDVjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVytCLGlCQUFpQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQ3pDLHVCQUFDLFFBQUcsV0FBVSxnQ0FDVixpQ0FBQyxRQUFLLElBQUksZ0JBQWdCbEMsS0FBSzZDLFNBQVMsSUFBSSxXQUFVLHlEQUNqRDdDLGVBQUs4QyxlQUFlLFNBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdaLGlCQUFpQiwyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLFFBQzNDLHVCQUFDLFFBQUcsV0FBVSxnQ0FDVGxDLGVBQUsrQyxjQUNGLHVCQUFDLFFBQUssSUFBSSxZQUFZL0MsS0FBSytDLFdBQVcsSUFBSSxXQUFVLHlEQUMvQy9DLGVBQUtnRCxVQUFVQyxvQkFBb0IsT0FBT2pELEtBQUsrQyxXQUFXLE1BRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLE9BTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2IsaUJBQWlCLHFCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ2xDLGVBQUsyQyxVQUFVLE9BQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV1QsaUJBQWlCLDZCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ3BELHNCQUFZa0IsS0FBS2tELFlBQVksTUFBTSxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdoQixpQkFBaUIsc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDbEMsZUFBS21ELFVBQVVDLFFBQVFwRCxLQUFLbUQsVUFBVUUsaUJBQWlCLE9BQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxXQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV25CLGlCQUFpQiw4QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBQzlDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0N4QyxpQkFBT00sS0FBS3NELGlCQUFpQixDQUFDLEVBQUVDLFFBQVEsQ0FBQyxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FGN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLElBRUN2RCxLQUFLUSxTQUFTUixLQUFLUSxNQUFNbEIsU0FBUyxLQUMvQix1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtDQUE4QywyQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLE1BQ3ZGLHVCQUFDLFNBQUksV0FBVSwyRUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNsRlUsS0FBS1csd0JBQXdCLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQseUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDbEgsdUJBQUMsUUFBRyxXQUFVLDJFQUEwRSwyQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQU52RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWlgsZUFBS1EsTUFBTUssSUFBSSxDQUFDekIsTUFBTW9FLFVBQVU7QUFDN0IsZ0JBQU1DLGVBQWUvRCxPQUFPTixLQUFLcUIsUUFBUSxJQUFJZixPQUFPTixLQUFLc0IsVUFBVTtBQUNuRSxnQkFBTWdELFVBQVUxRCxLQUFLVyx1QkFBdUJ4QixnQkFBZ0JDLElBQUksSUFBSTtBQUNwRSxnQkFBTXVFLFlBQVlGLGVBQWVDO0FBQ2pDLGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsa0NBQ1R0RSxlQUFLd0UsYUFDRix1QkFBQyxRQUFLLElBQUksY0FBY3hFLEtBQUt3RSxVQUFVLElBQUksV0FBVSx5REFDakQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQTZCeEUsZUFBS3lFLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGdCQUFFekUsS0FBSzBFO0FBQUFBLGdCQUFhO0FBQUEsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsaUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FDSTtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFBNkIxRSxlQUFLeUUsZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FDOUQsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsZ0JBQUV6RSxLQUFLMEU7QUFBQUEsZ0JBQWE7QUFBQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENwRSxpQkFBT04sS0FBS3FCLFFBQVEsRUFBRThDLFFBQVEsQ0FBQyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzdGLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEN6RSxzQkFBWU0sS0FBS3NCLFlBQVksVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEM1QixzQkFBWTJFLGNBQWMsVUFBVSxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2pHekQsS0FBS1csd0JBQXdCLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEM3QixzQkFBWTRFLFNBQVMsVUFBVSxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzNILHVCQUFDLFFBQUcsV0FBVSx1RUFBdUU1RSxzQkFBWTZFLFdBQVcsVUFBVSxLQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3SDtBQUFBLGVBbEJuSHZFLEtBQUtVLE1BQU0wRCxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFFBRVIsQ0FBQyxLQTNCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsV0F2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQSxLQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUEsU0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBLElBR0osdUJBQUMsU0FBSSxXQUFVLHVEQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyxtQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3BFNUMsZ0JBQWdCdEIsU0FBUyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsWUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pzQiwwQkFBZ0JDO0FBQUFBLFlBQUksQ0FBQ3BCLEtBQUtzRSxRQUN2Qix1QkFBQyxRQUNHO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhDQUE4Q3RFLGNBQUkyQixZQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEMzQixjQUFJNEIsUUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRSx1QkFBQyxRQUFHLFdBQVUsOENBQThDdkMsc0JBQVlXLElBQUlFLFFBQVEsVUFBVSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRztBQUFBLGlCQUgzRm9FLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFVBQ0gsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBLElBRUEsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix3REFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFdBeEIxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUEsbUNBQUMsVUFBSyxXQUFXN0IsaUJBQWlCLHlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXQyxpQkFBa0JyRCxzQkFBWXVCLGlCQUFpQkMsVUFBVSxVQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsZUFBM0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa007QUFBQSxVQUNsTSx1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUEsbUNBQUMsVUFBSyxXQUFXNEIsaUJBQWlCLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLGNBQUdyRCxZQUFZdUIsaUJBQWlCRSxZQUFZLFVBQVU7QUFBQSxpQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxlQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1TTtBQUFBLFVBQ3ZNLHVCQUFDLFNBQUksV0FBVSx3REFBdUQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsR0FBRzJCLGVBQWUsMEJBQTBCLHNCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGVBQWUsc0NBQXVDckQsc0JBQVlrQixLQUFLZ0UsY0FBYyxVQUFVLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFIO0FBQUEsZUFBclE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNFE7QUFBQSxhQUhoUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNDaEUsS0FBS2lFLG9CQUNGLHVCQUFDLFNBQUksV0FBVSxvRUFDWDtBQUFBLGlDQUFDLFlBQU8sK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFTO0FBQUEsVUFBRWpFLEtBQUtpRTtBQUFBQSxhQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVKLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVcvQixpQkFBaUIscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFDckMsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRGxDLGVBQUtrRSxTQUFTLE9BQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsYUFGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNENBO0FBQUEsT0EzSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRKQTtBQUVSO0FBQUVyRSxHQXRPV0QsOEJBQTRCO0FBQUEsVUFDdEJ6QixXQUNFQyxhQUNzQkksV0FBVztBQUFBO0FBQUEyRixLQUh6Q3ZFO0FBQTRCLElBQUF1RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlQ3J1ZEl0ZW0iLCJub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QcmludCIsIkZhU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiYmVnaW5QZGZQcmV2aWV3IiwiZmluaXNoUGRmUHJldmlldyIsInRvYXN0IiwiZ2V0TGlzdFJldHVyblBhdGgiLCJnZXRJdGVtVGF4VG90YWwiLCJpdGVtIiwidGF4ZXMiLCJsZW5ndGgiLCJyZWR1Y2UiLCJzdW0iLCJ0YXgiLCJOdW1iZXIiLCJhbW91bnQiLCJOb3Rhc0NyZWRpdG9Db21wcmFEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwibm90ZSIsImxvYWRpbmciLCJlcnJvciIsImlzUHJpbnRpbmciLCJzZXRJc1ByaW50aW5nIiwiY2FsY3VsYXRlZFRvdGFscyIsInN1YnRvdGFsIiwidG90YWxUYXhlcyIsIml0ZW1zIiwicXVhbnRpdHkiLCJ1bml0X3ByaWNlIiwiaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMiLCJhZ2dyZWdhdGVkVGF4ZXMiLCJtYXAiLCJNYXAiLCJ0Iiwia2V5IiwidGF4X2lkIiwiaGFzIiwic2V0IiwidGF4X25hbWUiLCJyYXRlIiwicm93IiwiZ2V0IiwiQXJyYXkiLCJmcm9tIiwidmFsdWVzIiwiaGFuZGxlUHJpbnQiLCJzZXNzaW9uIiwiZXJyIiwid2luZG93IiwiY2xvc2VkIiwiY2xvc2UiLCJjb25zb2xlIiwidG90YWxMYWJlbFN0eWxlIiwidG90YWxWYWx1ZVN0eWxlIiwic3RhdHVzU3RyIiwiU3RyaW5nIiwic3RhdHVzIiwidG9VcHBlckNhc2UiLCJzdGF0dXNUZXh0Iiwic3RhdHVzQ2xhc3MiLCJiYXNlUm91dGUiLCJzZXJpZXMiLCJ2b3VjaGVyX251bWJlciIsInZlbmRvcl9pZCIsInZlbmRvcl9uYW1lIiwicHVyY2hhc2VfaWQiLCJwdXJjaGFzZSIsImludGVybmFsX3ZvdWNoZXIiLCJpc3N1ZV9kYXRlIiwiY3VycmVuY3kiLCJuYW1lIiwiY3VycmVuY3lfbmFtZSIsImV4Y2hhbmdlX3JhdGUiLCJ0b0ZpeGVkIiwiaW5kZXgiLCJsaW5lU3VidG90YWwiLCJpdGVtVGF4IiwibGluZVRvdGFsIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3RfY29kZSIsImlkeCIsInRvdGFsX2Ftb3VudCIsInJlamVjdGlvbl9yZWFzb24iLCJub3RlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzQ3JlZGl0b0NvbXByYURldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWcsIHR5cGUgUHVyY2hhc2VDcmVkaXROb3RlLCB0eXBlIFB1cmNoYXNlQ3JlZGl0Tm90ZUl0ZW0gfSBmcm9tICcuLi9ub3Rhc19jcmVkaXRvX2NvbXByYS5jb25maWcnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IElvQXJyb3dCYWNrLCBJb1ByaW50IH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IEZhU3Bpbm5lciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBiZWdpblBkZlByZXZpZXcsIGZpbmlzaFBkZlByZXZpZXcgfSBmcm9tICcuLi8uLi8uLi91dGlscy9ibG9iSGVscGVyJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmNvbnN0IGdldEl0ZW1UYXhUb3RhbCA9IChpdGVtOiBQdXJjaGFzZUNyZWRpdE5vdGVJdGVtKSA9PiB7XG4gICAgaWYgKCFpdGVtLnRheGVzIHx8IGl0ZW0udGF4ZXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgICByZXR1cm4gaXRlbS50YXhlcy5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xufTtcblxuZXhwb3J0IGNvbnN0IE5vdGFzQ3JlZGl0b0NvbXByYURldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IG5vdGUsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxQdXJjaGFzZUNyZWRpdE5vdGU+KG5vdGFzQ3JlZGl0b0NvbXByYU1vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IFtpc1ByaW50aW5nLCBzZXRJc1ByaW50aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFub3RlKSByZXR1cm4geyBzdWJ0b3RhbDogMCwgdG90YWxUYXhlczogMCB9O1xuICAgICAgICBjb25zdCBpdGVtcyA9IG5vdGUuaXRlbXMgfHwgW107XG4gICAgICAgIGxldCBzdWJ0b3RhbCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICAgICAgc3VidG90YWwgKz0gTnVtYmVyKGl0ZW0ucXVhbnRpdHkpICogTnVtYmVyKGl0ZW0udW5pdF9wcmljZSk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHRvdGFsVGF4ZXMgPSAwO1xuICAgICAgICBpZiAobm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgdG90YWxUYXhlcyA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyBnZXRJdGVtVGF4VG90YWwoaXRlbSksIDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdG90YWxUYXhlcyA9IChub3RlLnRheGVzIHx8IFtdKS5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbFRheGVzIH07XG4gICAgfSwgW25vdGVdKTtcblxuICAgIGNvbnN0IGFnZ3JlZ2F0ZWRUYXhlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIW5vdGUpIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBub3RlLml0ZW1zIHx8IFtdO1xuICAgICAgICBpZiAobm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIHsgdGF4X25hbWU6IHN0cmluZzsgcmF0ZTogbnVtYmVyOyBhbW91bnQ6IG51bWJlciB9PigpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB0IG9mIGl0ZW0udGF4ZXMgfHwgW10pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5ID0gdC50YXhfaWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghbWFwLmhhcyhrZXkpKSBtYXAuc2V0KGtleSwgeyB0YXhfbmFtZTogdC50YXhfbmFtZSA/PyAnJywgcmF0ZTogdC5yYXRlLCBhbW91bnQ6IDAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJvdyA9IG1hcC5nZXQoa2V5KSE7XG4gICAgICAgICAgICAgICAgICAgIHJvdy5hbW91bnQgKz0gTnVtYmVyKHQuYW1vdW50KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShtYXAudmFsdWVzKCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAobm90ZS50YXhlcyB8fCBbXSkubWFwKHQgPT4gKHsgdGF4X25hbWU6IHQudGF4X25hbWUsIHJhdGU6IHQucmF0ZSwgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpIH0pKTtcbiAgICB9LCBbbm90ZV0pO1xuXG4gICAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghbm90ZSkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBQREYuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc1ByaW50aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZmluaXNoUGRmUHJldmlldyhzZXNzaW9uLCBgL3B1cmNoYXNlLWNyZWRpdC1ub3Rlcy8ke25vdGUuaWR9L3BkZmApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCBjb21wcm9iYW50ZSBQREYuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1ByaW50aW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBsYSBub3RhIGRlIGNyw6lkaXRvOiB7ZXJyb3IgYXMgc3RyaW5nfTwvZGl2PjtcbiAgICBpZiAoIW5vdGUpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5ObyBzZSBlbmNvbnRyw7MgZWwgZG9jdW1lbnRvLjwvZGl2PjtcblxuICAgIGNvbnN0IHRvdGFsTGFiZWxTdHlsZSA9IFwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0ZXh0LXJpZ2h0XCI7XG4gICAgY29uc3Qgc3RhdHVzU3RyID0gU3RyaW5nKG5vdGUuc3RhdHVzIHx8ICcnKS50b1VwcGVyQ2FzZSgpO1xuICAgIGNvbnN0IHN0YXR1c1RleHQgPSBzdGF0dXNTdHIgPT09ICdEUkFGVCcgPyAnQm9ycmFkb3InIDogc3RhdHVzU3RyID09PSAnSVNTVUVEJyA/ICdFbWl0aWRhJyA6IHN0YXR1c1N0ciA9PT0gJ1ZPSUQnID8gJ0FudWxhZGEnIDogbm90ZS5zdGF0dXMgfHwgJ0Rlc2Nvbm9jaWRvJztcbiAgICBjb25zdCBzdGF0dXNDbGFzcyA9IHN0YXR1c1N0ciA9PT0gJ0RSQUZUJyA/ICdiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCcgOiBzdGF0dXNTdHIgPT09ICdJU1NVRUQnID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiBzdGF0dXNTdHIgPT09ICdWT0lEJyA/ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCcgOiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgbWItNCBib3JkZXItYiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG5vdGFzQ3JlZGl0b0NvbXByYU1vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtZ3JheS01MDAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9BcnJvd0JhY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPk5DIENvbXByYToge25vdGUuc2VyaWVzID8gYCR7bm90ZS5zZXJpZXN9LWAgOiAnJ317bm90ZS52b3VjaGVyX251bWJlcn08L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbXQtMSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtICR7c3RhdHVzQ2xhc3N9YH0+e3N0YXR1c1RleHR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc206bXQtMCBzbTptbC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNQcmludGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzUHJpbnRpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz4gOiA8SW9QcmludCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC14LTQgZ2FwLXktNiBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlByb3ZlZWRvcjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9wcm92ZWVkb3Jlcy8ke25vdGUudmVuZG9yX2lkfWB9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge25vdGUudmVuZG9yX25hbWUgfHwgJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+UmVmLiBDb21wcmE8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge25vdGUucHVyY2hhc2VfaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2AvY29tcHJhcy8ke25vdGUucHVyY2hhc2VfaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25vdGUucHVyY2hhc2U/LmludGVybmFsX3ZvdWNoZXIgfHwgYElEOiAke25vdGUucHVyY2hhc2VfaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICctJ1xuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TZXJpZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e25vdGUuc2VyaWVzIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIEVtaXNpw7NuPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+TW9uZWRhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57bm90ZS5jdXJyZW5jeT8ubmFtZSA/PyBub3RlLmN1cnJlbmN5Py5jdXJyZW5jeV9uYW1lID8/ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlRpcG8gZGUgQ2FtYmlvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57TnVtYmVyKG5vdGUuZXhjaGFuZ2VfcmF0ZSB8fCAxKS50b0ZpeGVkKDIpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2RsPlxuXG4gICAgICAgICAgICB7bm90ZS5pdGVtcyAmJiBub3RlLml0ZW1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+w410ZW1zIGRlIGxhIE5vdGEgZGUgQ3LDqWRpdG88L2gzPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPlByb2R1Y3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q2FudC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlLmhhc19pdGVtX2xldmVsX3RheGVzICYmIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+SW1wdWVzdG9zPC90aD59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnByLTZcIj5Ub3RhbCBMw61uZWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5pdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsaW5lU3VidG90YWwgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXggPSBub3RlLmhhc19pdGVtX2xldmVsX3RheGVzID8gZ2V0SXRlbVRheFRvdGFsKGl0ZW0pIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWQgPz8gaW5kZXh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9kdWN0X2lkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2FydGljdWxvcy8ke2l0ZW0ucHJvZHVjdF9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPih7aXRlbS5wcm9kdWN0X2NvZGV9KTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e2l0ZW0ucHJvZHVjdF9uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57TnVtYmVyKGl0ZW0ucXVhbnRpdHkpLnRvRml4ZWQoMil9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShpdGVtLnVuaXRfcHJpY2UsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUobGluZVN1YnRvdGFsLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGl0ZW1UYXgsICdjdXJyZW5jeScpfTwvdGQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC0zIHByLTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgc206cHItNlwiPntmb3JtYXRWYWx1ZShsaW5lVG90YWwsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIHAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIGFwbGljYWRvczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5JbXB1ZXN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5UYXNhICglKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdncmVnYXRlZFRheGVzLm1hcCgodGF4LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpZHh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+e3RheC50YXhfbmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e3RheC5yYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgaW1wdWVzdG9zIGFwbGljYWRvcyBlbiBlc3RhIG5vdGEuPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+U3VidG90YWw6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy5zdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+SW1wdWVzdG9zOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj48c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsTGFiZWxTdHlsZX0gdGV4dC1sZyBmb250LXNlbWlib2xkYH0+VG90YWw6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlfSB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDBgfT57Zm9ybWF0VmFsdWUobm90ZS50b3RhbF9hbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtub3RlLnJlamVjdGlvbl9yZWFzb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAgcC0zIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHRleHQtc20gdGV4dC1yZWQtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Nb3Rpdm8gUmVjaGF6bzo8L3N0cm9uZz4ge25vdGUucmVqZWN0aW9uX3JlYXNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Ob3RhczwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+e25vdGUubm90ZXMgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9ub3Rhc19jcmVkaXRvX2NvbXByYS9wYWdlcy9Ob3Rhc0NyZWRpdG9Db21wcmFEZXRhaWxQYWdlLnRzeCJ9