import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/reportes/pages/ReportesListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/reportes/pages/ReportesListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { reportesModuleConfig } from "/src/features/reportes/reportes.config.tsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
export const ReportesListPage = () => {
  _s();
  const navigate = useNavigate();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(reportesModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/reportes/pages/ReportesListPage.tsx",
    lineNumber: 33,
    columnNumber: 21
  }, this);
  const handleRunReport = (item) => {
    navigate(`${reportesModuleConfig.baseRoute}/${item.code}`);
  };
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: reportesModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      onRowClick: handleRunReport
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/reportes/pages/ReportesListPage.tsx",
      lineNumber: 42,
      columnNumber: 5
    },
    this
  );
};
_s(ReportesListPage, "nvCgeVx3CHZgzRiYFzHy4h4uya8=", false, function() {
  return [useNavigate, useCrud];
});
_c = ReportesListPage;
var _c;
$RefreshReg$(_c, "ReportesListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/reportes/pages/ReportesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/reportes/pages/ReportesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYXNCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWJ0QixTQUFTQSx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyw0QkFBbUQ7QUFDNUQsU0FBU0MsbUJBQW1CO0FBRXJCLGFBQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU1DLFdBQVdILFlBQVk7QUFFN0IsUUFBTTtBQUFBLElBQ0ZJO0FBQUFBLElBQVVDO0FBQUFBLElBQVNDO0FBQUFBLElBQWFDO0FBQUFBLElBQU9DO0FBQUFBLElBQVlDO0FBQUFBLElBQVlDO0FBQUFBLElBQy9EQztBQUFBQSxJQUFlQztBQUFBQSxJQUFrQkM7QUFBQUEsSUFBZ0JDO0FBQUFBLElBQWNDO0FBQUFBLEVBQ25FLElBQUlqQixRQUEwQkMsb0JBQW9CO0FBRWxELE1BQUlRLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUd2RCxRQUFNUyxrQkFBa0JBLENBQUNDLFNBQTJCO0FBRWhEZCxhQUFTLEdBQUdKLHFCQUFxQm1CLFNBQVMsSUFBSUQsS0FBS0UsSUFBSSxFQUFFO0FBQUEsRUFDN0Q7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRcEI7QUFBQUEsTUFDUixvQkFBb0JLO0FBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBVUk7QUFBQUEsTUFDVixRQUFRQztBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0EsY0FBY0c7QUFBQUEsTUFDZCxZQUFZQztBQUFBQSxNQUNaLFVBQVVDO0FBQUFBLE1BQ1YsWUFBWUMsYUFBYUssUUFBUTtBQUFBLE1BQ2pDLFlBQVlKO0FBQUFBO0FBQUFBLElBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWFnQztBQUl4QztBQUFFZCxHQWxDV0Qsa0JBQWdCO0FBQUEsVUFDUkQsYUFLYkYsT0FBTztBQUFBO0FBQUF1QixLQU5GcEI7QUFBZ0IsSUFBQW9CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwicmVwb3J0ZXNNb2R1bGVDb25maWciLCJ1c2VOYXZpZ2F0ZSIsIlJlcG9ydGVzTGlzdFBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiaXNBcHBlbmRpbmciLCJlcnJvciIsImRlbGV0ZUl0ZW0iLCJoYW5kbGVTb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVMb2FkTW9yZSIsImhhbmRsZVNlYXJjaCIsInNlYXJjaFBhcmFtcyIsImhhbmRsZVJ1blJlcG9ydCIsIml0ZW0iLCJiYXNlUm91dGUiLCJjb2RlIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlcG9ydGVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyByZXBvcnRlc01vZHVsZUNvbmZpZywgdHlwZSBSZXBvcnREZWZpbml0aW9uIH0gZnJvbSAnLi4vcmVwb3J0ZXMuY29uZmlnJzsgLy8g4pyFIEltcG9ydCBhY3R1YWxpemFkb1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuZXhwb3J0IGNvbnN0IFJlcG9ydGVzTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxSZXBvcnREZWZpbml0aW9uPihyZXBvcnRlc01vZHVsZUNvbmZpZyk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICAvLyBBY2Npw7NuIGN1c3RvbSBwYXJhIGlyIGFsIFwiUnVubmVyXCJcbiAgICBjb25zdCBoYW5kbGVSdW5SZXBvcnQgPSAoaXRlbTogUmVwb3J0RGVmaW5pdGlvbikgPT4ge1xuICAgICAgICAvLyBOYXZlZ2Ftb3MgYSAvcmVwb3J0ZXMvMVxuICAgICAgICBuYXZpZ2F0ZShgJHtyZXBvcnRlc01vZHVsZUNvbmZpZy5iYXNlUm91dGV9LyR7aXRlbS5jb2RlfWApO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPFJlcG9ydERlZmluaXRpb24+XG4gICAgICAgICAgICBjb25maWc9e3JlcG9ydGVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgb25Sb3dDbGljaz17aGFuZGxlUnVuUmVwb3J0fVxuXG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9yZXBvcnRlcy9wYWdlcy9SZXBvcnRlc0xpc3RQYWdlLnRzeCJ9