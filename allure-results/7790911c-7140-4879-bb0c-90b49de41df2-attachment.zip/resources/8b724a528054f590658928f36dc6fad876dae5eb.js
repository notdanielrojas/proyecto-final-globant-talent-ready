import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/AccountMovementsTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/AccountMovementsTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { search } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { FaFilter } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
function createDefaultDateRange() {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
  return { from: oneMonthAgo, to: today };
}
const renderAccountDocumentType = (docType) => {
  let text = "";
  switch (docType) {
    case "SalesInvoice":
      text = "Factura de Venta";
      break;
    case "Collection":
      text = "Cobro";
      break;
    case "CreditNote":
      text = "Nota de Crédito";
      break;
    case "FinancialNote":
    case "FinancialNoteDebit":
    case "FinancialNoteCredit":
      text = "Nota Financiera";
      break;
    default:
      text = docType;
  }
  return text;
};
const renderAccountMovementDocumentLink = (mov) => {
  let path = "#";
  const docId = mov.id;
  const docNumber = mov.document_number || (mov.document_type === "Collection" ? `RC-${docId}` : "Ver Doc.");
  switch (mov.document_type) {
    case "SalesInvoice":
      path = `/facturas-de-venta/${docId}`;
      break;
    case "Collection":
      path = `/cobranzas/${docId}`;
      break;
    case "CreditNote":
      path = `/notas-credito/${docId}`;
      break;
    case "FinancialNote":
    case "FinancialNoteDebit":
    case "FinancialNoteCredit":
      path = `/notas-financieras/${docId}`;
      break;
    default:
      return /* @__PURE__ */ jsxDEV("span", { children: docNumber }, void 0, false, {
        fileName: "/app/src/components/common/AccountMovementsTab.tsx",
        lineNumber: 137,
        columnNumber: 14
      }, this);
  }
  return /* @__PURE__ */ jsxDEV(Link, { to: path, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: docNumber }, void 0, false, {
    fileName: "/app/src/components/common/AccountMovementsTab.tsx",
    lineNumber: 141,
    columnNumber: 5
  }, this);
};
export const AccountMovementsTab = ({ entityId, endpoint, dateInputIdPrefix = "" }) => {
  _s();
  const dateFromId = dateInputIdPrefix ? `${dateInputIdPrefix}-date_from` : "date_from";
  const dateToId = dateInputIdPrefix ? `${dateInputIdPrefix}-date_to` : "date_to";
  const [movements, setMovements] = useState([]);
  const [initialBalance, setInitialBalance] = useState(null);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [draftRange, setDraftRange] = useState(createDefaultDateRange);
  const [appliedRange, setAppliedRange] = useState(createDefaultDateRange);
  const appliedRangeRef = useRef(appliedRange);
  appliedRangeRef.current = appliedRange;
  const fetchMovements = useCallback(async (pageUrl, range) => {
    setLoading(true);
    try {
      let url;
      if (pageUrl) {
        if (pageUrl.startsWith("http")) {
          const urlObj = new URL(pageUrl);
          url = urlObj.pathname.replace(/^\/api\/?/, "") + urlObj.search;
        } else {
          url = pageUrl;
        }
      } else {
        const r = range ?? appliedRangeRef.current;
        const params = new URLSearchParams();
        params.set("start_date", r.from);
        params.set("end_date", r.to);
        params.set("client_id", entityId.toString());
        url = `${endpoint}?${params.toString()}`;
      }
      const response = await search(url);
      setInitialBalance(response.initial_balance);
      setMovements(response.statement.data);
      setPaginationMeta(response.statement);
    } catch (error) {
      toast.error("Error al cargar los movimientos del cliente.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [endpoint, entityId]);
  useEffect(() => {
    const defaults = createDefaultDateRange();
    setDraftRange(defaults);
    setAppliedRange(defaults);
    void fetchMovements(void 0, defaults);
  }, [fetchMovements, entityId]);
  const handlePageChange = (url) => {
    void fetchMovements(url);
  };
  const handleFilterSubmit = (e) => {
    e.preventDefault();
    if (draftRange.from === appliedRange.from && draftRange.to === appliedRange.to) {
      return;
    }
    setAppliedRange(draftRange);
    void fetchMovements(void 0, draftRange);
  };
  const columns = [
    { key: "transaction_date", label: "Fecha" },
    { key: "document_type", label: "Tipo Documento" },
    { key: "document_number", label: "Nº Documento" },
    { key: "debit", label: "Debe" },
    { key: "credit", label: "Haber" },
    { key: "balance", label: "Saldo" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleFilterSubmit, autoComplete: "off", className: "flex items-end gap-4 mb-4 p-4 bg-gray-50 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: dateFromId, className: "block text-sm font-medium text-gray-700", children: "Desde" }, void 0, false, {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 233,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: dateFromId,
            value: draftRange.from,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, from: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/AccountMovementsTab.tsx",
            lineNumber: 234,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/AccountMovementsTab.tsx",
        lineNumber: 232,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: dateToId, className: "block text-sm font-medium text-gray-700", children: "Hasta" }, void 0, false, {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 242,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: dateToId,
            value: draftRange.to,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, to: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/AccountMovementsTab.tsx",
            lineNumber: 243,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/AccountMovementsTab.tsx",
        lineNumber: 241,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(FaFilter, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/components/common/AccountMovementsTab.tsx",
              lineNumber: 254,
              columnNumber: 21
            }, this),
            " Filtrar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 250,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/AccountMovementsTab.tsx",
      lineNumber: 231,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/AccountMovementsTab.tsx",
      lineNumber: 259,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: columns.map(
          (col) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: `py-3.5 px-3 text-left text-sm font-semibold text-gray-900 ${["debit", "credit", "balance"].includes(col.key) ? "text-right" : ""}`, children: col.label }, col.key, false, {
            fileName: "/app/src/components/common/AccountMovementsTab.tsx",
            lineNumber: 267,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 265,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 264,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
          initialBalance !== null && /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-50 font-medium", children: [
            /* @__PURE__ */ jsxDEV("td", { colSpan: columns.length - 1, className: "py-3 pl-4 pr-3 text-sm font-semibold text-gray-900 sm:pl-6", children: [
              "SALDO ANTERIOR (al ",
              formatValue(appliedRange.from, "date"),
              ")"
            ] }, void 0, true, {
              fileName: "/app/src/components/common/AccountMovementsTab.tsx",
              lineNumber: 278,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm text-right font-semibold text-gray-900", children: formatValue(initialBalance, "currency") }, void 0, false, {
              fileName: "/app/src/components/common/AccountMovementsTab.tsx",
              lineNumber: 281,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/AccountMovementsTab.tsx",
            lineNumber: 277,
            columnNumber: 15
          }, this),
          movements.map(
            (mov, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: formatValue(mov.transaction_date, "date") }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 289,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: renderAccountDocumentType(mov.document_type) }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 290,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: renderAccountMovementDocumentLink(mov) }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 293,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.debit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 296,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.credit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 297,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-semibold", children: formatValue(mov.balance, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/AccountMovementsTab.tsx",
                lineNumber: 298,
                columnNumber: 41
              }, this)
            ] }, `${mov.id}-${mov.document_type}-${index}`, true, {
              fileName: "/app/src/components/common/AccountMovementsTab.tsx",
              lineNumber: 288,
              columnNumber: 15
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 273,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/AccountMovementsTab.tsx",
        lineNumber: 263,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/AccountMovementsTab.tsx",
        lineNumber: 262,
        columnNumber: 21
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          meta: paginationMeta,
          onPageChange: handlePageChange
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/AccountMovementsTab.tsx",
          lineNumber: 305,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/AccountMovementsTab.tsx",
      lineNumber: 261,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/AccountMovementsTab.tsx",
    lineNumber: 230,
    columnNumber: 5
  }, this);
};
_s(AccountMovementsTab, "b7nIBhyXAJBwDROKVm2xBfWdRoY=");
_c = AccountMovementsTab;
var _c;
$RefreshReg$(_c, "AccountMovementsTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/AccountMovementsTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/AccountMovementsTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUhtQixTQTRISCxVQTVIRzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwSG5CLFNBQVNBLFVBQVVDLFdBQVdDLGFBQWFDLGNBQWM7QUFDekQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFHdkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBd0R6QixTQUFTQyx5QkFBb0M7QUFDekMsUUFBTUMsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTUMsY0FBYyxJQUFJSCxLQUFLQSxLQUFLSSxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJLEVBQUVILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM5RixTQUFPLEVBQUVHLE1BQU1GLGFBQWFHLElBQUlQLE1BQU07QUFDMUM7QUFFQSxNQUFNUSw0QkFBNEJBLENBQUNDLFlBQW9CO0FBQ25ELE1BQUlDLE9BQU87QUFDWCxVQUFRRCxTQUFPO0FBQUEsSUFDWCxLQUFLO0FBQ0RDLGFBQU87QUFDUDtBQUFBLElBQ0osS0FBSztBQUNEQSxhQUFPO0FBQ1A7QUFBQSxJQUNKLEtBQUs7QUFDREEsYUFBTztBQUNQO0FBQUEsSUFDSixLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0RBLGFBQU87QUFDUDtBQUFBLElBQ0o7QUFDSUEsYUFBT0Q7QUFBQUEsRUFDZjtBQUNBLFNBQU9DO0FBQ1g7QUFHQSxNQUFNQyxvQ0FBb0NBLENBQUNDLFFBQW9DO0FBQzNFLE1BQUlDLE9BQU87QUFDWCxRQUFNQyxRQUFRRixJQUFJRztBQUNsQixRQUFNQyxZQUFZSixJQUFJSyxvQkFBb0JMLElBQUlNLGtCQUFrQixlQUFlLE1BQU1KLEtBQUssS0FBSztBQUUvRixVQUFRRixJQUFJTSxlQUFhO0FBQUEsSUFDckIsS0FBSztBQUNETCxhQUFPLHNCQUFzQkMsS0FBSztBQUNsQztBQUFBLElBQ0osS0FBSztBQUNERCxhQUFPLGNBQWNDLEtBQUs7QUFDMUI7QUFBQSxJQUNKLEtBQUs7QUFDREQsYUFBTyxrQkFBa0JDLEtBQUs7QUFDOUI7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDREQsYUFBTyxzQkFBc0JDLEtBQUs7QUFDbEM7QUFBQSxJQUNKO0FBQ0ksYUFBTyx1QkFBQyxVQUFNRSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsRUFDaEM7QUFFQSxTQUNJLHVCQUFDLFFBQUssSUFBSUgsTUFBTSxXQUFVLHlEQUNyQkcsdUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRVI7QUFHTyxhQUFNRyxzQkFBc0JBLENBQUMsRUFBRUMsVUFBVUMsVUFBVUMsb0JBQW9CLEdBQTZCLE1BQU07QUFBQUMsS0FBQTtBQUM3RyxRQUFNQyxhQUFhRixvQkFBb0IsR0FBR0EsaUJBQWlCLGVBQWU7QUFDMUUsUUFBTUcsV0FBV0gsb0JBQW9CLEdBQUdBLGlCQUFpQixhQUFhO0FBQ3RFLFFBQU0sQ0FBQ0ksV0FBV0MsWUFBWSxJQUFJdkMsU0FBdUMsRUFBRTtBQUMzRSxRQUFNLENBQUN3QyxnQkFBZ0JDLGlCQUFpQixJQUFJekMsU0FBd0IsSUFBSTtBQUN4RSxRQUFNLENBQUMwQyxnQkFBZ0JDLGlCQUFpQixJQUFJM0MsU0FBMEMsSUFBSTtBQUMxRixRQUFNLENBQUM0QyxTQUFTQyxVQUFVLElBQUk3QyxTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDOEMsWUFBWUMsYUFBYSxJQUFJL0MsU0FBb0JXLHNCQUFzQjtBQUM5RSxRQUFNLENBQUNxQyxjQUFjQyxlQUFlLElBQUlqRCxTQUFvQlcsc0JBQXNCO0FBQ2xGLFFBQU11QyxrQkFBa0IvQyxPQUFPNkMsWUFBWTtBQUMzQ0Usa0JBQWdCQyxVQUFVSDtBQUUxQixRQUFNSSxpQkFBaUJsRCxZQUFZLE9BQU9tRCxTQUFrQkMsVUFBc0I7QUFDOUVULGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFFQSxVQUFJVTtBQUVKLFVBQUlGLFNBQVM7QUFHVCxZQUFJQSxRQUFRRyxXQUFXLE1BQU0sR0FBRztBQUM1QixnQkFBTUMsU0FBUyxJQUFJQyxJQUFJTCxPQUFPO0FBQzlCRSxnQkFBTUUsT0FBT0UsU0FBU0MsUUFBUSxhQUFhLEVBQUUsSUFBSUgsT0FBT25EO0FBQUFBLFFBQzVELE9BQU87QUFDSGlELGdCQUFNRjtBQUFBQSxRQUNWO0FBQUEsTUFDSixPQUFPO0FBQ0gsY0FBTVEsSUFBSVAsU0FBU0osZ0JBQWdCQztBQUNuQyxjQUFNVyxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsZUFBT0UsSUFBSSxjQUFjSCxFQUFFM0MsSUFBSTtBQUMvQjRDLGVBQU9FLElBQUksWUFBWUgsRUFBRTFDLEVBQUU7QUFDM0IyQyxlQUFPRSxJQUFJLGFBQWFoQyxTQUFTaUMsU0FBUyxDQUFDO0FBQzNDVixjQUFNLEdBQUd0QixRQUFRLElBQUk2QixPQUFPRyxTQUFTLENBQUM7QUFBQSxNQUMxQztBQUVBLFlBQU1DLFdBQVcsTUFBTTVELE9BQVlpRCxHQUFHO0FBRXRDZCx3QkFBa0J5QixTQUFTQyxlQUFlO0FBQzFDNUIsbUJBQWEyQixTQUFTRSxVQUFVQyxJQUFJO0FBQ3BDMUIsd0JBQWtCdUIsU0FBU0UsU0FBUztBQUFBLElBRXhDLFNBQVNFLE9BQU87QUFDWmpFLFlBQU1pRSxNQUFNLDhDQUE4QztBQUMxREMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCLFVBQUM7QUFDR3pCLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0osR0FBRyxDQUFDWixVQUFVRCxRQUFRLENBQUM7QUFFdkIvQixZQUFVLE1BQU07QUFDWixVQUFNdUUsV0FBVzdELHVCQUF1QjtBQUN4Q29DLGtCQUFjeUIsUUFBUTtBQUN0QnZCLG9CQUFnQnVCLFFBQVE7QUFDeEIsU0FBS3BCLGVBQWVxQixRQUFXRCxRQUFRO0FBQUEsRUFDM0MsR0FBRyxDQUFDcEIsZ0JBQWdCcEIsUUFBUSxDQUFDO0FBRTdCLFFBQU0wQyxtQkFBbUJBLENBQUNuQixRQUFnQjtBQUN0QyxTQUFLSCxlQUFlRyxHQUFHO0FBQUEsRUFDM0I7QUFFQSxRQUFNb0IscUJBQXFCQSxDQUFDQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJL0IsV0FBVzVCLFNBQVM4QixhQUFhOUIsUUFBUTRCLFdBQVczQixPQUFPNkIsYUFBYTdCLElBQUk7QUFDNUU7QUFBQSxJQUNKO0FBQ0E4QixvQkFBZ0JILFVBQVU7QUFDMUIsU0FBS00sZUFBZXFCLFFBQVczQixVQUFVO0FBQUEsRUFDN0M7QUFHQSxRQUFNZ0MsVUFBVTtBQUFBLElBQ1osRUFBRUMsS0FBSyxvQkFBb0JDLE9BQU8sUUFBUTtBQUFBLElBQzFDLEVBQUVELEtBQUssaUJBQWlCQyxPQUFPLGlCQUFpQjtBQUFBLElBQ2hELEVBQUVELEtBQUssbUJBQW1CQyxPQUFPLGVBQWU7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLFNBQVNDLE9BQU8sT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssVUFBVUMsT0FBTyxRQUFRO0FBQUEsSUFDaEMsRUFBRUQsS0FBSyxXQUFXQyxPQUFPLFFBQVE7QUFBQSxFQUFDO0FBR3RDLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSwyQkFBQyxVQUFLLFVBQVVMLG9CQUFvQixjQUFhLE9BQU0sV0FBVSw4REFDN0Q7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxTQUFTdkMsWUFBWSxXQUFVLDJDQUEwQyxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBQ3JGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxJQUFJQTtBQUFBQSxZQUNKLE9BQU9VLFdBQVc1QjtBQUFBQSxZQUNsQixVQUFVLENBQUEwRCxNQUFLN0IsY0FBYyxDQUFBa0MsVUFBUyxFQUFFLEdBQUdBLE1BQU0vRCxNQUFNMEQsRUFBRU0sT0FBT0MsTUFBTSxFQUFFO0FBQUEsWUFDeEUsV0FBVTtBQUFBLFlBQXFGLGNBQWE7QUFBQTtBQUFBLFVBTGhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxSDtBQUFBLFdBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUzlDLFVBQVUsV0FBVSwyQ0FBMEMscUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsSUFBSUE7QUFBQUEsWUFDSixPQUFPUyxXQUFXM0I7QUFBQUEsWUFDbEIsVUFBVSxDQUFBeUQsTUFBSzdCLGNBQWMsQ0FBQWtDLFVBQVMsRUFBRSxHQUFHQSxNQUFNOUQsSUFBSXlELEVBQUVNLE9BQU9DLE1BQU0sRUFBRTtBQUFBLFlBQ3RFLFdBQVU7QUFBQSxZQUFxRixjQUFhO0FBQUE7QUFBQSxVQUxoSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLcUg7QUFBQSxXQVB6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFHO0FBQUE7QUFBQTtBQUFBLFFBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUN2QyxVQUNHLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxJQUVmLG1DQUNJO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0lrQyxrQkFBUU07QUFBQUEsVUFBSSxDQUFBQyxRQUNULHVCQUFDLFFBQWlCLE9BQU0sT0FBTSxXQUFXLDZEQUE2RCxDQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUVDLFNBQVNELElBQUlOLEdBQUcsSUFBSSxlQUFlLEVBQUUsSUFDcktNLGNBQUlMLFNBREFLLElBQUlOLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBQ0gsS0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FHWnZDO0FBQUFBLDZCQUFtQixRQUNoQix1QkFBQyxRQUFHLFdBQVUsMEJBQ1Y7QUFBQSxtQ0FBQyxRQUFHLFNBQVNzQyxRQUFRUyxTQUFTLEdBQUcsV0FBVSw4REFBNEQ7QUFBQTtBQUFBLGNBQy9FaEYsWUFBWXlDLGFBQWE5QixNQUFNLE1BQU07QUFBQSxjQUFFO0FBQUEsaUJBRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw0REFDVFgsc0JBQVlpQyxnQkFBZ0IsVUFBVSxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFHSEYsVUFBVThDO0FBQUFBLFlBQUksQ0FBQzVELEtBQUtnRSxVQUNqQix1QkFBQyxRQUNHO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhDQUE4Q2pGLHNCQUFZaUIsSUFBSWlFLGtCQUFrQixNQUFNLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNHO0FBQUEsY0FDdEcsdUJBQUMsUUFBRyxXQUFVLHFCQUNUckUsb0NBQTBCSSxJQUFJTSxhQUFhLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxxQkFDVFAsNENBQWtDQyxHQUFHLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0NqQixzQkFBWWlCLElBQUlrRSxPQUFPLFVBQVUsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRix1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDbkYsc0JBQVlpQixJQUFJbUUsUUFBUSxVQUFVLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEYsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3BGLHNCQUFZaUIsSUFBSW9FLFNBQVMsVUFBVSxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRztBQUFBLGlCQVY1RixHQUFHcEUsSUFBSUcsRUFBRSxJQUFJSCxJQUFJTSxhQUFhLElBQUkwRCxLQUFLLElBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxVQUNIO0FBQUEsYUEzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFdBdENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q0EsS0F4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQTtBQUFBLE1BQ0M5QyxrQkFDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBTUE7QUFBQUEsVUFDTixjQUFjZ0M7QUFBQUE7QUFBQUEsUUFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1DO0FBQUEsU0E5QzNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREE7QUFBQSxPQWhGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0ZBO0FBRVI7QUFBRXZDLEdBdEtXSixxQkFBbUI7QUFBQThELEtBQW5COUQ7QUFBbUIsSUFBQThEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwidXNlUmVmIiwiTGluayIsInRvYXN0Iiwic2VhcmNoIiwiZm9ybWF0VmFsdWUiLCJMb2FkaW5nU3Bpbm5lciIsIlBhZ2luYXRpb24iLCJGYUZpbHRlciIsImNyZWF0ZURlZmF1bHREYXRlUmFuZ2UiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwib25lTW9udGhBZ28iLCJub3ciLCJmcm9tIiwidG8iLCJyZW5kZXJBY2NvdW50RG9jdW1lbnRUeXBlIiwiZG9jVHlwZSIsInRleHQiLCJyZW5kZXJBY2NvdW50TW92ZW1lbnREb2N1bWVudExpbmsiLCJtb3YiLCJwYXRoIiwiZG9jSWQiLCJpZCIsImRvY051bWJlciIsImRvY3VtZW50X251bWJlciIsImRvY3VtZW50X3R5cGUiLCJBY2NvdW50TW92ZW1lbnRzVGFiIiwiZW50aXR5SWQiLCJlbmRwb2ludCIsImRhdGVJbnB1dElkUHJlZml4IiwiX3MiLCJkYXRlRnJvbUlkIiwiZGF0ZVRvSWQiLCJtb3ZlbWVudHMiLCJzZXRNb3ZlbWVudHMiLCJpbml0aWFsQmFsYW5jZSIsInNldEluaXRpYWxCYWxhbmNlIiwicGFnaW5hdGlvbk1ldGEiLCJzZXRQYWdpbmF0aW9uTWV0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZHJhZnRSYW5nZSIsInNldERyYWZ0UmFuZ2UiLCJhcHBsaWVkUmFuZ2UiLCJzZXRBcHBsaWVkUmFuZ2UiLCJhcHBsaWVkUmFuZ2VSZWYiLCJjdXJyZW50IiwiZmV0Y2hNb3ZlbWVudHMiLCJwYWdlVXJsIiwicmFuZ2UiLCJ1cmwiLCJzdGFydHNXaXRoIiwidXJsT2JqIiwiVVJMIiwicGF0aG5hbWUiLCJyZXBsYWNlIiwiciIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNldCIsInRvU3RyaW5nIiwicmVzcG9uc2UiLCJpbml0aWFsX2JhbGFuY2UiLCJzdGF0ZW1lbnQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZGVmYXVsdHMiLCJ1bmRlZmluZWQiLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlRmlsdGVyU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwiY29sdW1ucyIsImtleSIsImxhYmVsIiwicHJldiIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiY29sIiwiaW5jbHVkZXMiLCJsZW5ndGgiLCJpbmRleCIsInRyYW5zYWN0aW9uX2RhdGUiLCJkZWJpdCIsImNyZWRpdCIsImJhbGFuY2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBY2NvdW50TW92ZW1lbnRzVGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjaywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBzZWFyY2ggfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbi8vIOKchSBDT1JSRUNDScOTTiAxOiBFbGltaW5hbW9zICdQYWdpbmF0aW9uTGlua3MnIGRlIGxhIGltcG9ydGFjacOzblxuaW1wb3J0IHR5cGUgeyBQYWdpbmF0ZWRSZXNwb25zZSB9IGZyb20gJy4uLy4uL2ludGVyZmFjZXMvQXBpJzsgLy8gQXN1bW8gcXVlIHRpZW5lcyBQYWdpbmF0aW9uTGlua3NcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IFBhZ2luYXRpb24gfSBmcm9tICcuL1BhZ2luYXRpb24nO1xuaW1wb3J0IHsgRmFGaWx0ZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5cbi8vIC0tLSBUSVBPUyAoRXNwZWPDrWZpY29zIGRlIENsaWVudGUpIC0tLVxuXG4vLyDinIUgQ09SUkVDQ0nDk04gMTogRGVmaW5pbW9zIGVsIHRpcG8gbG9jYWwgcGFyYSBlbCBsaW5rXG5pbnRlcmZhY2UgUGFnaW5hdGlvbkxpbmsge1xuICAgIHVybDogc3RyaW5nIHwgbnVsbDtcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIGFjdGl2ZTogYm9vbGVhbjtcbn1cblxuLy8gSW50ZXJmYXogcGFyYSBsYSB0cmFuc2FjY2nDs24gZGUgY2xpZW50ZSAocGF5bG9hZC5zdGF0ZW1lbnQuZGF0YSlcbmludGVyZmFjZSBDdXN0b21lckFjY291bnRUcmFuc2FjdGlvbiB7XG4gICAgaWQ6IG51bWJlcjsgLy8gRXN0ZSBlcyBlbCBJRCBkZWwgZG9jdW1lbnRvIChGYWN0dXJhIG8gQ29icmFuemEpXG4gICAgdHJhbnNhY3Rpb25fZGF0ZTogc3RyaW5nO1xuICAgIGRvY3VtZW50X3R5cGU6IHN0cmluZztcbiAgICBkb2N1bWVudF9udW1iZXI6IHN0cmluZyB8IG51bGw7XG4gICAgZGViaXQ6IG51bWJlcjtcbiAgICBjcmVkaXQ6IG51bWJlcjtcbiAgICBiYWxhbmNlOiBudW1iZXI7XG59XG5cbi8vIEludGVyZmF6IHBhcmEgZWwgb2JqZXRvICdzdGF0ZW1lbnQnIChlcyBsYSBwYWdpbmFjacOzbilcbmludGVyZmFjZSBDdXN0b21lckFjY291bnRTdGF0ZW1lbnQge1xuICAgIGN1cnJlbnRfcGFnZTogbnVtYmVyO1xuICAgIGRhdGE6IEN1c3RvbWVyQWNjb3VudFRyYW5zYWN0aW9uW107XG4gICAgZmlyc3RfcGFnZV91cmw6IHN0cmluZztcbiAgICBmcm9tOiBudW1iZXI7XG4gICAgbGFzdF9wYWdlOiBudW1iZXI7XG4gICAgbGFzdF9wYWdlX3VybDogc3RyaW5nO1xuICAgIC8vIOKchSBDT1JSRUNDScOTTiAxOiBVc2Ftb3MgZWwgdGlwbyBsb2NhbCAnUGFnaW5hdGlvbkxpbmsnXG4gICAgbGlua3M6IFBhZ2luYXRpb25MaW5rW107XG4gICAgbmV4dF9wYWdlX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXRoOiBzdHJpbmc7XG4gICAgcGVyX3BhZ2U6IG51bWJlcjtcbiAgICBwcmV2X3BhZ2VfdXJsOiBzdHJpbmcgfCBudWxsO1xuICAgIHRvOiBudW1iZXI7XG4gICAgdG90YWw6IG51bWJlcjtcbn1cblxuLy8gSW50ZXJmYXogcGFyYSBsYSByZXNwdWVzdGEgY29tcGxldGEgZGUgL2N1c3RvbWVyLWFjY291bnRzXG5pbnRlcmZhY2UgQ3VzdG9tZXJBY2NvdW50UmVzcG9uc2Uge1xuICAgIGluaXRpYWxfYmFsYW5jZTogbnVtYmVyO1xuICAgIHN0YXRlbWVudDogQ3VzdG9tZXJBY2NvdW50U3RhdGVtZW50O1xuICAgIGZpbHRlcnM6IGFueTtcbn1cblxuaW50ZXJmYWNlIEFjY291bnRNb3ZlbWVudHNUYWJQcm9wcyB7XG4gICAgZW50aXR5SWQ6IHN0cmluZyB8IG51bWJlcjtcbiAgICBlbmRwb2ludDogc3RyaW5nOyAvLyBFajogJ2N1c3RvbWVyLWFjY291bnRzJ1xuICAgIC8qKiBQcmVmaWpvIHBhcmEgaWRzIGRlIGlucHV0cyBkZSBmZWNoYSAoZXZpdGEgY29saXNpw7NuIGVuIG1vZGFsZXMpLiAqL1xuICAgIGRhdGVJbnB1dElkUHJlZml4Pzogc3RyaW5nO1xufVxuXG50eXBlIERhdGVSYW5nZSA9IHsgZnJvbTogc3RyaW5nOyB0bzogc3RyaW5nIH07XG5cbmZ1bmN0aW9uIGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UoKTogRGF0ZVJhbmdlIHtcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xuICAgIGNvbnN0IG9uZU1vbnRoQWdvID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIDMwICogMjQgKiA2MCAqIDYwICogMTAwMCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xuICAgIHJldHVybiB7IGZyb206IG9uZU1vbnRoQWdvLCB0bzogdG9kYXkgfTtcbn1cblxuY29uc3QgcmVuZGVyQWNjb3VudERvY3VtZW50VHlwZSA9IChkb2NUeXBlOiBzdHJpbmcpID0+IHtcbiAgICBsZXQgdGV4dCA9ICcnO1xuICAgIHN3aXRjaCAoZG9jVHlwZSkge1xuICAgICAgICBjYXNlICdTYWxlc0ludm9pY2UnOlxuICAgICAgICAgICAgdGV4dCA9ICdGYWN0dXJhIGRlIFZlbnRhJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdDb2xsZWN0aW9uJzpcbiAgICAgICAgICAgIHRleHQgPSAnQ29icm8nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ0NyZWRpdE5vdGUnOlxuICAgICAgICAgICAgdGV4dCA9ICdOb3RhIGRlIENyw6lkaXRvJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdGaW5hbmNpYWxOb3RlJzpcbiAgICAgICAgY2FzZSAnRmluYW5jaWFsTm90ZURlYml0JzpcbiAgICAgICAgY2FzZSAnRmluYW5jaWFsTm90ZUNyZWRpdCc6XG4gICAgICAgICAgICB0ZXh0ID0gJ05vdGEgRmluYW5jaWVyYSc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRleHQgPSBkb2NUeXBlO1xuICAgIH1cbiAgICByZXR1cm4gdGV4dDtcbn1cblxuLy8gSGVscGVyIHBhcmEgcmVuZGVyaXphciBlbmxhY2VzIGEgbG9zIGRvY3VtZW50b3MgZGUgQ3RhLiBDdGUuIENsaWVudGVcbmNvbnN0IHJlbmRlckFjY291bnRNb3ZlbWVudERvY3VtZW50TGluayA9IChtb3Y6IEN1c3RvbWVyQWNjb3VudFRyYW5zYWN0aW9uKSA9PiB7XG4gICAgbGV0IHBhdGggPSAnIyc7XG4gICAgY29uc3QgZG9jSWQgPSBtb3YuaWQ7IC8vIEFzdW1pbW9zIHF1ZSAnaWQnIGVzIGVsIGlkIGRlbCBkb2N1bWVudG9cbiAgICBjb25zdCBkb2NOdW1iZXIgPSBtb3YuZG9jdW1lbnRfbnVtYmVyIHx8IChtb3YuZG9jdW1lbnRfdHlwZSA9PT0gJ0NvbGxlY3Rpb24nID8gYFJDLSR7ZG9jSWR9YCA6ICdWZXIgRG9jLicpOyAvLyBGYWxsYmFjayBwYXJhIENvYnJhbnphcyBzaW4gbnJvXG5cbiAgICBzd2l0Y2ggKG1vdi5kb2N1bWVudF90eXBlKSB7XG4gICAgICAgIGNhc2UgJ1NhbGVzSW52b2ljZSc6XG4gICAgICAgICAgICBwYXRoID0gYC9mYWN0dXJhcy1kZS12ZW50YS8ke2RvY0lkfWA7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnQ29sbGVjdGlvbic6XG4gICAgICAgICAgICBwYXRoID0gYC9jb2JyYW56YXMvJHtkb2NJZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ0NyZWRpdE5vdGUnOlxuICAgICAgICAgICAgcGF0aCA9IGAvbm90YXMtY3JlZGl0by8ke2RvY0lkfWA7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnRmluYW5jaWFsTm90ZSc6XG4gICAgICAgIGNhc2UgJ0ZpbmFuY2lhbE5vdGVEZWJpdCc6XG4gICAgICAgIGNhc2UgJ0ZpbmFuY2lhbE5vdGVDcmVkaXQnOlxuICAgICAgICAgICAgcGF0aCA9IGAvbm90YXMtZmluYW5jaWVyYXMvJHtkb2NJZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gPHNwYW4+e2RvY051bWJlcn08L3NwYW4+O1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxMaW5rIHRvPXtwYXRofSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAge2RvY051bWJlcn1cbiAgICAgICAgPC9MaW5rPlxuICAgICk7XG59O1xuXG5cbmV4cG9ydCBjb25zdCBBY2NvdW50TW92ZW1lbnRzVGFiID0gKHsgZW50aXR5SWQsIGVuZHBvaW50LCBkYXRlSW5wdXRJZFByZWZpeCA9ICcnIH06IEFjY291bnRNb3ZlbWVudHNUYWJQcm9wcykgPT4ge1xuICAgIGNvbnN0IGRhdGVGcm9tSWQgPSBkYXRlSW5wdXRJZFByZWZpeCA/IGAke2RhdGVJbnB1dElkUHJlZml4fS1kYXRlX2Zyb21gIDogJ2RhdGVfZnJvbSc7XG4gICAgY29uc3QgZGF0ZVRvSWQgPSBkYXRlSW5wdXRJZFByZWZpeCA/IGAke2RhdGVJbnB1dElkUHJlZml4fS1kYXRlX3RvYCA6ICdkYXRlX3RvJztcbiAgICBjb25zdCBbbW92ZW1lbnRzLCBzZXRNb3ZlbWVudHNdID0gdXNlU3RhdGU8Q3VzdG9tZXJBY2NvdW50VHJhbnNhY3Rpb25bXT4oW10pO1xuICAgIGNvbnN0IFtpbml0aWFsQmFsYW5jZSwgc2V0SW5pdGlhbEJhbGFuY2VdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW3BhZ2luYXRpb25NZXRhLCBzZXRQYWdpbmF0aW9uTWV0YV0gPSB1c2VTdGF0ZTxDdXN0b21lckFjY291bnRTdGF0ZW1lbnQgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBbZHJhZnRSYW5nZSwgc2V0RHJhZnRSYW5nZV0gPSB1c2VTdGF0ZTxEYXRlUmFuZ2U+KGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UpO1xuICAgIGNvbnN0IFthcHBsaWVkUmFuZ2UsIHNldEFwcGxpZWRSYW5nZV0gPSB1c2VTdGF0ZTxEYXRlUmFuZ2U+KGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UpO1xuICAgIGNvbnN0IGFwcGxpZWRSYW5nZVJlZiA9IHVzZVJlZihhcHBsaWVkUmFuZ2UpO1xuICAgIGFwcGxpZWRSYW5nZVJlZi5jdXJyZW50ID0gYXBwbGllZFJhbmdlO1xuXG4gICAgY29uc3QgZmV0Y2hNb3ZlbWVudHMgPSB1c2VDYWxsYmFjayhhc3luYyAocGFnZVVybD86IHN0cmluZywgcmFuZ2U/OiBEYXRlUmFuZ2UpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIC0tLSBMw5NHSUNBIFBBUkEgQ0xJRU5URVMgKENPTiBQQUdJTkFDScOTTikgLS0tXG4gICAgICAgICAgICBsZXQgdXJsOiBzdHJpbmc7XG5cbiAgICAgICAgICAgIGlmIChwYWdlVXJsKSB7XG4gICAgICAgICAgICAgICAgLy8gU2kgdmllbmUgcGFnZVVybCAoZGUgbGEgcGFnaW5hY2nDs24pLCBwdWVkZSBzZXIgdW5hIFVSTCBjb21wbGV0YVxuICAgICAgICAgICAgICAgIC8vIEV4dHJhZW1vcyBzb2xvIGxhIHJ1dGEgcmVsYXRpdmEgKHBhdGhuYW1lICsgc2VhcmNoKVxuICAgICAgICAgICAgICAgIGlmIChwYWdlVXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1cmxPYmogPSBuZXcgVVJMKHBhZ2VVcmwpO1xuICAgICAgICAgICAgICAgICAgICB1cmwgPSB1cmxPYmoucGF0aG5hbWUucmVwbGFjZSgvXlxcL2FwaVxcLz8vLCAnJykgKyB1cmxPYmouc2VhcmNoO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9IHBhZ2VVcmw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCByID0gcmFuZ2UgPz8gYXBwbGllZFJhbmdlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ3N0YXJ0X2RhdGUnLCByLmZyb20pO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ2VuZF9kYXRlJywgci50byk7XG4gICAgICAgICAgICAgICAgcGFyYW1zLnNldCgnY2xpZW50X2lkJywgZW50aXR5SWQudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICAgICAgdXJsID0gYCR7ZW5kcG9pbnR9PyR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8YW55Pih1cmwpIGFzIHVua25vd24gYXMgQ3VzdG9tZXJBY2NvdW50UmVzcG9uc2U7XG5cbiAgICAgICAgICAgIHNldEluaXRpYWxCYWxhbmNlKHJlc3BvbnNlLmluaXRpYWxfYmFsYW5jZSk7XG4gICAgICAgICAgICBzZXRNb3ZlbWVudHMocmVzcG9uc2Uuc3RhdGVtZW50LmRhdGEpO1xuICAgICAgICAgICAgc2V0UGFnaW5hdGlvbk1ldGEocmVzcG9uc2Uuc3RhdGVtZW50KTtcblxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBsb3MgbW92aW1pZW50b3MgZGVsIGNsaWVudGUuJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW2VuZHBvaW50LCBlbnRpdHlJZF0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZGVmYXVsdHMgPSBjcmVhdGVEZWZhdWx0RGF0ZVJhbmdlKCk7XG4gICAgICAgIHNldERyYWZ0UmFuZ2UoZGVmYXVsdHMpO1xuICAgICAgICBzZXRBcHBsaWVkUmFuZ2UoZGVmYXVsdHMpO1xuICAgICAgICB2b2lkIGZldGNoTW92ZW1lbnRzKHVuZGVmaW5lZCwgZGVmYXVsdHMpO1xuICAgIH0sIFtmZXRjaE1vdmVtZW50cywgZW50aXR5SWRdKTtcblxuICAgIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgdm9pZCBmZXRjaE1vdmVtZW50cyh1cmwpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVGaWx0ZXJTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKGRyYWZ0UmFuZ2UuZnJvbSA9PT0gYXBwbGllZFJhbmdlLmZyb20gJiYgZHJhZnRSYW5nZS50byA9PT0gYXBwbGllZFJhbmdlLnRvKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0QXBwbGllZFJhbmdlKGRyYWZ0UmFuZ2UpO1xuICAgICAgICB2b2lkIGZldGNoTW92ZW1lbnRzKHVuZGVmaW5lZCwgZHJhZnRSYW5nZSk7XG4gICAgfTtcblxuICAgIC8vIENvbHVtbmFzIEN0YS4gQ3RlLiBDbGllbnRlXG4gICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgeyBrZXk6ICd0cmFuc2FjdGlvbl9kYXRlJywgbGFiZWw6ICdGZWNoYScgfSxcbiAgICAgICAgeyBrZXk6ICdkb2N1bWVudF90eXBlJywgbGFiZWw6ICdUaXBvIERvY3VtZW50bycgfSxcbiAgICAgICAgeyBrZXk6ICdkb2N1bWVudF9udW1iZXInLCBsYWJlbDogJ07CuiBEb2N1bWVudG8nIH0sXG4gICAgICAgIHsga2V5OiAnZGViaXQnLCBsYWJlbDogJ0RlYmUnIH0sXG4gICAgICAgIHsga2V5OiAnY3JlZGl0JywgbGFiZWw6ICdIYWJlcicgfSxcbiAgICAgICAgeyBrZXk6ICdiYWxhbmNlJywgbGFiZWw6ICdTYWxkbycgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02XCI+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlRmlsdGVyU3VibWl0fSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtNCBtYi00IHAtNCBiZy1ncmF5LTUwIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2RhdGVGcm9tSWR9IGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkRlc2RlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD17ZGF0ZUZyb21JZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdFJhbmdlLmZyb219XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREcmFmdFJhbmdlKHByZXYgPT4gKHsgLi4ucHJldiwgZnJvbTogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2RhdGVUb0lkfSBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5IYXN0YTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2RhdGVUb0lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0UmFuZ2UudG99XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREcmFmdFJhbmdlKHByZXYgPT4gKHsgLi4ucHJldiwgdG86IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGYUZpbHRlciBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTJcIiAvPiBGaWx0cmFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxMb2FkaW5nU3Bpbm5lciAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbHVtbnMubWFwKGNvbCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17Y29sLmtleX0gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9e2BweS0zLjUgcHgtMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgJHtbJ2RlYml0JywgJ2NyZWRpdCcsICdiYWxhbmNlJ10uaW5jbHVkZXMoY29sLmtleSkgPyAndGV4dC1yaWdodCcgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZpbGEgZGUgU2FsZG8gSW5pY2lhbCAoU29sbyBDbGllbnRlcykgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbml0aWFsQmFsYW5jZSAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXtjb2x1bW5zLmxlbmd0aCAtIDF9IGNsYXNzTmFtZT1cInB5LTMgcGwtNCBwci0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU0FMRE8gQU5URVJJT1IgKGFsIHtmb3JtYXRWYWx1ZShhcHBsaWVkUmFuZ2UuZnJvbSwgJ2RhdGUnKX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtc20gdGV4dC1yaWdodCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGluaXRpYWxCYWxhbmNlLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW92ZW1lbnRzLm1hcCgobW92LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17YCR7bW92LmlkfS0ke21vdi5kb2N1bWVudF90eXBlfS0ke2luZGV4fWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNtOnBsLTZcIj57Zm9ybWF0VmFsdWUobW92LnRyYW5zYWN0aW9uX2RhdGUsICdkYXRlJyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckFjY291bnREb2N1bWVudFR5cGUobW92LmRvY3VtZW50X3R5cGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJBY2NvdW50TW92ZW1lbnREb2N1bWVudExpbmsobW92KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+e2Zvcm1hdFZhbHVlKG1vdi5kZWJpdCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZShtb3YuY3JlZGl0LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtc2VtaWJvbGRcIj57Zm9ybWF0VmFsdWUobW92LmJhbGFuY2UsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0aW9uTWV0YSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnaW5hdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGE9e3BhZ2luYXRpb25NZXRhIGFzIFBhZ2luYXRlZFJlc3BvbnNlPGFueT5bJ21ldGEnXX0gLy8gQ2FzdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9BY2NvdW50TW92ZW1lbnRzVGFiLnRzeCJ9