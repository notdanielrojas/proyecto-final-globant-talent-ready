import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/vendedores/pages/VendedoresCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/vendedores/pages/VendedoresCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialValues = {
  code: "",
  name: "",
  abbreviation: "",
  district_id: 0,
  // O 'null' si la API lo prefiere
  is_active: true
};
export const VendedoresCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(vendedoresModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.success(`Vendedor creado con éxito!`);
      navigate(getListReturnPath(vendedoresModuleConfig.baseRoute));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: vendedoresModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/vendedores/pages/VendedoresCreatePage.tsx",
      lineNumber: 49,
      columnNumber: 5
    },
    this
  );
};
_s(VendedoresCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = VendedoresCreatePage;
var _c;
$RefreshReg$(_c, "VendedoresCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/vendedores/pages/VendedoresCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/vendedores/pages/VendedoresCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDhCQUE2QztBQUN0RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsZ0JBQW1DO0FBQUEsRUFDckNDLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsY0FBYztBQUFBLEVBQ2RDLGFBQWE7QUFBQTtBQUFBLEVBQ2JDLFdBQVc7QUFDZjtBQUVPLGFBQU1DLHVCQUF1QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RDLFFBQU1DLFdBQVdkLFlBQVk7QUFDN0IsUUFBTSxFQUFFZSxTQUFTLElBQUlaLFlBQXNCRCxzQkFBc0I7QUFFakUsUUFBTWMsYUFBYSxPQUFPQyxTQUFtQjtBQUN6QyxVQUFNQyxVQUFVLE1BQU1ILFNBQVNFLElBQUk7QUFDbkMsUUFBSUMsU0FBUztBQUNUZCxZQUFNZSxRQUFRLDRCQUE0QjtBQUMxQ0wsZUFBU1Qsa0JBQWtCSCx1QkFBdUJrQixTQUFTLENBQUM7QUFBQSxJQUNoRTtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRbEI7QUFBQUEsTUFDUixhQUFhSTtBQUFBQSxNQUNiLFFBQVFVO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUI7QUFHekI7QUFBRUgsR0FwQldELHNCQUFvQjtBQUFBLFVBQ1paLGFBQ0lHLFdBQVc7QUFBQTtBQUFBa0IsS0FGdkJUO0FBQW9CLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNGb3JtUGFnZSIsInZlbmRlZG9yZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInRvYXN0IiwiZ2V0TGlzdFJldHVyblBhdGgiLCJpbml0aWFsVmFsdWVzIiwiY29kZSIsIm5hbWUiLCJhYmJyZXZpYXRpb24iLCJkaXN0cmljdF9pZCIsImlzX2FjdGl2ZSIsIlZlbmRlZG9yZXNDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJuZXdJdGVtIiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlZlbmRlZG9yZXNDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHZlbmRlZG9yZXNNb2R1bGVDb25maWcsIHR5cGUgVmVuZGVkb3IgfSBmcm9tICcuLi92ZW5kZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbi8vIFZhbG9yZXMgaW5pY2lhbGVzIHBhcmEgdW4gdmVuZGVkb3IgbnVldm9cbmNvbnN0IGluaXRpYWxWYWx1ZXM6IFBhcnRpYWw8VmVuZGVkb3I+ID0ge1xuICAgIGNvZGU6ICcnLFxuICAgIG5hbWU6ICcnLFxuICAgIGFiYnJldmlhdGlvbjogJycsXG4gICAgZGlzdHJpY3RfaWQ6IDAsIC8vIE8gJ251bGwnIHNpIGxhIEFQSSBsbyBwcmVmaWVyZVxuICAgIGlzX2FjdGl2ZTogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBWZW5kZWRvcmVzQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08VmVuZGVkb3I+KHZlbmRlZG9yZXNNb2R1bGVDb25maWcpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBWZW5kZWRvcikgPT4ge1xuICAgICAgICBjb25zdCBuZXdJdGVtID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YSk7XG4gICAgICAgIGlmIChuZXdJdGVtKSB7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBWZW5kZWRvciBjcmVhZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHZlbmRlZG9yZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgY29uZmlnPXt2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2luaXRpYWxWYWx1ZXMgYXMgVmVuZGVkb3J9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3ZlbmRlZG9yZXMvcGFnZXMvVmVuZGVkb3Jlc0NyZWF0ZVBhZ2UudHN4In0=