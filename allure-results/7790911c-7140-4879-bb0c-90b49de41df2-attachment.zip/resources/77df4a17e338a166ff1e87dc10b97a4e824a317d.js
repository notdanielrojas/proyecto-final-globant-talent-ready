import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericFormWithTaxes.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericFormWithTaxes.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { TaxSelectionBlock } from "/src/components/common/TaxSelectionBlock.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const GenericFormWithTaxes = ({
  mode,
  moduleConfig,
  taxFilterQuery,
  taxBlockTitle,
  taxTypeGroups,
  initialData,
  loadingItem,
  errorItem
}) => {
  _s();
  const navigate = useNavigate();
  const itemIdAsString = initialData.id ? String(initialData.id) : void 0;
  const { saveItem, loading: loadingSave } = useCrudItem(moduleConfig, itemIdAsString);
  const [selectedTaxIds, setSelectedTaxIds] = useState([]);
  useEffect(() => {
    if (mode === "edit" && initialData && initialData.relatedTaxes) {
      setSelectedTaxIds(initialData.relatedTaxes.map((tax) => tax.id));
    }
  }, [mode, initialData]);
  const handleSaveWrapper = async (formDataFromPage) => {
    const { relatedTaxes, ...restOfData } = formDataFromPage;
    const finalPayload = {
      ...restOfData,
      taxes: selectedTaxIds
      // Inyectamos la selección actual
    };
    const saved = await saveItem(finalPayload);
    if (saved) {
      toast.success(`${moduleConfig.moduleName} guardado con éxito!`);
      navigate(getListReturnPath(moduleConfig.baseRoute));
    }
  };
  if (loadingItem) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/components/common/GenericFormWithTaxes.tsx",
    lineNumber: 105,
    columnNumber: 27
  }, this);
  if (errorItem) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: errorItem }, void 0, false, {
    fileName: "/app/src/components/common/GenericFormWithTaxes.tsx",
    lineNumber: 106,
    columnNumber: 25
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: moduleConfig,
      mode,
      initialData,
      loading: loadingSave,
      onSave: handleSaveWrapper,
      children: /* @__PURE__ */ jsxDEV(
        TaxSelectionBlock,
        {
          title: taxBlockTitle,
          filterQuery: taxFilterQuery,
          typeGroups: taxTypeGroups,
          selectedIds: selectedTaxIds,
          onChange: setSelectedTaxIds
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/GenericFormWithTaxes.tsx",
          lineNumber: 117,
          columnNumber: 13
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/GenericFormWithTaxes.tsx",
      lineNumber: 109,
      columnNumber: 5
    },
    this
  );
};
_s(GenericFormWithTaxes, "RhrwrnCuROsXnECMpC8QvlL67HY=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = GenericFormWithTaxes;
var _c;
$RefreshReg$(_c, "GenericFormWithTaxes");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericFormWithTaxes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericFormWithTaxes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUY0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRjVCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBRy9CLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx5QkFBNEM7QUFDckQsU0FBU0MseUJBQXlCO0FBNEIzQixhQUFNQyx1QkFBdUIsQ0FBNEI7QUFBQSxFQUM1REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDMEIsTUFBTTtBQUFBQyxLQUFBO0FBRWhDLFFBQU1DLFdBQVdqQixZQUFZO0FBRTdCLFFBQU1rQixpQkFBaUJMLFlBQVlNLEtBQUtDLE9BQU9QLFlBQVlNLEVBQUUsSUFBSUU7QUFDakUsUUFBTSxFQUFFQyxVQUFVQyxTQUFTQyxZQUFZLElBQUl0QixZQUFlTyxjQUFjUyxjQUFjO0FBRXRGLFFBQU0sQ0FBQ08sZ0JBQWdCQyxpQkFBaUIsSUFBSTVCLFNBQW1CLEVBQUU7QUFHakVDLFlBQVUsTUFBTTtBQUNaLFFBQUlTLFNBQVMsVUFBVUssZUFBZUEsWUFBWWMsY0FBYztBQUM1REQsd0JBQWtCYixZQUFZYyxhQUFhQyxJQUFJLENBQUFDLFFBQU9BLElBQUlWLEVBQUUsQ0FBQztBQUFBLElBQ2pFO0FBQUEsRUFDSixHQUFHLENBQUNYLE1BQU1LLFdBQVcsQ0FBQztBQUd0QixRQUFNaUIsb0JBQW9CLE9BQU9DLHFCQUF3QjtBQUlyRCxVQUFNLEVBQUVKLGNBQWMsR0FBR0ssV0FBVyxJQUFJRDtBQUd4QyxVQUFNRSxlQUFlO0FBQUEsTUFDakIsR0FBR0Q7QUFBQUEsTUFDSEUsT0FBT1Q7QUFBQUE7QUFBQUEsSUFDWDtBQUdBLFVBQU1VLFFBQVEsTUFBTWIsU0FBU1csWUFBWTtBQUV6QyxRQUFJRSxPQUFPO0FBQ1BsQyxZQUFNbUMsUUFBUSxHQUFHM0IsYUFBYTRCLFVBQVUsc0JBQXNCO0FBQzlEcEIsZUFBU1gsa0JBQWtCRyxhQUFhNkIsU0FBUyxDQUFDO0FBQUEsSUFDdEQ7QUFBQSxFQUNKO0FBRUEsTUFBSXhCLFlBQWEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDdkMsTUFBSUMsVUFBVyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLHVCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlDO0FBRS9ELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFOO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTZTtBQUFBQSxNQUNULFFBQVFNO0FBQUFBLE1BR1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU9uQjtBQUFBQSxVQUNQLGFBQWFEO0FBQUFBLFVBQ2IsWUFBWUU7QUFBQUEsVUFDWixhQUFhYTtBQUFBQSxVQUNiLFVBQVVDO0FBQUFBO0FBQUFBLFFBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2dDO0FBQUE7QUFBQSxJQWJwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFlQTtBQUVSO0FBQUVWLEdBcEVXVCxzQkFBb0I7QUFBQSxVQVdaUCxhQUcwQkUsV0FBVztBQUFBO0FBQUFxQyxLQWQ3Q2hDO0FBQW9CLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwidXNlQ3J1ZEl0ZW0iLCJMb2FkaW5nU3Bpbm5lciIsIkdlbmVyaWNGb3JtUGFnZSIsIlRheFNlbGVjdGlvbkJsb2NrIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJHZW5lcmljRm9ybVdpdGhUYXhlcyIsIm1vZGUiLCJtb2R1bGVDb25maWciLCJ0YXhGaWx0ZXJRdWVyeSIsInRheEJsb2NrVGl0bGUiLCJ0YXhUeXBlR3JvdXBzIiwiaW5pdGlhbERhdGEiLCJsb2FkaW5nSXRlbSIsImVycm9ySXRlbSIsIl9zIiwibmF2aWdhdGUiLCJpdGVtSWRBc1N0cmluZyIsImlkIiwiU3RyaW5nIiwidW5kZWZpbmVkIiwic2F2ZUl0ZW0iLCJsb2FkaW5nIiwibG9hZGluZ1NhdmUiLCJzZWxlY3RlZFRheElkcyIsInNldFNlbGVjdGVkVGF4SWRzIiwicmVsYXRlZFRheGVzIiwibWFwIiwidGF4IiwiaGFuZGxlU2F2ZVdyYXBwZXIiLCJmb3JtRGF0YUZyb21QYWdlIiwicmVzdE9mRGF0YSIsImZpbmFsUGF5bG9hZCIsInRheGVzIiwic2F2ZWQiLCJzdWNjZXNzIiwibW9kdWxlTmFtZSIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkdlbmVyaWNGb3JtV2l0aFRheGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1XaXRoVGF4ZXMudHN4XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuLy8gSW1wb3J0YW1vcyBsb3MgY29tcG9uZW50ZXMgcmVmYWN0b3JpemFkb3NcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IFRheFNlbGVjdGlvbkJsb2NrLCB0eXBlIFRheFR5cGVHcm91cCB9IGZyb20gJy4vVGF4U2VsZWN0aW9uQmxvY2snO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmludGVyZmFjZSBUYXhJdGVtIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICByYXRlOiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBFbnRpdHlXaXRoVGF4ZXMge1xuICAgIGlkOiBzdHJpbmcgfCBudW1iZXI7XG4gICAgcmVsYXRlZFRheGVzPzogVGF4SXRlbVtdOyAvLyBDb21vIHZpZW5lbiBkZSBsYSBBUElcbiAgICB0YXhlcz86IG51bWJlcltdOyAgICAgICAgIC8vIENvbW8gbG9zIGVudmlhbW9zIGFsIGd1YXJkYXJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIFtrZXk6IHN0cmluZ106IGFueTtcbn1cblxuaW50ZXJmYWNlIEdlbmVyaWNGb3JtV2l0aFRheGVzUHJvcHM8VCBleHRlbmRzIEVudGl0eVdpdGhUYXhlcz4ge1xuICAgIG1vZGU6ICdjcmVhdGUnIHwgJ2VkaXQnO1xuICAgIG1vZHVsZUNvbmZpZzogTW9kdWxlQ29uZmlnPFQ+O1xuICAgIHRheEZpbHRlclF1ZXJ5OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICAgIHRheEJsb2NrVGl0bGU6IHN0cmluZztcbiAgICAvKiogU2kgc2UgZGVmaW5lLCBlbCBibG9xdWUgZGUgaW1wdWVzdG9zIHNlIGNhcmdhIHkgbXVlc3RyYSBwb3IgdGlwbyAoc3Vic2VjY2lvbmVzIGNvbiB0w610dWxvKS4gKi9cbiAgICB0YXhUeXBlR3JvdXBzPzogVGF4VHlwZUdyb3VwW107XG4gICAgaW5pdGlhbERhdGE6IFBhcnRpYWw8VD47XG4gICAgbG9hZGluZ0l0ZW0/OiBib29sZWFuO1xuICAgIGVycm9ySXRlbT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBjb25zdCBHZW5lcmljRm9ybVdpdGhUYXhlcyA9IDxUIGV4dGVuZHMgRW50aXR5V2l0aFRheGVzPih7XG4gICAgbW9kZSxcbiAgICBtb2R1bGVDb25maWcsXG4gICAgdGF4RmlsdGVyUXVlcnksXG4gICAgdGF4QmxvY2tUaXRsZSxcbiAgICB0YXhUeXBlR3JvdXBzLFxuICAgIGluaXRpYWxEYXRhLFxuICAgIGxvYWRpbmdJdGVtLFxuICAgIGVycm9ySXRlbSxcbn06IEdlbmVyaWNGb3JtV2l0aFRheGVzUHJvcHM8VD4pID0+IHtcblxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICAvLyBVc2Ftb3MgZWwgaG9vayBwYXJhIG1hbmVqYXIgbGEgbMOzZ2ljYSBkZSBndWFyZGFkbyAoQVBJKVxuICAgIGNvbnN0IGl0ZW1JZEFzU3RyaW5nID0gaW5pdGlhbERhdGEuaWQgPyBTdHJpbmcoaW5pdGlhbERhdGEuaWQpIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IHsgc2F2ZUl0ZW0sIGxvYWRpbmc6IGxvYWRpbmdTYXZlIH0gPSB1c2VDcnVkSXRlbTxUPihtb2R1bGVDb25maWcsIGl0ZW1JZEFzU3RyaW5nKTtcblxuICAgIGNvbnN0IFtzZWxlY3RlZFRheElkcywgc2V0U2VsZWN0ZWRUYXhJZHNdID0gdXNlU3RhdGU8bnVtYmVyW10+KFtdKTtcblxuICAgIC8vIFNpbmNyb25pemFtb3MgbG9zIGltcHVlc3RvcyBpbmljaWFsZXMgY3VhbmRvIGxsZWdhbiBsb3MgZGF0b3NcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobW9kZSA9PT0gJ2VkaXQnICYmIGluaXRpYWxEYXRhICYmIGluaXRpYWxEYXRhLnJlbGF0ZWRUYXhlcykge1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRUYXhJZHMoaW5pdGlhbERhdGEucmVsYXRlZFRheGVzLm1hcCh0YXggPT4gdGF4LmlkKSk7XG4gICAgICAgIH1cbiAgICB9LCBbbW9kZSwgaW5pdGlhbERhdGFdKTtcblxuICAgIC8vIEVzdGEgZnVuY2nDs24gaW50ZXJjZXB0YSBlbCBndWFyZGFkbyBkZWwgR2VuZXJpY0Zvcm1QYWdlXG4gICAgY29uc3QgaGFuZGxlU2F2ZVdyYXBwZXIgPSBhc3luYyAoZm9ybURhdGFGcm9tUGFnZTogVCkgPT4ge1xuXG4gICAgICAgIC8vIDEuIExpbXBpYW1vcyBlbCBhcnJheSBkZSBvYmpldG9zICdyZWxhdGVkVGF4ZXMnIHBhcmEgbm8gZW52aWFybG8gc3VjaW9cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICBjb25zdCB7IHJlbGF0ZWRUYXhlcywgLi4ucmVzdE9mRGF0YSB9ID0gZm9ybURhdGFGcm9tUGFnZTtcblxuICAgICAgICAvLyAyLiBDb21iaW5hbW9zIGxvcyBkYXRvcyBkZWwgZm9ybXVsYXJpbyBjb24gbnVlc3Ryb3MgSURzIGRlIGltcHVlc3Rvc1xuICAgICAgICBjb25zdCBmaW5hbFBheWxvYWQgPSB7XG4gICAgICAgICAgICAuLi5yZXN0T2ZEYXRhLFxuICAgICAgICAgICAgdGF4ZXM6IHNlbGVjdGVkVGF4SWRzLCAvLyBJbnllY3RhbW9zIGxhIHNlbGVjY2nDs24gYWN0dWFsXG4gICAgICAgIH0gYXMgVDtcblxuICAgICAgICAvLyAzLiBMbGFtYW1vcyBhbCBob29rIGRlIGd1YXJkYWRvXG4gICAgICAgIGNvbnN0IHNhdmVkID0gYXdhaXQgc2F2ZUl0ZW0oZmluYWxQYXlsb2FkKTtcblxuICAgICAgICBpZiAoc2F2ZWQpIHtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCR7bW9kdWxlQ29uZmlnLm1vZHVsZU5hbWV9IGd1YXJkYWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChtb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmdJdGVtKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvckl0ZW0pIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvckl0ZW19PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgY29uZmlnPXttb2R1bGVDb25maWd9XG4gICAgICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2luaXRpYWxEYXRhIGFzIFR9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nU2F2ZX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZVdyYXBwZXJ9IC8vIExlIHBhc2Ftb3MgbnVlc3RybyBpbnRlcmNlcHRvclxuICAgICAgICA+XG4gICAgICAgICAgICB7LyogSW55ZWN0YW1vcyBlbCBibG9xdWUgZGUgaW1wdWVzdG9zIGNvbW8gJ2NoaWxkcmVuJyAqL31cbiAgICAgICAgICAgIDxUYXhTZWxlY3Rpb25CbG9ja1xuICAgICAgICAgICAgICAgIHRpdGxlPXt0YXhCbG9ja1RpdGxlfVxuICAgICAgICAgICAgICAgIGZpbHRlclF1ZXJ5PXt0YXhGaWx0ZXJRdWVyeX1cbiAgICAgICAgICAgICAgICB0eXBlR3JvdXBzPXt0YXhUeXBlR3JvdXBzfVxuICAgICAgICAgICAgICAgIHNlbGVjdGVkSWRzPXtzZWxlY3RlZFRheElkc31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRUYXhJZHN9XG4gICAgICAgICAgICAvPlxuICAgICAgICA8L0dlbmVyaWNGb3JtUGFnZT5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtV2l0aFRheGVzLnRzeCJ9