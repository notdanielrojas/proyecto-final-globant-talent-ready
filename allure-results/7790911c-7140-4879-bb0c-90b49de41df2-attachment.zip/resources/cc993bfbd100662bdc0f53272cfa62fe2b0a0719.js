import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const fractioningsModuleConfig = {
  endpoint: "fractionings",
  moduleName: "Fraccionamiento/Impresión",
  moduleNamePlural: "Fraccionamientos/Impresiones",
  baseRoute: "/stock/fraccionamientos",
  disableEdit: true,
  detail: {
    displayNameKey: "id"
  },
  list: {
    columns: [
      { header: "ID", accessor: "id" },
      { header: "Fecha", accessor: "fractioning_date", format: "date" },
      //{ header: 'Descripción', accessor: 'description' },
      {
        header: "Productos Origen (Consumidos)",
        accessor: "movements",
        render: (item) => {
          const sourceItems = item.movements.filter((m) => parseFloat(m.quantity) < 0);
          return /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-600", children: [
            sourceItems.length,
            " producto(s)"
          ] }, void 0, true, {
            fileName: "/app/src/features/fractionings/fractionings.config.tsx",
            lineNumber: 50,
            columnNumber: 11
          }, this);
        }
      },
      {
        header: "Productos Resultantes (Generados)",
        accessor: "movements",
        render: (item) => {
          const resultingItems = item.movements.filter((m) => parseFloat(m.quantity) > 0 && !m.is_remanente);
          return /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-green-600", children: [
            resultingItems.length,
            " producto(s)"
          ] }, void 0, true, {
            fileName: "/app/src/features/fractionings/fractionings.config.tsx",
            lineNumber: 63,
            columnNumber: 11
          }, this);
        }
      },
      {
        header: "Productos Remanentes",
        accessor: "movements",
        render: (item) => {
          const resultingItems = item.movements.filter((m) => parseFloat(m.quantity) > 0 && m.is_remanente);
          return /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-orange-600", children: [
            resultingItems.length,
            " producto(s)"
          ] }, void 0, true, {
            fileName: "/app/src/features/fractionings/fractionings.config.tsx",
            lineNumber: 76,
            columnNumber: 11
          }, this);
        }
      }
      //{ header: 'Fecha de Creación', accessor: 'created_at', format: 'date' },
    ]
  },
  form: {
    block: []
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUR3QjtBQXZCakIsYUFBTUEsMkJBQXNEO0FBQUEsRUFDL0RDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsa0JBQWtCO0FBQUEsRUFDbEJDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQUEsRUFFYkMsUUFBUTtBQUFBLElBQ0pDLGdCQUFnQjtBQUFBLEVBQ3BCO0FBQUEsRUFFQUMsTUFBTTtBQUFBLElBQ0ZDLFNBQVM7QUFBQSxNQUNMLEVBQUVDLFFBQVEsTUFBTUMsVUFBVSxLQUFLO0FBQUEsTUFDL0IsRUFBRUQsUUFBUSxTQUFTQyxVQUFVLG9CQUFvQkMsUUFBUSxPQUFPO0FBQUE7QUFBQSxNQUVoRTtBQUFBLFFBQ0lGLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkUsUUFBUUEsQ0FBQ0MsU0FBc0I7QUFFM0IsZ0JBQU1DLGNBQWNELEtBQUtFLFVBQVVDLE9BQU8sQ0FBQUMsTUFBS0MsV0FBV0QsRUFBRUUsUUFBUSxJQUFJLENBQUM7QUFDekUsaUJBQ0ksdUJBQUMsVUFBSyxXQUFVLHdCQUNYTDtBQUFBQSx3QkFBWU07QUFBQUEsWUFBTztBQUFBLGVBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUVSO0FBQUEsTUFDSjtBQUFBLE1BQ0E7QUFBQSxRQUNJWCxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZFLFFBQVFBLENBQUNDLFNBQXNCO0FBRTNCLGdCQUFNUSxpQkFBaUJSLEtBQUtFLFVBQVVDLE9BQU8sQ0FBQUMsTUFBS0MsV0FBV0QsRUFBRUUsUUFBUSxJQUFJLEtBQUssQ0FBQ0YsRUFBRUssWUFBWTtBQUMvRixpQkFDSSx1QkFBQyxVQUFLLFdBQVUsMEJBQ1hEO0FBQUFBLDJCQUFlRDtBQUFBQSxZQUFPO0FBQUEsZUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBRVI7QUFBQSxNQUNKO0FBQUEsTUFDQTtBQUFBLFFBQ0lYLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkUsUUFBUUEsQ0FBQ0MsU0FBc0I7QUFFM0IsZ0JBQU1RLGlCQUFpQlIsS0FBS0UsVUFBVUMsT0FBTyxDQUFBQyxNQUFLQyxXQUFXRCxFQUFFRSxRQUFRLElBQUksS0FBS0YsRUFBRUssWUFBWTtBQUM5RixpQkFDSSx1QkFBQyxVQUFLLFdBQVUsMkJBQ1hEO0FBQUFBLDJCQUFlRDtBQUFBQSxZQUFPO0FBQUEsZUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBRVI7QUFBQSxNQUNKO0FBQUE7QUFBQSxJQUNBO0FBQUEsRUFFUjtBQUFBLEVBRUFHLE1BQU07QUFBQSxJQUNGQyxPQUFPO0FBQUEsRUFDWDtBQUNKIiwibmFtZXMiOlsiZnJhY3Rpb25pbmdzTW9kdWxlQ29uZmlnIiwiZW5kcG9pbnQiLCJtb2R1bGVOYW1lIiwibW9kdWxlTmFtZVBsdXJhbCIsImJhc2VSb3V0ZSIsImRpc2FibGVFZGl0IiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJsaXN0IiwiY29sdW1ucyIsImhlYWRlciIsImFjY2Vzc29yIiwiZm9ybWF0IiwicmVuZGVyIiwiaXRlbSIsInNvdXJjZUl0ZW1zIiwibW92ZW1lbnRzIiwiZmlsdGVyIiwibSIsInBhcnNlRmxvYXQiLCJxdWFudGl0eSIsImxlbmd0aCIsInJlc3VsdGluZ0l0ZW1zIiwiaXNfcmVtYW5lbnRlIiwiZm9ybSIsImJsb2NrIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImZyYWN0aW9uaW5ncy5jb25maWcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZVwiO1xuXG4vLyAtLS0gTlVFVkFTIElOVEVSRkFDRVMgQUxJTkVBREFTIENPTiBMQSBBUEkgLS0tXG5cbi8vIEludGVyZmF6IHBhcmEgdW4gbW92aW1pZW50byBpbmRpdmlkdWFsIGRlbnRybyBkZSB1biBmcmFjY2lvbmFtaWVudG9cbmV4cG9ydCBpbnRlcmZhY2UgRnJhY3Rpb25pbmdNb3ZlbWVudCB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBwcm9kdWN0X2lkOiBudW1iZXI7XG4gICAgcHJvZHVjdF9uYW1lPzogc3RyaW5nOyAvLyBFbCBub21icmUgdmllbmUgZW4gZWwgZGV0YWxsZVxuICAgIHF1YW50aXR5OiBzdHJpbmc7IC8vIExhIEFQSSBsbyBlbnbDrWEgY29tbyBzdHJpbmdcbiAgICBtb3ZlbWVudF9jb2RlOiAnQScgfCAnQic7IC8vIEE9QWx0YSwgQj1CYWphXG4gICAgb2JzZXJ2YXRpb246IHN0cmluZyB8IG51bGw7IC8vIOKchSBOdWV2byBjYW1wb1xuICAgIGFkZGl0aW9uYWxfY29zdDogc3RyaW5nIHwgbnVsbDsgLy8g4pyFIE51ZXZvIGNhbXBvXG4gICAgaXNfcmVtYW5lbnRlOiBib29sZWFuO1xufVxuXG4vLyBJbnRlcmZheiBwcmluY2lwYWwgcGFyYSB1biByZWdpc3RybyBkZSBGcmFjY2lvbmFtaWVudG9cbmV4cG9ydCBpbnRlcmZhY2UgRnJhY3Rpb25pbmcge1xuICAgIGlkOiBudW1iZXI7XG4gICAgZnJhY3Rpb25pbmdfZGF0ZTogc3RyaW5nO1xuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsO1xuICAgIGNyZWF0ZWRfYXQ6IHN0cmluZztcbiAgICBtb3ZlbWVudHM6IEZyYWN0aW9uaW5nTW92ZW1lbnRbXTsgLy8gVW4gw7puaWNvIGFycmF5IGRlIG1vdmltaWVudG9zXG59XG5cbi8vIENvbmZpZ3VyYWNpw7NuIGRlbCBtw7NkdWxvIGFjdHVhbGl6YWRhXG5leHBvcnQgY29uc3QgZnJhY3Rpb25pbmdzTW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8RnJhY3Rpb25pbmc+ID0ge1xuICAgIGVuZHBvaW50OiAnZnJhY3Rpb25pbmdzJyxcbiAgICBtb2R1bGVOYW1lOiAnRnJhY2Npb25hbWllbnRvL0ltcHJlc2nDs24nLFxuICAgIG1vZHVsZU5hbWVQbHVyYWw6ICdGcmFjY2lvbmFtaWVudG9zL0ltcHJlc2lvbmVzJyxcbiAgICBiYXNlUm91dGU6ICcvc3RvY2svZnJhY2Npb25hbWllbnRvcycsXG4gICAgZGlzYWJsZUVkaXQ6IHRydWUsXG5cbiAgICBkZXRhaWw6IHtcbiAgICAgICAgZGlzcGxheU5hbWVLZXk6ICdpZCcsXG4gICAgfSxcblxuICAgIGxpc3Q6IHtcbiAgICAgICAgY29sdW1uczogW1xuICAgICAgICAgICAgeyBoZWFkZXI6ICdJRCcsIGFjY2Vzc29yOiAnaWQnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0ZlY2hhJywgYWNjZXNzb3I6ICdmcmFjdGlvbmluZ19kYXRlJywgZm9ybWF0OiAnZGF0ZScgfSxcbiAgICAgICAgICAgIC8veyBoZWFkZXI6ICdEZXNjcmlwY2nDs24nLCBhY2Nlc3NvcjogJ2Rlc2NyaXB0aW9uJyB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1Byb2R1Y3RvcyBPcmlnZW4gKENvbnN1bWlkb3MpJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ21vdmVtZW50cycsXG4gICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbTogRnJhY3Rpb25pbmcpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmlsdHJhbW9zIGxvcyBtb3ZpbWllbnRvcyBkZSBCQUpBIChjYW50aWRhZCBuZWdhdGl2YSlcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc291cmNlSXRlbXMgPSBpdGVtLm1vdmVtZW50cy5maWx0ZXIobSA9PiBwYXJzZUZsb2F0KG0ucXVhbnRpdHkpIDwgMCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzb3VyY2VJdGVtcy5sZW5ndGh9IHByb2R1Y3RvKHMpXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdQcm9kdWN0b3MgUmVzdWx0YW50ZXMgKEdlbmVyYWRvcyknLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAnbW92ZW1lbnRzJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtOiBGcmFjdGlvbmluZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBGaWx0cmFtb3MgbG9zIG1vdmltaWVudG9zIGRlIEFMVEEgKGNhbnRpZGFkIHBvc2l0aXZhKVxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRpbmdJdGVtcyA9IGl0ZW0ubW92ZW1lbnRzLmZpbHRlcihtID0+IHBhcnNlRmxvYXQobS5xdWFudGl0eSkgPiAwICYmICFtLmlzX3JlbWFuZW50ZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdGluZ0l0ZW1zLmxlbmd0aH0gcHJvZHVjdG8ocylcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1Byb2R1Y3RvcyBSZW1hbmVudGVzJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ21vdmVtZW50cycsXG4gICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbTogRnJhY3Rpb25pbmcpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmlsdHJhbW9zIGxvcyBtb3ZpbWllbnRvcyBkZSBBTFRBIChjYW50aWRhZCBwb3NpdGl2YSlcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0aW5nSXRlbXMgPSBpdGVtLm1vdmVtZW50cy5maWx0ZXIobSA9PiBwYXJzZUZsb2F0KG0ucXVhbnRpdHkpID4gMCAmJiBtLmlzX3JlbWFuZW50ZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtb3JhbmdlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHRpbmdJdGVtcy5sZW5ndGh9IHByb2R1Y3RvKHMpXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8veyBoZWFkZXI6ICdGZWNoYSBkZSBDcmVhY2nDs24nLCBhY2Nlc3NvcjogJ2NyZWF0ZWRfYXQnLCBmb3JtYXQ6ICdkYXRlJyB9LFxuICAgICAgICBdLFxuICAgIH0sXG5cbiAgICBmb3JtOiB7XG4gICAgICAgIGJsb2NrOiBbXVxuICAgIH1cbn07XG5cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvZnJhY3Rpb25pbmdzL2ZyYWN0aW9uaW5ncy5jb25maWcudHN4In0=