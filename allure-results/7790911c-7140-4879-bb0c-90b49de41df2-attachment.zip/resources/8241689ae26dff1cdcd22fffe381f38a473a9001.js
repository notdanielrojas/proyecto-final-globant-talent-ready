import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/pages/ArticulosFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/pages/ArticulosFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { GenericFormWithTaxes } from "/src/components/common/GenericFormWithTaxes.tsx";
export const ArticulosFormPage = ({ mode, initialData, loading: loadingItem, error: errorItem }) => {
  return /* @__PURE__ */ jsxDEV(
    GenericFormWithTaxes,
    {
      mode,
      moduleConfig: articulosModuleConfig,
      taxFilterQuery: { type: "1" },
      taxBlockTitle: "Impuestos Específicos del Producto",
      initialData,
      loadingItem,
      errorItem
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/articulos/pages/ArticulosFormPage.tsx",
      lineNumber: 34,
      columnNumber: 10
    },
    this
  );
};
_c = ArticulosFormPage;
var _c;
$RefreshReg$(_c, "ArticulosFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/pages/ArticulosFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/pages/ArticulosFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkWixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLDZCQUE0QztBQUNyRCxTQUFTQyw0QkFBNEI7QUFVOUIsYUFBTUMsb0JBQXNEQSxDQUFDLEVBQUVDLE1BQU1DLGFBQWFDLFNBQVNDLGFBQWFDLE9BQU9DLFVBQVUsTUFBTTtBQUVsSSxTQUFRO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDTDtBQUFBLE1BQ0EsY0FBY1I7QUFBQUEsTUFFZCxnQkFBZ0IsRUFBRVMsTUFBTSxJQUFJO0FBQUEsTUFDNUIsZUFBYztBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFSSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRaUI7QUFFN0I7QUFBRUMsS0FaV1I7QUFBbUQsSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiR2VuZXJpY0Zvcm1XaXRoVGF4ZXMiLCJBcnRpY3Vsb3NGb3JtUGFnZSIsIm1vZGUiLCJpbml0aWFsRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nSXRlbSIsImVycm9yIiwiZXJyb3JJdGVtIiwidHlwZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFydGljdWxvc0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCB0eXBlIEFydGljdWxvIH0gZnJvbSAnLi4vYXJ0aWN1bG9zLmNvbmZpZyc7XG5pbXBvcnQgeyBHZW5lcmljRm9ybVdpdGhUYXhlcyB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtV2l0aFRheGVzJzsgLy8g4pyFIDEuIEltcG9ydGFtb3MgZWwgbnVldm8gY29tcG9uZW50ZVxuXG5pbnRlcmZhY2UgQXJ0aWN1bG9zRm9ybVBhZ2VQcm9wcyB7XG4gICAgbW9kZTogJ2NyZWF0ZScgfCAnZWRpdCc7XG4gICAgaW5pdGlhbERhdGE/OiBBcnRpY3VsbztcbiAgICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgICBlcnJvcj86IHN0cmluZyB8IG51bGw7XG59XG5cblxuZXhwb3J0IGNvbnN0IEFydGljdWxvc0Zvcm1QYWdlOiBSZWFjdC5GQzxBcnRpY3Vsb3NGb3JtUGFnZVByb3BzPiA9ICh7IG1vZGUsIGluaXRpYWxEYXRhLCBsb2FkaW5nOiBsb2FkaW5nSXRlbSwgZXJyb3I6IGVycm9ySXRlbSB9KSA9PiB7XG4gICAgLy8g4pyFIDIuIFJlbmRlcml6YW1vcyBlbCBmb3JtdWxhcmlvIGdlbsOpcmljbyBjb24gbGEgY29uZmlnIGRlIEFydMOtY3Vsb3NcbiAgICByZXR1cm4gKDxHZW5lcmljRm9ybVdpdGhUYXhlc1xuICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICBtb2R1bGVDb25maWc9e2FydGljdWxvc01vZHVsZUNvbmZpZ31cbiAgICAgICAgLy8gRmlsdHJhbW9zIHBvciBpbXB1ZXN0b3MgZGUgdGlwbyBcInByb2R1Y3RvXCJcbiAgICAgICAgdGF4RmlsdGVyUXVlcnk9e3sgdHlwZTogJzEnIH19XG4gICAgICAgIHRheEJsb2NrVGl0bGU9XCJJbXB1ZXN0b3MgRXNwZWPDrWZpY29zIGRlbCBQcm9kdWN0b1wiXG4gICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsRGF0YSF9XG4gICAgICAgIGxvYWRpbmdJdGVtPXtsb2FkaW5nSXRlbX1cbiAgICAgICAgZXJyb3JJdGVtPXtlcnJvckl0ZW19XG4gICAgLz4pXG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYXJ0aWN1bG9zL3BhZ2VzL0FydGljdWxvc0Zvcm1QYWdlLnRzeCJ9