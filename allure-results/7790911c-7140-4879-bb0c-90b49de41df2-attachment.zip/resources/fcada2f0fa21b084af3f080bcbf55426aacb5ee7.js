import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/pages/ArticulosCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/pages/ArticulosCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ArticulosFormPage } from "/src/features/articulos/pages/ArticulosFormPage.tsx";
const initialProductValues = {
  sku: "",
  name: "",
  stock_quantity: 0,
  cost_price: 0,
  sale_price: 0,
  unit: "",
  is_active: true,
  line: null,
  category: null,
  // ✅ 3. Añadir campos de impuestos para alinear con la interfaz
  relatedTaxes: [],
  taxes: []
};
export const ArticuloCreatePage = () => {
  return (
    // ✅ 4. Renderizar el wrapper
    /* @__PURE__ */ jsxDEV(
      ArticulosFormPage,
      {
        mode: "create",
        initialData: initialProductValues
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/articulos/pages/ArticulosCreatePage.tsx",
        lineNumber: 41,
        columnNumber: 5
      },
      this
    )
  );
};
_c = ArticuloCreatePage;
var _c;
$RefreshReg$(_c, "ArticuloCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/pages/ArticulosCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/pages/ArticulosCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJSLFNBQVNBLHlCQUF5QjtBQUVsQyxNQUFNQyx1QkFBMEM7QUFBQSxFQUM1Q0MsS0FBSztBQUFBLEVBQ0xDLE1BQU07QUFBQSxFQUNOQyxnQkFBZ0I7QUFBQSxFQUNoQkMsWUFBWTtBQUFBLEVBQ1pDLFlBQVk7QUFBQSxFQUNaQyxNQUFNO0FBQUEsRUFDTkMsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQUE7QUFBQSxFQUVWQyxjQUFjO0FBQUEsRUFDZEMsT0FBTztBQUNYO0FBRU8sYUFBTUMscUJBQXFCQSxNQUFNO0FBQ3BDO0FBQUE7QUFBQSxJQUVJO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFLO0FBQUEsUUFHTCxhQUFhWjtBQUFBQTtBQUFBQSxNQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJa0Q7QUFBQTtBQUcxRDtBQUFFYSxLQVZXRDtBQUFrQixJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQXJ0aWN1bG9zRm9ybVBhZ2UiLCJpbml0aWFsUHJvZHVjdFZhbHVlcyIsInNrdSIsIm5hbWUiLCJzdG9ja19xdWFudGl0eSIsImNvc3RfcHJpY2UiLCJzYWxlX3ByaWNlIiwidW5pdCIsImlzX2FjdGl2ZSIsImxpbmUiLCJjYXRlZ29yeSIsInJlbGF0ZWRUYXhlcyIsInRheGVzIiwiQXJ0aWN1bG9DcmVhdGVQYWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXJ0aWN1bG9zQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBcnRpY3VsbyB9IGZyb20gJy4uL2FydGljdWxvcy5jb25maWcnO1xuaW1wb3J0IHsgQXJ0aWN1bG9zRm9ybVBhZ2UgfSBmcm9tICcuL0FydGljdWxvc0Zvcm1QYWdlJztcblxuY29uc3QgaW5pdGlhbFByb2R1Y3RWYWx1ZXM6IFBhcnRpYWw8QXJ0aWN1bG8+ID0ge1xuICAgIHNrdTogJycsXG4gICAgbmFtZTogJycsXG4gICAgc3RvY2tfcXVhbnRpdHk6IDAsXG4gICAgY29zdF9wcmljZTogMCxcbiAgICBzYWxlX3ByaWNlOiAwLFxuICAgIHVuaXQ6ICcnLFxuICAgIGlzX2FjdGl2ZTogdHJ1ZSxcbiAgICBsaW5lOiBudWxsLFxuICAgIGNhdGVnb3J5OiBudWxsLFxuICAgIC8vIOKchSAzLiBBw7FhZGlyIGNhbXBvcyBkZSBpbXB1ZXN0b3MgcGFyYSBhbGluZWFyIGNvbiBsYSBpbnRlcmZhelxuICAgIHJlbGF0ZWRUYXhlczogW10sXG4gICAgdGF4ZXM6IFtdLFxufTtcblxuZXhwb3J0IGNvbnN0IEFydGljdWxvQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICAvLyDinIUgNC4gUmVuZGVyaXphciBlbCB3cmFwcGVyXG4gICAgICAgIDxBcnRpY3Vsb3NGb3JtUGFnZVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgICAgICAvLyDinIUgNS4gwqFMQSBDT1JSRUNDScOTTiEgUGFzYXIgJ2luaXRpYWxEYXRhJ1xuICAgICAgICAgICAgLy8gRXN0byBldml0YSBxdWUgJ2luaXRpYWxEYXRhJyBzZWEgJ3VuZGVmaW5lZCcgZW4gR2VuZXJpY0Zvcm1XaXRoVGF4ZXMuXG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFByb2R1Y3RWYWx1ZXMgYXMgQXJ0aWN1bG99XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9hcnRpY3Vsb3MvcGFnZXMvQXJ0aWN1bG9zQ3JlYXRlUGFnZS50c3gifQ==