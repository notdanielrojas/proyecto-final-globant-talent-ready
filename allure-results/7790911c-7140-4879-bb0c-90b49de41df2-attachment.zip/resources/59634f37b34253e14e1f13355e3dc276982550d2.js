import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/lista_precios/pages/ListasPreciosFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { priceListsModuleConfig } from "/src/features/lista_precios/listas_precios.config.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { searchByField } from "/src/services/apiService.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const EMPTY_ITEM = {
  id: 0,
  tempId: "",
  priceable_id: 0,
  priceable_type: "App\\Models\\Product",
  price: 0,
  product_name: "",
  product_code: ""
};
const defaultInitialData = {
  name: "",
  description: "",
  type: "general",
  is_active: true,
  valid_from: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  valid_to: null,
  client_id: null,
  client: void 0,
  items: []
};
export const ListasDePreciosFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: initialData, loading: loadingInitial, error } = useCrudItem(priceListsModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(priceListsModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const [editingItemTempId, setEditingItemTempId] = useState(null);
  const [clientCodeInput, setClientCodeInput] = useState("");
  const [productCodes, setProductCodes] = useState({});
  useEffect(() => {
    if (mode === "edit" && initialData) {
      const hydratedData = {
        ...defaultInitialData,
        ...initialData,
        is_active: initialData.is_active ?? true,
        valid_from: initialData.valid_from?.split("T")[0] || "",
        valid_to: initialData.valid_to?.split("T")[0] || null
      };
      if (initialData.client && clientesModuleConfig.relationalFields) {
        const { codeField } = clientesModuleConfig.relationalFields;
        hydratedData.customer_code = initialData.client[codeField] || "";
      }
      setFormData(hydratedData);
      if (hydratedData.customer_code) {
        setClientCodeInput(hydratedData.customer_code);
      }
      const itemsWithCodes = {};
      const loadedItems = initialData.items?.map((item) => {
        const tempId = crypto.randomUUID();
        itemsWithCodes[tempId] = item.priceable_code || "";
        return {
          ...item,
          tempId,
          product_name: item.priceable_name || `Producto ${item.priceable_id}`,
          product_code: item.priceable_code || `CODE-${item.priceable_id}`
        };
      }) || [];
      setItems(loadedItems);
      setProductCodes(itemsWithCodes);
    } else if (mode === "create") {
      setFormData(defaultInitialData);
      setItems([]);
      setClientCodeInput("");
      setProductCodes({});
    }
  }, [initialData, mode]);
  const handleHeaderChange = (e) => {
    const { name, value, type, checked } = e.target;
    let finalValue = type === "checkbox" ? checked : value;
    if (name === "is_active") finalValue = value === "true";
    if (name === "client_id" && value === "") finalValue = null;
    setFormData((prev) => ({
      ...prev,
      [name]: finalValue,
      ...name === "type" && value === "general" && { client_id: null, client_name: "", client: void 0 }
    }));
  };
  const handleAddItem = () => {
    const newId = crypto.randomUUID();
    setItems((prev) => [...prev, { ...EMPTY_ITEM, tempId: newId }]);
    setProductCodes((prev) => ({ ...prev, [newId]: "" }));
  };
  const handleRemoveItem = (tempId) => {
    setItems((prev) => prev.filter((item) => item.tempId !== tempId));
    setProductCodes((prev) => {
      const updated = { ...prev };
      delete updated[tempId];
      return updated;
    });
  };
  const handlePriceChange = (tempId, newPrice) => {
    setItems((prev) => prev.map(
      (item) => item.tempId === tempId ? { ...item, price: newPrice } : item
    ));
  };
  const handleOpenModal = (target, itemTempId) => {
    setEditingTarget(target);
    if (target === "client") {
      setModalConfig(clientesModuleConfig);
      setIsModalOpen(true);
    } else if (target === "item") {
      setEditingItemTempId(itemTempId || null);
      setIsProductModalOpen(true);
    }
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setIsProductModalOpen(false);
    setEditingTarget(null);
    setEditingItemTempId(null);
    setModalConfig(null);
  };
  const handleClientCodeSubmit = async () => {
    if (!clientCodeInput.trim()) return;
    try {
      const found = await searchByField(
        clientesModuleConfig.endpoint,
        [{ fieldName: "customer_code", value: clientCodeInput }]
      );
      if (found) {
        setFormData((prev) => ({
          ...prev,
          client_id: found.id,
          client_name: found.name,
          customer_code: found.customer_code || "",
          client: found
        }));
        setClientCodeInput(found.customer_code || String(found.id));
        toast.success(`Cliente encontrado: ${found.name}`);
      } else {
        toast.warning("Cliente no encontrado con ese código.");
        setFormData((prev) => ({ ...prev, client_id: null, client_name: void 0, customer_code: void 0, client: void 0 }));
      }
    } catch (error2) {
      toast.error("Error al buscar cliente por código.");
      console.error(error2);
    }
  };
  const handleProductCodeSubmit = async (tempId) => {
    const codeToSearch = productCodes[tempId]?.trim();
    if (!codeToSearch) return;
    try {
      const found = await searchByField(
        articulosModuleConfig.endpoint,
        [{ fieldName: "sku", value: codeToSearch }]
      );
      if (found) {
        setItems((prev) => prev.map(
          (item) => item.tempId === tempId ? {
            ...item,
            priceable_id: found.id,
            product_name: found.name,
            product_code: found.sku || found.code || "",
            price: found.sale_price || 0
          } : item
        ));
        setProductCodes((prev) => ({ ...prev, [tempId]: found.sku || found.code || String(found.id) }));
        toast.success(`Producto encontrado: ${found.name}`);
      } else {
        toast.warning("Producto no encontrado con ese código.");
        setItems((prev) => prev.map(
          (item) => item.tempId === tempId ? { ...item, priceable_id: 0, product_code: "", product_name: "", price: 0 } : item
        ));
      }
    } catch (error2) {
      toast.error("Error al buscar producto por código.");
      console.error(error2);
    }
  };
  const handleSelectModal = (selectedItem) => {
    if (!editingTarget) return;
    if (editingTarget === "client") {
      setFormData((prev) => ({
        ...prev,
        client_id: selectedItem.id,
        client_name: selectedItem.name,
        customer_code: selectedItem.customer_code || "",
        client: selectedItem
      }));
      setClientCodeInput(selectedItem.customer_code || String(selectedItem.id));
    } else if (editingTarget === "item" && editingItemTempId) {
      setItems((prevItems) => prevItems.map((item) => {
        if (item.tempId === editingItemTempId) {
          return {
            ...item,
            priceable_id: selectedItem.id,
            product_name: selectedItem.name,
            product_code: selectedItem.sku || selectedItem.code || "",
            price: selectedItem.sale_price || 0
          };
        }
        return item;
      }));
      setProductCodes((prev) => ({ ...prev, [editingItemTempId]: selectedItem.sku || selectedItem.code || String(selectedItem.id) }));
    }
    handleCloseModal();
  };
  const handleClearSelection = (target, itemTempId) => {
    if (target === "client") {
      setFormData((prev) => ({ ...prev, client_id: null, client_name: "", customer_code: void 0, client: void 0 }));
      setClientCodeInput("");
    } else if (target === "item" && itemTempId) {
      setItems((prev) => prev.map((item) => {
        if (item.tempId === itemTempId) {
          return { ...item, priceable_id: 0, product_code: "", product_name: "", price: 0 };
        }
        return item;
      }));
      setProductCodes((prev) => ({ ...prev, [itemTempId]: "" }));
    }
  };
  const handleSave = async () => {
    if (items.length === 0) {
      toast.error("Debe añadir al menos un producto.");
      return;
    }
    if (formData.type === "cliente_especifico" && !formData.client_id) {
      toast.error("Si el tipo es 'Cliente Específico', debe seleccionar un cliente.");
      return;
    }
    const itemsToSave = items.map((item) => ({
      id: item.id || 0,
      priceable_id: item.priceable_id,
      priceable_type: "App\\Models\\Product",
      price: Number(item.price) || 0
    }));
    const payload = {
      ...formData,
      client_id: formData.type === "cliente_especifico" ? formData.client_id : null,
      items: itemsToSave,
      is_active: !!formData.is_active
    };
    delete payload.client_name;
    console.log("Saving Price List Payload:", payload);
    await saveItem(payload);
    navigate(getListReturnPath(priceListsModuleConfig.baseRoute));
  };
  if (loadingInitial && mode === "edit") return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
    lineNumber: 328,
    columnNumber: 49
  }, this);
  if (error && mode === "edit") return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error cargando datos: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
    lineNumber: 329,
    columnNumber: 40
  }, this);
  const inputStyle = "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const labelStyle = "block text-sm font-medium text-gray-700";
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? `Crear ${priceListsModuleConfig.moduleName}` : `Editando ${priceListsModuleConfig.moduleName}: ${formData.name || ""}` }, void 0, false, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 337,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Datos Principales" }, void 0, false, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 344,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 mt-4 md:grid-cols-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "name", className: `${labelStyle} required`, children: "Nombre" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 347,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", id: "name", name: "name", value: formData.name || "", onChange: handleHeaderChange, autoComplete: "off", className: inputStyle, required: true }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 348,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 346,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "type", className: `${labelStyle} required`, children: "Tipo" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 351,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("select", { id: "type", name: "type", value: formData.type || "general", onChange: handleHeaderChange, className: inputStyle, required: true, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "general", children: "General" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 353,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "cliente_especifico", children: "Cliente Específico" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 354,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 352,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 350,
            columnNumber: 25
          }, this),
          formData.type === "cliente_especifico" && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "client_id", className: `${labelStyle} required`, children: "Cliente" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 359,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: clientCodeInput,
                nameValue: formData.client_name || null,
                onCodeChange: setClientCodeInput,
                onCodeSubmit: handleClientCodeSubmit,
                onSearchClick: () => handleOpenModal("client"),
                onClearClick: () => handleClearSelection("client")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 360,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 358,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-3", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "description", className: labelStyle, children: "Descripción" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 371,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("textarea", { id: "description", name: "description", value: formData.description || "", onChange: handleHeaderChange, autoComplete: "off", className: inputStyle, rows: 3 }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 372,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 370,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "valid_from", className: `${labelStyle} required`, children: "Válido Desde" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 375,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", id: "valid_from", name: "valid_from", value: formData.valid_from || "", onChange: handleHeaderChange, autoComplete: "off", className: inputStyle, required: true }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 376,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 374,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "valid_to", className: labelStyle, children: "Válido Hasta" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 379,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", id: "valid_to", name: "valid_to", value: formData.valid_to || "", onChange: handleHeaderChange, autoComplete: "off", className: inputStyle }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 380,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 378,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "is_active", className: `${labelStyle} required`, children: "Activa" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 383,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("select", { id: "is_active", name: "is_active", value: formData.is_active ? "true" : "false", onChange: handleHeaderChange, className: inputStyle, required: true, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "true", children: "Sí" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 385,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "false", children: "No" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 386,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 384,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 382,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 345,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 342,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-6 mt-6 border-t", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Productos y Precios" }, void 0, false, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 395,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-3/5", children: "Producto" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 402,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900 w-1/5", children: "Precio" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 403,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6 w-1/5", children: "Acciones" }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 404,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 401,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 400,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
            items.map(
              (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
                  RelationalInput,
                  {
                    codeValue: productCodes[item.tempId] || "",
                    nameValue: item.product_name || null,
                    onCodeChange: (val) => setProductCodes((prev) => ({ ...prev, [item.tempId]: val })),
                    onCodeSubmit: () => handleProductCodeSubmit(item.tempId),
                    onSearchClick: () => handleOpenModal("item", item.tempId),
                    onClearClick: () => handleClearSelection("item", item.tempId)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                    lineNumber: 411,
                    columnNumber: 45
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                  lineNumber: 410,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: /* @__PURE__ */ jsxDEV(
                  DecimalInput,
                  {
                    step: "0.01",
                    value: item.price,
                    onChange: (num) => handlePriceChange(item.tempId, num),
                    className: `${inputStyle} text-right max-w-[150px] inline-block`,
                    placeholder: "0.00"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                    lineNumber: 421,
                    columnNumber: 45
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                  lineNumber: 420,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleRemoveItem(item.tempId),
                    className: "p-2 text-red-500 hover:text-red-700",
                    title: "Eliminar Ítem",
                    children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                      fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                      lineNumber: 432,
                      columnNumber: 49
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                    lineNumber: 430,
                    columnNumber: 45
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                  lineNumber: 429,
                  columnNumber: 41
                }, this)
              ] }, item.tempId, true, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 409,
                columnNumber: 17
              }, this)
            ),
            items.length === 0 && /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 3, className: "px-6 py-4 text-center text-sm text-gray-500", children: "No hay productos añadidos." }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 438,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
              lineNumber: 438,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 407,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 399,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 398,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleAddItem,
            className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700",
            children: [
              /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 445,
                columnNumber: 25
              }, this),
              " Añadir Producto"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 443,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 393,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 mt-6 border-t", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(priceListsModuleConfig.baseRoute)), className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
          lineNumber: 451,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleSave,
            disabled: saving,
            className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:opacity-50",
            children: [
              saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 456,
                columnNumber: 35
              }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
                lineNumber: 456,
                columnNumber: 89
              }, this),
              "Guardar Cambios"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
            lineNumber: 454,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 450,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
      lineNumber: 336,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: handleCloseModal,
        onSelect: handleSelectModal,
        config: modalConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 464,
        columnNumber: 7
      },
      this
    ),
    isProductModalOpen && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isProductModalOpen,
        onClose: handleCloseModal,
        onSelect: handleSelectModal,
        config: articulosModuleConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
        lineNumber: 475,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx",
    lineNumber: 335,
    columnNumber: 5
  }, this);
};
_s(ListasDePreciosFormPage, "9Lj1Er6jgDo57iGutbWZoeLfrPE=", false, function() {
  return [useParams, useNavigate, useCrudItem, useCrudItem];
});
_c = ListasDePreciosFormPage;
var _c;
$RefreshReg$(_c, "ListasDePreciosFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/lista_precios/pages/ListasPreciosFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb1RrRCxTQU8xQyxVQVAwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsVGxELFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxhQUFhQyxpQkFBaUI7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxXQUFXQyxRQUFRQyxlQUFlO0FBQ25ELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyw4QkFBa0U7QUFDM0UsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLHlCQUF5QjtBQU9sQyxNQUFNQyxhQUFnQztBQUFBLEVBQ2xDQyxJQUFJO0FBQUEsRUFBR0MsUUFBUTtBQUFBLEVBQUlDLGNBQWM7QUFBQSxFQUFHQyxnQkFBZ0I7QUFBQSxFQUNwREMsT0FBTztBQUFBLEVBQUdDLGNBQWM7QUFBQSxFQUFJQyxjQUFjO0FBQzlDO0FBRUEsTUFBTUMscUJBQXlDO0FBQUEsRUFDM0NDLE1BQU07QUFBQSxFQUFJQyxhQUFhO0FBQUEsRUFBSUMsTUFBTTtBQUFBLEVBQVdDLFdBQVc7QUFBQSxFQUN2REMsYUFBWSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUFHQyxVQUFVO0FBQUEsRUFDOURDLFdBQVc7QUFBQSxFQUFNQyxRQUFRQztBQUFBQSxFQUFXQyxPQUFPO0FBQy9DO0FBRU8sYUFBTUMsMEJBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFdEIsR0FBRyxJQUFJakIsVUFBMEI7QUFDekMsUUFBTXdDLFdBQVd6QyxZQUFZO0FBQzdCLFFBQU0wQyxPQUFPeEIsS0FBSyxTQUFTO0FBRTNCLFFBQU0sRUFBRXlCLE1BQU1DLGFBQWFDLFNBQVNDLGdCQUFnQkMsTUFBTSxJQUFJeEMsWUFBdUJDLHdCQUF3QlUsRUFBRTtBQUMvRyxRQUFNLEVBQUU4QixVQUFVSCxTQUFTSSxPQUFPLElBQUkxQyxZQUF1QkMsd0JBQXdCVSxFQUFFO0FBR3ZGLFFBQU0sQ0FBQ2dDLFVBQVVDLFdBQVcsSUFBSXJELFNBQTZCMkIsa0JBQWtCO0FBQy9FLFFBQU0sQ0FBQ2EsT0FBT2MsUUFBUSxJQUFJdEQsU0FBOEIsRUFBRTtBQUMxRCxRQUFNLENBQUN1RCxhQUFhQyxjQUFjLElBQUl4RCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDeUQsb0JBQW9CQyxxQkFBcUIsSUFBSTFELFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUMyRCxhQUFhQyxjQUFjLElBQUk1RCxTQUFjLElBQUk7QUFDeEQsUUFBTSxDQUFDNkQsZUFBZUMsZ0JBQWdCLElBQUk5RCxTQUErQixJQUFJO0FBQzdFLFFBQU0sQ0FBQytELG1CQUFtQkMsb0JBQW9CLElBQUloRSxTQUF3QixJQUFJO0FBRzlFLFFBQU0sQ0FBQ2lFLGlCQUFpQkMsa0JBQWtCLElBQUlsRSxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDbUUsY0FBY0MsZUFBZSxJQUFJcEUsU0FBaUMsQ0FBQyxDQUFDO0FBRzNFQyxZQUFVLE1BQU07QUFDWixRQUFJMkMsU0FBUyxVQUFVRSxhQUFhO0FBQ2hDLFlBQU11QixlQUFlO0FBQUEsUUFDakIsR0FBRzFDO0FBQUFBLFFBQ0gsR0FBR21CO0FBQUFBLFFBQ0hmLFdBQVdlLFlBQVlmLGFBQWE7QUFBQSxRQUNwQ0MsWUFBWWMsWUFBWWQsWUFBWUcsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsUUFDckRDLFVBQVVVLFlBQVlWLFVBQVVELE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLE1BQ3JEO0FBR0EsVUFBSVcsWUFBWVIsVUFBVTFCLHFCQUFxQjBELGtCQUFrQjtBQUM3RCxjQUFNLEVBQUVDLFVBQVUsSUFBSTNELHFCQUFxQjBEO0FBQzNDLFFBQUNELGFBQXFCRyxnQkFBaUIxQixZQUFZUixPQUFlaUMsU0FBUyxLQUFLO0FBQUEsTUFDcEY7QUFFQWxCLGtCQUFZZ0IsWUFBWTtBQUd4QixVQUFJQSxhQUFhRyxlQUFlO0FBQzVCTiwyQkFBbUJHLGFBQWFHLGFBQWE7QUFBQSxNQUNqRDtBQUVBLFlBQU1DLGlCQUF5QyxDQUFDO0FBQ2hELFlBQU1DLGNBQWM1QixZQUFZTixPQUFPbUMsSUFBSSxDQUFBOUIsU0FBUTtBQUMvQyxjQUFNeEIsU0FBU3VELE9BQU9DLFdBQVc7QUFDakNKLHVCQUFlcEQsTUFBTSxJQUFJd0IsS0FBS2lDLGtCQUFrQjtBQUNoRCxlQUFPO0FBQUEsVUFDSCxHQUFHakM7QUFBQUEsVUFDSHhCO0FBQUFBLFVBQ0FJLGNBQWNvQixLQUFLa0Msa0JBQWtCLFlBQVlsQyxLQUFLdkIsWUFBWTtBQUFBLFVBQ2xFSSxjQUFjbUIsS0FBS2lDLGtCQUFrQixRQUFRakMsS0FBS3ZCLFlBQVk7QUFBQSxRQUNsRTtBQUFBLE1BQ0osQ0FBQyxLQUFLO0FBRU5nQyxlQUFTb0IsV0FBVztBQUNwQk4sc0JBQWdCSyxjQUFjO0FBQUEsSUFDbEMsV0FBVzdCLFNBQVMsVUFBVTtBQUMxQlMsa0JBQVkxQixrQkFBa0I7QUFDOUIyQixlQUFTLEVBQUU7QUFDWFkseUJBQW1CLEVBQUU7QUFDckJFLHNCQUFnQixDQUFDLENBQUM7QUFBQSxJQUN0QjtBQUFBLEVBQ0osR0FBRyxDQUFDdEIsYUFBYUYsSUFBSSxDQUFDO0FBR3RCLFFBQU1vQyxxQkFBcUJBLENBQUNDLE1BQXFGO0FBQzdHLFVBQU0sRUFBRXJELE1BQU1zRCxPQUFPcEQsTUFBTXFELFFBQVEsSUFBSUYsRUFBRUc7QUFDekMsUUFBSUMsYUFBa0J2RCxTQUFTLGFBQWFxRCxVQUFVRDtBQUV0RCxRQUFJdEQsU0FBUyxZQUFheUQsY0FBYUgsVUFBVTtBQUNqRCxRQUFJdEQsU0FBUyxlQUFlc0QsVUFBVSxHQUFJRyxjQUFhO0FBRXZEaEMsZ0JBQVksQ0FBQWlDLFVBQVM7QUFBQSxNQUNqQixHQUFHQTtBQUFBQSxNQUNILENBQUMxRCxJQUFJLEdBQUd5RDtBQUFBQSxNQUNSLEdBQUl6RCxTQUFTLFVBQVVzRCxVQUFVLGFBQWEsRUFBRTdDLFdBQVcsTUFBTWtELGFBQWEsSUFBSWpELFFBQVFDLE9BQVU7QUFBQSxJQUN4RyxFQUFFO0FBQUEsRUFDTjtBQUdBLFFBQU1pRCxnQkFBZ0JBLE1BQU07QUFDeEIsVUFBTUMsUUFBUWIsT0FBT0MsV0FBVztBQUNoQ3ZCLGFBQVMsQ0FBQWdDLFNBQVEsQ0FBQyxHQUFHQSxNQUFNLEVBQUUsR0FBR25FLFlBQVlFLFFBQVFvRSxNQUFNLENBQUMsQ0FBQztBQUM1RHJCLG9CQUFnQixDQUFBa0IsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0csS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ3REO0FBRUEsUUFBTUMsbUJBQW1CQSxDQUFDckUsV0FBbUI7QUFDekNpQyxhQUFTLENBQUFnQyxTQUFRQSxLQUFLSyxPQUFPLENBQUE5QyxTQUFRQSxLQUFLeEIsV0FBV0EsTUFBTSxDQUFDO0FBQzVEK0Msb0JBQWdCLENBQUFrQixTQUFRO0FBQ3BCLFlBQU1NLFVBQVUsRUFBRSxHQUFHTixLQUFLO0FBQzFCLGFBQU9NLFFBQVF2RSxNQUFNO0FBQ3JCLGFBQU91RTtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTUMsb0JBQW9CQSxDQUFDeEUsUUFBZ0J5RSxhQUE4QjtBQUNyRXhDLGFBQVMsQ0FBQWdDLFNBQVFBLEtBQUtYO0FBQUFBLE1BQUksQ0FBQTlCLFNBQ3RCQSxLQUFLeEIsV0FBV0EsU0FBUyxFQUFFLEdBQUd3QixNQUFNckIsT0FBT3NFLFNBQVMsSUFBSWpEO0FBQUFBLElBQzVELENBQUM7QUFBQSxFQUNMO0FBR0EsUUFBTWtELGtCQUFrQkEsQ0FBQ1gsUUFBdUJZLGVBQXdCO0FBQ3BFbEMscUJBQWlCc0IsTUFBTTtBQUN2QixRQUFJQSxXQUFXLFVBQVU7QUFDckJ4QixxQkFBZWhELG9CQUFvQjtBQUNuQzRDLHFCQUFlLElBQUk7QUFBQSxJQUN2QixXQUFXNEIsV0FBVyxRQUFRO0FBQzFCcEIsMkJBQXFCZ0MsY0FBYyxJQUFJO0FBRXZDdEMsNEJBQXNCLElBQUk7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFHQSxRQUFNdUMsbUJBQW1CQSxNQUFNO0FBQzNCekMsbUJBQWUsS0FBSztBQUNwQkUsMEJBQXNCLEtBQUs7QUFDM0JJLHFCQUFpQixJQUFJO0FBQ3JCRSx5QkFBcUIsSUFBSTtBQUN6QkosbUJBQWUsSUFBSTtBQUFBLEVBQ3ZCO0FBR0EsUUFBTXNDLHlCQUF5QixZQUFZO0FBQ3ZDLFFBQUksQ0FBQ2pDLGdCQUFnQmtDLEtBQUssRUFBRztBQUU3QixRQUFJO0FBQ0EsWUFBTUMsUUFBUSxNQUFNbkY7QUFBQUEsUUFDaEJMLHFCQUFxQnlGO0FBQUFBLFFBQ3JCLENBQUMsRUFBRUMsV0FBVyxpQkFBaUJwQixPQUFPakIsZ0JBQWdCLENBQUM7QUFBQSxNQUMzRDtBQUVBLFVBQUltQyxPQUFPO0FBQ1AvQyxvQkFBWSxDQUFBaUMsVUFBUztBQUFBLFVBQ2pCLEdBQUdBO0FBQUFBLFVBQ0hqRCxXQUFXK0QsTUFBTWhGO0FBQUFBLFVBQ2pCbUUsYUFBYWEsTUFBTXhFO0FBQUFBLFVBQ25CNEMsZUFBZTRCLE1BQU01QixpQkFBaUI7QUFBQSxVQUN0Q2xDLFFBQVE4RDtBQUFBQSxRQUNaLEVBQUU7QUFDRmxDLDJCQUFtQmtDLE1BQU01QixpQkFBaUIrQixPQUFPSCxNQUFNaEYsRUFBRSxDQUFDO0FBQzFEaEIsY0FBTW9HLFFBQVEsdUJBQXVCSixNQUFNeEUsSUFBSSxFQUFFO0FBQUEsTUFDckQsT0FBTztBQUNIeEIsY0FBTXFHLFFBQVEsdUNBQXVDO0FBQ3JEcEQsb0JBQVksQ0FBQWlDLFVBQVMsRUFBRSxHQUFHQSxNQUFNakQsV0FBVyxNQUFNa0QsYUFBYWhELFFBQVdpQyxlQUFlakMsUUFBV0QsUUFBUUMsT0FBVSxFQUFFO0FBQUEsTUFDM0g7QUFBQSxJQUNKLFNBQVNVLFFBQU87QUFDWjdDLFlBQU02QyxNQUFNLHFDQUFxQztBQUNqRHlELGNBQVF6RCxNQUFNQSxNQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNKO0FBR0EsUUFBTTBELDBCQUEwQixPQUFPdEYsV0FBbUI7QUFDdEQsVUFBTXVGLGVBQWV6QyxhQUFhOUMsTUFBTSxHQUFHOEUsS0FBSztBQUNoRCxRQUFJLENBQUNTLGFBQWM7QUFFbkIsUUFBSTtBQUVBLFlBQU1SLFFBQVEsTUFBTW5GO0FBQUFBLFFBQ2hCTixzQkFBc0IwRjtBQUFBQSxRQUN0QixDQUFDLEVBQUVDLFdBQVcsT0FBT3BCLE9BQU8wQixhQUFhLENBQUM7QUFBQSxNQUM5QztBQUVBLFVBQUlSLE9BQU87QUFDUDlDLGlCQUFTLENBQUFnQyxTQUFRQSxLQUFLWDtBQUFBQSxVQUFJLENBQUE5QixTQUN0QkEsS0FBS3hCLFdBQVdBLFNBQ1Y7QUFBQSxZQUNFLEdBQUd3QjtBQUFBQSxZQUNIdkIsY0FBYzhFLE1BQU1oRjtBQUFBQSxZQUNwQkssY0FBYzJFLE1BQU14RTtBQUFBQSxZQUNwQkYsY0FBYzBFLE1BQU1TLE9BQU9ULE1BQU1VLFFBQVE7QUFBQSxZQUN6Q3RGLE9BQU80RSxNQUFNVyxjQUFjO0FBQUEsVUFDL0IsSUFDRWxFO0FBQUFBLFFBQ1YsQ0FBQztBQUNEdUIsd0JBQWdCLENBQUFrQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDakUsTUFBTSxHQUFHK0UsTUFBTVMsT0FBT1QsTUFBTVUsUUFBUVAsT0FBT0gsTUFBTWhGLEVBQUUsRUFBRSxFQUFFO0FBQzVGaEIsY0FBTW9HLFFBQVEsd0JBQXdCSixNQUFNeEUsSUFBSSxFQUFFO0FBQUEsTUFDdEQsT0FBTztBQUNIeEIsY0FBTXFHLFFBQVEsd0NBQXdDO0FBQ3REbkQsaUJBQVMsQ0FBQWdDLFNBQVFBLEtBQUtYO0FBQUFBLFVBQUksQ0FBQTlCLFNBQ3RCQSxLQUFLeEIsV0FBV0EsU0FDVixFQUFFLEdBQUd3QixNQUFNdkIsY0FBYyxHQUFHSSxjQUFjLElBQUlELGNBQWMsSUFBSUQsT0FBTyxFQUFFLElBQ3pFcUI7QUFBQUEsUUFDVixDQUFDO0FBQUEsTUFDTDtBQUFBLElBQ0osU0FBU0ksUUFBTztBQUNaN0MsWUFBTTZDLE1BQU0sc0NBQXNDO0FBQ2xEeUQsY0FBUXpELE1BQU1BLE1BQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNK0Qsb0JBQW9CQSxDQUFDQyxpQkFBc0I7QUFDN0MsUUFBSSxDQUFDcEQsY0FBZTtBQUVwQixRQUFJQSxrQkFBa0IsVUFBVTtBQUM1QlIsa0JBQVksQ0FBQWlDLFVBQVM7QUFBQSxRQUNqQixHQUFHQTtBQUFBQSxRQUNIakQsV0FBVzRFLGFBQWE3RjtBQUFBQSxRQUN4Qm1FLGFBQWEwQixhQUFhckY7QUFBQUEsUUFDMUI0QyxlQUFleUMsYUFBYXpDLGlCQUFpQjtBQUFBLFFBQzdDbEMsUUFBUTJFO0FBQUFBLE1BQ1osRUFBRTtBQUNGL0MseUJBQW1CK0MsYUFBYXpDLGlCQUFpQitCLE9BQU9VLGFBQWE3RixFQUFFLENBQUM7QUFBQSxJQUM1RSxXQUFXeUMsa0JBQWtCLFVBQVVFLG1CQUFtQjtBQUN0RFQsZUFBUyxDQUFBNEQsY0FBYUEsVUFBVXZDLElBQUksQ0FBQTlCLFNBQVE7QUFDeEMsWUFBSUEsS0FBS3hCLFdBQVcwQyxtQkFBbUI7QUFDbkMsaUJBQU87QUFBQSxZQUNILEdBQUdsQjtBQUFBQSxZQUNIdkIsY0FBYzJGLGFBQWE3RjtBQUFBQSxZQUMzQkssY0FBY3dGLGFBQWFyRjtBQUFBQSxZQUMzQkYsY0FBY3VGLGFBQWFKLE9BQU9JLGFBQWFILFFBQVE7QUFBQSxZQUN2RHRGLE9BQU95RixhQUFhRixjQUFjO0FBQUEsVUFDdEM7QUFBQSxRQUNKO0FBQ0EsZUFBT2xFO0FBQUFBLE1BQ1gsQ0FBQyxDQUFDO0FBQ0Z1QixzQkFBZ0IsQ0FBQWtCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUN2QixpQkFBaUIsR0FBR2tELGFBQWFKLE9BQU9JLGFBQWFILFFBQVFQLE9BQU9VLGFBQWE3RixFQUFFLEVBQUUsRUFBRTtBQUFBLElBQ2hJO0FBRUE2RSxxQkFBaUI7QUFBQSxFQUNyQjtBQUdBLFFBQU1rQix1QkFBdUJBLENBQUMvQixRQUF1QlksZUFBd0I7QUFDekUsUUFBSVosV0FBVyxVQUFVO0FBQ3JCL0Isa0JBQVksQ0FBQWlDLFVBQVMsRUFBRSxHQUFHQSxNQUFNakQsV0FBVyxNQUFNa0QsYUFBYSxJQUFJZixlQUFlakMsUUFBV0QsUUFBUUMsT0FBVSxFQUFFO0FBQ2hIMkIseUJBQW1CLEVBQUU7QUFBQSxJQUN6QixXQUFXa0IsV0FBVyxVQUFVWSxZQUFZO0FBQ3hDMUMsZUFBUyxDQUFBZ0MsU0FBUUEsS0FBS1gsSUFBSSxDQUFBOUIsU0FBUTtBQUM5QixZQUFJQSxLQUFLeEIsV0FBVzJFLFlBQVk7QUFDNUIsaUJBQU8sRUFBRSxHQUFHbkQsTUFBTXZCLGNBQWMsR0FBR0ksY0FBYyxJQUFJRCxjQUFjLElBQUlELE9BQU8sRUFBRTtBQUFBLFFBQ3BGO0FBQ0EsZUFBT3FCO0FBQUFBLE1BQ1gsQ0FBQyxDQUFDO0FBQ0Z1QixzQkFBZ0IsQ0FBQWtCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNVLFVBQVUsR0FBRyxHQUFHLEVBQUU7QUFBQSxJQUMzRDtBQUFBLEVBQ0o7QUFHQSxRQUFNb0IsYUFBYSxZQUFZO0FBQzNCLFFBQUk1RSxNQUFNNkUsV0FBVyxHQUFHO0FBQ3BCakgsWUFBTTZDLE1BQU0sbUNBQW1DO0FBQUc7QUFBQSxJQUN0RDtBQUNBLFFBQUlHLFNBQVN0QixTQUFTLHdCQUF3QixDQUFDc0IsU0FBU2YsV0FBVztBQUMvRGpDLFlBQU02QyxNQUFNLGtFQUFrRTtBQUFHO0FBQUEsSUFDckY7QUFFQSxVQUFNcUUsY0FBYzlFLE1BQU1tQyxJQUFJLENBQUE5QixVQUFTO0FBQUEsTUFDbkN6QixJQUFJeUIsS0FBS3pCLE1BQU07QUFBQSxNQUNmRSxjQUFjdUIsS0FBS3ZCO0FBQUFBLE1BQ25CQyxnQkFBZ0I7QUFBQSxNQUNoQkMsT0FBTytGLE9BQU8xRSxLQUFLckIsS0FBSyxLQUFLO0FBQUEsSUFDakMsRUFBRTtBQUVGLFVBQU1nRyxVQUE4QjtBQUFBLE1BQ2hDLEdBQUdwRTtBQUFBQSxNQUNIZixXQUFXZSxTQUFTdEIsU0FBUyx1QkFBdUJzQixTQUFTZixZQUFZO0FBQUEsTUFDekVHLE9BQU84RTtBQUFBQSxNQUNQdkYsV0FBVyxDQUFDLENBQUNxQixTQUFTckI7QUFBQUEsSUFDMUI7QUFDQSxXQUFPeUYsUUFBUWpDO0FBR2ZtQixZQUFRZSxJQUFJLDhCQUE4QkQsT0FBTztBQUNqRCxVQUFNdEUsU0FBU3NFLE9BQW9CO0FBQ25DN0UsYUFBU3pCLGtCQUFrQlIsdUJBQXVCZ0gsU0FBUyxDQUFDO0FBQUEsRUFDaEU7QUFHQSxNQUFJMUUsa0JBQWtCSixTQUFTLE9BQVEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDN0QsTUFBSUssU0FBU0wsU0FBUyxPQUFRLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUF1Qks7QUFBQUEsT0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxRTtBQUUxRyxRQUFNMEUsYUFBYTtBQUNuQixRQUFNQyxhQUFhO0FBRW5CLFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0RBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQ1RoRixtQkFBUyxXQUFXLFNBQVNsQyx1QkFBdUJtSCxVQUFVLEtBQUssWUFBWW5ILHVCQUF1Qm1ILFVBQVUsS0FBS3pFLFNBQVN4QixRQUFRLEVBQUUsTUFEN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBRVg7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLGlDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFDbkUsdUJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsbUNBQUMsV0FBTSxTQUFRLFFBQU8sV0FBVyxHQUFHZ0csVUFBVSxhQUFhLHNCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLElBQUcsUUFBTyxNQUFLLFFBQU8sT0FBT3hFLFNBQVN4QixRQUFRLElBQUksVUFBVW9ELG9CQUFvQixjQUFhLE9BQU0sV0FBVzJDLFlBQVksVUFBUSxRQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSjtBQUFBLGVBRnpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFNBQVEsUUFBTyxXQUFXLEdBQUdDLFVBQVUsYUFBYSxvQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUMvRCx1QkFBQyxZQUFPLElBQUcsUUFBTyxNQUFLLFFBQU8sT0FBT3hFLFNBQVN0QixRQUFRLFdBQVcsVUFBVWtELG9CQUFvQixXQUFXMkMsWUFBWSxVQUFRLE1BQzFIO0FBQUEscUNBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsWUFBTyxPQUFNLHNCQUFxQixrQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0N2RSxTQUFTdEIsU0FBUyx3QkFDZix1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxTQUFRLGFBQVksV0FBVyxHQUFHOEYsVUFBVSxhQUFhLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLFlBQ3ZFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBVzNEO0FBQUFBLGdCQUNYLFdBQVdiLFNBQVNtQyxlQUFlO0FBQUEsZ0JBQ25DLGNBQWNyQjtBQUFBQSxnQkFDZCxjQUFjZ0M7QUFBQUEsZ0JBQ2QsZUFBZSxNQUFNSCxnQkFBZ0IsUUFBUTtBQUFBLGdCQUM3QyxjQUFjLE1BQU1vQixxQkFBcUIsUUFBUTtBQUFBO0FBQUEsY0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXVEO0FBQUEsZUFSM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUosdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsbUNBQUMsV0FBTSxTQUFRLGVBQWMsV0FBV1MsWUFBWSwyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUMvRCx1QkFBQyxjQUFTLElBQUcsZUFBYyxNQUFLLGVBQWMsT0FBT3hFLFNBQVN2QixlQUFlLElBQUksVUFBVW1ELG9CQUFvQixjQUFhLE9BQU0sV0FBVzJDLFlBQVksTUFBTSxLQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSztBQUFBLGVBRnJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFNBQVEsY0FBYSxXQUFXLEdBQUdDLFVBQVUsYUFBYSw0QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxXQUFNLE1BQUssUUFBTyxJQUFHLGNBQWEsTUFBSyxjQUFhLE9BQU94RSxTQUFTcEIsY0FBYyxJQUFJLFVBQVVnRCxvQkFBb0IsY0FBYSxPQUFNLFdBQVcyQyxZQUFZLFVBQVEsUUFBdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUs7QUFBQSxlQUYzSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxTQUFRLFlBQVcsV0FBV0MsWUFBWSw0QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUM3RCx1QkFBQyxXQUFNLE1BQUssUUFBTyxJQUFHLFlBQVcsTUFBSyxZQUFXLE9BQU94RSxTQUFTaEIsWUFBWSxJQUFJLFVBQVU0QyxvQkFBb0IsY0FBYSxPQUFNLFdBQVcyQyxjQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3SjtBQUFBLGVBRjVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFNBQVEsYUFBWSxXQUFXLEdBQUdDLFVBQVUsYUFBYSxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RSx1QkFBQyxZQUFPLElBQUcsYUFBWSxNQUFLLGFBQVksT0FBT3hFLFNBQVNyQixZQUFZLFNBQVMsU0FBUyxVQUFVaUQsb0JBQW9CLFdBQVcyQyxZQUFZLFVBQVEsTUFDL0k7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sUUFBTyxrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUN2Qix1QkFBQyxZQUFPLE9BQU0sU0FBUSxrQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0I7QUFBQSxpQkFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBM0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxXQS9DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0RBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsc0JBRVg7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0RBQWtELG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGdGQUErRSx3QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUc7QUFBQSxZQUNyRyx1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHNCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RjtBQUFBLFlBQ3ZGLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMEMsd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFIcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWm5GO0FBQUFBLGtCQUFNbUM7QUFBQUEsY0FBSSxDQUFDOUIsU0FDUix1QkFBQyxRQUNHO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhDQUNWO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLFdBQVdzQixhQUFhdEIsS0FBS3hCLE1BQU0sS0FBSztBQUFBLG9CQUN4QyxXQUFXd0IsS0FBS3BCLGdCQUFnQjtBQUFBLG9CQUNoQyxjQUFjLENBQUNxRyxRQUFRMUQsZ0JBQWdCLENBQUFrQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDekMsS0FBS3hCLE1BQU0sR0FBR3lHLElBQUksRUFBRTtBQUFBLG9CQUNoRixjQUFjLE1BQU1uQix3QkFBd0I5RCxLQUFLeEIsTUFBTTtBQUFBLG9CQUN2RCxlQUFlLE1BQU0wRSxnQkFBZ0IsUUFBUWxELEtBQUt4QixNQUFNO0FBQUEsb0JBQ3hELGNBQWMsTUFBTThGLHFCQUFxQixRQUFRdEUsS0FBS3hCLE1BQU07QUFBQTtBQUFBLGtCQU5oRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTWtFLEtBUHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1Y7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLE9BQU93QixLQUFLckI7QUFBQUEsb0JBQ1osVUFBVSxDQUFBdUcsUUFBT2xDLGtCQUFrQmhELEtBQUt4QixRQUFRMEcsR0FBRztBQUFBLG9CQUNuRCxXQUFXLEdBQUdKLFVBQVU7QUFBQSxvQkFDeEIsYUFBWTtBQUFBO0FBQUEsa0JBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLc0IsS0FOMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxxQ0FDVjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFBTyxNQUFLO0FBQUEsb0JBQVMsU0FBUyxNQUFNakMsaUJBQWlCN0MsS0FBS3hCLE1BQU07QUFBQSxvQkFDN0QsV0FBVTtBQUFBLG9CQUFzQyxPQUFNO0FBQUEsb0JBQ3RELGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBUTtBQUFBO0FBQUEsa0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQXpCS3dCLEtBQUt4QixRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsWUFDSDtBQUFBLFlBQ0FtQixNQUFNNkUsV0FBVyxLQUNkLHVCQUFDLFFBQUcsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSwrQ0FBOEMsMENBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJHO0FBQUEsZUEvQm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsYUF6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQSxLQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNENBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sTUFBSztBQUFBLFlBQVMsU0FBUzdCO0FBQUFBLFlBQzNCLFdBQVU7QUFBQSxZQUNWO0FBQUEscUNBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQUc7QUFBQTtBQUFBO0FBQUEsVUFGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR0E7QUFBQSxXQXJESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0RBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU03QyxTQUFTekIsa0JBQWtCUix1QkFBdUJnSCxTQUFTLENBQUMsR0FBRyxXQUFVLHFIQUFtSCx3QkFBak87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sTUFBSztBQUFBLFlBQVMsU0FBU047QUFBQUEsWUFBWSxVQUFVakU7QUFBQUEsWUFDakQsV0FBVTtBQUFBLFlBQ1RBO0FBQUFBLHVCQUFTLHVCQUFDLGFBQVUsV0FBVSwrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0QsSUFBTSx1QkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQSxVQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJQTtBQUFBLFdBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0EzSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRIQTtBQUFBLElBR0NJLGVBQWVJLGVBQ1o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVFKO0FBQUFBLFFBQ1IsU0FBUzBDO0FBQUFBLFFBQ1QsVUFBVWU7QUFBQUEsUUFDVixRQUFRckQ7QUFBQUE7QUFBQUEsTUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJd0I7QUFBQSxJQU0zQkYsc0JBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVFBO0FBQUFBLFFBQ1IsU0FBU3dDO0FBQUFBLFFBQ1QsVUFBVWU7QUFBQUEsUUFDVixRQUFRckc7QUFBQUE7QUFBQUEsTUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJbUM7QUFBQSxPQWhKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1KQTtBQUVSO0FBQUUrQixHQS9hV0QseUJBQXVCO0FBQUEsVUFDakJ0QyxXQUNFRCxhQUc2Q08sYUFDeEJBLFdBQVc7QUFBQTtBQUFBdUgsS0FOeEN2RjtBQUF1QixJQUFBdUY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ0b2FzdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhUGx1cyIsIkZhVHJhc2giLCJ1c2VDcnVkSXRlbSIsInByaWNlTGlzdHNNb2R1bGVDb25maWciLCJhcnRpY3Vsb3NNb2R1bGVDb25maWciLCJjbGllbnRlc01vZHVsZUNvbmZpZyIsIlJlbGF0aW9uYWxJbnB1dCIsIkRlY2ltYWxJbnB1dCIsIlNlYXJjaE1vZGFsIiwiTG9hZGluZ1NwaW5uZXIiLCJzZWFyY2hCeUZpZWxkIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJFTVBUWV9JVEVNIiwiaWQiLCJ0ZW1wSWQiLCJwcmljZWFibGVfaWQiLCJwcmljZWFibGVfdHlwZSIsInByaWNlIiwicHJvZHVjdF9uYW1lIiwicHJvZHVjdF9jb2RlIiwiZGVmYXVsdEluaXRpYWxEYXRhIiwibmFtZSIsImRlc2NyaXB0aW9uIiwidHlwZSIsImlzX2FjdGl2ZSIsInZhbGlkX2Zyb20iLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInZhbGlkX3RvIiwiY2xpZW50X2lkIiwiY2xpZW50IiwidW5kZWZpbmVkIiwiaXRlbXMiLCJMaXN0YXNEZVByZWNpb3NGb3JtUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJtb2RlIiwiaXRlbSIsImluaXRpYWxEYXRhIiwibG9hZGluZyIsImxvYWRpbmdJbml0aWFsIiwiZXJyb3IiLCJzYXZlSXRlbSIsInNhdmluZyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJzZXRJdGVtcyIsImlzTW9kYWxPcGVuIiwic2V0SXNNb2RhbE9wZW4iLCJpc1Byb2R1Y3RNb2RhbE9wZW4iLCJzZXRJc1Byb2R1Y3RNb2RhbE9wZW4iLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJlZGl0aW5nSXRlbVRlbXBJZCIsInNldEVkaXRpbmdJdGVtVGVtcElkIiwiY2xpZW50Q29kZUlucHV0Iiwic2V0Q2xpZW50Q29kZUlucHV0IiwicHJvZHVjdENvZGVzIiwic2V0UHJvZHVjdENvZGVzIiwiaHlkcmF0ZWREYXRhIiwicmVsYXRpb25hbEZpZWxkcyIsImNvZGVGaWVsZCIsImN1c3RvbWVyX2NvZGUiLCJpdGVtc1dpdGhDb2RlcyIsImxvYWRlZEl0ZW1zIiwibWFwIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInByaWNlYWJsZV9jb2RlIiwicHJpY2VhYmxlX25hbWUiLCJoYW5kbGVIZWFkZXJDaGFuZ2UiLCJlIiwidmFsdWUiLCJjaGVja2VkIiwidGFyZ2V0IiwiZmluYWxWYWx1ZSIsInByZXYiLCJjbGllbnRfbmFtZSIsImhhbmRsZUFkZEl0ZW0iLCJuZXdJZCIsImhhbmRsZVJlbW92ZUl0ZW0iLCJmaWx0ZXIiLCJ1cGRhdGVkIiwiaGFuZGxlUHJpY2VDaGFuZ2UiLCJuZXdQcmljZSIsImhhbmRsZU9wZW5Nb2RhbCIsIml0ZW1UZW1wSWQiLCJoYW5kbGVDbG9zZU1vZGFsIiwiaGFuZGxlQ2xpZW50Q29kZVN1Ym1pdCIsInRyaW0iLCJmb3VuZCIsImVuZHBvaW50IiwiZmllbGROYW1lIiwiU3RyaW5nIiwic3VjY2VzcyIsIndhcm5pbmciLCJjb25zb2xlIiwiaGFuZGxlUHJvZHVjdENvZGVTdWJtaXQiLCJjb2RlVG9TZWFyY2giLCJza3UiLCJjb2RlIiwic2FsZV9wcmljZSIsImhhbmRsZVNlbGVjdE1vZGFsIiwic2VsZWN0ZWRJdGVtIiwicHJldkl0ZW1zIiwiaGFuZGxlQ2xlYXJTZWxlY3Rpb24iLCJoYW5kbGVTYXZlIiwibGVuZ3RoIiwiaXRlbXNUb1NhdmUiLCJOdW1iZXIiLCJwYXlsb2FkIiwibG9nIiwiYmFzZVJvdXRlIiwiaW5wdXRTdHlsZSIsImxhYmVsU3R5bGUiLCJtb2R1bGVOYW1lIiwidmFsIiwibnVtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGlzdGFzUHJlY2lvc0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG4vLyBzcmMvbW9kdWxlcy9saXN0YXNfZGVfcHJlY2lvcy9wYWdlcy9MaXN0YXNQcmVjaW9zRm9ybVBhZ2UudHN4XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNhdmUsIEZhU3Bpbm5lciwgRmFQbHVzLCBGYVRyYXNoIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBwcmljZUxpc3RzTW9kdWxlQ29uZmlnLCB0eXBlIFByaWNlTGlzdCwgdHlwZSBQcmljZUxpc3RJdGVtIH0gZnJvbSAnLi4vbGlzdGFzX3ByZWNpb3MuY29uZmlnJzsgLy8gQ29ycmVnaWRvIHBhdGhcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJztcbmltcG9ydCB7IGNsaWVudGVzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vY2xpZW50ZXMvY2xpZW50ZXMuY29uZmlnJzsgLy8gTmVjZXNpdGFtb3MgQ2xpZW50ZSB5IGNvbmZpZ1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLy8gVGlwb3NcbnR5cGUgRm9ybVByaWNlTGlzdEl0ZW0gPSBQcmljZUxpc3RJdGVtICYgeyB0ZW1wSWQ6IHN0cmluZzsgcHJvZHVjdF9uYW1lPzogc3RyaW5nOyBwcm9kdWN0X2NvZGU/OiBzdHJpbmc7IH07XG50eXBlIEVkaXRpbmdUYXJnZXQgPSAnY2xpZW50JyB8ICdpdGVtJztcblxuLy8gQ29uc3RhbnRlc1xuY29uc3QgRU1QVFlfSVRFTTogRm9ybVByaWNlTGlzdEl0ZW0gPSB7XG4gICAgaWQ6IDAsIHRlbXBJZDogJycsIHByaWNlYWJsZV9pZDogMCwgcHJpY2VhYmxlX3R5cGU6IFwiQXBwXFxcXE1vZGVsc1xcXFxQcm9kdWN0XCIsXG4gICAgcHJpY2U6IDAsIHByb2R1Y3RfbmFtZTogJycsIHByb2R1Y3RfY29kZTogJycsXG59O1xuXG5jb25zdCBkZWZhdWx0SW5pdGlhbERhdGE6IFBhcnRpYWw8UHJpY2VMaXN0PiA9IHtcbiAgICBuYW1lOiAnJywgZGVzY3JpcHRpb246ICcnLCB0eXBlOiAnZ2VuZXJhbCcsIGlzX2FjdGl2ZTogdHJ1ZSxcbiAgICB2YWxpZF9mcm9tOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSwgdmFsaWRfdG86IG51bGwsXG4gICAgY2xpZW50X2lkOiBudWxsLCBjbGllbnQ6IHVuZGVmaW5lZCwgaXRlbXM6IFtdXG59O1xuXG5leHBvcnQgY29uc3QgTGlzdGFzRGVQcmVjaW9zRm9ybVBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBtb2RlID0gaWQgPyAnZWRpdCcgOiAnY3JlYXRlJztcblxuICAgIGNvbnN0IHsgaXRlbTogaW5pdGlhbERhdGEsIGxvYWRpbmc6IGxvYWRpbmdJbml0aWFsLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08UHJpY2VMaXN0PihwcmljZUxpc3RzTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSwgbG9hZGluZzogc2F2aW5nIH0gPSB1c2VDcnVkSXRlbTxQcmljZUxpc3Q+KHByaWNlTGlzdHNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIC8vIC0tLSBFU1RBRE9TIC0tLVxuICAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8UGFydGlhbDxQcmljZUxpc3Q+PihkZWZhdWx0SW5pdGlhbERhdGEpO1xuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8Rm9ybVByaWNlTGlzdEl0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpOyAvLyBNb2RhbCBnZW7DqXJpY28gKGNsaWVudGUpXG4gICAgY29uc3QgW2lzUHJvZHVjdE1vZGFsT3Blbiwgc2V0SXNQcm9kdWN0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTsgLy8gTW9kYWwgZXNwZWPDrWZpY28gcHJvZHVjdG9cbiAgICBjb25zdCBbbW9kYWxDb25maWcsIHNldE1vZGFsQ29uZmlnXSA9IHVzZVN0YXRlPGFueT4obnVsbCk7XG4gICAgY29uc3QgW2VkaXRpbmdUYXJnZXQsIHNldEVkaXRpbmdUYXJnZXRdID0gdXNlU3RhdGU8RWRpdGluZ1RhcmdldCB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0aW5nSXRlbVRlbXBJZCwgc2V0RWRpdGluZ0l0ZW1UZW1wSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgICAvLyDinIUgRXN0YWRvcyBwYXJhIGPDs2RpZ29zIChsbyBxdWUgZWwgdXN1YXJpbyBlc2NyaWJlKVxuICAgIGNvbnN0IFtjbGllbnRDb2RlSW5wdXQsIHNldENsaWVudENvZGVJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3Byb2R1Y3RDb2Rlcywgc2V0UHJvZHVjdENvZGVzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcblxuICAgIC8vIEVmZWN0byBwYXJhIGNhcmdhciBkYXRvcyBlbiBtb2RvICdlZGl0J1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChtb2RlID09PSAnZWRpdCcgJiYgaW5pdGlhbERhdGEpIHtcbiAgICAgICAgICAgIGNvbnN0IGh5ZHJhdGVkRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0SW5pdGlhbERhdGEsXG4gICAgICAgICAgICAgICAgLi4uaW5pdGlhbERhdGEsXG4gICAgICAgICAgICAgICAgaXNfYWN0aXZlOiBpbml0aWFsRGF0YS5pc19hY3RpdmUgPz8gdHJ1ZSxcbiAgICAgICAgICAgICAgICB2YWxpZF9mcm9tOiBpbml0aWFsRGF0YS52YWxpZF9mcm9tPy5zcGxpdCgnVCcpWzBdIHx8ICcnLFxuICAgICAgICAgICAgICAgIHZhbGlkX3RvOiBpbml0aWFsRGF0YS52YWxpZF90bz8uc3BsaXQoJ1QnKVswXSB8fCBudWxsLFxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gUG9ibGFyIGN1c3RvbWVyX2NvZGUgZGVzZGUgZWwgb2JqZXRvIGNsaWVudCBzaSBleGlzdGVcbiAgICAgICAgICAgIGlmIChpbml0aWFsRGF0YS5jbGllbnQgJiYgY2xpZW50ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgY29kZUZpZWxkIH0gPSBjbGllbnRlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuICAgICAgICAgICAgICAgIChoeWRyYXRlZERhdGEgYXMgYW55KS5jdXN0b21lcl9jb2RlID0gKGluaXRpYWxEYXRhLmNsaWVudCBhcyBhbnkpW2NvZGVGaWVsZF0gfHwgJyc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGh5ZHJhdGVkRGF0YSk7XG5cbiAgICAgICAgICAgIC8vIEluaWNpYWxpemFyIGPDs2RpZ28gZGVsIGNsaWVudGUgc2kgZXhpc3RlXG4gICAgICAgICAgICBpZiAoaHlkcmF0ZWREYXRhLmN1c3RvbWVyX2NvZGUpIHtcbiAgICAgICAgICAgICAgICBzZXRDbGllbnRDb2RlSW5wdXQoaHlkcmF0ZWREYXRhLmN1c3RvbWVyX2NvZGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBpdGVtc1dpdGhDb2RlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgICAgICAgICAgY29uc3QgbG9hZGVkSXRlbXMgPSBpbml0aWFsRGF0YS5pdGVtcz8ubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRlbXBJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgICAgICAgICAgICAgaXRlbXNXaXRoQ29kZXNbdGVtcElkXSA9IGl0ZW0ucHJpY2VhYmxlX2NvZGUgfHwgJyc7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkLFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X25hbWU6IGl0ZW0ucHJpY2VhYmxlX25hbWUgfHwgYFByb2R1Y3RvICR7aXRlbS5wcmljZWFibGVfaWR9YCxcbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9jb2RlOiBpdGVtLnByaWNlYWJsZV9jb2RlIHx8IGBDT0RFLSR7aXRlbS5wcmljZWFibGVfaWR9YCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSkgfHwgW107XG5cbiAgICAgICAgICAgIHNldEl0ZW1zKGxvYWRlZEl0ZW1zKTtcbiAgICAgICAgICAgIHNldFByb2R1Y3RDb2RlcyhpdGVtc1dpdGhDb2Rlcyk7XG4gICAgICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gJ2NyZWF0ZScpIHtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhbXSk7XG4gICAgICAgICAgICBzZXRDbGllbnRDb2RlSW5wdXQoJycpO1xuICAgICAgICAgICAgc2V0UHJvZHVjdENvZGVzKHt9KTtcbiAgICAgICAgfVxuICAgIH0sIFtpbml0aWFsRGF0YSwgbW9kZV0pO1xuXG4gICAgLy8gLS0tIE1BTkVKQURPUkVTIERFIENBQkVDRVJBIC0tLVxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudCB8IEhUTUxTZWxlY3RFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB7IG5hbWUsIHZhbHVlLCB0eXBlLCBjaGVja2VkIH0gPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50OyAvLyBUeXBlIGFzc2VydGlvbiBwYXJhICdjaGVja2VkJ1xuICAgICAgICBsZXQgZmluYWxWYWx1ZTogYW55ID0gdHlwZSA9PT0gJ2NoZWNrYm94JyA/IGNoZWNrZWQgOiB2YWx1ZTtcblxuICAgICAgICBpZiAobmFtZSA9PT0gJ2lzX2FjdGl2ZScpIGZpbmFsVmFsdWUgPSB2YWx1ZSA9PT0gJ3RydWUnO1xuICAgICAgICBpZiAobmFtZSA9PT0gJ2NsaWVudF9pZCcgJiYgdmFsdWUgPT09ICcnKSBmaW5hbFZhbHVlID0gbnVsbDtcblxuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgW25hbWVdOiBmaW5hbFZhbHVlLFxuICAgICAgICAgICAgLi4uKG5hbWUgPT09ICd0eXBlJyAmJiB2YWx1ZSA9PT0gJ2dlbmVyYWwnICYmIHsgY2xpZW50X2lkOiBudWxsLCBjbGllbnRfbmFtZTogJycsIGNsaWVudDogdW5kZWZpbmVkIH0pXG4gICAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgLy8gLS0tIE1BTkVKQURPUkVTIERFIElURU1TIFkgTU9EQUwgLS0tXG4gICAgY29uc3QgaGFuZGxlQWRkSXRlbSA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgbmV3SWQgPSBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IFsuLi5wcmV2LCB7IC4uLkVNUFRZX0lURU0sIHRlbXBJZDogbmV3SWQgfV0pO1xuICAgICAgICBzZXRQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbbmV3SWRdOiAnJyB9KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUl0ZW0gPSAodGVtcElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2LmZpbHRlcihpdGVtID0+IGl0ZW0udGVtcElkICE9PSB0ZW1wSWQpKTtcbiAgICAgICAgc2V0UHJvZHVjdENvZGVzKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiB9O1xuICAgICAgICAgICAgZGVsZXRlIHVwZGF0ZWRbdGVtcElkXTtcbiAgICAgICAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUHJpY2VDaGFuZ2UgPSAodGVtcElkOiBzdHJpbmcsIG5ld1ByaWNlOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2Lm1hcChpdGVtID0+XG4gICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5pdGVtLCBwcmljZTogbmV3UHJpY2UgfSA6IGl0ZW1cbiAgICAgICAgKSk7XG4gICAgfTtcblxuICAgIC8vIEFicmUgZWwgbW9kYWwgY29ycmVjdG8gc2Vnw7puIGVsIHRhcmdldFxuICAgIGNvbnN0IGhhbmRsZU9wZW5Nb2RhbCA9ICh0YXJnZXQ6IEVkaXRpbmdUYXJnZXQsIGl0ZW1UZW1wSWQ/OiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0RWRpdGluZ1RhcmdldCh0YXJnZXQpO1xuICAgICAgICBpZiAodGFyZ2V0ID09PSAnY2xpZW50Jykge1xuICAgICAgICAgICAgc2V0TW9kYWxDb25maWcoY2xpZW50ZXNNb2R1bGVDb25maWcpO1xuICAgICAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7IC8vIEFicmUgbW9kYWwgZ2Vuw6lyaWNvXG4gICAgICAgIH0gZWxzZSBpZiAodGFyZ2V0ID09PSAnaXRlbScpIHtcbiAgICAgICAgICAgIHNldEVkaXRpbmdJdGVtVGVtcElkKGl0ZW1UZW1wSWQgfHwgbnVsbCk7XG4gICAgICAgICAgICAvLyBObyBuZWNlc2l0YW1vcyBzZXRNb2RhbENvbmZpZyBhcXXDrSBwb3JxdWUgZWwgbW9kYWwgZGUgcHJvZHVjdG8gZXMgZXNwZWPDrWZpY29cbiAgICAgICAgICAgIHNldElzUHJvZHVjdE1vZGFsT3Blbih0cnVlKTsgLy8gQWJyZSBtb2RhbCBlc3BlY8OtZmljbyBkZSBwcm9kdWN0b1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIENpZXJyYSBhbWJvcyBtb2RhbGVzIChzaW1wbGlmaWNhZG8pXG4gICAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICBzZXRJc1Byb2R1Y3RNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KG51bGwpO1xuICAgICAgICBzZXRFZGl0aW5nSXRlbVRlbXBJZChudWxsKTtcbiAgICAgICAgc2V0TW9kYWxDb25maWcobnVsbCk7XG4gICAgfVxuXG4gICAgLy8g4pyFIEhhbmRsZXIgcGFyYSBidXNjYXIgY2xpZW50ZSBwb3IgY8OzZGlnb1xuICAgIGNvbnN0IGhhbmRsZUNsaWVudENvZGVTdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghY2xpZW50Q29kZUlucHV0LnRyaW0oKSkgcmV0dXJuO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8YW55PihcbiAgICAgICAgICAgICAgICBjbGllbnRlc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6ICdjdXN0b21lcl9jb2RlJywgdmFsdWU6IGNsaWVudENvZGVJbnB1dCB9XVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IGZvdW5kLmlkLFxuICAgICAgICAgICAgICAgICAgICBjbGllbnRfbmFtZTogZm91bmQubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfY29kZTogZm91bmQuY3VzdG9tZXJfY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgY2xpZW50OiBmb3VuZFxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICBzZXRDbGllbnRDb2RlSW5wdXQoZm91bmQuY3VzdG9tZXJfY29kZSB8fCBTdHJpbmcoZm91bmQuaWQpKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBDbGllbnRlIGVuY29udHJhZG86ICR7Zm91bmQubmFtZX1gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3Qud2FybmluZygnQ2xpZW50ZSBubyBlbmNvbnRyYWRvIGNvbiBlc2UgY8OzZGlnby4nKTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGNsaWVudF9pZDogbnVsbCwgY2xpZW50X25hbWU6IHVuZGVmaW5lZCwgY3VzdG9tZXJfY29kZTogdW5kZWZpbmVkLCBjbGllbnQ6IHVuZGVmaW5lZCB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIGNsaWVudGUgcG9yIGPDs2RpZ28uJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDinIUgSGFuZGxlciBwYXJhIGJ1c2NhciBwcm9kdWN0byBwb3IgY8OzZGlnb1xuICAgIGNvbnN0IGhhbmRsZVByb2R1Y3RDb2RlU3VibWl0ID0gYXN5bmMgKHRlbXBJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvZGVUb1NlYXJjaCA9IHByb2R1Y3RDb2Rlc1t0ZW1wSWRdPy50cmltKCk7XG4gICAgICAgIGlmICghY29kZVRvU2VhcmNoKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIOKchSBCdXNjYXIgY29uIGVsIGZvcm1hdG8gZGUgbcOhc2NhcmEgKGluY2x1eWUgcHVudG9zKVxuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oXG4gICAgICAgICAgICAgICAgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ3NrdScsIHZhbHVlOiBjb2RlVG9TZWFyY2ggfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PlxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaWNlYWJsZV9pZDogZm91bmQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9uYW1lOiBmb3VuZC5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfY29kZTogZm91bmQuc2t1IHx8IGZvdW5kLmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpY2U6IGZvdW5kLnNhbGVfcHJpY2UgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbVxuICAgICAgICAgICAgICAgICkpO1xuICAgICAgICAgICAgICAgIHNldFByb2R1Y3RDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFt0ZW1wSWRdOiBmb3VuZC5za3UgfHwgZm91bmQuY29kZSB8fCBTdHJpbmcoZm91bmQuaWQpIH0pKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBQcm9kdWN0byBlbmNvbnRyYWRvOiAke2ZvdW5kLm5hbWV9YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm5pbmcoJ1Byb2R1Y3RvIG5vIGVuY29udHJhZG8gY29uIGVzZSBjw7NkaWdvLicpO1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PlxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4uaXRlbSwgcHJpY2VhYmxlX2lkOiAwLCBwcm9kdWN0X2NvZGU6ICcnLCBwcm9kdWN0X25hbWU6ICcnLCBwcmljZTogMCB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cbiAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28uJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBNYW5lamEgbGEgc2VsZWNjacOzbiBkZSBDVUFMUVVJRVIgbW9kYWxcbiAgICBjb25zdCBoYW5kbGVTZWxlY3RNb2RhbCA9IChzZWxlY3RlZEl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoIWVkaXRpbmdUYXJnZXQpIHJldHVybjtcblxuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ2NsaWVudCcpIHtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIGNsaWVudF9pZDogc2VsZWN0ZWRJdGVtLmlkLFxuICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiBzZWxlY3RlZEl0ZW0ubmFtZSxcbiAgICAgICAgICAgICAgICBjdXN0b21lcl9jb2RlOiBzZWxlY3RlZEl0ZW0uY3VzdG9tZXJfY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBjbGllbnQ6IHNlbGVjdGVkSXRlbVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgc2V0Q2xpZW50Q29kZUlucHV0KHNlbGVjdGVkSXRlbS5jdXN0b21lcl9jb2RlIHx8IFN0cmluZyhzZWxlY3RlZEl0ZW0uaWQpKTtcbiAgICAgICAgfSBlbHNlIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAnaXRlbScgJiYgZWRpdGluZ0l0ZW1UZW1wSWQpIHtcbiAgICAgICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiBwcmV2SXRlbXMubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLnRlbXBJZCA9PT0gZWRpdGluZ0l0ZW1UZW1wSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmljZWFibGVfaWQ6IHNlbGVjdGVkSXRlbS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogc2VsZWN0ZWRJdGVtLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2NvZGU6IHNlbGVjdGVkSXRlbS5za3UgfHwgc2VsZWN0ZWRJdGVtLmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmljZTogc2VsZWN0ZWRJdGVtLnNhbGVfcHJpY2UgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzZXRQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbZWRpdGluZ0l0ZW1UZW1wSWRdOiBzZWxlY3RlZEl0ZW0uc2t1IHx8IHNlbGVjdGVkSXRlbS5jb2RlIHx8IFN0cmluZyhzZWxlY3RlZEl0ZW0uaWQpIH0pKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGhhbmRsZUNsb3NlTW9kYWwoKTsgLy8gQ2llcnJhIGVsIG1vZGFsIGFjdGl2b1xuICAgIH07XG5cbiAgICAvLyBMaW1waWEgbGEgc2VsZWNjacOzbiAoY2xpZW50ZSBvIHByb2R1Y3RvKVxuICAgIGNvbnN0IGhhbmRsZUNsZWFyU2VsZWN0aW9uID0gKHRhcmdldDogRWRpdGluZ1RhcmdldCwgaXRlbVRlbXBJZD86IHN0cmluZykgPT4ge1xuICAgICAgICBpZiAodGFyZ2V0ID09PSAnY2xpZW50Jykge1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBjbGllbnRfaWQ6IG51bGwsIGNsaWVudF9uYW1lOiAnJywgY3VzdG9tZXJfY29kZTogdW5kZWZpbmVkLCBjbGllbnQ6IHVuZGVmaW5lZCB9KSk7XG4gICAgICAgICAgICBzZXRDbGllbnRDb2RlSW5wdXQoJycpO1xuICAgICAgICB9IGVsc2UgaWYgKHRhcmdldCA9PT0gJ2l0ZW0nICYmIGl0ZW1UZW1wSWQpIHtcbiAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZW0udGVtcElkID09PSBpdGVtVGVtcElkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLml0ZW0sIHByaWNlYWJsZV9pZDogMCwgcHJvZHVjdF9jb2RlOiAnJywgcHJvZHVjdF9uYW1lOiAnJywgcHJpY2U6IDAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzZXRQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbaXRlbVRlbXBJZF06ICcnIH0pKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyAtLS0gTUFORUpBRE9SIERFIEdVQVJEQURPIC0tLVxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRGViZSBhw7FhZGlyIGFsIG1lbm9zIHVuIHByb2R1Y3RvLlwiKTsgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtRGF0YS50eXBlID09PSAnY2xpZW50ZV9lc3BlY2lmaWNvJyAmJiAhZm9ybURhdGEuY2xpZW50X2lkKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIlNpIGVsIHRpcG8gZXMgJ0NsaWVudGUgRXNwZWPDrWZpY28nLCBkZWJlIHNlbGVjY2lvbmFyIHVuIGNsaWVudGUuXCIpOyByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpdGVtc1RvU2F2ZSA9IGl0ZW1zLm1hcChpdGVtID0+ICh7XG4gICAgICAgICAgICBpZDogaXRlbS5pZCB8fCAwLFxuICAgICAgICAgICAgcHJpY2VhYmxlX2lkOiBpdGVtLnByaWNlYWJsZV9pZCxcbiAgICAgICAgICAgIHByaWNlYWJsZV90eXBlOiBcIkFwcFxcXFxNb2RlbHNcXFxcUHJvZHVjdFwiLFxuICAgICAgICAgICAgcHJpY2U6IE51bWJlcihpdGVtLnByaWNlKSB8fCAwLFxuICAgICAgICB9KSk7XG5cbiAgICAgICAgY29uc3QgcGF5bG9hZDogUGFydGlhbDxQcmljZUxpc3Q+ID0ge1xuICAgICAgICAgICAgLi4uZm9ybURhdGEsXG4gICAgICAgICAgICBjbGllbnRfaWQ6IGZvcm1EYXRhLnR5cGUgPT09ICdjbGllbnRlX2VzcGVjaWZpY28nID8gZm9ybURhdGEuY2xpZW50X2lkIDogbnVsbCxcbiAgICAgICAgICAgIGl0ZW1zOiBpdGVtc1RvU2F2ZSxcbiAgICAgICAgICAgIGlzX2FjdGl2ZTogISFmb3JtRGF0YS5pc19hY3RpdmUsXG4gICAgICAgIH07XG4gICAgICAgIGRlbGV0ZSBwYXlsb2FkLmNsaWVudF9uYW1lO1xuICAgICAgICAvLyBkZWxldGUgcGF5bG9hZC5jbGllbnQ7XG5cbiAgICAgICAgY29uc29sZS5sb2coXCJTYXZpbmcgUHJpY2UgTGlzdCBQYXlsb2FkOlwiLCBwYXlsb2FkKTtcbiAgICAgICAgYXdhaXQgc2F2ZUl0ZW0ocGF5bG9hZCBhcyBQcmljZUxpc3QpO1xuICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChwcmljZUxpc3RzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpOyAvLyBzYXZlSXRlbSB5YSBuYXZlZ2EgYWwgw6l4aXRvXG4gICAgfTtcblxuICAgIC8vIC0tLSBSRU5ERVIgLS0tXG4gICAgaWYgKGxvYWRpbmdJbml0aWFsICYmIG1vZGUgPT09ICdlZGl0JykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IgJiYgbW9kZSA9PT0gJ2VkaXQnKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBjYXJnYW5kbyBkYXRvczoge2Vycm9yIGFzIHN0cmluZ308L2Rpdj47XG5cbiAgICBjb25zdCBpbnB1dFN0eWxlID0gXCJ3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIjtcbiAgICBjb25zdCBsYWJlbFN0eWxlID0gXCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02XCI+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHttb2RlID09PSAnY3JlYXRlJyA/IGBDcmVhciAke3ByaWNlTGlzdHNNb2R1bGVDb25maWcubW9kdWxlTmFtZX1gIDogYEVkaXRhbmRvICR7cHJpY2VMaXN0c01vZHVsZUNvbmZpZy5tb2R1bGVOYW1lfTogJHtmb3JtRGF0YS5uYW1lIHx8ICcnfWB9XG4gICAgICAgICAgICAgICAgPC9oMT5cblxuICAgICAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gQ0FCRUNFUkEgKE1hbnVhbCkgLS0tICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiAuLi4gKHJlbmRlcml6YWRvIGRlIGNhYmVjZXJhIHNpbiBjYW1iaW9zKSAuLi4gKi99XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5EYXRvcyBQcmluY2lwYWxlczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBtdC00IG1kOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIiBjbGFzc05hbWU9e2Ake2xhYmVsU3R5bGV9IHJlcXVpcmVkYH0+Tm9tYnJlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm5hbWVcIiBuYW1lPVwibmFtZVwiIHZhbHVlPXtmb3JtRGF0YS5uYW1lIHx8ICcnfSBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9e2lucHV0U3R5bGV9IHJlcXVpcmVkIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ0eXBlXCIgY2xhc3NOYW1lPXtgJHtsYWJlbFN0eWxlfSByZXF1aXJlZGB9PlRpcG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgaWQ9XCJ0eXBlXCIgbmFtZT1cInR5cGVcIiB2YWx1ZT17Zm9ybURhdGEudHlwZSB8fCAnZ2VuZXJhbCd9IG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9IGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gcmVxdWlyZWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJnZW5lcmFsXCI+R2VuZXJhbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2xpZW50ZV9lc3BlY2lmaWNvXCI+Q2xpZW50ZSBFc3BlY8OtZmljbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEudHlwZSA9PT0gJ2NsaWVudGVfZXNwZWNpZmljbycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY2xpZW50X2lkXCIgY2xhc3NOYW1lPXtgJHtsYWJlbFN0eWxlfSByZXF1aXJlZGB9PkNsaWVudGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2NsaWVudENvZGVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEuY2xpZW50X25hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17c2V0Q2xpZW50Q29kZUlucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXtoYW5kbGVDbGllbnRDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdjbGllbnQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlQ2xlYXJTZWxlY3Rpb24oJ2NsaWVudCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZGVzY3JpcHRpb25cIiBjbGFzc05hbWU9e2xhYmVsU3R5bGV9PkRlc2NyaXBjacOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIGlkPVwiZGVzY3JpcHRpb25cIiBuYW1lPVwiZGVzY3JpcHRpb25cIiB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb24gfHwgJyd9IG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gcm93cz17M30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInZhbGlkX2Zyb21cIiBjbGFzc05hbWU9e2Ake2xhYmVsU3R5bGV9IHJlcXVpcmVkYH0+VsOhbGlkbyBEZXNkZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgaWQ9XCJ2YWxpZF9mcm9tXCIgbmFtZT1cInZhbGlkX2Zyb21cIiB2YWx1ZT17Zm9ybURhdGEudmFsaWRfZnJvbSB8fCAnJ30gb25DaGFuZ2U9e2hhbmRsZUhlYWRlckNoYW5nZX0gYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPXtpbnB1dFN0eWxlfSByZXF1aXJlZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidmFsaWRfdG9cIiBjbGFzc05hbWU9e2xhYmVsU3R5bGV9PlbDoWxpZG8gSGFzdGE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIGlkPVwidmFsaWRfdG9cIiBuYW1lPVwidmFsaWRfdG9cIiB2YWx1ZT17Zm9ybURhdGEudmFsaWRfdG8gfHwgJyd9IG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImlzX2FjdGl2ZVwiIGNsYXNzTmFtZT17YCR7bGFiZWxTdHlsZX0gcmVxdWlyZWRgfT5BY3RpdmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgaWQ9XCJpc19hY3RpdmVcIiBuYW1lPVwiaXNfYWN0aXZlXCIgdmFsdWU9e2Zvcm1EYXRhLmlzX2FjdGl2ZSA/ICd0cnVlJyA6ICdmYWxzZSd9IG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9IGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gcmVxdWlyZWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0cnVlXCI+U8OtPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJmYWxzZVwiPk5vPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogLS0tIFNFQ0NJw5NOIElURU1TIChzaW4gY2FtYmlvcyBlbiBsYSBlc3RydWN0dXJhKSAtLS0gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC02IG10LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIC4uLiAodGFibGEgeSBib3TDs24gYcOxYWRpciBzaW4gY2FtYmlvcykgLi4uICovfVxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMCBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBQcm9kdWN0b3MgeSBQcmVjaW9zXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNiB3LTMvNVwiPlByb2R1Y3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMS81XCI+UHJlY2lvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweS0zLjUgcGwtMyBwci00IHNtOnByLTYgdy0xLzVcIj5BY2Npb25lczwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0udGVtcElkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17cHJvZHVjdENvZGVzW2l0ZW0udGVtcElkXSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5wcm9kdWN0X25hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KHZhbCkgPT4gc2V0UHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW2l0ZW0udGVtcElkXTogdmFsIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlUHJvZHVjdENvZGVTdWJtaXQoaXRlbS50ZW1wSWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdpdGVtJywgaXRlbS50ZW1wSWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVDbGVhclNlbGVjdGlvbignaXRlbScsIGl0ZW0udGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnByaWNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVQcmljZUNoYW5nZShpdGVtLnRlbXBJZCwgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aW5wdXRTdHlsZX0gdGV4dC1yaWdodCBtYXgtdy1bMTUwcHhdIGlubGluZS1ibG9ja2B9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtMyBwci00IHRleHQtcmlnaHQgc206cHItNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVJdGVtKGl0ZW0udGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwXCIgdGl0bGU9XCJFbGltaW5hciDDjXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhVHJhc2ggLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY29sU3Bhbj17M30gY2xhc3NOYW1lPVwicHgtNiBweS00IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBwcm9kdWN0b3MgYcOxYWRpZG9zLjwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFkZEl0ZW19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIG10LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyYXktNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYVBsdXMgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gQcOxYWRpciBQcm9kdWN0b1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiAtLS0gQk9UT05FUyBERSBBQ0NJw5NOIChNYW51YWwpIC0tLSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBtdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHByaWNlTGlzdHNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSl9IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlU2F2ZX0gZGlzYWJsZWQ9e3NhdmluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgbWwtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NhdmluZyA/IDxGYVNwaW5uZXIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHctNSBoLTUgbXItMlwiIC8+IDogPEZhU2F2ZSBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTJcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgQ2FtYmlvc1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTW9kYWwgZ2Vuw6lyaWNvIHBhcmEgQ2xpZW50ZSAqL31cbiAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiBtb2RhbENvbmZpZyAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9XG4gICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RNb2RhbH1cbiAgICAgICAgICAgICAgICAgICAgY29uZmlnPXttb2RhbENvbmZpZ31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIC0tLSBDT1JSRUNDScOTTjogUmVuZGVyaXphZG8gY29uZGljaW9uYWwgZGVsIG1vZGFsIGRlIHByb2R1Y3RvIC0tLSAqL31cbiAgICAgICAgICAgIHsvKiBBc2VndXJhbW9zIHF1ZSBzb2xvIHNlIHJlbmRlcmljZSBjdWFuZG8gaXNQcm9kdWN0TW9kYWxPcGVuIHNlYSB0cnVlICovfVxuICAgICAgICAgICAge2lzUHJvZHVjdE1vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNQcm9kdWN0TW9kYWxPcGVufVxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZU1vZGFsfVxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17aGFuZGxlU2VsZWN0TW9kYWx9XG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZz17YXJ0aWN1bG9zTW9kdWxlQ29uZmlnfSAvLyBDb25maWcgc2llbXByZSBlcyBhcnTDrWN1bG9zIGFxdcOtXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGlzdGFfcHJlY2lvcy9wYWdlcy9MaXN0YXNQcmVjaW9zRm9ybVBhZ2UudHN4In0=