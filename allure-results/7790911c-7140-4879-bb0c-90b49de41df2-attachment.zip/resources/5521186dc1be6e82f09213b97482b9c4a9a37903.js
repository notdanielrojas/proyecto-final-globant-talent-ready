import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/ProtectedRoute.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/routes/ProtectedRoute.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useAuth } from "/src/hooks/useAuth.ts";
export const ProtectedRoute = () => {
  _s();
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login" }, void 0, false, {
      fileName: "/app/src/routes/ProtectedRoute.tsx",
      lineNumber: 29,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "/app/src/routes/ProtectedRoute.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(ProtectedRoute, "1LGxUrjNz4q7iKM/2JDC9lJQ3xY=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/routes/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/routes/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU2U7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBUmYsU0FBU0EsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxlQUFlO0FBRWpCLGFBQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsZ0JBQWdCLElBQUlILFFBQVE7QUFFcEMsTUFBSSxDQUFDRyxpQkFBaUI7QUFFbEIsV0FBTyx1QkFBQyxZQUFTLElBQUcsWUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsRUFDaEM7QUFHQSxTQUFPLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPO0FBQ2xCO0FBQUVELEdBVldELGdCQUFjO0FBQUEsVUFDS0QsT0FBTztBQUFBO0FBQUFJLEtBRDFCSDtBQUFjLElBQUFHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsIk91dGxldCIsInVzZUF1dGgiLCJQcm90ZWN0ZWRSb3V0ZSIsIl9zIiwiaXNBdXRoZW50aWNhdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9yb3V0ZXMvUHJvdGVjdGVkUm91dGUudHN4XG5pbXBvcnQgeyBOYXZpZ2F0ZSwgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vaG9va3MvdXNlQXV0aCc7XG5cbmV4cG9ydCBjb25zdCBQcm90ZWN0ZWRSb3V0ZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlzQXV0aGVudGljYXRlZCB9ID0gdXNlQXV0aCgpO1xuXG4gICAgaWYgKCFpc0F1dGhlbnRpY2F0ZWQpIHtcbiAgICAgICAgLy8gU2kgbm8gZXN0w6EgYXV0ZW50aWNhZG8sIGxvIHJlZGlyaWdpbW9zIGEgbGEgcMOhZ2luYSBkZSBsb2dpblxuICAgICAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgLz47XG4gICAgfVxuXG4gICAgLy8gU2kgZXN0w6EgYXV0ZW50aWNhZG8sIHJlbmRlcml6YSBlbCBsYXlvdXQgcHJpbmNpcGFsIHF1ZSBhIHN1IHZleiByZW5kZXJpemFyw6EgbGEgcMOhZ2luYSBoaWphXG4gICAgcmV0dXJuIDxPdXRsZXQgLz47XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvcm91dGVzL1Byb3RlY3RlZFJvdXRlLnRzeCJ9