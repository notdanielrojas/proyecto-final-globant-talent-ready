import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/MenuNavSearch.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/MenuNavSearch.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { RxMagnifyingGlass } from "/node_modules/.vite/deps/react-icons_rx.js?v=cc4fbb62";
import { getMenuIcon } from "/src/config/menuItems.tsx";
import { filterNavEntries, flattenNavigableRoutes } from "/src/utils/menuSearch.ts";
export function useMenuNavSearchResults(items, query) {
  _s();
  const entries = useMemo(() => flattenNavigableRoutes(items), [items]);
  return useMemo(() => filterNavEntries(entries, query), [entries, query]);
}
_s(useMenuNavSearchResults, "/D3fZMF8IFbP4tgSGPTyGLex9QA=");
export function MenuNavSearchBar({
  variant,
  query,
  onQueryChange,
  inputRef,
  sidebarCollapsed,
  onExpandSidebarForSearch
}) {
  const ariaLabel = "Buscar en el menú";
  if (variant === "sidebar" && sidebarCollapsed) {
    return /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onExpandSidebarForSearch,
        className: "flex items-center justify-center w-full p-2 rounded-md transition-colors duration-200 cursor-pointer hover:bg-gray-700 text-white",
        "aria-label": ariaLabel,
        children: /* @__PURE__ */ jsxDEV(RxMagnifyingGlass, { className: "w-6 h-6", "aria-hidden": true }, void 0, false, {
          fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
          lineNumber: 60,
          columnNumber: 17
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 54,
        columnNumber: 7
      },
      this
    );
  }
  const onKeyDown = (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      onQueryChange("");
      e.currentTarget.blur();
    }
  };
  if (variant === "sidebar") {
    return /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: inputRef,
        type: "search",
        value: query,
        onChange: (e) => onQueryChange(e.target.value),
        onKeyDown,
        placeholder: "Buscar...",
        autoComplete: "off",
        "aria-label": ariaLabel,
        className: "w-full px-3 py-2 text-sm text-white bg-gray-800/50 border border-gray-600 rounded-md placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 75,
        columnNumber: 7
      },
      this
    );
  }
  const iconPad = "pl-9";
  const inputBase = "w-full py-2 text-sm text-gray-900 bg-gray-50 border border-gray-200 rounded-lg placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500";
  if (variant === "topDesktop") {
    return /* @__PURE__ */ jsxDEV("div", { className: "relative shrink-0", children: [
      /* @__PURE__ */ jsxDEV(
        RxMagnifyingGlass,
        {
          className: "pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400",
          "aria-hidden": true
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
          lineNumber: 96,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          ref: inputRef,
          type: "search",
          value: query,
          onChange: (e) => onQueryChange(e.target.value),
          onKeyDown,
          placeholder: "Buscar...",
          autoComplete: "off",
          "aria-label": ariaLabel,
          className: `${iconPad} pr-3 ${inputBase} min-w-[11rem] max-w-[14rem]`
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
          lineNumber: 100,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2 pt-2 pb-1", children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
    /* @__PURE__ */ jsxDEV(
      RxMagnifyingGlass,
      {
        className: "pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400",
        "aria-hidden": true
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 118,
        columnNumber: 17
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: inputRef,
        type: "search",
        value: query,
        onChange: (e) => onQueryChange(e.target.value),
        onKeyDown,
        placeholder: "Buscar en el menú...",
        autoComplete: "off",
        "aria-label": ariaLabel,
        className: `${iconPad} pr-3 ${inputBase}`
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 122,
        columnNumber: 17
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
    lineNumber: 117,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
}
_c = MenuNavSearchBar;
export function MenuNavFlatResults({ entries, variant, onNavigate }) {
  if (entries.length === 0) {
    const emptyClass = variant === "sidebar" ? "mt-2 px-2 py-3 text-sm text-gray-300 text-center" : "px-3 py-4 text-sm text-gray-500 text-center";
    return /* @__PURE__ */ jsxDEV("p", { className: emptyClass, children: "Sin resultados" }, void 0, false, {
      fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
      lineNumber: 150,
      columnNumber: 12
    }, this);
  }
  if (variant === "sidebar") {
    return /* @__PURE__ */ jsxDEV("ul", { role: "list", className: "mt-2 space-y-1", children: entries.map(
      (e) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
        NavLink,
        {
          to: e.path,
          onClick: () => {
            onNavigate?.();
          },
          className: ({ isActive }) => `flex flex-col w-full p-2 text-sm rounded-md transition-colors duration-200 ${isActive ? "bg-indigo-600" : "hover:bg-gray-700"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: getMenuIcon(e.iconKey, 20) }, void 0, false, {
                fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
                lineNumber: 168,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: e.label }, void 0, false, {
                fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
                lineNumber: 169,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 167,
              columnNumber: 29
            }, this),
            e.sectionLabel && /* @__PURE__ */ jsxDEV("span", { className: "pl-8 mt-0.5 text-xs text-gray-400", children: e.sectionLabel }, void 0, false, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 172,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
          lineNumber: 158,
          columnNumber: 25
        },
        this
      ) }, e.path, false, {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 157,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this);
  }
  if (variant === "topMobile") {
    return /* @__PURE__ */ jsxDEV("ul", { role: "list", className: "px-2 pb-2 flex flex-col gap-0.5 max-h-[min(60vh,420px)] overflow-y-auto", children: entries.map(
      (e) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
        NavLink,
        {
          to: e.path,
          onClick: () => onNavigate?.(),
          className: ({ isActive }) => `flex flex-col px-3 py-2 rounded-lg text-sm transition-colors ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-700 hover:bg-gray-100"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-3 font-medium", children: [
              getMenuIcon(e.iconKey, 18),
              /* @__PURE__ */ jsxDEV("span", { children: e.label }, void 0, false, {
                fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
                lineNumber: 195,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 193,
              columnNumber: 29
            }, this),
            e.sectionLabel && /* @__PURE__ */ jsxDEV("span", { className: "pl-[2.25rem] text-xs text-gray-500", children: e.sectionLabel }, void 0, false, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 198,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
          lineNumber: 186,
          columnNumber: 25
        },
        this
      ) }, e.path, false, {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
      lineNumber: 183,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-w-[240px] py-2 bg-white rounded-lg shadow-lg border border-gray-100 max-h-96 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("ul", { role: "list", className: "space-y-0.5", children: entries.map(
    (e) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
      NavLink,
      {
        to: e.path,
        onClick: () => onNavigate?.(),
        className: ({ isActive }) => `flex items-start gap-3 px-4 py-2.5 text-left transition-colors hover:bg-gray-50 ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-700"}`,
        children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex-shrink-0 mt-0.5 text-indigo-600", children: getMenuIcon(e.iconKey, 20) }, void 0, false, {
            fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
            lineNumber: 219,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium block", children: e.label }, void 0, false, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 223,
              columnNumber: 33
            }, this),
            e.sectionLabel && /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 block mt-0.5", children: e.sectionLabel }, void 0, false, {
              fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
              lineNumber: 225,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
            lineNumber: 222,
            columnNumber: 29
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
        lineNumber: 212,
        columnNumber: 25
      },
      this
    ) }, e.path, false, {
      fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
      lineNumber: 211,
      columnNumber: 9
    }, this)
  ) }, void 0, false, {
    fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
    lineNumber: 209,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/layouts/MenuNavSearch.tsx",
    lineNumber: 208,
    columnNumber: 5
  }, this);
}
_c2 = MenuNavFlatResults;
var _c, _c2;
$RefreshReg$(_c, "MenuNavSearchBar");
$RefreshReg$(_c2, "MenuNavFlatResults");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/MenuNavSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/MenuNavSearch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4Q2hCLFNBQVNBLGVBQW1EO0FBQzVELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLG1CQUFrQztBQUMzQyxTQUFTQyxrQkFBa0JDLDhCQUE2QztBQUlqRSxnQkFBU0Msd0JBQXdCQyxPQUFtQkMsT0FBMkI7QUFBQUMsS0FBQTtBQUNsRixRQUFNQyxVQUFVVixRQUFRLE1BQU1LLHVCQUF1QkUsS0FBSyxHQUFHLENBQUNBLEtBQUssQ0FBQztBQUNwRSxTQUFPUCxRQUFRLE1BQU1JLGlCQUFpQk0sU0FBU0YsS0FBSyxHQUFHLENBQUNFLFNBQVNGLEtBQUssQ0FBQztBQUMzRTtBQUFDQyxHQUhlSCx5QkFBdUI7QUFjaEMsZ0JBQVNLLGlCQUFpQjtBQUFBLEVBQzdCQztBQUFBQSxFQUNBSjtBQUFBQSxFQUNBSztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNtQixHQUFHO0FBQ3RCLFFBQU1DLFlBQVk7QUFFbEIsTUFBSUwsWUFBWSxhQUFhRyxrQkFBa0I7QUFDM0MsV0FDSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsU0FBU0M7QUFBQUEsUUFDVCxXQUFVO0FBQUEsUUFDVixjQUFZQztBQUFBQSxRQUVaLGlDQUFDLHFCQUFrQixXQUFVLFdBQVUsZUFBVyxRQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUE7QUFBQSxNQU50RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLEVBRVI7QUFFQSxRQUFNQyxZQUFZQSxDQUFDQyxNQUF1QztBQUN0RCxRQUFJQSxFQUFFQyxRQUFRLFVBQVU7QUFDcEJELFFBQUVFLGdCQUFnQjtBQUNsQlIsb0JBQWMsRUFBRTtBQUNoQk0sUUFBRUcsY0FBY0MsS0FBSztBQUFBLElBQ3pCO0FBQUEsRUFDSjtBQUVBLE1BQUlYLFlBQVksV0FBVztBQUN2QixXQUNJO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxLQUFLRTtBQUFBQSxRQUNMLE1BQUs7QUFBQSxRQUNMLE9BQU9OO0FBQUFBLFFBQ1AsVUFBVSxDQUFDVyxNQUFNTixjQUFjTSxFQUFFSyxPQUFPQyxLQUFLO0FBQUEsUUFDN0M7QUFBQSxRQUNBLGFBQVk7QUFBQSxRQUNaLGNBQWE7QUFBQSxRQUNiLGNBQVlSO0FBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTb0w7QUFBQSxFQUc1TDtBQUVBLFFBQU1TLFVBQVU7QUFDaEIsUUFBTUMsWUFDRjtBQUVKLE1BQUlmLFlBQVksY0FBYztBQUMxQixXQUNJLHVCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxXQUFVO0FBQUEsVUFDVixlQUFXO0FBQUE7QUFBQSxRQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVlO0FBQUEsTUFFZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csS0FBS0U7QUFBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxPQUFPTjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ1csTUFBTU4sY0FBY00sRUFBRUssT0FBT0MsS0FBSztBQUFBLFVBQzdDO0FBQUEsVUFDQSxhQUFZO0FBQUEsVUFDWixjQUFhO0FBQUEsVUFDYixjQUFZUjtBQUFBQSxVQUNaLFdBQVcsR0FBR1MsT0FBTyxTQUFTQyxTQUFTO0FBQUE7QUFBQSxRQVQzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTMEU7QUFBQSxTQWQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsRUFFUjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHlCQUNYLGlDQUFDLFNBQUksV0FBVSxZQUNYO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFdBQVU7QUFBQSxRQUNWLGVBQVc7QUFBQTtBQUFBLE1BRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRWU7QUFBQSxJQUVmO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxLQUFLYjtBQUFBQSxRQUNMLE1BQUs7QUFBQSxRQUNMLE9BQU9OO0FBQUFBLFFBQ1AsVUFBVSxDQUFDVyxNQUFNTixjQUFjTSxFQUFFSyxPQUFPQyxLQUFLO0FBQUEsUUFDN0M7QUFBQSxRQUNBLGFBQVk7QUFBQSxRQUNaLGNBQWE7QUFBQSxRQUNiLGNBQVlSO0FBQUFBLFFBQ1osV0FBVyxHQUFHUyxPQUFPLFNBQVNDLFNBQVM7QUFBQTtBQUFBLE1BVDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVM4QztBQUFBLE9BZGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVSO0FBQUNDLEtBOUZlakI7QUFzR1QsZ0JBQVNrQixtQkFBbUIsRUFBRW5CLFNBQVNFLFNBQVNrQixXQUFvQyxHQUFHO0FBQzFGLE1BQUlwQixRQUFRcUIsV0FBVyxHQUFHO0FBQ3RCLFVBQU1DLGFBQ0ZwQixZQUFZLFlBQ04scURBQ0E7QUFDVixXQUFPLHVCQUFDLE9BQUUsV0FBV29CLFlBQVksOEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0M7QUFBQSxFQUNuRDtBQUVBLE1BQUlwQixZQUFZLFdBQVc7QUFDdkIsV0FDSSx1QkFBQyxRQUFHLE1BQUssUUFBTyxXQUFVLGtCQUNyQkYsa0JBQVF1QjtBQUFBQSxNQUFJLENBQUNkLE1BQ1YsdUJBQUMsUUFDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csSUFBSUEsRUFBRWU7QUFBQUEsVUFDTixTQUFTLE1BQU07QUFDWEoseUJBQWE7QUFBQSxVQUNqQjtBQUFBLFVBQ0EsV0FBVyxDQUFDLEVBQUVLLFNBQVMsTUFDbkIsOEVBQThFQSxXQUFXLGtCQUFrQixtQkFBbUI7QUFBQSxVQUdsSTtBQUFBLG1DQUFDLFVBQUssV0FBVSxxQkFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSxRQUFRaEMsc0JBQVlnQixFQUFFaUIsU0FBUyxFQUFFLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsY0FDbkQsdUJBQUMsVUFBTWpCLFlBQUVrQixTQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxpQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0NsQixFQUFFbUIsZ0JBQ0MsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ25CLFlBQUVtQixnQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQTtBQUFBO0FBQUEsUUFkNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ0JBLEtBakJLbkIsRUFBRWUsTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsSUFDSCxLQXJCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsRUFFUjtBQUVBLE1BQUl0QixZQUFZLGFBQWE7QUFDekIsV0FDSSx1QkFBQyxRQUFHLE1BQUssUUFBTyxXQUFVLDJFQUNyQkYsa0JBQVF1QjtBQUFBQSxNQUFJLENBQUNkLE1BQ1YsdUJBQUMsUUFDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csSUFBSUEsRUFBRWU7QUFBQUEsVUFDTixTQUFTLE1BQU1KLGFBQWE7QUFBQSxVQUM1QixXQUFXLENBQUMsRUFBRUssU0FBUyxNQUNuQixnRUFBZ0VBLFdBQVcsaUNBQWlDLGlDQUFpQztBQUFBLFVBR2pKO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHVDQUNYaEM7QUFBQUEsMEJBQVlnQixFQUFFaUIsU0FBUyxFQUFFO0FBQUEsY0FDMUIsdUJBQUMsVUFBTWpCLFlBQUVrQixTQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxpQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0NsQixFQUFFbUIsZ0JBQ0MsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQ25CLFlBQUVtQixnQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQTtBQUFBO0FBQUEsUUFaN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0EsS0FmS25CLEVBQUVlLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLElBQ0gsS0FuQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLEVBRVI7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxvR0FDWCxpQ0FBQyxRQUFHLE1BQUssUUFBTyxXQUFVLGVBQ3JCeEIsa0JBQVF1QjtBQUFBQSxJQUFJLENBQUNkLE1BQ1YsdUJBQUMsUUFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csSUFBSUEsRUFBRWU7QUFBQUEsUUFDTixTQUFTLE1BQU1KLGFBQWE7QUFBQSxRQUM1QixXQUFXLENBQUMsRUFBRUssU0FBUyxNQUNuQixtRkFBbUZBLFdBQVcsaUNBQWlDLGVBQWU7QUFBQSxRQUdsSjtBQUFBLGlDQUFDLFVBQUssV0FBVSx3Q0FDWGhDLHNCQUFZZ0IsRUFBRWlCLFNBQVMsRUFBRSxLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsa0JBQ1o7QUFBQSxtQ0FBQyxVQUFLLFdBQVUscUJBQXFCakIsWUFBRWtCLFNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDNUNsQixFQUFFbUIsZ0JBQ0MsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQ25CLFlBQUVtQixnQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxlQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUE7QUFBQTtBQUFBLE1BZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0JBLEtBakJLbkIsRUFBRWUsTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsRUFDSCxLQXJCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBLEtBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFUjtBQUFDSyxNQTFGZVY7QUFBa0IsSUFBQUQsSUFBQVc7QUFBQUMsYUFBQVosSUFBQTtBQUFBWSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIk5hdkxpbmsiLCJSeE1hZ25pZnlpbmdHbGFzcyIsImdldE1lbnVJY29uIiwiZmlsdGVyTmF2RW50cmllcyIsImZsYXR0ZW5OYXZpZ2FibGVSb3V0ZXMiLCJ1c2VNZW51TmF2U2VhcmNoUmVzdWx0cyIsIml0ZW1zIiwicXVlcnkiLCJfcyIsImVudHJpZXMiLCJNZW51TmF2U2VhcmNoQmFyIiwidmFyaWFudCIsIm9uUXVlcnlDaGFuZ2UiLCJpbnB1dFJlZiIsInNpZGViYXJDb2xsYXBzZWQiLCJvbkV4cGFuZFNpZGViYXJGb3JTZWFyY2giLCJhcmlhTGFiZWwiLCJvbktleURvd24iLCJlIiwia2V5Iiwic3RvcFByb3BhZ2F0aW9uIiwiY3VycmVudFRhcmdldCIsImJsdXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsImljb25QYWQiLCJpbnB1dEJhc2UiLCJfYyIsIk1lbnVOYXZGbGF0UmVzdWx0cyIsIm9uTmF2aWdhdGUiLCJsZW5ndGgiLCJlbXB0eUNsYXNzIiwibWFwIiwicGF0aCIsImlzQWN0aXZlIiwiaWNvbktleSIsImxhYmVsIiwic2VjdGlvbkxhYmVsIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1lbnVOYXZTZWFyY2gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHR5cGUgS2V5Ym9hcmRFdmVudCwgdHlwZSBSZWZPYmplY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOYXZMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBSeE1hZ25pZnlpbmdHbGFzcyB9IGZyb20gJ3JlYWN0LWljb25zL3J4JztcbmltcG9ydCB7IGdldE1lbnVJY29uLCB0eXBlIE1lbnVJdGVtIH0gZnJvbSAnLi4vLi4vY29uZmlnL21lbnVJdGVtcyc7XG5pbXBvcnQgeyBmaWx0ZXJOYXZFbnRyaWVzLCBmbGF0dGVuTmF2aWdhYmxlUm91dGVzLCB0eXBlIE5hdkVudHJ5IH0gZnJvbSAnLi4vLi4vdXRpbHMvbWVudVNlYXJjaCc7XG5cbmV4cG9ydCB0eXBlIE1lbnVOYXZTZWFyY2hWYXJpYW50ID0gJ3NpZGViYXInIHwgJ3RvcERlc2t0b3AnIHwgJ3RvcE1vYmlsZSc7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51TmF2U2VhcmNoUmVzdWx0cyhpdGVtczogTWVudUl0ZW1bXSwgcXVlcnk6IHN0cmluZyk6IE5hdkVudHJ5W10ge1xuICAgIGNvbnN0IGVudHJpZXMgPSB1c2VNZW1vKCgpID0+IGZsYXR0ZW5OYXZpZ2FibGVSb3V0ZXMoaXRlbXMpLCBbaXRlbXNdKTtcbiAgICByZXR1cm4gdXNlTWVtbygoKSA9PiBmaWx0ZXJOYXZFbnRyaWVzKGVudHJpZXMsIHF1ZXJ5KSwgW2VudHJpZXMsIHF1ZXJ5XSk7XG59XG5cbnR5cGUgTWVudU5hdlNlYXJjaEJhclByb3BzID0ge1xuICAgIHZhcmlhbnQ6IE1lbnVOYXZTZWFyY2hWYXJpYW50O1xuICAgIHF1ZXJ5OiBzdHJpbmc7XG4gICAgb25RdWVyeUNoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWQ7XG4gICAgaW5wdXRSZWY/OiBSZWZPYmplY3Q8SFRNTElucHV0RWxlbWVudCB8IG51bGw+O1xuICAgIHNpZGViYXJDb2xsYXBzZWQ/OiBib29sZWFuO1xuICAgIG9uRXhwYW5kU2lkZWJhckZvclNlYXJjaD86ICgpID0+IHZvaWQ7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gTWVudU5hdlNlYXJjaEJhcih7XG4gICAgdmFyaWFudCxcbiAgICBxdWVyeSxcbiAgICBvblF1ZXJ5Q2hhbmdlLFxuICAgIGlucHV0UmVmLFxuICAgIHNpZGViYXJDb2xsYXBzZWQsXG4gICAgb25FeHBhbmRTaWRlYmFyRm9yU2VhcmNoLFxufTogTWVudU5hdlNlYXJjaEJhclByb3BzKSB7XG4gICAgY29uc3QgYXJpYUxhYmVsID0gJ0J1c2NhciBlbiBlbCBtZW7Duic7XG5cbiAgICBpZiAodmFyaWFudCA9PT0gJ3NpZGViYXInICYmIHNpZGViYXJDb2xsYXBzZWQpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkV4cGFuZFNpZGViYXJGb3JTZWFyY2h9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy1mdWxsIHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1ncmF5LTcwMCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXthcmlhTGFiZWx9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJ4TWFnbmlmeWluZ0dsYXNzIGNsYXNzTmFtZT1cInctNiBoLTZcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgb25LZXlEb3duID0gKGU6IEtleWJvYXJkRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIG9uUXVlcnlDaGFuZ2UoJycpO1xuICAgICAgICAgICAgZS5jdXJyZW50VGFyZ2V0LmJsdXIoKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAodmFyaWFudCA9PT0gJ3NpZGViYXInKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uUXVlcnlDaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIG9uS2V5RG93bj17b25LZXlEb3dufVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyLi4uXCJcbiAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gdGV4dC13aGl0ZSBiZy1ncmF5LTgwMC81MCBib3JkZXIgYm9yZGVyLWdyYXktNjAwIHJvdW5kZWQtbWQgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGljb25QYWQgPSAncGwtOSc7XG4gICAgY29uc3QgaW5wdXRCYXNlID1cbiAgICAgICAgJ3ctZnVsbCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMCBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwJztcblxuICAgIGlmICh2YXJpYW50ID09PSAndG9wRGVza3RvcCcpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICA8UnhNYWduaWZ5aW5nR2xhc3NcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTIuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdy00IGgtNCB0ZXh0LWdyYXktNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3F1ZXJ5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uUXVlcnlDaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIuLi5cIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXthcmlhTGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aWNvblBhZH0gcHItMyAke2lucHV0QmFzZX0gbWluLXctWzExcmVtXSBtYXgtdy1bMTRyZW1dYH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBwdC0yIHBiLTFcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICA8UnhNYWduaWZ5aW5nR2xhc3NcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTIuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdy00IGgtNCB0ZXh0LWdyYXktNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3F1ZXJ5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uUXVlcnlDaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgZW4gZWwgbWVuw7ouLi5cIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXthcmlhTGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aWNvblBhZH0gcHItMyAke2lucHV0QmFzZX1gfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxudHlwZSBNZW51TmF2RmxhdFJlc3VsdHNQcm9wcyA9IHtcbiAgICBlbnRyaWVzOiBOYXZFbnRyeVtdO1xuICAgIHZhcmlhbnQ6IE1lbnVOYXZTZWFyY2hWYXJpYW50O1xuICAgIG9uTmF2aWdhdGU/OiAoKSA9PiB2b2lkO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIE1lbnVOYXZGbGF0UmVzdWx0cyh7IGVudHJpZXMsIHZhcmlhbnQsIG9uTmF2aWdhdGUgfTogTWVudU5hdkZsYXRSZXN1bHRzUHJvcHMpIHtcbiAgICBpZiAoZW50cmllcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc3QgZW1wdHlDbGFzcyA9XG4gICAgICAgICAgICB2YXJpYW50ID09PSAnc2lkZWJhcidcbiAgICAgICAgICAgICAgICA/ICdtdC0yIHB4LTIgcHktMyB0ZXh0LXNtIHRleHQtZ3JheS0zMDAgdGV4dC1jZW50ZXInXG4gICAgICAgICAgICAgICAgOiAncHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlcic7XG4gICAgICAgIHJldHVybiA8cCBjbGFzc05hbWU9e2VtcHR5Q2xhc3N9PlNpbiByZXN1bHRhZG9zPC9wPjtcbiAgICB9XG5cbiAgICBpZiAodmFyaWFudCA9PT0gJ3NpZGViYXInKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8dWwgcm9sZT1cImxpc3RcIiBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgIHtlbnRyaWVzLm1hcCgoZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtlLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17ZS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT8uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IGZsZXgtY29sIHctZnVsbCBwLTIgdGV4dC1zbSByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCAke2lzQWN0aXZlID8gJ2JnLWluZGlnby02MDAnIDogJ2hvdmVyOmJnLWdyYXktNzAwJ31gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1yLTJcIj57Z2V0TWVudUljb24oZS5pY29uS2V5LCAyMCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlLnNlY3Rpb25MYWJlbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBsLTggbXQtMC41IHRleHQteHMgdGV4dC1ncmF5LTQwMFwiPntlLnNlY3Rpb25MYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKHZhcmlhbnQgPT09ICd0b3BNb2JpbGUnKSB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8dWwgcm9sZT1cImxpc3RcIiBjbGFzc05hbWU9XCJweC0yIHBiLTIgZmxleCBmbGV4LWNvbCBnYXAtMC41IG1heC1oLVttaW4oNjB2aCw0MjBweCldIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgIHtlbnRyaWVzLm1hcCgoZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtlLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17ZS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGU/LigpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggZmxleC1jb2wgcHgtMyBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyAke2lzQWN0aXZlID8gJ2JnLWluZGlnby01MCB0ZXh0LWluZGlnby03MDAnIDogJ3RleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDAnfWBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldE1lbnVJY29uKGUuaWNvbktleSwgMTgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlLnNlY3Rpb25MYWJlbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBsLVsyLjI1cmVtXSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj57ZS5zZWN0aW9uTGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzI0MHB4XSBweS0yIGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgbWF4LWgtOTYgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICA8dWwgcm9sZT1cImxpc3RcIiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgIHtlbnRyaWVzLm1hcCgoZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtlLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17ZS5wYXRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGU/LigpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcHgtNCBweS0yLjUgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWdyYXktNTAgJHtpc0FjdGl2ZSA/ICdiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwJyA6ICd0ZXh0LWdyYXktNzAwJ31gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgbXQtMC41IHRleHQtaW5kaWdvLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0TWVudUljb24oZS5pY29uS2V5LCAyMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIGJsb2NrXCI+e2UubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZS5zZWN0aW9uTGFiZWwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGJsb2NrIG10LTAuNVwiPntlLnNlY3Rpb25MYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9sYXlvdXRzL01lbnVOYXZTZWFyY2gudHN4In0=