import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/NoDataMessage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/NoDataMessage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { RxInfoCircled } from "/node_modules/.vite/deps/react-icons_rx.js?v=cc4fbb62";
export const NoDataMessage = ({ moduleName }) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center p-10 mt-8 text-center bg-white border border-dashed rounded-lg", children: [
    /* @__PURE__ */ jsxDEV(RxInfoCircled, { className: "w-12 h-12 text-gray-400" }, void 0, false, {
      fileName: "/app/src/components/common/NoDataMessage.tsx",
      lineNumber: 30,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "mt-2 text-lg font-medium text-gray-900", children: [
      "No hay ",
      moduleName
    ] }, void 0, true, {
      fileName: "/app/src/components/common/NoDataMessage.tsx",
      lineNumber: 31,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: "Empieza por crear el primer registro." }, void 0, false, {
      fileName: "/app/src/components/common/NoDataMessage.tsx",
      lineNumber: 32,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/NoDataMessage.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
};
_c = NoDataMessage;
var _c;
$RefreshReg$(_c, "NoDataMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/NoDataMessage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/NoDataMessage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFUWixTQUFTQSxxQkFBcUI7QUFNdkIsYUFBTUMsZ0JBQWdCQSxDQUFDLEVBQUVDLFdBQWtCLE1BQU07QUFDcEQsU0FDSSx1QkFBQyxTQUFJLFdBQVUsNEdBQ1g7QUFBQSwyQkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtEO0FBQUEsSUFDbEQsdUJBQUMsUUFBRyxXQUFVLDBDQUF5QztBQUFBO0FBQUEsTUFBUUE7QUFBQUEsU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRTtBQUFBLElBQzFFLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEIscURBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRVI7QUFBRUMsS0FWV0Y7QUFBYSxJQUFBRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUnhJbmZvQ2lyY2xlZCIsIk5vRGF0YU1lc3NhZ2UiLCJtb2R1bGVOYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm9EYXRhTWVzc2FnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2NvbXBvbmVudHMvY29tbW9uL05vRGF0YU1lc3NhZ2UudHN4XG5pbXBvcnQgeyBSeEluZm9DaXJjbGVkIH0gZnJvbSAncmVhY3QtaWNvbnMvcngnO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIG1vZHVsZU5hbWU6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IE5vRGF0YU1lc3NhZ2UgPSAoeyBtb2R1bGVOYW1lIH06IFByb3BzKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTEwIG10LTggdGV4dC1jZW50ZXIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1kYXNoZWQgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgPFJ4SW5mb0NpcmNsZWQgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+Tm8gaGF5IHttb2R1bGVOYW1lfTwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgIEVtcGllemEgcG9yIGNyZWFyIGVsIHByaW1lciByZWdpc3Ryby5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9Ob0RhdGFNZXNzYWdlLnRzeCJ9