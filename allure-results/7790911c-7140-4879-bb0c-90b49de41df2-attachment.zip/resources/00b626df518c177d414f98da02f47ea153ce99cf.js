import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mov_stock/pages/MovStockEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mov_stock/pages/MovStockEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { stockMovementsModuleConfig } from "/src/features/mov_stock/movStock.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { MovStockFormPage } from "/src/features/mov_stock/pages/MovStockFormPage.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const MovStockEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: movement, loading: loadingData, error, saveItem } = useCrudItem(stockMovementsModuleConfig, id);
  const [saving, setSaving] = useState(false);
  const handleSave = async (formData) => {
    if (!movement) return;
    setSaving(true);
    const productRow = formData.products[0];
    const payload = {
      ...formData.commonData,
      product_id: productRow.product.id,
      quantity: productRow.quantity
    };
    delete payload.client_name;
    delete payload.vendor_name;
    try {
      const result = await saveItem(payload);
      if (result) {
        toast.success("Movimiento actualizado con éxito!");
        navigate(getListReturnPath(stockMovementsModuleConfig.baseRoute));
      }
    } finally {
      setSaving(false);
    }
  };
  if (loadingData) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockEditPage.tsx",
    lineNumber: 65,
    columnNumber: 27
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockEditPage.tsx",
    lineNumber: 66,
    columnNumber: 21
  }, this);
  if (!movement) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento no encontrado." }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockEditPage.tsx",
    lineNumber: 67,
    columnNumber: 25
  }, this);
  return /* @__PURE__ */ jsxDEV(
    MovStockFormPage,
    {
      mode: "edit",
      initialData: movement,
      onSubmit: handleSave,
      loading: saving
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/mov_stock/pages/MovStockEditPage.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
};
_s(MovStockEditPage, "4fsYw6IheM6QHRX3ARiNKdd4/MQ=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = MovStockEditPage;
var _c;
$RefreshReg$(_c, "MovStockEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mov_stock/pages/MovStockEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mov_stock/pages/MovStockEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkM0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1QzVCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxtQkFBbUI7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxrQ0FBaUQ7QUFDMUQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHdCQUErQztBQUN4RCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCO0FBRTNCLGFBQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU0sRUFBRUMsR0FBRyxJQUFJVixVQUEwQjtBQUN6QyxRQUFNVyxXQUFXVixZQUFZO0FBRTdCLFFBQU0sRUFBRVcsTUFBTUMsVUFBVUMsU0FBU0MsYUFBYUMsT0FBT0MsU0FBUyxJQUFJYixZQUFzQkQsNEJBQTRCTyxFQUFFO0FBQ3RILFFBQU0sQ0FBQ1EsUUFBUUMsU0FBUyxJQUFJcEIsU0FBUyxLQUFLO0FBRTFDLFFBQU1xQixhQUFhLE9BQU9DLGFBQStCO0FBQ3JELFFBQUksQ0FBQ1IsU0FBVTtBQUNmTSxjQUFVLElBQUk7QUFJZCxVQUFNRyxhQUFhRCxTQUFTRSxTQUFTLENBQUM7QUFFdEMsVUFBTUMsVUFBNkI7QUFBQSxNQUMvQixHQUFHSCxTQUFTSTtBQUFBQSxNQUNaQyxZQUFZSixXQUFXSyxRQUFTakI7QUFBQUEsTUFDaENrQixVQUFVTixXQUFXTTtBQUFBQSxJQUN6QjtBQUVBLFdBQVFKLFFBQWdCSztBQUN4QixXQUFRTCxRQUFnQk07QUFFeEIsUUFBSTtBQUNBLFlBQU1DLFNBQVMsTUFBTWQsU0FBU08sT0FBbUI7QUFDakQsVUFBSU8sUUFBUTtBQUNSN0IsY0FBTThCLFFBQVEsbUNBQW1DO0FBQ2pEckIsaUJBQVNKLGtCQUFrQkosMkJBQTJCOEIsU0FBUyxDQUFDO0FBQUEsTUFDcEU7QUFBQSxJQUNKLFVBQUM7QUFDR2QsZ0JBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDSjtBQUVBLE1BQUlKLFlBQWEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDdkMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0gsU0FBVSxRQUFPLHVCQUFDLFNBQUkseUNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4QjtBQUVwRCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTCxhQUFhQTtBQUFBQSxNQUNiLFVBQVVPO0FBQUFBLE1BQ1YsU0FBU0Y7QUFBQUE7QUFBQUEsSUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJb0I7QUFHNUI7QUFBRVQsR0EvQ1dELGtCQUFnQjtBQUFBLFVBQ1ZSLFdBQ0VDLGFBRWlERyxXQUFXO0FBQUE7QUFBQThCLEtBSnBFMUI7QUFBZ0IsSUFBQTBCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwidG9hc3QiLCJzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiTW92U3RvY2tGb3JtUGFnZSIsIkxvYWRpbmdTcGlubmVyIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJNb3ZTdG9ja0VkaXRQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiaXRlbSIsIm1vdmVtZW50IiwibG9hZGluZyIsImxvYWRpbmdEYXRhIiwiZXJyb3IiLCJzYXZlSXRlbSIsInNhdmluZyIsInNldFNhdmluZyIsImhhbmRsZVNhdmUiLCJmb3JtRGF0YSIsInByb2R1Y3RSb3ciLCJwcm9kdWN0cyIsInBheWxvYWQiLCJjb21tb25EYXRhIiwicHJvZHVjdF9pZCIsInByb2R1Y3QiLCJxdWFudGl0eSIsImNsaWVudF9uYW1lIiwidmVuZG9yX25hbWUiLCJyZXN1bHQiLCJzdWNjZXNzIiwiYmFzZVJvdXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW92U3RvY2tFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLCB0eXBlIE1vdlN0b2NrIH0gZnJvbSAnLi4vbW92U3RvY2suY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgTW92U3RvY2tGb3JtUGFnZSwgdHlwZSBNb3ZTdG9ja0Zvcm1EYXRhIH0gZnJvbSAnLi9Nb3ZTdG9ja0Zvcm1QYWdlJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IE1vdlN0b2NrRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICAvLyBIb29rIHBhcmEgZmV0Y2ggeSBzYXZlXG4gICAgY29uc3QgeyBpdGVtOiBtb3ZlbWVudCwgbG9hZGluZzogbG9hZGluZ0RhdGEsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08TW92U3RvY2s+KHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZm9ybURhdGE6IE1vdlN0b2NrRm9ybURhdGEpID0+IHtcbiAgICAgICAgaWYgKCFtb3ZlbWVudCkgcmV0dXJuO1xuICAgICAgICBzZXRTYXZpbmcodHJ1ZSk7XG5cbiAgICAgICAgLy8gTMOzZ2ljYSBJTkRJVklEVUFMOiBFbiBlZGljacOzbiBzb2xvIGFjdHVhbGl6YW1vcyBlbCBtb3ZpbWllbnRvIGFjdHVhbFxuICAgICAgICAvLyAoQXN1bWltb3MgcXVlIGxhIGdyaWxsYSBzb2xvIHRpZW5lIDEgcHJvZHVjdG8gZW4gZWRpY2nDs24sIHRvbWFtb3MgZWwgcHJpbWVybylcbiAgICAgICAgY29uc3QgcHJvZHVjdFJvdyA9IGZvcm1EYXRhLnByb2R1Y3RzWzBdO1xuXG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IFBhcnRpYWw8TW92U3RvY2s+ID0ge1xuICAgICAgICAgICAgLi4uZm9ybURhdGEuY29tbW9uRGF0YSxcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RSb3cucHJvZHVjdCEuaWQsXG4gICAgICAgICAgICBxdWFudGl0eTogcHJvZHVjdFJvdy5xdWFudGl0eSxcbiAgICAgICAgfTtcblxuICAgICAgICBkZWxldGUgKHBheWxvYWQgYXMgYW55KS5jbGllbnRfbmFtZTtcbiAgICAgICAgZGVsZXRlIChwYXlsb2FkIGFzIGFueSkudmVuZG9yX25hbWU7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHNhdmVJdGVtKHBheWxvYWQgYXMgTW92U3RvY2spO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ01vdmltaWVudG8gYWN0dWFsaXphZG8gY29uIMOpeGl0byEnKTtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmdEYXRhKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIW1vdmVtZW50KSByZXR1cm4gPGRpdj5Nb3ZpbWllbnRvIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPE1vdlN0b2NrRm9ybVBhZ2VcbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXttb3ZlbWVudH1cbiAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbG9hZGluZz17c2F2aW5nfVxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbW92X3N0b2NrL3BhZ2VzL01vdlN0b2NrRWRpdFBhZ2UudHN4In0=