import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  RxDashboard,
  RxArchive,
  RxPerson,
  RxGear,
  RxBackpack,
  RxPieChart,
  RxLayers,
  RxLockClosed,
  RxFileText,
  RxIdCard,
  RxCube,
  RxBox,
  RxShuffle,
  RxScissors,
  RxPaperPlane,
  RxBookmark,
  RxDownload,
  RxClipboard
} from "/node_modules/.vite/deps/react-icons_rx.js?v=cc4fbb62";
import {
  FaTruck,
  FaMoneyBillWave,
  FaUserTie,
  FaUserTag,
  FaShippingFast,
  FaStore,
  FaChartBar
} from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
const ICON_MAP = {
  dashboard: (size = 24) => /* @__PURE__ */ jsxDEV(RxDashboard, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 60,
    columnNumber: 29
  }, this),
  layers: (size = 24) => /* @__PURE__ */ jsxDEV(RxLayers, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 61,
    columnNumber: 26
  }, this),
  archive: (size = 24) => /* @__PURE__ */ jsxDEV(RxArchive, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 62,
    columnNumber: 27
  }, this),
  backpack: (size = 24) => /* @__PURE__ */ jsxDEV(RxBackpack, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 63,
    columnNumber: 28
  }, this),
  box: (size = 24) => /* @__PURE__ */ jsxDEV(RxBox, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 64,
    columnNumber: 23
  }, this),
  pieChart: (size = 24) => /* @__PURE__ */ jsxDEV(RxPieChart, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 65,
    columnNumber: 28
  }, this),
  gear: (size = 24) => /* @__PURE__ */ jsxDEV(RxGear, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 66,
    columnNumber: 24
  }, this),
  chartBar: (size = 24) => /* @__PURE__ */ jsxDEV(FaChartBar, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 67,
    columnNumber: 28
  }, this),
  person: (size = 24) => /* @__PURE__ */ jsxDEV(RxPerson, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 68,
    columnNumber: 26
  }, this),
  lockClosed: (size = 24) => /* @__PURE__ */ jsxDEV(RxLockClosed, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 69,
    columnNumber: 30
  }, this),
  fileText: (size = 24) => /* @__PURE__ */ jsxDEV(RxFileText, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 70,
    columnNumber: 28
  }, this),
  idCard: (size = 24) => /* @__PURE__ */ jsxDEV(RxIdCard, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 71,
    columnNumber: 26
  }, this),
  cube: (size = 24) => /* @__PURE__ */ jsxDEV(RxCube, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 72,
    columnNumber: 24
  }, this),
  shuffle: (size = 24) => /* @__PURE__ */ jsxDEV(RxShuffle, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 73,
    columnNumber: 27
  }, this),
  scissors: (size = 24) => /* @__PURE__ */ jsxDEV(RxScissors, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 74,
    columnNumber: 28
  }, this),
  paperPlane: (size = 24) => /* @__PURE__ */ jsxDEV(RxPaperPlane, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 75,
    columnNumber: 30
  }, this),
  bookmark: (size = 24) => /* @__PURE__ */ jsxDEV(RxBookmark, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 76,
    columnNumber: 28
  }, this),
  download: (size = 24) => /* @__PURE__ */ jsxDEV(RxDownload, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 77,
    columnNumber: 28
  }, this),
  clipboard: (size = 24) => /* @__PURE__ */ jsxDEV(RxClipboard, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 78,
    columnNumber: 29
  }, this),
  truck: (size = 24) => /* @__PURE__ */ jsxDEV(FaTruck, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 79,
    columnNumber: 25
  }, this),
  moneyBillWave: (size = 24) => /* @__PURE__ */ jsxDEV(FaMoneyBillWave, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 80,
    columnNumber: 33
  }, this),
  userTie: (size = 24) => /* @__PURE__ */ jsxDEV(FaUserTie, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 81,
    columnNumber: 27
  }, this),
  userTag: (size = 24) => /* @__PURE__ */ jsxDEV(FaUserTag, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 82,
    columnNumber: 27
  }, this),
  shippingFast: (size = 24) => /* @__PURE__ */ jsxDEV(FaShippingFast, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 83,
    columnNumber: 32
  }, this),
  store: (size = 24) => /* @__PURE__ */ jsxDEV(FaStore, { size }, void 0, false, {
    fileName: "/app/src/config/menuItems.tsx",
    lineNumber: 84,
    columnNumber: 25
  }, this)
};
export function getMenuIcon(key, size = 24) {
  return ICON_MAP[key]?.(size) ?? null;
}
export const MENU_ITEMS = [
  { path: "/dashboard", label: "Dashboard", iconKey: "dashboard" },
  {
    label: "Gestión de Clientes",
    iconKey: "archive",
    children: [
      { path: "/leads", label: "Prospectos", iconKey: "person" },
      { path: "/clientes", label: "Clientes", iconKey: "person" },
      { path: "/facturas-de-venta", label: "Facturas de Venta", iconKey: "archive" },
      { path: "/notas-credito", label: "Notas de Crédito", iconKey: "archive" },
      { path: "/notas-financieras", label: "Notas Financieras", iconKey: "archive" },
      { path: "/pedidos-de-venta", label: "Pedidos de Venta", iconKey: "archive" },
      {
        path: "/autorizacion-pedidos",
        label: "Autorizar pedidos",
        iconKey: "archive",
        description: "Listado de pedidos por autorizar y ya autorizados"
      },
      { path: "/cobranzas", label: "Cobranzas", iconKey: "download" },
      { path: "/remitos", label: "Remitos", iconKey: "shippingFast" },
      { path: "/vendedores", label: "Vendedores", iconKey: "userTie" },
      { path: "/compradores", label: "Compradores", iconKey: "userTag" }
    ]
  },
  {
    label: "Gestión de Proveedores",
    iconKey: "backpack",
    children: [
      { path: "/proveedores", label: "Proveedores", iconKey: "backpack" },
      { path: "/compras", label: "Compras", iconKey: "backpack" },
      //{ path: '/notas-credito-compra', label: 'Notas de Crédito', iconKey: 'archive' },
      { path: "/notas-financieras-compra", label: "Notas Financieras", iconKey: "archive" },
      { path: "/ordenes-de-pago", label: "Órdenes de Pago", iconKey: "paperPlane" }
    ]
  },
  {
    label: "Inventario",
    iconKey: "box",
    children: [
      { path: "/articulos", label: "Artículos", iconKey: "archive" },
      { path: "/mercadolibre-publicaciones", label: "Publicaciones ML", iconKey: "store" },
      { path: "/transportes", label: "Transportes", iconKey: "truck" },
      { path: "/stock/movimientos", label: "Movimientos de Stock", iconKey: "shuffle" },
      { path: "/stock/fraccionamientos", label: "Fraccion/Impresión", iconKey: "scissors" }
    ]
  },
  {
    label: "Finanzas",
    iconKey: "pieChart",
    children: [
      { path: "/bancos", label: "Bancos", iconKey: "idCard" },
      { path: "/cajas", label: "Cajas", iconKey: "cube" },
      { path: "/movimientos-bancos", label: "Movimientos de Banco", iconKey: "shuffle" },
      { path: "/cheques", label: "Cheques Recibidos", iconKey: "fileText" },
      { path: "/monedas", label: "Monedas", iconKey: "moneyBillWave" },
      { path: "/plan-de-cuentas", label: "Plan de Cuentas", iconKey: "fileText" }
    ]
  },
  {
    label: "Configuración",
    iconKey: "gear",
    iconOnly: true,
    children: [
      { path: "/configuracion/usuarios", label: "Usuarios", iconKey: "person" },
      { path: "/configuracion/profiles", label: "Perfiles", iconKey: "lockClosed" },
      { path: "/configuracion/impuestos", label: "Impuestos", iconKey: "bookmark" },
      {
        path: "/configuracion/comisiones-vendedores",
        label: "Comisiones (rentabilidad)",
        iconKey: "chartBar"
      },
      {
        path: "/configuracion/sistema",
        label: "Configuración del sistema",
        iconKey: "gear"
      },
      {
        path: "/configuracion/tablas-accesorias",
        label: "Tablas accesorias",
        iconKey: "bookmark"
      },
      { path: "/listas-de-precios", label: "Listas de Precios", iconKey: "clipboard" }
    ]
  },
  {
    path: "/reportes",
    label: "Reportes",
    iconKey: "chartBar",
    iconOnly: true
  }
];

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkQ4QjtBQTFEOUI7QUFBQSxFQUNJQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1A7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBNkJQLE1BQU1DLFdBQThEO0FBQUEsRUFDaEVDLFdBQVdBLENBQUNDLE9BQU8sT0FBTyx1QkFBQyxlQUFZLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QjtBQUFBLEVBQ2xEQyxRQUFRQSxDQUFDRCxPQUFPLE9BQU8sdUJBQUMsWUFBUyxRQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUI7QUFBQSxFQUM1Q0UsU0FBU0EsQ0FBQ0YsT0FBTyxPQUFPLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNCO0FBQUEsRUFDOUNHLFVBQVVBLENBQUNILE9BQU8sT0FBTyx1QkFBQyxjQUFXLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1QjtBQUFBLEVBQ2hESSxLQUFLQSxDQUFDSixPQUFPLE9BQU8sdUJBQUMsU0FBTSxRQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0I7QUFBQSxFQUN0Q0ssVUFBVUEsQ0FBQ0wsT0FBTyxPQUFPLHVCQUFDLGNBQVcsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVCO0FBQUEsRUFDaERNLE1BQU1BLENBQUNOLE9BQU8sT0FBTyx1QkFBQyxVQUFPLFFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtQjtBQUFBLEVBQ3hDTyxVQUFVQSxDQUFDUCxPQUFPLE9BQU8sdUJBQUMsY0FBVyxRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUI7QUFBQSxFQUNoRFEsUUFBUUEsQ0FBQ1IsT0FBTyxPQUFPLHVCQUFDLFlBQVMsUUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFCO0FBQUEsRUFDNUNTLFlBQVlBLENBQUNULE9BQU8sT0FBTyx1QkFBQyxnQkFBYSxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUI7QUFBQSxFQUNwRFUsVUFBVUEsQ0FBQ1YsT0FBTyxPQUFPLHVCQUFDLGNBQVcsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVCO0FBQUEsRUFDaERXLFFBQVFBLENBQUNYLE9BQU8sT0FBTyx1QkFBQyxZQUFTLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQjtBQUFBLEVBQzVDWSxNQUFNQSxDQUFDWixPQUFPLE9BQU8sdUJBQUMsVUFBTyxRQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUI7QUFBQSxFQUN4Q2EsU0FBU0EsQ0FBQ2IsT0FBTyxPQUFPLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNCO0FBQUEsRUFDOUNjLFVBQVVBLENBQUNkLE9BQU8sT0FBTyx1QkFBQyxjQUFXLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1QjtBQUFBLEVBQ2hEZSxZQUFZQSxDQUFDZixPQUFPLE9BQU8sdUJBQUMsZ0JBQWEsUUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlCO0FBQUEsRUFDcERnQixVQUFVQSxDQUFDaEIsT0FBTyxPQUFPLHVCQUFDLGNBQVcsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVCO0FBQUEsRUFDaERpQixVQUFVQSxDQUFDakIsT0FBTyxPQUFPLHVCQUFDLGNBQVcsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVCO0FBQUEsRUFDaERrQixXQUFXQSxDQUFDbEIsT0FBTyxPQUFPLHVCQUFDLGVBQVksUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdCO0FBQUEsRUFDbERtQixPQUFPQSxDQUFDbkIsT0FBTyxPQUFPLHVCQUFDLFdBQVEsUUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9CO0FBQUEsRUFDMUNvQixlQUFlQSxDQUFDcEIsT0FBTyxPQUFPLHVCQUFDLG1CQUFnQixRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRCO0FBQUEsRUFDMURxQixTQUFTQSxDQUFDckIsT0FBTyxPQUFPLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNCO0FBQUEsRUFDOUNzQixTQUFTQSxDQUFDdEIsT0FBTyxPQUFPLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNCO0FBQUEsRUFDOUN1QixjQUFjQSxDQUFDdkIsT0FBTyxPQUFPLHVCQUFDLGtCQUFlLFFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkI7QUFBQSxFQUN4RHdCLE9BQU9BLENBQUN4QixPQUFPLE9BQU8sdUJBQUMsV0FBUSxRQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0I7QUFDOUM7QUFFTyxnQkFBU3lCLFlBQVlDLEtBQWtCMUIsT0FBTyxJQUFlO0FBQ2hFLFNBQU9GLFNBQVM0QixHQUFHLElBQUkxQixJQUFJLEtBQUs7QUFDcEM7QUFrQk8sYUFBTTJCLGFBQXlCO0FBQUEsRUFDbEMsRUFBRUMsTUFBTSxjQUFjQyxPQUFPLGFBQWFDLFNBQVMsWUFBWTtBQUFBLEVBQy9EO0FBQUEsSUFDSUQsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsTUFDTixFQUFFSCxNQUFNLFVBQVVDLE9BQU8sY0FBY0MsU0FBUyxTQUFTO0FBQUEsTUFDekQsRUFBRUYsTUFBTSxhQUFhQyxPQUFPLFlBQVlDLFNBQVMsU0FBUztBQUFBLE1BQzFELEVBQUVGLE1BQU0sc0JBQXNCQyxPQUFPLHFCQUFxQkMsU0FBUyxVQUFVO0FBQUEsTUFDN0UsRUFBRUYsTUFBTSxrQkFBa0JDLE9BQU8sb0JBQW9CQyxTQUFTLFVBQVU7QUFBQSxNQUN4RSxFQUFFRixNQUFNLHNCQUFzQkMsT0FBTyxxQkFBcUJDLFNBQVMsVUFBVTtBQUFBLE1BQzdFLEVBQUVGLE1BQU0scUJBQXFCQyxPQUFPLG9CQUFvQkMsU0FBUyxVQUFVO0FBQUEsTUFDM0U7QUFBQSxRQUNJRixNQUFNO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNURSxhQUFhO0FBQUEsTUFDakI7QUFBQSxNQUNBLEVBQUVKLE1BQU0sY0FBY0MsT0FBTyxhQUFhQyxTQUFTLFdBQVc7QUFBQSxNQUM5RCxFQUFFRixNQUFNLFlBQVlDLE9BQU8sV0FBV0MsU0FBUyxlQUFlO0FBQUEsTUFDOUQsRUFBRUYsTUFBTSxlQUFlQyxPQUFPLGNBQWNDLFNBQVMsVUFBVTtBQUFBLE1BQy9ELEVBQUVGLE1BQU0sZ0JBQWdCQyxPQUFPLGVBQWVDLFNBQVMsVUFBVTtBQUFBLElBQUM7QUFBQSxFQUUxRTtBQUFBLEVBQ0E7QUFBQSxJQUNJRCxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxNQUNOLEVBQUVILE1BQU0sZ0JBQWdCQyxPQUFPLGVBQWVDLFNBQVMsV0FBVztBQUFBLE1BQ2xFLEVBQUVGLE1BQU0sWUFBWUMsT0FBTyxXQUFXQyxTQUFTLFdBQVc7QUFBQTtBQUFBLE1BRTFELEVBQUVGLE1BQU0sNkJBQTZCQyxPQUFPLHFCQUFxQkMsU0FBUyxVQUFVO0FBQUEsTUFDcEYsRUFBRUYsTUFBTSxvQkFBb0JDLE9BQU8sbUJBQW1CQyxTQUFTLGFBQWE7QUFBQSxJQUFDO0FBQUEsRUFFckY7QUFBQSxFQUNBO0FBQUEsSUFDSUQsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsTUFDTixFQUFFSCxNQUFNLGNBQWNDLE9BQU8sYUFBYUMsU0FBUyxVQUFVO0FBQUEsTUFDN0QsRUFBRUYsTUFBTSwrQkFBK0JDLE9BQU8sb0JBQW9CQyxTQUFTLFFBQVE7QUFBQSxNQUNuRixFQUFFRixNQUFNLGdCQUFnQkMsT0FBTyxlQUFlQyxTQUFTLFFBQVE7QUFBQSxNQUMvRCxFQUFFRixNQUFNLHNCQUFzQkMsT0FBTyx3QkFBd0JDLFNBQVMsVUFBVTtBQUFBLE1BQ2hGLEVBQUVGLE1BQU0sMkJBQTJCQyxPQUFPLHNCQUFzQkMsU0FBUyxXQUFXO0FBQUEsSUFBQztBQUFBLEVBRTdGO0FBQUEsRUFDQTtBQUFBLElBQ0lELE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLE1BQ04sRUFBRUgsTUFBTSxXQUFXQyxPQUFPLFVBQVVDLFNBQVMsU0FBUztBQUFBLE1BQ3RELEVBQUVGLE1BQU0sVUFBVUMsT0FBTyxTQUFTQyxTQUFTLE9BQU87QUFBQSxNQUNsRCxFQUFFRixNQUFNLHVCQUF1QkMsT0FBTyx3QkFBd0JDLFNBQVMsVUFBVTtBQUFBLE1BQ2pGLEVBQUVGLE1BQU0sWUFBWUMsT0FBTyxxQkFBcUJDLFNBQVMsV0FBVztBQUFBLE1BQ3BFLEVBQUVGLE1BQU0sWUFBWUMsT0FBTyxXQUFXQyxTQUFTLGdCQUFnQjtBQUFBLE1BQy9ELEVBQUVGLE1BQU0sb0JBQW9CQyxPQUFPLG1CQUFtQkMsU0FBUyxXQUFXO0FBQUEsSUFBQztBQUFBLEVBRW5GO0FBQUEsRUFDQTtBQUFBLElBQ0lELE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEcsVUFBVTtBQUFBLElBQ1ZGLFVBQVU7QUFBQSxNQUNOLEVBQUVILE1BQU0sMkJBQTJCQyxPQUFPLFlBQVlDLFNBQVMsU0FBUztBQUFBLE1BQ3hFLEVBQUVGLE1BQU0sMkJBQTJCQyxPQUFPLFlBQVlDLFNBQVMsYUFBYTtBQUFBLE1BQzVFLEVBQUVGLE1BQU0sNEJBQTRCQyxPQUFPLGFBQWFDLFNBQVMsV0FBVztBQUFBLE1BQzVFO0FBQUEsUUFDSUYsTUFBTTtBQUFBLFFBQ05DLE9BQU87QUFBQSxRQUNQQyxTQUFTO0FBQUEsTUFDYjtBQUFBLE1BQ0E7QUFBQSxRQUNJRixNQUFNO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxNQUNiO0FBQUEsTUFDQTtBQUFBLFFBQ0lGLE1BQU07QUFBQSxRQUNOQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLE1BQ2I7QUFBQSxNQUNBLEVBQUVGLE1BQU0sc0JBQXNCQyxPQUFPLHFCQUFxQkMsU0FBUyxZQUFZO0FBQUEsSUFBQztBQUFBLEVBRXhGO0FBQUEsRUFDQTtBQUFBLElBQ0lGLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RHLFVBQVU7QUFBQSxFQUNkO0FBQUMiLCJuYW1lcyI6WyJSeERhc2hib2FyZCIsIlJ4QXJjaGl2ZSIsIlJ4UGVyc29uIiwiUnhHZWFyIiwiUnhCYWNrcGFjayIsIlJ4UGllQ2hhcnQiLCJSeExheWVycyIsIlJ4TG9ja0Nsb3NlZCIsIlJ4RmlsZVRleHQiLCJSeElkQ2FyZCIsIlJ4Q3ViZSIsIlJ4Qm94IiwiUnhTaHVmZmxlIiwiUnhTY2lzc29ycyIsIlJ4UGFwZXJQbGFuZSIsIlJ4Qm9va21hcmsiLCJSeERvd25sb2FkIiwiUnhDbGlwYm9hcmQiLCJGYVRydWNrIiwiRmFNb25leUJpbGxXYXZlIiwiRmFVc2VyVGllIiwiRmFVc2VyVGFnIiwiRmFTaGlwcGluZ0Zhc3QiLCJGYVN0b3JlIiwiRmFDaGFydEJhciIsIklDT05fTUFQIiwiZGFzaGJvYXJkIiwic2l6ZSIsImxheWVycyIsImFyY2hpdmUiLCJiYWNrcGFjayIsImJveCIsInBpZUNoYXJ0IiwiZ2VhciIsImNoYXJ0QmFyIiwicGVyc29uIiwibG9ja0Nsb3NlZCIsImZpbGVUZXh0IiwiaWRDYXJkIiwiY3ViZSIsInNodWZmbGUiLCJzY2lzc29ycyIsInBhcGVyUGxhbmUiLCJib29rbWFyayIsImRvd25sb2FkIiwiY2xpcGJvYXJkIiwidHJ1Y2siLCJtb25leUJpbGxXYXZlIiwidXNlclRpZSIsInVzZXJUYWciLCJzaGlwcGluZ0Zhc3QiLCJzdG9yZSIsImdldE1lbnVJY29uIiwia2V5IiwiTUVOVV9JVEVNUyIsInBhdGgiLCJsYWJlbCIsImljb25LZXkiLCJjaGlsZHJlbiIsImRlc2NyaXB0aW9uIiwiaWNvbk9ubHkiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWVudUl0ZW1zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gICAgUnhEYXNoYm9hcmQsXG4gICAgUnhBcmNoaXZlLFxuICAgIFJ4UGVyc29uLFxuICAgIFJ4R2VhcixcbiAgICBSeEJhY2twYWNrLFxuICAgIFJ4UGllQ2hhcnQsXG4gICAgUnhMYXllcnMsXG4gICAgUnhMb2NrQ2xvc2VkLFxuICAgIFJ4RmlsZVRleHQsXG4gICAgUnhJZENhcmQsXG4gICAgUnhDdWJlLFxuICAgIFJ4Qm94LFxuICAgIFJ4U2h1ZmZsZSxcbiAgICBSeFNjaXNzb3JzLFxuICAgIFJ4UGFwZXJQbGFuZSxcbiAgICBSeEJvb2ttYXJrLFxuICAgIFJ4RG93bmxvYWQsXG4gICAgUnhDbGlwYm9hcmQsXG59IGZyb20gJ3JlYWN0LWljb25zL3J4JztcbmltcG9ydCB7XG4gICAgRmFUcnVjayxcbiAgICBGYU1vbmV5QmlsbFdhdmUsXG4gICAgRmFVc2VyVGllLFxuICAgIEZhVXNlclRhZyxcbiAgICBGYVNoaXBwaW5nRmFzdCxcbiAgICBGYVN0b3JlLFxuICAgIEZhQ2hhcnRCYXIsXG59IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcblxuZXhwb3J0IHR5cGUgTWVudUljb25LZXkgPVxuICAgIHwgJ2Rhc2hib2FyZCdcbiAgICB8ICdsYXllcnMnXG4gICAgfCAnYXJjaGl2ZSdcbiAgICB8ICdiYWNrcGFjaydcbiAgICB8ICdib3gnXG4gICAgfCAncGllQ2hhcnQnXG4gICAgfCAnZ2VhcidcbiAgICB8ICdjaGFydEJhcidcbiAgICB8ICdwZXJzb24nXG4gICAgfCAnbG9ja0Nsb3NlZCdcbiAgICB8ICdmaWxlVGV4dCdcbiAgICB8ICdpZENhcmQnXG4gICAgfCAnY3ViZSdcbiAgICB8ICdzaHVmZmxlJ1xuICAgIHwgJ3NjaXNzb3JzJ1xuICAgIHwgJ3BhcGVyUGxhbmUnXG4gICAgfCAnYm9va21hcmsnXG4gICAgfCAnZG93bmxvYWQnXG4gICAgfCAnY2xpcGJvYXJkJ1xuICAgIHwgJ3RydWNrJ1xuICAgIHwgJ21vbmV5QmlsbFdhdmUnXG4gICAgfCAndXNlclRpZSdcbiAgICB8ICd1c2VyVGFnJ1xuICAgIHwgJ3NoaXBwaW5nRmFzdCdcbiAgICB8ICdzdG9yZSc7XG5cbmNvbnN0IElDT05fTUFQOiBSZWNvcmQ8TWVudUljb25LZXksIChzaXplPzogbnVtYmVyKSA9PiBSZWFjdE5vZGU+ID0ge1xuICAgIGRhc2hib2FyZDogKHNpemUgPSAyNCkgPT4gPFJ4RGFzaGJvYXJkIHNpemU9e3NpemV9IC8+LFxuICAgIGxheWVyczogKHNpemUgPSAyNCkgPT4gPFJ4TGF5ZXJzIHNpemU9e3NpemV9IC8+LFxuICAgIGFyY2hpdmU6IChzaXplID0gMjQpID0+IDxSeEFyY2hpdmUgc2l6ZT17c2l6ZX0gLz4sXG4gICAgYmFja3BhY2s6IChzaXplID0gMjQpID0+IDxSeEJhY2twYWNrIHNpemU9e3NpemV9IC8+LFxuICAgIGJveDogKHNpemUgPSAyNCkgPT4gPFJ4Qm94IHNpemU9e3NpemV9IC8+LFxuICAgIHBpZUNoYXJ0OiAoc2l6ZSA9IDI0KSA9PiA8UnhQaWVDaGFydCBzaXplPXtzaXplfSAvPixcbiAgICBnZWFyOiAoc2l6ZSA9IDI0KSA9PiA8UnhHZWFyIHNpemU9e3NpemV9IC8+LFxuICAgIGNoYXJ0QmFyOiAoc2l6ZSA9IDI0KSA9PiA8RmFDaGFydEJhciBzaXplPXtzaXplfSAvPixcbiAgICBwZXJzb246IChzaXplID0gMjQpID0+IDxSeFBlcnNvbiBzaXplPXtzaXplfSAvPixcbiAgICBsb2NrQ2xvc2VkOiAoc2l6ZSA9IDI0KSA9PiA8UnhMb2NrQ2xvc2VkIHNpemU9e3NpemV9IC8+LFxuICAgIGZpbGVUZXh0OiAoc2l6ZSA9IDI0KSA9PiA8UnhGaWxlVGV4dCBzaXplPXtzaXplfSAvPixcbiAgICBpZENhcmQ6IChzaXplID0gMjQpID0+IDxSeElkQ2FyZCBzaXplPXtzaXplfSAvPixcbiAgICBjdWJlOiAoc2l6ZSA9IDI0KSA9PiA8UnhDdWJlIHNpemU9e3NpemV9IC8+LFxuICAgIHNodWZmbGU6IChzaXplID0gMjQpID0+IDxSeFNodWZmbGUgc2l6ZT17c2l6ZX0gLz4sXG4gICAgc2Npc3NvcnM6IChzaXplID0gMjQpID0+IDxSeFNjaXNzb3JzIHNpemU9e3NpemV9IC8+LFxuICAgIHBhcGVyUGxhbmU6IChzaXplID0gMjQpID0+IDxSeFBhcGVyUGxhbmUgc2l6ZT17c2l6ZX0gLz4sXG4gICAgYm9va21hcms6IChzaXplID0gMjQpID0+IDxSeEJvb2ttYXJrIHNpemU9e3NpemV9IC8+LFxuICAgIGRvd25sb2FkOiAoc2l6ZSA9IDI0KSA9PiA8UnhEb3dubG9hZCBzaXplPXtzaXplfSAvPixcbiAgICBjbGlwYm9hcmQ6IChzaXplID0gMjQpID0+IDxSeENsaXBib2FyZCBzaXplPXtzaXplfSAvPixcbiAgICB0cnVjazogKHNpemUgPSAyNCkgPT4gPEZhVHJ1Y2sgc2l6ZT17c2l6ZX0gLz4sXG4gICAgbW9uZXlCaWxsV2F2ZTogKHNpemUgPSAyNCkgPT4gPEZhTW9uZXlCaWxsV2F2ZSBzaXplPXtzaXplfSAvPixcbiAgICB1c2VyVGllOiAoc2l6ZSA9IDI0KSA9PiA8RmFVc2VyVGllIHNpemU9e3NpemV9IC8+LFxuICAgIHVzZXJUYWc6IChzaXplID0gMjQpID0+IDxGYVVzZXJUYWcgc2l6ZT17c2l6ZX0gLz4sXG4gICAgc2hpcHBpbmdGYXN0OiAoc2l6ZSA9IDI0KSA9PiA8RmFTaGlwcGluZ0Zhc3Qgc2l6ZT17c2l6ZX0gLz4sXG4gICAgc3RvcmU6IChzaXplID0gMjQpID0+IDxGYVN0b3JlIHNpemU9e3NpemV9IC8+LFxufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGdldE1lbnVJY29uKGtleTogTWVudUljb25LZXksIHNpemUgPSAyNCk6IFJlYWN0Tm9kZSB7XG4gICAgcmV0dXJuIElDT05fTUFQW2tleV0/LihzaXplKSA/PyBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1lbnVJdGVtQ2hpbGQge1xuICAgIHBhdGg6IHN0cmluZztcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIGljb25LZXk6IE1lbnVJY29uS2V5O1xuICAgIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1lbnVJdGVtIHtcbiAgICBwYXRoPzogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgaWNvbktleTogTWVudUljb25LZXk7XG4gICAgY2hpbGRyZW4/OiBNZW51SXRlbUNoaWxkW107XG4gICAgLyoqIElmIHRydWUsIHNob3cgb25seSBhcyBpY29uIGluIG5hdmJhciAoZS5nLiBDb25maWd1cmFjacOzbiwgUmVwb3J0ZXMpICovXG4gICAgaWNvbk9ubHk/OiBib29sZWFuO1xufVxuXG5leHBvcnQgY29uc3QgTUVOVV9JVEVNUzogTWVudUl0ZW1bXSA9IFtcbiAgICB7IHBhdGg6ICcvZGFzaGJvYXJkJywgbGFiZWw6ICdEYXNoYm9hcmQnLCBpY29uS2V5OiAnZGFzaGJvYXJkJyB9LFxuICAgIHtcbiAgICAgICAgbGFiZWw6ICdHZXN0acOzbiBkZSBDbGllbnRlcycsXG4gICAgICAgIGljb25LZXk6ICdhcmNoaXZlJyxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHsgcGF0aDogJy9sZWFkcycsIGxhYmVsOiAnUHJvc3BlY3RvcycsIGljb25LZXk6ICdwZXJzb24nIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvY2xpZW50ZXMnLCBsYWJlbDogJ0NsaWVudGVzJywgaWNvbktleTogJ3BlcnNvbicgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9mYWN0dXJhcy1kZS12ZW50YScsIGxhYmVsOiAnRmFjdHVyYXMgZGUgVmVudGEnLCBpY29uS2V5OiAnYXJjaGl2ZScgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9ub3Rhcy1jcmVkaXRvJywgbGFiZWw6ICdOb3RhcyBkZSBDcsOpZGl0bycsIGljb25LZXk6ICdhcmNoaXZlJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL25vdGFzLWZpbmFuY2llcmFzJywgbGFiZWw6ICdOb3RhcyBGaW5hbmNpZXJhcycsIGljb25LZXk6ICdhcmNoaXZlJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL3BlZGlkb3MtZGUtdmVudGEnLCBsYWJlbDogJ1BlZGlkb3MgZGUgVmVudGEnLCBpY29uS2V5OiAnYXJjaGl2ZScgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwYXRoOiAnL2F1dG9yaXphY2lvbi1wZWRpZG9zJyxcbiAgICAgICAgICAgICAgICBsYWJlbDogJ0F1dG9yaXphciBwZWRpZG9zJyxcbiAgICAgICAgICAgICAgICBpY29uS2V5OiAnYXJjaGl2ZScsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdMaXN0YWRvIGRlIHBlZGlkb3MgcG9yIGF1dG9yaXphciB5IHlhIGF1dG9yaXphZG9zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvY29icmFuemFzJywgbGFiZWw6ICdDb2JyYW56YXMnLCBpY29uS2V5OiAnZG93bmxvYWQnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvcmVtaXRvcycsIGxhYmVsOiAnUmVtaXRvcycsIGljb25LZXk6ICdzaGlwcGluZ0Zhc3QnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvdmVuZGVkb3JlcycsIGxhYmVsOiAnVmVuZGVkb3JlcycsIGljb25LZXk6ICd1c2VyVGllJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL2NvbXByYWRvcmVzJywgbGFiZWw6ICdDb21wcmFkb3JlcycsIGljb25LZXk6ICd1c2VyVGFnJyB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBsYWJlbDogJ0dlc3Rpw7NuIGRlIFByb3ZlZWRvcmVzJyxcbiAgICAgICAgaWNvbktleTogJ2JhY2twYWNrJyxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHsgcGF0aDogJy9wcm92ZWVkb3JlcycsIGxhYmVsOiAnUHJvdmVlZG9yZXMnLCBpY29uS2V5OiAnYmFja3BhY2snIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvY29tcHJhcycsIGxhYmVsOiAnQ29tcHJhcycsIGljb25LZXk6ICdiYWNrcGFjaycgfSxcbiAgICAgICAgICAgIC8veyBwYXRoOiAnL25vdGFzLWNyZWRpdG8tY29tcHJhJywgbGFiZWw6ICdOb3RhcyBkZSBDcsOpZGl0bycsIGljb25LZXk6ICdhcmNoaXZlJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL25vdGFzLWZpbmFuY2llcmFzLWNvbXByYScsIGxhYmVsOiAnTm90YXMgRmluYW5jaWVyYXMnLCBpY29uS2V5OiAnYXJjaGl2ZScgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9vcmRlbmVzLWRlLXBhZ28nLCBsYWJlbDogJ8OTcmRlbmVzIGRlIFBhZ28nLCBpY29uS2V5OiAncGFwZXJQbGFuZScgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbGFiZWw6ICdJbnZlbnRhcmlvJyxcbiAgICAgICAgaWNvbktleTogJ2JveCcsXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7IHBhdGg6ICcvYXJ0aWN1bG9zJywgbGFiZWw6ICdBcnTDrWN1bG9zJywgaWNvbktleTogJ2FyY2hpdmUnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvbWVyY2Fkb2xpYnJlLXB1YmxpY2FjaW9uZXMnLCBsYWJlbDogJ1B1YmxpY2FjaW9uZXMgTUwnLCBpY29uS2V5OiAnc3RvcmUnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvdHJhbnNwb3J0ZXMnLCBsYWJlbDogJ1RyYW5zcG9ydGVzJywgaWNvbktleTogJ3RydWNrJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL3N0b2NrL21vdmltaWVudG9zJywgbGFiZWw6ICdNb3ZpbWllbnRvcyBkZSBTdG9jaycsIGljb25LZXk6ICdzaHVmZmxlJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL3N0b2NrL2ZyYWNjaW9uYW1pZW50b3MnLCBsYWJlbDogJ0ZyYWNjaW9uL0ltcHJlc2nDs24nLCBpY29uS2V5OiAnc2Npc3NvcnMnIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGxhYmVsOiAnRmluYW56YXMnLFxuICAgICAgICBpY29uS2V5OiAncGllQ2hhcnQnLFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgeyBwYXRoOiAnL2JhbmNvcycsIGxhYmVsOiAnQmFuY29zJywgaWNvbktleTogJ2lkQ2FyZCcgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9jYWphcycsIGxhYmVsOiAnQ2FqYXMnLCBpY29uS2V5OiAnY3ViZScgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9tb3ZpbWllbnRvcy1iYW5jb3MnLCBsYWJlbDogJ01vdmltaWVudG9zIGRlIEJhbmNvJywgaWNvbktleTogJ3NodWZmbGUnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvY2hlcXVlcycsIGxhYmVsOiAnQ2hlcXVlcyBSZWNpYmlkb3MnLCBpY29uS2V5OiAnZmlsZVRleHQnIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvbW9uZWRhcycsIGxhYmVsOiAnTW9uZWRhcycsIGljb25LZXk6ICdtb25leUJpbGxXYXZlJyB9LFxuICAgICAgICAgICAgeyBwYXRoOiAnL3BsYW4tZGUtY3VlbnRhcycsIGxhYmVsOiAnUGxhbiBkZSBDdWVudGFzJywgaWNvbktleTogJ2ZpbGVUZXh0JyB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBsYWJlbDogJ0NvbmZpZ3VyYWNpw7NuJyxcbiAgICAgICAgaWNvbktleTogJ2dlYXInLFxuICAgICAgICBpY29uT25seTogdHJ1ZSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHsgcGF0aDogJy9jb25maWd1cmFjaW9uL3VzdWFyaW9zJywgbGFiZWw6ICdVc3VhcmlvcycsIGljb25LZXk6ICdwZXJzb24nIH0sXG4gICAgICAgICAgICB7IHBhdGg6ICcvY29uZmlndXJhY2lvbi9wcm9maWxlcycsIGxhYmVsOiAnUGVyZmlsZXMnLCBpY29uS2V5OiAnbG9ja0Nsb3NlZCcgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9jb25maWd1cmFjaW9uL2ltcHVlc3RvcycsIGxhYmVsOiAnSW1wdWVzdG9zJywgaWNvbktleTogJ2Jvb2ttYXJrJyB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6ICcvY29uZmlndXJhY2lvbi9jb21pc2lvbmVzLXZlbmRlZG9yZXMnLFxuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ29taXNpb25lcyAocmVudGFiaWxpZGFkKScsXG4gICAgICAgICAgICAgICAgaWNvbktleTogJ2NoYXJ0QmFyJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aDogJy9jb25maWd1cmFjaW9uL3Npc3RlbWEnLFxuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ29uZmlndXJhY2nDs24gZGVsIHNpc3RlbWEnLFxuICAgICAgICAgICAgICAgIGljb25LZXk6ICdnZWFyJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aDogJy9jb25maWd1cmFjaW9uL3RhYmxhcy1hY2Nlc29yaWFzJyxcbiAgICAgICAgICAgICAgICBsYWJlbDogJ1RhYmxhcyBhY2Nlc29yaWFzJyxcbiAgICAgICAgICAgICAgICBpY29uS2V5OiAnYm9va21hcmsnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHsgcGF0aDogJy9saXN0YXMtZGUtcHJlY2lvcycsIGxhYmVsOiAnTGlzdGFzIGRlIFByZWNpb3MnLCBpY29uS2V5OiAnY2xpcGJvYXJkJyB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBwYXRoOiAnL3JlcG9ydGVzJyxcbiAgICAgICAgbGFiZWw6ICdSZXBvcnRlcycsXG4gICAgICAgIGljb25LZXk6ICdjaGFydEJhcicsXG4gICAgICAgIGljb25Pbmx5OiB0cnVlLFxuICAgIH0sXG5dO1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb25maWcvbWVudUl0ZW1zLnRzeCJ9