import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/proveedores/pages/ProveedoresFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/proveedores/pages/ProveedoresFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { GenericFormWithTaxes } from "/src/components/common/GenericFormWithTaxes.tsx";
const PROVEEDOR_TAX_TYPE_GROUPS = [
  { type: 1, label: "Impuestos" },
  { type: 3, label: "Retenciones", queryOverrides: { positive_rate_only: "1" } }
];
export const ProveedoresFormPage = ({ mode, initialData, loading: loadingItem, error: errorItem }) => {
  return /* @__PURE__ */ jsxDEV(
    GenericFormWithTaxes,
    {
      mode,
      moduleConfig: proveedoresModuleConfig,
      taxFilterQuery: {},
      taxTypeGroups: PROVEEDOR_TAX_TYPE_GROUPS,
      taxBlockTitle: "Impuestos y Retenciones del Proveedor",
      initialData,
      loadingItem,
      errorItem
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/proveedores/pages/ProveedoresFormPage.tsx",
      lineNumber: 41,
      columnNumber: 5
    },
    this
  );
};
_c = ProveedoresFormPage;
var _c;
$RefreshReg$(_c, "ProveedoresFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/proveedores/pages/ProveedoresFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/proveedores/pages/ProveedoresFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJSLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsK0JBQStDO0FBQ3hELFNBQVNDLDRCQUE0QjtBQUdyQyxNQUFNQyw0QkFBNEM7QUFBQSxFQUM5QyxFQUFFQyxNQUFNLEdBQUdDLE9BQU8sWUFBWTtBQUFBLEVBQzlCLEVBQUVELE1BQU0sR0FBR0MsT0FBTyxlQUFlQyxnQkFBZ0IsRUFBRUMsb0JBQW9CLElBQUksRUFBRTtBQUFDO0FBVzNFLGFBQU1DLHNCQUEwREEsQ0FBQyxFQUFFQyxNQUFNQyxhQUFhQyxTQUFTQyxhQUFhQyxPQUFPQyxVQUFVLE1BQU07QUFDdEksU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0c7QUFBQSxNQUNBLGNBQWNiO0FBQUFBLE1BQ2QsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixlQUFlRTtBQUFBQSxNQUNmLGVBQWM7QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLElBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUXlCO0FBR2pDO0FBQUVZLEtBYldQO0FBQXVELElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIiwiR2VuZXJpY0Zvcm1XaXRoVGF4ZXMiLCJQUk9WRUVET1JfVEFYX1RZUEVfR1JPVVBTIiwidHlwZSIsImxhYmVsIiwicXVlcnlPdmVycmlkZXMiLCJwb3NpdGl2ZV9yYXRlX29ubHkiLCJQcm92ZWVkb3Jlc0Zvcm1QYWdlIiwibW9kZSIsImluaXRpYWxEYXRhIiwibG9hZGluZyIsImxvYWRpbmdJdGVtIiwiZXJyb3IiLCJlcnJvckl0ZW0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm92ZWVkb3Jlc0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNGb3JtUGFnZS50c3hcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBQcm92ZWVkb3IgfSBmcm9tICcuLi9wcm92ZWVkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1XaXRoVGF4ZXMgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVdpdGhUYXhlcyc7XG5pbXBvcnQgdHlwZSB7IFRheFR5cGVHcm91cCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1RheFNlbGVjdGlvbkJsb2NrJztcblxuY29uc3QgUFJPVkVFRE9SX1RBWF9UWVBFX0dST1VQUzogVGF4VHlwZUdyb3VwW10gPSBbXG4gICAgeyB0eXBlOiAxLCBsYWJlbDogJ0ltcHVlc3RvcycgfSxcbiAgICB7IHR5cGU6IDMsIGxhYmVsOiAnUmV0ZW5jaW9uZXMnLCBxdWVyeU92ZXJyaWRlczogeyBwb3NpdGl2ZV9yYXRlX29ubHk6ICcxJyB9IH0sXG5dO1xuXG4vLyBQcm9wcyBxdWUgcmVjaWJlIGRlIENyZWF0ZVBhZ2UgbyBFZGl0UGFnZVxuaW50ZXJmYWNlIFByb3ZlZWRvcmVzRm9ybVBhZ2VQcm9wcyB7XG4gICAgbW9kZTogJ2NyZWF0ZScgfCAnZWRpdCc7XG4gICAgaW5pdGlhbERhdGE/OiBQcm92ZWVkb3I7XG4gICAgbG9hZGluZz86IGJvb2xlYW47XG4gICAgZXJyb3I/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgY29uc3QgUHJvdmVlZG9yZXNGb3JtUGFnZTogUmVhY3QuRkM8UHJvdmVlZG9yZXNGb3JtUGFnZVByb3BzPiA9ICh7IG1vZGUsIGluaXRpYWxEYXRhLCBsb2FkaW5nOiBsb2FkaW5nSXRlbSwgZXJyb3I6IGVycm9ySXRlbSB9KSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtV2l0aFRheGVzPFByb3ZlZWRvcj5cbiAgICAgICAgICAgIG1vZGU9e21vZGV9XG4gICAgICAgICAgICBtb2R1bGVDb25maWc9e3Byb3ZlZWRvcmVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgdGF4RmlsdGVyUXVlcnk9e3t9fVxuICAgICAgICAgICAgdGF4VHlwZUdyb3Vwcz17UFJPVkVFRE9SX1RBWF9UWVBFX0dST1VQU31cbiAgICAgICAgICAgIHRheEJsb2NrVGl0bGU9XCJJbXB1ZXN0b3MgeSBSZXRlbmNpb25lcyBkZWwgUHJvdmVlZG9yXCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsRGF0YSF9XG4gICAgICAgICAgICBsb2FkaW5nSXRlbT17bG9hZGluZ0l0ZW19XG4gICAgICAgICAgICBlcnJvckl0ZW09e2Vycm9ySXRlbX1cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3Byb3ZlZWRvcmVzL3BhZ2VzL1Byb3ZlZWRvcmVzRm9ybVBhZ2UudHN4In0=