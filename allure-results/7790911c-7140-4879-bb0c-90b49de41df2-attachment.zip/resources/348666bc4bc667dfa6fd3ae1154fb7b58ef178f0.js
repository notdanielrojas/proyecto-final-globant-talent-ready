import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/AutocompleteDropdown.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/AutocompleteDropdown.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=cc4fbb62"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
export const AutocompleteDropdown = ({
  items,
  isOpen,
  onSelect,
  onClose,
  renderItem,
  selectedIndex,
  loading = false,
  emptyMessage = "No se encontraron resultados",
  triggerElement
}) => {
  _s();
  const dropdownRef = useRef(null);
  const itemRefs = useRef([]);
  const [position, setPosition] = useState({ top: 0, left: 0, width: 0 });
  useEffect(() => {
    if (isOpen && triggerElement) {
      const rect = triggerElement.getBoundingClientRect();
      setPosition({
        top: rect.bottom + window.scrollY + 4,
        // 4px de margen
        left: rect.left + window.scrollX,
        width: rect.width * 1.5
      });
    }
  }, [isOpen, triggerElement]);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        if (triggerElement && !triggerElement.contains(event.target)) {
          onClose();
        }
      }
    };
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen, onClose, triggerElement]);
  useEffect(() => {
    if (selectedIndex >= 0 && itemRefs.current[selectedIndex]) {
      itemRefs.current[selectedIndex]?.scrollIntoView({
        block: "nearest",
        behavior: "smooth"
      });
    }
  }, [selectedIndex]);
  if (!isOpen) return null;
  const dropdownContent = /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: dropdownRef,
      className: "fixed bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto z-[9999]",
      style: {
        top: `${position.top}px`,
        left: `${position.left}px`,
        width: `${position.width}px`
      },
      children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2 text-sm text-gray-500", children: "Buscando..." }, void 0, false, {
        fileName: "/app/src/components/common/AutocompleteDropdown.tsx",
        lineNumber: 104,
        columnNumber: 5
      }, this) : items.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2 text-sm text-gray-500", children: emptyMessage }, void 0, false, {
        fileName: "/app/src/components/common/AutocompleteDropdown.tsx",
        lineNumber: 106,
        columnNumber: 5
      }, this) : items.map(
        (item, index) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: (el) => {
              itemRefs.current[index] = el;
            },
            onClick: (e) => {
              e.preventDefault();
              e.stopPropagation();
              onSelect(item);
              onClose();
            },
            className: `px-4 py-2 cursor-pointer text-sm hover:bg-indigo-50 ${index === selectedIndex ? "bg-indigo-100" : ""}`,
            children: renderItem(item)
          },
          item.id,
          false,
          {
            fileName: "/app/src/components/common/AutocompleteDropdown.tsx",
            lineNumber: 109,
            columnNumber: 5
          },
          this
        )
      )
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/AutocompleteDropdown.tsx",
      lineNumber: 94,
      columnNumber: 3
    },
    this
  );
  return createPortal(dropdownContent, document.body);
};
_s(AutocompleteDropdown, "L1brgIwqZ7SHKfmrlv7bCLVD7ao=");
_c = AutocompleteDropdown;
var _c;
$RefreshReg$(_c, "AutocompleteDropdown");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/AutocompleteDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/AutocompleteDropdown.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRmhCLFNBQVNBLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUM1QyxTQUFTQyxvQkFBb0I7QUFjdEIsYUFBTUMsdUJBQXVCLENBQW9DO0FBQUEsRUFDcEVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxlQUFlO0FBQUEsRUFDZkM7QUFDMEIsTUFBTTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU1DLGNBQWNkLE9BQXVCLElBQUk7QUFDL0MsUUFBTWUsV0FBV2YsT0FBa0MsRUFBRTtBQUNyRCxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUVpQixLQUFLLEdBQUdDLE1BQU0sR0FBR0MsT0FBTyxFQUFFLENBQUM7QUFHdEVyQixZQUFVLE1BQU07QUFDWixRQUFJTSxVQUFVTyxnQkFBZ0I7QUFDMUIsWUFBTVMsT0FBT1QsZUFBZVUsc0JBQXNCO0FBQ2xETCxrQkFBWTtBQUFBLFFBQ1JDLEtBQUtHLEtBQUtFLFNBQVNDLE9BQU9DLFVBQVU7QUFBQTtBQUFBLFFBQ3BDTixNQUFNRSxLQUFLRixPQUFPSyxPQUFPRTtBQUFBQSxRQUN6Qk4sT0FBT0MsS0FBS0QsUUFBUTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNMO0FBQUEsRUFDSixHQUFHLENBQUNmLFFBQVFPLGNBQWMsQ0FBQztBQUczQmIsWUFBVSxNQUFNO0FBQ1osVUFBTTRCLHFCQUFxQkEsQ0FBQ0MsVUFBc0I7QUFDOUMsVUFBSWQsWUFBWWUsV0FBVyxDQUFDZixZQUFZZSxRQUFRQyxTQUFTRixNQUFNRyxNQUFjLEdBQUc7QUFDNUUsWUFBSW5CLGtCQUFrQixDQUFDQSxlQUFla0IsU0FBU0YsTUFBTUcsTUFBYyxHQUFHO0FBQ2xFeEIsa0JBQVE7QUFBQSxRQUNaO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxRQUFJRixRQUFRO0FBQ1IyQixlQUFTQyxpQkFBaUIsYUFBYU4sa0JBQWtCO0FBQUEsSUFDN0Q7QUFFQSxXQUFPLE1BQU07QUFDVEssZUFBU0Usb0JBQW9CLGFBQWFQLGtCQUFrQjtBQUFBLElBQ2hFO0FBQUEsRUFDSixHQUFHLENBQUN0QixRQUFRRSxTQUFTSyxjQUFjLENBQUM7QUFHcENiLFlBQVUsTUFBTTtBQUNaLFFBQUlVLGlCQUFpQixLQUFLTSxTQUFTYyxRQUFRcEIsYUFBYSxHQUFHO0FBQ3ZETSxlQUFTYyxRQUFRcEIsYUFBYSxHQUFHMEIsZUFBZTtBQUFBLFFBQzVDQyxPQUFPO0FBQUEsUUFDUEMsVUFBVTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKLEdBQUcsQ0FBQzVCLGFBQWEsQ0FBQztBQUVsQixNQUFJLENBQUNKLE9BQVEsUUFBTztBQUVwQixRQUFNaUMsa0JBQ0Y7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLEtBQUt4QjtBQUFBQSxNQUNMLFdBQVU7QUFBQSxNQUNWLE9BQU87QUFBQSxRQUNISSxLQUFLLEdBQUdGLFNBQVNFLEdBQUc7QUFBQSxRQUNwQkMsTUFBTSxHQUFHSCxTQUFTRyxJQUFJO0FBQUEsUUFDdEJDLE9BQU8sR0FBR0osU0FBU0ksS0FBSztBQUFBLE1BQzVCO0FBQUEsTUFFQ1Ysb0JBQ0csdUJBQUMsU0FBSSxXQUFVLG1DQUFrQywyQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RCxJQUM1RE4sTUFBTW1DLFdBQVcsSUFDakIsdUJBQUMsU0FBSSxXQUFVLG1DQUFtQzVCLDBCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELElBRS9EUCxNQUFNb0M7QUFBQUEsUUFBSSxDQUFDQyxNQUFNQyxVQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFRyxLQUFLLENBQUNDLE9BQU87QUFBRTVCLHVCQUFTYyxRQUFRYSxLQUFLLElBQUlDO0FBQUFBLFlBQUk7QUFBQSxZQUM3QyxTQUFTLENBQUNDLE1BQU07QUFDWkEsZ0JBQUVDLGVBQWU7QUFDakJELGdCQUFFRSxnQkFBZ0I7QUFDbEJ4Qyx1QkFBU21DLElBQUk7QUFDYmxDLHNCQUFRO0FBQUEsWUFDWjtBQUFBLFlBQ0EsV0FBVyx1REFBdURtQyxVQUFVakMsZ0JBQWdCLGtCQUFrQixFQUFFO0FBQUEsWUFHL0dELHFCQUFXaUMsSUFBSTtBQUFBO0FBQUEsVUFYWEEsS0FBS007QUFBQUEsVUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxNQUNIO0FBQUE7QUFBQSxJQTdCVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErQkE7QUFJSixTQUFPN0MsYUFBYW9DLGlCQUFpQk4sU0FBU2dCLElBQUk7QUFDdEQ7QUFBRW5DLEdBL0ZXVixzQkFBb0I7QUFBQThDLEtBQXBCOUM7QUFBb0IsSUFBQThDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsImNyZWF0ZVBvcnRhbCIsIkF1dG9jb21wbGV0ZURyb3Bkb3duIiwiaXRlbXMiLCJpc09wZW4iLCJvblNlbGVjdCIsIm9uQ2xvc2UiLCJyZW5kZXJJdGVtIiwic2VsZWN0ZWRJbmRleCIsImxvYWRpbmciLCJlbXB0eU1lc3NhZ2UiLCJ0cmlnZ2VyRWxlbWVudCIsIl9zIiwiZHJvcGRvd25SZWYiLCJpdGVtUmVmcyIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJ0b3AiLCJsZWZ0Iiwid2lkdGgiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwiYm90dG9tIiwid2luZG93Iiwic2Nyb2xsWSIsInNjcm9sbFgiLCJoYW5kbGVDbGlja091dHNpZGUiLCJldmVudCIsImN1cnJlbnQiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJzY3JvbGxJbnRvVmlldyIsImJsb2NrIiwiYmVoYXZpb3IiLCJkcm9wZG93bkNvbnRlbnQiLCJsZW5ndGgiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJlbCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInN0b3BQcm9wYWdhdGlvbiIsImlkIiwiYm9keSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1dG9jb21wbGV0ZURyb3Bkb3duLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVQb3J0YWwgfSBmcm9tICdyZWFjdC1kb20nO1xuXG5pbnRlcmZhY2UgQXV0b2NvbXBsZXRlRHJvcGRvd25Qcm9wczxUPiB7XG4gICAgaXRlbXM6IFRbXTtcbiAgICBpc09wZW46IGJvb2xlYW47XG4gICAgb25TZWxlY3Q6IChpdGVtOiBUKSA9PiB2b2lkO1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gICAgcmVuZGVySXRlbTogKGl0ZW06IFQpID0+IFJlYWN0LlJlYWN0Tm9kZTtcbiAgICBzZWxlY3RlZEluZGV4OiBudW1iZXI7XG4gICAgbG9hZGluZz86IGJvb2xlYW47XG4gICAgZW1wdHlNZXNzYWdlPzogc3RyaW5nO1xuICAgIHRyaWdnZXJFbGVtZW50OiBIVE1MRWxlbWVudCB8IG51bGw7IC8vIOKchSBOVUVWTzogUmVmZXJlbmNpYSBhbCBpbnB1dCBwYXJhIHBvc2ljaW9uYXJcbn1cblxuZXhwb3J0IGNvbnN0IEF1dG9jb21wbGV0ZURyb3Bkb3duID0gPFQgZXh0ZW5kcyB7IGlkOiBzdHJpbmcgfCBudW1iZXIgfT4oe1xuICAgIGl0ZW1zLFxuICAgIGlzT3BlbixcbiAgICBvblNlbGVjdCxcbiAgICBvbkNsb3NlLFxuICAgIHJlbmRlckl0ZW0sXG4gICAgc2VsZWN0ZWRJbmRleCxcbiAgICBsb2FkaW5nID0gZmFsc2UsXG4gICAgZW1wdHlNZXNzYWdlID0gJ05vIHNlIGVuY29udHJhcm9uIHJlc3VsdGFkb3MnLFxuICAgIHRyaWdnZXJFbGVtZW50XG59OiBBdXRvY29tcGxldGVEcm9wZG93blByb3BzPFQ+KSA9PiB7XG4gICAgY29uc3QgZHJvcGRvd25SZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGl0ZW1SZWZzID0gdXNlUmVmPChIVE1MRGl2RWxlbWVudCB8IG51bGwpW10+KFtdKTtcbiAgICBjb25zdCBbcG9zaXRpb24sIHNldFBvc2l0aW9uXSA9IHVzZVN0YXRlKHsgdG9wOiAwLCBsZWZ0OiAwLCB3aWR0aDogMCB9KTtcblxuICAgIC8vIENhbGN1bGFyIHBvc2ljacOzbiBkZWwgZHJvcGRvd24gYmFzYWRvIGVuIGVsIGlucHV0XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlzT3BlbiAmJiB0cmlnZ2VyRWxlbWVudCkge1xuICAgICAgICAgICAgY29uc3QgcmVjdCA9IHRyaWdnZXJFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgc2V0UG9zaXRpb24oe1xuICAgICAgICAgICAgICAgIHRvcDogcmVjdC5ib3R0b20gKyB3aW5kb3cuc2Nyb2xsWSArIDQsIC8vIDRweCBkZSBtYXJnZW5cbiAgICAgICAgICAgICAgICBsZWZ0OiByZWN0LmxlZnQgKyB3aW5kb3cuc2Nyb2xsWCxcbiAgICAgICAgICAgICAgICB3aWR0aDogcmVjdC53aWR0aCAqIDEuNVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbaXNPcGVuLCB0cmlnZ2VyRWxlbWVudF0pO1xuXG4gICAgLy8gQ2VycmFyIGFsIGhhY2VyIGNsaWNrIGZ1ZXJhXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAoZHJvcGRvd25SZWYuY3VycmVudCAmJiAhZHJvcGRvd25SZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodHJpZ2dlckVsZW1lbnQgJiYgIXRyaWdnZXJFbGVtZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCBhcyBOb2RlKSkge1xuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGlmIChpc09wZW4pIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbaXNPcGVuLCBvbkNsb3NlLCB0cmlnZ2VyRWxlbWVudF0pO1xuXG4gICAgLy8gU2Nyb2xsIGFsIGl0ZW0gc2VsZWNjaW9uYWRvXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKHNlbGVjdGVkSW5kZXggPj0gMCAmJiBpdGVtUmVmcy5jdXJyZW50W3NlbGVjdGVkSW5kZXhdKSB7XG4gICAgICAgICAgICBpdGVtUmVmcy5jdXJyZW50W3NlbGVjdGVkSW5kZXhdPy5zY3JvbGxJbnRvVmlldyh7XG4gICAgICAgICAgICAgICAgYmxvY2s6ICduZWFyZXN0JyxcbiAgICAgICAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSwgW3NlbGVjdGVkSW5kZXhdKTtcblxuICAgIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGRyb3Bkb3duQ29udGVudCA9IChcbiAgICAgICAgPGRpdlxuICAgICAgICAgICAgcmVmPXtkcm9wZG93blJlZn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctbGcgbWF4LWgtNjAgb3ZlcmZsb3ctYXV0byB6LVs5OTk5XVwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHRvcDogYCR7cG9zaXRpb24udG9wfXB4YCxcbiAgICAgICAgICAgICAgICBsZWZ0OiBgJHtwb3NpdGlvbi5sZWZ0fXB4YCxcbiAgICAgICAgICAgICAgICB3aWR0aDogYCR7cG9zaXRpb24ud2lkdGh9cHhgXG4gICAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5CdXNjYW5kby4uLjwvZGl2PlxuICAgICAgICAgICAgKSA6IGl0ZW1zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57ZW1wdHlNZXNzYWdlfTwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBpdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17KGVsKSA9PiB7IGl0ZW1SZWZzLmN1cnJlbnRbaW5kZXhdID0gZWw7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0KGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTsgLy8g4pyFIENlcnJhciBleHBsw61jaXRhbWVudGUgZGVzcHXDqXMgZGUgc2VsZWNjaW9uYXJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbSBob3ZlcjpiZy1pbmRpZ28tNTAgJHtpbmRleCA9PT0gc2VsZWN0ZWRJbmRleCA/ICdiZy1pbmRpZ28tMTAwJyA6ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJJdGVtKGl0ZW0pfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIC8vIOKchSBSZW5kZXJpemFyIHVzYW5kbyBQb3J0YWwgcGFyYSBxdWUgZmxvdGUgc29icmUgdG9kb1xuICAgIHJldHVybiBjcmVhdGVQb3J0YWwoZHJvcGRvd25Db250ZW50LCBkb2N1bWVudC5ib2R5KTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL0F1dG9jb21wbGV0ZURyb3Bkb3duLnRzeCJ9