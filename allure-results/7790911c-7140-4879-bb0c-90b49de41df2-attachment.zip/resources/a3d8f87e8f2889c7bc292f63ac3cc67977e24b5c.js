import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mov_stock/pages/MovStockFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mov_stock/pages/MovStockFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaPlus, FaSave, FaSpinner, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { stockMovementsModuleConfig } from "/src/features/mov_stock/movStock.config.tsx";
import { searchByField } from "/src/services/apiService.ts";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const costCurrencyLabel = (costCurrency) => {
  const key = String(costCurrency ?? "").trim();
  if (key === "1") return "Pesos (ARS)";
  if (key === "2") return "Dólares (USD)";
  return "—";
};
const purchasePriceDisplay = (product) => {
  if (!product) return "—";
  const raw = product.purchase_price;
  if (raw == null || raw === "") return "—";
  return formatValue(raw, "number");
};
export const MovStockFormPage = ({ mode, initialData, loading = false, onSubmit }) => {
  _s();
  const navigate = useNavigate();
  const [commonData, setCommonData] = useState({
    movement_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    movement_code: "",
    client_id: null,
    client_name: void 0,
    customer_code: void 0,
    vendor_id: null,
    vendor_name: void 0,
    vendor_code: void 0,
    reference: "",
    voucher: "",
    delivery_note: ""
  });
  const [products, setProducts] = useState([]);
  const [clientCodeInput, setClientCodeInput] = useState("");
  const [vendorCodeInput, setVendorCodeInput] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [modalConfig, setModalConfig] = useState(null);
  useEffect(() => {
    if (mode === "edit" && initialData) {
      setCommonData({
        movement_date: initialData.movement_date ? initialData.movement_date.split("T")[0] : "",
        movement_code: initialData.movement_code,
        client_id: initialData.client_id,
        client_name: initialData.client_name,
        customer_code: initialData.customer_code,
        vendor_id: initialData.vendor_id,
        vendor_name: initialData.vendor_name,
        vendor_code: initialData.vendor_code,
        reference: initialData.reference || "",
        voucher: initialData.voucher || "",
        delivery_note: initialData.delivery_note || ""
      });
      if (initialData.client_id) setClientCodeInput(String(initialData.customer_code));
      if (initialData.vendor_id) setVendorCodeInput(String(initialData.vendor_code));
      setProducts([{
        tempId: "edit-item-1",
        product: {
          id: initialData.product_id,
          name: initialData.product_name || "",
          sku: initialData.sku || ""
          // Si el backend no trae el código del producto, quedará vacío hasta que busquen
        },
        quantity: initialData.quantity,
        ui_product_code: initialData.sku || ""
        // O inicialData.product_code si lo tienes
      }]);
    }
  }, [mode, initialData]);
  const handleAddProductRow = () => {
    setProducts((p) => [...p, { tempId: crypto.randomUUID(), product: null, quantity: 1, ui_product_code: "" }]);
  };
  const handleRemoveProductRow = (tempId) => {
    setProducts((p) => p.filter((item) => item.tempId !== tempId));
  };
  const handleUpdateProductRow = (tempId, field, value) => {
    setProducts((p) => p.map((item) => item.tempId === tempId ? { ...item, [field]: value } : item));
  };
  const handleProductCodeSubmit = async (tempId) => {
    const itemIndex = products.findIndex((p) => p.tempId === tempId);
    if (itemIndex === -1) return;
    const item = products[itemIndex];
    if (!item.ui_product_code) return;
    try {
      const found = await searchByField(articulosModuleConfig.endpoint, [{ fieldName: "sku", value: item.ui_product_code }]);
      if (found) {
        setProducts((prev) => prev.map((p) => p.tempId === tempId ? { ...p, product: found, ui_product_code: found.sku } : p));
      } else {
        toast.warn(`Producto no encontrado.`);
        setProducts((prev) => prev.map((p) => p.tempId === tempId ? { ...p, product: null } : p));
      }
    } catch (error) {
      console.error(error);
    }
  };
  const handleEntityCodeSubmit = async (type) => {
    const code = type === "client" ? clientCodeInput : vendorCodeInput;
    if (!code) return;
    const config = type === "client" ? clientesModuleConfig : proveedoresModuleConfig;
    try {
      const found = await searchByField(config.endpoint, [{ fieldName: type === "client" ? "customer_code" : "vendor_code", value: code }]);
      if (found) {
        if (type === "client") {
          setCommonData((p) => ({ ...p, client_id: found.id, client_name: found.name }));
          setClientCodeInput(found.customer_code || String(found.id));
        } else {
          setCommonData((p) => ({ ...p, vendor_id: found.id, vendor_name: found.name }));
          setVendorCodeInput(found.vendor_code || String(found.id));
        }
        toast.success(`${type === "client" ? "Cliente" : "Proveedor"} encontrado.`);
      } else {
        toast.warn("Registro no encontrado.");
      }
    } catch (e) {
      console.error(e);
    }
  };
  const handleCommonDataChange = (field, value) => {
    setCommonData((prev) => {
      const newState = { ...prev, [field]: value };
      if (field === "movement_code") {
        newState.client_id = null;
        newState.client_name = void 0;
        newState.vendor_id = null;
        newState.vendor_name = void 0;
        setClientCodeInput("");
        setVendorCodeInput("");
      }
      return newState;
    });
  };
  const openModal = (target, config) => {
    setEditingTarget(target);
    setModalConfig(config);
    setIsModalOpen(true);
  };
  const handleSelect = (selectedItem) => {
    if (editingTarget === "client") {
      setCommonData((p) => ({ ...p, client_id: selectedItem.id, client_name: selectedItem.name }));
      setClientCodeInput(selectedItem.customer_code || String(selectedItem.id));
    } else if (editingTarget === "vendor") {
      setCommonData((p) => ({ ...p, vendor_id: selectedItem.id, vendor_name: selectedItem.name }));
      setVendorCodeInput(selectedItem.vendor_code || String(selectedItem.id));
    } else if (typeof editingTarget === "number") {
      setProducts((prevProducts) => prevProducts.map((item, index) => {
        if (index !== editingTarget) return item;
        return {
          ...item,
          product: selectedItem,
          // ✅ MAGIA AQUÍ: Llenamos el input triangular con el código del ítem seleccionado
          // Agregué 'sku' por si acaso tu backend lo llama así en vez de 'code'
          ui_product_code: selectedItem.code || selectedItem.sku || String(selectedItem.id)
        };
      }));
    }
    setIsModalOpen(false);
  };
  const handleSubmit = async () => {
    if (!commonData.movement_code) {
      toast.error("Debe seleccionar un tipo.");
      return;
    }
    if (products.length === 0 || products.some((p) => !p.product || p.quantity <= 0)) {
      toast.error("Productos inválidos.");
      return;
    }
    if (commonData.movement_code === "A" && (!commonData.vendor_id || !commonData.delivery_note)) {
      toast.error("Datos de proveedor incompletos.");
      return;
    }
    await onSubmit({ commonData, products });
  };
  const showClient = commonData.movement_code !== "A";
  const showVendor = commonData.movement_code !== "F";
  const showDeliveryNote = commonData.movement_code === "A";
  const tableInputStyles = "w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const totalCantidadArticulos = products.reduce((sum, p) => {
    const q = p.quantity;
    return sum + (typeof q === "number" && !Number.isNaN(q) ? q : 0);
  }, 0);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Crear Movimiento(s)" : "Editar Movimiento" }, void 0, false, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 275,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 md:grid-cols-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "m_date", className: "block text-sm font-medium text-gray-700", children: "Fecha" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 284,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "m_date", type: "date", value: commonData.movement_date, onChange: (e) => handleCommonDataChange("movement_date", e.target.value), className: tableInputStyles, autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 285,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 283,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "m_code", className: "block text-sm font-medium text-gray-700", children: "Tipo" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 289,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("select", { id: "m_code", value: commonData.movement_code, onChange: (e) => handleCommonDataChange("movement_code", e.target.value), className: tableInputStyles, disabled: mode === "edit", children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccione..." }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 291,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A - Compra" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 292,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B - Baja" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 293,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C - Ajuste" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 294,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "D", children: "D - Devolución" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 295,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "F", children: "F - Venta" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 296,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "S", children: "S - Salida" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 297,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 290,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 288,
        columnNumber: 21
      }, this),
      showClient && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 304,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: clientCodeInput,
            nameValue: commonData.client_name || null,
            onCodeChange: setClientCodeInput,
            onCodeSubmit: () => handleEntityCodeSubmit("client"),
            onSearchClick: () => openModal("client", clientesModuleConfig),
            onClearClick: () => {
              handleCommonDataChange("client_id", null);
              handleCommonDataChange("client_name", void 0);
              setClientCodeInput("");
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 305,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 303,
        columnNumber: 11
      }, this),
      showVendor && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Proveedor" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 316,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: vendorCodeInput,
            nameValue: commonData.vendor_name || null,
            onCodeChange: setVendorCodeInput,
            onCodeSubmit: () => handleEntityCodeSubmit("vendor"),
            onSearchClick: () => openModal("vendor", proveedoresModuleConfig),
            onClearClick: () => {
              handleCommonDataChange("vendor_id", null);
              handleCommonDataChange("vendor_name", void 0);
              setVendorCodeInput("");
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 317,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 315,
        columnNumber: 11
      }, this),
      showDeliveryNote && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "del_note", className: "block text-sm font-medium text-gray-700", children: "Remito" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 335,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "del_note", type: "text", value: commonData.delivery_note, onChange: (e) => handleCommonDataChange("delivery_note", e.target.value), className: tableInputStyles, autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 336,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 334,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "ref", className: "block text-sm font-medium text-gray-700", children: "Referencia" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 340,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "ref", type: "text", value: commonData.reference, onChange: (e) => handleCommonDataChange("reference", e.target.value), className: tableInputStyles, autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 341,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 339,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 281,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 280,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos" }, void 0, false, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 348,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3 px-3 text-left text-sm font-semibold text-gray-900 w-2/5", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 353,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900", children: "Cantidad" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 354,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900 whitespace-nowrap", children: "Precio de compra" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 355,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900 whitespace-nowrap", children: "Moneda de compra" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 356,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3 px-3" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 357,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 352,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 351,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: products.map(
          (p, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-2 px-3", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: p.ui_product_code,
                nameValue: p.product?.name || null,
                onCodeChange: (val) => handleUpdateProductRow(p.tempId, "ui_product_code", val),
                onCodeSubmit: () => handleProductCodeSubmit(p.tempId),
                onSearchClick: () => openModal(index, articulosModuleConfig),
                onClearClick: () => setProducts((pr) => pr.map((i) => i.tempId === p.tempId ? { ...i, product: null, ui_product_code: "" } : i)),
                mask: "sku",
                enableAutocomplete: true,
                autocompleteConfig: {
                  endpoint: articulosModuleConfig.endpoint,
                  codeField: "sku",
                  nameField: "name",
                  onSelect: (product) => {
                    setProducts((prev) => prev.map(
                      (pr) => pr.tempId === p.tempId ? { ...pr, product, ui_product_code: product.sku } : pr
                    ));
                  }
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
                lineNumber: 364,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 363,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: p.quantity, onChange: (num) => handleUpdateProductRow(p.tempId, "quantity", num), className: tableInputStyles, "aria-label": `Cantidad ${index + 1}` }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 387,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 386,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-700 tabular-nums whitespace-nowrap", children: purchasePriceDisplay(p.product) }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 389,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-700 whitespace-nowrap", children: p.product ? costCurrencyLabel(p.product.cost_currency) : "—" }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 392,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveProductRow(p.tempId), className: "text-red-500 hover:text-red-700", "aria-label": "Borrar", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 397,
              columnNumber: 162
            }, this) }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 397,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
              lineNumber: 395,
              columnNumber: 37
            }, this)
          ] }, p.tempId, true, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 362,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 360,
          columnNumber: 25
        }, this),
        mode === "create" && /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { scope: "row", className: "py-3 px-3 text-left text-sm font-semibold text-gray-900", children: "Total artículos" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 405,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm font-semibold text-gray-900 tabular-nums", children: totalCantidadArticulos }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 408,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm text-gray-500", children: "—" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 411,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm text-gray-500", children: "—" }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 412,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", "aria-hidden": true }, void 0, false, {
            fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
            lineNumber: 413,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 404,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 403,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 350,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 349,
        columnNumber: 17
      }, this),
      mode === "create" && /* @__PURE__ */ jsxDEV("button", { onClick: handleAddProductRow, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 422,
          columnNumber: 25
        }, this),
        " Añadir Producto"
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 421,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 347,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(stockMovementsModuleConfig.baseRoute)), className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 429,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSubmit, disabled: loading, className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-green-400", children: [
        loading ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 animate-spin" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 431,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
          lineNumber: 431,
          columnNumber: 86
        }, this),
        "Guardar"
      ] }, void 0, true, {
        fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
        lineNumber: 430,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 428,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => setIsModalOpen(false), onSelect: handleSelect, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
      lineNumber: 437,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/mov_stock/pages/MovStockFormPage.tsx",
    lineNumber: 274,
    columnNumber: 5
  }, this);
};
_s(MovStockFormPage, "R7WONcHB0g9xVS29x2c6YTwMgjo=", false, function() {
  return [useNavigate];
});
_c = MovStockFormPage;
var _c;
$RefreshReg$(_c, "MovStockFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mov_stock/pages/MovStockFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mov_stock/pages/MovStockFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1BZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlQWixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxRQUFRQyxXQUFXQyxlQUFlO0FBQ25ELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxrQ0FBaUQ7QUFDMUQsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDZCQUE0QztBQUNyRCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsb0JBQW9CQSxDQUFDQyxpQkFBb0Q7QUFDM0UsUUFBTUMsTUFBTUMsT0FBT0YsZ0JBQWdCLEVBQUUsRUFBRUcsS0FBSztBQUM1QyxNQUFJRixRQUFRLElBQUssUUFBTztBQUN4QixNQUFJQSxRQUFRLElBQUssUUFBTztBQUN4QixTQUFPO0FBQ1g7QUFFQSxNQUFNRyx1QkFBdUJBLENBQUNDLFlBQTZCO0FBQ3ZELE1BQUksQ0FBQ0EsUUFBUyxRQUFPO0FBQ3JCLFFBQU1DLE1BQU1ELFFBQVFFO0FBQ3BCLE1BQUlELE9BQU8sUUFBUUEsUUFBUSxHQUFJLFFBQU87QUFDdEMsU0FBT1QsWUFBWVMsS0FBSyxRQUFRO0FBQ3BDO0FBa0NPLGFBQU1FLG1CQUFtQkEsQ0FBQyxFQUFFQyxNQUFNQyxhQUFhQyxVQUFVLE9BQU9DLFNBQWdDLE1BQU07QUFBQUMsS0FBQTtBQUN6RyxRQUFNQyxXQUFXMUIsWUFBWTtBQUc3QixRQUFNLENBQUMyQixZQUFZQyxhQUFhLElBQUluQyxTQUFTO0FBQUEsSUFDekNvQyxnQkFBZSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxJQUNwREMsZUFBZTtBQUFBLElBQ2ZDLFdBQVc7QUFBQSxJQUNYQyxhQUFhQztBQUFBQSxJQUNiQyxlQUFlRDtBQUFBQSxJQUNmRSxXQUFXO0FBQUEsSUFDWEMsYUFBYUg7QUFBQUEsSUFDYkksYUFBYUo7QUFBQUEsSUFDYkssV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxlQUFlO0FBQUEsRUFDbkIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJcEQsU0FBeUIsRUFBRTtBQUczRCxRQUFNLENBQUNxRCxpQkFBaUJDLGtCQUFrQixJQUFJdEQsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3VELGlCQUFpQkMsa0JBQWtCLElBQUl4RCxTQUFTLEVBQUU7QUFHekQsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzJELGVBQWVDLGdCQUFnQixJQUFJNUQsU0FBK0IsSUFBSTtBQUM3RSxRQUFNLENBQUM2RCxhQUFhQyxjQUFjLElBQUk5RCxTQUFjLElBQUk7QUFHeERDLFlBQVUsTUFBTTtBQUNaLFFBQUkyQixTQUFTLFVBQVVDLGFBQWE7QUFFaENNLG9CQUFjO0FBQUEsUUFDVkMsZUFBZVAsWUFBWU8sZ0JBQWdCUCxZQUFZTyxjQUFjRyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFBQSxRQUNyRkMsZUFBZVgsWUFBWVc7QUFBQUEsUUFDM0JDLFdBQVdaLFlBQVlZO0FBQUFBLFFBQ3ZCQyxhQUFhYixZQUFZYTtBQUFBQSxRQUN6QkUsZUFBZWYsWUFBWWU7QUFBQUEsUUFDM0JDLFdBQVdoQixZQUFZZ0I7QUFBQUEsUUFDdkJDLGFBQWFqQixZQUFZaUI7QUFBQUEsUUFDekJDLGFBQWFsQixZQUFZa0I7QUFBQUEsUUFDekJDLFdBQVduQixZQUFZbUIsYUFBYTtBQUFBLFFBQ3BDQyxTQUFTcEIsWUFBWW9CLFdBQVc7QUFBQSxRQUNoQ0MsZUFBZXJCLFlBQVlxQixpQkFBaUI7QUFBQSxNQUNoRCxDQUFDO0FBSUQsVUFBSXJCLFlBQVlZLFVBQVdhLG9CQUFtQmpDLE9BQU9RLFlBQVllLGFBQWEsQ0FBQztBQUMvRSxVQUFJZixZQUFZZ0IsVUFBV1csb0JBQW1CbkMsT0FBT1EsWUFBWWtCLFdBQVcsQ0FBQztBQU03RUssa0JBQVksQ0FBQztBQUFBLFFBQ1RXLFFBQVE7QUFBQSxRQUNSdkMsU0FBUztBQUFBLFVBQ0x3QyxJQUFJbkMsWUFBWW9DO0FBQUFBLFVBQ2hCQyxNQUFNckMsWUFBWXNDLGdCQUFnQjtBQUFBLFVBQ2xDQyxLQUFLdkMsWUFBWXVDLE9BQU87QUFBQTtBQUFBLFFBQzVCO0FBQUEsUUFDQUMsVUFBVXhDLFlBQVl3QztBQUFBQSxRQUN0QkMsaUJBQWlCekMsWUFBWXVDLE9BQU87QUFBQTtBQUFBLE1BQ3hDLENBQUMsQ0FBQztBQUFBLElBQ047QUFBQSxFQUNKLEdBQUcsQ0FBQ3hDLE1BQU1DLFdBQVcsQ0FBQztBQU10QixRQUFNMEMsc0JBQXNCQSxNQUFNO0FBQzlCbkIsZ0JBQVksQ0FBQW9CLE1BQUssQ0FBQyxHQUFHQSxHQUFHLEVBQUVULFFBQVFVLE9BQU9DLFdBQVcsR0FBR2xELFNBQVMsTUFBTTZDLFVBQVUsR0FBR0MsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFDN0c7QUFDQSxRQUFNSyx5QkFBeUJBLENBQUNaLFdBQW1CO0FBQy9DWCxnQkFBWSxDQUFBb0IsTUFBS0EsRUFBRUksT0FBTyxDQUFBQyxTQUFRQSxLQUFLZCxXQUFXQSxNQUFNLENBQUM7QUFBQSxFQUM3RDtBQUNBLFFBQU1lLHlCQUF5QkEsQ0FBQ2YsUUFBZ0JnQixPQUEyQkMsVUFBZTtBQUN0RjVCLGdCQUFZLENBQUFvQixNQUFLQSxFQUFFUyxJQUFJLENBQUFKLFNBQVFBLEtBQUtkLFdBQVdBLFNBQVMsRUFBRSxHQUFHYyxNQUFNLENBQUNFLEtBQUssR0FBR0MsTUFBTSxJQUFJSCxJQUFJLENBQUM7QUFBQSxFQUMvRjtBQUdBLFFBQU1LLDBCQUEwQixPQUFPbkIsV0FBbUI7QUFDdEQsVUFBTW9CLFlBQVloQyxTQUFTaUMsVUFBVSxDQUFBWixNQUFLQSxFQUFFVCxXQUFXQSxNQUFNO0FBQzdELFFBQUlvQixjQUFjLEdBQUk7QUFDdEIsVUFBTU4sT0FBTzFCLFNBQVNnQyxTQUFTO0FBQy9CLFFBQUksQ0FBQ04sS0FBS1AsZ0JBQWlCO0FBRTNCLFFBQUk7QUFFQSxZQUFNZSxRQUFRLE1BQU01RSxjQUF3Qkksc0JBQXNCeUUsVUFBVSxDQUFDLEVBQUVDLFdBQVcsT0FBT1AsT0FBT0gsS0FBS1AsZ0JBQWdCLENBQUMsQ0FBQztBQUMvSCxVQUFJZSxPQUFPO0FBQ1BqQyxvQkFBWSxDQUFBb0MsU0FBUUEsS0FBS1AsSUFBSSxDQUFBVCxNQUFLQSxFQUFFVCxXQUFXQSxTQUFTLEVBQUUsR0FBR1MsR0FBR2hELFNBQVM2RCxPQUFPZixpQkFBaUJlLE1BQU1qQixJQUFJLElBQUlJLENBQUMsQ0FBQztBQUFBLE1BQ3JILE9BQU87QUFDSHRFLGNBQU11RixLQUFLLHlCQUF5QjtBQUNwQ3JDLG9CQUFZLENBQUFvQyxTQUFRQSxLQUFLUCxJQUFJLENBQUFULE1BQUtBLEVBQUVULFdBQVdBLFNBQVMsRUFBRSxHQUFHUyxHQUFHaEQsU0FBUyxLQUFLLElBQUlnRCxDQUFDLENBQUM7QUFBQSxNQUN4RjtBQUFBLElBQ0osU0FBU2tCLE9BQU87QUFBRUMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQUc7QUFBQSxFQUM1QztBQUVBLFFBQU1FLHlCQUF5QixPQUFPQyxTQUE4QjtBQUNoRSxVQUFNQyxPQUFPRCxTQUFTLFdBQVd4QyxrQkFBa0JFO0FBQ25ELFFBQUksQ0FBQ3VDLEtBQU07QUFDWCxVQUFNQyxTQUFTRixTQUFTLFdBQVcvRSx1QkFBdUJDO0FBRTFELFFBQUk7QUFDQSxZQUFNc0UsUUFBUSxNQUFNNUUsY0FBbUJzRixPQUFPVCxVQUFVLENBQUMsRUFBRUMsV0FBV00sU0FBUyxXQUFXLGtCQUFrQixlQUFlYixPQUFPYyxLQUFLLENBQUMsQ0FBQztBQUN6SSxVQUFJVCxPQUFPO0FBQ1AsWUFBSVEsU0FBUyxVQUFVO0FBQ25CMUQsd0JBQWMsQ0FBQXFDLE9BQU0sRUFBRSxHQUFHQSxHQUFHL0IsV0FBVzRDLE1BQU1yQixJQUFJdEIsYUFBYTJDLE1BQU1uQixLQUFLLEVBQUU7QUFDM0VaLDZCQUFtQitCLE1BQU16QyxpQkFBaUJ2QixPQUFPZ0UsTUFBTXJCLEVBQUUsQ0FBQztBQUFBLFFBQzlELE9BQU87QUFDSDdCLHdCQUFjLENBQUFxQyxPQUFNLEVBQUUsR0FBR0EsR0FBRzNCLFdBQVd3QyxNQUFNckIsSUFBSWxCLGFBQWF1QyxNQUFNbkIsS0FBSyxFQUFFO0FBQzNFViw2QkFBbUI2QixNQUFNdEMsZUFBZTFCLE9BQU9nRSxNQUFNckIsRUFBRSxDQUFDO0FBQUEsUUFDNUQ7QUFDQTlELGNBQU04RixRQUFRLEdBQUdILFNBQVMsV0FBVyxZQUFZLFdBQVcsY0FBYztBQUFBLE1BQzlFLE9BQU87QUFDSDNGLGNBQU11RixLQUFLLHlCQUF5QjtBQUFBLE1BQ3hDO0FBQUEsSUFDSixTQUFTUSxHQUFHO0FBQUVOLGNBQVFELE1BQU1PLENBQUM7QUFBQSxJQUFHO0FBQUEsRUFDcEM7QUFHQSxRQUFNQyx5QkFBeUJBLENBQUNuQixPQUFnQ0MsVUFBZTtBQUMzRTdDLGtCQUFjLENBQUFxRCxTQUFRO0FBQ2xCLFlBQU1XLFdBQVcsRUFBRSxHQUFHWCxNQUFNLENBQUNULEtBQUssR0FBR0MsTUFBTTtBQUMzQyxVQUFJRCxVQUFVLGlCQUFpQjtBQUMzQm9CLGlCQUFTMUQsWUFBWTtBQUFNMEQsaUJBQVN6RCxjQUFjQztBQUNsRHdELGlCQUFTdEQsWUFBWTtBQUFNc0QsaUJBQVNyRCxjQUFjSDtBQUNsRFcsMkJBQW1CLEVBQUU7QUFBR0UsMkJBQW1CLEVBQUU7QUFBQSxNQUNqRDtBQUNBLGFBQU8yQztBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMO0FBR0EsUUFBTUMsWUFBWUEsQ0FBQ0MsUUFBdUJOLFdBQWdCO0FBQ3REbkMscUJBQWlCeUMsTUFBTTtBQUN2QnZDLG1CQUFlaUMsTUFBTTtBQUNyQnJDLG1CQUFlLElBQUk7QUFBQSxFQUN2QjtBQUVBLFFBQU00QyxlQUFlQSxDQUFDQyxpQkFBc0I7QUFDeEMsUUFBSTVDLGtCQUFrQixVQUFVO0FBQzVCeEIsb0JBQWMsQ0FBQXFDLE9BQU0sRUFBRSxHQUFHQSxHQUFHL0IsV0FBVzhELGFBQWF2QyxJQUFJdEIsYUFBYTZELGFBQWFyQyxLQUFLLEVBQUU7QUFDekZaLHlCQUFtQmlELGFBQWEzRCxpQkFBaUJ2QixPQUFPa0YsYUFBYXZDLEVBQUUsQ0FBQztBQUFBLElBQzVFLFdBQVdMLGtCQUFrQixVQUFVO0FBQ25DeEIsb0JBQWMsQ0FBQXFDLE9BQU0sRUFBRSxHQUFHQSxHQUFHM0IsV0FBVzBELGFBQWF2QyxJQUFJbEIsYUFBYXlELGFBQWFyQyxLQUFLLEVBQUU7QUFDekZWLHlCQUFtQitDLGFBQWF4RCxlQUFlMUIsT0FBT2tGLGFBQWF2QyxFQUFFLENBQUM7QUFBQSxJQUMxRSxXQUFXLE9BQU9MLGtCQUFrQixVQUFVO0FBQzFDUCxrQkFBWSxDQUFBb0QsaUJBQWdCQSxhQUFhdkIsSUFBSSxDQUFDSixNQUFNNEIsVUFBVTtBQUUxRCxZQUFJQSxVQUFVOUMsY0FBZSxRQUFPa0I7QUFHcEMsZUFBTztBQUFBLFVBQ0gsR0FBR0E7QUFBQUEsVUFDSHJELFNBQVMrRTtBQUFBQTtBQUFBQTtBQUFBQSxVQUdUakMsaUJBQWlCaUMsYUFBYVQsUUFBUVMsYUFBYW5DLE9BQU8vQyxPQUFPa0YsYUFBYXZDLEVBQUU7QUFBQSxRQUNwRjtBQUFBLE1BQ0osQ0FBQyxDQUFDO0FBQUEsSUFDTjtBQUNBTixtQkFBZSxLQUFLO0FBQUEsRUFDeEI7QUFHQSxRQUFNZ0QsZUFBZSxZQUFZO0FBRTdCLFFBQUksQ0FBQ3hFLFdBQVdNLGVBQWU7QUFBRXRDLFlBQU13RixNQUFNLDJCQUEyQjtBQUFHO0FBQUEsSUFBUTtBQUNuRixRQUFJdkMsU0FBU3dELFdBQVcsS0FBS3hELFNBQVN5RCxLQUFLLENBQUFwQyxNQUFLLENBQUNBLEVBQUVoRCxXQUFXZ0QsRUFBRUgsWUFBWSxDQUFDLEdBQUc7QUFBRW5FLFlBQU13RixNQUFNLHNCQUFzQjtBQUFHO0FBQUEsSUFBUTtBQUMvSCxRQUFJeEQsV0FBV00sa0JBQWtCLFFBQVEsQ0FBQ04sV0FBV1csYUFBYSxDQUFDWCxXQUFXZ0IsZ0JBQWdCO0FBQUVoRCxZQUFNd0YsTUFBTSxpQ0FBaUM7QUFBRztBQUFBLElBQVE7QUFFeEosVUFBTTNELFNBQVMsRUFBRUcsWUFBWWlCLFNBQVMsQ0FBQztBQUFBLEVBQzNDO0FBR0EsUUFBTTBELGFBQWEzRSxXQUFXTSxrQkFBa0I7QUFDaEQsUUFBTXNFLGFBQWE1RSxXQUFXTSxrQkFBa0I7QUFDaEQsUUFBTXVFLG1CQUFtQjdFLFdBQVdNLGtCQUFrQjtBQUN0RCxRQUFNd0UsbUJBQW1CO0FBRXpCLFFBQU1DLHlCQUF5QjlELFNBQVMrRCxPQUFPLENBQUNDLEtBQUszQyxNQUFNO0FBQ3ZELFVBQU00QyxJQUFJNUMsRUFBRUg7QUFDWixXQUFPOEMsT0FBTyxPQUFPQyxNQUFNLFlBQVksQ0FBQ0MsT0FBT0MsTUFBTUYsQ0FBQyxJQUFJQSxJQUFJO0FBQUEsRUFDbEUsR0FBRyxDQUFDO0FBRUosU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBQ1g7QUFBQSwyQkFBQyxRQUFHLFdBQVUsdUNBQ1R4RixtQkFBUyxXQUFXLHdCQUF3Qix1QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1gsaUNBQUMsU0FBSSxXQUFVLHlDQUVYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxVQUFTLFdBQVUsMkNBQTBDLHFCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakYsdUJBQUMsV0FBTSxJQUFHLFVBQVMsTUFBSyxRQUFPLE9BQU9NLFdBQVdFLGVBQWUsVUFBVSxDQUFBNkQsTUFBS0MsdUJBQXVCLGlCQUFpQkQsRUFBRUksT0FBT3JCLEtBQUssR0FBRyxXQUFXZ0Msa0JBQWtCLGNBQWEsU0FBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TDtBQUFBLFdBRjNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxVQUFTLFdBQVUsMkNBQTBDLG9CQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsUUFDaEYsdUJBQUMsWUFBTyxJQUFHLFVBQVMsT0FBTzlFLFdBQVdNLGVBQWUsVUFBVSxDQUFBeUQsTUFBS0MsdUJBQXVCLGlCQUFpQkQsRUFBRUksT0FBT3JCLEtBQUssR0FBRyxXQUFXZ0Msa0JBQWtCLFVBQVVwRixTQUFTLFFBQ3pLO0FBQUEsaUNBQUMsWUFBTyxPQUFNLElBQUcsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsWUFBTyxPQUFNLEtBQUksMEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFDNUIsdUJBQUMsWUFBTyxPQUFNLEtBQUksd0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFDMUIsdUJBQUMsWUFBTyxPQUFNLEtBQUksMEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFDNUIsdUJBQUMsWUFBTyxPQUFNLEtBQUksOEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFDaEMsdUJBQUMsWUFBTyxPQUFNLEtBQUkseUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFDM0IsdUJBQUMsWUFBTyxPQUFNLEtBQUksMEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsYUFQaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUdDaUYsY0FDRyx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyx1QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2xFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFXeEQ7QUFBQUEsWUFBaUIsV0FBV25CLFdBQVdRLGVBQWU7QUFBQSxZQUNqRSxjQUFjWTtBQUFBQSxZQUFvQixjQUFjLE1BQU1zQyx1QkFBdUIsUUFBUTtBQUFBLFlBQ3JGLGVBQWUsTUFBTVEsVUFBVSxVQUFVdEYsb0JBQW9CO0FBQUEsWUFDN0QsY0FBYyxNQUFNO0FBQUVvRixxQ0FBdUIsYUFBYSxJQUFJO0FBQUdBLHFDQUF1QixlQUFldkQsTUFBUztBQUFHVyxpQ0FBbUIsRUFBRTtBQUFBLFlBQUc7QUFBQTtBQUFBLFVBSi9JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlpSjtBQUFBLFdBTnJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUh3RCxjQUNHLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLHlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVd2RDtBQUFBQSxZQUFpQixXQUFXckIsV0FBV1ksZUFBZTtBQUFBLFlBQ2pFLGNBQWNVO0FBQUFBLFlBQW9CLGNBQWMsTUFBTW9DLHVCQUF1QixRQUFRO0FBQUEsWUFDckYsZUFBZSxNQUFNUSxVQUFVLFVBQVVyRix1QkFBdUI7QUFBQSxZQUNoRSxjQUFjLE1BQU07QUFBRW1GLHFDQUF1QixhQUFhLElBQUk7QUFBR0EscUNBQXVCLGVBQWV2RCxNQUFTO0FBQUdhLGlDQUFtQixFQUFFO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFKL0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlKO0FBQUEsV0FOcko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFTSHVELG9CQUNHLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFNBQVEsWUFBVyxXQUFVLDJDQUEwQyxzQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFdBQU0sSUFBRyxZQUFXLE1BQUssUUFBTyxPQUFPN0UsV0FBV2dCLGVBQWUsVUFBVSxDQUFBK0MsTUFBS0MsdUJBQXVCLGlCQUFpQkQsRUFBRUksT0FBT3JCLEtBQUssR0FBRyxXQUFXZ0Msa0JBQWtCLGNBQWEsU0FBcEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5TDtBQUFBLFdBRjdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUosdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxPQUFNLFdBQVUsMkNBQTBDLDBCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFDbkYsdUJBQUMsV0FBTSxJQUFHLE9BQU0sTUFBSyxRQUFPLE9BQU85RSxXQUFXYyxXQUFXLFVBQVUsQ0FBQWlELE1BQUtDLHVCQUF1QixhQUFhRCxFQUFFSSxPQUFPckIsS0FBSyxHQUFHLFdBQVdnQyxrQkFBa0IsY0FBYSxTQUF2SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRLO0FBQUEsV0FGaEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0E3REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQSxLQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0VBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLHlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsU0FBSSxXQUFVLHdCQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsaUVBQWdFLHdCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFFBQUcsV0FBVSwyREFBMEQsd0JBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsUUFBRyxXQUFVLDZFQUE0RSxnQ0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxVQUMxRyx1QkFBQyxRQUFHLFdBQVUsNkVBQTRFLGdDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRztBQUFBLFVBQzFHLHVCQUFDLFFBQUcsV0FBVSxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsYUFMOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1o3RCxtQkFBUzhCO0FBQUFBLFVBQUksQ0FBQ1QsR0FBR2lDLFVBQ2QsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxhQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV2pDLEVBQUVGO0FBQUFBLGdCQUFpQixXQUFXRSxFQUFFaEQsU0FBUzBDLFFBQVE7QUFBQSxnQkFDNUQsY0FBYyxDQUFDcUQsUUFBUXpDLHVCQUF1Qk4sRUFBRVQsUUFBUSxtQkFBbUJ3RCxHQUFHO0FBQUEsZ0JBQzlFLGNBQWMsTUFBTXJDLHdCQUF3QlYsRUFBRVQsTUFBTTtBQUFBLGdCQUNwRCxlQUFlLE1BQU1xQyxVQUFVSyxPQUFPNUYscUJBQXFCO0FBQUEsZ0JBQzNELGNBQWMsTUFBTXVDLFlBQVksQ0FBQW9FLE9BQU1BLEdBQUd2QyxJQUFJLENBQUF3QyxNQUFLQSxFQUFFMUQsV0FBV1MsRUFBRVQsU0FBUyxFQUFFLEdBQUcwRCxHQUFHakcsU0FBUyxNQUFNOEMsaUJBQWlCLEdBQUcsSUFBSW1ELENBQUMsQ0FBQztBQUFBLGdCQUMzSCxNQUFLO0FBQUEsZ0JBQ0wsb0JBQW9CO0FBQUEsZ0JBQ3BCLG9CQUFvQjtBQUFBLGtCQUNoQm5DLFVBQVV6RSxzQkFBc0J5RTtBQUFBQSxrQkFDaENvQyxXQUFXO0FBQUEsa0JBQ1hDLFdBQVc7QUFBQSxrQkFDWEMsVUFBVUEsQ0FBQ3BHLFlBQVk7QUFDbkI0QixnQ0FBWSxDQUFBb0MsU0FBUUEsS0FBS1A7QUFBQUEsc0JBQUksQ0FBQXVDLE9BQ3pCQSxHQUFHekQsV0FBV1MsRUFBRVQsU0FDVixFQUFFLEdBQUd5RCxJQUFJaEcsU0FBa0I4QyxpQkFBaUI5QyxRQUFRNEMsSUFBSSxJQUN4RG9EO0FBQUFBLG9CQUNWLENBQUM7QUFBQSxrQkFDTDtBQUFBLGdCQUNKO0FBQUE7QUFBQSxjQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQk0sS0FwQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNWLGlDQUFDLGdCQUFhLE9BQU9oRCxFQUFFSCxVQUFVLFVBQVUsQ0FBQXdELFFBQU8vQyx1QkFBdUJOLEVBQUVULFFBQVEsWUFBWThELEdBQUcsR0FBRyxXQUFXYixrQkFBa0IsY0FBWSxZQUFZUCxRQUFRLENBQUMsTUFBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0ssS0FEMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGtFQUNUbEYsK0JBQXFCaUQsRUFBRWhELE9BQU8sS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUNUZ0QsWUFBRWhELFVBQVVOLGtCQUFrQnNELEVBQUVoRCxRQUFRc0csYUFBYSxJQUFJLE9BRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx3QkFFVixpQ0FBQyxZQUFPLFNBQVMsTUFBTW5ELHVCQUF1QkgsRUFBRVQsTUFBTSxHQUFHLFdBQVUsbUNBQWtDLGNBQVcsVUFBUyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVEsS0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0ksS0FGeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBcENLUyxFQUFFVCxRQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsUUFDSCxLQXhDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsUUFDQ25DLFNBQVMsWUFDTix1QkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxPQUFNLE9BQU0sV0FBVSwyREFBeUQsK0JBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSw4REFDVHFGLG9DQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FBa0MsaUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQyxpQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxRQUFHLFdBQVUsYUFBWSxlQUFXLFFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsYUFUekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FqRVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1FQSxLQXBFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUVBO0FBQUEsTUFFQ3JGLFNBQVMsWUFDTix1QkFBQyxZQUFPLFNBQVMyQyxxQkFBcUIsV0FBVSxpSUFDNUM7QUFBQSwrQkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUFHO0FBQUEsV0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0E1RVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNdEMsU0FBU2hCLGtCQUFrQlQsMkJBQTJCdUgsU0FBUyxDQUFDLEdBQUcsV0FBVSwyR0FBMEcsd0JBQTVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb087QUFBQSxNQUNwTyx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTckIsY0FBYyxVQUFVNUUsU0FBUyxXQUFVLDJJQUNyRUE7QUFBQUEsa0JBQVUsdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdELElBQU0sdUJBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBRHhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQzJCLGVBQWVJLGVBQ1osdUJBQUMsZUFBWSxRQUFRSixhQUFhLFNBQVMsTUFBTUMsZUFBZSxLQUFLLEdBQUcsVUFBVTRDLGNBQWMsUUFBUXpDLGVBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0g7QUFBQSxPQW5LNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFLQTtBQUVSO0FBQUU3QixHQXRXV0wsa0JBQWdCO0FBQUEsVUFDUnBCLFdBQVc7QUFBQTtBQUFBeUgsS0FEbkJyRztBQUFnQixJQUFBcUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidG9hc3QiLCJGYVBsdXMiLCJGYVNhdmUiLCJGYVNwaW5uZXIiLCJGYVRyYXNoIiwidXNlTmF2aWdhdGUiLCJzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZyIsInNlYXJjaEJ5RmllbGQiLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsImFydGljdWxvc01vZHVsZUNvbmZpZyIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwicHJvdmVlZG9yZXNNb2R1bGVDb25maWciLCJmb3JtYXRWYWx1ZSIsImdldExpc3RSZXR1cm5QYXRoIiwiY29zdEN1cnJlbmN5TGFiZWwiLCJjb3N0Q3VycmVuY3kiLCJrZXkiLCJTdHJpbmciLCJ0cmltIiwicHVyY2hhc2VQcmljZURpc3BsYXkiLCJwcm9kdWN0IiwicmF3IiwicHVyY2hhc2VfcHJpY2UiLCJNb3ZTdG9ja0Zvcm1QYWdlIiwibW9kZSIsImluaXRpYWxEYXRhIiwibG9hZGluZyIsIm9uU3VibWl0IiwiX3MiLCJuYXZpZ2F0ZSIsImNvbW1vbkRhdGEiLCJzZXRDb21tb25EYXRhIiwibW92ZW1lbnRfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwibW92ZW1lbnRfY29kZSIsImNsaWVudF9pZCIsImNsaWVudF9uYW1lIiwidW5kZWZpbmVkIiwiY3VzdG9tZXJfY29kZSIsInZlbmRvcl9pZCIsInZlbmRvcl9uYW1lIiwidmVuZG9yX2NvZGUiLCJyZWZlcmVuY2UiLCJ2b3VjaGVyIiwiZGVsaXZlcnlfbm90ZSIsInByb2R1Y3RzIiwic2V0UHJvZHVjdHMiLCJjbGllbnRDb2RlSW5wdXQiLCJzZXRDbGllbnRDb2RlSW5wdXQiLCJ2ZW5kb3JDb2RlSW5wdXQiLCJzZXRWZW5kb3JDb2RlSW5wdXQiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwidGVtcElkIiwiaWQiLCJwcm9kdWN0X2lkIiwibmFtZSIsInByb2R1Y3RfbmFtZSIsInNrdSIsInF1YW50aXR5IiwidWlfcHJvZHVjdF9jb2RlIiwiaGFuZGxlQWRkUHJvZHVjdFJvdyIsInAiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiaGFuZGxlUmVtb3ZlUHJvZHVjdFJvdyIsImZpbHRlciIsIml0ZW0iLCJoYW5kbGVVcGRhdGVQcm9kdWN0Um93IiwiZmllbGQiLCJ2YWx1ZSIsIm1hcCIsImhhbmRsZVByb2R1Y3RDb2RlU3VibWl0IiwiaXRlbUluZGV4IiwiZmluZEluZGV4IiwiZm91bmQiLCJlbmRwb2ludCIsImZpZWxkTmFtZSIsInByZXYiLCJ3YXJuIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlRW50aXR5Q29kZVN1Ym1pdCIsInR5cGUiLCJjb2RlIiwiY29uZmlnIiwic3VjY2VzcyIsImUiLCJoYW5kbGVDb21tb25EYXRhQ2hhbmdlIiwibmV3U3RhdGUiLCJvcGVuTW9kYWwiLCJ0YXJnZXQiLCJoYW5kbGVTZWxlY3QiLCJzZWxlY3RlZEl0ZW0iLCJwcmV2UHJvZHVjdHMiLCJpbmRleCIsImhhbmRsZVN1Ym1pdCIsImxlbmd0aCIsInNvbWUiLCJzaG93Q2xpZW50Iiwic2hvd1ZlbmRvciIsInNob3dEZWxpdmVyeU5vdGUiLCJ0YWJsZUlucHV0U3R5bGVzIiwidG90YWxDYW50aWRhZEFydGljdWxvcyIsInJlZHVjZSIsInN1bSIsInEiLCJOdW1iZXIiLCJpc05hTiIsInZhbCIsInByIiwiaSIsImNvZGVGaWVsZCIsIm5hbWVGaWVsZCIsIm9uU2VsZWN0IiwibnVtIiwiY29zdF9jdXJyZW5jeSIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vdlN0b2NrRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhUGx1cywgRmFTYXZlLCBGYVNwaW5uZXIsIEZhVHJhc2ggfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgc3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWcsIHR5cGUgTW92U3RvY2sgfSBmcm9tICcuLi9tb3ZTdG9jay5jb25maWcnO1xuaW1wb3J0IHsgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZywgdHlwZSBBcnRpY3VsbyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJztcbmltcG9ydCB7IGNsaWVudGVzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vY2xpZW50ZXMvY2xpZW50ZXMuY29uZmlnJztcbmltcG9ydCB7IHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vcHJvdmVlZG9yZXMvcHJvdmVlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLyoqIEV0aXF1ZXRhIGRlIG1vbmVkYSBkZSBjb3N0bzsgbWlzbWEgY29udmVuY2nDs24gcXVlIGFydGljdWxvcy5jb25maWcgKGBjb3N0X2N1cnJlbmN5YCkuICovXG5jb25zdCBjb3N0Q3VycmVuY3lMYWJlbCA9IChjb3N0Q3VycmVuY3k6IEFydGljdWxvWydjb3N0X2N1cnJlbmN5J10pOiBzdHJpbmcgPT4ge1xuICAgIGNvbnN0IGtleSA9IFN0cmluZyhjb3N0Q3VycmVuY3kgPz8gJycpLnRyaW0oKTtcbiAgICBpZiAoa2V5ID09PSAnMScpIHJldHVybiAnUGVzb3MgKEFSUyknO1xuICAgIGlmIChrZXkgPT09ICcyJykgcmV0dXJuICdEw7NsYXJlcyAoVVNEKSc7XG4gICAgcmV0dXJuICfigJQnO1xufTtcblxuY29uc3QgcHVyY2hhc2VQcmljZURpc3BsYXkgPSAocHJvZHVjdDogQXJ0aWN1bG8gfCBudWxsKSA9PiB7XG4gICAgaWYgKCFwcm9kdWN0KSByZXR1cm4gJ+KAlCc7XG4gICAgY29uc3QgcmF3ID0gcHJvZHVjdC5wdXJjaGFzZV9wcmljZTtcbiAgICBpZiAocmF3ID09IG51bGwgfHwgcmF3ID09PSAnJykgcmV0dXJuICfigJQnO1xuICAgIHJldHVybiBmb3JtYXRWYWx1ZShyYXcsICdudW1iZXInKTtcbn07XG5cbi8vIC0tLSBJbnRlcmZhY2VzIC0tLVxuZXhwb3J0IGludGVyZmFjZSBQcm9kdWN0RW50cnkge1xuICAgIHRlbXBJZDogc3RyaW5nO1xuICAgIHByb2R1Y3Q6IEFydGljdWxvIHwgbnVsbDtcbiAgICBxdWFudGl0eTogbnVtYmVyO1xuICAgIHVpX3Byb2R1Y3RfY29kZTogc3RyaW5nOyAvLyBFc3RhZG8gdHJpYW5ndWxhclxufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1vdlN0b2NrRm9ybURhdGEge1xuICAgIGNvbW1vbkRhdGE6IHtcbiAgICAgICAgbW92ZW1lbnRfZGF0ZTogc3RyaW5nO1xuICAgICAgICBtb3ZlbWVudF9jb2RlOiBzdHJpbmc7XG4gICAgICAgIGNsaWVudF9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICAgICAgY2xpZW50X25hbWU/OiBzdHJpbmc7XG4gICAgICAgIHZlbmRvcl9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICAgICAgdmVuZG9yX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIHJlZmVyZW5jZTogc3RyaW5nO1xuICAgICAgICB2b3VjaGVyOiBzdHJpbmc7XG4gICAgICAgIGRlbGl2ZXJ5X25vdGU6IHN0cmluZztcbiAgICB9O1xuICAgIHByb2R1Y3RzOiBQcm9kdWN0RW50cnlbXTtcbn1cblxuaW50ZXJmYWNlIE1vdlN0b2NrRm9ybVBhZ2VQcm9wcyB7XG4gICAgbW9kZTogJ2NyZWF0ZScgfCAnZWRpdCc7XG4gICAgaW5pdGlhbERhdGE/OiBNb3ZTdG9jaztcbiAgICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgICBvblN1Ym1pdDogKGRhdGE6IE1vdlN0b2NrRm9ybURhdGEpID0+IFByb21pc2U8dm9pZD47XG59XG5cbnR5cGUgRWRpdGluZ1RhcmdldCA9ICdjbGllbnQnIHwgJ3ZlbmRvcicgfCBudW1iZXI7XG5cbmV4cG9ydCBjb25zdCBNb3ZTdG9ja0Zvcm1QYWdlID0gKHsgbW9kZSwgaW5pdGlhbERhdGEsIGxvYWRpbmcgPSBmYWxzZSwgb25TdWJtaXQgfTogTW92U3RvY2tGb3JtUGFnZVByb3BzKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgLy8gLS0tIDEuIEVTVEFET1MgLS0tXG4gICAgY29uc3QgW2NvbW1vbkRhdGEsIHNldENvbW1vbkRhdGFdID0gdXNlU3RhdGUoe1xuICAgICAgICBtb3ZlbWVudF9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgICAgbW92ZW1lbnRfY29kZTogJycsXG4gICAgICAgIGNsaWVudF9pZDogbnVsbCBhcyBudW1iZXIgfCBudWxsLFxuICAgICAgICBjbGllbnRfbmFtZTogdW5kZWZpbmVkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICAgICAgY3VzdG9tZXJfY29kZTogdW5kZWZpbmVkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICAgICAgdmVuZG9yX2lkOiBudWxsIGFzIG51bWJlciB8IG51bGwsXG4gICAgICAgIHZlbmRvcl9uYW1lOiB1bmRlZmluZWQgYXMgc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgICAgICB2ZW5kb3JfY29kZTogdW5kZWZpbmVkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICAgICAgcmVmZXJlbmNlOiAnJyxcbiAgICAgICAgdm91Y2hlcjogJycsXG4gICAgICAgIGRlbGl2ZXJ5X25vdGU6ICcnLFxuICAgIH0pO1xuXG4gICAgY29uc3QgW3Byb2R1Y3RzLCBzZXRQcm9kdWN0c10gPSB1c2VTdGF0ZTxQcm9kdWN0RW50cnlbXT4oW10pO1xuXG4gICAgLy8gRXN0YWRvcyBUcmlhbmd1bGFyZXMgKElucHV0cyBkZSBUZXh0bylcbiAgICBjb25zdCBbY2xpZW50Q29kZUlucHV0LCBzZXRDbGllbnRDb2RlSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt2ZW5kb3JDb2RlSW5wdXQsIHNldFZlbmRvckNvZGVJbnB1dF0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICAvLyBNb2RhbFxuICAgIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPEVkaXRpbmdUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbW9kYWxDb25maWcsIHNldE1vZGFsQ29uZmlnXSA9IHVzZVN0YXRlPGFueT4obnVsbCk7XG5cbiAgICAvLyAtLS0gMi4gRUZFQ1RPIERFIElOSUNJQUxJWkFDScOTTiAoTW9kbyBFZGljacOzbikgLS0tXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1vZGUgPT09ICdlZGl0JyAmJiBpbml0aWFsRGF0YSkge1xuICAgICAgICAgICAgLy8gQS4gUG9ibGFyIGNhYmVjZXJhXG4gICAgICAgICAgICBzZXRDb21tb25EYXRhKHtcbiAgICAgICAgICAgICAgICBtb3ZlbWVudF9kYXRlOiBpbml0aWFsRGF0YS5tb3ZlbWVudF9kYXRlID8gaW5pdGlhbERhdGEubW92ZW1lbnRfZGF0ZS5zcGxpdCgnVCcpWzBdIDogJycsXG4gICAgICAgICAgICAgICAgbW92ZW1lbnRfY29kZTogaW5pdGlhbERhdGEubW92ZW1lbnRfY29kZSxcbiAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IGluaXRpYWxEYXRhLmNsaWVudF9pZCxcbiAgICAgICAgICAgICAgICBjbGllbnRfbmFtZTogaW5pdGlhbERhdGEuY2xpZW50X25hbWUsXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJfY29kZTogaW5pdGlhbERhdGEuY3VzdG9tZXJfY29kZSxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGluaXRpYWxEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfbmFtZTogaW5pdGlhbERhdGEudmVuZG9yX25hbWUsXG4gICAgICAgICAgICAgICAgdmVuZG9yX2NvZGU6IGluaXRpYWxEYXRhLnZlbmRvcl9jb2RlLFxuICAgICAgICAgICAgICAgIHJlZmVyZW5jZTogaW5pdGlhbERhdGEucmVmZXJlbmNlIHx8ICcnLFxuICAgICAgICAgICAgICAgIHZvdWNoZXI6IGluaXRpYWxEYXRhLnZvdWNoZXIgfHwgJycsXG4gICAgICAgICAgICAgICAgZGVsaXZlcnlfbm90ZTogaW5pdGlhbERhdGEuZGVsaXZlcnlfbm90ZSB8fCAnJyxcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBCLiBQb2JsYXIgY8OzZGlnb3MgZGUgY2FiZWNlcmEgKFNpIGFwbGljYSlcbiAgICAgICAgICAgIC8vIEFzdW1pZW5kbyBxdWUgaW5pdGlhbERhdGEgdHJhZSBlbCBDVUlUL0PDs2RpZ28gbyB1c2FuZG8gZWwgSUQgY29tbyBmYWxsYmFja1xuICAgICAgICAgICAgaWYgKGluaXRpYWxEYXRhLmNsaWVudF9pZCkgc2V0Q2xpZW50Q29kZUlucHV0KFN0cmluZyhpbml0aWFsRGF0YS5jdXN0b21lcl9jb2RlKSk7XG4gICAgICAgICAgICBpZiAoaW5pdGlhbERhdGEudmVuZG9yX2lkKSBzZXRWZW5kb3JDb2RlSW5wdXQoU3RyaW5nKGluaXRpYWxEYXRhLnZlbmRvcl9jb2RlKSk7XG5cbiAgICAgICAgICAgIC8vIEMuIFBvYmxhciBwcm9kdWN0b3NcbiAgICAgICAgICAgIC8vIElNUE9SVEFOVEU6IEVuIGVkaWNpw7NuIHN1ZWxlIHNlciAxIG1vdmltaWVudG8gPSAxIHByb2R1Y3RvLiBcbiAgICAgICAgICAgIC8vIFNpIHR1IGJhY2tlbmQgc29wb3J0YSBlZGl0YXIgbG90ZXMsIGFxdcOtIG1hcGVhcsOtYXMgZWwgYXJyYXkuXG4gICAgICAgICAgICAvLyBBc3VtaXJlbW9zIGVzdHJ1Y3R1cmEgc2ltcGxlIHBhcmEgZXN0ZSBlamVtcGxvOlxuICAgICAgICAgICAgc2V0UHJvZHVjdHMoW3tcbiAgICAgICAgICAgICAgICB0ZW1wSWQ6ICdlZGl0LWl0ZW0tMScsXG4gICAgICAgICAgICAgICAgcHJvZHVjdDoge1xuICAgICAgICAgICAgICAgICAgICBpZDogaW5pdGlhbERhdGEucHJvZHVjdF9pZCxcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogaW5pdGlhbERhdGEucHJvZHVjdF9uYW1lIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBza3U6IGluaXRpYWxEYXRhLnNrdSB8fCAnJywvLyBTaSBlbCBiYWNrZW5kIG5vIHRyYWUgZWwgY8OzZGlnbyBkZWwgcHJvZHVjdG8sIHF1ZWRhcsOhIHZhY8OtbyBoYXN0YSBxdWUgYnVzcXVlblxuICAgICAgICAgICAgICAgIH0gYXMgQXJ0aWN1bG8sXG4gICAgICAgICAgICAgICAgcXVhbnRpdHk6IGluaXRpYWxEYXRhLnF1YW50aXR5LFxuICAgICAgICAgICAgICAgIHVpX3Byb2R1Y3RfY29kZTogaW5pdGlhbERhdGEuc2t1IHx8ICcnLCAvLyBPIGluaWNpYWxEYXRhLnByb2R1Y3RfY29kZSBzaSBsbyB0aWVuZXNcbiAgICAgICAgICAgIH1dKTtcbiAgICAgICAgfVxuICAgIH0sIFttb2RlLCBpbml0aWFsRGF0YV0pO1xuXG5cbiAgICAvLyAtLS0gMy4gSEFORExFUlMgTMOTR0lDT1MgKElndWFsZXMgYWwgQ3JlYXRlIGFudGVyaW9yKSAtLS1cblxuICAgIC8vIC4uLiAoSGFuZGxlcnMgZGUgUHJvZHVjdHM6IEFkZCwgUmVtb3ZlLCBVcGRhdGUpIC4uLlxuICAgIGNvbnN0IGhhbmRsZUFkZFByb2R1Y3RSb3cgPSAoKSA9PiB7XG4gICAgICAgIHNldFByb2R1Y3RzKHAgPT4gWy4uLnAsIHsgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLCBwcm9kdWN0OiBudWxsLCBxdWFudGl0eTogMSwgdWlfcHJvZHVjdF9jb2RlOiAnJyB9XSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZW1vdmVQcm9kdWN0Um93ID0gKHRlbXBJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldFByb2R1Y3RzKHAgPT4gcC5maWx0ZXIoaXRlbSA9PiBpdGVtLnRlbXBJZCAhPT0gdGVtcElkKSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVVcGRhdGVQcm9kdWN0Um93ID0gKHRlbXBJZDogc3RyaW5nLCBmaWVsZDoga2V5b2YgUHJvZHVjdEVudHJ5LCB2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgIHNldFByb2R1Y3RzKHAgPT4gcC5tYXAoaXRlbSA9PiBpdGVtLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5pdGVtLCBbZmllbGRdOiB2YWx1ZSB9IDogaXRlbSkpO1xuICAgIH07XG5cbiAgICAvLyAuLi4gKEhhbmRsZXJzIGRlIELDunNxdWVkYSBUcmlhbmd1bGFyKSAuLi5cbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0Q29kZVN1Ym1pdCA9IGFzeW5jICh0ZW1wSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBpdGVtSW5kZXggPSBwcm9kdWN0cy5maW5kSW5kZXgocCA9PiBwLnRlbXBJZCA9PT0gdGVtcElkKTtcbiAgICAgICAgaWYgKGl0ZW1JbmRleCA9PT0gLTEpIHJldHVybjtcbiAgICAgICAgY29uc3QgaXRlbSA9IHByb2R1Y3RzW2l0ZW1JbmRleF07XG4gICAgICAgIGlmICghaXRlbS51aV9wcm9kdWN0X2NvZGUpIHJldHVybjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8g4pyFIEJ1c2NhciBjb24gZWwgZm9ybWF0byBkZSBtw6FzY2FyYSAoaW5jbHV5ZSBwdW50b3MpXG4gICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8QXJ0aWN1bG8+KGFydGljdWxvc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgW3sgZmllbGROYW1lOiAnc2t1JywgdmFsdWU6IGl0ZW0udWlfcHJvZHVjdF9jb2RlIH1dKTtcbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIHNldFByb2R1Y3RzKHByZXYgPT4gcHJldi5tYXAocCA9PiBwLnRlbXBJZCA9PT0gdGVtcElkID8geyAuLi5wLCBwcm9kdWN0OiBmb3VuZCwgdWlfcHJvZHVjdF9jb2RlOiBmb3VuZC5za3UgfSA6IHApKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3Qud2FybihgUHJvZHVjdG8gbm8gZW5jb250cmFkby5gKTtcbiAgICAgICAgICAgICAgICBzZXRQcm9kdWN0cyhwcmV2ID0+IHByZXYubWFwKHAgPT4gcC50ZW1wSWQgPT09IHRlbXBJZCA/IHsgLi4ucCwgcHJvZHVjdDogbnVsbCB9IDogcCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikgeyBjb25zb2xlLmVycm9yKGVycm9yKTsgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVFbnRpdHlDb2RlU3VibWl0ID0gYXN5bmMgKHR5cGU6ICdjbGllbnQnIHwgJ3ZlbmRvcicpID0+IHtcbiAgICAgICAgY29uc3QgY29kZSA9IHR5cGUgPT09ICdjbGllbnQnID8gY2xpZW50Q29kZUlucHV0IDogdmVuZG9yQ29kZUlucHV0O1xuICAgICAgICBpZiAoIWNvZGUpIHJldHVybjtcbiAgICAgICAgY29uc3QgY29uZmlnID0gdHlwZSA9PT0gJ2NsaWVudCcgPyBjbGllbnRlc01vZHVsZUNvbmZpZyA6IHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8YW55Pihjb25maWcuZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogdHlwZSA9PT0gJ2NsaWVudCcgPyAnY3VzdG9tZXJfY29kZScgOiAndmVuZG9yX2NvZGUnLCB2YWx1ZTogY29kZSB9XSk7IC8vIEFqdXN0YXIgJ2N1aXQnIHNlZ8O6biBjb3JyZXNwb25kYVxuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGUgPT09ICdjbGllbnQnKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldENvbW1vbkRhdGEocCA9PiAoeyAuLi5wLCBjbGllbnRfaWQ6IGZvdW5kLmlkLCBjbGllbnRfbmFtZTogZm91bmQubmFtZSB9KSk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudENvZGVJbnB1dChmb3VuZC5jdXN0b21lcl9jb2RlIHx8IFN0cmluZyhmb3VuZC5pZCkpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNldENvbW1vbkRhdGEocCA9PiAoeyAuLi5wLCB2ZW5kb3JfaWQ6IGZvdW5kLmlkLCB2ZW5kb3JfbmFtZTogZm91bmQubmFtZSB9KSk7XG4gICAgICAgICAgICAgICAgICAgIHNldFZlbmRvckNvZGVJbnB1dChmb3VuZC52ZW5kb3JfY29kZSB8fCBTdHJpbmcoZm91bmQuaWQpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgJHt0eXBlID09PSAnY2xpZW50JyA/ICdDbGllbnRlJyA6ICdQcm92ZWVkb3InfSBlbmNvbnRyYWRvLmApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC53YXJuKFwiUmVnaXN0cm8gbm8gZW5jb250cmFkby5cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgY29uc29sZS5lcnJvcihlKTsgfVxuICAgIH07XG5cbiAgICAvLyAuLi4gKEhhbmRsZXJzIGRlIFVJIGNvbXVuZXMpIC4uLlxuICAgIGNvbnN0IGhhbmRsZUNvbW1vbkRhdGFDaGFuZ2UgPSAoZmllbGQ6IGtleW9mIHR5cGVvZiBjb21tb25EYXRhLCB2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgIHNldENvbW1vbkRhdGEocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfTtcbiAgICAgICAgICAgIGlmIChmaWVsZCA9PT0gJ21vdmVtZW50X2NvZGUnKSB7XG4gICAgICAgICAgICAgICAgbmV3U3RhdGUuY2xpZW50X2lkID0gbnVsbDsgbmV3U3RhdGUuY2xpZW50X25hbWUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgbmV3U3RhdGUudmVuZG9yX2lkID0gbnVsbDsgbmV3U3RhdGUudmVuZG9yX25hbWUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50Q29kZUlucHV0KCcnKTsgc2V0VmVuZG9yQ29kZUlucHV0KCcnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBuZXdTdGF0ZTtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIC4uLiAoSGFuZGxlcnMgZGUgTW9kYWwpIC4uLlxuICAgIGNvbnN0IG9wZW5Nb2RhbCA9ICh0YXJnZXQ6IEVkaXRpbmdUYXJnZXQsIGNvbmZpZzogYW55KSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdUYXJnZXQodGFyZ2V0KTtcbiAgICAgICAgc2V0TW9kYWxDb25maWcoY29uZmlnKTtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdCA9IChzZWxlY3RlZEl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ2NsaWVudCcpIHtcbiAgICAgICAgICAgIHNldENvbW1vbkRhdGEocCA9PiAoeyAuLi5wLCBjbGllbnRfaWQ6IHNlbGVjdGVkSXRlbS5pZCwgY2xpZW50X25hbWU6IHNlbGVjdGVkSXRlbS5uYW1lIH0pKTtcbiAgICAgICAgICAgIHNldENsaWVudENvZGVJbnB1dChzZWxlY3RlZEl0ZW0uY3VzdG9tZXJfY29kZSB8fCBTdHJpbmcoc2VsZWN0ZWRJdGVtLmlkKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ3ZlbmRvcicpIHtcbiAgICAgICAgICAgIHNldENvbW1vbkRhdGEocCA9PiAoeyAuLi5wLCB2ZW5kb3JfaWQ6IHNlbGVjdGVkSXRlbS5pZCwgdmVuZG9yX25hbWU6IHNlbGVjdGVkSXRlbS5uYW1lIH0pKTtcbiAgICAgICAgICAgIHNldFZlbmRvckNvZGVJbnB1dChzZWxlY3RlZEl0ZW0udmVuZG9yX2NvZGUgfHwgU3RyaW5nKHNlbGVjdGVkSXRlbS5pZCkpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBlZGl0aW5nVGFyZ2V0ID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgc2V0UHJvZHVjdHMocHJldlByb2R1Y3RzID0+IHByZXZQcm9kdWN0cy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gU2kgbm8gZXMgbGEgZmlsYSBxdWUgZXN0YW1vcyBlZGl0YW5kbywgbGEgZGVqYW1vcyBpZ3VhbFxuICAgICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gZWRpdGluZ1RhcmdldCkgcmV0dXJuIGl0ZW07XG5cbiAgICAgICAgICAgICAgICAvLyBTaSBFUyBsYSBmaWxhLCBhY3R1YWxpemFtb3MgcHJvZHVjdG8gWSBlbCBjw7NkaWdvIHZpc3VhbCAoc2t1KVxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3Q6IHNlbGVjdGVkSXRlbSxcbiAgICAgICAgICAgICAgICAgICAgLy8g4pyFIE1BR0lBIEFRVcONOiBMbGVuYW1vcyBlbCBpbnB1dCB0cmlhbmd1bGFyIGNvbiBlbCBjw7NkaWdvIGRlbCDDrXRlbSBzZWxlY2Npb25hZG9cbiAgICAgICAgICAgICAgICAgICAgLy8gQWdyZWd1w6kgJ3NrdScgcG9yIHNpIGFjYXNvIHR1IGJhY2tlbmQgbG8gbGxhbWEgYXPDrSBlbiB2ZXogZGUgJ2NvZGUnXG4gICAgICAgICAgICAgICAgICAgIHVpX3Byb2R1Y3RfY29kZTogc2VsZWN0ZWRJdGVtLmNvZGUgfHwgc2VsZWN0ZWRJdGVtLnNrdSB8fCBTdHJpbmcoc2VsZWN0ZWRJdGVtLmlkKVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gNC4gUFJFUEFSQUNJw5NOIERFIERBVE9TIFBBUkEgRU5Ww41PIC0tLVxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gVmFsaWRhY2lvbmVzIGLDoXNpY2FzIGRlIFVJIGFudGVzIGRlIHBhc2FyIGFsIHBhZHJlXG4gICAgICAgIGlmICghY29tbW9uRGF0YS5tb3ZlbWVudF9jb2RlKSB7IHRvYXN0LmVycm9yKCdEZWJlIHNlbGVjY2lvbmFyIHVuIHRpcG8uJyk7IHJldHVybjsgfVxuICAgICAgICBpZiAocHJvZHVjdHMubGVuZ3RoID09PSAwIHx8IHByb2R1Y3RzLnNvbWUocCA9PiAhcC5wcm9kdWN0IHx8IHAucXVhbnRpdHkgPD0gMCkpIHsgdG9hc3QuZXJyb3IoJ1Byb2R1Y3RvcyBpbnbDoWxpZG9zLicpOyByZXR1cm47IH1cbiAgICAgICAgaWYgKGNvbW1vbkRhdGEubW92ZW1lbnRfY29kZSA9PT0gJ0EnICYmICghY29tbW9uRGF0YS52ZW5kb3JfaWQgfHwgIWNvbW1vbkRhdGEuZGVsaXZlcnlfbm90ZSkpIHsgdG9hc3QuZXJyb3IoJ0RhdG9zIGRlIHByb3ZlZWRvciBpbmNvbXBsZXRvcy4nKTsgcmV0dXJuOyB9XG5cbiAgICAgICAgYXdhaXQgb25TdWJtaXQoeyBjb21tb25EYXRhLCBwcm9kdWN0cyB9KTtcbiAgICB9O1xuXG4gICAgLy8gTMOzZ2ljYSB2aXN1YWwgY29uZGljaW9uYWxcbiAgICBjb25zdCBzaG93Q2xpZW50ID0gY29tbW9uRGF0YS5tb3ZlbWVudF9jb2RlICE9PSAnQSc7XG4gICAgY29uc3Qgc2hvd1ZlbmRvciA9IGNvbW1vbkRhdGEubW92ZW1lbnRfY29kZSAhPT0gJ0YnO1xuICAgIGNvbnN0IHNob3dEZWxpdmVyeU5vdGUgPSBjb21tb25EYXRhLm1vdmVtZW50X2NvZGUgPT09ICdBJztcbiAgICBjb25zdCB0YWJsZUlucHV0U3R5bGVzID0gXCJ3LWZ1bGwgcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCI7XG5cbiAgICBjb25zdCB0b3RhbENhbnRpZGFkQXJ0aWN1bG9zID0gcHJvZHVjdHMucmVkdWNlKChzdW0sIHApID0+IHtcbiAgICAgICAgY29uc3QgcSA9IHAucXVhbnRpdHk7XG4gICAgICAgIHJldHVybiBzdW0gKyAodHlwZW9mIHEgPT09ICdudW1iZXInICYmICFOdW1iZXIuaXNOYU4ocSkgPyBxIDogMCk7XG4gICAgfSwgMCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS04XCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZScgPyAnQ3JlYXIgTW92aW1pZW50byhzKScgOiAnRWRpdGFyIE1vdmltaWVudG8nfVxuICAgICAgICAgICAgPC9oMT5cblxuICAgICAgICAgICAgey8qIC0tLSBTRUNDScOTTiBEQVRPUyBHRU5FUkFMRVMgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIEZlY2hhICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtX2RhdGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GZWNoYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJtX2RhdGVcIiB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtjb21tb25EYXRhLm1vdmVtZW50X2RhdGV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUNvbW1vbkRhdGFDaGFuZ2UoJ21vdmVtZW50X2RhdGUnLCBlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT17dGFibGVJbnB1dFN0eWxlc30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBUaXBvICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtX2NvZGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5UaXBvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgaWQ9XCJtX2NvZGVcIiB2YWx1ZT17Y29tbW9uRGF0YS5tb3ZlbWVudF9jb2RlfSBvbkNoYW5nZT17ZSA9PiBoYW5kbGVDb21tb25EYXRhQ2hhbmdlKCdtb3ZlbWVudF9jb2RlJywgZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9e3RhYmxlSW5wdXRTdHlsZXN9IGRpc2FibGVkPXttb2RlID09PSAnZWRpdCd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25lLi4uPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFcIj5BIC0gQ29tcHJhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJcIj5CIC0gQmFqYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDXCI+QyAtIEFqdXN0ZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEXCI+RCAtIERldm9sdWNpw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkZcIj5GIC0gVmVudGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU1wiPlMgLSBTYWxpZGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQ2xpZW50ZSAvIFByb3ZlZWRvciBjb24gUmVsYXRpb25hbElucHV0ICovfVxuICAgICAgICAgICAgICAgICAgICB7c2hvd0NsaWVudCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5DbGllbnRlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Y2xpZW50Q29kZUlucHV0fSBuYW1lVmFsdWU9e2NvbW1vbkRhdGEuY2xpZW50X25hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXtzZXRDbGllbnRDb2RlSW5wdXR9IG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlRW50aXR5Q29kZVN1Ym1pdCgnY2xpZW50Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IG9wZW5Nb2RhbCgnY2xpZW50JywgY2xpZW50ZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHsgaGFuZGxlQ29tbW9uRGF0YUNoYW5nZSgnY2xpZW50X2lkJywgbnVsbCk7IGhhbmRsZUNvbW1vbkRhdGFDaGFuZ2UoJ2NsaWVudF9uYW1lJywgdW5kZWZpbmVkKTsgc2V0Q2xpZW50Q29kZUlucHV0KCcnKTsgfX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge3Nob3dWZW5kb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UHJvdmVlZG9yPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17dmVuZG9yQ29kZUlucHV0fSBuYW1lVmFsdWU9e2NvbW1vbkRhdGEudmVuZG9yX25hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXtzZXRWZW5kb3JDb2RlSW5wdXR9IG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlRW50aXR5Q29kZVN1Ym1pdCgndmVuZG9yJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IG9wZW5Nb2RhbCgndmVuZG9yJywgcHJvdmVlZG9yZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHsgaGFuZGxlQ29tbW9uRGF0YUNoYW5nZSgndmVuZG9yX2lkJywgbnVsbCk7IGhhbmRsZUNvbW1vbkRhdGFDaGFuZ2UoJ3ZlbmRvcl9uYW1lJywgdW5kZWZpbmVkKTsgc2V0VmVuZG9yQ29kZUlucHV0KCcnKTsgfX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogT3Ryb3MgY2FtcG9zIFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ2b3VjaGVyXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Q29tcHJvYmFudGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwidm91Y2hlclwiIHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NvbW1vbkRhdGEudm91Y2hlcn0gb25DaGFuZ2U9e2UgPT4gaGFuZGxlQ29tbW9uRGF0YUNoYW5nZSgndm91Y2hlcicsIGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPXt0YWJsZUlucHV0U3R5bGVzfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKi99XG4gICAgICAgICAgICAgICAgICAgIHtzaG93RGVsaXZlcnlOb3RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkZWxfbm90ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlJlbWl0bzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiZGVsX25vdGVcIiB0eXBlPVwidGV4dFwiIHZhbHVlPXtjb21tb25EYXRhLmRlbGl2ZXJ5X25vdGV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUNvbW1vbkRhdGFDaGFuZ2UoJ2RlbGl2ZXJ5X25vdGUnLCBlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT17dGFibGVJbnB1dFN0eWxlc30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJyZWZcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5SZWZlcmVuY2lhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cInJlZlwiIHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NvbW1vbkRhdGEucmVmZXJlbmNlfSBvbkNoYW5nZT17ZSA9PiBoYW5kbGVDb21tb25EYXRhQ2hhbmdlKCdyZWZlcmVuY2UnLCBlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT17dGFibGVJbnB1dFN0eWxlc30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBTRUNDScOTTiBQUk9EVUNUT1MgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UHJvZHVjdG9zPC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHctMi81XCI+UHJvZHVjdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnRpZGFkPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5QcmVjaW8gZGUgY29tcHJhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5Nb25lZGEgZGUgY29tcHJhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb2R1Y3RzLm1hcCgocCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cC50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtwLnVpX3Byb2R1Y3RfY29kZX0gbmFtZVZhbHVlPXtwLnByb2R1Y3Q/Lm5hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVVcGRhdGVQcm9kdWN0Um93KHAudGVtcElkLCAndWlfcHJvZHVjdF9jb2RlJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVQcm9kdWN0Q29kZVN1Ym1pdChwLnRlbXBJZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IG9wZW5Nb2RhbChpbmRleCwgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBzZXRQcm9kdWN0cyhwciA9PiBwci5tYXAoaSA9PiBpLnRlbXBJZCA9PT0gcC50ZW1wSWQgPyB7IC4uLmksIHByb2R1Y3Q6IG51bGwsIHVpX3Byb2R1Y3RfY29kZTogJycgfSA6IGkpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFzaz1cInNrdVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuYWJsZUF1dG9jb21wbGV0ZT17dHJ1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b2NvbXBsZXRlQ29uZmlnPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRwb2ludDogYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnc2t1JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ25hbWUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q6IChwcm9kdWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UHJvZHVjdHMocHJldiA9PiBwcmV2Lm1hcChwciA9PiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHIudGVtcElkID09PSBwLnRlbXBJZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5wciwgcHJvZHVjdDogcHJvZHVjdCwgdWlfcHJvZHVjdF9jb2RlOiBwcm9kdWN0LnNrdSB9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBwclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXQgdmFsdWU9e3AucXVhbnRpdHl9IG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlVXBkYXRlUHJvZHVjdFJvdyhwLnRlbXBJZCwgJ3F1YW50aXR5JywgbnVtKX0gY2xhc3NOYW1lPXt0YWJsZUlucHV0U3R5bGVzfSBhcmlhLWxhYmVsPXtgQ2FudGlkYWQgJHtpbmRleCArIDF9YH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTcwMCB0YWJ1bGFyLW51bXMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHVyY2hhc2VQcmljZURpc3BsYXkocC5wcm9kdWN0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTcwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwLnByb2R1Y3QgPyBjb3N0Q3VycmVuY3lMYWJlbChwLnByb2R1Y3QuY29zdF9jdXJyZW5jeSkgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU29sbyBwZXJtaXRpbW9zIGJvcnJhciBzaSBoYXkgbcOhcyBkZSAxIG8gc2kgZXMgY3JlYWNpw7NuLCBlbiBlZGljacOzbiBkZSAxIGl0ZW0gw7puaWNvIHF1aXrDoXMgcXVpZXJhcyBibG9xdWVhciBib3JyYXIgZWwgw7puaWNvIGl0ZW0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVQcm9kdWN0Um93KHAudGVtcElkKX0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMFwiIGFyaWEtbGFiZWw9XCJCb3JyYXJcIj48RmFUcmFzaCAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZScgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Zm9vdCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBhcnTDrWN1bG9zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxDYW50aWRhZEFydGljdWxvc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rmb290PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogQm90w7NuIGHDsWFkaXIgc29sbyBzaSBlcyBjcmVhY2nDs24gbyBzaSB0dSBsw7NnaWNhIGRlIG5lZ29jaW8gcGVybWl0ZSBhZ3JlZ2FyIGl0ZW1zIGFsIGVkaXRhciAqL31cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZScgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUFkZFByb2R1Y3RSb3d9IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgbXQtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEHDsWFkaXIgUHJvZHVjdG9cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIEZPT1RFUiBBQ0NJT05FUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTUwXCI+Q2FuY2VsYXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9IGRpc2FibGVkPXtsb2FkaW5nfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyZWVuLTYwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpiZy1ncmVlbi00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiBhbmltYXRlLXNwaW5cIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9IG9uU2VsZWN0PXtoYW5kbGVTZWxlY3R9IGNvbmZpZz17bW9kYWxDb25maWd9IC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21vdl9zdG9jay9wYWdlcy9Nb3ZTdG9ja0Zvcm1QYWdlLnRzeCJ9