import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { notasFinancierasModuleConfig } from "/src/features/notas_financieras/notas_financieras.config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getModuleBasePermission, getRequiredPermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const NotasFinancierasListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(notasFinancierasModuleConfig, getDefaultListDateRange());
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(notasFinancierasModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const hasEditPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const hasDeletePermission = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEditNote = (note) => {
    return hasEditPermission && !note.cae_number;
  };
  const canDeleteNote = (note) => {
    return hasDeletePermission && !note.cae_number;
  };
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx",
    lineNumber: 49,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: notasFinancierasModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit: canEditNote,
      canDelete: canDeleteNote
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx",
      lineNumber: 52,
      columnNumber: 5
    },
    this
  );
};
_s(NotasFinancierasListPage, "yjB/rutd0ICjbFA72BDSbAuQTHI=", false, function() {
  return [useCrud, usePermissions];
});
_c = NotasFinancierasListPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG9DQUF3RDtBQUNqRSxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCQyw2QkFBNkI7QUFDL0QsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLDJCQUEyQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJbkIsUUFBdUJDLDhCQUE4Qkksd0JBQXdCLENBQUM7QUFHbEYsUUFBTSxFQUFFZSxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTW1CLG1CQUFtQmpCLHNCQUFzQkgsNkJBQTZCcUIsU0FBUztBQUNyRixRQUFNQyxhQUFhRixtQkFBbUJsQix3QkFBd0JrQixnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxvQkFBb0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFDakYsUUFBTUUsc0JBQXNCRixhQUFhSCxvQkFBb0JHLFlBQVksUUFBUSxJQUFJO0FBR3JGLFFBQU1HLGNBQWNBLENBQUNDLFNBQWlDO0FBQ2xELFdBQU9ILHFCQUFxQixDQUFDRyxLQUFLQztBQUFBQSxFQUN0QztBQUVBLFFBQU1DLGdCQUFnQkEsQ0FBQ0YsU0FBaUM7QUFDcEQsV0FBT0YsdUJBQXVCLENBQUNFLEtBQUtDO0FBQUFBLEVBQ3hDO0FBRUEsTUFBSWpCLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRVjtBQUFBQSxNQUNSLG9CQUFvQk87QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhVyxRQUFRO0FBQUEsTUFDakMsaUJBQWlCWCxhQUFhWSxhQUFhO0FBQUEsTUFDM0MsZUFBZVosYUFBYWEsV0FBVztBQUFBLE1BQ3ZDLHVCQUF1QjtBQUFBLE1BQ3ZCLFNBQVNOO0FBQUFBLE1BQ1QsV0FBV0c7QUFBQUE7QUFBQUEsSUFqQmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUI2QjtBQUdyQztBQUFFdEIsR0E3Q1dELDBCQUF3QjtBQUFBLFVBSTdCTixTQUc0QkUsY0FBYztBQUFBO0FBQUErQixLQVByQzNCO0FBQXdCLElBQUEyQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsIm5vdGFzRmluYW5jaWVyYXNNb2R1bGVDb25maWciLCJ1c2VQZXJtaXNzaW9ucyIsImdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJOb3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJoYXNFZGl0UGVybWlzc2lvbiIsImhhc0RlbGV0ZVBlcm1pc3Npb24iLCJjYW5FZGl0Tm90ZSIsIm5vdGUiLCJjYWVfbnVtYmVyIiwiY2FuRGVsZXRlTm90ZSIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90YXNGaW5hbmNpZXJhc0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgbm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZywgdHlwZSBGaW5hbmNpYWxOb3RlIH0gZnJvbSAnLi4vbm90YXNfZmluYW5jaWVyYXMuY29uZmlnJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24sIGdldFJlcXVpcmVkUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdERhdGVSYW5nZSc7XG5cbmV4cG9ydCBjb25zdCBOb3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxGaW5hbmNpYWxOb3RlPihub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnLCBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSgpKTtcblxuICAgIC8vIOKchSBQZXJtaXNvcyBkZWwgbcOzZHVsb1xuICAgIGNvbnN0IHsgaGFzTW9kdWxlUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKTtcbiAgICBjb25zdCBtb2R1bGVQZXJtaXNzaW9uID0gZ2V0UmVxdWlyZWRQZXJtaXNzaW9uKG5vdGFzRmluYW5jaWVyYXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBoYXNFZGl0UGVybWlzc2lvbiA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuICAgIGNvbnN0IGhhc0RlbGV0ZVBlcm1pc3Npb24gPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnZGVsZXRlJykgOiB0cnVlO1xuXG4gICAgLy8g4pyFIFJlZ2xhcyBjb21iaW5hZGFzOiBwZXJtaXNvICsgQ0FFXG4gICAgY29uc3QgY2FuRWRpdE5vdGUgPSAobm90ZTogRmluYW5jaWFsTm90ZSk6IGJvb2xlYW4gPT4ge1xuICAgICAgICByZXR1cm4gaGFzRWRpdFBlcm1pc3Npb24gJiYgIW5vdGUuY2FlX251bWJlcjtcbiAgICB9O1xuXG4gICAgY29uc3QgY2FuRGVsZXRlTm90ZSA9IChub3RlOiBGaW5hbmNpYWxOb3RlKTogYm9vbGVhbiA9PiB7XG4gICAgICAgIHJldHVybiBoYXNEZWxldGVQZXJtaXNzaW9uICYmICFub3RlLmNhZV9udW1iZXI7XG4gICAgfTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8RmluYW5jaWFsTm90ZT5cbiAgICAgICAgICAgIGNvbmZpZz17bm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgb25EZWxldGU9e2RlbGV0ZUl0ZW19XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJTdGFydD17c2VhcmNoUGFyYW1zLnN0YXJ0RGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJFbmQ9e3NlYXJjaFBhcmFtcy5lbmREYXRlID8/ICcnfVxuICAgICAgICAgICAgZW5hYmxlRGF0ZVJhbmdlRmlsdGVyPXt0cnVlfVxuICAgICAgICAgICAgY2FuRWRpdD17Y2FuRWRpdE5vdGV9XG4gICAgICAgICAgICBjYW5EZWxldGU9e2NhbkRlbGV0ZU5vdGV9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG5cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXMvcGFnZXMvTm90YXNGaW5hbmNpZXJhc0xpc3RQYWdlLnRzeCJ9