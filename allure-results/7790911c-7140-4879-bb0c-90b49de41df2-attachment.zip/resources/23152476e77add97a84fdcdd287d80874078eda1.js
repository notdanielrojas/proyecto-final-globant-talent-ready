import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { ordenesPagoModuleConfig } from "/src/features/ordenes_pago/ordenes_pago.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const OrdenesPagoListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(ordenesPagoModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: ordenesPagoModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx",
      lineNumber: 34,
      columnNumber: 5
    },
    this
  );
};
_s(OrdenesPagoListPage, "OpZ0ArL+5wGVsfZK9Ifi0y1Fv3w=", false, function() {
  return [useCrud];
});
_c = OrdenesPagoListPage;
var _c;
$RefreshReg$(_c, "OrdenesPagoListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3NCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVh0QixTQUFTQSx1QkFBdUI7QUFDaEMsU0FBU0MsK0JBQWtEO0FBQzNELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLHNCQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJZixRQUFzQkQseUJBQXlCRSx3QkFBd0IsQ0FBQztBQUU1RSxNQUFJTSxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFdkQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVI7QUFBQUEsTUFDUixvQkFBb0JLO0FBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBVUk7QUFBQUEsTUFDVixRQUFRQztBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0EsY0FBY0c7QUFBQUEsTUFDZCxZQUFZQztBQUFBQSxNQUNaLFVBQVVDO0FBQUFBLE1BQ1YsWUFBWUMsYUFBYUMsUUFBUTtBQUFBLE1BQ2pDLGlCQUFpQkQsYUFBYUUsYUFBYTtBQUFBLE1BQzNDLGVBQWVGLGFBQWFHLFdBQVc7QUFBQSxNQUN2Qyx1QkFBdUI7QUFBQTtBQUFBLElBZjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWVnQztBQUd4QztBQUFFZixHQTNCV0QscUJBQW1CO0FBQUEsVUFJeEJGLE9BQU87QUFBQTtBQUFBbUIsS0FKRmpCO0FBQW1CLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwib3JkZW5lc1BhZ29Nb2R1bGVDb25maWciLCJ1c2VDcnVkIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJPcmRlbmVzUGFnb0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcmRlbmVzUGFnb0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgb3JkZW5lc1BhZ29Nb2R1bGVDb25maWcsIHR5cGUgUGF5bWVudE9yZGVyIH0gZnJvbSAnLi4vb3JkZW5lc19wYWdvLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuXG5leHBvcnQgY29uc3QgT3JkZW5lc1BhZ29MaXN0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7XG4gICAgICAgIHJlc3BvbnNlLCBsb2FkaW5nLCBpc0FwcGVuZGluZywgZXJyb3IsIGRlbGV0ZUl0ZW0sIGhhbmRsZVNvcnQsIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbiwgaGFuZGxlUGFnZUNoYW5nZSwgaGFuZGxlTG9hZE1vcmUsIGhhbmRsZVNlYXJjaCwgc2VhcmNoUGFyYW1zLFxuICAgIH0gPSB1c2VDcnVkPFBheW1lbnRPcmRlcj4ob3JkZW5lc1BhZ29Nb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxQYXltZW50T3JkZXI+XG4gICAgICAgICAgICBjb25maWc9e29yZGVuZXNQYWdvTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL29yZGVuZXNfcGFnby9wYWdlcy9PcmRlbmVzUGFnb0xpc3RQYWdlLnRzeCJ9