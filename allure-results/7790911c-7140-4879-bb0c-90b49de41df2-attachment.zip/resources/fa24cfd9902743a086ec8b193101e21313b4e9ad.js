import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profiles/pages/ProfileEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/profiles/pages/ProfileEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { profilesModuleConfig } from "/src/features/profiles/profiles.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getPermissions } from "/src/services/apiService.ts";
import { groupBy } from "/src/utils/helpers.ts";
import { getPermissionLabel, getPermissionModuleTitle, sortPermissionsForDisplay } from "/src/utils/translations.ts";
export const ProfileEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: profile, loading: loadingProfile, error: errorProfile, saveItem } = useCrudItem(profilesModuleConfig, id);
  const [_, setAllPermissions] = useState([]);
  const [loadingPermissions, setLoadingPermissions] = useState(true);
  const [groupedPermissions, setGroupedPermissions] = useState({});
  const [selectedPermissions, setSelectedPermissions] = useState([]);
  const [profileName, setProfileName] = useState("");
  useEffect(() => {
    getPermissions().then((permissions) => {
      setAllPermissions(permissions);
      setGroupedPermissions(groupBy(permissions, (p) => p.name.split(".")[0]));
    }).catch((error) => console.error("Error loading permissions:", error)).finally(() => setLoadingPermissions(false));
  }, []);
  useEffect(() => {
    if (profile) {
      setProfileName(profile.name);
      setSelectedPermissions(profile.permissions.map((p) => p.id));
    }
  }, [profile]);
  const handlePermissionChange = (permissionId, checked) => {
    setSelectedPermissions(
      (prev) => checked ? [...prev, permissionId] : prev.filter((id2) => id2 !== permissionId)
    );
  };
  const handleSelectAll = () => {
    const allPermissionIds = Object.values(groupedPermissions).flat().map((p) => p.id);
    const allSelected = areAllPermissionsSelected();
    if (allSelected) {
      setSelectedPermissions([]);
    } else {
      setSelectedPermissions(allPermissionIds);
    }
  };
  const handleSelectAllForEntity = (entity) => {
    const entityPermissions = groupedPermissions[entity] || [];
    const entityPermissionIds = entityPermissions.map((p) => p.id);
    const allEntitySelected = areAllEntityPermissionsSelected(entity);
    setSelectedPermissions((prev) => {
      if (allEntitySelected) {
        return prev.filter((id2) => !entityPermissionIds.includes(id2));
      } else {
        const newSet = new Set(prev);
        entityPermissionIds.forEach((id2) => newSet.add(id2));
        return Array.from(newSet);
      }
    });
  };
  const areAllPermissionsSelected = () => {
    const allPermissionIds = Object.values(groupedPermissions).flat().map((p) => p.id);
    return allPermissionIds.length > 0 && allPermissionIds.every((id2) => selectedPermissions.includes(id2));
  };
  const areAllEntityPermissionsSelected = (entity) => {
    const entityPermissions = groupedPermissions[entity] || [];
    return entityPermissions.length > 0 && entityPermissions.every((p) => selectedPermissions.includes(p.id));
  };
  const handleSave = async () => {
    const saveData = { name: profileName, permissions: selectedPermissions };
    const saved = await saveItem(saveData);
    if (saved) {
      navigate("/configuracion/profiles");
    }
  };
  if (loadingProfile || loadingPermissions) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos..." }, void 0, false, {
    fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
    lineNumber: 118,
    columnNumber: 52
  }, this);
  if (errorProfile) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: errorProfile }, void 0, false, {
    fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
    lineNumber: 119,
    columnNumber: 28
  }, this);
  return (
    // Ya no usamos GenericFormPage, construimos el formulario directamente aquí
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: "Editar Perfil" }, void 0, false, {
          fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
          lineNumber: 125,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "profileName", className: "block text-sm font-medium text-gray-700", children: "Nombre del Perfil" }, void 0, false, {
            fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
            lineNumber: 127,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "profileName",
              value: profileName,
              onChange: (e) => setProfileName(e.target.value),
              className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
              lineNumber: 130,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
          lineNumber: 126,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
        lineNumber: 124,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-900", children: "Permisos" }, void 0, false, {
            fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
            lineNumber: 141,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleSelectAll,
              className: "px-3 py-1.5 text-sm font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded-md hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-indigo-500",
              children: areAllPermissionsSelected() ? "Deseleccionar Todos" : "Seleccionar Todos"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
              lineNumber: 142,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
          lineNumber: 140,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: Object.entries(groupedPermissions).map(
          ([entity, permissions]) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-700", children: [
                getPermissionModuleTitle(entity),
                ":"
              ] }, void 0, true, {
                fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
                lineNumber: 154,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleSelectAllForEntity(entity),
                  className: "px-2 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded hover:bg-indigo-100 focus:outline-none focus:ring-1 focus:ring-indigo-500",
                  children: areAllEntityPermissionsSelected(entity) ? "Desmarcar" : "Marcar Todos"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
                  lineNumber: 155,
                  columnNumber: 33
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
              lineNumber: 153,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-2 mt-2", children: sortPermissionsForDisplay(entity, permissions).map(
              (permission) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: `permission-${permission.id}`,
                    type: "checkbox",
                    value: permission.id,
                    checked: selectedPermissions.includes(permission.id),
                    onChange: (e) => handlePermissionChange(permission.id, e.target.checked),
                    className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
                    autoComplete: "off"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
                    lineNumber: 166,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: `permission-${permission.id}`, className: "ml-2 text-sm text-gray-700", children: getPermissionLabel(permission.name) }, void 0, false, {
                  fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
                  lineNumber: 173,
                  columnNumber: 41
                }, this)
              ] }, permission.id, true, {
                fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
                lineNumber: 165,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
              lineNumber: 163,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("hr", { className: "my-2 border-gray-200" }, void 0, false, {
              fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
              lineNumber: 179,
              columnNumber: 29
            }, this)
          ] }, entity, true, {
            fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
            lineNumber: 152,
            columnNumber: 11
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
          lineNumber: 150,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
        lineNumber: 139,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex justify-end", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate("/configuracion/profiles"),
            className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: "Cancelar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
            lineNumber: 186,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleSave,
            className: "px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
            children: "Guardar Cambios"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
            lineNumber: 193,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
        lineNumber: 185,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/profiles/pages/ProfileEditPage.tsx",
      lineNumber: 123,
      columnNumber: 5
    }, this)
  );
};
_s(ProfileEditPage, "am8sNom91TRbOKlPFQd0RAOW4oE=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ProfileEditPage;
var _c;
$RefreshReg$(_c, "ProfileEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/profiles/pages/ProfileEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/profiles/pages/ProfileEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dxRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsR3JELFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxXQUFXQyxtQkFBbUI7QUFDdkMsU0FBU0MsNEJBQTJEO0FBQ3BFLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0JDLDBCQUEwQkMsaUNBQWlDO0FBRWpGLGFBQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsR0FBRyxJQUFJWCxVQUEwQjtBQUN6QyxRQUFNWSxXQUFXWCxZQUFZO0FBQzdCLFFBQU0sRUFBRVksTUFBTUMsU0FBU0MsU0FBU0MsZ0JBQWdCQyxPQUFPQyxjQUFjQyxTQUFTLElBQUloQixZQUFxQkQsc0JBQXNCUyxFQUFFO0FBQy9ILFFBQU0sQ0FBQ1MsR0FBR0MsaUJBQWlCLElBQUl2QixTQUF1QixFQUFFO0FBQ3hELFFBQU0sQ0FBQ3dCLG9CQUFvQkMscUJBQXFCLElBQUl6QixTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDMEIsb0JBQW9CQyxxQkFBcUIsSUFBSTNCLFNBQTBDLENBQUMsQ0FBQztBQUNoRyxRQUFNLENBQUM0QixxQkFBcUJDLHNCQUFzQixJQUFJN0IsU0FBbUIsRUFBRTtBQUczRSxRQUFNLENBQUM4QixhQUFhQyxjQUFjLElBQUkvQixTQUFTLEVBQUU7QUFFakRDLFlBQVUsTUFBTTtBQUNaSyxtQkFBMkIsRUFDdEIwQixLQUFLLENBQUFDLGdCQUFlO0FBQ2pCVix3QkFBa0JVLFdBQVc7QUFDN0JOLDRCQUFzQnBCLFFBQVEwQixhQUFhLENBQUNDLE1BQU1BLEVBQUVDLEtBQUtDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDM0UsQ0FBQyxFQUNBQyxNQUFNLENBQUFsQixVQUFTbUIsUUFBUW5CLE1BQU0sOEJBQThCQSxLQUFLLENBQUMsRUFDakVvQixRQUFRLE1BQU1kLHNCQUFzQixLQUFLLENBQUM7QUFBQSxFQUNuRCxHQUFHLEVBQUU7QUFFTHhCLFlBQVUsTUFBTTtBQUNaLFFBQUllLFNBQVM7QUFFVGUscUJBQWVmLFFBQVFtQixJQUFJO0FBQzNCTiw2QkFBdUJiLFFBQVFpQixZQUFZTyxJQUFJLENBQUFOLE1BQUtBLEVBQUVyQixFQUFFLENBQUM7QUFBQSxJQUM3RDtBQUFBLEVBQ0osR0FBRyxDQUFDRyxPQUFPLENBQUM7QUFFWixRQUFNeUIseUJBQXlCQSxDQUFDQyxjQUFzQkMsWUFBcUI7QUFDdkVkO0FBQUFBLE1BQXVCLENBQUFlLFNBQ25CRCxVQUFVLENBQUMsR0FBR0MsTUFBTUYsWUFBWSxJQUFJRSxLQUFLQyxPQUFPLENBQUFoQyxRQUFNQSxRQUFPNkIsWUFBWTtBQUFBLElBQzdFO0FBQUEsRUFDSjtBQUdBLFFBQU1JLGtCQUFrQkEsTUFBTTtBQUMxQixVQUFNQyxtQkFBbUJDLE9BQU9DLE9BQU92QixrQkFBa0IsRUFBRXdCLEtBQUssRUFBRVYsSUFBSSxDQUFBTixNQUFLQSxFQUFFckIsRUFBRTtBQUMvRSxVQUFNc0MsY0FBY0MsMEJBQTBCO0FBRTlDLFFBQUlELGFBQWE7QUFFYnRCLDZCQUF1QixFQUFFO0FBQUEsSUFDN0IsT0FBTztBQUVIQSw2QkFBdUJrQixnQkFBZ0I7QUFBQSxJQUMzQztBQUFBLEVBQ0o7QUFHQSxRQUFNTSwyQkFBMkJBLENBQUNDLFdBQW1CO0FBQ2pELFVBQU1DLG9CQUFvQjdCLG1CQUFtQjRCLE1BQU0sS0FBSztBQUN4RCxVQUFNRSxzQkFBc0JELGtCQUFrQmYsSUFBSSxDQUFBTixNQUFLQSxFQUFFckIsRUFBRTtBQUMzRCxVQUFNNEMsb0JBQW9CQyxnQ0FBZ0NKLE1BQU07QUFFaEV6QiwyQkFBdUIsQ0FBQWUsU0FBUTtBQUMzQixVQUFJYSxtQkFBbUI7QUFFbkIsZUFBT2IsS0FBS0MsT0FBTyxDQUFBaEMsUUFBTSxDQUFDMkMsb0JBQW9CRyxTQUFTOUMsR0FBRSxDQUFDO0FBQUEsTUFDOUQsT0FBTztBQUVILGNBQU0rQyxTQUFTLElBQUlDLElBQUlqQixJQUFJO0FBQzNCWSw0QkFBb0JNLFFBQVEsQ0FBQWpELFFBQU0rQyxPQUFPRyxJQUFJbEQsR0FBRSxDQUFDO0FBQ2hELGVBQU9tRCxNQUFNQyxLQUFLTCxNQUFNO0FBQUEsTUFDNUI7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBR0EsUUFBTVIsNEJBQTRCQSxNQUFNO0FBQ3BDLFVBQU1MLG1CQUFtQkMsT0FBT0MsT0FBT3ZCLGtCQUFrQixFQUFFd0IsS0FBSyxFQUFFVixJQUFJLENBQUFOLE1BQUtBLEVBQUVyQixFQUFFO0FBQy9FLFdBQU9rQyxpQkFBaUJtQixTQUFTLEtBQUtuQixpQkFBaUJvQixNQUFNLENBQUF0RCxRQUFNZSxvQkFBb0IrQixTQUFTOUMsR0FBRSxDQUFDO0FBQUEsRUFDdkc7QUFHQSxRQUFNNkMsa0NBQWtDQSxDQUFDSixXQUFtQjtBQUN4RCxVQUFNQyxvQkFBb0I3QixtQkFBbUI0QixNQUFNLEtBQUs7QUFDeEQsV0FBT0Msa0JBQWtCVyxTQUFTLEtBQUtYLGtCQUFrQlksTUFBTSxDQUFBakMsTUFBS04sb0JBQW9CK0IsU0FBU3pCLEVBQUVyQixFQUFFLENBQUM7QUFBQSxFQUMxRztBQUVBLFFBQU11RCxhQUFhLFlBQVk7QUFFM0IsVUFBTUMsV0FBVyxFQUFFbEMsTUFBTUwsYUFBYUcsYUFBYUwsb0JBQW9CO0FBQ3ZFLFVBQU0wQyxRQUFRLE1BQU1qRCxTQUFTZ0QsUUFBZTtBQUM1QyxRQUFJQyxPQUFPO0FBQ1B4RCxlQUFTLHlCQUF5QjtBQUFBLElBQ3RDO0FBQUEsRUFDSjtBQUVBLE1BQUlJLGtCQUFrQk0sbUJBQW9CLFFBQU8sdUJBQUMsU0FBSSxpQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNCO0FBQ3ZFLE1BQUlKLGFBQWMsUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUVyRTtBQUFBO0FBQUEsSUFFSSx1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUNqRSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLGlDQUFDLFdBQU0sU0FBUSxlQUFjLFdBQVUsMkNBQXlDLGlDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsT0FBT1U7QUFBQUEsY0FDUCxVQUFVLENBQUN5QyxNQUFNeEMsZUFBZXdDLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxjQUM5QyxXQUFVO0FBQUEsY0FBc0osY0FBYTtBQUFBO0FBQUEsWUFMakw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3NMO0FBQUEsYUFUMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSx1Q0FBc0Msd0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsVUFDNUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFNBQVMzQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVUTSxvQ0FBMEIsSUFBSSx3QkFBd0I7QUFBQTtBQUFBLFlBTDNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNWSixpQkFBTzBCLFFBQVFoRCxrQkFBa0IsRUFBRWM7QUFBQUEsVUFBSSxDQUFDLENBQUNjLFFBQVFyQixXQUFXLE1BQ3pELHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNkJBQTZCeEI7QUFBQUEseUNBQXlCNkMsTUFBTTtBQUFBLGdCQUFFO0FBQUEsbUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZFO0FBQUEsY0FDN0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTUQseUJBQXlCQyxNQUFNO0FBQUEsa0JBQzlDLFdBQVU7QUFBQSxrQkFFVEksMENBQWdDSixNQUFNLElBQUksY0FBYztBQUFBO0FBQUEsZ0JBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHVFQUNWNUMsb0NBQTBCNEMsUUFBUXJCLFdBQVcsRUFBRU87QUFBQUEsY0FBSSxDQUFBbUMsZUFDaEQsdUJBQUMsU0FBd0IsV0FBVSxxQkFDL0I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxJQUFJLGNBQWNBLFdBQVc5RCxFQUFFO0FBQUEsb0JBQy9CLE1BQUs7QUFBQSxvQkFDTCxPQUFPOEQsV0FBVzlEO0FBQUFBLG9CQUNsQixTQUFTZSxvQkFBb0IrQixTQUFTZ0IsV0FBVzlELEVBQUU7QUFBQSxvQkFDbkQsVUFBVSxDQUFDMEQsTUFBTTlCLHVCQUF1QmtDLFdBQVc5RCxJQUFJMEQsRUFBRUMsT0FBTzdCLE9BQU87QUFBQSxvQkFDdkUsV0FBVTtBQUFBLG9CQUF3RSxjQUFhO0FBQUE7QUFBQSxrQkFObkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU13RztBQUFBLGdCQUN4Ryx1QkFBQyxXQUFNLFNBQVMsY0FBY2dDLFdBQVc5RCxFQUFFLElBQUksV0FBVSw4QkFDcERMLDZCQUFtQm1FLFdBQVd4QyxJQUFJLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFWTXdDLFdBQVc5RCxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsWUFDSCxLQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSwwQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLGVBM0I5QnlDLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxRQUNILEtBL0JMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQ0E7QUFBQSxXQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNeEMsU0FBUyx5QkFBeUI7QUFBQSxZQUNqRCxXQUFVO0FBQUEsWUFBbUg7QUFBQTtBQUFBLFVBSGpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU3NEO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQWdJO0FBQUE7QUFBQSxVQUg5STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0E3RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThFQTtBQUFBO0FBRVI7QUFBRXhELEdBL0tXRCxpQkFBZTtBQUFBLFVBQ1RULFdBQ0VDLGFBQ2lFRSxXQUFXO0FBQUE7QUFBQXVFLEtBSHBGakU7QUFBZSxJQUFBaUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJwcm9maWxlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiZ2V0UGVybWlzc2lvbnMiLCJncm91cEJ5IiwiZ2V0UGVybWlzc2lvbkxhYmVsIiwiZ2V0UGVybWlzc2lvbk1vZHVsZVRpdGxlIiwic29ydFBlcm1pc3Npb25zRm9yRGlzcGxheSIsIlByb2ZpbGVFZGl0UGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJwcm9maWxlIiwibG9hZGluZyIsImxvYWRpbmdQcm9maWxlIiwiZXJyb3IiLCJlcnJvclByb2ZpbGUiLCJzYXZlSXRlbSIsIl8iLCJzZXRBbGxQZXJtaXNzaW9ucyIsImxvYWRpbmdQZXJtaXNzaW9ucyIsInNldExvYWRpbmdQZXJtaXNzaW9ucyIsImdyb3VwZWRQZXJtaXNzaW9ucyIsInNldEdyb3VwZWRQZXJtaXNzaW9ucyIsInNlbGVjdGVkUGVybWlzc2lvbnMiLCJzZXRTZWxlY3RlZFBlcm1pc3Npb25zIiwicHJvZmlsZU5hbWUiLCJzZXRQcm9maWxlTmFtZSIsInRoZW4iLCJwZXJtaXNzaW9ucyIsInAiLCJuYW1lIiwic3BsaXQiLCJjYXRjaCIsImNvbnNvbGUiLCJmaW5hbGx5IiwibWFwIiwiaGFuZGxlUGVybWlzc2lvbkNoYW5nZSIsInBlcm1pc3Npb25JZCIsImNoZWNrZWQiLCJwcmV2IiwiZmlsdGVyIiwiaGFuZGxlU2VsZWN0QWxsIiwiYWxsUGVybWlzc2lvbklkcyIsIk9iamVjdCIsInZhbHVlcyIsImZsYXQiLCJhbGxTZWxlY3RlZCIsImFyZUFsbFBlcm1pc3Npb25zU2VsZWN0ZWQiLCJoYW5kbGVTZWxlY3RBbGxGb3JFbnRpdHkiLCJlbnRpdHkiLCJlbnRpdHlQZXJtaXNzaW9ucyIsImVudGl0eVBlcm1pc3Npb25JZHMiLCJhbGxFbnRpdHlTZWxlY3RlZCIsImFyZUFsbEVudGl0eVBlcm1pc3Npb25zU2VsZWN0ZWQiLCJpbmNsdWRlcyIsIm5ld1NldCIsIlNldCIsImZvckVhY2giLCJhZGQiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJldmVyeSIsImhhbmRsZVNhdmUiLCJzYXZlRGF0YSIsInNhdmVkIiwiZSIsInRhcmdldCIsInZhbHVlIiwiZW50cmllcyIsInBlcm1pc3Npb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9maWxlRWRpdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBwcm9maWxlc01vZHVsZUNvbmZpZywgdHlwZSBQcm9maWxlLCB0eXBlIFBlcm1pc3Npb24gfSBmcm9tICcuLi9wcm9maWxlcy5jb25maWcudHN4JztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgZ2V0UGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IGdyb3VwQnkgfSBmcm9tICcuLi8uLi8uLi91dGlscy9oZWxwZXJzJztcbmltcG9ydCB7IGdldFBlcm1pc3Npb25MYWJlbCwgZ2V0UGVybWlzc2lvbk1vZHVsZVRpdGxlLCBzb3J0UGVybWlzc2lvbnNGb3JEaXNwbGF5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvdHJhbnNsYXRpb25zJztcblxuZXhwb3J0IGNvbnN0IFByb2ZpbGVFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbTogcHJvZmlsZSwgbG9hZGluZzogbG9hZGluZ1Byb2ZpbGUsIGVycm9yOiBlcnJvclByb2ZpbGUsIHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxQcm9maWxlPihwcm9maWxlc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IFtfLCBzZXRBbGxQZXJtaXNzaW9uc10gPSB1c2VTdGF0ZTxQZXJtaXNzaW9uW10+KFtdKTtcbiAgICBjb25zdCBbbG9hZGluZ1Blcm1pc3Npb25zLCBzZXRMb2FkaW5nUGVybWlzc2lvbnNdID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2dyb3VwZWRQZXJtaXNzaW9ucywgc2V0R3JvdXBlZFBlcm1pc3Npb25zXSA9IHVzZVN0YXRlPHsgW2tleTogc3RyaW5nXTogUGVybWlzc2lvbltdIH0+KHt9KTtcbiAgICBjb25zdCBbc2VsZWN0ZWRQZXJtaXNzaW9ucywgc2V0U2VsZWN0ZWRQZXJtaXNzaW9uc10gPSB1c2VTdGF0ZTxudW1iZXJbXT4oW10pO1xuXG4gICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBFc3RhZG8gbG9jYWwgcGFyYSBlbCBub21icmUgZGVsIHBlcmZpbFxuICAgIGNvbnN0IFtwcm9maWxlTmFtZSwgc2V0UHJvZmlsZU5hbWVdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZ2V0UGVybWlzc2lvbnM8UGVybWlzc2lvbj4oKVxuICAgICAgICAgICAgLnRoZW4ocGVybWlzc2lvbnMgPT4ge1xuICAgICAgICAgICAgICAgIHNldEFsbFBlcm1pc3Npb25zKHBlcm1pc3Npb25zKTtcbiAgICAgICAgICAgICAgICBzZXRHcm91cGVkUGVybWlzc2lvbnMoZ3JvdXBCeShwZXJtaXNzaW9ucywgKHApID0+IHAubmFtZS5zcGxpdCgnLicpWzBdKSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKGVycm9yID0+IGNvbnNvbGUuZXJyb3IoXCJFcnJvciBsb2FkaW5nIHBlcm1pc3Npb25zOlwiLCBlcnJvcikpXG4gICAgICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nUGVybWlzc2lvbnMoZmFsc2UpKTtcbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvZmlsZSkge1xuICAgICAgICAgICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBTZXRlYW1vcyBsb3MgZXN0YWRvcyBsb2NhbGVzIGN1YW5kbyBlbCBwZXJmaWwgc2UgY2FyZ2FcbiAgICAgICAgICAgIHNldFByb2ZpbGVOYW1lKHByb2ZpbGUubmFtZSk7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFBlcm1pc3Npb25zKHByb2ZpbGUucGVybWlzc2lvbnMubWFwKHAgPT4gcC5pZCkpO1xuICAgICAgICB9XG4gICAgfSwgW3Byb2ZpbGVdKTtcblxuICAgIGNvbnN0IGhhbmRsZVBlcm1pc3Npb25DaGFuZ2UgPSAocGVybWlzc2lvbklkOiBudW1iZXIsIGNoZWNrZWQ6IGJvb2xlYW4pID0+IHtcbiAgICAgICAgc2V0U2VsZWN0ZWRQZXJtaXNzaW9ucyhwcmV2ID0+XG4gICAgICAgICAgICBjaGVja2VkID8gWy4uLnByZXYsIHBlcm1pc3Npb25JZF0gOiBwcmV2LmZpbHRlcihpZCA9PiBpZCAhPT0gcGVybWlzc2lvbklkKVxuICAgICAgICApO1xuICAgIH07XG5cbiAgICAvLyDinIUgSGFuZGxlciBwYXJhIHNlbGVjY2lvbmFyL2Rlc2VsZWNjaW9uYXIgdG9kb3MgbG9zIHBlcm1pc29zXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBhbGxQZXJtaXNzaW9uSWRzID0gT2JqZWN0LnZhbHVlcyhncm91cGVkUGVybWlzc2lvbnMpLmZsYXQoKS5tYXAocCA9PiBwLmlkKTtcbiAgICAgICAgY29uc3QgYWxsU2VsZWN0ZWQgPSBhcmVBbGxQZXJtaXNzaW9uc1NlbGVjdGVkKCk7XG5cbiAgICAgICAgaWYgKGFsbFNlbGVjdGVkKSB7XG4gICAgICAgICAgICAvLyBTaSB0b2RvcyBlc3TDoW4gc2VsZWNjaW9uYWRvcywgZGVzZWxlY2Npb25hciB0b2Rvc1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRQZXJtaXNzaW9ucyhbXSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBTaSBubyB0b2RvcyBlc3TDoW4gc2VsZWNjaW9uYWRvcywgc2VsZWNjaW9uYXIgdG9kb3NcbiAgICAgICAgICAgIHNldFNlbGVjdGVkUGVybWlzc2lvbnMoYWxsUGVybWlzc2lvbklkcyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8g4pyFIEhhbmRsZXIgcGFyYSBzZWxlY2Npb25hci9kZXNlbGVjY2lvbmFyIHRvZG9zIGxvcyBwZXJtaXNvcyBkZSB1bmEgZW50aWRhZCBlc3BlY8OtZmljYVxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEFsbEZvckVudGl0eSA9IChlbnRpdHk6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBlbnRpdHlQZXJtaXNzaW9ucyA9IGdyb3VwZWRQZXJtaXNzaW9uc1tlbnRpdHldIHx8IFtdO1xuICAgICAgICBjb25zdCBlbnRpdHlQZXJtaXNzaW9uSWRzID0gZW50aXR5UGVybWlzc2lvbnMubWFwKHAgPT4gcC5pZCk7XG4gICAgICAgIGNvbnN0IGFsbEVudGl0eVNlbGVjdGVkID0gYXJlQWxsRW50aXR5UGVybWlzc2lvbnNTZWxlY3RlZChlbnRpdHkpO1xuXG4gICAgICAgIHNldFNlbGVjdGVkUGVybWlzc2lvbnMocHJldiA9PiB7XG4gICAgICAgICAgICBpZiAoYWxsRW50aXR5U2VsZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAvLyBTaSB0b2RvcyBsb3MgZGUgbGEgZW50aWRhZCBlc3TDoW4gc2VsZWNjaW9uYWRvcywgZGVzZWxlY2Npb25hcmxvc1xuICAgICAgICAgICAgICAgIHJldHVybiBwcmV2LmZpbHRlcihpZCA9PiAhZW50aXR5UGVybWlzc2lvbklkcy5pbmNsdWRlcyhpZCkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBTaSBubyB0b2RvcyBlc3TDoW4gc2VsZWNjaW9uYWRvcywgc2VsZWNjaW9uYXIgdG9kb3MgbG9zIGRlIGxhIGVudGlkYWRcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdTZXQgPSBuZXcgU2V0KHByZXYpO1xuICAgICAgICAgICAgICAgIGVudGl0eVBlcm1pc3Npb25JZHMuZm9yRWFjaChpZCA9PiBuZXdTZXQuYWRkKGlkKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20obmV3U2V0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIOKchSBWZXJpZmljYXIgc2kgdG9kb3MgbG9zIHBlcm1pc29zIGVzdMOhbiBzZWxlY2Npb25hZG9zXG4gICAgY29uc3QgYXJlQWxsUGVybWlzc2lvbnNTZWxlY3RlZCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgYWxsUGVybWlzc2lvbklkcyA9IE9iamVjdC52YWx1ZXMoZ3JvdXBlZFBlcm1pc3Npb25zKS5mbGF0KCkubWFwKHAgPT4gcC5pZCk7XG4gICAgICAgIHJldHVybiBhbGxQZXJtaXNzaW9uSWRzLmxlbmd0aCA+IDAgJiYgYWxsUGVybWlzc2lvbklkcy5ldmVyeShpZCA9PiBzZWxlY3RlZFBlcm1pc3Npb25zLmluY2x1ZGVzKGlkKSk7XG4gICAgfTtcblxuICAgIC8vIOKchSBWZXJpZmljYXIgc2kgdG9kb3MgbG9zIHBlcm1pc29zIGRlIHVuYSBlbnRpZGFkIGVzdMOhbiBzZWxlY2Npb25hZG9zXG4gICAgY29uc3QgYXJlQWxsRW50aXR5UGVybWlzc2lvbnNTZWxlY3RlZCA9IChlbnRpdHk6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBlbnRpdHlQZXJtaXNzaW9ucyA9IGdyb3VwZWRQZXJtaXNzaW9uc1tlbnRpdHldIHx8IFtdO1xuICAgICAgICByZXR1cm4gZW50aXR5UGVybWlzc2lvbnMubGVuZ3RoID4gMCAmJiBlbnRpdHlQZXJtaXNzaW9ucy5ldmVyeShwID0+IHNlbGVjdGVkUGVybWlzc2lvbnMuaW5jbHVkZXMocC5pZCkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAvLyBVc2Ftb3MgbG9zIGVzdGFkb3MgbG9jYWxlcyBwYXJhIGNvbnN0cnVpciBlbCBwYXlsb2FkXG4gICAgICAgIGNvbnN0IHNhdmVEYXRhID0geyBuYW1lOiBwcm9maWxlTmFtZSwgcGVybWlzc2lvbnM6IHNlbGVjdGVkUGVybWlzc2lvbnMgfTtcbiAgICAgICAgY29uc3Qgc2F2ZWQgPSBhd2FpdCBzYXZlSXRlbShzYXZlRGF0YSBhcyBhbnkpO1xuICAgICAgICBpZiAoc2F2ZWQpIHtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY29uZmlndXJhY2lvbi9wcm9maWxlcycpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nUHJvZmlsZSB8fCBsb2FkaW5nUGVybWlzc2lvbnMpIHJldHVybiA8ZGl2PkNhcmdhbmRvIGRhdG9zLi4uPC9kaXY+O1xuICAgIGlmIChlcnJvclByb2ZpbGUpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvclByb2ZpbGV9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgLy8gWWEgbm8gdXNhbW9zIEdlbmVyaWNGb3JtUGFnZSwgY29uc3RydWltb3MgZWwgZm9ybXVsYXJpbyBkaXJlY3RhbWVudGUgYXF1w61cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNlwiPlxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkVkaXRhciBQZXJmaWw8L2gxPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInByb2ZpbGVOYW1lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBOb21icmUgZGVsIFBlcmZpbFxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicHJvZmlsZU5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGVOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm9maWxlTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QZXJtaXNvczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2VsZWN0QWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluZGlnby02MDAgYmctaW5kaWdvLTUwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWluZGlnby0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YXJlQWxsUGVybWlzc2lvbnNTZWxlY3RlZCgpID8gJ0Rlc2VsZWNjaW9uYXIgVG9kb3MnIDogJ1NlbGVjY2lvbmFyIFRvZG9zJ31cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKGdyb3VwZWRQZXJtaXNzaW9ucykubWFwKChbZW50aXR5LCBwZXJtaXNzaW9uc10pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtlbnRpdHl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+e2dldFBlcm1pc3Npb25Nb2R1bGVUaXRsZShlbnRpdHkpfTo8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdEFsbEZvckVudGl0eShlbnRpdHkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1pbmRpZ28tNjAwIGJnLWluZGlnby01MCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgcm91bmRlZCBob3ZlcjpiZy1pbmRpZ28tMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FyZUFsbEVudGl0eVBlcm1pc3Npb25zU2VsZWN0ZWQoZW50aXR5KSA/ICdEZXNtYXJjYXInIDogJ01hcmNhciBUb2Rvcyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAteC00IGdhcC15LTIgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c29ydFBlcm1pc3Npb25zRm9yRGlzcGxheShlbnRpdHksIHBlcm1pc3Npb25zKS5tYXAocGVybWlzc2lvbiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cGVybWlzc2lvbi5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BwZXJtaXNzaW9uLSR7cGVybWlzc2lvbi5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGVybWlzc2lvbi5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRQZXJtaXNzaW9ucy5pbmNsdWRlcyhwZXJtaXNzaW9uLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVQZXJtaXNzaW9uQ2hhbmdlKHBlcm1pc3Npb24uaWQsIGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTYwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpyaW5nLWluZGlnby01MDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgcGVybWlzc2lvbi0ke3Blcm1pc3Npb24uaWR9YH0gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldFBlcm1pc3Npb25MYWJlbChwZXJtaXNzaW9uLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm15LTIgYm9yZGVyLWdyYXktMjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvY29uZmlndXJhY2lvbi9wcm9maWxlcycpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBtbC0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBHdWFyZGFyIENhbWJpb3NcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3Byb2ZpbGVzL3BhZ2VzL1Byb2ZpbGVFZGl0UGFnZS50c3gifQ==