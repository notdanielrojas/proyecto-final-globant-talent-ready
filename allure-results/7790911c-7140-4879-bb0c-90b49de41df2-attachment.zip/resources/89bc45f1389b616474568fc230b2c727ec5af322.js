import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/ModalContext.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/context/ModalContext.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { ConfirmationModal } from "/src/components/ui/ConfirmationModal.tsx";
const ModalContext = createContext(void 0);
export const ModalProvider = ({ children }) => {
  _s();
  const [modalOptions, setModalOptions] = useState(null);
  const showConfirmationModal = useCallback((options) => {
    setModalOptions(options);
  }, []);
  const handleConfirm = () => {
    if (modalOptions) {
      modalOptions.onConfirm();
      setModalOptions(null);
    }
  };
  const handleCancel = () => {
    setModalOptions(null);
  };
  return /* @__PURE__ */ jsxDEV(ModalContext.Provider, { value: { showConfirmationModal }, children: [
    children,
    modalOptions && /* @__PURE__ */ jsxDEV(
      ConfirmationModal,
      {
        isOpen: true,
        onConfirm: handleConfirm,
        onCancel: handleCancel,
        title: modalOptions.title,
        message: modalOptions.message
      },
      void 0,
      false,
      {
        fileName: "/app/src/context/ModalContext.tsx",
        lineNumber: 60,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/context/ModalContext.tsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
};
_s(ModalProvider, "Op4PsDJVJG9orptah18vWudBwvM=");
_c = ModalProvider;
export const useModal = () => {
  _s2();
  const context = useContext(ModalContext);
  if (context === void 0) {
    throw new Error("useModal debe ser usado dentro de un ModalProvider");
  }
  return context;
};
_s2(useModal, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "ModalProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/context/ModalContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/context/ModalContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4Q2hCLE9BQU9BLFNBQVNDLGVBQWVDLFlBQVlDLFVBQVVDLG1CQUFtQjtBQUN4RSxTQUFTQyx5QkFBeUI7QUFlbEMsTUFBTUMsZUFBZUwsY0FBNENNLE1BQVM7QUFFbkUsYUFBTUMsZ0JBQXlEQSxDQUFDLEVBQUVDLFNBQVMsTUFBTTtBQUFBQyxLQUFBO0FBQ3BGLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJVCxTQUE4QixJQUFJO0FBRTFFLFFBQU1VLHdCQUF3QlQsWUFBWSxDQUFDVSxZQUEwQjtBQUNqRUYsb0JBQWdCRSxPQUFPO0FBQUEsRUFDM0IsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZ0JBQWdCQSxNQUFNO0FBQ3hCLFFBQUlKLGNBQWM7QUFDZEEsbUJBQWFLLFVBQVU7QUFDdkJKLHNCQUFnQixJQUFJO0FBQUEsSUFDeEI7QUFBQSxFQUNKO0FBRUEsUUFBTUssZUFBZUEsTUFBTTtBQUN2Qkwsb0JBQWdCLElBQUk7QUFBQSxFQUN4QjtBQUVBLFNBQ0ksdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQU8sRUFBRUMsc0JBQXNCLEdBQ2pESjtBQUFBQTtBQUFBQSxJQUNBRSxnQkFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUTtBQUFBLFFBQ1IsV0FBV0k7QUFBQUEsUUFDWCxVQUFVRTtBQUFBQSxRQUNWLE9BQU9OLGFBQWFPO0FBQUFBLFFBQ3BCLFNBQVNQLGFBQWFRO0FBQUFBO0FBQUFBLE1BTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtrQztBQUFBLE9BUjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVSO0FBRUFULEdBbENhRixlQUFzRDtBQUFBWSxLQUF0RFo7QUFtQ04sYUFBTWEsV0FBV0EsTUFBTTtBQUFBQyxNQUFBO0FBQzFCLFFBQU1DLFVBQVVyQixXQUFXSSxZQUFZO0FBQ3ZDLE1BQUlpQixZQUFZaEIsUUFBVztBQUN2QixVQUFNLElBQUlpQixNQUFNLG9EQUFvRDtBQUFBLEVBQ3hFO0FBQ0EsU0FBT0Q7QUFDWDtBQUFFRCxJQU5XRCxVQUFRO0FBQUEsSUFBQUQ7QUFBQUssYUFBQUwsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiQ29uZmlybWF0aW9uTW9kYWwiLCJNb2RhbENvbnRleHQiLCJ1bmRlZmluZWQiLCJNb2RhbFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsIm1vZGFsT3B0aW9ucyIsInNldE1vZGFsT3B0aW9ucyIsInNob3dDb25maXJtYXRpb25Nb2RhbCIsIm9wdGlvbnMiLCJoYW5kbGVDb25maXJtIiwib25Db25maXJtIiwiaGFuZGxlQ2FuY2VsIiwidGl0bGUiLCJtZXNzYWdlIiwiX2MiLCJ1c2VNb2RhbCIsIl9zMiIsImNvbnRleHQiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNb2RhbENvbnRleHQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDb25maXJtYXRpb25Nb2RhbCB9IGZyb20gJy4uL2NvbXBvbmVudHMvdWkvQ29uZmlybWF0aW9uTW9kYWwnO1xuXG5cbi8vIERlZmluZSBsYSBlc3RydWN0dXJhIGRlIGxvcyBkYXRvcyBxdWUgbmVjZXNpdGFyw6EgZWwgbW9kYWxcbmludGVyZmFjZSBNb2RhbE9wdGlvbnMge1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIG9uQ29uZmlybTogKCkgPT4gdm9pZDsgLy8gTGEgZnVuY2nDs24gYSBlamVjdXRhciBzaSBlbCB1c3VhcmlvIGNvbmZpcm1hXG59XG5cbi8vIERlZmluZSBsbyBxdWUgbnVlc3RybyBjb250ZXh0byB2YSBhIGV4cG9uZXJcbmludGVyZmFjZSBNb2RhbENvbnRleHRUeXBlIHtcbiAgICBzaG93Q29uZmlybWF0aW9uTW9kYWw6IChvcHRpb25zOiBNb2RhbE9wdGlvbnMpID0+IHZvaWQ7XG59XG5cbmNvbnN0IE1vZGFsQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8TW9kYWxDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuZXhwb3J0IGNvbnN0IE1vZGFsUHJvdmlkZXI6IFJlYWN0LkZDPHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9PiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgICBjb25zdCBbbW9kYWxPcHRpb25zLCBzZXRNb2RhbE9wdGlvbnNdID0gdXNlU3RhdGU8TW9kYWxPcHRpb25zIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBzaG93Q29uZmlybWF0aW9uTW9kYWwgPSB1c2VDYWxsYmFjaygob3B0aW9uczogTW9kYWxPcHRpb25zKSA9PiB7XG4gICAgICAgIHNldE1vZGFsT3B0aW9ucyhvcHRpb25zKTtcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBoYW5kbGVDb25maXJtID0gKCkgPT4ge1xuICAgICAgICBpZiAobW9kYWxPcHRpb25zKSB7XG4gICAgICAgICAgICBtb2RhbE9wdGlvbnMub25Db25maXJtKCk7XG4gICAgICAgICAgICBzZXRNb2RhbE9wdGlvbnMobnVsbCk7IC8vIENpZXJyYSBlbCBtb2RhbFxuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcbiAgICAgICAgc2V0TW9kYWxPcHRpb25zKG51bGwpOyAvLyBDaWVycmEgZWwgbW9kYWxcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPE1vZGFsQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBzaG93Q29uZmlybWF0aW9uTW9kYWwgfX0+XG4gICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgICAgICB7bW9kYWxPcHRpb25zICYmIChcbiAgICAgICAgICAgICAgICA8Q29uZmlybWF0aW9uTW9kYWxcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm09e2hhbmRsZUNvbmZpcm19XG4gICAgICAgICAgICAgICAgICAgIG9uQ2FuY2VsPXtoYW5kbGVDYW5jZWx9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXttb2RhbE9wdGlvbnMudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U9e21vZGFsT3B0aW9ucy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L01vZGFsQ29udGV4dC5Qcm92aWRlcj5cbiAgICApO1xufTtcblxuLy8gSG9vayBwZXJzb25hbGl6YWRvIHBhcmEgdXNhciBlbCBjb250ZXh0byBmw6FjaWxtZW50ZVxuZXhwb3J0IGNvbnN0IHVzZU1vZGFsID0gKCkgPT4ge1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KE1vZGFsQ29udGV4dCk7XG4gICAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VzZU1vZGFsIGRlYmUgc2VyIHVzYWRvIGRlbnRybyBkZSB1biBNb2RhbFByb3ZpZGVyJyk7XG4gICAgfVxuICAgIHJldHVybiBjb250ZXh0O1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbnRleHQvTW9kYWxDb250ZXh0LnRzeCJ9