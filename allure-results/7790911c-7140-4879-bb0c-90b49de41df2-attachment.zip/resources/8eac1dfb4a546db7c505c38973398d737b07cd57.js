import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cajas/pages/CajasEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cajas/pages/CajasEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { cajasModuleConfig } from "/src/features/cajas/cajas.config.tsx";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
export const CajasEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: caja, loading, error, saveItem } = useCrudItem(cajasModuleConfig, id);
  const [hydratedData, setHydratedData] = useState(null);
  useEffect(() => {
    if (caja) {
      const hydrated = { ...caja };
      if (caja.sign === "E" && caja.client_name) {
        hydrated.name = caja.client_name;
      }
      if (caja.sign === "S" && caja.vendor_name) {
        hydrated.name = caja.vendor_name;
      }
      setHydratedData(hydrated);
    }
  }, [caja]);
  const isReadOnlyFromBank = !!caja?.source_type && caja.source_id != null && caja.source_type.includes("BankMovement");
  const handleSave = async (data) => {
    if (isReadOnlyFromBank) {
      toast.error("No es posible editar movimientos de caja generados automáticamente desde movimientos de banco.");
      return;
    }
    const total = Number(data.amount);
    if (!Number.isFinite(total) || total <= 0) {
      toast.error("El importe debe ser mayor que 0.");
      return;
    }
    const dataToSave = { ...data };
    if (dataToSave.value_type === "H") {
      dataToSave.check_amount = dataToSave.amount;
    } else {
      dataToSave.check_amount = 0;
    }
    if (data.sign === "E" && data.name) {
      dataToSave.client_name = data.name;
    } else if (data.sign === "S" && data.name) {
      dataToSave.vendor_name = data.name;
    }
    delete dataToSave.name;
    delete dataToSave.code;
    const saved = await saveItem(dataToSave);
    if (saved) {
      toast.info(`Movimiento actualizado con éxito!`);
      navigate("/cajas");
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del movimiento..." }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasEditPage.tsx",
    lineNumber: 98,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasEditPage.tsx",
    lineNumber: 99,
    columnNumber: 21
  }, this);
  if (!caja || !hydratedData) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento de caja no encontrado." }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasEditPage.tsx",
    lineNumber: 100,
    columnNumber: 38
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: cajasModuleConfig,
      initialData: hydratedData,
      onSave: handleSave,
      mode: "edit",
      readOnly: isReadOnlyFromBank
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/cajas/pages/CajasEditPage.tsx",
      lineNumber: 103,
      columnNumber: 5
    },
    this
  );
};
_s(CajasEditPage, "AnA+4CNQ+1YnK4OL49RwAKdUaFA=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = CajasEditPage;
var _c;
$RefreshReg$(_c, "CajasEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cajas/pages/CajasEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cajas/pages/CajasEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEV3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3RXhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx5QkFBb0M7QUFDN0MsU0FBU0MsYUFBYTtBQUVmLGFBQU1DLGdCQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sRUFBRUMsR0FBRyxJQUFJVixVQUEwQjtBQUN6QyxRQUFNVyxXQUFXVixZQUFZO0FBQzdCLFFBQU0sRUFBRVcsTUFBTUMsTUFBTUMsU0FBU0MsT0FBT0MsU0FBUyxJQUFJWCxZQUFrQkMsbUJBQW1CSSxFQUFFO0FBQ3hGLFFBQU0sQ0FBQ08sY0FBY0MsZUFBZSxJQUFJZixTQUFzQixJQUFJO0FBR2xFRCxZQUFVLE1BQU07QUFDWixRQUFJVyxNQUFNO0FBQ04sWUFBTU0sV0FBaUIsRUFBRSxHQUFHTixLQUFLO0FBR2pDLFVBQUlBLEtBQUtPLFNBQVMsT0FBT1AsS0FBS1EsYUFBYTtBQUN2Q0YsaUJBQVNHLE9BQU9ULEtBQUtRO0FBQUFBLE1BRXpCO0FBR0EsVUFBSVIsS0FBS08sU0FBUyxPQUFPUCxLQUFLVSxhQUFhO0FBQ3ZDSixpQkFBU0csT0FBT1QsS0FBS1U7QUFBQUEsTUFFekI7QUFFQUwsc0JBQWdCQyxRQUFRO0FBQUEsSUFDNUI7QUFBQSxFQUNKLEdBQUcsQ0FBQ04sSUFBSSxDQUFDO0FBRVQsUUFBTVcscUJBQ0YsQ0FBQyxDQUFDWCxNQUFNWSxlQUNSWixLQUFLYSxhQUFhLFFBQ2xCYixLQUFLWSxZQUFZRSxTQUFTLGNBQWM7QUFFNUMsUUFBTUMsYUFBYSxPQUFPQyxTQUFlO0FBQ3JDLFFBQUlMLG9CQUFvQjtBQUNwQmpCLFlBQU1RLE1BQU0sZ0dBQWdHO0FBQzVHO0FBQUEsSUFDSjtBQUNBLFVBQU1lLFFBQVFDLE9BQU9GLEtBQUtHLE1BQU07QUFDaEMsUUFBSSxDQUFDRCxPQUFPRSxTQUFTSCxLQUFLLEtBQUtBLFNBQVMsR0FBRztBQUN2Q3ZCLFlBQU1RLE1BQU0sa0NBQWtDO0FBQzlDO0FBQUEsSUFDSjtBQUdBLFVBQU1tQixhQUFtQixFQUFFLEdBQUdMLEtBQUs7QUFDbkMsUUFBSUssV0FBV0MsZUFBZSxLQUFLO0FBQy9CRCxpQkFBV0UsZUFBZUYsV0FBV0Y7QUFBQUEsSUFDekMsT0FBTztBQUNIRSxpQkFBV0UsZUFBZTtBQUFBLElBQzlCO0FBRUEsUUFBSVAsS0FBS1QsU0FBUyxPQUFPUyxLQUFLUCxNQUFNO0FBRWhDWSxpQkFBV2IsY0FBY1EsS0FBS1A7QUFBQUEsSUFDbEMsV0FBV08sS0FBS1QsU0FBUyxPQUFPUyxLQUFLUCxNQUFNO0FBRXZDWSxpQkFBV1gsY0FBY00sS0FBS1A7QUFBQUEsSUFDbEM7QUFHQSxXQUFRWSxXQUFtQlo7QUFDM0IsV0FBUVksV0FBbUJHO0FBRTNCLFVBQU1DLFFBQVEsTUFBTXRCLFNBQVNrQixVQUFVO0FBQ3ZDLFFBQUlJLE9BQU87QUFDUC9CLFlBQU1nQyxLQUFLLG1DQUFtQztBQUM5QzVCLGVBQVMsUUFBUTtBQUFBLElBQ3JCO0FBQUEsRUFDSjtBQUVBLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGdEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDekQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsUUFBUSxDQUFDSSxhQUFjLFFBQU8sdUJBQUMsU0FBSSxpREFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNDO0FBRXpFLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFYO0FBQUFBLE1BQ1IsYUFBYVc7QUFBQUEsTUFDYixRQUFRVztBQUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLFVBQVVKO0FBQUFBO0FBQUFBLElBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2lDO0FBR3pDO0FBQUVmLEdBbkZXRCxlQUFhO0FBQUEsVUFDUFIsV0FDRUMsYUFDZ0NJLFdBQVc7QUFBQTtBQUFBbUMsS0FIbkRoQztBQUFhLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkdlbmVyaWNGb3JtUGFnZSIsInVzZUNydWRJdGVtIiwiY2FqYXNNb2R1bGVDb25maWciLCJ0b2FzdCIsIkNhamFzRWRpdFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJpdGVtIiwiY2FqYSIsImxvYWRpbmciLCJlcnJvciIsInNhdmVJdGVtIiwiaHlkcmF0ZWREYXRhIiwic2V0SHlkcmF0ZWREYXRhIiwiaHlkcmF0ZWQiLCJzaWduIiwiY2xpZW50X25hbWUiLCJuYW1lIiwidmVuZG9yX25hbWUiLCJpc1JlYWRPbmx5RnJvbUJhbmsiLCJzb3VyY2VfdHlwZSIsInNvdXJjZV9pZCIsImluY2x1ZGVzIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJ0b3RhbCIsIk51bWJlciIsImFtb3VudCIsImlzRmluaXRlIiwiZGF0YVRvU2F2ZSIsInZhbHVlX3R5cGUiLCJjaGVja19hbW91bnQiLCJjb2RlIiwic2F2ZWQiLCJpbmZvIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2FqYXNFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzRWRpdFBhZ2UudHN4XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgY2FqYXNNb2R1bGVDb25maWcsIHR5cGUgQ2FqYSB9IGZyb20gJy4uL2NhamFzLmNvbmZpZyc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcblxuZXhwb3J0IGNvbnN0IENhamFzRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IGNhamEsIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08Q2FqYT4oY2FqYXNNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCBbaHlkcmF0ZWREYXRhLCBzZXRIeWRyYXRlZERhdGFdID0gdXNlU3RhdGU8Q2FqYSB8IG51bGw+KG51bGwpO1xuXG4gICAgLy8g4pyFIFBvYmxhciBjYW1wb3MgcGxhbm9zIGRlc2RlIG9iamV0b3MgcmVsYWNpb25hbGVzIGN1YW5kbyBzZSBjYXJnYSBlbCBpdGVtXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNhamEpIHtcbiAgICAgICAgICAgIGNvbnN0IGh5ZHJhdGVkOiBDYWphID0geyAuLi5jYWphIH07XG5cbiAgICAgICAgICAgIC8vIFNpIGVsIGJhY2tlbmQgZW52w61hIGNsaWVudF9uYW1lLCBtYXBlYXJsbyBhICduYW1lJyBwYXJhIEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgaWYgKGNhamEuc2lnbiA9PT0gJ0UnICYmIGNhamEuY2xpZW50X25hbWUpIHtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZC5uYW1lID0gY2FqYS5jbGllbnRfbmFtZTtcbiAgICAgICAgICAgICAgICAvLyBjdXN0b21lcl9jb2RlIHlhIHZpZW5lIGRlbCBiYWNrZW5kIGRpcmVjdGFtZW50ZVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBTaSBlbCBiYWNrZW5kIGVudsOtYSB2ZW5kb3JfbmFtZSwgbWFwZWFybG8gYSAnbmFtZScgcGFyYSBHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGlmIChjYWphLnNpZ24gPT09ICdTJyAmJiBjYWphLnZlbmRvcl9uYW1lKSB7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWQubmFtZSA9IGNhamEudmVuZG9yX25hbWU7XG4gICAgICAgICAgICAgICAgLy8gdmVuZG9yX2NvZGUgeWEgdmllbmUgZGVsIGJhY2tlbmQgZGlyZWN0YW1lbnRlXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldEh5ZHJhdGVkRGF0YShoeWRyYXRlZCk7XG4gICAgICAgIH1cbiAgICB9LCBbY2FqYV0pO1xuXG4gICAgY29uc3QgaXNSZWFkT25seUZyb21CYW5rID1cbiAgICAgICAgISFjYWphPy5zb3VyY2VfdHlwZSAmJlxuICAgICAgICBjYWphLnNvdXJjZV9pZCAhPSBudWxsICYmXG4gICAgICAgIGNhamEuc291cmNlX3R5cGUuaW5jbHVkZXMoJ0JhbmtNb3ZlbWVudCcpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBDYWphKSA9PiB7XG4gICAgICAgIGlmIChpc1JlYWRPbmx5RnJvbUJhbmspIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBlcyBwb3NpYmxlIGVkaXRhciBtb3ZpbWllbnRvcyBkZSBjYWphIGdlbmVyYWRvcyBhdXRvbcOhdGljYW1lbnRlIGRlc2RlIG1vdmltaWVudG9zIGRlIGJhbmNvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRvdGFsID0gTnVtYmVyKGRhdGEuYW1vdW50KTtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUodG90YWwpIHx8IHRvdGFsIDw9IDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBpbXBvcnRlIGRlYmUgc2VyIG1heW9yIHF1ZSAwLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g4pyFIE1hcGVhciAnbmFtZScgYSAnY2xpZW50X25hbWUnIG8gJ3ZlbmRvcl9uYW1lJyBzZWfDum4gZWwgc2lnblxuICAgICAgICBjb25zdCBkYXRhVG9TYXZlOiBDYWphID0geyAuLi5kYXRhIH07XG4gICAgICAgIGlmIChkYXRhVG9TYXZlLnZhbHVlX3R5cGUgPT09ICdIJykge1xuICAgICAgICAgICAgZGF0YVRvU2F2ZS5jaGVja19hbW91bnQgPSBkYXRhVG9TYXZlLmFtb3VudDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRhdGFUb1NhdmUuY2hlY2tfYW1vdW50ID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChkYXRhLnNpZ24gPT09ICdFJyAmJiBkYXRhLm5hbWUpIHtcbiAgICAgICAgICAgIC8vIFNpIGVzIEVudHJhZGEgeSBoYXkgdW4gbmFtZSwgbWFwZWFyIGEgY2xpZW50X25hbWVcbiAgICAgICAgICAgIGRhdGFUb1NhdmUuY2xpZW50X25hbWUgPSBkYXRhLm5hbWU7XG4gICAgICAgIH0gZWxzZSBpZiAoZGF0YS5zaWduID09PSAnUycgJiYgZGF0YS5uYW1lKSB7XG4gICAgICAgICAgICAvLyBTaSBlcyBTYWxpZGEgeSBoYXkgdW4gbmFtZSwgbWFwZWFyIGEgdmVuZG9yX25hbWVcbiAgICAgICAgICAgIGRhdGFUb1NhdmUudmVuZG9yX25hbWUgPSBkYXRhLm5hbWU7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBMaW1waWFyIGVsIGNhbXBvIHRlbXBvcmFsICduYW1lJyBhbnRlcyBkZSBlbnZpYXJcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkubmFtZTtcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkuY29kZTtcblxuICAgICAgICBjb25zdCBzYXZlZCA9IGF3YWl0IHNhdmVJdGVtKGRhdGFUb1NhdmUpO1xuICAgICAgICBpZiAoc2F2ZWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oYE1vdmltaWVudG8gYWN0dWFsaXphZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY2FqYXMnKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGF0b3MgZGVsIG1vdmltaWVudG8uLi48L2Rpdj47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghY2FqYSB8fCAhaHlkcmF0ZWREYXRhKSByZXR1cm4gPGRpdj5Nb3ZpbWllbnRvIGRlIGNhamEgbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e2NhamFzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2h5ZHJhdGVkRGF0YX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgICAgIHJlYWRPbmx5PXtpc1JlYWRPbmx5RnJvbUJhbmt9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzRWRpdFBhZ2UudHN4In0=