import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { mercadoLibrePublicacionesConfig } from "/src/features/mercadolibre_publicaciones/mercadolibre_publicaciones.config.tsx";
export const MercadoLibrePublicacionesListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(mercadoLibrePublicacionesConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx",
    lineNumber: 30,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: mercadoLibrePublicacionesConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? ""
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx",
      lineNumber: 33,
      columnNumber: 5
    },
    this
  );
};
_s(MercadoLibrePublicacionesListPage, "OpZ0ArL+5wGVsfZK9Ifi0y1Fv3w=", false, function() {
  return [useCrud];
});
_c = MercadoLibrePublicacionesListPage;
var _c;
$RefreshReg$(_c, "MercadoLibrePublicacionesListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXNCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ0QixTQUFTQSx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyx1Q0FBcUU7QUFFdkUsYUFBTUMsb0NBQW9DQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkQsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQVVDO0FBQUFBLElBQVNDO0FBQUFBLElBQWFDO0FBQUFBLElBQU9DO0FBQUFBLElBQVlDO0FBQUFBLElBQVlDO0FBQUFBLElBQy9EQztBQUFBQSxJQUFlQztBQUFBQSxJQUFrQkM7QUFBQUEsSUFBZ0JDO0FBQUFBLElBQWNDO0FBQUFBLEVBQ25FLElBQUlmLFFBQWlDQywrQkFBK0I7QUFFcEUsTUFBSU0sTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRXZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFOO0FBQUFBLE1BQ1Isb0JBQW9CRztBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFDLFFBQVE7QUFBQTtBQUFBLElBWnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVl3QztBQUdoRDtBQUFFYixHQXhCV0QsbUNBQWlDO0FBQUEsVUFJdENGLE9BQU87QUFBQTtBQUFBaUIsS0FKRmY7QUFBaUMsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkdlbmVyaWNMaXN0UGFnZSIsInVzZUNydWQiLCJtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnIiwiTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2VuZXJpY0xpc3RQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IHVzZUNydWQgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkJztcbmltcG9ydCB7IG1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWcsIHR5cGUgTWVyY2Fkb0xpYnJlUHVibGljYXRpb24gfSBmcm9tICcuLi9tZXJjYWRvbGlicmVfcHVibGljYWNpb25lcy5jb25maWcnO1xuXG5leHBvcnQgY29uc3QgTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0xpc3RQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsIGxvYWRpbmcsIGlzQXBwZW5kaW5nLCBlcnJvciwgZGVsZXRlSXRlbSwgaGFuZGxlU29ydCwgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLCBoYW5kbGVQYWdlQ2hhbmdlLCBoYW5kbGVMb2FkTW9yZSwgaGFuZGxlU2VhcmNoLCBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8TWVyY2Fkb0xpYnJlUHVibGljYXRpb24+KG1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWcpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxNZXJjYWRvTGlicmVQdWJsaWNhdGlvbj5cbiAgICAgICAgICAgIGNvbmZpZz17bWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0NvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgb25EZWxldGU9e2RlbGV0ZUl0ZW19XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21lcmNhZG9saWJyZV9wdWJsaWNhY2lvbmVzL3BhZ2VzL01lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNMaXN0UGFnZS50c3gifQ==