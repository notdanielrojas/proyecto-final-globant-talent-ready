import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/leads/pages/LeadsDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/leads/pages/LeadsDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { leadsModuleConfig } from "/src/features/leads/leads.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { convertLeadToClient } from "/src/services/apiService.ts";
import { useModal } from "/src/context/ModalContext.tsx";
export const LeadsDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { showConfirmationModal } = useModal();
  const { hasModulePermission } = usePermissions();
  const [converting, setConverting] = useState(false);
  const { item: lead, loading, error } = useCrudItem(leadsModuleConfig, id);
  const modulePermission = getRequiredPermission(leadsModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEditLeads = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const handleConvertToClient = useCallback(
    async (leadId) => {
      setConverting(true);
      try {
        const client = await convertLeadToClient(leadId);
        navigate(`/clientes/${client.id}`);
      } catch (e) {
        const axiosLike = e;
        const msg = axiosLike.response?.data?.message;
        toast.error(
          typeof msg === "string" && msg.length > 0 ? msg : "No se pudo convertir el prospecto."
        );
      } finally {
        setConverting(false);
      }
    },
    [navigate]
  );
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsDetailPage.tsx",
    lineNumber: 67,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsDetailPage.tsx",
    lineNumber: 68,
    columnNumber: 21
  }, this);
  if (!lead) return /* @__PURE__ */ jsxDEV("div", { children: "Lead no encontrado." }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsDetailPage.tsx",
    lineNumber: 69,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericDetailPage,
    {
      config: leadsModuleConfig,
      item: lead,
      renderHeaderActions: canEditLeads ? (item) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          disabled: converting,
          onClick: () => showConfirmationModal({
            title: "Convertir prospecto en cliente",
            message: "Se creará un cliente con los datos de este prospecto y el prospecto se eliminará. Esta acción no se puede deshacer. ¿Deseas continuar?",
            onConfirm: () => {
              void handleConvertToClient(Number(item.id));
            }
          }),
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none",
          children: converting ? "Convirtiendo…" : "Convertir para cliente"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/leads/pages/LeadsDetailPage.tsx",
          lineNumber: 78,
          columnNumber: 7
        },
        this
      ) : void 0
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/leads/pages/LeadsDetailPage.tsx",
      lineNumber: 72,
      columnNumber: 5
    },
    this
  );
};
_s(LeadsDetailPage, "ZChPteQQvbbUUa38wohNS/tu1Pk=", false, function() {
  return [useParams, useNavigate, useModal, usePermissions, useCrudItem];
});
_c = LeadsDetailPage;
var _c;
$RefreshReg$(_c, "LeadsDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/leads/pages/LeadsDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/leads/pages/LeadsDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0N3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5Q3hCLFNBQVNBLFVBQVVDLG1CQUFtQjtBQUN0QyxTQUFTQyxhQUFhQyxpQkFBaUI7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBb0M7QUFDN0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxnQkFBZ0I7QUFFbEIsYUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxHQUFHLElBQUliLFVBQTBCO0FBQ3pDLFFBQU1jLFdBQVdmLFlBQVk7QUFDN0IsUUFBTSxFQUFFZ0Isc0JBQXNCLElBQUlMLFNBQVM7QUFDM0MsUUFBTSxFQUFFTSxvQkFBb0IsSUFBSVYsZUFBZTtBQUMvQyxRQUFNLENBQUNXLFlBQVlDLGFBQWEsSUFBSXJCLFNBQVMsS0FBSztBQUVsRCxRQUFNLEVBQUVzQixNQUFNQyxNQUFNQyxTQUFTQyxNQUFNLElBQUluQixZQUFrQkQsbUJBQW1CVyxFQUFFO0FBRTlFLFFBQU1VLG1CQUFtQmhCLHNCQUFzQkwsa0JBQWtCc0IsU0FBUztBQUMxRSxRQUFNQyxhQUFhRixtQkFBbUJmLHdCQUF3QmUsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsZUFBZUQsYUFBYVQsb0JBQW9CUyxZQUFZLE1BQU0sSUFBSTtBQUU1RSxRQUFNRSx3QkFBd0I3QjtBQUFBQSxJQUMxQixPQUFPOEIsV0FBbUI7QUFDdEJWLG9CQUFjLElBQUk7QUFDbEIsVUFBSTtBQUNBLGNBQU1XLFNBQVMsTUFBTXBCLG9CQUFvQm1CLE1BQU07QUFDL0NkLGlCQUFTLGFBQWFlLE9BQU9oQixFQUFFLEVBQUU7QUFBQSxNQUNyQyxTQUFTaUIsR0FBWTtBQUNqQixjQUFNQyxZQUFZRDtBQUNsQixjQUFNRSxNQUFNRCxVQUFVRSxVQUFVQyxNQUFNQztBQUN0Q2xDLGNBQU1xQjtBQUFBQSxVQUNGLE9BQU9VLFFBQVEsWUFBWUEsSUFBSUksU0FBUyxJQUNsQ0osTUFDQTtBQUFBLFFBQ1Y7QUFBQSxNQUNKLFVBQUM7QUFDR2Qsc0JBQWMsS0FBSztBQUFBLE1BQ3ZCO0FBQUEsSUFDSjtBQUFBLElBQ0EsQ0FBQ0osUUFBUTtBQUFBLEVBQ2I7QUFFQSxNQUFJTyxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLG1DQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0I7QUFFMUMsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUWxCO0FBQUFBLE1BQ1IsTUFBTWtCO0FBQUFBLE1BQ04scUJBQ0lNLGVBQ00sQ0FBQ1AsU0FDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsVUFBVUY7QUFBQUEsVUFDVixTQUFTLE1BQ1BGLHNCQUFzQjtBQUFBLFlBQ2xCc0IsT0FBTztBQUFBLFlBQ1BGLFNBQ0k7QUFBQSxZQUNKRyxXQUFXQSxNQUFNO0FBQ2IsbUJBQUtYLHNCQUFzQlksT0FBT3BCLEtBQUtOLEVBQUUsQ0FBQztBQUFBLFlBQzlDO0FBQUEsVUFDSixDQUFDO0FBQUEsVUFFSCxXQUFVO0FBQUEsVUFFVEksdUJBQWEsa0JBQWtCO0FBQUE7QUFBQSxRQWZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnQkEsSUFFSnVCO0FBQUFBO0FBQUFBLElBeEJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXlCSztBQUdiO0FBQUU1QixHQW5FV0QsaUJBQWU7QUFBQSxVQUNUWCxXQUNFRCxhQUNpQlcsVUFDRkosZ0JBR09ILFdBQVc7QUFBQTtBQUFBc0MsS0FQekM5QjtBQUFlLElBQUE4QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidG9hc3QiLCJsZWFkc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiR2VuZXJpY0RldGFpbFBhZ2UiLCJMb2FkaW5nU3Bpbm5lciIsInVzZVBlcm1pc3Npb25zIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJjb252ZXJ0TGVhZFRvQ2xpZW50IiwidXNlTW9kYWwiLCJMZWFkc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJzaG93Q29uZmlybWF0aW9uTW9kYWwiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwiY29udmVydGluZyIsInNldENvbnZlcnRpbmciLCJpdGVtIiwibGVhZCIsImxvYWRpbmciLCJlcnJvciIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdExlYWRzIiwiaGFuZGxlQ29udmVydFRvQ2xpZW50IiwibGVhZElkIiwiY2xpZW50IiwiZSIsImF4aW9zTGlrZSIsIm1zZyIsInJlc3BvbnNlIiwiZGF0YSIsIm1lc3NhZ2UiLCJsZW5ndGgiLCJ0aXRsZSIsIm9uQ29uZmlybSIsIk51bWJlciIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxlYWRzRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGxlYWRzTW9kdWxlQ29uZmlnLCB0eXBlIExlYWQgfSBmcm9tICcuLi9sZWFkcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBHZW5lcmljRGV0YWlsUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNEZXRhaWxQYWdlJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBjb252ZXJ0TGVhZFRvQ2xpZW50IH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyB1c2VNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbnRleHQvTW9kYWxDb250ZXh0JztcblxuZXhwb3J0IGNvbnN0IExlYWRzRGV0YWlsUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgc2hvd0NvbmZpcm1hdGlvbk1vZGFsIH0gPSB1c2VNb2RhbCgpO1xuICAgIGNvbnN0IHsgaGFzTW9kdWxlUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKTtcbiAgICBjb25zdCBbY29udmVydGluZywgc2V0Q29udmVydGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCB7IGl0ZW06IGxlYWQsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxMZWFkPihsZWFkc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihsZWFkc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkVkaXRMZWFkcyA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuXG4gICAgY29uc3QgaGFuZGxlQ29udmVydFRvQ2xpZW50ID0gdXNlQ2FsbGJhY2soXG4gICAgICAgIGFzeW5jIChsZWFkSWQ6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgc2V0Q29udmVydGluZyh0cnVlKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gYXdhaXQgY29udmVydExlYWRUb0NsaWVudChsZWFkSWQpO1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvY2xpZW50ZXMvJHtjbGllbnQuaWR9YCk7XG4gICAgICAgICAgICB9IGNhdGNoIChlOiB1bmtub3duKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYXhpb3NMaWtlID0gZSBhcyB7IHJlc3BvbnNlPzogeyBkYXRhPzogeyBtZXNzYWdlPzogc3RyaW5nIH0gfSB9O1xuICAgICAgICAgICAgICAgIGNvbnN0IG1zZyA9IGF4aW9zTGlrZS5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZTtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihcbiAgICAgICAgICAgICAgICAgICAgdHlwZW9mIG1zZyA9PT0gJ3N0cmluZycgJiYgbXNnLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbXNnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdObyBzZSBwdWRvIGNvbnZlcnRpciBlbCBwcm9zcGVjdG8uJ1xuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldENvbnZlcnRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbbmF2aWdhdGVdXG4gICAgKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWxlYWQpIHJldHVybiA8ZGl2PkxlYWQgbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17bGVhZHNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpdGVtPXtsZWFkfVxuICAgICAgICAgICAgcmVuZGVySGVhZGVyQWN0aW9ucz17XG4gICAgICAgICAgICAgICAgY2FuRWRpdExlYWRzXG4gICAgICAgICAgICAgICAgICAgID8gKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y29udmVydGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dDb25maXJtYXRpb25Nb2RhbCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0NvbnZlcnRpciBwcm9zcGVjdG8gZW4gY2xpZW50ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdTZSBjcmVhcsOhIHVuIGNsaWVudGUgY29uIGxvcyBkYXRvcyBkZSBlc3RlIHByb3NwZWN0byB5IGVsIHByb3NwZWN0byBzZSBlbGltaW5hcsOhLiBFc3RhIGFjY2nDs24gbm8gc2UgcHVlZGUgZGVzaGFjZXIuIMK/RGVzZWFzIGNvbnRpbnVhcj8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm9pZCBoYW5kbGVDb252ZXJ0VG9DbGllbnQoTnVtYmVyKGl0ZW0uaWQpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb252ZXJ0aW5nID8gJ0NvbnZpcnRpZW5kb+KApicgOiAnQ29udmVydGlyIHBhcmEgY2xpZW50ZSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGVhZHMvcGFnZXMvTGVhZHNEZXRhaWxQYWdlLnRzeCJ9