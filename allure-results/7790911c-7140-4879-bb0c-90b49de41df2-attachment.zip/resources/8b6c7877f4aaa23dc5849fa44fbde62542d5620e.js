import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/clientes/pages/ClientesDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/clientes/pages/ClientesDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { EntityDetailPageLayout } from "/src/components/common/EntityDetailPageLayout.tsx";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
const ClienteDetailContent = ({ config, item }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(GenericDetailPage, { config, item, hideHeader: true }, void 0, false, {
      fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
      lineNumber: 33,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2 bg-gray-50 rounded-t-md", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: "Impuestos y Retenciones Asignadas" }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 38,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 37,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: item.relatedTaxes && item.relatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 space-y-2", children: item.relatedTaxes?.map(
        (tax) => /* @__PURE__ */ jsxDEV("li", { className: "text-base text-gray-900", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: tax.name }, void 0, false, {
            fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
            lineNumber: 45,
            columnNumber: 37
          }, this),
          " (",
          tax.rate,
          "%)"
        ] }, tax.id, true, {
          fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
          lineNumber: 44,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 42,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Este cliente no tiene impuestos específicos asignados." }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 50,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 40,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
      lineNumber: 36,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 5
  }, this);
};
_c = ClienteDetailContent;
export const ClienteDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: cliente, loading, error } = useCrudItem(clientesModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
    lineNumber: 63,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
    lineNumber: 64,
    columnNumber: 21
  }, this);
  if (!cliente) return /* @__PURE__ */ jsxDEV("div", { children: "Cliente no encontrado." }, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
    lineNumber: 65,
    columnNumber: 24
  }, this);
  const tabs = [
    { id: "details", name: "Detalles" },
    { id: "movements", name: "Cuenta Corriente" },
    { id: "sales_history", name: "Histórico ventas" }
  ];
  return /* @__PURE__ */ jsxDEV(
    EntityDetailPageLayout,
    {
      config: clientesModuleConfig,
      item: cliente,
      entityType: "client",
      customDetailComponent: /* @__PURE__ */ jsxDEV(ClienteDetailContent, { config: clientesModuleConfig, item: cliente }, void 0, false, {
        fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
        lineNumber: 79,
        columnNumber: 30
      }, this),
      tabs
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/clientes/pages/ClientesDetailPage.tsx",
      lineNumber: 75,
      columnNumber: 5
    },
    this
  );
};
_s(ClienteDetailPage, "ghzHQnGCnt9TkZMmZ1mPHx8koHo=", false, function() {
  return [useParams, useCrudItem];
});
_c2 = ClienteDetailPage;
var _c, _c2;
$RefreshReg$(_c, "ClienteDetailContent");
$RefreshReg$(_c2, "ClienteDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/clientes/pages/ClientesDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/clientes/pages/ClientesDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWlosU0FBU0EsaUJBQWlCO0FBQzFCLFNBQVNDLDRCQUEwQztBQUNuRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsOEJBQThCO0FBQ3ZDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxzQkFBc0I7QUFHL0IsTUFBTUMsdUJBQXlGQSxDQUFDLEVBQUVDLFFBQVFDLEtBQUssTUFBTTtBQUNqSCxTQUNJLHVCQUFDLFNBRUc7QUFBQSwyQkFBQyxxQkFBa0IsUUFBZ0IsTUFBWSxZQUFZLFFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0U7QUFBQSxJQUdoRSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsUUFBRyxXQUFVLHFDQUFvQyxpREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRixLQUR2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNWQSxlQUFLQyxnQkFBZ0JELEtBQUtDLGFBQWFDLFNBQVMsSUFDN0MsdUJBQUMsUUFBRyxXQUFVLDRCQUNURixlQUFLQyxjQUFjRTtBQUFBQSxRQUFJLENBQUFDLFFBQ3BCLHVCQUFDLFFBQWdCLFdBQVUsMkJBQ3ZCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGVBQWVBLGNBQUlDLFFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFBTztBQUFBLFVBQUdELElBQUlFO0FBQUFBLFVBQUs7QUFBQSxhQUR0REYsSUFBSUcsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUNILEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLElBRUEsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QixzRUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRixLQVZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsT0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUVSO0FBRUFDLEtBN0JNVjtBQThCQyxhQUFNVyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLEVBQUVILEdBQUcsSUFBSWYsVUFBMEI7QUFDekMsUUFBTSxFQUFFUSxNQUFNVyxTQUFTQyxTQUFTQyxNQUFNLElBQUluQixZQUFxQkQsc0JBQXNCYyxFQUFFO0FBRXZGLE1BQUlLLFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsUUFBUyxRQUFPLHVCQUFDLFNBQUksc0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQjtBQUVoRCxRQUFNRyxPQUFPO0FBQUEsSUFDVCxFQUFFUCxJQUFJLFdBQVdGLE1BQU0sV0FBVztBQUFBLElBQ2xDLEVBQUVFLElBQUksYUFBYUYsTUFBTSxtQkFBbUI7QUFBQSxJQUM1QyxFQUFFRSxJQUFJLGlCQUFpQkYsTUFBTSxtQkFBbUI7QUFBQSxFQUFDO0FBSXJELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFaO0FBQUFBLE1BQ1IsTUFBTWtCO0FBQUFBLE1BQ04sWUFBVztBQUFBLE1BQ1gsdUJBQXVCLHVCQUFDLHdCQUFxQixRQUFRbEIsc0JBQXNCLE1BQU1rQixXQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDekY7QUFBQTtBQUFBLElBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2U7QUFHdkI7QUFBRUQsR0F4QldELG1CQUFpQjtBQUFBLFVBQ1hqQixXQUMyQkUsV0FBVztBQUFBO0FBQUFxQixNQUY1Q047QUFBaUIsSUFBQUQsSUFBQU87QUFBQUMsYUFBQVIsSUFBQTtBQUFBUSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiY2xpZW50ZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIkVudGl0eURldGFpbFBhZ2VMYXlvdXQiLCJHZW5lcmljRGV0YWlsUGFnZSIsIkxvYWRpbmdTcGlubmVyIiwiQ2xpZW50ZURldGFpbENvbnRlbnQiLCJjb25maWciLCJpdGVtIiwicmVsYXRlZFRheGVzIiwibGVuZ3RoIiwibWFwIiwidGF4IiwibmFtZSIsInJhdGUiLCJpZCIsIl9jIiwiQ2xpZW50ZURldGFpbFBhZ2UiLCJfcyIsImNsaWVudGUiLCJsb2FkaW5nIiwiZXJyb3IiLCJ0YWJzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudGVzRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL2NsaWVudGVzL3BhZ2VzL0NsaWVudGVzRGV0YWlsUGFnZS50c3hcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgY2xpZW50ZXNNb2R1bGVDb25maWcsIHR5cGUgQ2xpZW50ZSB9IGZyb20gJy4uL2NsaWVudGVzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IEVudGl0eURldGFpbFBhZ2VMYXlvdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9FbnRpdHlEZXRhaWxQYWdlTGF5b3V0JztcbmltcG9ydCB7IEdlbmVyaWNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcblxuLy8gV3JhcHBlciBwYXJhIGVsIGNvbnRlbmlkbyBkZWwgZGV0YWxsZVxuY29uc3QgQ2xpZW50ZURldGFpbENvbnRlbnQ6IFJlYWN0LkZDPHsgY29uZmlnOiB0eXBlb2YgY2xpZW50ZXNNb2R1bGVDb25maWc7IGl0ZW06IENsaWVudGUgfT4gPSAoeyBjb25maWcsIGl0ZW0gfSkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICB7LyogMS4gRGV0YWxsZSBHZW7DqXJpY28gKi99XG4gICAgICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXtjb25maWd9IGl0ZW09e2l0ZW19IGhpZGVIZWFkZXI9e3RydWV9IC8+XG5cbiAgICAgICAgICAgIHsvKiAyLiBCbG9xdWUgZGUgSW1wdWVzdG9zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJvcmRlciByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctZ3JheS01MCByb3VuZGVkLXQtbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkltcHVlc3RvcyB5IFJldGVuY2lvbmVzIEFzaWduYWRhczwvaDQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmVsYXRlZFRheGVzICYmIGl0ZW0ucmVsYXRlZFRheGVzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1kaXNjIHBsLTUgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmVsYXRlZFRheGVzPy5tYXAodGF4ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17dGF4LmlkfSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57dGF4Lm5hbWV9PC9zcGFuPiAoe3RheC5yYXRlfSUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+RXN0ZSBjbGllbnRlIG5vIHRpZW5lIGltcHVlc3RvcyBlc3BlY8OtZmljb3MgYXNpZ25hZG9zLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuLy8gUMOhZ2luYSBkZSBEZXRhbGxlXG5leHBvcnQgY29uc3QgQ2xpZW50ZURldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbTogY2xpZW50ZSwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPENsaWVudGU+KGNsaWVudGVzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFjbGllbnRlKSByZXR1cm4gPGRpdj5DbGllbnRlIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgY29uc3QgdGFicyA9IFtcbiAgICAgICAgeyBpZDogJ2RldGFpbHMnLCBuYW1lOiAnRGV0YWxsZXMnIH0sXG4gICAgICAgIHsgaWQ6ICdtb3ZlbWVudHMnLCBuYW1lOiAnQ3VlbnRhIENvcnJpZW50ZScgfSxcbiAgICAgICAgeyBpZDogJ3NhbGVzX2hpc3RvcnknLCBuYW1lOiAnSGlzdMOzcmljbyB2ZW50YXMnIH0sXG4gICAgXTtcblxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEVudGl0eURldGFpbFBhZ2VMYXlvdXRcbiAgICAgICAgICAgIGNvbmZpZz17Y2xpZW50ZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpdGVtPXtjbGllbnRlfVxuICAgICAgICAgICAgZW50aXR5VHlwZT1cImNsaWVudFwiIC8vIEltcG9ydGFudGUgcGFyYSBsYXMgcGVzdGHDsWFzXG4gICAgICAgICAgICBjdXN0b21EZXRhaWxDb21wb25lbnQ9ezxDbGllbnRlRGV0YWlsQ29udGVudCBjb25maWc9e2NsaWVudGVzTW9kdWxlQ29uZmlnfSBpdGVtPXtjbGllbnRlfSAvPn1cbiAgICAgICAgICAgIHRhYnM9e3RhYnN9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jbGllbnRlcy9wYWdlcy9DbGllbnRlc0RldGFpbFBhZ2UudHN4In0=