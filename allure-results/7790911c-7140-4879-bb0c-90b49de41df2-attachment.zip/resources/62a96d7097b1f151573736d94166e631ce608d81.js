import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { comisionesVendedoresConfig } from "/src/features/comisiones_vendedores/comisiones_vendedores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { patch } from "/src/services/apiService.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
function unwrapResource(body) {
  if (body && typeof body === "object" && "data" in body) {
    return body.data;
  }
  return body;
}
export const ComisionesVendedoresEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error } = useCrudItem(comisionesVendedoresConfig, id);
  const [marginFrom, setMarginFrom] = useState("");
  const [marginTo, setMarginTo] = useState("");
  const [commissionRate, setCommissionRate] = useState("");
  const [isActive, setIsActive] = useState(true);
  useEffect(() => {
    if (item) {
      setMarginFrom(String(item.margin_from));
      setMarginTo(item.margin_to == null ? "" : String(item.margin_to));
      setCommissionRate(String(item.commission_rate));
      setIsActive(item.is_active);
    }
  }, [item]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!id) return;
    const margin_from = parseFloat(marginFrom.replace(",", "."));
    if (Number.isNaN(margin_from) || margin_from < 0) {
      toast.error('El margen "desde" debe ser un número mayor o igual a 0.');
      return;
    }
    const marginToTrim = marginTo.trim();
    const margin_to = marginToTrim === "" ? null : Number(marginToTrim.replace(",", "."));
    if (margin_to !== null && (Number.isNaN(margin_to) || margin_to < 0)) {
      toast.error('El margen "hasta" no es un número válido.');
      return;
    }
    if (margin_to !== null && margin_to < margin_from) {
      toast.error('El margen "hasta" debe ser mayor o igual al "desde".');
      return;
    }
    const rate = parseFloat(commissionRate.replace(",", "."));
    if (Number.isNaN(rate) || rate < 0 || rate > 100) {
      toast.error("La tasa de comisión debe ser un número entre 0 y 100.");
      return;
    }
    try {
      const res = await patch(comisionesVendedoresConfig.endpoint, id, {
        margin_from,
        margin_to,
        commission_rate: rate,
        is_active: isActive
      });
      unwrapResource(res);
      toast.info("Tramo actualizado correctamente.");
      navigate(getListReturnPath(comisionesVendedoresConfig.baseRoute));
    } catch (err) {
      let displayMessage = "Error al guardar el tramo.";
      if (err && typeof err === "object" && "response" in err) {
        const api = err.response?.data;
        if (api?.errors) {
          const first = Object.keys(api.errors)[0];
          displayMessage = `Error: ${api.errors[first][0]}`;
        } else if (typeof api?.message === "string" && api.message) {
          displayMessage = `Error: ${api.message}`;
        }
      }
      toast.error(displayMessage);
      console.error(err);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del tramo..." }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
    lineNumber: 111,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
    lineNumber: 112,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Tramo no encontrado." }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
    lineNumber: 113,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-2 text-xl font-semibold text-gray-900", children: [
      "Editar ",
      comisionesVendedoresConfig.moduleName
    ] }, void 0, true, {
      fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
      lineNumber: 117,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mb-6 text-sm text-gray-600", children: "Modificá el rango de rentabilidad, la tasa de comisión y el estado activo." }, void 0, false, {
      fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
      lineNumber: 118,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, autoComplete: "off", className: "max-w-xl space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "margin_from", className: "block text-sm font-medium text-gray-700", children: "Margen rentabilidad desde (%)" }, void 0, false, {
          fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
          lineNumber: 122,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "margin_from",
            type: "text",
            inputMode: "decimal",
            value: marginFrom,
            onChange: (e) => setMarginFrom(e.target.value),
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 125,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
        lineNumber: 121,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "margin_to", className: "block text-sm font-medium text-gray-700", children: [
          "Margen rentabilidad hasta (%) ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-normal text-gray-500", children: "(opcional; vacío = sin tope)" }, void 0, false, {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 135,
            columnNumber: 55
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
          lineNumber: 134,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "margin_to",
            type: "text",
            inputMode: "decimal",
            value: marginTo,
            onChange: (e) => setMarginTo(e.target.value),
            placeholder: "Vacío = sin tope",
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 137,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
        lineNumber: 133,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "commission_rate", className: "block text-sm font-medium text-gray-700", children: "Tasa de comisión (%)" }, void 0, false, {
          fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
          lineNumber: 147,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "commission_rate",
            type: "text",
            inputMode: "decimal",
            value: commissionRate,
            onChange: (e) => setCommissionRate(e.target.value),
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 150,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
        lineNumber: 146,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "is_active", className: "block text-sm font-medium text-gray-700", children: "Activo" }, void 0, false, {
          fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
          lineNumber: 159,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            id: "is_active",
            value: isActive ? "1" : "0",
            onChange: (e) => setIsActive(e.target.value === "1"),
            className: "block w-full px-3 py-2 mt-1 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "1", children: "Sí" }, void 0, false, {
                fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
                lineNumber: 168,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "0", children: "No" }, void 0, false, {
                fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
                lineNumber: 169,
                columnNumber: 25
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 162,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
        lineNumber: 158,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(-1),
            className: "inline-flex justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: "Volver"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 173,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "inline-flex justify-center px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-indigo-600 hover:bg-indigo-700",
            children: "Guardar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
            lineNumber: 180,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
        lineNumber: 172,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
      lineNumber: 120,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
};
_s(ComisionesVendedoresEditPage, "EvB30bdSh9zADf8ysqBHCqE7UdM=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ComisionesVendedoresEditPage;
var _c;
$RefreshReg$(_c, "ComisionesVendedoresEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzRnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0Msa0NBQTZEO0FBQ3RFLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBRWxDLFNBQVNDLGVBQWtCQyxNQUFrQjtBQUN6QyxNQUFJQSxRQUFRLE9BQU9BLFNBQVMsWUFBWSxVQUFXQSxNQUFpQjtBQUNoRSxXQUFRQSxLQUFxQkM7QUFBQUEsRUFDakM7QUFDQSxTQUFPRDtBQUNYO0FBRU8sYUFBTUUsK0JBQStCQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUMsUUFBTSxFQUFFQyxHQUFHLElBQUlkLFVBQTBCO0FBQ3pDLFFBQU1lLFdBQVdkLFlBQVk7QUFDN0IsUUFBTSxFQUFFZSxNQUFNQyxTQUFTQyxNQUFNLElBQUliLFlBQWtDRCw0QkFBNEJVLEVBQUU7QUFFakcsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUlsQixTQUFTLEVBQUU7QUFFL0MsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJcEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3FCLGdCQUFnQkMsaUJBQWlCLElBQUl0QixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUIsVUFBVUMsV0FBVyxJQUFJeEIsU0FBUyxJQUFJO0FBRTdDQyxZQUFVLE1BQU07QUFDWixRQUFJYSxNQUFNO0FBQ05JLG9CQUFjTyxPQUFPWCxLQUFLWSxXQUFXLENBQUM7QUFDdENOLGtCQUFZTixLQUFLYSxhQUFhLE9BQU8sS0FBS0YsT0FBT1gsS0FBS2EsU0FBUyxDQUFDO0FBQ2hFTCx3QkFBa0JHLE9BQU9YLEtBQUtjLGVBQWUsQ0FBQztBQUM5Q0osa0JBQVlWLEtBQUtlLFNBQVM7QUFBQSxJQUM5QjtBQUFBLEVBQ0osR0FBRyxDQUFDZixJQUFJLENBQUM7QUFFVCxRQUFNZ0IsZUFBZSxPQUFPQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNwQixHQUFJO0FBRVQsVUFBTWMsY0FBY08sV0FBV2hCLFdBQVdpQixRQUFRLEtBQUssR0FBRyxDQUFDO0FBQzNELFFBQUlDLE9BQU9DLE1BQU1WLFdBQVcsS0FBS0EsY0FBYyxHQUFHO0FBQzlDckIsWUFBTVcsTUFBTSx5REFBeUQ7QUFDckU7QUFBQSxJQUNKO0FBRUEsVUFBTXFCLGVBQWVsQixTQUFTbUIsS0FBSztBQUNuQyxVQUFNWCxZQUNGVSxpQkFBaUIsS0FBSyxPQUFPRixPQUFPRSxhQUFhSCxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQ3RFLFFBQUlQLGNBQWMsU0FBU1EsT0FBT0MsTUFBTVQsU0FBUyxLQUFLQSxZQUFZLElBQUk7QUFDbEV0QixZQUFNVyxNQUFNLDJDQUEyQztBQUN2RDtBQUFBLElBQ0o7QUFDQSxRQUFJVyxjQUFjLFFBQVFBLFlBQVlELGFBQWE7QUFDL0NyQixZQUFNVyxNQUFNLHNEQUFzRDtBQUNsRTtBQUFBLElBQ0o7QUFFQSxVQUFNdUIsT0FBT04sV0FBV1osZUFBZWEsUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUN4RCxRQUFJQyxPQUFPQyxNQUFNRyxJQUFJLEtBQUtBLE9BQU8sS0FBS0EsT0FBTyxLQUFLO0FBQzlDbEMsWUFBTVcsTUFBTSx1REFBdUQ7QUFDbkU7QUFBQSxJQUNKO0FBRUEsUUFBSTtBQUVBLFlBQU13QixNQUFNLE1BQU1wQyxNQUFXRiwyQkFBMkJ1QyxVQUFVN0IsSUFBSTtBQUFBLFFBQ2xFYztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQyxpQkFBaUJXO0FBQUFBLFFBQ2pCVixXQUFXTjtBQUFBQSxNQUNmLENBQUM7QUFDRGhCLHFCQUFxQ2lDLEdBQUc7QUFDeENuQyxZQUFNcUMsS0FBSyxrQ0FBa0M7QUFDN0M3QixlQUFTUCxrQkFBa0JKLDJCQUEyQnlDLFNBQVMsQ0FBQztBQUFBLElBQ3BFLFNBQVNDLEtBQWM7QUFDbkIsVUFBSUMsaUJBQWlCO0FBQ3JCLFVBQUlELE9BQU8sT0FBT0EsUUFBUSxZQUFZLGNBQWNBLEtBQUs7QUFFckQsY0FBTUUsTUFBT0YsSUFBWUcsVUFBVXRDO0FBQ25DLFlBQUlxQyxLQUFLRSxRQUFRO0FBQ2IsZ0JBQU1DLFFBQVFDLE9BQU9DLEtBQUtMLElBQUlFLE1BQU0sRUFBRSxDQUFDO0FBQ3ZDSCwyQkFBaUIsVUFBVUMsSUFBSUUsT0FBT0MsS0FBSyxFQUFFLENBQUMsQ0FBQztBQUFBLFFBQ25ELFdBQVcsT0FBT0gsS0FBS00sWUFBWSxZQUFZTixJQUFJTSxTQUFTO0FBQ3hEUCwyQkFBaUIsVUFBVUMsSUFBSU0sT0FBTztBQUFBLFFBQzFDO0FBQUEsTUFDSjtBQUNBL0MsWUFBTVcsTUFBTTZCLGNBQWM7QUFDMUJRLGNBQVFyQyxNQUFNNEIsR0FBRztBQUFBLElBQ3JCO0FBQUEsRUFDSjtBQUVBLE1BQUk3QixRQUFTLFFBQU8sdUJBQUMsU0FBSSwyQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWdDO0FBQ3BELE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLG9DQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUI7QUFFM0MsU0FDSSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNENBQTJDO0FBQUE7QUFBQSxNQUFRWiwyQkFBMkJvRDtBQUFBQSxTQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVHO0FBQUEsSUFDdkcsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwwRkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvSDtBQUFBLElBRXBILHVCQUFDLFVBQUssVUFBVXhCLGNBQWMsY0FBYSxPQUFNLFdBQVUsc0JBQ3ZEO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxlQUFjLFdBQVUsMkNBQXlDLDZDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixPQUFPYjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2MsTUFBTWIsY0FBY2EsRUFBRXdCLE9BQU9DLEtBQUs7QUFBQSxZQUM3QyxXQUFVO0FBQUEsWUFBc0osY0FBYTtBQUFBO0FBQUEsVUFOakw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXNMO0FBQUEsV0FWMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxTQUFRLGFBQVksV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLFVBQzVDLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsNENBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsYUFEMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csSUFBRztBQUFBLFlBQ0gsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsT0FBT3JDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDWSxNQUFNWCxZQUFZVyxFQUFFd0IsT0FBT0MsS0FBSztBQUFBLFlBQzNDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUFzSixjQUFhO0FBQUE7QUFBQSxVQVBqTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPc0w7QUFBQSxXQVgxTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFNBQVEsbUJBQWtCLFdBQVUsMkNBQXlDLG9DQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixPQUFPbkM7QUFBQUEsWUFDUCxVQUFVLENBQUNVLE1BQU1ULGtCQUFrQlMsRUFBRXdCLE9BQU9DLEtBQUs7QUFBQSxZQUNqRCxXQUFVO0FBQUEsWUFBc0osY0FBYTtBQUFBO0FBQUEsVUFOakw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXNMO0FBQUEsV0FWMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxTQUFRLGFBQVksV0FBVSwyQ0FBeUMsc0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLElBQUc7QUFBQSxZQUNILE9BQU9qQyxXQUFXLE1BQU07QUFBQSxZQUN4QixVQUFVLENBQUNRLE1BQU1QLFlBQVlPLEVBQUV3QixPQUFPQyxVQUFVLEdBQUc7QUFBQSxZQUNuRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxLQUFJLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLGNBQ3BCLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBO0FBQUE7QUFBQSxVQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNM0MsU0FBUyxFQUFFO0FBQUEsWUFDMUIsV0FBVTtBQUFBLFlBQThJO0FBQUE7QUFBQSxVQUg1SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUFzSjtBQUFBO0FBQUEsVUFGcEs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBbEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtRUE7QUFBQSxPQXZFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0VBO0FBRVI7QUFBRUYsR0EzSldELDhCQUE0QjtBQUFBLFVBQ3RCWixXQUNFQyxhQUNnQkksV0FBVztBQUFBO0FBQUFzRCxLQUhuQy9DO0FBQTRCLElBQUErQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImNvbWlzaW9uZXNWZW5kZWRvcmVzQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJwYXRjaCIsInRvYXN0IiwiZ2V0TGlzdFJldHVyblBhdGgiLCJ1bndyYXBSZXNvdXJjZSIsImJvZHkiLCJkYXRhIiwiQ29taXNpb25lc1ZlbmRlZG9yZXNFZGl0UGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJsb2FkaW5nIiwiZXJyb3IiLCJtYXJnaW5Gcm9tIiwic2V0TWFyZ2luRnJvbSIsIm1hcmdpblRvIiwic2V0TWFyZ2luVG8iLCJjb21taXNzaW9uUmF0ZSIsInNldENvbW1pc3Npb25SYXRlIiwiaXNBY3RpdmUiLCJzZXRJc0FjdGl2ZSIsIlN0cmluZyIsIm1hcmdpbl9mcm9tIiwibWFyZ2luX3RvIiwiY29tbWlzc2lvbl9yYXRlIiwiaXNfYWN0aXZlIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicGFyc2VGbG9hdCIsInJlcGxhY2UiLCJOdW1iZXIiLCJpc05hTiIsIm1hcmdpblRvVHJpbSIsInRyaW0iLCJyYXRlIiwicmVzIiwiZW5kcG9pbnQiLCJpbmZvIiwiYmFzZVJvdXRlIiwiZXJyIiwiZGlzcGxheU1lc3NhZ2UiLCJhcGkiLCJyZXNwb25zZSIsImVycm9ycyIsImZpcnN0IiwiT2JqZWN0Iiwia2V5cyIsIm1lc3NhZ2UiLCJjb25zb2xlIiwibW9kdWxlTmFtZSIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29taXNpb25lc1ZlbmRlZG9yZXNFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNvbWlzaW9uZXNWZW5kZWRvcmVzQ29uZmlnLCB0eXBlIENvbW1pc3Npb25NYXJnaW5UaWVyIH0gZnJvbSAnLi4vY29taXNpb25lc192ZW5kZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHBhdGNoIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5mdW5jdGlvbiB1bndyYXBSZXNvdXJjZTxUPihib2R5OiB1bmtub3duKTogVCB7XG4gICAgaWYgKGJvZHkgJiYgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmICdkYXRhJyBpbiAoYm9keSBhcyBvYmplY3QpKSB7XG4gICAgICAgIHJldHVybiAoYm9keSBhcyB7IGRhdGE6IFQgfSkuZGF0YTtcbiAgICB9XG4gICAgcmV0dXJuIGJvZHkgYXMgVDtcbn1cblxuZXhwb3J0IGNvbnN0IENvbWlzaW9uZXNWZW5kZWRvcmVzRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxDb21taXNzaW9uTWFyZ2luVGllcj4oY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcsIGlkKTtcblxuICAgIGNvbnN0IFttYXJnaW5Gcm9tLCBzZXRNYXJnaW5Gcm9tXSA9IHVzZVN0YXRlKCcnKTtcbiAgICAvKiogVmFjw61vID0gc2luIHRvcGUgKG51bGwpICovXG4gICAgY29uc3QgW21hcmdpblRvLCBzZXRNYXJnaW5Ub10gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2NvbW1pc3Npb25SYXRlLCBzZXRDb21taXNzaW9uUmF0ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2lzQWN0aXZlLCBzZXRJc0FjdGl2ZV0gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpdGVtKSB7XG4gICAgICAgICAgICBzZXRNYXJnaW5Gcm9tKFN0cmluZyhpdGVtLm1hcmdpbl9mcm9tKSk7XG4gICAgICAgICAgICBzZXRNYXJnaW5UbyhpdGVtLm1hcmdpbl90byA9PSBudWxsID8gJycgOiBTdHJpbmcoaXRlbS5tYXJnaW5fdG8pKTtcbiAgICAgICAgICAgIHNldENvbW1pc3Npb25SYXRlKFN0cmluZyhpdGVtLmNvbW1pc3Npb25fcmF0ZSkpO1xuICAgICAgICAgICAgc2V0SXNBY3RpdmUoaXRlbS5pc19hY3RpdmUpO1xuICAgICAgICB9XG4gICAgfSwgW2l0ZW1dKTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBpZiAoIWlkKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgbWFyZ2luX2Zyb20gPSBwYXJzZUZsb2F0KG1hcmdpbkZyb20ucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBpZiAoTnVtYmVyLmlzTmFOKG1hcmdpbl9mcm9tKSB8fCBtYXJnaW5fZnJvbSA8IDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBtYXJnZW4gXCJkZXNkZVwiIGRlYmUgc2VyIHVuIG7Dum1lcm8gbWF5b3IgbyBpZ3VhbCBhIDAuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBtYXJnaW5Ub1RyaW0gPSBtYXJnaW5Uby50cmltKCk7XG4gICAgICAgIGNvbnN0IG1hcmdpbl90byA9XG4gICAgICAgICAgICBtYXJnaW5Ub1RyaW0gPT09ICcnID8gbnVsbCA6IE51bWJlcihtYXJnaW5Ub1RyaW0ucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBpZiAobWFyZ2luX3RvICE9PSBudWxsICYmIChOdW1iZXIuaXNOYU4obWFyZ2luX3RvKSB8fCBtYXJnaW5fdG8gPCAwKSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIG1hcmdlbiBcImhhc3RhXCIgbm8gZXMgdW4gbsO6bWVybyB2w6FsaWRvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtYXJnaW5fdG8gIT09IG51bGwgJiYgbWFyZ2luX3RvIDwgbWFyZ2luX2Zyb20pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBtYXJnZW4gXCJoYXN0YVwiIGRlYmUgc2VyIG1heW9yIG8gaWd1YWwgYWwgXCJkZXNkZVwiLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmF0ZSA9IHBhcnNlRmxvYXQoY29tbWlzc2lvblJhdGUucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBpZiAoTnVtYmVyLmlzTmFOKHJhdGUpIHx8IHJhdGUgPCAwIHx8IHJhdGUgPiAxMDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdMYSB0YXNhIGRlIGNvbWlzacOzbiBkZWJlIHNlciB1biBuw7ptZXJvIGVudHJlIDAgeSAxMDAuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHBhdGNoPGFueT4oY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcuZW5kcG9pbnQsIGlkLCB7XG4gICAgICAgICAgICAgICAgbWFyZ2luX2Zyb20sXG4gICAgICAgICAgICAgICAgbWFyZ2luX3RvLFxuICAgICAgICAgICAgICAgIGNvbW1pc3Npb25fcmF0ZTogcmF0ZSxcbiAgICAgICAgICAgICAgICBpc19hY3RpdmU6IGlzQWN0aXZlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB1bndyYXBSZXNvdXJjZTxDb21taXNzaW9uTWFyZ2luVGllcj4ocmVzKTtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oJ1RyYW1vIGFjdHVhbGl6YWRvIGNvcnJlY3RhbWVudGUuJyk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZy5iYXNlUm91dGUpKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgICAgICBsZXQgZGlzcGxheU1lc3NhZ2UgPSAnRXJyb3IgYWwgZ3VhcmRhciBlbCB0cmFtby4nO1xuICAgICAgICAgICAgaWYgKGVyciAmJiB0eXBlb2YgZXJyID09PSAnb2JqZWN0JyAmJiAncmVzcG9uc2UnIGluIGVycikge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgY29uc3QgYXBpID0gKGVyciBhcyBhbnkpLnJlc3BvbnNlPy5kYXRhO1xuICAgICAgICAgICAgICAgIGlmIChhcGk/LmVycm9ycykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaXJzdCA9IE9iamVjdC5rZXlzKGFwaS5lcnJvcnMpWzBdO1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5TWVzc2FnZSA9IGBFcnJvcjogJHthcGkuZXJyb3JzW2ZpcnN0XVswXX1gO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGFwaT8ubWVzc2FnZSA9PT0gJ3N0cmluZycgJiYgYXBpLm1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheU1lc3NhZ2UgPSBgRXJyb3I6ICR7YXBpLm1lc3NhZ2V9YDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihkaXNwbGF5TWVzc2FnZSk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2PkNhcmdhbmRvIGRhdG9zIGRlbCB0cmFtby4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFpdGVtKSByZXR1cm4gPGRpdj5UcmFtbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNlwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5FZGl0YXIge2NvbWlzaW9uZXNWZW5kZWRvcmVzQ29uZmlnLm1vZHVsZU5hbWV9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTYgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+TW9kaWZpY8OhIGVsIHJhbmdvIGRlIHJlbnRhYmlsaWRhZCwgbGEgdGFzYSBkZSBjb21pc2nDs24geSBlbCBlc3RhZG8gYWN0aXZvLjwvcD5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPVwibWF4LXcteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtYXJnaW5fZnJvbVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTWFyZ2VuIHJlbnRhYmlsaWRhZCBkZXNkZSAoJSlcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1hcmdpbl9mcm9tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcmdpbkZyb219XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1hcmdpbkZyb20oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm1hcmdpbl90b1wiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTWFyZ2VuIHJlbnRhYmlsaWRhZCBoYXN0YSAoJSkgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ub3JtYWwgdGV4dC1ncmF5LTUwMFwiPihvcGNpb25hbDsgdmFjw61vID0gc2luIHRvcGUpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWFyZ2luX3RvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21hcmdpblRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXJnaW5UbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlZhY8OtbyA9IHNpbiB0b3BlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgbXQtMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb21taXNzaW9uX3JhdGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRhc2EgZGUgY29taXNpw7NuICglKVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29tbWlzc2lvbl9yYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25SYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21taXNzaW9uUmF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaXNfYWN0aXZlXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBBY3Rpdm9cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpc19hY3RpdmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lzQWN0aXZlID8gJzEnIDogJzAnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJc0FjdGl2ZShlLnRhcmdldC52YWx1ZSA9PT0gJzEnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgbXQtMSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIxXCI+U8OtPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMFwiPk5vPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKC0xKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGp1c3RpZnktY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgVm9sdmVyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGp1c3RpZnktY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBHdWFyZGFyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY29taXNpb25lc192ZW5kZWRvcmVzL3BhZ2VzL0NvbWlzaW9uZXNWZW5kZWRvcmVzRWRpdFBhZ2UudHN4In0=