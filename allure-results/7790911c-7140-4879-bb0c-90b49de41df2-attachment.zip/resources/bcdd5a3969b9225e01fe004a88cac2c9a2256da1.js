import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/monedas/pages/MonedasCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/monedas/pages/MonedasCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialValues = {
  code: "",
  name: "",
  exchange_rate: 0,
  exchange_rate_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
  // Fecha de hoy por defecto
};
export const MonedasCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(monedasModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.success(`Moneda creada con éxito!`);
      navigate(getListReturnPath(monedasModuleConfig.baseRoute));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: monedasModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/monedas/pages/MonedasCreatePage.tsx",
      lineNumber: 48,
      columnNumber: 5
    },
    this
  );
};
_s(MonedasCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = MonedasCreatePage;
var _c;
$RefreshReg$(_c, "MonedasCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/monedas/pages/MonedasCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/monedas/pages/MonedasCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDJCQUF3QztBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsZ0JBQWlDO0FBQUEsRUFDbkNDLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsZUFBZTtBQUFBLEVBQ2ZDLHFCQUFvQixvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQTtBQUM3RDtBQUVPLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLFdBQVdoQixZQUFZO0FBQzdCLFFBQU0sRUFBRWlCLFNBQVMsSUFBSWQsWUFBb0JELG1CQUFtQjtBQUU1RCxRQUFNZ0IsYUFBYSxPQUFPQyxTQUFpQjtBQUN2QyxVQUFNQyxVQUFVLE1BQU1ILFNBQVNFLElBQUk7QUFDbkMsUUFBSUMsU0FBUztBQUNUaEIsWUFBTWlCLFFBQVEsMEJBQTBCO0FBQ3hDTCxlQUFTWCxrQkFBa0JILG9CQUFvQm9CLFNBQVMsQ0FBQztBQUFBLElBQzdEO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFwQjtBQUFBQSxNQUNSLGFBQWFJO0FBQUFBLE1BQ2IsUUFBUVk7QUFBQUEsTUFDUixNQUFLO0FBQUE7QUFBQSxJQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlpQjtBQUd6QjtBQUFFSCxHQXBCV0QsbUJBQWlCO0FBQUEsVUFDVGQsYUFDSUcsV0FBVztBQUFBO0FBQUFvQixLQUZ2QlQ7QUFBaUIsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwibW9uZWRhc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImluaXRpYWxWYWx1ZXMiLCJjb2RlIiwibmFtZSIsImV4Y2hhbmdlX3JhdGUiLCJleGNoYW5nZV9yYXRlX2RhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsIk1vbmVkYXNDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJuZXdJdGVtIiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vbmVkYXNDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IG1vbmVkYXNNb2R1bGVDb25maWcsIHR5cGUgTW9uZWRhIH0gZnJvbSAnLi4vbW9uZWRhcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG4vLyBWYWxvcmVzIGluaWNpYWxlcyBwYXJhIHVuYSBtb25lZGEgbnVldmFcbmNvbnN0IGluaXRpYWxWYWx1ZXM6IFBhcnRpYWw8TW9uZWRhPiA9IHtcbiAgICBjb2RlOiAnJyxcbiAgICBuYW1lOiAnJyxcbiAgICBleGNoYW5nZV9yYXRlOiAwLFxuICAgIGV4Y2hhbmdlX3JhdGVfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sIC8vIEZlY2hhIGRlIGhveSBwb3IgZGVmZWN0b1xufTtcblxuZXhwb3J0IGNvbnN0IE1vbmVkYXNDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxNb25lZGE+KG1vbmVkYXNNb2R1bGVDb25maWcpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBNb25lZGEpID0+IHtcbiAgICAgICAgY29uc3QgbmV3SXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAobmV3SXRlbSkge1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgTW9uZWRhIGNyZWFkYSBjb24gw6l4aXRvIWApO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobW9uZWRhc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e21vbmVkYXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFZhbHVlcyBhcyBNb25lZGF9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21vbmVkYXMvcGFnZXMvTW9uZWRhc0NyZWF0ZVBhZ2UudHN4In0=