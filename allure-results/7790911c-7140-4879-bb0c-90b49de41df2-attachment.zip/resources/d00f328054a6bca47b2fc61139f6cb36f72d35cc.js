import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/MainLayout.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "https://back-imcoarca.leonardojose.dev/api", "VITE_NAV_LAYOUT": "sidebar"};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/MainLayout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { TopNavbar } from "/src/components/layouts/TopNavbar.tsx";
import { Sidebar } from "/src/components/layouts/Sidebar.tsx";
import { Header } from "/src/components/layouts/Header.tsx";
const useSidebar = import.meta.env.VITE_NAV_LAYOUT === "sidebar";
export const MainLayout = () => {
  if (useSidebar) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex w-full h-screen bg-gray-50", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "/app/src/components/layouts/MainLayout.tsx",
        lineNumber: 31,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
        /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
          fileName: "/app/src/components/layouts/MainLayout.tsx",
          lineNumber: 33,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("main", { className: "flex-1 p-6 overflow-y-auto", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
          fileName: "/app/src/components/layouts/MainLayout.tsx",
          lineNumber: 35,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/components/layouts/MainLayout.tsx",
          lineNumber: 34,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/layouts/MainLayout.tsx",
        lineNumber: 32,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/layouts/MainLayout.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col w-full min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(TopNavbar, {}, void 0, false, {
      fileName: "/app/src/components/layouts/MainLayout.tsx",
      lineNumber: 44,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-1 p-6 overflow-y-auto", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "/app/src/components/layouts/MainLayout.tsx",
      lineNumber: 46,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/components/layouts/MainLayout.tsx",
      lineNumber: 45,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/layouts/MainLayout.tsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
};
_c = MainLayout;
var _c;
$RefreshReg$(_c, "MainLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/MainLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/MainLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV2dCOzs7Ozs7Ozs7Ozs7Ozs7O0FBWGhCLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUV2QixNQUFNQyxhQUFhQyxZQUFZQyxJQUFJQyxvQkFBb0I7QUFFaEQsYUFBTUMsYUFBYUEsTUFBTTtBQUM1QixNQUFJSixZQUFZO0FBQ1osV0FDSSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1g7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1IsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsK0JBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU87QUFBQSxRQUNQLHVCQUFDLFVBQUssV0FBVSw4QkFDWixpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxLQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxFQUVSO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ1g7QUFBQSwyQkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVTtBQUFBLElBQ1YsdUJBQUMsVUFBSyxXQUFVLDhCQUNaLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFUjtBQUFFSyxLQXZCV0Q7QUFBVSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiT3V0bGV0IiwiVG9wTmF2YmFyIiwiU2lkZWJhciIsIkhlYWRlciIsInVzZVNpZGViYXIiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX05BVl9MQVlPVVQiLCJNYWluTGF5b3V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWFpbkxheW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBUb3BOYXZiYXIgfSBmcm9tICcuL1RvcE5hdmJhcic7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnLi9TaWRlYmFyJztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4vSGVhZGVyJztcblxuY29uc3QgdXNlU2lkZWJhciA9IGltcG9ydC5tZXRhLmVudi5WSVRFX05BVl9MQVlPVVQgPT09ICdzaWRlYmFyJztcblxuZXhwb3J0IGNvbnN0IE1haW5MYXlvdXQgPSAoKSA9PiB7XG4gICAgaWYgKHVzZVNpZGViYXIpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaC1zY3JlZW4gYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgIDxTaWRlYmFyIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8SGVhZGVyIC8+XG4gICAgICAgICAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBwLTYgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8T3V0bGV0IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbWFpbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCB3LWZ1bGwgbWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgIDxUb3BOYXZiYXIgLz5cbiAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBwLTYgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPE91dGxldCAvPlxuICAgICAgICAgICAgPC9tYWluPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9sYXlvdXRzL01haW5MYXlvdXQudHN4In0=