import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/proveedores/pages/ProveedoresListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/proveedores/pages/ProveedoresListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
export const ProveedoresListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(proveedoresModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresListPage.tsx",
    lineNumber: 40,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: proveedoresModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? ""
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/proveedores/pages/ProveedoresListPage.tsx",
      lineNumber: 43,
      columnNumber: 5
    },
    this
  );
};
_s(ProveedoresListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = ProveedoresListPage;
var _c;
$RefreshReg$(_c, "ProveedoresListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/proveedores/pages/ProveedoresListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/proveedores/pages/ProveedoresListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQztBQUVqRCxhQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZixRQUFtQkMsdUJBQXVCO0FBRTlDLE1BQUlNLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRTjtBQUFBQSxNQUNSLG9CQUFvQkc7QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhQyxRQUFRO0FBQUE7QUFBQSxJQVpyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZd0M7QUFHaEQ7QUFBRWIsR0FsQ1dELHFCQUFtQjtBQUFBLFVBY3hCRixPQUFPO0FBQUE7QUFBQWlCLEtBZEZmO0FBQW1CLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwicHJvdmVlZG9yZXNNb2R1bGVDb25maWciLCJQcm92ZWVkb3Jlc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb3ZlZWRvcmVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBQcm92ZWVkb3IgfSBmcm9tICcuLi9wcm92ZWVkb3Jlcy5jb25maWcudHN4JztcblxuZXhwb3J0IGNvbnN0IFByb3ZlZWRvcmVzTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxQcm92ZWVkb3I+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnKTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8UHJvdmVlZG9yPlxuICAgICAgICAgICAgY29uZmlnPXtwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgb25EZWxldGU9e2RlbGV0ZUl0ZW19XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3Byb3ZlZWRvcmVzL3BhZ2VzL1Byb3ZlZWRvcmVzTGlzdFBhZ2UudHN4In0=