import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ToggleSwitch.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/ToggleSwitch.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export const ToggleSwitch = ({ enabled, onChange, srLabel = "Toggle" }) => {
  const handleClick = () => {
    onChange(!enabled);
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      role: "switch",
      "aria-checked": enabled,
      onClick: handleClick,
      className: `relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${enabled ? "bg-indigo-600" : "bg-gray-200"}`,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: srLabel }, void 0, false, {
          fileName: "/app/src/components/ui/ToggleSwitch.tsx",
          lineNumber: 45,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            "aria-hidden": "true",
            className: `inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${enabled ? "translate-x-5" : "translate-x-0"}`
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/ui/ToggleSwitch.tsx",
            lineNumber: 48,
            columnNumber: 13
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/ui/ToggleSwitch.tsx",
      lineNumber: 36,
      columnNumber: 5
    },
    this
  );
};
_c = ToggleSwitch;
var _c;
$RefreshReg$(_c, "ToggleSwitch");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/ToggleSwitch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/ToggleSwitch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJZOzs7Ozs7Ozs7Ozs7Ozs7O0FBeEJaLE9BQU9BLFdBQVc7QUFTWCxhQUFNQyxlQUE0Q0EsQ0FBQyxFQUFFQyxTQUFTQyxVQUFVQyxVQUFVLFNBQVMsTUFBTTtBQUNwRyxRQUFNQyxjQUFjQSxNQUFNO0FBQ3RCRixhQUFTLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLE1BQUs7QUFBQSxNQUNMLE1BQUs7QUFBQSxNQUNMLGdCQUFjQTtBQUFBQSxNQUNkLFNBQVNHO0FBQUFBLE1BQ1QsV0FBVyw0TkFBNE5ILFVBQVUsa0JBQWtCLGFBQWE7QUFBQSxNQUloUjtBQUFBLCtCQUFDLFVBQUssV0FBVSxXQUFXRSxxQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBR25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxlQUFZO0FBQUEsWUFDWixXQUFXLDBHQUEwR0YsVUFBVSxrQkFBa0IsZUFBZTtBQUFBO0FBQUEsVUFGcEs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR1c7QUFBQTtBQUFBO0FBQUEsSUFmZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQkE7QUFFUjtBQUFFSSxLQXpCV0w7QUFBeUMsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiVG9nZ2xlU3dpdGNoIiwiZW5hYmxlZCIsIm9uQ2hhbmdlIiwic3JMYWJlbCIsImhhbmRsZUNsaWNrIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9nZ2xlU3dpdGNoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy91aS9Ub2dnbGVTd2l0Y2gudHN4XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgVG9nZ2xlU3dpdGNoUHJvcHMge1xuICAgIGVuYWJsZWQ6IGJvb2xlYW47XG4gICAgb25DaGFuZ2U6IChlbmFibGVkOiBib29sZWFuKSA9PiB2b2lkO1xuICAgIC8vIE9wY2lvbmFsOiBwYXJhIGxlY3RvcmVzIGRlIHBhbnRhbGxhXG4gICAgc3JMYWJlbD86IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IFRvZ2dsZVN3aXRjaDogUmVhY3QuRkM8VG9nZ2xlU3dpdGNoUHJvcHM+ID0gKHsgZW5hYmxlZCwgb25DaGFuZ2UsIHNyTGFiZWwgPSBcIlRvZ2dsZVwiIH0pID0+IHtcbiAgICBjb25zdCBoYW5kbGVDbGljayA9ICgpID0+IHtcbiAgICAgICAgb25DaGFuZ2UoIWVuYWJsZWQpO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHJvbGU9XCJzd2l0Y2hcIlxuICAgICAgICAgICAgYXJpYS1jaGVja2VkPXtlbmFibGVkfVxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBpbmxpbmUtZmxleCBoLTYgdy0xMSBmbGV4LXNocmluay0wIGN1cnNvci1wb2ludGVyIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIGVhc2UtaW4tb3V0IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgJHtlbmFibGVkID8gJ2JnLWluZGlnby02MDAnIDogJ2JnLWdyYXktMjAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAgICB7LyogRXRpcXVldGEgcGFyYSBsZWN0b3IgZGUgcGFudGFsbGEgKi99XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+e3NyTGFiZWx9PC9zcGFuPlxuXG4gICAgICAgICAgICB7LyogRWwgXCJib3TDs25cIiBkZXNsaXphbnRlICovfVxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBoLTUgdy01IHRyYW5zZm9ybSByb3VuZGVkLWZ1bGwgYmctd2hpdGUgc2hhZG93IHJpbmctMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBlYXNlLWluLW91dCAke2VuYWJsZWQgPyAndHJhbnNsYXRlLXgtNScgOiAndHJhbnNsYXRlLXgtMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvdWkvVG9nZ2xlU3dpdGNoLnRzeCJ9