import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { getAll } from "/src/services/apiService.ts";
import { createValueMapperRenderer } from "/src/utils/renders.tsx";
import {} from "/src/types/appliedTaxes.ts";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { getAllowedInvoiceSeries, resolveInvoiceSeriesForTaxChange } from "/src/utils/invoiceSeries.ts";
const loadDistricts = async () => {
  const response = await getAll("districts");
  return response.data.map((district) => ({
    value: district.id,
    label: district.name
  }));
};
const loadZones = async () => {
  const response = await getAll("zones");
  return response.data.map((z) => ({
    value: z.id,
    label: `${z.code} – ${z.name}`
  }));
};
const taxConditionOptions = [
  { value: "I", label: "IVA Responsable Inscripto" },
  { value: "M", label: "Monotributista" },
  { value: "E", label: "Exento" },
  { value: "C", label: "Consumidor Final" },
  { value: "N", label: "No Responsable" }
];
const renderTaxCondition = createValueMapperRenderer(
  taxConditionOptions,
  "tax"
);
export const clientesModuleConfig = {
  endpoint: "clients",
  moduleName: "Cliente",
  moduleNamePlural: "Clientes",
  baseRoute: "/clientes",
  // Sección para la vista de detalle
  detail: {
    displayNameKey: "name"
  },
  // Reemplaza la propiedad 'list' en tu archivo de configuración con esta versión completa:
  list: {
    columns: [
      // --- Grupo: Datos Principales ---
      { header: "Código Cliente", accessor: "customer_code" },
      { header: "Nombre o Razón Social", accessor: "name" },
      { header: "CUIT", accessor: "cuit" },
      { header: "Teléfono", accessor: "phone", render: (item) => item.phone || "-" },
      { header: "Email", accessor: "email", render: (item) => item.email || "-" },
      { header: "Persona de Contacto", accessor: "contact", render: (item) => item.contact || "-" },
      { header: "Rubro", accessor: "rubro", render: (item) => item.rubro || "-" },
      { header: "Zona", accessor: "zone_name", render: (item) => item.zone_name || "-" },
      {
        header: "Ley Exportación TDF",
        accessor: "ley_exportacion_tdf",
        render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.ley_exportacion_tdf ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`, children: item.ley_exportacion_tdf ? "Sí" : "No" }, void 0, false, {
          fileName: "/app/src/features/clientes/clientes.config.tsx",
          lineNumber: 160,
          columnNumber: 7
        }, this)
      }
      /*
      { header: 'Vendedor Asignado', accessor: 'salesrep_name', render: (item) => item.salesrep_name || '-' },
      { header: 'Comprador', accessor: 'buyer_name', render: (item) => item.buyer_name || '-' },
      { header: 'Transporte', accessor: 'transport_name', render: (item) => item.transport_name || '-' },
      { header: 'Observaciones', accessor: 'observations', render: (item) => item.observations || '-' },
       // --- Grupo: Domicilios ---
      { header: 'Domicilio Fiscal', accessor: 'address', render: (item) => item.address || '-' },
      { header: 'Código Postal', accessor: 'zip', render: (item) => item.zip || '-' },
      { header: 'Localidad', accessor: 'city', render: (item) => item.city || '-' },
      { header: 'Provincia', accessor: 'district', render: (item) => item.district_name?.toString() || '-' },
      { header: 'Zona', accessor: 'zone_name', render: (item) => item.zone_name || '-' },
       // --- Grupo: Datos Impositivos y de Crédito ---
      { header: 'Condición IVA', accessor: 'tax', render: renderTaxCondition },
      { header: 'Días de Pago', accessor: 'payday', render: (item) => item.payday?.toString() || '-' },
      { header: 'Límite de Crédito', accessor: 'credit', render: (item) => item.credit?.toString() || '-' },
      { header: 'Exención', accessor: 'freetax', render: (item) => item.freetax?.toString() || '-' },
      { header: 'Serie de Factura', accessor: 'serie', render: (item) => item.serie || '-' },
      {
          header: 'Retiene IVA',
          accessor: 'retieniva',
          render: (item) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.retieniva ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {item.retieniva ? 'Sí' : 'No'}
              </span>
          ),
      },
      {
          header: 'Adherido a FCE',
          accessor: 'fce',
          render: (item) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.fce ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {item.fce ? 'Sí' : 'No'}
              </span>
          ),
      },
       // --- Grupo: Datos de Cobranza ---
      { header: 'Domicilio de Cobranza', accessor: 'paymentaddress', render: (item) => item.paymentaddress || '-' },
      { header: 'Localidad de Cobranza', accessor: 'paymentcity', render: (item) => item.paymentcity || '-' },
      { header: 'CP de Cobranza', accessor: 'paymentzip', render: (item) => item.paymentzip || '-' },
      { header: 'Contacto de Cobranza', accessor: 'paymentcontact', render: (item) => item.paymentcontact || '-' },
      { header: 'Teléfono de Cobranza', accessor: 'paymentphone', render: (item) => item.paymentphone || '-' },
      { header: 'Días de Cobranza', accessor: 'paymentdays', render: (item) => item.paymentdays || '-' },
      { header: 'Horario de Cobranza', accessor: 'paymenthour', render: (item) => item.paymenthour || '-' },
      { header: 'Obs. de Cobranza', accessor: 'paymentobs', render: (item) => item.paymentobs || '-' },
       // --- Grupo: Configuraciones Avanzadas (Banderas) ---
      {
          header: 'Cliente Congelado',
          accessor: 'congelcli',
          render: (item) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.congelcli ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'}`}>
                  {item.congelcli ? 'Sí' : 'No'}
              </span>
          ),
      },
      {
          header: 'Es Prospecto',
          accessor: 'prospect',
          render: (item) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.prospect ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                  {item.prospect ? 'Sí' : 'No'}
              </span>
          ),
      },
      {
          header: 'Pedir Constancia de IVA',
          accessor: 'pediriva',
          render: (item) => (
              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.pediriva ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {item.pediriva ? 'Sí' : 'No'}
              </span>
          ),
      },
      */
    ]
  },
  // NUEVA SECCIÓN: Definición de los campos para el formulario
  form: {
    // Reemplaza el contenido de 'fields' en tu archivo clientes.config.tsx con esto:
    block: [
      {
        name: "Datos básicos",
        fields: [
          // --- Grupo: Datos Principales ---
          { name: "customer_code", label: "Código Cliente", type: "text", detailOnly: true },
          { name: "cuit", label: "CUIT", type: "text", placeholder: "Ej: 30-12345678-9", mandatory: true, mask: "cuit" },
          {
            name: "tax",
            label: "Condición Tributaria",
            type: "select",
            options: taxConditionOptions,
            render: renderTaxCondition,
            onChangeEffect: (newValue, currentData, updateFormData) => {
              updateFormData({
                serie: resolveInvoiceSeriesForTaxChange(String(newValue), currentData.serie)
              });
            }
          },
          { name: "name", label: "Nombre o Razón Social", type: "text", placeholder: "Ej: Empresa S.A.", mandatory: true },
          {
            name: "retieniva",
            label: "Retiene IVA",
            type: "select",
            options: [
              // Opciones de ejemplo
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            valueType: "boolean",
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.retieniva ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.retieniva ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 275,
              columnNumber: 9
            }, this)
          },
          {
            name: "ley_exportacion_tdf",
            label: "Aplica Ley de Exportación TDF",
            type: "select",
            options: [
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            valueType: "boolean",
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.ley_exportacion_tdf ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`, children: item.ley_exportacion_tdf ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 290,
              columnNumber: 9
            }, this)
          },
          {
            name: "serie",
            label: "Serie de Factura",
            type: "select",
            getOptions: (fd) => getAllowedInvoiceSeries(fd.tax).map((s) => ({ value: s, label: s })),
            readonly: (fd) => getAllowedInvoiceSeries(fd.tax).length <= 1,
            render: (item) => item.serie || "-"
          },
          { name: "startdate", label: "Fecha de alta", type: "date", format: "date" },
          {
            name: "currency_id",
            label: "Moneda",
            type: "relational",
            relationalConfig: { moduleConfig: monedasModuleConfig, codeField: "currency_code", nameField: "currency_name" },
            render: (item) => item.currency_name || "-"
          }
        ]
      },
      {
        name: "Datos de Contacto",
        fields: [
          { name: "address", label: "Domicilio Fiscal", type: "text" },
          { name: "zip", label: "Código Postal", type: "text" },
          { name: "city", label: "Localidad", type: "text" },
          {
            name: "district",
            label: "Provincia",
            type: "select",
            loadOptions: loadDistricts,
            render: (item) => item.district_name?.toString() || "-"
          },
          {
            name: "phone",
            label: "Teléfono",
            type: "text",
            placeholder: "Ej: 11-4444-5555",
            render: (item) => {
              if (!item.phone) return "-";
              const cleanPhone = item.phone.replace(/[^0-9]/g, "");
              return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { children: item.phone }, void 0, false, {
                  fileName: "/app/src/features/clientes/clientes.config.tsx",
                  lineNumber: 338,
                  columnNumber: 37
                }, this),
                cleanPhone.length > 6 && /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: `https://wa.me/${cleanPhone}`,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "text-green-500 hover:text-green-700 transition-colors",
                    title: "Abrir chat de WhatsApp",
                    children: /* @__PURE__ */ jsxDEV(FaWhatsapp, { size: 20 }, void 0, false, {
                      fileName: "/app/src/features/clientes/clientes.config.tsx",
                      lineNumber: 347,
                      columnNumber: 45
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/clientes/clientes.config.tsx",
                    lineNumber: 340,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/features/clientes/clientes.config.tsx",
                lineNumber: 337,
                columnNumber: 13
              }, this);
            }
          },
          {
            name: "whatsapp",
            label: "WhatsApp",
            type: "text",
            placeholder: "Ej: +5491112345678",
            render: (item) => {
              if (!item.whatsapp) return "-";
              const cleanWa = item.whatsapp.replace(/[^0-9]/g, "");
              return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { children: item.whatsapp }, void 0, false, {
                  fileName: "/app/src/features/clientes/clientes.config.tsx",
                  lineNumber: 364,
                  columnNumber: 37
                }, this),
                cleanWa.length > 6 && /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: `https://wa.me/${cleanWa}`,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "text-green-500 hover:text-green-700 transition-colors",
                    title: "Abrir chat de WhatsApp",
                    children: /* @__PURE__ */ jsxDEV(FaWhatsapp, { size: 20 }, void 0, false, {
                      fileName: "/app/src/features/clientes/clientes.config.tsx",
                      lineNumber: 373,
                      columnNumber: 45
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/clientes/clientes.config.tsx",
                    lineNumber: 366,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/features/clientes/clientes.config.tsx",
                lineNumber: 363,
                columnNumber: 13
              }, this);
            }
          },
          {
            name: "email",
            label: "Email",
            type: "email",
            allowMultipleEmails: true,
            placeholder: "Uno o varios, separados por coma o espacio"
          },
          { name: "contact", label: "Persona de Contacto", type: "text" },
          { name: "rubro", label: "Rubro", type: "text" },
          {
            name: "salesrep",
            label: "Vendedor Asignado",
            type: "relational",
            relationalConfig: {
              moduleConfig: vendedoresModuleConfig,
              codeField: "salesrep_code",
              nameField: "salesrep_name"
            },
            render: (item) => item.salesrep_name?.toString() || "-"
          },
          {
            name: "buyer_id",
            label: "Comprador",
            type: "relational",
            relationalConfig: {
              moduleConfig: compradoresModuleConfig,
              codeField: "buyer_code",
              nameField: "buyer_name"
            },
            render: (item) => item.buyer_name || "-"
          }
          // Podría ser un 'select' si tienes una lista de vendedores
        ]
      },
      {
        name: "Datos de Entrega",
        fields: [
          {
            name: "shipaddress",
            label: "Domicilios de Entrega",
            type: "array-string",
            // ✅ USAMOS EL NUEVO TIPO
            placeholder: "Calle, Número, Localidad"
          },
          {
            name: "zone",
            label: "Zona",
            type: "select",
            loadOptions: loadZones,
            render: (item) => item.zone_name?.toString() || "-"
          },
          {
            name: "transport_id",
            label: "Transporte",
            type: "relational",
            relationalConfig: {
              moduleConfig: transportesModuleConfig,
              codeField: "transport_code",
              nameField: "transport_name"
            },
            render: (item) => item.transport_name || "-"
          }
        ]
      },
      {
        name: "Datos de Cobranza",
        fields: [
          { name: "paymentaddress", label: "Domicilio de Cobranza", type: "text" },
          { name: "paymentcity", label: "Localidad de Cobranza", type: "text" },
          { name: "paymentzip", label: "CP de Cobranza", type: "text" },
          { name: "paymentcontact", label: "Contacto de Cobranza", type: "text" },
          { name: "paymentphone", label: "Teléfono de Cobranza", type: "text" },
          { name: "paymentdays", label: "Días de Cobranza", type: "text", placeholder: "Ej: Lunes, Miércoles" },
          { name: "paymenthour", label: "Horario de Cobranza", type: "text", placeholder: "Ej: 9 a 12 hs" },
          { name: "paymentobs", label: "Observaciones de Cobranza", type: "text" },
          { name: "plazoreal", label: "Plazo real", type: "number" },
          { name: "collection_contact", label: "Contacto", type: "text", placeholder: "Contacto de cobranza" },
          {
            name: "collection_email",
            label: "Email",
            type: "email",
            allowMultipleEmails: true,
            placeholder: "Uno o varios, separados por coma o espacio"
          },
          { name: "collection_phone", label: "Teléfono", type: "text" },
          { name: "collection_portal_url", label: "URL de portal de cobros", type: "url", placeholder: "https://..." },
          { name: "collection_portal_username", label: "Usuario de portal de cobros", type: "text" },
          { name: "collection_portal_password", label: "Clave de portal de cobros", type: "password" }
        ]
      },
      {
        name: "Otros Datos de Cobranza",
        fields: [
          { name: "observations", label: "Observaciones Generales", type: "text" },
          // --- Grupo: Domicilios ---
          // --- Grupo: Datos Impositivos y de Crédito ---
          { name: "payday", label: "Días de Pago", type: "number" },
          { name: "credit", label: "Límite de Crédito", type: "number" },
          { name: "freetax", label: "Exención", type: "number" },
          {
            name: "fce",
            label: "Adherido a FCE",
            type: "select",
            options: [
              // Opciones de ejemplo
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.fce ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.fce ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 495,
              columnNumber: 9
            }, this),
            valueType: "boolean"
          },
          {
            name: "cbu",
            label: "CBU",
            type: "text",
            placeholder: "22 dígitos",
            mask: "cbu",
            visibleWhen: (formData) => Boolean(formData.fce),
            mandatory: (formData) => Boolean(formData.fce)
          },
          // --- Grupo: Datos de Cobranza ---
          // --- Grupo: Configuraciones Avanzadas (Banderas) ---
          {
            name: "congelcli",
            label: "Cliente Congelado",
            type: "select",
            options: [
              // Opciones de ejemplo
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.congelcli ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.congelcli ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 521,
              columnNumber: 9
            }, this),
            valueType: "boolean"
          },
          {
            name: "prospect",
            label: "Es Prospecto",
            type: "select",
            options: [
              // Opciones de ejemplo
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            valueType: "boolean",
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.prospect ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.prospect ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 534,
              columnNumber: 9
            }, this)
          },
          {
            name: "pediriva",
            label: "Pedir Constancia de IVA",
            type: "select",
            options: [
              // Opciones de ejemplo
              { value: "0", label: "No" },
              { value: "1", label: "Si" }
            ],
            render: (item) => /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.pediriva ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.pediriva ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/clientes/clientes.config.tsx",
              lineNumber: 545,
              columnNumber: 9
            }, this),
            valueType: "boolean"
          }
        ]
      }
    ]
  },
  relationalFields: {
    idField: "id",
    codeField: "customer_code",
    // El cliente buscará por SKU
    nameField: "name"
    // Y mostraremos el nombre
  },
  listItemCodeKey: "customer_code",
  listItemNameKey: "name"
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0pvQjtBQS9KcEIsU0FBU0EsY0FBYztBQUV2QixTQUFTQyxpQ0FBaUM7QUFDMUMsZUFBNkM7QUFDN0MsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx5QkFBeUJDLHdDQUF3QztBQXlGMUUsTUFBTUMsZ0JBQStCLFlBQVk7QUFHN0MsUUFBTUMsV0FBVyxNQUFNVixPQUFxQyxXQUFXO0FBQ3ZFLFNBQU9VLFNBQVNDLEtBQUtDLElBQUksQ0FBQUMsY0FBYTtBQUFBLElBQ2xDQyxPQUFPRCxTQUFTRTtBQUFBQSxJQUNoQkMsT0FBT0gsU0FBU0k7QUFBQUEsRUFDcEIsRUFBRTtBQUNOO0FBRUEsTUFBTUMsWUFBMkIsWUFBWTtBQUN6QyxRQUFNUixXQUFXLE1BQU1WLE9BQW1ELE9BQU87QUFDakYsU0FBT1UsU0FBU0MsS0FBS0MsSUFBSSxDQUFDTyxPQUFPO0FBQUEsSUFDN0JMLE9BQU9LLEVBQUVKO0FBQUFBLElBQ1RDLE9BQU8sR0FBR0csRUFBRUMsSUFBSSxNQUFNRCxFQUFFRixJQUFJO0FBQUEsRUFDaEMsRUFBRTtBQUNOO0FBRUEsTUFBTUksc0JBQXNCO0FBQUEsRUFDeEIsRUFBRVAsT0FBTyxLQUFLRSxPQUFPLDRCQUE0QjtBQUFBLEVBQ2pELEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxpQkFBaUI7QUFBQSxFQUN0QyxFQUFFRixPQUFPLEtBQUtFLE9BQU8sU0FBUztBQUFBLEVBQzlCLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxtQkFBbUI7QUFBQSxFQUN4QyxFQUFFRixPQUFPLEtBQUtFLE9BQU8saUJBQWlCO0FBQUM7QUFJM0MsTUFBTU0scUJBQXFCckI7QUFBQUEsRUFDdkJvQjtBQUFBQSxFQUNBO0FBQ0o7QUFHTyxhQUFNRSx1QkFBOEM7QUFBQSxFQUN2REMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaQyxrQkFBa0I7QUFBQSxFQUNsQkMsV0FBVztBQUFBO0FBQUEsRUFHWEMsUUFBUTtBQUFBLElBQ0pDLGdCQUFnQjtBQUFBLEVBQ3BCO0FBQUE7QUFBQSxFQUlBQyxNQUFNO0FBQUEsSUFDRkMsU0FBUztBQUFBO0FBQUEsTUFFTCxFQUFFQyxRQUFRLGtCQUFrQkMsVUFBVSxnQkFBaUI7QUFBQSxNQUN2RCxFQUFFRCxRQUFRLHlCQUF5QkMsVUFBVSxPQUFPO0FBQUEsTUFDcEQsRUFBRUQsUUFBUSxRQUFRQyxVQUFVLE9BQU87QUFBQSxNQUNuQyxFQUFFRCxRQUFRLFlBQVlDLFVBQVUsU0FBU0MsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS0MsU0FBUyxJQUFJO0FBQUEsTUFDN0UsRUFBRUosUUFBUSxTQUFTQyxVQUFVLFNBQVNDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtFLFNBQVMsSUFBSTtBQUFBLE1BQzFFLEVBQUVMLFFBQVEsdUJBQXVCQyxVQUFVLFdBQVdDLFFBQVFBLENBQUNDLFNBQVNBLEtBQUtHLFdBQVcsSUFBSTtBQUFBLE1BQzVGLEVBQUVOLFFBQVEsU0FBU0MsVUFBVSxTQUFTQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLSSxTQUFTLElBQUk7QUFBQSxNQUMxRSxFQUFFUCxRQUFRLFFBQVFDLFVBQVUsYUFBYUMsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS0ssYUFBYSxJQUFJO0FBQUEsTUFDakY7QUFBQSxRQUNJUixRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFBLENBQUNDLFNBQ0wsdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUEsS0FBS00sc0JBQXNCLGdDQUFnQywyQkFBMkIsSUFDbktOLGVBQUtNLHNCQUFzQixPQUFPLFFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBQ0E7QUFBQSxFQThFUjtBQUFBO0FBQUEsRUFHQUMsTUFBTTtBQUFBO0FBQUEsSUFFRkMsT0FBTztBQUFBLE1BQ0g7QUFBQSxRQUNJMUIsTUFBTTtBQUFBLFFBQ04yQixRQUFRO0FBQUE7QUFBQSxVQUVKLEVBQUUzQixNQUFNLGlCQUFpQkQsT0FBTyxrQkFBa0I2QixNQUFNLFFBQVFDLFlBQVksS0FBSztBQUFBLFVBQ2pGLEVBQUU3QixNQUFNLFFBQVFELE9BQU8sUUFBUTZCLE1BQU0sUUFBUUUsYUFBYSxxQkFBcUJDLFdBQVcsTUFBTUMsTUFBTSxPQUFPO0FBQUEsVUFDN0c7QUFBQSxZQUNJaEMsTUFBTTtBQUFBLFlBQ05ELE9BQU87QUFBQSxZQUNQNkIsTUFBTTtBQUFBLFlBQ05LLFNBQVM3QjtBQUFBQSxZQUNUYSxRQUFRWjtBQUFBQSxZQUNSNkIsZ0JBQWdCQSxDQUFDQyxVQUFVQyxhQUFhQyxtQkFBbUI7QUFDdkRBLDZCQUFlO0FBQUEsZ0JBQ1hDLE9BQU8vQyxpQ0FBaUNnRCxPQUFPSixRQUFRLEdBQUdDLFlBQVlFLEtBQUs7QUFBQSxjQUMvRSxDQUFDO0FBQUEsWUFDTDtBQUFBLFVBQ0o7QUFBQSxVQUNBLEVBQUV0QyxNQUFNLFFBQVFELE9BQU8seUJBQXlCNkIsTUFBTSxRQUFRRSxhQUFhLG9CQUFvQkMsV0FBVyxLQUFLO0FBQUEsVUFDL0c7QUFBQSxZQUNJL0IsTUFBTTtBQUFBLFlBQWFELE9BQU87QUFBQSxZQUFlNkIsTUFBTTtBQUFBLFlBQVVLLFNBQVM7QUFBQTtBQUFBLGNBQzlELEVBQUVwQyxPQUFPLEtBQUtFLE9BQU8sS0FBSztBQUFBLGNBQzFCLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsWUFBQztBQUFBLFlBRS9CeUMsV0FBVztBQUFBLFlBQ1h2QixRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUt1QixZQUFZLGdDQUFnQyx5QkFBeUIsSUFDdkp2QixlQUFLdUIsWUFBWSxPQUFPLFFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUVSO0FBQUEsVUFDQTtBQUFBLFlBQ0l6QyxNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTkssU0FBUztBQUFBLGNBQ0wsRUFBRXBDLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsY0FDMUIsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLEtBQUs7QUFBQSxZQUFDO0FBQUEsWUFFL0J5QyxXQUFXO0FBQUEsWUFDWHZCLFFBQVFBLENBQUNDLFNBQ0wsdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUEsS0FBS00sc0JBQXNCLGdDQUFnQywyQkFBMkIsSUFDbktOLGVBQUtNLHNCQUFzQixPQUFPLFFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUVSO0FBQUEsVUFDQTtBQUFBLFlBQ0l4QixNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTmMsWUFBWUEsQ0FBQ0MsT0FBT3JELHdCQUF3QnFELEdBQUdDLEdBQUcsRUFBRWpELElBQUksQ0FBQWtELE9BQU0sRUFBRWhELE9BQU9nRCxHQUFHOUMsT0FBTzhDLEVBQUUsRUFBRTtBQUFBLFlBQ3JGQyxVQUFVQSxDQUFDSCxPQUFPckQsd0JBQXdCcUQsR0FBR0MsR0FBRyxFQUFFRyxVQUFVO0FBQUEsWUFDNUQ5QixRQUFRQSxDQUFDQyxTQUFTQSxLQUFLb0IsU0FBUztBQUFBLFVBQ3BDO0FBQUEsVUFDQSxFQUFFdEMsTUFBTSxhQUFhRCxPQUFPLGlCQUFpQjZCLE1BQU0sUUFBUW9CLFFBQVEsT0FBTztBQUFBLFVBQzFFO0FBQUEsWUFDSWhELE1BQU07QUFBQSxZQUNORCxPQUFPO0FBQUEsWUFDUDZCLE1BQU07QUFBQSxZQUNOcUIsa0JBQWtCLEVBQUVDLGNBQWNqRSxxQkFBcUJrRSxXQUFXLGlCQUFpQkMsV0FBVyxnQkFBZ0I7QUFBQSxZQUM5R25DLFFBQVFBLENBQUNDLFNBQVNBLEtBQUttQyxpQkFBaUI7QUFBQSxVQUM1QztBQUFBLFFBQUM7QUFBQSxNQUVUO0FBQUEsTUFDQTtBQUFBLFFBQ0lyRCxNQUFNO0FBQUEsUUFDTjJCLFFBQVE7QUFBQSxVQUNKLEVBQUUzQixNQUFNLFdBQVdELE9BQU8sb0JBQW9CNkIsTUFBTSxPQUFPO0FBQUEsVUFDM0QsRUFBRTVCLE1BQU0sT0FBT0QsT0FBTyxpQkFBaUI2QixNQUFNLE9BQU87QUFBQSxVQUNwRCxFQUFFNUIsTUFBTSxRQUFRRCxPQUFPLGFBQWE2QixNQUFNLE9BQU87QUFBQSxVQUNqRDtBQUFBLFlBQ0k1QixNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTjBCLGFBQWE5RDtBQUFBQSxZQUNieUIsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBS3FDLGVBQWVDLFNBQVMsS0FBSztBQUFBLFVBQ3hEO0FBQUEsVUFDQTtBQUFBLFlBQ0l4RCxNQUFNO0FBQUEsWUFBU0QsT0FBTztBQUFBLFlBQ3RCNkIsTUFBTTtBQUFBLFlBQ05FLGFBQWE7QUFBQSxZQUNiYixRQUFRQSxDQUFDQyxTQUFrQjtBQUN2QixrQkFBSSxDQUFDQSxLQUFLQyxNQUFPLFFBQU87QUFHeEIsb0JBQU1zQyxhQUFhdkMsS0FBS0MsTUFBTXVDLFFBQVEsV0FBVyxFQUFFO0FBRW5ELHFCQUNJLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHVDQUFDLFVBQU14QyxlQUFLQyxTQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQ2pCc0MsV0FBV1YsU0FBUyxLQUNqQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFNLGlCQUFpQlUsVUFBVTtBQUFBLG9CQUNqQyxRQUFPO0FBQUEsb0JBQ1AsS0FBSTtBQUFBLG9CQUNKLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFCO0FBQUE7QUFBQSxrQkFQekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFBO0FBQUEsbUJBWFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLFlBRVI7QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFlBQ0l6RCxNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFlBQ2JiLFFBQVFBLENBQUNDLFNBQWtCO0FBQ3ZCLGtCQUFJLENBQUNBLEtBQUt5QyxTQUFVLFFBQU87QUFDM0Isb0JBQU1DLFVBQVUxQyxLQUFLeUMsU0FBU0QsUUFBUSxXQUFXLEVBQUU7QUFDbkQscUJBQ0ksdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsdUNBQUMsVUFBTXhDLGVBQUt5QyxZQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFCO0FBQUEsZ0JBQ3BCQyxRQUFRYixTQUFTLEtBQ2Q7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBTSxpQkFBaUJhLE9BQU87QUFBQSxvQkFDOUIsUUFBTztBQUFBLG9CQUNQLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQjtBQUFBO0FBQUEsa0JBUHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLG1CQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxZQUVSO0FBQUEsVUFDSjtBQUFBLFVBQ0E7QUFBQSxZQUNJNUQsTUFBTTtBQUFBLFlBQ05ELE9BQU87QUFBQSxZQUNQNkIsTUFBTTtBQUFBLFlBQ05pQyxxQkFBcUI7QUFBQSxZQUNyQi9CLGFBQWE7QUFBQSxVQUNqQjtBQUFBLFVBQ0EsRUFBRTlCLE1BQU0sV0FBV0QsT0FBTyx1QkFBdUI2QixNQUFNLE9BQU87QUFBQSxVQUM5RCxFQUFFNUIsTUFBTSxTQUFTRCxPQUFPLFNBQVM2QixNQUFNLE9BQU87QUFBQSxVQUM5QztBQUFBLFlBQ0k1QixNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTnFCLGtCQUFrQjtBQUFBLGNBQ2RDLGNBQWNoRTtBQUFBQSxjQUNkaUUsV0FBVztBQUFBLGNBQ1hDLFdBQVc7QUFBQSxZQUNmO0FBQUEsWUFDQW5DLFFBQVFBLENBQUNDLFNBQVNBLEtBQUs0QyxlQUFlTixTQUFTLEtBQUs7QUFBQSxVQUN4RDtBQUFBLFVBQ0E7QUFBQSxZQUNJeEQsTUFBTTtBQUFBLFlBQ05ELE9BQU87QUFBQSxZQUNQNkIsTUFBTTtBQUFBLFlBQ05xQixrQkFBa0I7QUFBQSxjQUNkQyxjQUFjL0Q7QUFBQUEsY0FDZGdFLFdBQVc7QUFBQSxjQUNYQyxXQUFXO0FBQUEsWUFDZjtBQUFBLFlBQ0FuQyxRQUFRQSxDQUFDQyxTQUFTQSxLQUFLNkMsY0FBYztBQUFBLFVBQ3pDO0FBQUE7QUFBQSxRQUFHO0FBQUEsTUFFWDtBQUFBLE1BQ0E7QUFBQSxRQUNJL0QsTUFBTTtBQUFBLFFBQ04yQixRQUFRO0FBQUEsVUFDSjtBQUFBLFlBQ0kzQixNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUE7QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDakI7QUFBQSxVQUNBO0FBQUEsWUFDSTlCLE1BQU07QUFBQSxZQUNORCxPQUFPO0FBQUEsWUFDUDZCLE1BQU07QUFBQSxZQUNOMEIsYUFBYXJEO0FBQUFBLFlBQ2JnQixRQUFRQSxDQUFDQyxTQUFTQSxLQUFLSyxXQUFXaUMsU0FBUyxLQUFLO0FBQUEsVUFDcEQ7QUFBQSxVQUNBO0FBQUEsWUFDSXhELE1BQU07QUFBQSxZQUNORCxPQUFPO0FBQUEsWUFDUDZCLE1BQU07QUFBQSxZQUNOcUIsa0JBQWtCO0FBQUEsY0FDZEMsY0FBYzlEO0FBQUFBLGNBQ2QrRCxXQUFXO0FBQUEsY0FDWEMsV0FBVztBQUFBLFlBQ2Y7QUFBQSxZQUNBbkMsUUFBUUEsQ0FBQ0MsU0FBU0EsS0FBSzhDLGtCQUFrQjtBQUFBLFVBQzdDO0FBQUEsUUFBQztBQUFBLE1BRVQ7QUFBQSxNQUNBO0FBQUEsUUFDSWhFLE1BQU07QUFBQSxRQUNOMkIsUUFBUTtBQUFBLFVBQ0osRUFBRTNCLE1BQU0sa0JBQWtCRCxPQUFPLHlCQUF5QjZCLE1BQU0sT0FBTztBQUFBLFVBQ3ZFLEVBQUU1QixNQUFNLGVBQWVELE9BQU8seUJBQXlCNkIsTUFBTSxPQUFPO0FBQUEsVUFDcEUsRUFBRTVCLE1BQU0sY0FBY0QsT0FBTyxrQkFBa0I2QixNQUFNLE9BQU87QUFBQSxVQUM1RCxFQUFFNUIsTUFBTSxrQkFBa0JELE9BQU8sd0JBQXdCNkIsTUFBTSxPQUFPO0FBQUEsVUFDdEUsRUFBRTVCLE1BQU0sZ0JBQWdCRCxPQUFPLHdCQUF3QjZCLE1BQU0sT0FBTztBQUFBLFVBQ3BFLEVBQUU1QixNQUFNLGVBQWVELE9BQU8sb0JBQW9CNkIsTUFBTSxRQUFRRSxhQUFhLHVCQUF1QjtBQUFBLFVBQ3BHLEVBQUU5QixNQUFNLGVBQWVELE9BQU8sdUJBQXVCNkIsTUFBTSxRQUFRRSxhQUFhLGdCQUFnQjtBQUFBLFVBQ2hHLEVBQUU5QixNQUFNLGNBQWNELE9BQU8sNkJBQTZCNkIsTUFBTSxPQUFPO0FBQUEsVUFDdkUsRUFBRTVCLE1BQU0sYUFBYUQsT0FBTyxjQUFjNkIsTUFBTSxTQUFTO0FBQUEsVUFDekQsRUFBRTVCLE1BQU0sc0JBQXNCRCxPQUFPLFlBQVk2QixNQUFNLFFBQVFFLGFBQWEsdUJBQXVCO0FBQUEsVUFDbkc7QUFBQSxZQUNJOUIsTUFBTTtBQUFBLFlBQ05ELE9BQU87QUFBQSxZQUNQNkIsTUFBTTtBQUFBLFlBQ05pQyxxQkFBcUI7QUFBQSxZQUNyQi9CLGFBQWE7QUFBQSxVQUNqQjtBQUFBLFVBQ0EsRUFBRTlCLE1BQU0sb0JBQW9CRCxPQUFPLFlBQVk2QixNQUFNLE9BQU87QUFBQSxVQUM1RCxFQUFFNUIsTUFBTSx5QkFBeUJELE9BQU8sMkJBQTJCNkIsTUFBTSxPQUFPRSxhQUFhLGNBQWM7QUFBQSxVQUMzRyxFQUFFOUIsTUFBTSw4QkFBOEJELE9BQU8sK0JBQStCNkIsTUFBTSxPQUFPO0FBQUEsVUFDekYsRUFBRTVCLE1BQU0sOEJBQThCRCxPQUFPLDZCQUE2QjZCLE1BQU0sV0FBVztBQUFBLFFBQUM7QUFBQSxNQUVwRztBQUFBLE1BRUE7QUFBQSxRQUNJNUIsTUFBTTtBQUFBLFFBQ04yQixRQUFRO0FBQUEsVUFDSixFQUFFM0IsTUFBTSxnQkFBZ0JELE9BQU8sMkJBQTJCNkIsTUFBTSxPQUFPO0FBQUE7QUFBQTtBQUFBLFVBWXZFLEVBQUU1QixNQUFNLFVBQVVELE9BQU8sZ0JBQWdCNkIsTUFBTSxTQUFTO0FBQUEsVUFDeEQsRUFBRTVCLE1BQU0sVUFBVUQsT0FBTyxxQkFBcUI2QixNQUFNLFNBQVM7QUFBQSxVQUM3RCxFQUFFNUIsTUFBTSxXQUFXRCxPQUFPLFlBQVk2QixNQUFNLFNBQVM7QUFBQSxVQUdyRDtBQUFBLFlBQ0k1QixNQUFNO0FBQUEsWUFBT0QsT0FBTztBQUFBLFlBQWtCNkIsTUFBTTtBQUFBLFlBQVVLLFNBQVM7QUFBQTtBQUFBLGNBQzNELEVBQUVwQyxPQUFPLEtBQUtFLE9BQU8sS0FBSztBQUFBLGNBQzFCLEVBQUVGLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsWUFBQztBQUFBLFlBRS9Ca0IsUUFBUUEsQ0FBQ0MsU0FDTCx1QkFBQyxVQUFLLFdBQVcsaUVBQWlFQSxLQUFLK0MsTUFBTSxnQ0FBZ0MseUJBQXlCLElBQ2pKL0MsZUFBSytDLE1BQU0sT0FBTyxRQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFSnpCLFdBQVc7QUFBQSxVQUNmO0FBQUEsVUFDQTtBQUFBLFlBQ0l4QyxNQUFNO0FBQUEsWUFDTkQsT0FBTztBQUFBLFlBQ1A2QixNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFlBQ2JFLE1BQU07QUFBQSxZQUNOa0MsYUFBYUEsQ0FBQ0MsYUFBYUMsUUFBUUQsU0FBU0YsR0FBRztBQUFBLFlBQy9DbEMsV0FBV0EsQ0FBQ29DLGFBQWFDLFFBQVFELFNBQVNGLEdBQUc7QUFBQSxVQUNqRDtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsWUFDSWpFLE1BQU07QUFBQSxZQUFhRCxPQUFPO0FBQUEsWUFBcUI2QixNQUFNO0FBQUEsWUFBVUssU0FBUztBQUFBO0FBQUEsY0FDcEUsRUFBRXBDLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsY0FDMUIsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLEtBQUs7QUFBQSxZQUFDO0FBQUEsWUFFL0JrQixRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUttRCxZQUFZLGdDQUFnQyx5QkFBeUIsSUFDdkpuRCxlQUFLbUQsWUFBWSxPQUFPLFFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVKN0IsV0FBVztBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDSXhDLE1BQU07QUFBQSxZQUFZRCxPQUFPO0FBQUEsWUFBZ0I2QixNQUFNO0FBQUEsWUFBVUssU0FBUztBQUFBO0FBQUEsY0FDOUQsRUFBRXBDLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsY0FDMUIsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLEtBQUs7QUFBQSxZQUFDO0FBQUEsWUFFL0J5QyxXQUFXO0FBQUEsWUFDWHZCLFFBQVFBLENBQUNDLFNBQ0wsdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUEsS0FBS29ELFdBQVcsZ0NBQWdDLHlCQUF5QixJQUN0SnBELGVBQUtvRCxXQUFXLE9BQU8sUUFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBRVI7QUFBQSxVQUNBO0FBQUEsWUFDSXRFLE1BQU07QUFBQSxZQUFZRCxPQUFPO0FBQUEsWUFBMkI2QixNQUFNO0FBQUEsWUFBVUssU0FBUztBQUFBO0FBQUEsY0FDekUsRUFBRXBDLE9BQU8sS0FBS0UsT0FBTyxLQUFLO0FBQUEsY0FDMUIsRUFBRUYsT0FBTyxLQUFLRSxPQUFPLEtBQUs7QUFBQSxZQUFDO0FBQUEsWUFFL0JrQixRQUFRQSxDQUFDQyxTQUNMLHVCQUFDLFVBQUssV0FBVyxpRUFBaUVBLEtBQUtxRCxXQUFXLGdDQUFnQyx5QkFBeUIsSUFDdEpyRCxlQUFLcUQsV0FBVyxPQUFPLFFBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVKL0IsV0FBVztBQUFBLFVBQ2Y7QUFBQSxRQUFDO0FBQUEsTUFFVDtBQUFBLElBQUM7QUFBQSxFQUVUO0FBQUEsRUFDQWdDLGtCQUFrQjtBQUFBLElBQ2RDLFNBQVM7QUFBQSxJQUNUdEIsV0FBVztBQUFBO0FBQUEsSUFDWEMsV0FBVztBQUFBO0FBQUEsRUFDZjtBQUFBLEVBQ0FzQixpQkFBaUI7QUFBQSxFQUNqQkMsaUJBQWlCO0FBQ3JCIiwibmFtZXMiOlsiZ2V0QWxsIiwiY3JlYXRlVmFsdWVNYXBwZXJSZW5kZXJlciIsIm1vbmVkYXNNb2R1bGVDb25maWciLCJ2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnIiwiY29tcHJhZG9yZXNNb2R1bGVDb25maWciLCJ0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyIsIkZhV2hhdHNhcHAiLCJnZXRBbGxvd2VkSW52b2ljZVNlcmllcyIsInJlc29sdmVJbnZvaWNlU2VyaWVzRm9yVGF4Q2hhbmdlIiwibG9hZERpc3RyaWN0cyIsInJlc3BvbnNlIiwiZGF0YSIsIm1hcCIsImRpc3RyaWN0IiwidmFsdWUiLCJpZCIsImxhYmVsIiwibmFtZSIsImxvYWRab25lcyIsInoiLCJjb2RlIiwidGF4Q29uZGl0aW9uT3B0aW9ucyIsInJlbmRlclRheENvbmRpdGlvbiIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwiZW5kcG9pbnQiLCJtb2R1bGVOYW1lIiwibW9kdWxlTmFtZVBsdXJhbCIsImJhc2VSb3V0ZSIsImRldGFpbCIsImRpc3BsYXlOYW1lS2V5IiwibGlzdCIsImNvbHVtbnMiLCJoZWFkZXIiLCJhY2Nlc3NvciIsInJlbmRlciIsIml0ZW0iLCJwaG9uZSIsImVtYWlsIiwiY29udGFjdCIsInJ1YnJvIiwiem9uZV9uYW1lIiwibGV5X2V4cG9ydGFjaW9uX3RkZiIsImZvcm0iLCJibG9jayIsImZpZWxkcyIsInR5cGUiLCJkZXRhaWxPbmx5IiwicGxhY2Vob2xkZXIiLCJtYW5kYXRvcnkiLCJtYXNrIiwib3B0aW9ucyIsIm9uQ2hhbmdlRWZmZWN0IiwibmV3VmFsdWUiLCJjdXJyZW50RGF0YSIsInVwZGF0ZUZvcm1EYXRhIiwic2VyaWUiLCJTdHJpbmciLCJ2YWx1ZVR5cGUiLCJyZXRpZW5pdmEiLCJnZXRPcHRpb25zIiwiZmQiLCJ0YXgiLCJzIiwicmVhZG9ubHkiLCJsZW5ndGgiLCJmb3JtYXQiLCJyZWxhdGlvbmFsQ29uZmlnIiwibW9kdWxlQ29uZmlnIiwiY29kZUZpZWxkIiwibmFtZUZpZWxkIiwiY3VycmVuY3lfbmFtZSIsImxvYWRPcHRpb25zIiwiZGlzdHJpY3RfbmFtZSIsInRvU3RyaW5nIiwiY2xlYW5QaG9uZSIsInJlcGxhY2UiLCJ3aGF0c2FwcCIsImNsZWFuV2EiLCJhbGxvd011bHRpcGxlRW1haWxzIiwic2FsZXNyZXBfbmFtZSIsImJ1eWVyX25hbWUiLCJ0cmFuc3BvcnRfbmFtZSIsImZjZSIsInZpc2libGVXaGVuIiwiZm9ybURhdGEiLCJCb29sZWFuIiwiY29uZ2VsY2xpIiwicHJvc3BlY3QiLCJwZWRpcml2YSIsInJlbGF0aW9uYWxGaWVsZHMiLCJpZEZpZWxkIiwibGlzdEl0ZW1Db2RlS2V5IiwibGlzdEl0ZW1OYW1lS2V5Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNsaWVudGVzLmNvbmZpZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0QWxsIH0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2VcIjtcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnLCBPcHRpb25zTG9hZGVyIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZVwiO1xuaW1wb3J0IHsgY3JlYXRlVmFsdWVNYXBwZXJSZW5kZXJlciB9IGZyb20gXCIuLi8uLi91dGlscy9yZW5kZXJzXCI7XG5pbXBvcnQgeyB0eXBlIFJlbGF0ZWRUYXggYXMgQ2xpZW50VGF4IH0gZnJvbSBcIi4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlc1wiO1xuaW1wb3J0IHsgbW9uZWRhc01vZHVsZUNvbmZpZyB9IGZyb20gXCIuLi9tb25lZGFzL21vbmVkYXMuY29uZmlnXCI7XG5pbXBvcnQgeyB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnIH0gZnJvbSBcIi4uL3ZlbmRlZG9yZXMvdmVuZGVkb3Jlcy5jb25maWdcIjtcbmltcG9ydCB7IGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnIH0gZnJvbSBcIi4uL2NvbXByYWRvcmVzL2NvbXByYWRvcmVzLmNvbmZpZ1wiO1xuaW1wb3J0IHsgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcgfSBmcm9tIFwiLi4vdHJhbnNwb3J0ZXMvdHJhbnNwb3J0ZXMuY29uZmlnXCI7XG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XG5pbXBvcnQgeyBnZXRBbGxvd2VkSW52b2ljZVNlcmllcywgcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JUYXhDaGFuZ2UgfSBmcm9tIFwiLi4vLi4vdXRpbHMvaW52b2ljZVNlcmllc1wiO1xuXG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2xpZW50ZSB7XG5cbiAgICAvLyAtLS0gSWRlbnRpZmljYWRvciBQcmluY2lwYWwgLS0tXG4gICAgaWQ6IG51bWJlcjtcblxuICAgIC8vIC0tLSBEYXRvcyBQcmluY2lwYWxlcyAtLS1cbiAgICBjdXN0b21lcl9jb2RlOiBzdHJpbmc7XG4gICAgbmFtZTogc3RyaW5nOyAvLyBSZXF1ZXJpZG9cbiAgICBjdWl0OiBzdHJpbmc7IC8vIFJlcXVlcmlkb1xuICAgIHBob25lOiBzdHJpbmcgfCBudWxsO1xuICAgIHdoYXRzYXBwOiBzdHJpbmcgfCBudWxsO1xuICAgIGVtYWlsOiBzdHJpbmcgfCBudWxsO1xuICAgIGVzdGFkbzogJ0FjdGl2bycgfCAnSW5hY3Rpdm8nO1xuICAgIGNvbnRhY3Q6IHN0cmluZyB8IG51bGw7XG4gICAgcnVicm86IHN0cmluZyB8IG51bGw7XG4gICAgc2FsZXNyZXA6IG51bWJlciB8IG51bGw7XG4gICAgc2FsZXNyZXBfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBzYWxlc3JlcF9jb2RlPzogc3RyaW5nIHwgbnVsbDtcblxuICAgIG9ic2VydmF0aW9uczogc3RyaW5nIHwgbnVsbDtcblxuICAgIC8vIC0tLSBEb21pY2lsaW9zIC0tLVxuICAgIGFkZHJlc3M6IHN0cmluZyB8IG51bGw7XG4gICAgc2hpcGFkZHJlc3M6IHN0cmluZ1tdO1xuICAgIHppcDogc3RyaW5nIHwgbnVsbDtcbiAgICBjaXR5OiBzdHJpbmcgfCBudWxsO1xuICAgIGRpc3RyaWN0OiBudW1iZXIgfCBudWxsO1xuICAgIGRpc3RyaWN0X25hbWU6IHN0cmluZyB8IG51bGw7XG4gICAgLyoqIElkIGRlIHpvbmEgKGB6b25lcy5pZGApLCBtaXNtbyBjcml0ZXJpbyBxdWUgYGRpc3RyaWN0YC4gKi9cbiAgICB6b25lOiBudW1iZXIgfCBudWxsO1xuICAgIHpvbmVfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBzdGFydGRhdGU6IHN0cmluZyB8IG51bGw7XG5cbiAgICAvLyAtLS0gRGF0b3MgSW1wb3NpdGl2b3MgeSBkZSBDcsOpZGl0byAtLS1cbiAgICB0YXg6ICdJJyB8ICdNJyB8ICdFJyB8IHN0cmluZyB8IG51bGw7IC8vIFB1ZWRlcyBhanVzdGFyIGxvcyB0aXBvcyBsaXRlcmFsZXMgc2Vnw7puIHR1cyBuZWNlc2lkYWRlc1xuICAgIHBheWRheTogbnVtYmVyIHwgbnVsbDtcbiAgICBjcmVkaXQ6IG51bWJlciB8IG51bGw7XG4gICAgZnJlZXRheDogbnVtYmVyIHwgbnVsbDtcbiAgICBzZXJpZTogc3RyaW5nIHwgbnVsbDtcbiAgICByZXRpZW5pdmE6IGJvb2xlYW47XG4gICAgZmNlOiBib29sZWFuO1xuICAgIGxleV9leHBvcnRhY2lvbl90ZGY6IGJvb2xlYW47XG4gICAgLyoqIENsYXZlIGJhbmNhcmlhIHVuaWZvcm1lOyBzb2xvIHJlbGV2YW50ZSBzaSBlc3TDoSBhZGhlcmlkbyBhIEZDRS4gKi9cbiAgICBjYnU6IHN0cmluZyB8IG51bGw7XG5cbiAgICBidXllcl9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICBidXllcl9uYW1lPzogc3RyaW5nIHwgbnVsbDtcbiAgICBidXllcl9jb2RlPzogc3RyaW5nIHwgbnVsbDtcbiAgICB0cmFuc3BvcnRfaWQ6IG51bWJlciB8IG51bGw7XG4gICAgdHJhbnNwb3J0X25hbWU/OiBzdHJpbmcgfCBudWxsO1xuICAgIHRyYW5zcG9ydF9jb2RlPzogc3RyaW5nIHwgbnVsbDtcbiAgICBjdXJyZW5jeV9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICBjdXJyZW5jeV9uYW1lPzogc3RyaW5nIHwgbnVsbDtcbiAgICBjdXJyZW5jeV9jb2RlPzogc3RyaW5nIHwgbnVsbDtcblxuICAgIC8vIC0tLSBEYXRvcyBkZSBDb2JyYW56YSAtLS1cbiAgICBwYXltZW50YWRkcmVzczogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50Y2l0eTogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50emlwOiBzdHJpbmcgfCBudWxsO1xuICAgIHBheW1lbnRjb250YWN0OiBzdHJpbmcgfCBudWxsO1xuICAgIHBheW1lbnRwaG9uZTogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50ZGF5czogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50aG91cjogc3RyaW5nIHwgbnVsbDtcbiAgICBwYXltZW50b2JzOiBzdHJpbmcgfCBudWxsO1xuICAgIHBsYXpvcmVhbDogbnVtYmVyIHwgbnVsbDtcblxuICAgIGNvbGxlY3Rpb25fY29udGFjdDogc3RyaW5nIHwgbnVsbDtcbiAgICBjb2xsZWN0aW9uX2VtYWlsOiBzdHJpbmcgfCBudWxsO1xuICAgIGNvbGxlY3Rpb25fcGhvbmU6IHN0cmluZyB8IG51bGw7XG4gICAgY29sbGVjdGlvbl9wb3J0YWxfdXJsOiBzdHJpbmcgfCBudWxsO1xuICAgIGNvbGxlY3Rpb25fcG9ydGFsX3VzZXJuYW1lOiBzdHJpbmcgfCBudWxsO1xuICAgIGNvbGxlY3Rpb25fcG9ydGFsX3Bhc3N3b3JkOiBzdHJpbmcgfCBudWxsO1xuXG4gICAgLy8gLS0tIENvbmZpZ3VyYWNpb25lcyAoQmFuZGVyYXMgQm9vbGVhbmFzKSAtLS1cbiAgICBjb25nZWxjbGk6IGJvb2xlYW47XG4gICAgcHJvc3BlY3Q6IGJvb2xlYW47XG4gICAgcGVkaXJpdmE6IGJvb2xlYW47XG4gICAgcmVsYXRlZFRheGVzPzogQ2xpZW50VGF4W11cbiAgICB0YXhlcz86IG51bWJlcltdO1xuICAgIC8qKiBTYWxkbyBhIGZhdm9yIGRlbCBjbGllbnRlIChhbCBjb25zdWx0YXIgZW4gY29udGV4dG8gZGUgY29icmFuemFzKS4gKi9cbiAgICBhZHZhbmNlX2JhbGFuY2U/OiBudW1iZXI7XG4gICAgLy8gLS0tIFRpbWVzdGFtcHMgKE9wY2lvbmFsLCBwZXJvIMO6dGlsIHRlbmVybG9zKSAtLS1cbiAgICBjcmVhdGVkX2F0Pzogc3RyaW5nO1xuICAgIHVwZGF0ZWRfYXQ/OiBzdHJpbmc7XG59XG5cbmNvbnN0IGxvYWREaXN0cmljdHM6IE9wdGlvbnNMb2FkZXIgPSBhc3luYyAoKSA9PiB7XG4gICAgLy8gQXN1bWltb3MgcXVlIGxhIEFQSSBkZXZ1ZWx2ZSB1biBvYmpldG8gY29uIHVuYSBwcm9waWVkYWQgJ2RhdGEnIHF1ZSBlcyB1biBhcnJheS5cbiAgICAvLyBZIHF1ZSBjYWRhIG9iamV0byBkZWwgYXJyYXkgdGllbmUgJ2lkJyB5ICduYW1lJy4gQWp1c3RhIHNpIGVzIGRpZmVyZW50ZS5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldEFsbDx7IGlkOiBudW1iZXI7IG5hbWU6IHN0cmluZyB9PignZGlzdHJpY3RzJyk7XG4gICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEubWFwKGRpc3RyaWN0ID0+ICh7XG4gICAgICAgIHZhbHVlOiBkaXN0cmljdC5pZCxcbiAgICAgICAgbGFiZWw6IGRpc3RyaWN0Lm5hbWVcbiAgICB9KSk7XG59O1xuXG5jb25zdCBsb2FkWm9uZXM6IE9wdGlvbnNMb2FkZXIgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBnZXRBbGw8eyBpZDogbnVtYmVyOyBjb2RlOiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9Pignem9uZXMnKTtcbiAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS5tYXAoKHopID0+ICh7XG4gICAgICAgIHZhbHVlOiB6LmlkLFxuICAgICAgICBsYWJlbDogYCR7ei5jb2RlfSDigJMgJHt6Lm5hbWV9YCxcbiAgICB9KSk7XG59O1xuXG5jb25zdCB0YXhDb25kaXRpb25PcHRpb25zID0gW1xuICAgIHsgdmFsdWU6ICdJJywgbGFiZWw6ICdJVkEgUmVzcG9uc2FibGUgSW5zY3JpcHRvJyB9LFxuICAgIHsgdmFsdWU6ICdNJywgbGFiZWw6ICdNb25vdHJpYnV0aXN0YScgfSxcbiAgICB7IHZhbHVlOiAnRScsIGxhYmVsOiAnRXhlbnRvJyB9LFxuICAgIHsgdmFsdWU6ICdDJywgbGFiZWw6ICdDb25zdW1pZG9yIEZpbmFsJyB9LFxuICAgIHsgdmFsdWU6ICdOJywgbGFiZWw6ICdObyBSZXNwb25zYWJsZScgfSxcbl07XG5cbi8vIDIuIENyZWEgZWwgcmVuZGVyZXIgcmV1dGlsaXphYmxlIGEgcGFydGlyIGRlIGVzb3MgaW5ncmVkaWVudGVzLlxuY29uc3QgcmVuZGVyVGF4Q29uZGl0aW9uID0gY3JlYXRlVmFsdWVNYXBwZXJSZW5kZXJlcjxDbGllbnRlPihcbiAgICB0YXhDb25kaXRpb25PcHRpb25zLFxuICAgICd0YXgnXG4pO1xuXG4vLyBBcGxpY2Ftb3MgbGEgbnVldmEgZXN0cnVjdHVyYSBkZSBjb25maWd1cmFjacOzblxuZXhwb3J0IGNvbnN0IGNsaWVudGVzTW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8Q2xpZW50ZT4gPSB7XG4gICAgZW5kcG9pbnQ6ICdjbGllbnRzJyxcbiAgICBtb2R1bGVOYW1lOiAnQ2xpZW50ZScsXG4gICAgbW9kdWxlTmFtZVBsdXJhbDogJ0NsaWVudGVzJyxcbiAgICBiYXNlUm91dGU6ICcvY2xpZW50ZXMnLFxuXG4gICAgLy8gU2VjY2nDs24gcGFyYSBsYSB2aXN0YSBkZSBkZXRhbGxlXG4gICAgZGV0YWlsOiB7XG4gICAgICAgIGRpc3BsYXlOYW1lS2V5OiAnbmFtZScsXG4gICAgfSxcblxuICAgIC8vIFJlZW1wbGF6YSBsYSBwcm9waWVkYWQgJ2xpc3QnIGVuIHR1IGFyY2hpdm8gZGUgY29uZmlndXJhY2nDs24gY29uIGVzdGEgdmVyc2nDs24gY29tcGxldGE6XG5cbiAgICBsaXN0OiB7XG4gICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRGF0b3MgUHJpbmNpcGFsZXMgLS0tXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0PDs2RpZ28gQ2xpZW50ZScsIGFjY2Vzc29yOiAnY3VzdG9tZXJfY29kZScsIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ05vbWJyZSBvIFJhesOzbiBTb2NpYWwnLCBhY2Nlc3NvcjogJ25hbWUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NVSVQnLCBhY2Nlc3NvcjogJ2N1aXQnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1RlbMOpZm9ubycsIGFjY2Vzc29yOiAncGhvbmUnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnBob25lIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdFbWFpbCcsIGFjY2Vzc29yOiAnZW1haWwnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmVtYWlsIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdQZXJzb25hIGRlIENvbnRhY3RvJywgYWNjZXNzb3I6ICdjb250YWN0JywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5jb250YWN0IHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdSdWJybycsIGFjY2Vzc29yOiAncnVicm8nLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnJ1YnJvIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdab25hJywgYWNjZXNzb3I6ICd6b25lX25hbWUnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnpvbmVfbmFtZSB8fCAnLScgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdMZXkgRXhwb3J0YWNpw7NuIFRERicsXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6ICdsZXlfZXhwb3J0YWNpb25fdGRmJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtpdGVtLmxleV9leHBvcnRhY2lvbl90ZGYgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxleV9leHBvcnRhY2lvbl90ZGYgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8qXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1ZlbmRlZG9yIEFzaWduYWRvJywgYWNjZXNzb3I6ICdzYWxlc3JlcF9uYW1lJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5zYWxlc3JlcF9uYW1lIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdDb21wcmFkb3InLCBhY2Nlc3NvcjogJ2J1eWVyX25hbWUnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmJ1eWVyX25hbWUgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1RyYW5zcG9ydGUnLCBhY2Nlc3NvcjogJ3RyYW5zcG9ydF9uYW1lJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS50cmFuc3BvcnRfbmFtZSB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnT2JzZXJ2YWNpb25lcycsIGFjY2Vzc29yOiAnb2JzZXJ2YXRpb25zJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5vYnNlcnZhdGlvbnMgfHwgJy0nIH0sXG5cbiAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRG9taWNpbGlvcyAtLS1cbiAgICAgICAgICAgIHsgaGVhZGVyOiAnRG9taWNpbGlvIEZpc2NhbCcsIGFjY2Vzc29yOiAnYWRkcmVzcycsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uYWRkcmVzcyB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnQ8OzZGlnbyBQb3N0YWwnLCBhY2Nlc3NvcjogJ3ppcCcsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uemlwIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdMb2NhbGlkYWQnLCBhY2Nlc3NvcjogJ2NpdHknLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmNpdHkgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1Byb3ZpbmNpYScsIGFjY2Vzc29yOiAnZGlzdHJpY3QnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmRpc3RyaWN0X25hbWU/LnRvU3RyaW5nKCkgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1pvbmEnLCBhY2Nlc3NvcjogJ3pvbmVfbmFtZScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uem9uZV9uYW1lIHx8ICctJyB9LFxuXG4gICAgICAgICAgICAvLyAtLS0gR3J1cG86IERhdG9zIEltcG9zaXRpdm9zIHkgZGUgQ3LDqWRpdG8gLS0tXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NvbmRpY2nDs24gSVZBJywgYWNjZXNzb3I6ICd0YXgnLCByZW5kZXI6IHJlbmRlclRheENvbmRpdGlvbiB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdEw61hcyBkZSBQYWdvJywgYWNjZXNzb3I6ICdwYXlkYXknLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnBheWRheT8udG9TdHJpbmcoKSB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnTMOtbWl0ZSBkZSBDcsOpZGl0bycsIGFjY2Vzc29yOiAnY3JlZGl0JywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5jcmVkaXQ/LnRvU3RyaW5nKCkgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0V4ZW5jacOzbicsIGFjY2Vzc29yOiAnZnJlZXRheCcsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uZnJlZXRheD8udG9TdHJpbmcoKSB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnU2VyaWUgZGUgRmFjdHVyYScsIGFjY2Vzc29yOiAnc2VyaWUnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnNlcmllIHx8ICctJyB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1JldGllbmUgSVZBJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ3JldGllbml2YScsXG4gICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXRlbS5yZXRpZW5pdmEgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5yZXRpZW5pdmEgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdBZGhlcmlkbyBhIEZDRScsXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6ICdmY2UnLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0uZmNlID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZmNlID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogRGF0b3MgZGUgQ29icmFuemEgLS0tXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0RvbWljaWxpbyBkZSBDb2JyYW56YScsIGFjY2Vzc29yOiAncGF5bWVudGFkZHJlc3MnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnBheW1lbnRhZGRyZXNzIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdMb2NhbGlkYWQgZGUgQ29icmFuemEnLCBhY2Nlc3NvcjogJ3BheW1lbnRjaXR5JywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5wYXltZW50Y2l0eSB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnQ1AgZGUgQ29icmFuemEnLCBhY2Nlc3NvcjogJ3BheW1lbnR6aXAnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnBheW1lbnR6aXAgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NvbnRhY3RvIGRlIENvYnJhbnphJywgYWNjZXNzb3I6ICdwYXltZW50Y29udGFjdCcsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucGF5bWVudGNvbnRhY3QgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1RlbMOpZm9ubyBkZSBDb2JyYW56YScsIGFjY2Vzc29yOiAncGF5bWVudHBob25lJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5wYXltZW50cGhvbmUgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0TDrWFzIGRlIENvYnJhbnphJywgYWNjZXNzb3I6ICdwYXltZW50ZGF5cycsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucGF5bWVudGRheXMgfHwgJy0nIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0hvcmFyaW8gZGUgQ29icmFuemEnLCBhY2Nlc3NvcjogJ3BheW1lbnRob3VyJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5wYXltZW50aG91ciB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnT2JzLiBkZSBDb2JyYW56YScsIGFjY2Vzc29yOiAncGF5bWVudG9icycsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucGF5bWVudG9icyB8fCAnLScgfSxcblxuICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBDb25maWd1cmFjaW9uZXMgQXZhbnphZGFzIChCYW5kZXJhcykgLS0tXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaGVhZGVyOiAnQ2xpZW50ZSBDb25nZWxhZG8nLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAnY29uZ2VsY2xpJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtpdGVtLmNvbmdlbGNsaSA/ICdiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCcgOiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb25nZWxjbGkgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6ICdFcyBQcm9zcGVjdG8nLFxuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAncHJvc3BlY3QnLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0ucHJvc3BlY3QgPyAnYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCcgOiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9zcGVjdCA/ICdTw60nIDogJ05vJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ1BlZGlyIENvbnN0YW5jaWEgZGUgSVZBJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ3BlZGlyaXZhJyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtpdGVtLnBlZGlyaXZhID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGVkaXJpdmEgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICovXG4gICAgICAgIF0sXG4gICAgfSxcblxuICAgIC8vIE5VRVZBIFNFQ0NJw5NOOiBEZWZpbmljacOzbiBkZSBsb3MgY2FtcG9zIHBhcmEgZWwgZm9ybXVsYXJpb1xuICAgIGZvcm06IHtcbiAgICAgICAgLy8gUmVlbXBsYXphIGVsIGNvbnRlbmlkbyBkZSAnZmllbGRzJyBlbiB0dSBhcmNoaXZvIGNsaWVudGVzLmNvbmZpZy50c3ggY29uIGVzdG86XG4gICAgICAgIGJsb2NrOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJEYXRvcyBiw6FzaWNvc1wiLFxuICAgICAgICAgICAgICAgIGZpZWxkczogW1xuICAgICAgICAgICAgICAgICAgICAvLyAtLS0gR3J1cG86IERhdG9zIFByaW5jaXBhbGVzIC0tLVxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdjdXN0b21lcl9jb2RlJywgbGFiZWw6ICdDw7NkaWdvIENsaWVudGUnLCB0eXBlOiAndGV4dCcsIGRldGFpbE9ubHk6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnY3VpdCcsIGxhYmVsOiAnQ1VJVCcsIHR5cGU6ICd0ZXh0JywgcGxhY2Vob2xkZXI6ICdFajogMzAtMTIzNDU2NzgtOScsIG1hbmRhdG9yeTogdHJ1ZSwgbWFzazogJ2N1aXQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICd0YXgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdDb25kaWNpw7NuIFRyaWJ1dGFyaWEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiB0YXhDb25kaXRpb25PcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiByZW5kZXJUYXhDb25kaXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZUVmZmVjdDogKG5ld1ZhbHVlLCBjdXJyZW50RGF0YSwgdXBkYXRlRm9ybURhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcmllOiByZXNvbHZlSW52b2ljZVNlcmllc0ZvclRheENoYW5nZShTdHJpbmcobmV3VmFsdWUpLCBjdXJyZW50RGF0YS5zZXJpZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ25hbWUnLCBsYWJlbDogJ05vbWJyZSBvIFJhesOzbiBTb2NpYWwnLCB0eXBlOiAndGV4dCcsIHBsYWNlaG9sZGVyOiAnRWo6IEVtcHJlc2EgUy5BLicsIG1hbmRhdG9yeTogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAncmV0aWVuaXZhJywgbGFiZWw6ICdSZXRpZW5lIElWQScsIHR5cGU6ICdzZWxlY3QnLCBvcHRpb25zOiBbIC8vIE9wY2lvbmVzIGRlIGVqZW1wbG9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMCcsIGxhYmVsOiAnTm8nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzEnLCBsYWJlbDogJ1NpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogJ2Jvb2xlYW4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtpdGVtLnJldGllbml2YSA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmV0aWVuaXZhID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdsZXlfZXhwb3J0YWNpb25fdGRmJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnQXBsaWNhIExleSBkZSBFeHBvcnRhY2nDs24gVERGJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdzZWxlY3QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICcwJywgbGFiZWw6ICdObycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMScsIGxhYmVsOiAnU2knIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiAnYm9vbGVhbicsXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0ubGV5X2V4cG9ydGFjaW9uX3RkZiA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sZXlfZXhwb3J0YWNpb25fdGRmID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdzZXJpZScsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1NlcmllIGRlIEZhY3R1cmEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3NlbGVjdCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRPcHRpb25zOiAoZmQpID0+IGdldEFsbG93ZWRJbnZvaWNlU2VyaWVzKGZkLnRheCkubWFwKHMgPT4gKHsgdmFsdWU6IHMsIGxhYmVsOiBzIH0pKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRvbmx5OiAoZmQpID0+IGdldEFsbG93ZWRJbnZvaWNlU2VyaWVzKGZkLnRheCkubGVuZ3RoIDw9IDEsXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnNlcmllIHx8ICctJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnc3RhcnRkYXRlJywgbGFiZWw6ICdGZWNoYSBkZSBhbHRhJywgdHlwZTogJ2RhdGUnLCBmb3JtYXQ6ICdkYXRlJyB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY3VycmVuY3lfaWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdNb25lZGEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3JlbGF0aW9uYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbENvbmZpZzogeyBtb2R1bGVDb25maWc6IG1vbmVkYXNNb2R1bGVDb25maWcsIGNvZGVGaWVsZDogJ2N1cnJlbmN5X2NvZGUnLCBuYW1lRmllbGQ6ICdjdXJyZW5jeV9uYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5jdXJyZW5jeV9uYW1lIHx8ICctJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJEYXRvcyBkZSBDb250YWN0b1wiLFxuICAgICAgICAgICAgICAgIGZpZWxkczogW1xuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdhZGRyZXNzJywgbGFiZWw6ICdEb21pY2lsaW8gRmlzY2FsJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ3ppcCcsIGxhYmVsOiAnQ8OzZGlnbyBQb3N0YWwnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnY2l0eScsIGxhYmVsOiAnTG9jYWxpZGFkJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdkaXN0cmljdCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1Byb3ZpbmNpYScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnc2VsZWN0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRPcHRpb25zOiBsb2FkRGlzdHJpY3RzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5kaXN0cmljdF9uYW1lPy50b1N0cmluZygpIHx8ICctJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3Bob25lJywgbGFiZWw6ICdUZWzDqWZvbm8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6ICdFajogMTEtNDQ0NC01NTU1JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW06IENsaWVudGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWl0ZW0ucGhvbmUpIHJldHVybiAnLSc7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMaW1waWFtb3MgZWwgbsO6bWVybyAoc29sbyBkw61naXRvcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGVhblBob25lID0gaXRlbS5waG9uZS5yZXBsYWNlKC9bXjAtOV0vZywgJycpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ucGhvbmV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NsZWFuUGhvbmUubGVuZ3RoID4gNiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vd2EubWUvJHtjbGVhblBob25lfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBob3Zlcjp0ZXh0LWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWJyaXIgY2hhdCBkZSBXaGF0c0FwcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnd2hhdHNhcHAnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdXaGF0c0FwcCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogJ0VqOiArNTQ5MTExMjM0NTY3OCcsXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtOiBDbGllbnRlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpdGVtLndoYXRzYXBwKSByZXR1cm4gJy0nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNsZWFuV2EgPSBpdGVtLndoYXRzYXBwLnJlcGxhY2UoL1teMC05XS9nLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ud2hhdHNhcHB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NsZWFuV2EubGVuZ3RoID4gNiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vd2EubWUvJHtjbGVhbldhfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBob3Zlcjp0ZXh0LWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWJyaXIgY2hhdCBkZSBXaGF0c0FwcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2VtYWlsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnRW1haWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2VtYWlsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93TXVsdGlwbGVFbWFpbHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogJ1VubyBvIHZhcmlvcywgc2VwYXJhZG9zIHBvciBjb21hIG8gZXNwYWNpbycsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2NvbnRhY3QnLCBsYWJlbDogJ1BlcnNvbmEgZGUgQ29udGFjdG8nLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncnVicm8nLCBsYWJlbDogJ1J1YnJvJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdzYWxlc3JlcCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1ZlbmRlZG9yIEFzaWduYWRvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdyZWxhdGlvbmFsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uYWxDb25maWc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVDb25maWc6IHZlbmRlZG9yZXNNb2R1bGVDb25maWcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnc2FsZXNyZXBfY29kZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZUZpZWxkOiAnc2FsZXNyZXBfbmFtZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnNhbGVzcmVwX25hbWU/LnRvU3RyaW5nKCkgfHwgJy0nXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdidXllcl9pZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0NvbXByYWRvcicsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncmVsYXRpb25hbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICByZWxhdGlvbmFsQ29uZmlnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kdWxlQ29uZmlnOiBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlRmllbGQ6ICdidXllcl9jb2RlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICdidXllcl9uYW1lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uYnV5ZXJfbmFtZSB8fCAnLSdcbiAgICAgICAgICAgICAgICAgICAgfSwgLy8gUG9kcsOtYSBzZXIgdW4gJ3NlbGVjdCcgc2kgdGllbmVzIHVuYSBsaXN0YSBkZSB2ZW5kZWRvcmVzXG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIkRhdG9zIGRlIEVudHJlZ2FcIixcbiAgICAgICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3NoaXBhZGRyZXNzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnRG9taWNpbGlvcyBkZSBFbnRyZWdhJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhcnJheS1zdHJpbmcnLCAvLyDinIUgVVNBTU9TIEVMIE5VRVZPIFRJUE9cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyOiAnQ2FsbGUsIE7Dum1lcm8sIExvY2FsaWRhZCdcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3pvbmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdab25hJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdzZWxlY3QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZE9wdGlvbnM6IGxvYWRab25lcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0uem9uZV9uYW1lPy50b1N0cmluZygpIHx8ICctJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3RyYW5zcG9ydF9pZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1RyYW5zcG9ydGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3JlbGF0aW9uYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbENvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZHVsZUNvbmZpZzogdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAndHJhbnNwb3J0X2NvZGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ3RyYW5zcG9ydF9uYW1lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0udHJhbnNwb3J0X25hbWUgfHwgJy0nXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIkRhdG9zIGRlIENvYnJhbnphXCIsXG4gICAgICAgICAgICAgICAgZmllbGRzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ3BheW1lbnRhZGRyZXNzJywgbGFiZWw6ICdEb21pY2lsaW8gZGUgQ29icmFuemEnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudGNpdHknLCBsYWJlbDogJ0xvY2FsaWRhZCBkZSBDb2JyYW56YScsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdwYXltZW50emlwJywgbGFiZWw6ICdDUCBkZSBDb2JyYW56YScsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdwYXltZW50Y29udGFjdCcsIGxhYmVsOiAnQ29udGFjdG8gZGUgQ29icmFuemEnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudHBob25lJywgbGFiZWw6ICdUZWzDqWZvbm8gZGUgQ29icmFuemEnLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudGRheXMnLCBsYWJlbDogJ0TDrWFzIGRlIENvYnJhbnphJywgdHlwZTogJ3RleHQnLCBwbGFjZWhvbGRlcjogJ0VqOiBMdW5lcywgTWnDqXJjb2xlcycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudGhvdXInLCBsYWJlbDogJ0hvcmFyaW8gZGUgQ29icmFuemEnLCB0eXBlOiAndGV4dCcsIHBsYWNlaG9sZGVyOiAnRWo6IDkgYSAxMiBocycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAncGF5bWVudG9icycsIGxhYmVsOiAnT2JzZXJ2YWNpb25lcyBkZSBDb2JyYW56YScsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdwbGF6b3JlYWwnLCBsYWJlbDogJ1BsYXpvIHJlYWwnLCB0eXBlOiAnbnVtYmVyJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdjb2xsZWN0aW9uX2NvbnRhY3QnLCBsYWJlbDogJ0NvbnRhY3RvJywgdHlwZTogJ3RleHQnLCBwbGFjZWhvbGRlcjogJ0NvbnRhY3RvIGRlIGNvYnJhbnphJyB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY29sbGVjdGlvbl9lbWFpbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0VtYWlsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdlbWFpbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGxvd011bHRpcGxlRW1haWxzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6ICdVbm8gbyB2YXJpb3MsIHNlcGFyYWRvcyBwb3IgY29tYSBvIGVzcGFjaW8nLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdjb2xsZWN0aW9uX3Bob25lJywgbGFiZWw6ICdUZWzDqWZvbm8nLCB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnY29sbGVjdGlvbl9wb3J0YWxfdXJsJywgbGFiZWw6ICdVUkwgZGUgcG9ydGFsIGRlIGNvYnJvcycsIHR5cGU6ICd1cmwnLCBwbGFjZWhvbGRlcjogJ2h0dHBzOi8vLi4uJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdjb2xsZWN0aW9uX3BvcnRhbF91c2VybmFtZScsIGxhYmVsOiAnVXN1YXJpbyBkZSBwb3J0YWwgZGUgY29icm9zJywgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2NvbGxlY3Rpb25fcG9ydGFsX3Bhc3N3b3JkJywgbGFiZWw6ICdDbGF2ZSBkZSBwb3J0YWwgZGUgY29icm9zJywgdHlwZTogJ3Bhc3N3b3JkJyB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIk90cm9zIERhdG9zIGRlIENvYnJhbnphXCIsXG4gICAgICAgICAgICAgICAgZmllbGRzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ29ic2VydmF0aW9ucycsIGxhYmVsOiAnT2JzZXJ2YWNpb25lcyBHZW5lcmFsZXMnLCB0eXBlOiAndGV4dCcgfSxcblxuICAgICAgICAgICAgICAgICAgICAvLyAtLS0gR3J1cG86IERvbWljaWxpb3MgLS0tXG5cblxuXG5cblxuXG5cbiAgICAgICAgICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBEYXRvcyBJbXBvc2l0aXZvcyB5IGRlIENyw6lkaXRvIC0tLVxuXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ3BheWRheScsIGxhYmVsOiAnRMOtYXMgZGUgUGFnbycsIHR5cGU6ICdudW1iZXInIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2NyZWRpdCcsIGxhYmVsOiAnTMOtbWl0ZSBkZSBDcsOpZGl0bycsIHR5cGU6ICdudW1iZXInIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2ZyZWV0YXgnLCBsYWJlbDogJ0V4ZW5jacOzbicsIHR5cGU6ICdudW1iZXInIH0sXG5cblxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnZmNlJywgbGFiZWw6ICdBZGhlcmlkbyBhIEZDRScsIHR5cGU6ICdzZWxlY3QnLCBvcHRpb25zOiBbIC8vIE9wY2lvbmVzIGRlIGVqZW1wbG9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMCcsIGxhYmVsOiAnTm8nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzEnLCBsYWJlbDogJ1NpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXRlbS5mY2UgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmZjZSA/ICdTw60nIDogJ05vJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiAnYm9vbGVhbicsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdjYnUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdDQlUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6ICcyMiBkw61naXRvcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXNrOiAnY2J1JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpc2libGVXaGVuOiAoZm9ybURhdGEpID0+IEJvb2xlYW4oZm9ybURhdGEuZmNlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hbmRhdG9yeTogKGZvcm1EYXRhKSA9PiBCb29sZWFuKGZvcm1EYXRhLmZjZSksXG4gICAgICAgICAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgICAgICAgICAgLy8gLS0tIEdydXBvOiBEYXRvcyBkZSBDb2JyYW56YSAtLS1cblxuXG4gICAgICAgICAgICAgICAgICAgIC8vIC0tLSBHcnVwbzogQ29uZmlndXJhY2lvbmVzIEF2YW56YWRhcyAoQmFuZGVyYXMpIC0tLVxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY29uZ2VsY2xpJywgbGFiZWw6ICdDbGllbnRlIENvbmdlbGFkbycsIHR5cGU6ICdzZWxlY3QnLCBvcHRpb25zOiBbIC8vIE9wY2lvbmVzIGRlIGVqZW1wbG9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMCcsIGxhYmVsOiAnTm8nIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzEnLCBsYWJlbDogJ1NpJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXRlbS5jb25nZWxjbGkgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNvbmdlbGNsaSA/ICdTw60nIDogJ05vJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiAnYm9vbGVhbicsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdwcm9zcGVjdCcsIGxhYmVsOiAnRXMgUHJvc3BlY3RvJywgdHlwZTogJ3NlbGVjdCcsIG9wdGlvbnM6IFsgLy8gT3BjaW9uZXMgZGUgZWplbXBsb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICcwJywgbGFiZWw6ICdObycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnMScsIGxhYmVsOiAnU2knIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiAnYm9vbGVhbicsXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0ucHJvc3BlY3QgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb3NwZWN0ID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdwZWRpcml2YScsIGxhYmVsOiAnUGVkaXIgQ29uc3RhbmNpYSBkZSBJVkEnLCB0eXBlOiAnc2VsZWN0Jywgb3B0aW9uczogWyAvLyBPcGNpb25lcyBkZSBlamVtcGxvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJzAnLCBsYWJlbDogJ05vJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICcxJywgbGFiZWw6ICdTaScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2l0ZW0ucGVkaXJpdmEgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnBlZGlyaXZhID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6ICdib29sZWFuJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9LFxuICAgIHJlbGF0aW9uYWxGaWVsZHM6IHtcbiAgICAgICAgaWRGaWVsZDogJ2lkJyxcbiAgICAgICAgY29kZUZpZWxkOiAnY3VzdG9tZXJfY29kZScsIC8vIEVsIGNsaWVudGUgYnVzY2Fyw6EgcG9yIFNLVVxuICAgICAgICBuYW1lRmllbGQ6ICduYW1lJywgLy8gWSBtb3N0cmFyZW1vcyBlbCBub21icmVcbiAgICB9LFxuICAgIGxpc3RJdGVtQ29kZUtleTogJ2N1c3RvbWVyX2NvZGUnLFxuICAgIGxpc3RJdGVtTmFtZUtleTogJ25hbWUnLFxufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NsaWVudGVzL2NsaWVudGVzLmNvbmZpZy50c3gifQ==