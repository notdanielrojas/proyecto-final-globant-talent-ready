import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/pages/ForgotPasswordPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/auth/pages/ForgotPasswordPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { AuthLayout } from "/src/features/auth/components/AuthLayout.tsx";
export const ForgotPasswordPage = () => {
  _s();
  const [email, setEmail] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Solicitando reseteo para el email:", email);
    toast.success("Si existe una cuenta con ese email, recibirás un correo con las instrucciones.");
  };
  return /* @__PURE__ */ jsxDEV(AuthLayout, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-bold text-gray-900", children: "Recuperar Contraseña" }, void 0, false, {
        fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
        lineNumber: 40,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600", children: "Ingresa tu email y te enviaremos un enlace para resetear tu contraseña." }, void 0, false, {
        fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
        lineNumber: 41,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
      lineNumber: 39,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "mt-8 space-y-6", autoComplete: "off", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "email", className: "block text-sm font-medium text-gray-700", children: "Email" }, void 0, false, {
          fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
          lineNumber: 47,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "email",
            type: "email",
            value: email,
            onChange: (e) => setEmail(e.target.value),
            required: true,
            autoComplete: "off",
            className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
            lineNumber: 50,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
        lineNumber: 46,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "w-full px-4 py-2 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
          children: "Solicitar Enlace"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
          lineNumber: 61,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
        lineNumber: 60,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
      lineNumber: 45,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-center", children: /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "font-medium text-indigo-600 hover:text-indigo-500", children: "Volver a Iniciar Sesión" }, void 0, false, {
      fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
      lineNumber: 70,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
      lineNumber: 69,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/auth/pages/ForgotPasswordPage.tsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
};
_s(ForgotPasswordPage, "qu4bovk5U4+JuhY7vxbmswqixrc=");
_c = ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/auth/pages/ForgotPasswordPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/auth/pages/ForgotPasswordPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQmhCLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msa0JBQWtCO0FBRXBCLGFBQU1DLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUCxTQUFTLEVBQUU7QUFFckMsUUFBTVEsZUFBZUEsQ0FBQ0MsTUFBdUI7QUFDekNBLE1BQUVDLGVBQWU7QUFFakJDLFlBQVFDLElBQUksc0NBQXNDTixLQUFLO0FBR3ZESixVQUFNVyxRQUFRLGdGQUFnRjtBQUFBLEVBQ2xHO0FBRUEsU0FDSSx1QkFBQyxjQUNHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGVBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsbUNBQWtDLG9DQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9FO0FBQUEsTUFDcEUsdUJBQUMsT0FBRSxXQUFVLDhCQUE0Qix1RkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLFVBQUssVUFBVUwsY0FBYyxXQUFVLGtCQUFpQixjQUFhLE9BQ2xFO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxTQUFRLFdBQVUsMkNBQXlDLHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxPQUFPRjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ0csTUFBTUYsU0FBU0UsRUFBRUssT0FBT0MsS0FBSztBQUFBLFlBQ3hDO0FBQUEsWUFDQSxjQUFhO0FBQUEsWUFDYixXQUFVO0FBQUE7QUFBQSxVQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9rSjtBQUFBLFdBWHRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQWtLO0FBQUE7QUFBQSxRQUZoTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDWCxpQ0FBQyxRQUFLLElBQUcsVUFBUyxXQUFVLHFEQUFtRCx1Q0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQTtBQUVSO0FBQUVWLEdBbkRXRCxvQkFBa0I7QUFBQVksS0FBbEJaO0FBQWtCLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiTGluayIsInRvYXN0IiwiQXV0aExheW91dCIsIkZvcmdvdFBhc3N3b3JkUGFnZSIsIl9zIiwiZW1haWwiLCJzZXRFbWFpbCIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImNvbnNvbGUiLCJsb2ciLCJzdWNjZXNzIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGb3Jnb3RQYXNzd29yZFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgQXV0aExheW91dCB9IGZyb20gJy4uL2NvbXBvbmVudHMvQXV0aExheW91dCc7XG5cbmV4cG9ydCBjb25zdCBGb3Jnb3RQYXNzd29yZFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgLy8gRW4gdW5hIGFwcCByZWFsLCBhcXXDrSBsbGFtYXLDrWFzIGFsIGVuZHBvaW50IGRlIHR1IEFQSSBwYXJhIGVudmlhciBlbCBjb3JyZW8uXG4gICAgICAgIGNvbnNvbGUubG9nKCdTb2xpY2l0YW5kbyByZXNldGVvIHBhcmEgZWwgZW1haWw6JywgZW1haWwpO1xuXG4gICAgICAgIC8vIEVzIHVuYSBidWVuYSBwcsOhY3RpY2EgZGUgc2VndXJpZGFkIG5vIGNvbmZpcm1hciBzaSBlbCBlbWFpbCBleGlzdGUgbyBuby5cbiAgICAgICAgdG9hc3Quc3VjY2VzcygnU2kgZXhpc3RlIHVuYSBjdWVudGEgY29uIGVzZSBlbWFpbCwgcmVjaWJpcsOhcyB1biBjb3JyZW8gY29uIGxhcyBpbnN0cnVjY2lvbmVzLicpO1xuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8QXV0aExheW91dD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LWNlbnRlcic+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5SZWN1cGVyYXIgQ29udHJhc2XDsWE8L2gxPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0nbXQtMiB0ZXh0LXNtIHRleHQtZ3JheS02MDAnPlxuICAgICAgICAgICAgICAgICAgICBJbmdyZXNhIHR1IGVtYWlsIHkgdGUgZW52aWFyZW1vcyB1biBlbmxhY2UgcGFyYSByZXNldGVhciB0dSBjb250cmFzZcOxYS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cIm10LTggc3BhY2UteS02XCIgYXV0b0NvbXBsZXRlPVwib2ZmXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgRW1haWxcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIHJvdW5kZWQtbWQgaG92ZXI6YmctaW5kaWdvLTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctb2Zmc2V0LTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgU29saWNpdGFyIEVubGFjZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICBWb2x2ZXIgYSBJbmljaWFyIFNlc2nDs25cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9BdXRoTGF5b3V0PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYXV0aC9wYWdlcy9Gb3Jnb3RQYXNzd29yZFBhZ2UudHN4In0=