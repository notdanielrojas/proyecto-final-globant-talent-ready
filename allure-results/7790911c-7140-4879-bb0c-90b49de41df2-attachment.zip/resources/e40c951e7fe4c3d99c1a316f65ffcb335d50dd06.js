import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/RelationalInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/RelationalInput.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { FaSearch, FaTimes } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { applyMask, getMask } from "/src/utils/masks.ts";
import { useDebounce } from "/src/hooks/useDebounce.ts";
import { AutocompleteDropdown } from "/src/components/common/AutocompleteDropdown.tsx";
import { getAll } from "/src/services/apiService.ts";
export const RelationalInput = ({
  codeValue,
  nameValue,
  onCodeChange,
  onCodeSubmit,
  onSearchClick,
  onClearClick,
  disabled,
  hasError,
  mask,
  enableAutocomplete = false,
  autocompleteConfig
}) => {
  _s();
  const [autocompleteItems, setAutocompleteItems] = useState([]);
  const [isAutocompleteOpen, setIsAutocompleteOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);
  const lastSelectedCodeRef = useRef(null);
  const selectionTimestampRef = useRef(0);
  const debouncedCode = useDebounce(codeValue || "", 200);
  useEffect(() => {
    if (!enableAutocomplete || !autocompleteConfig) return;
    const isFocused = document.activeElement === inputRef.current;
    if (!isFocused) {
      return;
    }
    const timeSinceSelection = Date.now() - selectionTimestampRef.current;
    if (lastSelectedCodeRef.current === debouncedCode && timeSinceSelection < 2e3) {
      return;
    }
    if (!debouncedCode || debouncedCode.length < 2) {
      setAutocompleteItems([]);
      setIsAutocompleteOpen(false);
      return;
    }
    let isActive = true;
    const searchProducts = async () => {
      if (document.activeElement !== inputRef.current) {
        return;
      }
      setLoading(true);
      setIsAutocompleteOpen(true);
      try {
        const response = await getAll(autocompleteConfig.endpoint, {
          ...autocompleteConfig.searchParams,
          term: debouncedCode,
          per_page: 10
        });
        if (isActive) {
          if (document.activeElement === inputRef.current) {
            const items = response?.data || [];
            setAutocompleteItems(items);
            setSelectedIndex(-1);
          }
        }
      } catch (error) {
        if (isActive) {
          console.error("Error en autocompletado:", error);
          setAutocompleteItems([]);
        }
      } finally {
        if (isActive) {
          setLoading(false);
        }
      }
    };
    searchProducts();
    return () => {
      isActive = false;
    };
  }, [debouncedCode, enableAutocomplete, autocompleteConfig]);
  const handleKeyDown = (e) => {
    if (enableAutocomplete && isAutocompleteOpen && autocompleteItems.length > 0) {
      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          setSelectedIndex(
            (prev) => prev < autocompleteItems.length - 1 ? prev + 1 : prev
          );
          return;
        case "ArrowUp":
          e.preventDefault();
          setSelectedIndex((prev) => prev > 0 ? prev - 1 : -1);
          return;
        case "Escape":
          e.preventDefault();
          setIsAutocompleteOpen(false);
          return;
        default:
          break;
      }
    }
    if (e.key === "Enter") {
      e.preventDefault();
      if (enableAutocomplete && isAutocompleteOpen && autocompleteItems.length > 0) {
        if (selectedIndex >= 0 && autocompleteItems[selectedIndex]) {
          handleSelectItem(autocompleteItems[selectedIndex]);
          return;
        } else if (autocompleteItems.length > 0) {
          handleSelectItem(autocompleteItems[0]);
          return;
        }
      }
      onCodeSubmit();
    } else if (e.key === "Tab") {
      if (isAutocompleteOpen) {
        setIsAutocompleteOpen(false);
        setAutocompleteItems([]);
      }
      onCodeSubmit();
    }
  };
  const handleCodeChange = (e) => {
    const rawValue = e.target.value;
    const maskedValue = mask ? applyMask(mask, rawValue) : rawValue;
    onCodeChange(maskedValue);
    if (maskedValue.length >= 2 && enableAutocomplete) {
      setIsAutocompleteOpen(true);
    }
  };
  const handleSelectItem = (item) => {
    if (autocompleteConfig) {
      const codeValue2 = item[autocompleteConfig.codeField] || "";
      lastSelectedCodeRef.current = codeValue2;
      selectionTimestampRef.current = Date.now();
      setIsAutocompleteOpen(false);
      setAutocompleteItems([]);
      onCodeChange(codeValue2);
      if (autocompleteConfig.onSelect) {
        autocompleteConfig.onSelect(item);
      }
    }
    inputRef.current?.blur();
  };
  const maskDefinition = mask ? getMask(mask) : void 0;
  const displayValue = codeValue || "";
  const maxLength = maskDefinition?.maxLength;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex w-full space-x-2 mt-1", children: [
    /* @__PURE__ */ jsxDEV("div", { ref: containerRef, className: "relative w-1/3", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          ref: inputRef,
          type: "text",
          value: displayValue,
          onChange: handleCodeChange,
          onKeyDown: handleKeyDown,
          onFocus: () => {
            if (enableAutocomplete && autocompleteItems.length > 0 && debouncedCode.length >= 2) {
              setIsAutocompleteOpen(true);
            }
          },
          placeholder: "Código...",
          autoComplete: "off",
          className: `block w-full px-3 py-2 border rounded-md shadow-sm sm:text-sm ${hasError ? "border-red-500" : "border-gray-300"} focus:ring-indigo-500 focus:border-indigo-500`,
          disabled,
          maxLength
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/RelationalInput.tsx",
          lineNumber: 241,
          columnNumber: 17
        },
        this
      ),
      enableAutocomplete && autocompleteConfig && isAutocompleteOpen && autocompleteItems.length > 0 && /* @__PURE__ */ jsxDEV(
        AutocompleteDropdown,
        {
          items: autocompleteItems,
          isOpen: isAutocompleteOpen,
          onSelect: handleSelectItem,
          onClose: () => {
            setIsAutocompleteOpen(false);
            setAutocompleteItems([]);
          },
          renderItem: (item) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "font-medium", children: item[autocompleteConfig.codeField] }, void 0, false, {
              fileName: "/app/src/components/common/RelationalInput.tsx",
              lineNumber: 269,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: item[autocompleteConfig.nameField] }, void 0, false, {
              fileName: "/app/src/components/common/RelationalInput.tsx",
              lineNumber: 270,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/RelationalInput.tsx",
            lineNumber: 268,
            columnNumber: 11
          }, this),
          selectedIndex,
          loading,
          emptyMessage: "No se encontraron productos",
          triggerElement: inputRef.current
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/RelationalInput.tsx",
          lineNumber: 259,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/RelationalInput.tsx",
      lineNumber: 240,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex-1", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: nameValue || "",
          readOnly: true,
          placeholder: "Nombre...",
          autoComplete: "off",
          className: "block w-full px-3 py-2 pr-20 bg-gray-100 border border-gray-300 rounded-md shadow-sm sm:text-sm",
          disabled
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/RelationalInput.tsx",
          lineNumber: 282,
          columnNumber: 17
        },
        this
      ),
      (codeValue || nameValue) && !disabled && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: (e) => {
            e.stopPropagation();
            onClearClick();
            setIsAutocompleteOpen(false);
          },
          className: "absolute inset-y-0 right-10 p-1 text-gray-400 rounded-full hover:text-gray-600",
          "aria-label": "Limpiar",
          children: /* @__PURE__ */ jsxDEV(FaTimes, {}, void 0, false, {
            fileName: "/app/src/components/common/RelationalInput.tsx",
            lineNumber: 303,
            columnNumber: 25
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/RelationalInput.tsx",
          lineNumber: 293,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onSearchClick,
          disabled,
          className: "absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 border-l border-gray-300 hover:text-indigo-600",
          "aria-label": "Buscar",
          children: /* @__PURE__ */ jsxDEV(FaSearch, {}, void 0, false, {
            fileName: "/app/src/components/common/RelationalInput.tsx",
            lineNumber: 314,
            columnNumber: 21
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/RelationalInput.tsx",
          lineNumber: 307,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/RelationalInput.tsx",
      lineNumber: 281,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/RelationalInput.tsx",
    lineNumber: 238,
    columnNumber: 5
  }, this);
};
_s(RelationalInput, "kmsDf9qbbYWr614AadtK/ifJjZc=", false, function() {
  return [useDebounce];
});
_c = RelationalInput;
var _c;
$RefreshReg$(_c, "RelationalInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/RelationalInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/RelationalInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNk5nQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1TmhCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsVUFBVUMsZUFBZTtBQUNsQyxTQUFTQyxXQUFXQyxlQUFlO0FBQ25DLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsY0FBYztBQXdCaEIsYUFBTUMsa0JBQWtCQSxDQUFDO0FBQUEsRUFDNUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLHFCQUFxQjtBQUFBLEVBQ3JCQztBQUNrQixNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJeEIsU0FBZ0IsRUFBRTtBQUNwRSxRQUFNLENBQUN5QixvQkFBb0JDLHFCQUFxQixJQUFJMUIsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZCLFNBQVNDLFVBQVUsSUFBSTlCLFNBQVMsS0FBSztBQUM1QyxRQUFNK0IsV0FBVzdCLE9BQXlCLElBQUk7QUFDOUMsUUFBTThCLGVBQWU5QixPQUF1QixJQUFJO0FBQ2hELFFBQU0rQixzQkFBc0IvQixPQUFzQixJQUFJO0FBQ3RELFFBQU1nQyx3QkFBd0JoQyxPQUFlLENBQUM7QUFHOUMsUUFBTWlDLGdCQUFnQjVCLFlBQVlJLGFBQWEsSUFBSSxHQUFHO0FBR3REVixZQUFVLE1BQU07QUFDWixRQUFJLENBQUNtQixzQkFBc0IsQ0FBQ0MsbUJBQW9CO0FBR2hELFVBQU1lLFlBQVlDLFNBQVNDLGtCQUFrQlAsU0FBU1E7QUFDdEQsUUFBSSxDQUFDSCxXQUFXO0FBQ1o7QUFBQSxJQUNKO0FBR0EsVUFBTUkscUJBQXFCQyxLQUFLQyxJQUFJLElBQUlSLHNCQUFzQks7QUFDOUQsUUFBSU4sb0JBQW9CTSxZQUFZSixpQkFBaUJLLHFCQUFxQixLQUFNO0FBQzVFO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ0wsaUJBQWlCQSxjQUFjUSxTQUFTLEdBQUc7QUFDNUNuQiwyQkFBcUIsRUFBRTtBQUN2QkUsNEJBQXNCLEtBQUs7QUFDM0I7QUFBQSxJQUNKO0FBR0EsUUFBSWtCLFdBQVc7QUFFZixVQUFNQyxpQkFBaUIsWUFBWTtBQUUvQixVQUFJUixTQUFTQyxrQkFBa0JQLFNBQVNRLFNBQVM7QUFDN0M7QUFBQSxNQUNKO0FBRUFULGlCQUFXLElBQUk7QUFDZkosNEJBQXNCLElBQUk7QUFDMUIsVUFBSTtBQUVBLGNBQU1vQixXQUFXLE1BQU1yQyxPQUFZWSxtQkFBbUIwQixVQUFVO0FBQUEsVUFDNUQsR0FBRzFCLG1CQUFtQjJCO0FBQUFBLFVBQ3RCQyxNQUFNZDtBQUFBQSxVQUNOZSxVQUFVO0FBQUEsUUFDZCxDQUFDO0FBR0QsWUFBSU4sVUFBVTtBQUVWLGNBQUlQLFNBQVNDLGtCQUFrQlAsU0FBU1EsU0FBUztBQUM3QyxrQkFBTVksUUFBUUwsVUFBVU0sUUFBUTtBQUNoQzVCLGlDQUFxQjJCLEtBQUs7QUFDMUJ2Qiw2QkFBaUIsRUFBRTtBQUFBLFVBQ3ZCO0FBQUEsUUFDSjtBQUFBLE1BQ0osU0FBU3lCLE9BQU87QUFDWixZQUFJVCxVQUFVO0FBQ1ZVLGtCQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQzdCLCtCQUFxQixFQUFFO0FBQUEsUUFDM0I7QUFBQSxNQUNKLFVBQUM7QUFDRyxZQUFJb0IsVUFBVTtBQUNWZCxxQkFBVyxLQUFLO0FBQUEsUUFDcEI7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUVBZSxtQkFBZTtBQUVmLFdBQU8sTUFBTTtBQUNURCxpQkFBVztBQUFBLElBQ2Y7QUFBQSxFQUNKLEdBQUcsQ0FBQ1QsZUFBZWYsb0JBQW9CQyxrQkFBa0IsQ0FBQztBQUUxRCxRQUFNa0MsZ0JBQWdCQSxDQUFDQyxNQUEyQjtBQUU5QyxRQUFJcEMsc0JBQXNCSyxzQkFBc0JGLGtCQUFrQm9CLFNBQVMsR0FBRztBQUMxRSxjQUFRYSxFQUFFQyxLQUFHO0FBQUEsUUFDVCxLQUFLO0FBQ0RELFlBQUVFLGVBQWU7QUFDakI5QjtBQUFBQSxZQUFpQixDQUFBK0IsU0FDYkEsT0FBT3BDLGtCQUFrQm9CLFNBQVMsSUFBSWdCLE9BQU8sSUFBSUE7QUFBQUEsVUFDckQ7QUFDQTtBQUFBLFFBQ0osS0FBSztBQUNESCxZQUFFRSxlQUFlO0FBQ2pCOUIsMkJBQWlCLENBQUErQixTQUFRQSxPQUFPLElBQUlBLE9BQU8sSUFBSSxFQUFFO0FBQ2pEO0FBQUEsUUFDSixLQUFLO0FBQ0RILFlBQUVFLGVBQWU7QUFDakJoQyxnQ0FBc0IsS0FBSztBQUMzQjtBQUFBLFFBQ0o7QUFDSTtBQUFBLE1BQ1I7QUFBQSxJQUNKO0FBR0EsUUFBSThCLEVBQUVDLFFBQVEsU0FBUztBQUNuQkQsUUFBRUUsZUFBZTtBQUVqQixVQUFJdEMsc0JBQXNCSyxzQkFBc0JGLGtCQUFrQm9CLFNBQVMsR0FBRztBQUMxRSxZQUFJaEIsaUJBQWlCLEtBQUtKLGtCQUFrQkksYUFBYSxHQUFHO0FBQ3hEaUMsMkJBQWlCckMsa0JBQWtCSSxhQUFhLENBQUM7QUFFakQ7QUFBQSxRQUNKLFdBQVdKLGtCQUFrQm9CLFNBQVMsR0FBRztBQUVyQ2lCLDJCQUFpQnJDLGtCQUFrQixDQUFDLENBQUM7QUFFckM7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUVBVCxtQkFBYTtBQUFBLElBQ2pCLFdBQVcwQyxFQUFFQyxRQUFRLE9BQU87QUFFeEIsVUFBSWhDLG9CQUFvQjtBQUNwQkMsOEJBQXNCLEtBQUs7QUFDM0JGLDZCQUFxQixFQUFFO0FBQUEsTUFDM0I7QUFFQVYsbUJBQWE7QUFBQSxJQUVqQjtBQUFBLEVBQ0o7QUFFQSxRQUFNK0MsbUJBQW1CQSxDQUFDTCxNQUEyQztBQUNqRSxVQUFNTSxXQUFXTixFQUFFTyxPQUFPQztBQUUxQixVQUFNQyxjQUFjOUMsT0FBT2QsVUFBVWMsTUFBTTJDLFFBQVEsSUFBSUE7QUFDdkRqRCxpQkFBYW9ELFdBQVc7QUFHeEIsUUFBSUEsWUFBWXRCLFVBQVUsS0FBS3ZCLG9CQUFvQjtBQUMvQ00sNEJBQXNCLElBQUk7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFFQSxRQUFNa0MsbUJBQW1CQSxDQUFDTSxTQUFjO0FBQ3BDLFFBQUk3QyxvQkFBb0I7QUFDcEIsWUFBTVYsYUFBWXVELEtBQUs3QyxtQkFBbUI4QyxTQUFTLEtBQUs7QUFHeERsQywwQkFBb0JNLFVBQVU1QjtBQUM5QnVCLDRCQUFzQkssVUFBVUUsS0FBS0MsSUFBSTtBQUd6Q2hCLDRCQUFzQixLQUFLO0FBQzNCRiwyQkFBcUIsRUFBRTtBQUd2QlgsbUJBQWFGLFVBQVM7QUFHdEIsVUFBSVUsbUJBQW1CK0MsVUFBVTtBQUM3Qi9DLDJCQUFtQitDLFNBQVNGLElBQUk7QUFBQSxNQUNwQztBQUFBLElBQ0o7QUFFQW5DLGFBQVNRLFNBQVM4QixLQUFLO0FBQUEsRUFDM0I7QUFFQSxRQUFNQyxpQkFBaUJuRCxPQUFPYixRQUFRYSxJQUFJLElBQUlvRDtBQUM5QyxRQUFNQyxlQUFlN0QsYUFBYTtBQUNsQyxRQUFNOEQsWUFBWUgsZ0JBQWdCRztBQUVsQyxTQUNJLHVCQUFDLFNBQUksV0FBVSw4QkFFWDtBQUFBLDJCQUFDLFNBQUksS0FBS3pDLGNBQWMsV0FBVSxrQkFDOUI7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csS0FBS0Q7QUFBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxPQUFPeUM7QUFBQUEsVUFDUCxVQUFVWDtBQUFBQSxVQUNWLFdBQVdOO0FBQUFBLFVBQ1gsU0FBUyxNQUFNO0FBQ1gsZ0JBQUluQyxzQkFBc0JHLGtCQUFrQm9CLFNBQVMsS0FBS1IsY0FBY1EsVUFBVSxHQUFHO0FBQ2pGakIsb0NBQXNCLElBQUk7QUFBQSxZQUM5QjtBQUFBLFVBQ0o7QUFBQSxVQUNBLGFBQVk7QUFBQSxVQUNaLGNBQWE7QUFBQSxVQUNiLFdBQVcsaUVBQWlFUixXQUFXLG1CQUFtQixpQkFBaUI7QUFBQSxVQUMzSDtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZXlCO0FBQUEsTUFFeEJFLHNCQUFzQkMsc0JBQXNCSSxzQkFBc0JGLGtCQUFrQm9CLFNBQVMsS0FDMUY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE9BQU9wQjtBQUFBQSxVQUNQLFFBQVFFO0FBQUFBLFVBQ1IsVUFBVW1DO0FBQUFBLFVBQ1YsU0FBUyxNQUFNO0FBQ1hsQyxrQ0FBc0IsS0FBSztBQUMzQkYsaUNBQXFCLEVBQUU7QUFBQSxVQUMzQjtBQUFBLFVBQ0EsWUFBWSxDQUFDMEMsU0FDVCx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGVBQWVBLGVBQUs3QyxtQkFBbUI4QyxTQUFTLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFO0FBQUEsWUFDakUsdUJBQUMsU0FBSSxXQUFVLHlCQUF5QkQsZUFBSzdDLG1CQUFtQnFELFNBQVMsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxlQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFSjtBQUFBLFVBQ0E7QUFBQSxVQUNBLGNBQWE7QUFBQSxVQUNiLGdCQUFnQjNDLFNBQVNRO0FBQUFBO0FBQUFBLFFBakI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFpQnFDO0FBQUEsU0FwQzdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxPQUFPM0IsYUFBYTtBQUFBLFVBQ3BCO0FBQUEsVUFDQSxhQUFZO0FBQUEsVUFDWixjQUFhO0FBQUEsVUFDYixXQUFVO0FBQUEsVUFDVjtBQUFBO0FBQUEsUUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPdUI7QUFBQSxPQUdyQkQsYUFBYUMsY0FBYyxDQUFDSyxZQUMxQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBUyxDQUFDdUMsTUFBTTtBQUNaQSxjQUFFbUIsZ0JBQWdCO0FBQ2xCM0QseUJBQWE7QUFDYlUsa0NBQXNCLEtBQUs7QUFBQSxVQUMvQjtBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBQ1YsY0FBVztBQUFBLFVBRVgsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRO0FBQUE7QUFBQSxRQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFHSjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBU1g7QUFBQUEsVUFDVDtBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBQ1YsY0FBVztBQUFBLFVBRVgsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFTO0FBQUE7QUFBQSxRQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0FsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLE9BOUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFUjtBQUFFTyxHQTdRV1osaUJBQWU7QUFBQSxVQXVCRkgsV0FBVztBQUFBO0FBQUFxRSxLQXZCeEJsRTtBQUFlLElBQUFrRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJGYVNlYXJjaCIsIkZhVGltZXMiLCJhcHBseU1hc2siLCJnZXRNYXNrIiwidXNlRGVib3VuY2UiLCJBdXRvY29tcGxldGVEcm9wZG93biIsImdldEFsbCIsIlJlbGF0aW9uYWxJbnB1dCIsImNvZGVWYWx1ZSIsIm5hbWVWYWx1ZSIsIm9uQ29kZUNoYW5nZSIsIm9uQ29kZVN1Ym1pdCIsIm9uU2VhcmNoQ2xpY2siLCJvbkNsZWFyQ2xpY2siLCJkaXNhYmxlZCIsImhhc0Vycm9yIiwibWFzayIsImVuYWJsZUF1dG9jb21wbGV0ZSIsImF1dG9jb21wbGV0ZUNvbmZpZyIsIl9zIiwiYXV0b2NvbXBsZXRlSXRlbXMiLCJzZXRBdXRvY29tcGxldGVJdGVtcyIsImlzQXV0b2NvbXBsZXRlT3BlbiIsInNldElzQXV0b2NvbXBsZXRlT3BlbiIsInNlbGVjdGVkSW5kZXgiLCJzZXRTZWxlY3RlZEluZGV4IiwibG9hZGluZyIsInNldExvYWRpbmciLCJpbnB1dFJlZiIsImNvbnRhaW5lclJlZiIsImxhc3RTZWxlY3RlZENvZGVSZWYiLCJzZWxlY3Rpb25UaW1lc3RhbXBSZWYiLCJkZWJvdW5jZWRDb2RlIiwiaXNGb2N1c2VkIiwiZG9jdW1lbnQiLCJhY3RpdmVFbGVtZW50IiwiY3VycmVudCIsInRpbWVTaW5jZVNlbGVjdGlvbiIsIkRhdGUiLCJub3ciLCJsZW5ndGgiLCJpc0FjdGl2ZSIsInNlYXJjaFByb2R1Y3RzIiwicmVzcG9uc2UiLCJlbmRwb2ludCIsInNlYXJjaFBhcmFtcyIsInRlcm0iLCJwZXJfcGFnZSIsIml0ZW1zIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImhhbmRsZUtleURvd24iLCJlIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJwcmV2IiwiaGFuZGxlU2VsZWN0SXRlbSIsImhhbmRsZUNvZGVDaGFuZ2UiLCJyYXdWYWx1ZSIsInRhcmdldCIsInZhbHVlIiwibWFza2VkVmFsdWUiLCJpdGVtIiwiY29kZUZpZWxkIiwib25TZWxlY3QiLCJibHVyIiwibWFza0RlZmluaXRpb24iLCJ1bmRlZmluZWQiLCJkaXNwbGF5VmFsdWUiLCJtYXhMZW5ndGgiLCJuYW1lRmllbGQiLCJzdG9wUHJvcGFnYXRpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWxhdGlvbmFsSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9jb21wb25lbnRzL2NvbW1vbi9SZWxhdGlvbmFsSW5wdXQudHN4XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGYVNlYXJjaCwgRmFUaW1lcyB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGFwcGx5TWFzaywgZ2V0TWFzayB9IGZyb20gJy4uLy4uL3V0aWxzL21hc2tzJztcbmltcG9ydCB7IHVzZURlYm91bmNlIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlRGVib3VuY2UnO1xuaW1wb3J0IHsgQXV0b2NvbXBsZXRlRHJvcGRvd24gfSBmcm9tICcuL0F1dG9jb21wbGV0ZURyb3Bkb3duJztcbmltcG9ydCB7IGdldEFsbCB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHR5cGUgeyBTZWFyY2hQYXJhbXMgfSBmcm9tICcuL0dlbmVyaWNMaXN0UGFnZSc7XG5cbmludGVyZmFjZSBSZWxhdGlvbmFsSW5wdXRQcm9wcyB7XG4gICAgY29kZVZhbHVlOiBzdHJpbmcgfCBudWxsOyAvLyDinIUgUkVOT01CUkFETzogRWwgdmFsb3IgZGVsIGPDs2RpZ28gKGVqOiAnUDEwMDEnKVxuICAgIG5hbWVWYWx1ZTogc3RyaW5nIHwgbnVsbDsgLy8g4pyFIE5VRVZPOiBFbCB2YWxvciBkZWwgbm9tYnJlIChlajogJ0FydMOtY3VsbyBBJylcbiAgICBvbkNvZGVDaGFuZ2U6IChuZXdDb2RlOiBzdHJpbmcpID0+IHZvaWQ7IC8vIOKchSBOVUVWTzogUGFyYSBhY3R1YWxpemFyIGVsIGlucHV0XG4gICAgb25Db2RlU3VibWl0OiAoKSA9PiB2b2lkOyAvLyDinIUgTlVFVk86IFBhcmEgZWwgJ0VudGVyJyBrZXlcbiAgICBvblNlYXJjaENsaWNrOiAoKSA9PiB2b2lkO1xuICAgIG9uQ2xlYXJDbGljazogKCkgPT4gdm9pZDtcbiAgICBkaXNhYmxlZD86IGJvb2xlYW47XG4gICAgaGFzRXJyb3I/OiBib29sZWFuO1xuICAgIG1hc2s/OiBzdHJpbmc7IC8vIOKchSBOVUVWTzogTm9tYnJlIGRlIGxhIG3DoXNjYXJhIGEgYXBsaWNhclxuICAgIC8vIOKchSBOVUVWQVMgUFJPUFMgcGFyYSBhdXRvY29tcGxldGFkb1xuICAgIGVuYWJsZUF1dG9jb21wbGV0ZT86IGJvb2xlYW47XG4gICAgYXV0b2NvbXBsZXRlQ29uZmlnPzoge1xuICAgICAgICBlbmRwb2ludDogc3RyaW5nO1xuICAgICAgICBjb2RlRmllbGQ6IHN0cmluZztcbiAgICAgICAgbmFtZUZpZWxkOiBzdHJpbmc7XG4gICAgICAgIHNlYXJjaFBhcmFtcz86IFBhcnRpYWw8U2VhcmNoUGFyYW1zPjtcbiAgICAgICAgb25TZWxlY3Q/OiAoaXRlbTogYW55KSA9PiB2b2lkO1xuICAgIH07XG59XG5cbmV4cG9ydCBjb25zdCBSZWxhdGlvbmFsSW5wdXQgPSAoe1xuICAgIGNvZGVWYWx1ZSxcbiAgICBuYW1lVmFsdWUsXG4gICAgb25Db2RlQ2hhbmdlLFxuICAgIG9uQ29kZVN1Ym1pdCxcbiAgICBvblNlYXJjaENsaWNrLFxuICAgIG9uQ2xlYXJDbGljayxcbiAgICBkaXNhYmxlZCxcbiAgICBoYXNFcnJvcixcbiAgICBtYXNrLFxuICAgIGVuYWJsZUF1dG9jb21wbGV0ZSA9IGZhbHNlLFxuICAgIGF1dG9jb21wbGV0ZUNvbmZpZ1xufTogUmVsYXRpb25hbElucHV0UHJvcHMpID0+IHtcbiAgICBjb25zdCBbYXV0b2NvbXBsZXRlSXRlbXMsIHNldEF1dG9jb21wbGV0ZUl0ZW1zXSA9IHVzZVN0YXRlPGFueVtdPihbXSk7XG4gICAgY29uc3QgW2lzQXV0b2NvbXBsZXRlT3Blbiwgc2V0SXNBdXRvY29tcGxldGVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbc2VsZWN0ZWRJbmRleCwgc2V0U2VsZWN0ZWRJbmRleF0gPSB1c2VTdGF0ZSgtMSk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgbGFzdFNlbGVjdGVkQ29kZVJlZiA9IHVzZVJlZjxzdHJpbmcgfCBudWxsPihudWxsKTsgLy8g4pyFIEd1YXJkYXIgZWwgY8OzZGlnbyBxdWUgYWNhYmFtb3MgZGUgc2VsZWNjaW9uYXJcbiAgICBjb25zdCBzZWxlY3Rpb25UaW1lc3RhbXBSZWYgPSB1c2VSZWY8bnVtYmVyPigwKTsgLy8g4pyFIFRpbWVzdGFtcCBkZSBsYSDDumx0aW1hIHNlbGVjY2nDs25cblxuICAgIC8vIERlYm91bmNlIGRlbCB2YWxvciBwYXJhIGLDunNxdWVkYVxuICAgIGNvbnN0IGRlYm91bmNlZENvZGUgPSB1c2VEZWJvdW5jZShjb2RlVmFsdWUgfHwgJycsIDIwMCk7XG5cbiAgICAvLyBCw7pzcXVlZGEgYXV0b23DoXRpY2EgY3VhbmRvIGNhbWJpYSBlbCBjw7NkaWdvIChjb24gZGVib3VuY2UpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFlbmFibGVBdXRvY29tcGxldGUgfHwgIWF1dG9jb21wbGV0ZUNvbmZpZykgcmV0dXJuO1xuXG4gICAgICAgIC8vIOKchSBTb2xvIGJ1c2NhciBzaSBlc3RlIGlucHV0IGVzdMOhIGVuZm9jYWRvIChwYXJhIGV2aXRhciBiw7pzcXVlZGFzIGVuIG90cm9zIGlucHV0cyBkZSBsYSB0YWJsYSlcbiAgICAgICAgY29uc3QgaXNGb2N1c2VkID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gaW5wdXRSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFpc0ZvY3VzZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOKchSBTaSBlbCBjw7NkaWdvIGNvaW5jaWRlIGV4YWN0YW1lbnRlIGNvbiBlbCBxdWUgYWNhYmFtb3MgZGUgc2VsZWNjaW9uYXIgKGVuIGxvcyDDumx0aW1vcyAyIHNlZ3VuZG9zKSwgbm8gYnVzY2FyXG4gICAgICAgIGNvbnN0IHRpbWVTaW5jZVNlbGVjdGlvbiA9IERhdGUubm93KCkgLSBzZWxlY3Rpb25UaW1lc3RhbXBSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKGxhc3RTZWxlY3RlZENvZGVSZWYuY3VycmVudCA9PT0gZGVib3VuY2VkQ29kZSAmJiB0aW1lU2luY2VTZWxlY3Rpb24gPCAyMDAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIWRlYm91bmNlZENvZGUgfHwgZGVib3VuY2VkQ29kZS5sZW5ndGggPCAyKSB7XG4gICAgICAgICAgICBzZXRBdXRvY29tcGxldGVJdGVtcyhbXSk7XG4gICAgICAgICAgICBzZXRJc0F1dG9jb21wbGV0ZU9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g4pyFIEZsYWcgcGFyYSBjYW5jZWxhciBsYSBhY3R1YWxpemFjacOzbiBzaSBlbCBlZmVjdG8gc2UgZGVzbW9udGEgKHVzdWFyaW8gc2lndWUgZXNjcmliaWVuZG8pXG4gICAgICAgIGxldCBpc0FjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgY29uc3Qgc2VhcmNoUHJvZHVjdHMgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAvLyDinIUgVmVyaWZpY2FyIG51ZXZhbWVudGUgcXVlIGVsIGlucHV0IHNpZ3VlIGVuZm9jYWRvIGFudGVzIGRlIGJ1c2NhclxuICAgICAgICAgICAgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgIT09IGlucHV0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICBzZXRJc0F1dG9jb21wbGV0ZU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIOKchSBVc2FyIGdldEFsbCBjb24gYsO6c3F1ZWRhIHBhcmNpYWwgKGlndWFsIHF1ZSBlbCBtb2RhbClcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldEFsbDxhbnk+KGF1dG9jb21wbGV0ZUNvbmZpZy5lbmRwb2ludCwge1xuICAgICAgICAgICAgICAgICAgICAuLi5hdXRvY29tcGxldGVDb25maWcuc2VhcmNoUGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB0ZXJtOiBkZWJvdW5jZWRDb2RlLFxuICAgICAgICAgICAgICAgICAgICBwZXJfcGFnZTogMTBcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIC8vIOKchSBTb2xvIGFjdHVhbGl6YXIgZXN0YWRvIHNpIGVsIGNvbXBvbmVudGUgc2lndWUgbW9udGFkbyB5IGVzIGxhIHBldGljacOzbiBtw6FzIHJlY2llbnRlXG4gICAgICAgICAgICAgICAgaWYgKGlzQWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOKchSBWZXJpZmljYXIgdW5hIHZleiBtw6FzIHF1ZSBlbCBpbnB1dCBzaWd1ZSBlbmZvY2FkbyBhbnRlcyBkZSBhY3R1YWxpemFyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50ID09PSBpbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtcyA9IHJlc3BvbnNlPy5kYXRhIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXV0b2NvbXBsZXRlSXRlbXMoaXRlbXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJbmRleCgtMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGlmIChpc0FjdGl2ZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBlbiBhdXRvY29tcGxldGFkbzonLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIHNldEF1dG9jb21wbGV0ZUl0ZW1zKFtdKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIGlmIChpc0FjdGl2ZSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgc2VhcmNoUHJvZHVjdHMoKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaXNBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfTtcbiAgICB9LCBbZGVib3VuY2VkQ29kZSwgZW5hYmxlQXV0b2NvbXBsZXRlLCBhdXRvY29tcGxldGVDb25maWddKTtcblxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgICAvLyBTaSBlbCBhdXRvY29tcGxldGFkbyBlc3TDoSBhY3Rpdm8geSBoYXkgaXRlbXMgdmlzaWJsZXMsIG1hbmVqYXIgbmF2ZWdhY2nDs24gY29uIGZsZWNoYXNcbiAgICAgICAgaWYgKGVuYWJsZUF1dG9jb21wbGV0ZSAmJiBpc0F1dG9jb21wbGV0ZU9wZW4gJiYgYXV0b2NvbXBsZXRlSXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgc3dpdGNoIChlLmtleSkge1xuICAgICAgICAgICAgICAgIGNhc2UgJ0Fycm93RG93bic6XG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJbmRleChwcmV2ID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBwcmV2IDwgYXV0b2NvbXBsZXRlSXRlbXMubGVuZ3RoIC0gMSA/IHByZXYgKyAxIDogcHJldlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgY2FzZSAnQXJyb3dVcCc6XG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJbmRleChwcmV2ID0+IHByZXYgPiAwID8gcHJldiAtIDEgOiAtMSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICBjYXNlICdFc2NhcGUnOlxuICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQXV0b2NvbXBsZXRlT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOKchSBFbnRlciBlamVjdXRhIGxhIGLDunNxdWVkYVxuICAgICAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIC8vIFNpIGhheSBkcm9wZG93biBhYmllcnRvIGNvbiBpdGVtcywgc2VsZWNjaW9uYXIgaXRlbSBwZXJvIE5PIGVqZWN1dGFyIGLDunNxdWVkYSBhZGljaW9uYWxcbiAgICAgICAgICAgIGlmIChlbmFibGVBdXRvY29tcGxldGUgJiYgaXNBdXRvY29tcGxldGVPcGVuICYmIGF1dG9jb21wbGV0ZUl0ZW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRJbmRleCA+PSAwICYmIGF1dG9jb21wbGV0ZUl0ZW1zW3NlbGVjdGVkSW5kZXhdKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVNlbGVjdEl0ZW0oYXV0b2NvbXBsZXRlSXRlbXNbc2VsZWN0ZWRJbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAvLyDinIUgTk8gZWplY3V0YXIgb25Db2RlU3VibWl0KCkgY3VhbmRvIHNlIHNlbGVjY2lvbmEgZGVzZGUgZWwgZHJvcGRvd25cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoYXV0b2NvbXBsZXRlSXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBTaSBubyBoYXkgc2VsZWNjacOzbiBwZXJvIGhheSByZXN1bHRhZG9zLCBzZWxlY2Npb25hciBlbCBwcmltZXJvXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVNlbGVjdEl0ZW0oYXV0b2NvbXBsZXRlSXRlbXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICAvLyDinIUgTk8gZWplY3V0YXIgb25Db2RlU3VibWl0KCkgY3VhbmRvIHNlIHNlbGVjY2lvbmEgZGVzZGUgZWwgZHJvcGRvd25cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFNvbG8gZWplY3V0YXIgbGEgYsO6c3F1ZWRhIHNpIE5PIHNlIHNlbGVjY2lvbsOzIG5pbmfDum4gaXRlbSBkZWwgZHJvcGRvd25cbiAgICAgICAgICAgIG9uQ29kZVN1Ym1pdCgpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnVGFiJykge1xuICAgICAgICAgICAgLy8g4pyFIFRhYiBjaWVycmEgZWwgZHJvcGRvd24sIGVqZWN1dGEgYsO6c3F1ZWRhIHkgYXZhbnphXG4gICAgICAgICAgICBpZiAoaXNBdXRvY29tcGxldGVPcGVuKSB7XG4gICAgICAgICAgICAgICAgc2V0SXNBdXRvY29tcGxldGVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBzZXRBdXRvY29tcGxldGVJdGVtcyhbXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBFamVjdXRhciBiw7pzcXVlZGEgYW50ZXMgZGUgYXZhbnphclxuICAgICAgICAgICAgb25Db2RlU3VibWl0KCk7XG4gICAgICAgICAgICAvLyBObyBwcmV2ZW5pciBlbCBjb21wb3J0YW1pZW50byBwb3IgZGVmZWN0byBwYXJhIHF1ZSBUYWIgYXZhbmNlIGFsIHNpZ3VpZW50ZSBjYW1wb1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNvZGVDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICAgICAgY29uc3QgcmF3VmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgLy8g4pyFIEFwbGljYXIgbcOhc2NhcmEgc2kgZXN0w6EgY29uZmlndXJhZGFcbiAgICAgICAgY29uc3QgbWFza2VkVmFsdWUgPSBtYXNrID8gYXBwbHlNYXNrKG1hc2ssIHJhd1ZhbHVlKSA6IHJhd1ZhbHVlO1xuICAgICAgICBvbkNvZGVDaGFuZ2UobWFza2VkVmFsdWUpO1xuXG4gICAgICAgIC8vIEFicmlyIGRyb3Bkb3duIHNpIGhheSB0ZXh0byBzdWZpY2llbnRlXG4gICAgICAgIGlmIChtYXNrZWRWYWx1ZS5sZW5ndGggPj0gMiAmJiBlbmFibGVBdXRvY29tcGxldGUpIHtcbiAgICAgICAgICAgIHNldElzQXV0b2NvbXBsZXRlT3Blbih0cnVlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RJdGVtID0gKGl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoYXV0b2NvbXBsZXRlQ29uZmlnKSB7XG4gICAgICAgICAgICBjb25zdCBjb2RlVmFsdWUgPSBpdGVtW2F1dG9jb21wbGV0ZUNvbmZpZy5jb2RlRmllbGRdIHx8ICcnO1xuXG4gICAgICAgICAgICAvLyDinIUgR3VhcmRhciBlbCBjw7NkaWdvIHNlbGVjY2lvbmFkbyB5IGVsIHRpbWVzdGFtcCBwYXJhIGV2aXRhciBiw7pzcXVlZGFcbiAgICAgICAgICAgIGxhc3RTZWxlY3RlZENvZGVSZWYuY3VycmVudCA9IGNvZGVWYWx1ZTtcbiAgICAgICAgICAgIHNlbGVjdGlvblRpbWVzdGFtcFJlZi5jdXJyZW50ID0gRGF0ZS5ub3coKTtcblxuICAgICAgICAgICAgLy8g4pyFIENlcnJhciBpbm1lZGlhdGFtZW50ZSBhbnRlcyBkZSBjdWFscXVpZXIgb3RyYSBhY2Npw7NuXG4gICAgICAgICAgICBzZXRJc0F1dG9jb21wbGV0ZU9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgc2V0QXV0b2NvbXBsZXRlSXRlbXMoW10pO1xuXG4gICAgICAgICAgICAvLyBBY3R1YWxpemFyIGVsIGPDs2RpZ29cbiAgICAgICAgICAgIG9uQ29kZUNoYW5nZShjb2RlVmFsdWUpO1xuXG4gICAgICAgICAgICAvLyBTaSBoYXkgY2FsbGJhY2sgcGVyc29uYWxpemFkbywgbG8gbGxhbWFtb3NcbiAgICAgICAgICAgIGlmIChhdXRvY29tcGxldGVDb25maWcub25TZWxlY3QpIHtcbiAgICAgICAgICAgICAgICBhdXRvY29tcGxldGVDb25maWcub25TZWxlY3QoaXRlbSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpbnB1dFJlZi5jdXJyZW50Py5ibHVyKCk7XG4gICAgfTtcblxuICAgIGNvbnN0IG1hc2tEZWZpbml0aW9uID0gbWFzayA/IGdldE1hc2sobWFzaykgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgZGlzcGxheVZhbHVlID0gY29kZVZhbHVlIHx8ICcnO1xuICAgIGNvbnN0IG1heExlbmd0aCA9IG1hc2tEZWZpbml0aW9uPy5tYXhMZW5ndGg7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIHNwYWNlLXgtMiBtdC0xXCI+XG4gICAgICAgICAgICB7LyogLS0tIElucHV0IGRlbCBDw7NkaWdvIChFZGl0YWJsZSkgY29uIEF1dG9jb21wbGV0YWRvIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgcmVmPXtjb250YWluZXJSZWZ9IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctMS8zXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHJlZj17aW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Rpc3BsYXlWYWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvZGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17aGFuZGxlS2V5RG93bn1cbiAgICAgICAgICAgICAgICAgICAgb25Gb2N1cz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVuYWJsZUF1dG9jb21wbGV0ZSAmJiBhdXRvY29tcGxldGVJdGVtcy5sZW5ndGggPiAwICYmIGRlYm91bmNlZENvZGUubGVuZ3RoID49IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0F1dG9jb21wbGV0ZU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ8OzZGlnby4uLlwiXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc20gJHtoYXNFcnJvciA/ICdib3JkZXItcmVkLTUwMCcgOiAnYm9yZGVyLWdyYXktMzAwJ30gZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwYH1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9e21heExlbmd0aH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtlbmFibGVBdXRvY29tcGxldGUgJiYgYXV0b2NvbXBsZXRlQ29uZmlnICYmIGlzQXV0b2NvbXBsZXRlT3BlbiAmJiBhdXRvY29tcGxldGVJdGVtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPEF1dG9jb21wbGV0ZURyb3Bkb3duXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtcz17YXV0b2NvbXBsZXRlSXRlbXN9XG4gICAgICAgICAgICAgICAgICAgICAgICBpc09wZW49e2lzQXV0b2NvbXBsZXRlT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RJdGVtfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldElzQXV0b2NvbXBsZXRlT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXV0b2NvbXBsZXRlSXRlbXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlckl0ZW09eyhpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntpdGVtW2F1dG9jb21wbGV0ZUNvbmZpZy5jb2RlRmllbGRdfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPntpdGVtW2F1dG9jb21wbGV0ZUNvbmZpZy5uYW1lRmllbGRdfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSW5kZXg9e3NlbGVjdGVkSW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgZW1wdHlNZXNzYWdlPVwiTm8gc2UgZW5jb250cmFyb24gcHJvZHVjdG9zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyaWdnZXJFbGVtZW50PXtpbnB1dFJlZi5jdXJyZW50fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHsvKiAtLS0gU3BhbiBkZWwgTm9tYnJlIChSZWFkb25seSkgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmFtZVZhbHVlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWJyZS4uLlwiXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgcHItMjAgYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgey8qIEJvdMOzbiBMaW1waWFyIChYKSAqL31cbiAgICAgICAgICAgICAgICB7KGNvZGVWYWx1ZSB8fCBuYW1lVmFsdWUpICYmICFkaXNhYmxlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldElzQXV0b2NvbXBsZXRlT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTEwIHAtMSB0ZXh0LWdyYXktNDAwIHJvdW5kZWQtZnVsbCBob3Zlcjp0ZXh0LWdyYXktNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJMaW1waWFyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhVGltZXMgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7LyogQm90w7NuIEJ1c2NhciAoTHVwYSkgKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25TZWFyY2hDbGlja31cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtZ3JheS01MDAgYm9yZGVyLWwgYm9yZGVyLWdyYXktMzAwIGhvdmVyOnRleHQtaW5kaWdvLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJCdXNjYXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEZhU2VhcmNoIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL1JlbGF0aW9uYWxJbnB1dC50c3gifQ==