import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { mercadoLibrePublicacionesConfig } from "/src/features/mercadolibre_publicaciones/mercadolibre_publicaciones.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const MercadoLibrePublicacionesDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const { item, loading, error } = useCrudItem(mercadoLibrePublicacionesConfig, id);
  const modulePermission = getRequiredPermission(mercadoLibrePublicacionesConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
    lineNumber: 40,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
    lineNumber: 41,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "No encontrado" }, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-white rounded-lg shadow-sm space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b pb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(mercadoLibrePublicacionesConfig.baseRoute)), className: "p-2 hover:bg-gray-100 rounded-full", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6 text-gray-500" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 49,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 48,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-900", children: "Detalle Vinculación ML" }, void 0, false, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 52,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: [
            "ID: ",
            item.meli_id
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 53,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 51,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
        lineNumber: 47,
        columnNumber: 17
      }, this),
      canEdit && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => navigate(`${mercadoLibrePublicacionesConfig.baseRoute}/${id}/editar`),
          className: "inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(IoPencil, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 61,
              columnNumber: 25
            }, this),
            " Editar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 57,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
      lineNumber: 46,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-lg border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-500 uppercase mb-3", children: "Producto Local Asociado" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 68,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Nombre:" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 71,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: item.product?.name || item.product_name }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 72,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 70,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Código (SKU Local):" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 75,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: item.product?.sku || item.product_code }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 76,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 74,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Stock Actual:" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 79,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: item.product?.stock_quantity ?? "N/A" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 80,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 78,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 69,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
        lineNumber: 67,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 p-4 rounded-lg border border-yellow-100", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-yellow-700 uppercase mb-3", children: "Configuración MercadoLibre" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 86,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Publicación ID:" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 89,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900", children: item.meli_id }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 90,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 88,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Estado:" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 93,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded text-xs font-bold ${item.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: item.is_active ? "ACTIVA" : "PAUSADA" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 94,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 92,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between border-t border-yellow-200 pt-2 mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800 font-medium", children: "Factor de Conversión:" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 99,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-xl text-indigo-700", children: [
              "1 Venta ML = -",
              item.stock_reduction_quantity,
              " Stock Local"
            ] }, void 0, true, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
              lineNumber: 100,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
            lineNumber: 98,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
          lineNumber: 87,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
        lineNumber: 85,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
      lineNumber: 66,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
};
_s(MercadoLibrePublicacionesDetailPage, "udr1ZDFn/ZXbGo11/1gzwQEpMbQ=", false, function() {
  return [useParams, useNavigate, usePermissions, useCrudItem];
});
_c = MercadoLibrePublicacionesDetailPage;
var _c;
$RefreshReg$(_c, "MercadoLibrePublicacionesDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0J3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsdUNBQXFFO0FBQzlFLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxzQ0FBc0NBLE1BQU07QUFBQUMsS0FBQTtBQUNyRCxRQUFNLEVBQUVDLEdBQUcsSUFBSWIsVUFBMEI7QUFDekMsUUFBTWMsV0FBV2IsWUFBWTtBQUM3QixRQUFNLEVBQUVjLG9CQUFvQixJQUFJUixlQUFlO0FBQy9DLFFBQU0sRUFBRVMsTUFBTUMsU0FBU0MsTUFBTSxJQUFJaEIsWUFBcUNDLGlDQUFpQ1UsRUFBRTtBQUd6RyxRQUFNTSxtQkFBbUJYLHNCQUFzQkwsZ0NBQWdDaUIsU0FBUztBQUN4RixRQUFNQyxhQUFhRixtQkFBbUJWLHdCQUF3QlUsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsVUFBVUQsYUFBYU4sb0JBQW9CTSxZQUFZLE1BQU0sSUFBSTtBQUV2RSxNQUFJSixRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLDZCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0I7QUFFcEMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsK0NBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTUYsU0FBU0osa0JBQWtCUCxnQ0FBZ0NpQixTQUFTLENBQUMsR0FBRyxXQUFVLHNDQUNyRyxpQ0FBQyxlQUFZLFdBQVUsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1DQUFrQyxzQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxZQUFLSixLQUFLTztBQUFBQSxlQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQ0QsV0FDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csU0FBUyxNQUFNUixTQUFTLEdBQUdYLGdDQUFnQ2lCLFNBQVMsSUFBSVAsRUFBRSxTQUFTO0FBQUEsVUFDbkYsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEI7QUFBQSxZQUFHO0FBQUE7QUFBQTtBQUFBLFFBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FoQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9EQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtEQUFpRCx1Q0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRjtBQUFBLFFBQ3RGLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN2Qyx1QkFBQyxVQUFLLFdBQVUsZUFBZUcsZUFBS1EsU0FBU0MsUUFBUVQsS0FBS1UsZ0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsZUFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQixtQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxVQUFLLFdBQVUsZUFBZVYsZUFBS1EsU0FBU0csT0FBT1gsS0FBS1ksZ0JBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxVQUFLLFdBQVUsZUFBZVosZUFBS1EsU0FBU0ssa0JBQWtCLFNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0RBQW1ELDBDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJGO0FBQUEsUUFDM0YsdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLCtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQy9DLHVCQUFDLFVBQUssV0FBVSwyQkFBMkJiLGVBQUtPLFdBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN2Qyx1QkFBQyxVQUFLLFdBQVcseUNBQXlDUCxLQUFLYyxZQUFZLGdDQUFnQyx5QkFBeUIsSUFDL0hkLGVBQUtjLFlBQVksV0FBVyxhQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNkJBQTRCLHFDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFVBQUssV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLGNBQWVkLEtBQUtlO0FBQUFBLGNBQXlCO0FBQUEsaUJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsZUFGakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLFNBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0E7QUFBQSxPQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNERBO0FBRVI7QUFBRW5CLEdBOUVXRCxxQ0FBbUM7QUFBQSxVQUM3QlgsV0FDRUMsYUFDZU0sZ0JBQ0NMLFdBQVc7QUFBQTtBQUFBOEIsS0FKbkNyQjtBQUFtQyxJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwidXNlQ3J1ZEl0ZW0iLCJtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJJb0Fycm93QmFjayIsIklvUGVuY2lsIiwidXNlUGVybWlzc2lvbnMiLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImdldExpc3RSZXR1cm5QYXRoIiwiTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwiaXRlbSIsImxvYWRpbmciLCJlcnJvciIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdCIsIm1lbGlfaWQiLCJwcm9kdWN0IiwibmFtZSIsInByb2R1Y3RfbmFtZSIsInNrdSIsInByb2R1Y3RfY29kZSIsInN0b2NrX3F1YW50aXR5IiwiaXNfYWN0aXZlIiwic3RvY2tfcmVkdWN0aW9uX3F1YW50aXR5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgbWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0NvbmZpZywgdHlwZSBNZXJjYWRvTGlicmVQdWJsaWNhdGlvbiB9IGZyb20gJy4uL21lcmNhZG9saWJyZV9wdWJsaWNhY2lvbmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2ssIElvUGVuY2lsIH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGhhc01vZHVsZVBlcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gICAgY29uc3QgeyBpdGVtLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08TWVyY2Fkb0xpYnJlUHVibGljYXRpb24+KG1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWcsIGlkKTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnLmJhc2VSb3V0ZSk7XG4gICAgY29uc3QgbW9kdWxlQmFzZSA9IG1vZHVsZVBlcm1pc3Npb24gPyBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbihtb2R1bGVQZXJtaXNzaW9uKSA6IG51bGw7XG4gICAgY29uc3QgY2FuRWRpdCA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghaXRlbSkgcmV0dXJuIDxkaXY+Tm8gZW5jb250cmFkbzwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgcGItNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0NvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLWdyYXktMTAwIHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvQXJyb3dCYWNrIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ncmF5LTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5EZXRhbGxlIFZpbmN1bGFjacOzbiBNTDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5JRDoge2l0ZW0ubWVsaV9pZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtjYW5FZGl0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYCR7bWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0NvbmZpZy5iYXNlUm91dGV9LyR7aWR9L2VkaXRhcmApfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBiZy1pbmRpZ28tNjAwIHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVuY2lsIGNsYXNzTmFtZT1cIm1yLTJcIiAvPiBFZGl0YXJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItM1wiPlByb2R1Y3RvIExvY2FsIEFzb2NpYWRvPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+Tm9tYnJlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntpdGVtLnByb2R1Y3Q/Lm5hbWUgfHwgaXRlbS5wcm9kdWN0X25hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPkPDs2RpZ28gKFNLVSBMb2NhbCk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e2l0ZW0ucHJvZHVjdD8uc2t1IHx8IGl0ZW0ucHJvZHVjdF9jb2RlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5TdG9jayBBY3R1YWw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e2l0ZW0ucHJvZHVjdD8uc3RvY2tfcXVhbnRpdHkgPz8gJ04vQSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci15ZWxsb3ctMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXllbGxvdy03MDAgdXBwZXJjYXNlIG1iLTNcIj5Db25maWd1cmFjacOzbiBNZXJjYWRvTGlicmU8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5QdWJsaWNhY2nDs24gSUQ6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e2l0ZW0ubWVsaV9pZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPkVzdGFkbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LXhzIGZvbnQtYm9sZCAke2l0ZW0uaXNfYWN0aXZlID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCcgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pc19hY3RpdmUgPyAnQUNUSVZBJyA6ICdQQVVTQURBJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLXllbGxvdy0yMDAgcHQtMiBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LW1lZGl1bVwiPkZhY3RvciBkZSBDb252ZXJzacOzbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteGwgdGV4dC1pbmRpZ28tNzAwXCI+MSBWZW50YSBNTCA9IC17aXRlbS5zdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHl9IFN0b2NrIExvY2FsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbWVyY2Fkb2xpYnJlX3B1YmxpY2FjaW9uZXMvcGFnZXMvTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0RldGFpbFBhZ2UudHN4In0=