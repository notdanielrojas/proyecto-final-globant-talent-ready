import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericTable } from "/src/components/common/GenericTable.tsx";
import { NoDataMessage } from "/src/components/common/NoDataMessage.tsx";
import { GenericCardList } from "/src/components/common/GenericCardList.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { FaSearch } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
export const GenericListPage = ({
  config,
  loading,
  paginationResponse,
  isAppending,
  onDelete,
  onSort,
  sortBy,
  sortDirection,
  onPageChange,
  onLoadMore,
  onSearch,
  searchTerm,
  persistedSearchParams,
  additionalSearchMerge,
  renderExtraSearchFields,
  dateFilterStart = "",
  dateFilterEnd = "",
  enableDateRangeFilter = false,
  // ✅ NUEVO: Valor por defecto
  onRowClick,
  canEdit: canEditProp,
  // ✅ Prop opcional que puede sobrescribir los permisos
  canDelete: canDeleteProp,
  // ✅ Prop opcional que puede sobrescribir los permisos
  additionalHeaderButtons,
  enableRowSelection = false,
  selectedIds,
  onToggleRow,
  onTogglePage
}) => {
  _s();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const [localSearch, setLocalSearch] = useState(searchTerm);
  const [startDate, setStartDate] = useState(dateFilterStart);
  const [endDate, setEndDate] = useState(dateFilterEnd);
  useEffect(() => {
    setLocalSearch(searchTerm);
  }, [searchTerm]);
  useEffect(() => {
    setStartDate(dateFilterStart);
    setEndDate(dateFilterEnd);
  }, [dateFilterStart, dateFilterEnd]);
  const modulePermission = getRequiredPermission(config.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canCreate = moduleBase ? hasModulePermission(moduleBase, "create") : true;
  const handleCreateNew = () => {
    navigate(`${config.baseRoute}/nuevo`);
  };
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    onSearch({
      ...persistedSearchParams ?? {},
      term: localSearch,
      startDate,
      endDate,
      ...additionalSearchMerge ?? {}
    });
  };
  const data = paginationResponse?.data ?? [];
  const defaultCanEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const defaultCanDelete = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEdit = canEditProp !== void 0 ? canEditProp : defaultCanEdit;
  const canDelete = canDeleteProp !== void 0 ? canDeleteProp : defaultCanDelete;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:flex-auto", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: [
        "Listado de ",
        config.moduleNamePlural
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 235,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 234,
        columnNumber: 17
      }, this),
      canCreate || additionalHeaderButtons ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 mt-4 sm:flex-nowrap sm:mt-0 sm:ml-4 sm:flex-none sm:justify-end", children: [
        additionalHeaderButtons,
        canCreate && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleCreateNew,
            className: "inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:w-auto",
            children: config.moduleName === "Compra" ? "Ingresar Comprobante de Compra" : "Crear " + config.moduleName
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericListPage.tsx",
            lineNumber: 241,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 238,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 233,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSearchSubmit, className: "p-4 mt-4 bg-gray-50 border rounded-lg", autoComplete: "off", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-3", children: enableDateRangeFilter ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "start-date", className: "block text-sm font-medium text-gray-700", children: "Desde" }, void 0, false, {
            fileName: "/app/src/components/common/GenericListPage.tsx",
            lineNumber: 260,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              id: "start-date",
              value: startDate,
              onChange: (e) => setStartDate(e.target.value),
              autoComplete: "off",
              className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericListPage.tsx",
              lineNumber: 261,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 259,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "end-date", className: "block text-sm font-medium text-gray-700", children: "Hasta" }, void 0, false, {
            fileName: "/app/src/components/common/GenericListPage.tsx",
            lineNumber: 271,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              id: "end-date",
              value: endDate,
              onChange: (e) => setEndDate(e.target.value),
              autoComplete: "off",
              className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericListPage.tsx",
              lineNumber: 272,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 270,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "search-term", className: "block text-sm font-medium text-gray-700", children: "Buscar" }, void 0, false, {
            fileName: "/app/src/components/common/GenericListPage.tsx",
            lineNumber: 282,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative flex mt-1 rounded-md shadow-sm", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                id: "search-term",
                value: localSearch,
                onChange: (e) => setLocalSearch(e.target.value),
                placeholder: "Buscar...",
                autoComplete: "off",
                className: "block w-full px-3 py-2 border-gray-300 rounded-l-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/common/GenericListPage.tsx",
                lineNumber: 284,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "relative inline-flex items-center px-4 py-2 -ml-px space-x-2 text-sm font-medium text-gray-700 border border-gray-300 rounded-r-md bg-gray-50 hover:bg-gray-100",
                children: [
                  /* @__PURE__ */ jsxDEV(FaSearch, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericListPage.tsx",
                    lineNumber: 297,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Buscar" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericListPage.tsx",
                    lineNumber: 298,
                    columnNumber: 41
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/components/common/GenericListPage.tsx",
                lineNumber: 293,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/components/common/GenericListPage.tsx",
            lineNumber: 283,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 281,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 257,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-3", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "search-term", className: "block text-sm font-medium text-gray-700", children: "Buscar" }, void 0, false, {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 305,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative flex mt-1 rounded-md shadow-sm", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "search-term",
              value: localSearch,
              onChange: (e) => setLocalSearch(e.target.value),
              placeholder: "Buscar...",
              autoComplete: "off",
              className: "block w-full px-3 py-2 border-gray-300 rounded-l-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericListPage.tsx",
              lineNumber: 307,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "relative inline-flex items-center px-4 py-2 -ml-px space-x-2 text-sm font-medium text-gray-700 border border-gray-300 rounded-r-md bg-gray-50 hover:bg-gray-100",
              children: [
                /* @__PURE__ */ jsxDEV(FaSearch, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                  fileName: "/app/src/components/common/GenericListPage.tsx",
                  lineNumber: 320,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Buscar" }, void 0, false, {
                  fileName: "/app/src/components/common/GenericListPage.tsx",
                  lineNumber: 321,
                  columnNumber: 37
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/components/common/GenericListPage.tsx",
              lineNumber: 316,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 306,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 304,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 255,
        columnNumber: 17
      }, this),
      renderExtraSearchFields ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 mt-4 md:grid-cols-3", children: renderExtraSearchFields }, void 0, false, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 328,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 254,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: loading && !isAppending ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 336,
      columnNumber: 9
    }, this) : data.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hidden lg:block", children: /* @__PURE__ */ jsxDEV(
        GenericTable,
        {
          data,
          columns: config.list.columns,
          baseRoute: config.baseRoute,
          onDelete,
          onSort,
          sortBy,
          sortDirection,
          disableEdit: config.disableEdit,
          paginationMeta: paginationResponse?.meta ?? null,
          onPageChange,
          disableActions: config.disableActions,
          onRowClick,
          canEdit,
          canDelete,
          enableRowSelection,
          selectedIds,
          onToggleRow,
          onTogglePage
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 340,
          columnNumber: 29
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 339,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "block lg:hidden", children: /* @__PURE__ */ jsxDEV(
        GenericCardList,
        {
          data,
          columns: config.list.columns,
          baseRoute: config.baseRoute,
          onDelete,
          paginationLinks: paginationResponse?.links ?? null,
          isAppending,
          onLoadMore,
          onSort,
          sortBy,
          sortDirection,
          disableEdit: config.disableEdit,
          onRowClick,
          canEdit,
          canDelete,
          enableRowSelection,
          selectedIds,
          onToggleRow,
          onTogglePage
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/GenericListPage.tsx",
          lineNumber: 362,
          columnNumber: 29
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/components/common/GenericListPage.tsx",
        lineNumber: 361,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 338,
      columnNumber: 9
    }, this) : !loading && /* @__PURE__ */ jsxDEV(NoDataMessage, { moduleName: config.moduleNamePlural.toLowerCase() }, void 0, false, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 385,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/GenericListPage.tsx",
      lineNumber: 334,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/GenericListPage.tsx",
    lineNumber: 232,
    columnNumber: 5
  }, this);
};
_s(GenericListPage, "adgHM8JoLYUqd3kuFslPJbCbTVc=", false, function() {
  return [useNavigate, usePermissions];
});
_c = GenericListPage;
var _c;
$RefreshReg$(_c, "GenericListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdU5vQixTQXNCSSxVQXRCSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2TnBCLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBRS9CLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCQywrQkFBK0I7QUE2SHhELGFBQU1DLGtCQUFrQixDQUFvQztBQUFBLEVBQy9EQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxrQkFBa0I7QUFBQSxFQUNsQkMsZ0JBQWdCO0FBQUEsRUFDaEJDLHdCQUF3QjtBQUFBO0FBQUEsRUFDeEJDO0FBQUFBLEVBQ0FDLFNBQVNDO0FBQUFBO0FBQUFBLEVBQ1RDLFdBQVdDO0FBQUFBO0FBQUFBLEVBQ1hDO0FBQUFBLEVBQ0FDLHFCQUFxQjtBQUFBLEVBQ3JCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNxQixNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsV0FBV3ZDLFlBQVk7QUFDN0IsUUFBTSxFQUFFd0Msb0JBQW9CLElBQUlsQyxlQUFlO0FBQy9DLFFBQU0sQ0FBQ21DLGFBQWFDLGNBQWMsSUFBSTVDLFNBQVN1QixVQUFVO0FBR3pELFFBQU0sQ0FBQ3NCLFdBQVdDLFlBQVksSUFBSTlDLFNBQVMyQixlQUFlO0FBQzFELFFBQU0sQ0FBQ29CLFNBQVNDLFVBQVUsSUFBSWhELFNBQVM0QixhQUFhO0FBR3BEM0IsWUFBVSxNQUFNO0FBQ1oyQyxtQkFBZXJCLFVBQVU7QUFBQSxFQUM3QixHQUFHLENBQUNBLFVBQVUsQ0FBQztBQUVmdEIsWUFBVSxNQUFNO0FBQ1o2QyxpQkFBYW5CLGVBQWU7QUFDNUJxQixlQUFXcEIsYUFBYTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ0QsaUJBQWlCQyxhQUFhLENBQUM7QUFHbkMsUUFBTXFCLG1CQUFtQnhDLHNCQUFzQkcsT0FBT3NDLFNBQVM7QUFDL0QsUUFBTUMsYUFBYUYsbUJBQW1CdkMsd0JBQXdCdUMsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsWUFBWUQsYUFBYVQsb0JBQW9CUyxZQUFZLFFBQVEsSUFBSTtBQUUzRSxRQUFNRSxrQkFBa0JBLE1BQU07QUFDMUJaLGFBQVMsR0FBRzdCLE9BQU9zQyxTQUFTLFFBQVE7QUFBQSxFQUN4QztBQUdBLFFBQU1JLHFCQUFxQkEsQ0FBQ0MsTUFBdUI7QUFDL0NBLE1BQUVDLGVBQWU7QUFDakJsQyxhQUFTO0FBQUEsTUFDTCxHQUFJRSx5QkFBeUIsQ0FBQztBQUFBLE1BQzlCaUMsTUFBTWQ7QUFBQUEsTUFDTkU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQSxHQUFJdEIseUJBQXlCLENBQUM7QUFBQSxJQUNsQyxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1pQyxPQUFPNUMsb0JBQW9CNEMsUUFBUTtBQUd6QyxRQUFNQyxpQkFBaUJSLGFBQWFULG9CQUFvQlMsWUFBWSxNQUFNLElBQUk7QUFDOUUsUUFBTVMsbUJBQW1CVCxhQUFhVCxvQkFBb0JTLFlBQVksUUFBUSxJQUFJO0FBR2xGLFFBQU1wQixVQUFVQyxnQkFBZ0I2QixTQUFZN0IsY0FBYzJCO0FBQzFELFFBQU0xQixZQUFZQyxrQkFBa0IyQixTQUFZM0IsZ0JBQWdCMEI7QUFFaEUsU0FDSSx1QkFBQyxTQUNHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUNYLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLFFBQVloRCxPQUFPa0Q7QUFBQUEsV0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RixLQUQ3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNFVixhQUFhakIsMEJBQ1gsdUJBQUMsU0FBSSxXQUFVLHFHQUNWQTtBQUFBQTtBQUFBQSxRQUNBaUIsYUFDRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU0M7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVHpDLGlCQUFPbUQsZUFBZSxXQUFXLG1DQUFtQyxXQUFXbkQsT0FBT21EO0FBQUFBO0FBQUFBLFVBTDNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FUUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0EsSUFDQTtBQUFBLFNBakJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxJQUdBLHVCQUFDLFVBQUssVUFBVVQsb0JBQW9CLFdBQVUseUNBQXdDLGNBQWEsT0FDL0Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUNBQ1Z6QixrQ0FDRyxtQ0FFSTtBQUFBLCtCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsY0FBYSxXQUFVLDJDQUEwQyxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsT0FBT2dCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDVSxNQUFNVCxhQUFhUyxFQUFFUyxPQUFPQyxLQUFLO0FBQUEsY0FDNUMsY0FBYTtBQUFBLGNBQ2IsV0FBVTtBQUFBO0FBQUEsWUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNZ0o7QUFBQSxhQVJwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsWUFBVyxXQUFVLDJDQUEwQyxxQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsT0FBT2xCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDUSxNQUFNUCxXQUFXTyxFQUFFUyxPQUFPQyxLQUFLO0FBQUEsY0FDMUMsY0FBYTtBQUFBLGNBQ2IsV0FBVTtBQUFBO0FBQUEsWUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNZ0o7QUFBQSxhQVJwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsZUFBYyxXQUFVLDJDQUEwQyxzQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUN2Rix1QkFBQyxTQUFJLFdBQVUsMkNBQ1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxJQUFHO0FBQUEsZ0JBQ0gsT0FBT3RCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ1ksTUFBTVgsZUFBZVcsRUFBRVMsT0FBT0MsS0FBSztBQUFBLGdCQUM5QyxhQUFZO0FBQUEsZ0JBQ1osY0FBYTtBQUFBLGdCQUNiLFdBQVU7QUFBQTtBQUFBLGNBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTzRIO0FBQUEsWUFFNUg7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUMzQyx1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVk7QUFBQTtBQUFBO0FBQUEsY0FMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLGFBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsV0FBTSxTQUFRLGVBQWMsV0FBVSwyQ0FBMEMsc0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxRQUN2Rix1QkFBQyxTQUFJLFdBQVUsMkNBQ1g7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsT0FBT3RCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDWSxNQUFNWCxlQUFlVyxFQUFFUyxPQUFPQyxLQUFLO0FBQUEsY0FDOUMsYUFBWTtBQUFBLGNBQ1osY0FBYTtBQUFBLGNBQ2IsV0FBVTtBQUFBO0FBQUEsWUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPNEg7QUFBQSxVQUU1SDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJDO0FBQUEsZ0JBQzNDLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUE7QUFBQSxZQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBLEtBckVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1RUE7QUFBQSxNQUNDdkMsMEJBQ0csdUJBQUMsU0FBSSxXQUFVLDhDQUNWQSxxQ0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFDQTtBQUFBLFNBN0VSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNWYixxQkFBVyxDQUFDRSxjQUNULHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxJQUNmMkMsS0FBS1EsU0FBUyxJQUNkLG1DQUNJO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1CQUNYO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRztBQUFBLFVBQ0EsU0FBU3RELE9BQU91RCxLQUFLQztBQUFBQSxVQUNyQixXQUFXeEQsT0FBT3NDO0FBQUFBLFVBQ2xCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxhQUFhdEMsT0FBT3lEO0FBQUFBLFVBQ3BCLGdCQUFnQnZELG9CQUFvQndELFFBQVE7QUFBQSxVQUM1QztBQUFBLFVBQ0EsZ0JBQWdCMUQsT0FBTzJEO0FBQUFBLFVBQ3ZCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQitCLEtBbkJuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHO0FBQUEsVUFDQSxTQUFTM0QsT0FBT3VELEtBQUtDO0FBQUFBLFVBQ3JCLFdBQVd4RCxPQUFPc0M7QUFBQUEsVUFDbEI7QUFBQSxVQUNBLGlCQUFpQnBDLG9CQUFvQjBELFNBQVM7QUFBQSxVQUM5QztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLGFBQWE1RCxPQUFPeUQ7QUFBQUEsVUFDcEI7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtCK0IsS0FuQm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkNBLElBRUEsQ0FBQ3hELFdBQVcsdUJBQUMsaUJBQWMsWUFBWUQsT0FBT2tELGlCQUFpQlcsWUFBWSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFLEtBbkRyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBO0FBQUEsT0EzSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRKQTtBQUVSO0FBQUVqQyxHQTVPVzdCLGlCQUFlO0FBQUEsVUE0QlBULGFBQ2VNLGNBQWM7QUFBQTtBQUFBa0UsS0E3QnJDL0Q7QUFBZSxJQUFBK0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNUYWJsZSIsIk5vRGF0YU1lc3NhZ2UiLCJHZW5lcmljQ2FyZExpc3QiLCJMb2FkaW5nU3Bpbm5lciIsIkZhU2VhcmNoIiwidXNlUGVybWlzc2lvbnMiLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsIkdlbmVyaWNMaXN0UGFnZSIsImNvbmZpZyIsImxvYWRpbmciLCJwYWdpbmF0aW9uUmVzcG9uc2UiLCJpc0FwcGVuZGluZyIsIm9uRGVsZXRlIiwib25Tb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsIm9uUGFnZUNoYW5nZSIsIm9uTG9hZE1vcmUiLCJvblNlYXJjaCIsInNlYXJjaFRlcm0iLCJwZXJzaXN0ZWRTZWFyY2hQYXJhbXMiLCJhZGRpdGlvbmFsU2VhcmNoTWVyZ2UiLCJyZW5kZXJFeHRyYVNlYXJjaEZpZWxkcyIsImRhdGVGaWx0ZXJTdGFydCIsImRhdGVGaWx0ZXJFbmQiLCJlbmFibGVEYXRlUmFuZ2VGaWx0ZXIiLCJvblJvd0NsaWNrIiwiY2FuRWRpdCIsImNhbkVkaXRQcm9wIiwiY2FuRGVsZXRlIiwiY2FuRGVsZXRlUHJvcCIsImFkZGl0aW9uYWxIZWFkZXJCdXR0b25zIiwiZW5hYmxlUm93U2VsZWN0aW9uIiwic2VsZWN0ZWRJZHMiLCJvblRvZ2dsZVJvdyIsIm9uVG9nZ2xlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwibG9jYWxTZWFyY2giLCJzZXRMb2NhbFNlYXJjaCIsInN0YXJ0RGF0ZSIsInNldFN0YXJ0RGF0ZSIsImVuZERhdGUiLCJzZXRFbmREYXRlIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJjYW5DcmVhdGUiLCJoYW5kbGVDcmVhdGVOZXciLCJoYW5kbGVTZWFyY2hTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0ZXJtIiwiZGF0YSIsImRlZmF1bHRDYW5FZGl0IiwiZGVmYXVsdENhbkRlbGV0ZSIsInVuZGVmaW5lZCIsIm1vZHVsZU5hbWVQbHVyYWwiLCJtb2R1bGVOYW1lIiwidGFyZ2V0IiwidmFsdWUiLCJsZW5ndGgiLCJsaXN0IiwiY29sdW1ucyIsImRpc2FibGVFZGl0IiwibWV0YSIsImRpc2FibGVBY3Rpb25zIiwibGlua3MiLCJ0b0xvd2VyQ2FzZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkdlbmVyaWNMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY1RhYmxlIH0gZnJvbSAnLi9HZW5lcmljVGFibGUnO1xuaW1wb3J0IHsgTm9EYXRhTWVzc2FnZSB9IGZyb20gJy4vTm9EYXRhTWVzc2FnZSc7XG5pbXBvcnQgeyBHZW5lcmljQ2FyZExpc3QgfSBmcm9tICcuL0dlbmVyaWNDYXJkTGlzdCc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB0eXBlIHsgUGFnaW5hdGVkUmVzcG9uc2UgfSBmcm9tICcuLi8uLi9pbnRlcmZhY2VzL0FwaSc7XG5pbXBvcnQgeyBGYVNlYXJjaCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcblxuLy8gLS0tIElOVEVSRkFDRVMgWSBUSVBPUyAtLS1cblxuZXhwb3J0IGludGVyZmFjZSBDb2x1bW5EZWZpbml0aW9uPFQ+IHtcbiAgICBoZWFkZXI6IHN0cmluZztcbiAgICBhY2Nlc3Nvcjoga2V5b2YgVDtcbiAgICAvKiogU2kgZXhpc3RlLCBzZSBlbnbDrWEgYSBsYSBBUEkgY29tbyBgc29ydF9ieWAgZW4gbHVnYXIgZGVsIGFjY2Vzc29yIChlai4gcHJvZHVjdF9uYW1lIHZzIHByb2R1Y3RfaWQpLiAqL1xuICAgIHNvcnRGaWVsZD86IHN0cmluZztcbiAgICByZW5kZXI/OiAoaXRlbTogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xuICAgIGZvcm1hdD86ICdkYXRlJyB8ICdjdXJyZW5jeSc7XG59XG5cbmV4cG9ydCB0eXBlIE9wdGlvbnNMb2FkZXIgPSAoKSA9PiBQcm9taXNlPHsgdmFsdWU6IHN0cmluZyB8IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9W10+O1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlbGF0aW9uYWxGaWVsZENvbmZpZzxSPiB7XG4gICAgbW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8Uj47XG4gICAgbmFtZUZpZWxkOiBzdHJpbmc7XG4gICAgY29kZUZpZWxkOiBzdHJpbmc7XG59XG5cbmV4cG9ydCB0eXBlIEZvcm1DaGFuZ2VFZmZlY3Q8VD4gPSAoXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICBuZXdWYWx1ZTogYW55LFxuICAgIGN1cnJlbnREYXRhOiBULFxuICAgIHVwZGF0ZURhdGE6ICh1cGRhdGVzOiBQYXJ0aWFsPFQ+KSA9PiB2b2lkXG4pID0+IHZvaWQ7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRm9ybUZpZWxkQ29uZmlnPFQ+IHtcbiAgICBuYW1lOiBrZXlvZiBUO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgdHlwZTogJ3RleHQnIHwgJ3RleHRhcmVhJyB8ICdlbWFpbCcgfCAndXJsJyB8ICdkYXRlJyB8ICdudW1iZXInIHwgJ3NlbGVjdCcgfCAncGFzc3dvcmQnIHwgJ2NoZWNrYm94LWdyb3VwJyB8ICdyZWxhdGlvbmFsJyB8ICdhcnJheS1zdHJpbmcnO1xuICAgIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xuICAgIG9wdGlvbnM/OiB7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuOyBsYWJlbDogc3RyaW5nIH1bXTtcbiAgICBsb2FkT3B0aW9ucz86IE9wdGlvbnNMb2FkZXI7XG4gICAgcmVuZGVyPzogKGl0ZW06IFQpID0+IFJlYWN0LlJlYWN0Tm9kZTtcbiAgICBtYW5kYXRvcnk/OiBib29sZWFuIHwgKChmb3JtRGF0YTogVCkgPT4gYm9vbGVhbik7XG4gICAgcmVhZG9ubHk/OiBib29sZWFuIHwgKChmb3JtRGF0YTogVCkgPT4gYm9vbGVhbik7XG4gICAgdmlzaWJsZVdoZW4/OiAoZm9ybURhdGE6IFQpID0+IGJvb2xlYW47XG4gICAgZ2V0T3B0aW9ucz86IChmb3JtRGF0YTogVCkgPT4geyB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbjsgbGFiZWw6IHN0cmluZyB9W107XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICByZWxhdGlvbmFsQ29uZmlnPzogUmVsYXRpb25hbEZpZWxkQ29uZmlnPGFueT47XG4gICAgZm9ybWF0PzogJ2RhdGUnIHwgJ2N1cnJlbmN5JztcbiAgICB2YWx1ZVR5cGU/OiAnc3RyaW5nJyB8ICdudW1iZXInIHwgJ2Jvb2xlYW4nO1xuICAgIG9uQ2hhbmdlRWZmZWN0PzogRm9ybUNoYW5nZUVmZmVjdDxUPjtcbiAgICBtYXNrPzogc3RyaW5nOyAvLyDinIUgTm9tYnJlIGRlIGxhIG3DoXNjYXJhIGEgYXBsaWNhciAoY29uc3VsdGEgZWwgcmVnaXN0cm8gZW4gdXRpbHMvbWFza3MudHMpXG4gICAgLyoqIFNpIGVzIHRydWUsIGVsIGNhbXBvIHNvbG8gc2UgbXVlc3RyYSBlbiBsYSB2aXN0YSBkZSBkZXRhbGxlLCBubyBlbiBlbCBmb3JtdWxhcmlvLiAqL1xuICAgIGRldGFpbE9ubHk/OiBib29sZWFuO1xuICAgIC8qKiBQZXJtaXRlIHZhcmlvcyBlbWFpbHMgc2VwYXJhZG9zIHBvciBjb21hIG8gZXNwYWNpbzsgdmFsaWRhIGNhZGEgdW5vLiAqL1xuICAgIGFsbG93TXVsdGlwbGVFbWFpbHM/OiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEZvcm1CbG9ja0NvbmZpZzxUPiB7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIGZpZWxkczogRm9ybUZpZWxkQ29uZmlnPFQ+W107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTW9kdWxlQ29uZmlnPFQ+IHtcbiAgICBlbmRwb2ludDogc3RyaW5nO1xuICAgIG1vZHVsZU5hbWU6IHN0cmluZztcbiAgICBtb2R1bGVOYW1lUGx1cmFsOiBzdHJpbmc7XG4gICAgYmFzZVJvdXRlOiBzdHJpbmc7XG4gICAgZGlzYWJsZUVkaXQ/OiBib29sZWFuO1xuICAgIGRpc2FibGVBY3Rpb25zPzogYm9vbGVhbjtcbiAgICBsaXN0OiB7XG4gICAgICAgIGNvbHVtbnM6IENvbHVtbkRlZmluaXRpb248VD5bXTtcbiAgICB9O1xuICAgIGRldGFpbDoge1xuICAgICAgICBkaXNwbGF5TmFtZUtleToga2V5b2YgVDtcbiAgICB9O1xuICAgIGZvcm06IHtcbiAgICAgICAgYmxvY2s6IEZvcm1CbG9ja0NvbmZpZzxUPltdXG4gICAgfVxuICAgIHJlbGF0aW9uYWxGaWVsZHM/OiB7XG4gICAgICAgIGlkRmllbGQ6IGtleW9mIFQ7ICAgICAvLyAoZWo6ICdpZCcpXG4gICAgICAgIGNvZGVGaWVsZDoga2V5b2YgVDsgLy8gKGVqOiAnc2t1JywgJ2N1aXQnKVxuICAgICAgICBuYW1lRmllbGQ6IGtleW9mIFQ7IC8vIChlajogJ25hbWUnKVxuICAgIH07XG4gICAgLyoqIFdoZW4gdGhpcyBtb2R1bGUncyBpdGVtcyBhcmUgc2VsZWN0ZWQgaW4gYSBSZWxhdGlvbmFsSW5wdXQsIGVhY2ggaXRlbSBoYXMgdGhlc2Uga2V5cyBmb3IgY29kZS9uYW1lIChlLmcuIHBsYW5fZGVfY3VlbnRhcyB1c2VzIFwiY29kZVwiL1wibmFtZVwiKS4gRGVmYXVsdHMgdG8gcmVsYXRpb25hbEZpZWxkcyBpZiBub3Qgc2V0LiAqL1xuICAgIGxpc3RJdGVtQ29kZUtleT86IHN0cmluZztcbiAgICBsaXN0SXRlbU5hbWVLZXk/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCB0eXBlIFNlYXJjaFBhcmFtVmFsdWUgPSBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgc3RyaW5nW10gfCBudW1iZXJbXSB8IHVuZGVmaW5lZDtcblxuLy8g4pyFIE5VRVZPOiBTZSBkZWZpbmUgZWwgdGlwbyBwYXJhIGxvcyBwYXLDoW1ldHJvcyBkZSBiw7pzcXVlZGFcbmV4cG9ydCBpbnRlcmZhY2UgU2VhcmNoUGFyYW1zIHtcbiAgICB0ZXJtPzogc3RyaW5nO1xuICAgIHN0YXJ0RGF0ZT86IHN0cmluZztcbiAgICBlbmREYXRlPzogc3RyaW5nO1xuICAgIFtrZXk6IHN0cmluZ106IFNlYXJjaFBhcmFtVmFsdWU7XG59XG5cbmludGVyZmFjZSBHZW5lcmljTGlzdFBhZ2VQcm9wczxUIGV4dGVuZHMgeyBpZDogc3RyaW5nIHwgbnVtYmVyIH0+IHtcbiAgICBjb25maWc6IE1vZHVsZUNvbmZpZzxUPjtcbiAgICBsb2FkaW5nOiBib29sZWFuO1xuICAgIHBhZ2luYXRpb25SZXNwb25zZTogUGFnaW5hdGVkUmVzcG9uc2U8VD4gfCBudWxsO1xuICAgIGlzQXBwZW5kaW5nOiBib29sZWFuO1xuICAgIG9uRGVsZXRlPzogKGlkOiBudW1iZXIgfCBzdHJpbmcpID0+IHZvaWQ7XG4gICAgb25Tb3J0OiAoc29ydEZpZWxkOiBzdHJpbmcpID0+IHZvaWQ7XG4gICAgc29ydEJ5OiBzdHJpbmcgfCBudWxsO1xuICAgIHNvcnREaXJlY3Rpb246ICdhc2MnIHwgJ2Rlc2MnIHwgbnVsbDtcbiAgICBvblBhZ2VDaGFuZ2U6ICh1cmw6IHN0cmluZykgPT4gdm9pZDtcbiAgICBvbkxvYWRNb3JlOiAoKSA9PiB2b2lkO1xuICAgIG9uU2VhcmNoOiAocGFyYW1zOiBTZWFyY2hQYXJhbXMpID0+IHZvaWQ7IC8vIOKchSBDQU1CSU86IG9uU2VhcmNoIGFob3JhIHJlY2liZSB1biBvYmpldG8gZGUgcGFyw6FtZXRyb3NcbiAgICBzZWFyY2hUZXJtOiBzdHJpbmc7XG4gICAgcGVyc2lzdGVkU2VhcmNoUGFyYW1zPzogU2VhcmNoUGFyYW1zO1xuICAgIGFkZGl0aW9uYWxTZWFyY2hNZXJnZT86IFBhcnRpYWw8U2VhcmNoUGFyYW1zPjtcbiAgICByZW5kZXJFeHRyYVNlYXJjaEZpZWxkcz86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgICAvKiogVmFsb3JlcyBkZWwgaG9vayAoc2VhcmNoUGFyYW1zKSBwYXJhIHNpbmNyb25pemFyIGlucHV0cyBEZXNkZS9IYXN0YSBlbiBlbCBwcmltZXIgcmVuZGVyIHkgdHJhcyBCdXNjYXIuICovXG4gICAgZGF0ZUZpbHRlclN0YXJ0Pzogc3RyaW5nO1xuICAgIGRhdGVGaWx0ZXJFbmQ/OiBzdHJpbmc7XG4gICAgZW5hYmxlRGF0ZVJhbmdlRmlsdGVyPzogYm9vbGVhbjsgLy8g4pyFIE5VRVZPOiBQcm9wIHBhcmEgaGFiaWxpdGFyIGVsIGZpbHRybyBkZSBmZWNoYVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgb25Sb3dDbGljaz86IChpdGVtOiBhbnkpID0+IHZvaWQ7XG4gICAgY2FuRWRpdD86IGJvb2xlYW4gfCAoKGl0ZW06IFQpID0+IGJvb2xlYW4pOyAvLyDinIUgUGVybWlzbyBwYXJhIGVkaXRhciAocHVlZGUgc2VyIGZ1bmNpw7NuLCBvcGNpb25hbClcbiAgICBjYW5EZWxldGU/OiBib29sZWFuIHwgKChpdGVtOiBUKSA9PiBib29sZWFuKTsgLy8g4pyFIFBlcm1pc28gcGFyYSBlbGltaW5hciAocHVlZGUgc2VyIGZ1bmNpw7NuLCBvcGNpb25hbClcbiAgICAvKiogQm90b25lcyBleHRyYSBlbiBsYSBjYWJlY2VyYSAoZWouIG1hc2l2b3MpLCBqdW50byBhIENyZWFyIGN1YW5kbyBleGlzdGEuICovXG4gICAgYWRkaXRpb25hbEhlYWRlckJ1dHRvbnM/OiBSZWFjdC5SZWFjdE5vZGU7XG4gICAgZW5hYmxlUm93U2VsZWN0aW9uPzogYm9vbGVhbjtcbiAgICBzZWxlY3RlZElkcz86IFNldDxudW1iZXI+O1xuICAgIG9uVG9nZ2xlUm93PzogKGlkOiBudW1iZXIpID0+IHZvaWQ7XG4gICAgb25Ub2dnbGVQYWdlPzogKGlkczogbnVtYmVyW10sIGNoZWNrZWQ6IGJvb2xlYW4pID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBHZW5lcmljTGlzdFBhZ2UgPSA8VCBleHRlbmRzIHsgaWQ6IHN0cmluZyB8IG51bWJlciB9Pih7XG4gICAgY29uZmlnLFxuICAgIGxvYWRpbmcsXG4gICAgcGFnaW5hdGlvblJlc3BvbnNlLFxuICAgIGlzQXBwZW5kaW5nLFxuICAgIG9uRGVsZXRlLFxuICAgIG9uU29ydCxcbiAgICBzb3J0QnksXG4gICAgc29ydERpcmVjdGlvbixcbiAgICBvblBhZ2VDaGFuZ2UsXG4gICAgb25Mb2FkTW9yZSxcbiAgICBvblNlYXJjaCxcbiAgICBzZWFyY2hUZXJtLFxuICAgIHBlcnNpc3RlZFNlYXJjaFBhcmFtcyxcbiAgICBhZGRpdGlvbmFsU2VhcmNoTWVyZ2UsXG4gICAgcmVuZGVyRXh0cmFTZWFyY2hGaWVsZHMsXG4gICAgZGF0ZUZpbHRlclN0YXJ0ID0gJycsXG4gICAgZGF0ZUZpbHRlckVuZCA9ICcnLFxuICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlciA9IGZhbHNlLCAvLyDinIUgTlVFVk86IFZhbG9yIHBvciBkZWZlY3RvXG4gICAgb25Sb3dDbGljayxcbiAgICBjYW5FZGl0OiBjYW5FZGl0UHJvcCwgLy8g4pyFIFByb3Agb3BjaW9uYWwgcXVlIHB1ZWRlIHNvYnJlc2NyaWJpciBsb3MgcGVybWlzb3NcbiAgICBjYW5EZWxldGU6IGNhbkRlbGV0ZVByb3AsIC8vIOKchSBQcm9wIG9wY2lvbmFsIHF1ZSBwdWVkZSBzb2JyZXNjcmliaXIgbG9zIHBlcm1pc29zXG4gICAgYWRkaXRpb25hbEhlYWRlckJ1dHRvbnMsXG4gICAgZW5hYmxlUm93U2VsZWN0aW9uID0gZmFsc2UsXG4gICAgc2VsZWN0ZWRJZHMsXG4gICAgb25Ub2dnbGVSb3csXG4gICAgb25Ub2dnbGVQYWdlLFxufTogR2VuZXJpY0xpc3RQYWdlUHJvcHM8VD4pID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpOyAvLyDinIUgQWdyZWdhciBob29rXG4gICAgY29uc3QgW2xvY2FsU2VhcmNoLCBzZXRMb2NhbFNlYXJjaF0gPSB1c2VTdGF0ZShzZWFyY2hUZXJtKTtcblxuICAgIC8vIOKchSBOVUVWTzogRXN0YWRvcyBwYXJhIGVsIHJhbmdvIGRlIGZlY2hhc1xuICAgIGNvbnN0IFtzdGFydERhdGUsIHNldFN0YXJ0RGF0ZV0gPSB1c2VTdGF0ZShkYXRlRmlsdGVyU3RhcnQpO1xuICAgIGNvbnN0IFtlbmREYXRlLCBzZXRFbmREYXRlXSA9IHVzZVN0YXRlKGRhdGVGaWx0ZXJFbmQpO1xuXG4gICAgLy8gU2luY3Jvbml6YSBlbCB0w6lybWlubyBkZSBiw7pzcXVlZGEgbG9jYWwgc2kgY2FtYmlhIGV4dGVybmFtZW50ZVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldExvY2FsU2VhcmNoKHNlYXJjaFRlcm0pO1xuICAgIH0sIFtzZWFyY2hUZXJtXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRTdGFydERhdGUoZGF0ZUZpbHRlclN0YXJ0KTtcbiAgICAgICAgc2V0RW5kRGF0ZShkYXRlRmlsdGVyRW5kKTtcbiAgICB9LCBbZGF0ZUZpbHRlclN0YXJ0LCBkYXRlRmlsdGVyRW5kXSk7XG5cbiAgICAvLyDinIUgT2J0ZW5lciBlbCBtw7NkdWxvIGJhc2UgcGFyYSB2YWxpZGFyIHBlcm1pc29zXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihjb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBjYW5DcmVhdGUgPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnY3JlYXRlJykgOiB0cnVlO1xuXG4gICAgY29uc3QgaGFuZGxlQ3JlYXRlTmV3ID0gKCkgPT4ge1xuICAgICAgICBuYXZpZ2F0ZShgJHtjb25maWcuYmFzZVJvdXRlfS9udWV2b2ApO1xuICAgIH07XG5cbiAgICAvLyDinIUgQ0FNQklPOiBFbCBzdWJtaXQgYWhvcmEgZW52w61hIHRvZG9zIGxvcyBwYXLDoW1ldHJvcyBkZSBiw7pzcXVlZGFcbiAgICBjb25zdCBoYW5kbGVTZWFyY2hTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgb25TZWFyY2goe1xuICAgICAgICAgICAgLi4uKHBlcnNpc3RlZFNlYXJjaFBhcmFtcyA/PyB7fSksXG4gICAgICAgICAgICB0ZXJtOiBsb2NhbFNlYXJjaCxcbiAgICAgICAgICAgIHN0YXJ0RGF0ZSxcbiAgICAgICAgICAgIGVuZERhdGUsXG4gICAgICAgICAgICAuLi4oYWRkaXRpb25hbFNlYXJjaE1lcmdlID8/IHt9KSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IHBhZ2luYXRpb25SZXNwb25zZT8uZGF0YSA/PyBbXTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyIHkgZWxpbWluYXIgKHNpIG5vIHNlIHBhc2FuIHByb3BzIHBlcnNvbmFsaXphZGFzKVxuICAgIGNvbnN0IGRlZmF1bHRDYW5FZGl0ID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG4gICAgY29uc3QgZGVmYXVsdENhbkRlbGV0ZSA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdkZWxldGUnKSA6IHRydWU7XG5cbiAgICAvLyDinIUgVXNhciBsYXMgcHJvcHMgcGVyc29uYWxpemFkYXMgc2kgZXhpc3Rlbiwgc2lubyB1c2FyIGxvcyBwZXJtaXNvcyBwb3IgZGVmZWN0b1xuICAgIGNvbnN0IGNhbkVkaXQgPSBjYW5FZGl0UHJvcCAhPT0gdW5kZWZpbmVkID8gY2FuRWRpdFByb3AgOiBkZWZhdWx0Q2FuRWRpdDtcbiAgICBjb25zdCBjYW5EZWxldGUgPSBjYW5EZWxldGVQcm9wICE9PSB1bmRlZmluZWQgPyBjYW5EZWxldGVQcm9wIDogZGVmYXVsdENhbkRlbGV0ZTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5MaXN0YWRvIGRlIHtjb25maWcubW9kdWxlTmFtZVBsdXJhbH08L2gxPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHsoY2FuQ3JlYXRlIHx8IGFkZGl0aW9uYWxIZWFkZXJCdXR0b25zKSA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtNCBzbTpmbGV4LW5vd3JhcCBzbTptdC0wIHNtOm1sLTQgc206ZmxleC1ub25lIHNtOmp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkaXRpb25hbEhlYWRlckJ1dHRvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FuQ3JlYXRlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDcmVhdGVOZXd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgc206dy1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb25maWcubW9kdWxlTmFtZSA9PT0gJ0NvbXByYScgPyAnSW5ncmVzYXIgQ29tcHJvYmFudGUgZGUgQ29tcHJhJyA6ICdDcmVhciAnICsgY29uZmlnLm1vZHVsZU5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7Lyog4pyFIENBTUJJTzogRWwgZm9ybXVsYXJpbyBkZSBiw7pzcXVlZGEgYWhvcmEgaW5jbHV5ZSBsb3MgZmlsdHJvcyBkZSBmZWNoYSAqL31cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTZWFyY2hTdWJtaXR9IGNsYXNzTmFtZT1cInAtNCBtdC00IGJnLWdyYXktNTAgYm9yZGVyIHJvdW5kZWQtbGdcIiBhdXRvQ29tcGxldGU9XCJvZmZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgICAge2VuYWJsZURhdGVSYW5nZUZpbHRlciA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSBSZW9yZ2FuaXphZG86IEZlY2hhcyBwcmltZXJvIHBhcmEgbWVqb3IgdXNhYmlsaWRhZCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInN0YXJ0LWRhdGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5EZXNkZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzdGFydC1kYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdGFydERhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN0YXJ0RGF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW5kLWRhdGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5IYXN0YTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbmQtZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5kRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW5kRGF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic2VhcmNoLXRlcm1cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5CdXNjYXI8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggbXQtMSByb3VuZGVkLW1kIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VhcmNoLXRlcm1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtsb2NhbFNlYXJjaH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExvY2FsU2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2Nhci4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWwtbWQgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIC1tbC1weCBzcGFjZS14LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1yLW1kIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNlYXJjaCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJ1c2Nhcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJzZWFyY2gtdGVybVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkJ1c2NhcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IG10LTEgcm91bmRlZC1tZCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInNlYXJjaC10ZXJtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtsb2NhbFNlYXJjaH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TG9jYWxTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbC1tZCBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiAtbWwtcHggc3BhY2UteC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtci1tZCBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU2VhcmNoIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CdXNjYXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge3JlbmRlckV4dHJhU2VhcmNoRmllbGRzID8gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTQgbXQtNCBtZDpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckV4dHJhU2VhcmNoRmllbGRzfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XG4gICAgICAgICAgICAgICAge2xvYWRpbmcgJiYgIWlzQXBwZW5kaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgICAgICAgICAgICAgICApIDogZGF0YS5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8R2VuZXJpY1RhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2RhdGF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbmZpZy5saXN0LmNvbHVtbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2VSb3V0ZT17Y29uZmlnLmJhc2VSb3V0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9e29uRGVsZXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNvcnQ9e29uU29ydH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVFZGl0PXtjb25maWcuZGlzYWJsZUVkaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb25NZXRhPXtwYWdpbmF0aW9uUmVzcG9uc2U/Lm1ldGEgPz8gbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVBY3Rpb25zPXtjb25maWcuZGlzYWJsZUFjdGlvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUm93Q2xpY2s9e29uUm93Q2xpY2t9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbkVkaXQ9e2NhbkVkaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbkRlbGV0ZT17Y2FuRGVsZXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmFibGVSb3dTZWxlY3Rpb249e2VuYWJsZVJvd1NlbGVjdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJZHM9e3NlbGVjdGVkSWRzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblRvZ2dsZVJvdz17b25Ub2dnbGVSb3d9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlUGFnZT17b25Ub2dnbGVQYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvY2sgbGc6aGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEdlbmVyaWNDYXJkTGlzdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtkYXRhfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb25maWcubGlzdC5jb2x1bW5zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlUm91dGU9e2NvbmZpZy5iYXNlUm91dGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXtvbkRlbGV0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnaW5hdGlvbkxpbmtzPXtwYWdpbmF0aW9uUmVzcG9uc2U/LmxpbmtzID8/IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Mb2FkTW9yZT17b25Mb2FkTW9yZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Tb3J0PXtvblNvcnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlRWRpdD17Y29uZmlnLmRpc2FibGVFZGl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblJvd0NsaWNrPXtvblJvd0NsaWNrfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5FZGl0PXtjYW5FZGl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5EZWxldGU9e2NhbkRlbGV0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5hYmxlUm93U2VsZWN0aW9uPXtlbmFibGVSb3dTZWxlY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSWRzPXtzZWxlY3RlZElkc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Ub2dnbGVSb3c9e29uVG9nZ2xlUm93fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblRvZ2dsZVBhZ2U9e29uVG9nZ2xlUGFnZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICFsb2FkaW5nICYmIDxOb0RhdGFNZXNzYWdlIG1vZHVsZU5hbWU9e2NvbmZpZy5tb2R1bGVOYW1lUGx1cmFsLnRvTG93ZXJDYXNlKCl9IC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlLnRzeCJ9