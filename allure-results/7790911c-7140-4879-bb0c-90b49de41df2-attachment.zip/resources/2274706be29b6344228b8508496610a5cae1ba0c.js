import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/pages/ArticulosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/pages/ArticulosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { EntityDetailPageLayout } from "/src/components/common/EntityDetailPageLayout.tsx";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
const ArticuloDetailContent = ({ config, item }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(GenericDetailPage, { config, item, hideHeader: true }, void 0, false, {
      fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
      lineNumber: 37,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-2 bg-gray-50 rounded-t-md", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: "Impuestos Aplicados al Producto" }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 42,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 41,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: item.relatedTaxes && item.relatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 space-y-2", children: item.relatedTaxes.map(
        (tax) => /* @__PURE__ */ jsxDEV("li", { className: "text-base text-gray-900", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: tax.name }, void 0, false, {
            fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
            lineNumber: 50,
            columnNumber: 37
          }, this),
          " (",
          tax.rate,
          "%)"
        ] }, tax.id, true, {
          fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
          lineNumber: 49,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 47,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Este producto no tiene impuestos específicos asignados." }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 44,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
      lineNumber: 40,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
};
_c = ArticuloDetailContent;
export const ArticuloDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: articulo, loading, error } = useCrudItem(articulosModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del artículo..." }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
    lineNumber: 68,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
    lineNumber: 69,
    columnNumber: 21
  }, this);
  if (!articulo) return /* @__PURE__ */ jsxDEV("div", { children: "Artículo no encontrado." }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
    lineNumber: 70,
    columnNumber: 25
  }, this);
  const tabs = [
    { id: "details", name: "Detalles" },
    { id: "movements", name: "Movimientos de Stock" }
  ];
  return /* @__PURE__ */ jsxDEV(
    EntityDetailPageLayout,
    {
      config: articulosModuleConfig,
      item: articulo,
      entityType: "product",
      customDetailComponent: /* @__PURE__ */ jsxDEV(ArticuloDetailContent, { config: articulosModuleConfig, item: articulo }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
        lineNumber: 83,
        columnNumber: 30
      }, this),
      tabs
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/articulos/pages/ArticulosDetailPage.tsx",
      lineNumber: 79,
      columnNumber: 5
    },
    this
  );
};
_s(ArticuloDetailPage, "mpSUQAolkRZGTw+tDUUcmyOwymY=", false, function() {
  return [useParams, useCrudItem];
});
_c2 = ArticuloDetailPage;
var _c, _c2;
$RefreshReg$(_c, "ArticuloDetailContent");
$RefreshReg$(_c2, "ArticuloDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/pages/ArticulosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/pages/ArticulosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCWixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsNkJBQTRDO0FBQ3JELFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MseUJBQXlCO0FBUWxDLE1BQU1DLHdCQUE4REEsQ0FBQyxFQUFFQyxRQUFRQyxLQUFLLE1BQU07QUFDdEYsU0FDSSx1QkFBQyxTQUVHO0FBQUEsMkJBQUMscUJBQWtCLFFBQWdCLE1BQVksWUFBWSxRQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFHaEUsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVFQUNYLGlDQUFDLFFBQUcsV0FBVSxxQ0FBb0MsK0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUYsS0FEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FFVkEsZUFBS0MsZ0JBQWdCRCxLQUFLQyxhQUFhQyxTQUFTLElBQzdDLHVCQUFDLFFBQUcsV0FBVSw0QkFDVEYsZUFBS0MsYUFBYUU7QUFBQUEsUUFBSSxDQUFBQyxRQUNuQix1QkFBQyxRQUFnQixXQUFVLDJCQUN2QjtBQUFBLGlDQUFDLFVBQUssV0FBVSxlQUFlQSxjQUFJQyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQU87QUFBQSxVQUFHRCxJQUFJRTtBQUFBQSxVQUFLO0FBQUEsYUFEdERGLElBQUlHLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFDSCxLQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsdUVBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEYsS0FYcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLE9BdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFUjtBQUFFQyxLQTVCSVY7QUE4QkMsYUFBTVcscUJBQXFCQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxFQUFFSCxHQUFHLElBQUlkLFVBQTBCO0FBRXpDLFFBQU0sRUFBRU8sTUFBTVcsVUFBVUMsU0FBU0MsTUFBTSxJQUFJbEIsWUFBc0JELHVCQUF1QmEsRUFBRTtBQUUxRixNQUFJSyxRQUFTLFFBQU8sdUJBQUMsU0FBSSxnREFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3pELE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLFNBQVUsUUFBTyx1QkFBQyxTQUFJLHVDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEI7QUFFbEQsUUFBTUcsT0FBTztBQUFBLElBQ1QsRUFBRVAsSUFBSSxXQUFXRixNQUFNLFdBQVc7QUFBQSxJQUNsQyxFQUFFRSxJQUFJLGFBQWFGLE1BQU0sdUJBQXVCO0FBQUEsRUFBQztBQUlyRCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRWDtBQUFBQSxNQUNSLE1BQU1pQjtBQUFBQSxNQUNOLFlBQVc7QUFBQSxNQUNYLHVCQUF1Qix1QkFBQyx5QkFBc0IsUUFBUWpCLHVCQUF1QixNQUFNaUIsWUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQzVGO0FBQUE7QUFBQSxJQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtlO0FBR3ZCO0FBQUVELEdBeEJXRCxvQkFBa0I7QUFBQSxVQUNaaEIsV0FFNEJFLFdBQVc7QUFBQTtBQUFBb0IsTUFIN0NOO0FBQWtCLElBQUFELElBQUFPO0FBQUFDLGFBQUFSLElBQUE7QUFBQVEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsImFydGljdWxvc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiRW50aXR5RGV0YWlsUGFnZUxheW91dCIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiQXJ0aWN1bG9EZXRhaWxDb250ZW50IiwiY29uZmlnIiwiaXRlbSIsInJlbGF0ZWRUYXhlcyIsImxlbmd0aCIsIm1hcCIsInRheCIsIm5hbWUiLCJyYXRlIiwiaWQiLCJfYyIsIkFydGljdWxvRGV0YWlsUGFnZSIsIl9zIiwiYXJ0aWN1bG8iLCJsb2FkaW5nIiwiZXJyb3IiLCJ0YWJzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFydGljdWxvc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCB0eXBlIEFydGljdWxvIH0gZnJvbSAnLi4vYXJ0aWN1bG9zLmNvbmZpZy50c3gnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbS50cyc7XG4vLyDinIUgTlVFVk86IFNlIGltcG9ydGEgZWwgbGF5b3V0IGdlbsOpcmljbyBkZSBkZXRhbGxlXG5pbXBvcnQgeyBFbnRpdHlEZXRhaWxQYWdlTGF5b3V0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vRW50aXR5RGV0YWlsUGFnZUxheW91dC50c3gnO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZS50c3gnOyAvLyDinIUgMS4gSU1QT1JUQU1PUyBFTCBERVRBTExFIEdFTsOJUklDT1xuXG5cbmludGVyZmFjZSBBcnRpY3Vsb0RldGFpbENvbnRlbnRQcm9wcyB7XG4gICAgY29uZmlnOiB0eXBlb2YgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnO1xuICAgIGl0ZW06IEFydGljdWxvO1xufVxuXG5jb25zdCBBcnRpY3Vsb0RldGFpbENvbnRlbnQ6IFJlYWN0LkZDPEFydGljdWxvRGV0YWlsQ29udGVudFByb3BzPiA9ICh7IGNvbmZpZywgaXRlbSB9KSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHsvKiBSZW5kZXJpemEgdG9kb3MgbG9zIGNhbXBvcyBkZSAnYXJ0aWN1bG9zLmNvbmZpZy50c3gnICovfVxuICAgICAgICAgICAgPEdlbmVyaWNEZXRhaWxQYWdlIGNvbmZpZz17Y29uZmlnfSBpdGVtPXtpdGVtfSBoaWRlSGVhZGVyPXt0cnVlfSAvPlxuXG4gICAgICAgICAgICB7LyogWSBBREVNw4FTLCByZW5kZXJpemEgbnVlc3RybyBibG9xdWUgZGUgaW1wdWVzdG9zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJvcmRlciByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCBweS0yIGJnLWdyYXktNTAgcm91bmRlZC10LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgQXBsaWNhZG9zIGFsIFByb2R1Y3RvPC9oND5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQXF1w60gdXNhbW9zIGl0ZW0ucmVsYXRlZFRheGVzIHF1ZSB2aWVuZSBkZSBsYSBBUEkgKi99XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlbGF0ZWRUYXhlcyAmJiBpdGVtLnJlbGF0ZWRUYXhlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBwbC01IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlbGF0ZWRUYXhlcy5tYXAodGF4ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17dGF4LmlkfSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57dGF4Lm5hbWV9PC9zcGFuPiAoe3RheC5yYXRlfSUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+RXN0ZSBwcm9kdWN0byBubyB0aWVuZSBpbXB1ZXN0b3MgZXNwZWPDrWZpY29zIGFzaWduYWRvcy48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBBcnRpY3Vsb0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuXG4gICAgY29uc3QgeyBpdGVtOiBhcnRpY3VsbywgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPEFydGljdWxvPihhcnRpY3Vsb3NNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkZXRhbGxlIGRlbCBhcnTDrWN1bG8uLi48L2Rpdj47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghYXJ0aWN1bG8pIHJldHVybiA8ZGl2PkFydMOtY3VsbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IHRhYnMgPSBbXG4gICAgICAgIHsgaWQ6ICdkZXRhaWxzJywgbmFtZTogJ0RldGFsbGVzJyB9LFxuICAgICAgICB7IGlkOiAnbW92ZW1lbnRzJywgbmFtZTogJ01vdmltaWVudG9zIGRlIFN0b2NrJyB9LFxuICAgIF07XG5cbiAgICAvLyDinIUgQ0FNQklPOiBTZSB1dGlsaXphIGVsIG51ZXZvIGxheW91dCBjb24gcGVzdGHDsWFzXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEVudGl0eURldGFpbFBhZ2VMYXlvdXRcbiAgICAgICAgICAgIGNvbmZpZz17YXJ0aWN1bG9zTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgaXRlbT17YXJ0aWN1bG99XG4gICAgICAgICAgICBlbnRpdHlUeXBlPVwicHJvZHVjdFwiXG4gICAgICAgICAgICBjdXN0b21EZXRhaWxDb21wb25lbnQ9ezxBcnRpY3Vsb0RldGFpbENvbnRlbnQgY29uZmlnPXthcnRpY3Vsb3NNb2R1bGVDb25maWd9IGl0ZW09e2FydGljdWxvfSAvPn1cbiAgICAgICAgICAgIHRhYnM9e3RhYnN9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2FydGljdWxvcy9wYWdlcy9BcnRpY3Vsb3NEZXRhaWxQYWdlLnRzeCJ9