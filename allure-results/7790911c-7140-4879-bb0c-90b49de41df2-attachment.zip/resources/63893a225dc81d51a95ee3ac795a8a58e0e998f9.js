import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/PermissionRoute.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/routes/PermissionRoute.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useAuth } from "/src/hooks/useAuth.ts";
import { getRequiredPermission, hasPermission, getModuleBasePermission, hasModulePermission } from "/src/utils/permissions.ts";
import { NoAccessMessage } from "/src/components/ui/NoAccessMessage.tsx";
export const PermissionRoute = ({ children, requiredPermission, action, baseRoute }) => {
  _s();
  const { isAuthenticated, permissions } = useAuth();
  const location = useLocation();
  if (!isAuthenticated) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", state: { from: location } }, void 0, false, {
      fileName: "/app/src/routes/PermissionRoute.tsx",
      lineNumber: 37,
      columnNumber: 12
    }, this);
  }
  if (action && baseRoute) {
    const modulePermission = getRequiredPermission(baseRoute);
    const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
    if (moduleBase && !hasModulePermission(permissions, moduleBase, action)) {
      const actionMessages = {
        view: "ver",
        create: "crear",
        edit: "editar",
        delete: "eliminar"
      };
      return /* @__PURE__ */ jsxDEV(NoAccessMessage, { message: `No tienes permisos para ${actionMessages[action]} en este módulo.` }, void 0, false, {
        fileName: "/app/src/routes/PermissionRoute.tsx",
        lineNumber: 52,
        columnNumber: 14
      }, this);
    }
    return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
      fileName: "/app/src/routes/PermissionRoute.tsx",
      lineNumber: 55,
      columnNumber: 12
    }, this);
  }
  const permission = requiredPermission || getRequiredPermission(location.pathname);
  if (permission && !hasPermission(permissions, permission)) {
    return /* @__PURE__ */ jsxDEV(NoAccessMessage, { message: "No tienes permisos para acceder a esta sección." }, void 0, false, {
      fileName: "/app/src/routes/PermissionRoute.tsx",
      lineNumber: 62,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "/app/src/routes/PermissionRoute.tsx",
    lineNumber: 65,
    columnNumber: 10
  }, this);
};
_s(PermissionRoute, "gA2qISQ8XYSfSyYuyn2Et9B2cAw=", false, function() {
  return [useAuth, useLocation];
});
_c = PermissionRoute;
var _c;
$RefreshReg$(_c, "PermissionRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/routes/PermissionRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/routes/PermissionRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJlLFNBa0JBLFVBbEJBOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCZixTQUFTQSxVQUFVQyxtQkFBbUI7QUFDdEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyx1QkFBdUJDLGVBQWVDLHlCQUF5QkMsMkJBQTJCO0FBQ25HLFNBQVNDLHVCQUF1QjtBQVN6QixhQUFNQyxrQkFBa0JBLENBQUMsRUFBRUMsVUFBVUMsb0JBQW9CQyxRQUFRQyxVQUFnQyxNQUFNO0FBQUFDLEtBQUE7QUFDMUcsUUFBTSxFQUFFQyxpQkFBaUJDLFlBQVksSUFBSWIsUUFBUTtBQUNqRCxRQUFNYyxXQUFXZixZQUFZO0FBRTdCLE1BQUksQ0FBQ2EsaUJBQWlCO0FBQ2xCLFdBQU8sdUJBQUMsWUFBUyxJQUFHLFVBQVMsT0FBTyxFQUFFRyxNQUFNRCxTQUFTLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Q7QUFBQSxFQUMzRDtBQUdBLE1BQUlMLFVBQVVDLFdBQVc7QUFDckIsVUFBTU0sbUJBQW1CZixzQkFBc0JTLFNBQVM7QUFDeEQsVUFBTU8sYUFBYUQsbUJBQW1CYix3QkFBd0JhLGdCQUFnQixJQUFJO0FBRWxGLFFBQUlDLGNBQWMsQ0FBQ2Isb0JBQW9CUyxhQUFhSSxZQUFZUixNQUFNLEdBQUc7QUFDckUsWUFBTVMsaUJBQWlCO0FBQUEsUUFDbkJDLE1BQU07QUFBQSxRQUNOQyxRQUFRO0FBQUEsUUFDUkMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxNQUNaO0FBQ0EsYUFBTyx1QkFBQyxtQkFBZ0IsU0FBUywyQkFBMkJKLGVBQWVULE1BQU0sQ0FBQyxzQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLElBQ3pHO0FBRUEsV0FBTyxtQ0FBR0YsWUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxFQUN2QjtBQUdBLFFBQU1nQixhQUFhZixzQkFBc0JQLHNCQUFzQmEsU0FBU1UsUUFBUTtBQUVoRixNQUFJRCxjQUFjLENBQUNyQixjQUFjVyxhQUFhVSxVQUFVLEdBQUc7QUFDdkQsV0FBTyx1QkFBQyxtQkFBZ0IsU0FBUSxxREFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRTtBQUFBLEVBQ3JGO0FBRUEsU0FBTyxtQ0FBR2hCLFlBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFZO0FBQ3ZCO0FBQUVJLEdBbENXTCxpQkFBZTtBQUFBLFVBQ2lCTixTQUN4QkQsV0FBVztBQUFBO0FBQUEwQixLQUZuQm5CO0FBQWUsSUFBQW1CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsInVzZUxvY2F0aW9uIiwidXNlQXV0aCIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImhhc1Blcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJOb0FjY2Vzc01lc3NhZ2UiLCJQZXJtaXNzaW9uUm91dGUiLCJjaGlsZHJlbiIsInJlcXVpcmVkUGVybWlzc2lvbiIsImFjdGlvbiIsImJhc2VSb3V0ZSIsIl9zIiwiaXNBdXRoZW50aWNhdGVkIiwicGVybWlzc2lvbnMiLCJsb2NhdGlvbiIsImZyb20iLCJtb2R1bGVQZXJtaXNzaW9uIiwibW9kdWxlQmFzZSIsImFjdGlvbk1lc3NhZ2VzIiwidmlldyIsImNyZWF0ZSIsImVkaXQiLCJkZWxldGUiLCJwZXJtaXNzaW9uIiwicGF0aG5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZXJtaXNzaW9uUm91dGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2hvb2tzL3VzZUF1dGgnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBoYXNQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiwgaGFzTW9kdWxlUGVybWlzc2lvbiB9IGZyb20gJy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IE5vQWNjZXNzTWVzc2FnZSB9IGZyb20gJy4uL2NvbXBvbmVudHMvdWkvTm9BY2Nlc3NNZXNzYWdlJztcblxuaW50ZXJmYWNlIFBlcm1pc3Npb25Sb3V0ZVByb3BzIHtcbiAgICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICAgIHJlcXVpcmVkUGVybWlzc2lvbj86IHN0cmluZzsgLy8gUGVybWlzbyBlc3BlY8OtZmljbyAob3BjaW9uYWwpXG4gICAgYWN0aW9uPzogJ3ZpZXcnIHwgJ2NyZWF0ZScgfCAnZWRpdCcgfCAnZGVsZXRlJzsgLy8g4pyFIE5VRVZPOiBBY2Npw7NuIGEgdmFsaWRhclxuICAgIGJhc2VSb3V0ZT86IHN0cmluZzsgLy8g4pyFIE5VRVZPOiBSdXRhIGJhc2UgZGVsIG3Ds2R1bG8gKHBhcmEgdXNhciBjb24gYWN0aW9uKVxufVxuXG5leHBvcnQgY29uc3QgUGVybWlzc2lvblJvdXRlID0gKHsgY2hpbGRyZW4sIHJlcXVpcmVkUGVybWlzc2lvbiwgYWN0aW9uLCBiYXNlUm91dGUgfTogUGVybWlzc2lvblJvdXRlUHJvcHMpID0+IHtcbiAgICBjb25zdCB7IGlzQXV0aGVudGljYXRlZCwgcGVybWlzc2lvbnMgfSA9IHVzZUF1dGgoKTtcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgICBpZiAoIWlzQXV0aGVudGljYXRlZCkge1xuICAgICAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgc3RhdGU9e3sgZnJvbTogbG9jYXRpb24gfX0gLz47XG4gICAgfVxuXG4gICAgLy8g4pyFIE5VRVZPOiBTaSBzZSBwcm9wb3JjaW9uYSBhY3Rpb24geSBiYXNlUm91dGUsIHZhbGlkYXIgcGVybWlzbyBkZSBtw7NkdWxvXG4gICAgaWYgKGFjdGlvbiAmJiBiYXNlUm91dGUpIHtcbiAgICAgICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihiYXNlUm91dGUpO1xuICAgICAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICAgICAgXG4gICAgICAgIGlmIChtb2R1bGVCYXNlICYmICFoYXNNb2R1bGVQZXJtaXNzaW9uKHBlcm1pc3Npb25zLCBtb2R1bGVCYXNlLCBhY3Rpb24pKSB7XG4gICAgICAgICAgICBjb25zdCBhY3Rpb25NZXNzYWdlcyA9IHtcbiAgICAgICAgICAgICAgICB2aWV3OiAndmVyJyxcbiAgICAgICAgICAgICAgICBjcmVhdGU6ICdjcmVhcicsXG4gICAgICAgICAgICAgICAgZWRpdDogJ2VkaXRhcicsXG4gICAgICAgICAgICAgICAgZGVsZXRlOiAnZWxpbWluYXInXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgcmV0dXJuIDxOb0FjY2Vzc01lc3NhZ2UgbWVzc2FnZT17YE5vIHRpZW5lcyBwZXJtaXNvcyBwYXJhICR7YWN0aW9uTWVzc2FnZXNbYWN0aW9uXX0gZW4gZXN0ZSBtw7NkdWxvLmB9IC8+O1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICByZXR1cm4gPD57Y2hpbGRyZW59PC8+O1xuICAgIH1cblxuICAgIC8vIEzDs2dpY2Egb3JpZ2luYWwgcGFyYSBwZXJtaXNvcyBlc3BlY8OtZmljb3NcbiAgICBjb25zdCBwZXJtaXNzaW9uID0gcmVxdWlyZWRQZXJtaXNzaW9uIHx8IGdldFJlcXVpcmVkUGVybWlzc2lvbihsb2NhdGlvbi5wYXRobmFtZSk7XG5cbiAgICBpZiAocGVybWlzc2lvbiAmJiAhaGFzUGVybWlzc2lvbihwZXJtaXNzaW9ucywgcGVybWlzc2lvbikpIHtcbiAgICAgICAgcmV0dXJuIDxOb0FjY2Vzc01lc3NhZ2UgbWVzc2FnZT1cIk5vIHRpZW5lcyBwZXJtaXNvcyBwYXJhIGFjY2VkZXIgYSBlc3RhIHNlY2Npw7NuLlwiIC8+O1xuICAgIH1cblxuICAgIHJldHVybiA8PntjaGlsZHJlbn08Lz47XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9yb3V0ZXMvUGVybWlzc2lvblJvdXRlLnRzeCJ9