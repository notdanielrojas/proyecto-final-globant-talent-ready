import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/impuestos/pages/ImpuestosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport4_react["useState"]; const useCallback = __vite__cjsImport4_react["useCallback"];
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { taxesModuleConfig } from "/src/features/impuestos/impuestos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { RetentionProfilesEditorModal } from "/src/features/impuestos/components/RetentionProfilesEditorModal.tsx";
export const ImpuestosDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error, fetchItem } = useCrudItem(taxesModuleConfig, id);
  const { hasModulePermission: hasPerm } = usePermissions();
  const [retentionModalOpen, setRetentionModalOpen] = useState(false);
  const modulePermission = getRequiredPermission(taxesModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEditTaxes = moduleBase ? hasPerm(moduleBase, "edit") : true;
  const handleRetentionSaved = useCallback(() => {
    void fetchItem();
  }, [fetchItem]);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del impuesto..." }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
    lineNumber: 43,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
    lineNumber: 44,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Impuesto no encontrado." }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
    lineNumber: 45,
    columnNumber: 21
  }, this);
  const taxIdNum = Number(item.id);
  const showRetentionButton = item.type === 3 && !Number.isNaN(taxIdNum);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      GenericDetailPage,
      {
        config: taxesModuleConfig,
        item,
        renderHeaderActions: showRetentionButton ? () => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setRetentionModalOpen(true),
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: "Tabla de retención"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
            lineNumber: 58,
            columnNumber: 9
          },
          this
        ) : void 0
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
        lineNumber: 52,
        columnNumber: 13
      },
      this
    ),
    showRetentionButton && retentionModalOpen && /* @__PURE__ */ jsxDEV(
      RetentionProfilesEditorModal,
      {
        isOpen: retentionModalOpen,
        taxId: taxIdNum,
        canEdit: canEditTaxes,
        onClose: () => setRetentionModalOpen(false),
        onSaved: handleRetentionSaved
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
        lineNumber: 70,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
};
_s(ImpuestosDetailPage, "4A7giTDfY0sJEvZi1sTh6RQO2no=", false, function() {
  return [useParams, useCrudItem, usePermissions];
});
_c = ImpuestosDetailPage;
var _c;
$RefreshReg$(_c, "ImpuestosDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/impuestos/pages/ImpuestosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJ3QixTQVFoQixVQVJnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF2QnhCLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxVQUFVQyxtQkFBbUI7QUFDdEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHlCQUFtQztBQUM1QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLG9DQUFvQztBQUV0QyxhQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVosVUFBMEI7QUFDekMsUUFBTSxFQUFFYSxNQUFNQyxTQUFTQyxPQUFPQyxVQUFVLElBQUlYLFlBQWlCRCxtQkFBbUJRLEVBQUU7QUFDbEYsUUFBTSxFQUFFSyxxQkFBcUJDLFFBQVEsSUFBSVosZUFBZTtBQUN4RCxRQUFNLENBQUNhLG9CQUFvQkMscUJBQXFCLElBQUluQixTQUFTLEtBQUs7QUFFbEUsUUFBTW9CLG1CQUFtQmQsc0JBQXNCSCxrQkFBa0JrQixTQUFTO0FBQzFFLFFBQU1DLGFBQWFGLG1CQUFtQmIsd0JBQXdCYSxnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxlQUFlRCxhQUFhTCxRQUFRSyxZQUFZLE1BQU0sSUFBSTtBQUVoRSxRQUFNRSx1QkFBdUJ2QixZQUFZLE1BQU07QUFDM0MsU0FBS2MsVUFBVTtBQUFBLEVBQ25CLEdBQUcsQ0FBQ0EsU0FBUyxDQUFDO0FBRWQsTUFBSUYsUUFBUyxRQUFPLHVCQUFDLFNBQUksZ0RBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN6RCxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDRixLQUFNLFFBQU8sdUJBQUMsU0FBSSx1Q0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRCO0FBRTlDLFFBQU1hLFdBQVdDLE9BQU9kLEtBQUtELEVBQUU7QUFDL0IsUUFBTWdCLHNCQUFzQmYsS0FBS2dCLFNBQVMsS0FBSyxDQUFDRixPQUFPRyxNQUFNSixRQUFRO0FBRXJFLFNBQ0ksbUNBQ0k7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUXRCO0FBQUFBLFFBQ1I7QUFBQSxRQUNBLHFCQUNJd0Isc0JBQ00sTUFDSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNUixzQkFBc0IsSUFBSTtBQUFBLFlBQ3pDLFdBQVU7QUFBQSxZQUE0STtBQUFBO0FBQUEsVUFIMUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsSUFFSlc7QUFBQUE7QUFBQUEsTUFkZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFlSztBQUFBLElBRUpILHVCQUF1QlQsc0JBQ3BCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRQTtBQUFBQSxRQUNSLE9BQU9PO0FBQUFBLFFBQ1AsU0FBU0Y7QUFBQUEsUUFDVCxTQUFTLE1BQU1KLHNCQUFzQixLQUFLO0FBQUEsUUFDMUMsU0FBU0s7QUFBQUE7QUFBQUEsTUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLa0M7QUFBQSxPQXhCMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVSO0FBQUVkLEdBbkRXRCxxQkFBbUI7QUFBQSxVQUNiVixXQUM2QkssYUFDSEMsY0FBYztBQUFBO0FBQUEwQixLQUg5Q3RCO0FBQW1CLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsIkdlbmVyaWNEZXRhaWxQYWdlIiwidGF4ZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInVzZVBlcm1pc3Npb25zIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJSZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsIiwiSW1wdWVzdG9zRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJpdGVtIiwibG9hZGluZyIsImVycm9yIiwiZmV0Y2hJdGVtIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsImhhc1Blcm0iLCJyZXRlbnRpb25Nb2RhbE9wZW4iLCJzZXRSZXRlbnRpb25Nb2RhbE9wZW4iLCJtb2R1bGVQZXJtaXNzaW9uIiwiYmFzZVJvdXRlIiwibW9kdWxlQmFzZSIsImNhbkVkaXRUYXhlcyIsImhhbmRsZVJldGVudGlvblNhdmVkIiwidGF4SWROdW0iLCJOdW1iZXIiLCJzaG93UmV0ZW50aW9uQnV0dG9uIiwidHlwZSIsImlzTmFOIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW1wdWVzdG9zRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBHZW5lcmljRGV0YWlsUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNEZXRhaWxQYWdlJztcbmltcG9ydCB7IHRheGVzTW9kdWxlQ29uZmlnLCB0eXBlIFRheCB9IGZyb20gJy4uL2ltcHVlc3Rvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBSZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsIH0gZnJvbSAnLi4vY29tcG9uZW50cy9SZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsJztcblxuZXhwb3J0IGNvbnN0IEltcHVlc3Rvc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbSwgbG9hZGluZywgZXJyb3IsIGZldGNoSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08VGF4Pih0YXhlc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IHsgaGFzTW9kdWxlUGVybWlzc2lvbjogaGFzUGVybSB9ID0gdXNlUGVybWlzc2lvbnMoKTtcbiAgICBjb25zdCBbcmV0ZW50aW9uTW9kYWxPcGVuLCBzZXRSZXRlbnRpb25Nb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbih0YXhlc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkVkaXRUYXhlcyA9IG1vZHVsZUJhc2UgPyBoYXNQZXJtKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuXG4gICAgY29uc3QgaGFuZGxlUmV0ZW50aW9uU2F2ZWQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIHZvaWQgZmV0Y2hJdGVtKCk7XG4gICAgfSwgW2ZldGNoSXRlbV0pO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2PkNhcmdhbmRvIGRldGFsbGUgZGVsIGltcHVlc3RvLi4uPC9kaXY+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWl0ZW0pIHJldHVybiA8ZGl2PkltcHVlc3RvIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgY29uc3QgdGF4SWROdW0gPSBOdW1iZXIoaXRlbS5pZCk7XG4gICAgY29uc3Qgc2hvd1JldGVudGlvbkJ1dHRvbiA9IGl0ZW0udHlwZSA9PT0gMyAmJiAhTnVtYmVyLmlzTmFOKHRheElkTnVtKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2VcbiAgICAgICAgICAgICAgICBjb25maWc9e3RheGVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XG4gICAgICAgICAgICAgICAgcmVuZGVySGVhZGVyQWN0aW9ucz17XG4gICAgICAgICAgICAgICAgICAgIHNob3dSZXRlbnRpb25CdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgID8gKCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJldGVudGlvbk1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhYmxhIGRlIHJldGVuY2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7c2hvd1JldGVudGlvbkJ1dHRvbiAmJiByZXRlbnRpb25Nb2RhbE9wZW4gJiYgKFxuICAgICAgICAgICAgICAgIDxSZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17cmV0ZW50aW9uTW9kYWxPcGVufVxuICAgICAgICAgICAgICAgICAgICB0YXhJZD17dGF4SWROdW19XG4gICAgICAgICAgICAgICAgICAgIGNhbkVkaXQ9e2NhbkVkaXRUYXhlc31cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UmV0ZW50aW9uTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgb25TYXZlZD17aGFuZGxlUmV0ZW50aW9uU2F2ZWR9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9pbXB1ZXN0b3MvcGFnZXMvSW1wdWVzdG9zRGV0YWlsUGFnZS50c3gifQ==