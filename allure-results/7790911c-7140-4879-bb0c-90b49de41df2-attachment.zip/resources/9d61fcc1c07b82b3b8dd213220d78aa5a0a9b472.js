import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
export const PlanDeCuentasEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: planDeCuentas, loading, error, saveItem } = useCrudItem(planDeCuentasModuleConfig, id);
  const [hydratedData, setHydratedData] = useState(null);
  const [originalCode, setOriginalCode] = useState("");
  const [originalName, setOriginalName] = useState("");
  useEffect(() => {
    if (planDeCuentas) {
      const hydrated = { ...planDeCuentas };
      setOriginalCode(planDeCuentas.code || "");
      setOriginalName(planDeCuentas.name || "");
      if (planDeCuentas.parent_name) {
        hydrated.related_to_name = planDeCuentas.parent_name;
      } else if (planDeCuentas.parent) {
        hydrated.related_to_name = planDeCuentas.parent.name;
      }
      if (planDeCuentas.parent_code) {
        hydrated.related_to_code = planDeCuentas.parent_code;
      } else if (planDeCuentas.parent) {
        hydrated.related_to_code = planDeCuentas.parent.code;
      }
      setHydratedData(hydrated);
    }
  }, [planDeCuentas]);
  const handleSave = async (data) => {
    const dataToSave = { ...data };
    if (originalCode) {
      dataToSave.code = originalCode;
    }
    if (originalName) {
      dataToSave.name = originalName;
    }
    delete dataToSave.related_to_code;
    delete dataToSave.related_to_name;
    delete dataToSave.parent;
    delete dataToSave.parent_id;
    delete dataToSave.parent_code;
    delete dataToSave.parent_name;
    const saved = await saveItem(dataToSave);
    if (saved) {
      toast.info(`Cuenta actualizada con éxito!`);
      navigate("/plan-de-cuentas");
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos de la cuenta..." }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx",
    lineNumber: 88,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx",
    lineNumber: 89,
    columnNumber: 21
  }, this);
  if (!planDeCuentas || !hydratedData) return /* @__PURE__ */ jsxDEV("div", { children: "Cuenta no encontrada." }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx",
    lineNumber: 90,
    columnNumber: 47
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: planDeCuentasModuleConfig,
      initialData: hydratedData,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx",
      lineNumber: 93,
      columnNumber: 5
    },
    this
  );
};
_s(PlanDeCuentasEditPage, "S/AM71n6K4mklX1vXog8V/1UpOg=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = PlanDeCuentasEditPage;
var _c;
$RefreshReg$(_c, "PlanDeCuentasEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0V3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRXhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGlDQUFxRDtBQUM5RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUVmLGFBQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsR0FBRyxJQUFJVixVQUEwQjtBQUN6QyxRQUFNVyxXQUFXVixZQUFZO0FBQzdCLFFBQU0sRUFBRVcsTUFBTUMsZUFBZUMsU0FBU0MsT0FBT0MsU0FBUyxJQUFJVixZQUEyQkQsMkJBQTJCSyxFQUFFO0FBQ2xILFFBQU0sQ0FBQ08sY0FBY0MsZUFBZSxJQUFJZixTQUErQixJQUFJO0FBQzNFLFFBQU0sQ0FBQ2dCLGNBQWNDLGVBQWUsSUFBSWpCLFNBQWlCLEVBQUU7QUFDM0QsUUFBTSxDQUFDa0IsY0FBY0MsZUFBZSxJQUFJbkIsU0FBaUIsRUFBRTtBQUczREQsWUFBVSxNQUFNO0FBQ1osUUFBSVcsZUFBZTtBQUNmLFlBQU1VLFdBQTBCLEVBQUUsR0FBR1YsY0FBYztBQUduRE8sc0JBQWdCUCxjQUFjVyxRQUFRLEVBQUU7QUFDeENGLHNCQUFnQlQsY0FBY1ksUUFBUSxFQUFFO0FBR3hDLFVBQUlaLGNBQWNhLGFBQWE7QUFDM0JILGlCQUFTSSxrQkFBa0JkLGNBQWNhO0FBQUFBLE1BQzdDLFdBQVdiLGNBQWNlLFFBQVE7QUFDN0JMLGlCQUFTSSxrQkFBa0JkLGNBQWNlLE9BQU9IO0FBQUFBLE1BQ3BEO0FBRUEsVUFBSVosY0FBY2dCLGFBQWE7QUFDM0JOLGlCQUFTTyxrQkFBa0JqQixjQUFjZ0I7QUFBQUEsTUFDN0MsV0FBV2hCLGNBQWNlLFFBQVE7QUFDN0JMLGlCQUFTTyxrQkFBa0JqQixjQUFjZSxPQUFPSjtBQUFBQSxNQUNwRDtBQUVBTixzQkFBZ0JLLFFBQVE7QUFBQSxJQUM1QjtBQUFBLEVBQ0osR0FBRyxDQUFDVixhQUFhLENBQUM7QUFFbEIsUUFBTWtCLGFBQWEsT0FBT0MsU0FBd0I7QUFFOUMsVUFBTUMsYUFBNEIsRUFBRSxHQUFHRCxLQUFLO0FBRzVDLFFBQUliLGNBQWM7QUFDZGMsaUJBQVdULE9BQU9MO0FBQUFBLElBQ3RCO0FBQ0EsUUFBSUUsY0FBYztBQUNkWSxpQkFBV1IsT0FBT0o7QUFBQUEsSUFDdEI7QUFHQSxXQUFRWSxXQUFtQkg7QUFDM0IsV0FBUUcsV0FBbUJOO0FBQzNCLFdBQVFNLFdBQW1CTDtBQUMzQixXQUFRSyxXQUFtQkM7QUFDM0IsV0FBUUQsV0FBbUJKO0FBQzNCLFdBQVFJLFdBQW1CUDtBQUUzQixVQUFNUyxRQUFRLE1BQU1uQixTQUFTaUIsVUFBVTtBQUN2QyxRQUFJRSxPQUFPO0FBQ1A1QixZQUFNNkIsS0FBSywrQkFBK0I7QUFDMUN6QixlQUFTLGtCQUFrQjtBQUFBLElBQy9CO0FBQUEsRUFDSjtBQUVBLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLDhDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUM7QUFDdkQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsaUJBQWlCLENBQUNJLGFBQWMsUUFBTyx1QkFBQyxTQUFJLHFDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEI7QUFFdEUsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVo7QUFBQUEsTUFDUixhQUFhWTtBQUFBQSxNQUNiLFFBQVFjO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJZTtBQUd2QjtBQUFFdEIsR0F6RVdELHVCQUFxQjtBQUFBLFVBQ2ZSLFdBQ0VDLGFBQ3lDSyxXQUFXO0FBQUE7QUFBQStCLEtBSDVEN0I7QUFBcUIsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwicGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJQbGFuRGVDdWVudGFzRWRpdFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJpdGVtIiwicGxhbkRlQ3VlbnRhcyIsImxvYWRpbmciLCJlcnJvciIsInNhdmVJdGVtIiwiaHlkcmF0ZWREYXRhIiwic2V0SHlkcmF0ZWREYXRhIiwib3JpZ2luYWxDb2RlIiwic2V0T3JpZ2luYWxDb2RlIiwib3JpZ2luYWxOYW1lIiwic2V0T3JpZ2luYWxOYW1lIiwiaHlkcmF0ZWQiLCJjb2RlIiwibmFtZSIsInBhcmVudF9uYW1lIiwicmVsYXRlZF90b19uYW1lIiwicGFyZW50IiwicGFyZW50X2NvZGUiLCJyZWxhdGVkX3RvX2NvZGUiLCJoYW5kbGVTYXZlIiwiZGF0YSIsImRhdGFUb1NhdmUiLCJwYXJlbnRfaWQiLCJzYXZlZCIsImluZm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQbGFuRGVDdWVudGFzRWRpdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBHZW5lcmljRm9ybVBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVBhZ2UnO1xuaW1wb3J0IHsgcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZywgdHlwZSBQbGFuRGVDdWVudGFzIH0gZnJvbSAnLi4vcGxhbl9kZV9jdWVudGFzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuXG5leHBvcnQgY29uc3QgUGxhbkRlQ3VlbnRhc0VkaXRQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBpdGVtOiBwbGFuRGVDdWVudGFzLCBsb2FkaW5nLCBlcnJvciwgc2F2ZUl0ZW0gfSA9IHVzZUNydWRJdGVtPFBsYW5EZUN1ZW50YXM+KHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCBbaHlkcmF0ZWREYXRhLCBzZXRIeWRyYXRlZERhdGFdID0gdXNlU3RhdGU8UGxhbkRlQ3VlbnRhcyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtvcmlnaW5hbENvZGUsIHNldE9yaWdpbmFsQ29kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgICBjb25zdCBbb3JpZ2luYWxOYW1lLCBzZXRPcmlnaW5hbE5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgICAvLyDinIUgUG9ibGFyIGNhbXBvcyBwbGFub3MgZGVzZGUgb2JqZXRvcyByZWxhY2lvbmFsZXMgY3VhbmRvIHNlIGNhcmdhIGVsIGl0ZW1cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocGxhbkRlQ3VlbnRhcykge1xuICAgICAgICAgICAgY29uc3QgaHlkcmF0ZWQ6IFBsYW5EZUN1ZW50YXMgPSB7IC4uLnBsYW5EZUN1ZW50YXMgfTtcblxuICAgICAgICAgICAgLy8g4pyFIEd1YXJkYXIgdmFsb3JlcyBvcmlnaW5hbGVzIGRlIGNvZGUgeSBuYW1lIHBhcmEgcmVzdGF1cmFybG9zIHNpIHNvbiBzb2JyZXNjcml0b3NcbiAgICAgICAgICAgIHNldE9yaWdpbmFsQ29kZShwbGFuRGVDdWVudGFzLmNvZGUgfHwgJycpO1xuICAgICAgICAgICAgc2V0T3JpZ2luYWxOYW1lKHBsYW5EZUN1ZW50YXMubmFtZSB8fCAnJyk7XG5cbiAgICAgICAgICAgIC8vIOKchSBNYXBlYXIgcGFyZW50X2NvZGUgeSBwYXJlbnRfbmFtZSBhIHJlbGF0ZWRfdG9fY29kZSB5IHJlbGF0ZWRfdG9fbmFtZSBwYXJhIEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgaWYgKHBsYW5EZUN1ZW50YXMucGFyZW50X25hbWUpIHtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZC5yZWxhdGVkX3RvX25hbWUgPSBwbGFuRGVDdWVudGFzLnBhcmVudF9uYW1lO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChwbGFuRGVDdWVudGFzLnBhcmVudCkge1xuICAgICAgICAgICAgICAgIGh5ZHJhdGVkLnJlbGF0ZWRfdG9fbmFtZSA9IHBsYW5EZUN1ZW50YXMucGFyZW50Lm5hbWU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChwbGFuRGVDdWVudGFzLnBhcmVudF9jb2RlKSB7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWQucmVsYXRlZF90b19jb2RlID0gcGxhbkRlQ3VlbnRhcy5wYXJlbnRfY29kZTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAocGxhbkRlQ3VlbnRhcy5wYXJlbnQpIHtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZC5yZWxhdGVkX3RvX2NvZGUgPSBwbGFuRGVDdWVudGFzLnBhcmVudC5jb2RlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRIeWRyYXRlZERhdGEoaHlkcmF0ZWQpO1xuICAgICAgICB9XG4gICAgfSwgW3BsYW5EZUN1ZW50YXNdKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogUGxhbkRlQ3VlbnRhcykgPT4ge1xuICAgICAgICAvLyDinIUgUmVzdGF1cmFyIGNvZGUgeSBuYW1lIHNpIGZ1ZXJvbiBzb2JyZXNjcml0b3MgcG9yIEdlbmVyaWNGb3JtUGFnZSBhbCBzZWxlY2Npb25hciByZWxhdGVkX3RvXG4gICAgICAgIGNvbnN0IGRhdGFUb1NhdmU6IFBsYW5EZUN1ZW50YXMgPSB7IC4uLmRhdGEgfTtcblxuICAgICAgICAvLyBSZXN0YXVyYXIgbG9zIHZhbG9yZXMgb3JpZ2luYWxlcyBkZSBjb2RlIHkgbmFtZSAocG9yIHNpIGZ1ZXJvbiBzb2JyZXNjcml0b3MpXG4gICAgICAgIGlmIChvcmlnaW5hbENvZGUpIHtcbiAgICAgICAgICAgIGRhdGFUb1NhdmUuY29kZSA9IG9yaWdpbmFsQ29kZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3JpZ2luYWxOYW1lKSB7XG4gICAgICAgICAgICBkYXRhVG9TYXZlLm5hbWUgPSBvcmlnaW5hbE5hbWU7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBMaW1waWFyIGNhbXBvcyByZWxhY2lvbmFsZXMgYW50ZXMgZGUgZW52aWFyXG4gICAgICAgIGRlbGV0ZSAoZGF0YVRvU2F2ZSBhcyBhbnkpLnJlbGF0ZWRfdG9fY29kZTtcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkucmVsYXRlZF90b19uYW1lO1xuICAgICAgICBkZWxldGUgKGRhdGFUb1NhdmUgYXMgYW55KS5wYXJlbnQ7XG4gICAgICAgIGRlbGV0ZSAoZGF0YVRvU2F2ZSBhcyBhbnkpLnBhcmVudF9pZDtcbiAgICAgICAgZGVsZXRlIChkYXRhVG9TYXZlIGFzIGFueSkucGFyZW50X2NvZGU7XG4gICAgICAgIGRlbGV0ZSAoZGF0YVRvU2F2ZSBhcyBhbnkpLnBhcmVudF9uYW1lO1xuXG4gICAgICAgIGNvbnN0IHNhdmVkID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YVRvU2F2ZSk7XG4gICAgICAgIGlmIChzYXZlZCkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhgQ3VlbnRhIGFjdHVhbGl6YWRhIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL3BsYW4tZGUtY3VlbnRhcycpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkYXRvcyBkZSBsYSBjdWVudGEuLi48L2Rpdj47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghcGxhbkRlQ3VlbnRhcyB8fCAhaHlkcmF0ZWREYXRhKSByZXR1cm4gPGRpdj5DdWVudGEgbm8gZW5jb250cmFkYS48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e3BsYW5EZUN1ZW50YXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aHlkcmF0ZWREYXRhfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbW9kZT1cImVkaXRcIlxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wbGFuX2RlX2N1ZW50YXMvcGFnZXMvUGxhbkRlQ3VlbnRhc0VkaXRQYWdlLnRzeCJ9