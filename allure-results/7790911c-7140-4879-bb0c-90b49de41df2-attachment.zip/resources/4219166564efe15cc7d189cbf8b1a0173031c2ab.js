import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transportes/pages/TransportesCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/transportes/pages/TransportesCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialValues = {
  code: "",
  name: "",
  address: "",
  phone: "",
  tax_id: "",
  is_active: true
  // Por defecto creamos activos
};
export const TransportesCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(transportesModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.success(`Transporte creado con éxito!`);
      navigate(getListReturnPath(transportesModuleConfig.baseRoute));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: transportesModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/transportes/pages/TransportesCreatePage.tsx",
      lineNumber: 50,
      columnNumber: 5
    },
    this
  );
};
_s(TransportesCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = TransportesCreatePage;
var _c;
$RefreshReg$(_c, "TransportesCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/transportes/pages/TransportesCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/transportes/pages/TransportesCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLCtCQUFnRDtBQUN6RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsZ0JBQXFDO0FBQUEsRUFDdkNDLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsU0FBUztBQUFBLEVBQ1RDLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBO0FBQ2Y7QUFFTyxhQUFNQyx3QkFBd0JBLE1BQU07QUFBQUMsS0FBQTtBQUN2QyxRQUFNQyxXQUFXZixZQUFZO0FBQzdCLFFBQU0sRUFBRWdCLFNBQVMsSUFBSWIsWUFBd0JELHVCQUF1QjtBQUVwRSxRQUFNZSxhQUFhLE9BQU9DLFNBQXFCO0FBQzNDLFVBQU1DLFVBQVUsTUFBTUgsU0FBU0UsSUFBSTtBQUNuQyxRQUFJQyxTQUFTO0FBQ1RmLFlBQU1nQixRQUFRLDhCQUE4QjtBQUM1Q0wsZUFBU1Ysa0JBQWtCSCx3QkFBd0JtQixTQUFTLENBQUM7QUFBQSxJQUNqRTtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRbkI7QUFBQUEsTUFDUixhQUFhSTtBQUFBQSxNQUNiLFFBQVFXO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUI7QUFHekI7QUFBRUgsR0FwQldELHVCQUFxQjtBQUFBLFVBQ2JiLGFBQ0lHLFdBQVc7QUFBQTtBQUFBbUIsS0FGdkJUO0FBQXFCLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNGb3JtUGFnZSIsInRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJ0b2FzdCIsImdldExpc3RSZXR1cm5QYXRoIiwiaW5pdGlhbFZhbHVlcyIsImNvZGUiLCJuYW1lIiwiYWRkcmVzcyIsInBob25lIiwidGF4X2lkIiwiaXNfYWN0aXZlIiwiVHJhbnNwb3J0ZXNDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJuZXdJdGVtIiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRyYW5zcG9ydGVzQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZywgdHlwZSBUcmFuc3BvcnRlIH0gZnJvbSAnLi4vdHJhbnNwb3J0ZXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLy8gVmFsb3JlcyBpbmljaWFsZXMgcGFyYSB1biB0cmFuc3BvcnRlIG51ZXZvXG5jb25zdCBpbml0aWFsVmFsdWVzOiBQYXJ0aWFsPFRyYW5zcG9ydGU+ID0ge1xuICAgIGNvZGU6ICcnLFxuICAgIG5hbWU6ICcnLFxuICAgIGFkZHJlc3M6ICcnLFxuICAgIHBob25lOiAnJyxcbiAgICB0YXhfaWQ6ICcnLFxuICAgIGlzX2FjdGl2ZTogdHJ1ZSwgLy8gUG9yIGRlZmVjdG8gY3JlYW1vcyBhY3Rpdm9zXG59O1xuXG5leHBvcnQgY29uc3QgVHJhbnNwb3J0ZXNDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxUcmFuc3BvcnRlPih0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IFRyYW5zcG9ydGUpID0+IHtcbiAgICAgICAgY29uc3QgbmV3SXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAobmV3SXRlbSkge1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgVHJhbnNwb3J0ZSBjcmVhZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17dHJhbnNwb3J0ZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFZhbHVlcyBhcyBUcmFuc3BvcnRlfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy90cmFuc3BvcnRlcy9wYWdlcy9UcmFuc3BvcnRlc0NyZWF0ZVBhZ2UudHN4In0=