import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash, FaFillDrip } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, search, searchByField } from "/src/services/apiService.ts";
import { previewGananciasRetention, previewRetention } from "/src/services/retentionsService.ts";
import {
  buildAppliedPurchasesForSave,
  buildAppliedPurchasesForRetentionPreview,
  buildAppliedFinancialNotesForSave,
  buildGananciasRetentionPreviewRequest,
  buildRetentionPreviewRequest,
  computeGrossAppliedAmount,
  sumAppliedAmountsRecord
} from "/src/features/ordenes_pago/buildAppliedPurchasesPayload.ts";
import {
  ordenesPagoModuleConfig,
  PAYMENT_METHOD_RETENTION_GANANCIAS,
  GANANCIAS_TAX_ID,
  buildVendorRetentionPaymentCode,
  parseTaxIdFromVendorRetentionCode,
  isVendorDynamicRetentionPaymentCode,
  signedNoteBalance,
  signedNoteTotal,
  undeliveredChecksConfig
} from "/src/features/ordenes_pago/ordenes_pago.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import {} from "/src/features/compras/compras.config.tsx";
import {} from "/src/features/notas_financieras_compra/notas_financieras_compra.config.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue, formatDateForInput } from "/src/utils/formatters.ts";
import { useModal } from "/src/context/ModalContext.tsx";
import { bancosModuleConfig } from "/src/features/bancos/bancos.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
function isGananciasRetentionItem(item) {
  return Boolean(item.is_system_generated) && item.system_type === "ganancias_retention" || item.payment_method_code === PAYMENT_METHOD_RETENTION_GANANCIAS;
}
function isVendorRetentionItem(item) {
  return Boolean(item.is_system_generated) && item.system_type === "vendor_retention" || isVendorDynamicRetentionPaymentCode(item.payment_method_code);
}
function isSystemRetentionPaymentRow(item) {
  return isGananciasRetentionItem(item) || isVendorRetentionItem(item);
}
function vendorRetentionSelectLabel(item) {
  const n = item.retention_tax_name?.trim();
  return n ? `Retención ${n}` : "Retención";
}
export const OrdenesPagoFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: initialData, loading: loadingInitial, saveItem, loading: saving } = useCrudItem(ordenesPagoModuleConfig, id);
  const { showConfirmationModal } = useModal();
  const [headerData, setHeaderData] = useState({
    payment_date: formatDateForInput(/* @__PURE__ */ new Date()),
    vendor_id: null,
    vendor_name: "",
    discount: 0
  });
  const [vendorCodeInput, setVendorCodeInput] = useState("");
  const [items, setItems] = useState([]);
  const [vendorTaxes, setVendorTaxes] = useState([]);
  const [vendorRetentionInfo, setVendorRetentionInfo] = useState(null);
  const [pendingPurchases, setPendingPurchases] = useState([]);
  const [pendingFinancialNotes, setPendingFinancialNotes] = useState([]);
  const [isLoadingPurchases, setIsLoadingPurchases] = useState(false);
  const [appliedAmounts, setAppliedAmounts] = useState({});
  const [appliedFinancialNoteAmounts, setAppliedFinancialNoteAmounts] = useState({});
  const [vendorAdvanceBalance, setVendorAdvanceBalance] = useState(0);
  const [gananciasRetention, setGananciasRetention] = useState(null);
  const [vendorRetentionsPreview, setVendorRetentionsPreview] = useState(
    {}
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [modalConfig, setModalConfig] = useState(null);
  useEffect(() => {
    if (mode === "edit" && initialData) {
      setHeaderData({
        payment_date: formatDateForInput(new Date(initialData.payment_date)),
        vendor_id: initialData.vendor_id,
        vendor_name: initialData.vendor?.name || "",
        discount: initialData.discount || 0
      });
      if (initialData.vendor) {
        setVendorCodeInput(initialData.vendor.vendor_code || String(initialData.vendor_id));
        setVendorAdvanceBalance((Number(initialData.vendor.advance_balance) || 0) * -1);
        setVendorRetentionInfo({
          do_not_retain: Boolean(initialData.vendor.do_not_retain),
          vendor_type: initialData.vendor.vendor_type ?? null
        });
      }
      const mappedItems = initialData.items?.map((i) => {
        const newItem = {
          payment_method_code: i.payment_method_code,
          bank_id: i.bank_id,
          bank_name: i.bank_name,
          bank_code: i.bank_code,
          check_number: i.check_number,
          check_date: i.check_date,
          value: Number(i.value) || 0,
          check_key: i.check_key,
          chart_account: i.chart_account,
          received_check_id: i.received_check_id,
          received_check: i.received_check ?? null,
          tempId: crypto.randomUUID(),
          id: i.id,
          ...i.value_base != null && !Number.isNaN(Number(i.value_base)) ? { value_base: Number(i.value_base) } : {},
          ui_account_code: i.chart_account?.code || "",
          ui_bank_code: i.bank_code || "",
          ui_check_search: i.check_number || "",
          ui_received_holder: i.received_check?.check_holder ?? "",
          ui_received_cuit: i.received_check?.issuer_cuit ?? "",
          ui_received_reference: i.received_check?.reference_number ?? ""
        };
        if (i.bank) {
          newItem.bank_name = i.bank.name;
        }
        if (i.payment_method_code === PAYMENT_METHOD_RETENTION_GANANCIAS) {
          newItem.is_system_generated = true;
          newItem.system_type = "ganancias_retention";
          newItem.retention_value_overridden = true;
        }
        const vendorRetTaxId = parseTaxIdFromVendorRetentionCode(i.payment_method_code);
        if (vendorRetTaxId != null) {
          newItem.is_system_generated = true;
          newItem.system_type = "vendor_retention";
          newItem.retention_tax_id = vendorRetTaxId;
          newItem.retention_value_overridden = true;
          const matchTax = initialData.applied_taxes?.find((t) => t.tax_id === vendorRetTaxId);
          newItem.retention_tax_name = matchTax?.tax_name ?? void 0;
        }
        return newItem;
      }) || [];
      let retRowSeen = false;
      const seenVendorRetentionTaxIds = /* @__PURE__ */ new Set();
      const itemsFiltered = mappedItems.filter((it) => {
        if (it.payment_method_code === PAYMENT_METHOD_RETENTION_GANANCIAS) {
          if (retRowSeen) return false;
          retRowSeen = true;
          return true;
        }
        const vtid = parseTaxIdFromVendorRetentionCode(it.payment_method_code);
        if (vtid != null) {
          if (seenVendorRetentionTaxIds.has(vtid)) return false;
          seenVendorRetentionTaxIds.add(vtid);
          return true;
        }
        return true;
      });
      setItems(itemsFiltered);
      const retItPersisted = itemsFiltered.find((i) => i.payment_method_code === PAYMENT_METHOD_RETENTION_GANANCIAS);
      const persistedRetentionValueBase = retItPersisted != null && retItPersisted.value_base != null && !Number.isNaN(Number(retItPersisted.value_base)) ? Number(retItPersisted.value_base) : void 0;
      const ganTax = initialData.applied_taxes?.find(
        (t) => t.tax_id === GANANCIAS_TAX_ID || t.tax_name && t.tax_name.includes("Ganancias")
      );
      if (ganTax && Number(ganTax.amount) > 0) {
        setGananciasRetention({
          amount: Number(ganTax.amount),
          tax_id: ganTax.tax_id,
          vendor_id: initialData.vendor_id,
          case_code: initialData.vendor?.vendor_type ?? null,
          ...persistedRetentionValueBase !== void 0 ? { value_base: persistedRetentionValueBase } : {}
        });
      } else {
        const retIt = retItPersisted;
        if (retIt && Number(retIt.value) > 0) {
          setGananciasRetention({
            amount: Number(retIt.value),
            tax_id: GANANCIAS_TAX_ID,
            vendor_id: initialData.vendor_id,
            case_code: initialData.vendor?.vendor_type ?? null,
            ...persistedRetentionValueBase !== void 0 ? { value_base: persistedRetentionValueBase } : {}
          });
        } else {
          setGananciasRetention(null);
        }
      }
      const initialVendorRetPreview = {};
      for (const it of itemsFiltered) {
        const tid = parseTaxIdFromVendorRetentionCode(it.payment_method_code);
        if (tid == null) continue;
        const at = initialData.applied_taxes?.find((t) => t.tax_id === tid);
        const persistedVb = it.value_base != null && !Number.isNaN(Number(it.value_base)) ? Number(it.value_base) : void 0;
        initialVendorRetPreview[tid] = {
          tax_id: tid,
          tax_name: (at?.tax_name ?? it.retention_tax_name) || "Retención",
          amount: Number(at?.amount) || Number(it.value) || 0,
          ...persistedVb !== void 0 ? { value_base: persistedVb } : {}
        };
      }
      setVendorRetentionsPreview(initialVendorRetPreview);
      const loadVendorTaxes = async (vendorId) => {
        try {
          const fullVendor = await getById("vendors", vendorId);
          setVendorTaxes(fullVendor.taxes || []);
          setVendorAdvanceBalance((Number(fullVendor.advance_balance) || 0) * -1);
          setVendorRetentionInfo({
            do_not_retain: Boolean(fullVendor.do_not_retain),
            vendor_type: fullVendor.vendor_type ?? null
          });
        } catch {
          toast.error("Error al cargar impuestos del proveedor.");
        }
      };
      if (initialData.vendor_id) {
        loadVendorTaxes(initialData.vendor_id);
      }
      const loadEditData = async () => {
        if (!initialData.vendor_id) return;
        setIsLoadingPurchases(true);
        try {
          const params = new URLSearchParams({ vendor_id: initialData.vendor_id.toString(), has_balance: "true" });
          const pendingResponsePromise = search(`purchases?${params.toString()}`);
          const pendingNotesPromise = search(`purchase-financial-notes?${params.toString()}`);
          const appliedPurchaseIds = initialData.applied_purchases?.map((ap) => ap.purchase.id) || [];
          const appliedPurchasesPromises = appliedPurchaseIds.map((id2) => getById("purchases", id2));
          const appliedNoteIds = initialData.applied_financial_notes?.map((an) => an.purchase_financial_note.id) || [];
          const appliedNotesPromises = appliedNoteIds.map(
            (noteId) => getById("purchase-financial-notes", noteId)
          );
          const [pendingResponse, pendingNotesResponse, ...fetchedApplied] = await Promise.all(
            [
              pendingResponsePromise,
              pendingNotesPromise,
              ...appliedPurchasesPromises,
              ...appliedNotesPromises
            ]
          );
          const fetchedAppliedPurchases = fetchedApplied.slice(0, appliedPurchasesPromises.length);
          const fetchedAppliedNotes = fetchedApplied.slice(appliedPurchasesPromises.length);
          const allPurchasesMap = /* @__PURE__ */ new Map();
          fetchedAppliedPurchases.forEach((p) => {
            if (p) allPurchasesMap.set(p.id, p);
          });
          pendingResponse.data.forEach((p) => {
            if (!allPurchasesMap.has(p.id)) allPurchasesMap.set(p.id, p);
          });
          const finalPurchases = Array.from(allPurchasesMap.values()).map((p) => {
            const appliedDetail = initialData.applied_purchases?.find((ap) => ap.purchase.id === p.id);
            if (appliedDetail) {
              const originalBalance = (Number(p.balance) || 0) + (Number(appliedDetail.amount_applied) || 0);
              return { ...p, balance: originalBalance };
            }
            return p;
          });
          setPendingPurchases(finalPurchases);
          const allNotesMap = /* @__PURE__ */ new Map();
          fetchedAppliedNotes.forEach((n) => {
            if (n) allNotesMap.set(n.id, n);
          });
          pendingNotesResponse.data.forEach((n) => {
            if (!allNotesMap.has(n.id)) allNotesMap.set(n.id, n);
          });
          const finalNotes = Array.from(allNotesMap.values()).map((n) => {
            const appliedDetail = initialData.applied_financial_notes?.find(
              (an) => an.purchase_financial_note.id === n.id
            );
            if (appliedDetail) {
              const currentBalance = signedNoteBalance(n);
              const originalBalance = currentBalance + (Number(appliedDetail.amount_applied) || 0);
              return { ...n, balance: originalBalance };
            }
            return n;
          });
          setPendingFinancialNotes(finalNotes);
          if (initialData.applied_purchases) {
            const initialAmounts = initialData.applied_purchases.reduce((acc, ap) => {
              acc[ap.purchase.id] = Number(ap.amount_applied) || 0;
              return acc;
            }, {});
            setAppliedAmounts(initialAmounts);
          }
          if (initialData.applied_financial_notes) {
            const initialNoteAmounts = initialData.applied_financial_notes.reduce((acc, an) => {
              acc[an.purchase_financial_note.id] = Number(an.amount_applied) || 0;
              return acc;
            }, {});
            setAppliedFinancialNoteAmounts(initialNoteAmounts);
          }
        } catch (error) {
          toast.error("No se pudieron cargar las facturas del proveedor.");
          console.error(error);
        } finally {
          setIsLoadingPurchases(false);
        }
      };
      loadEditData();
    } else if (mode === "create") {
      setVendorTaxes([]);
      setVendorRetentionInfo(null);
      setGananciasRetention(null);
      setVendorRetentionsPreview({});
      setPendingFinancialNotes([]);
      setAppliedFinancialNoteAmounts({});
    }
  }, [mode, initialData]);
  const handleVendorCodeSubmit = async () => {
    if (!vendorCodeInput) return;
    try {
      const found = await searchByField(proveedoresModuleConfig.endpoint, [{ fieldName: "vendor_code", value: vendorCodeInput }]);
      if (found) {
        handleSelectVendor(found);
        setVendorCodeInput(found.vendor_code || String(found.id));
        toast.success("Proveedor encontrado.");
      } else {
        toast.warn("Proveedor no encontrado.");
        setHeaderData((prev) => ({ ...prev, vendor_id: null, vendor_name: "", discount: 0 }));
        setPendingPurchases([]);
        setPendingFinancialNotes([]);
        setAppliedFinancialNoteAmounts({});
        setVendorTaxes([]);
        setVendorRetentionInfo(null);
        setGananciasRetention(null);
        setVendorRetentionsPreview({});
      }
    } catch (e) {
      console.error(e);
      toast.error("Error buscando proveedor.");
    }
  };
  const handleItemCodeSubmit = async (tempId, type) => {
    const itemIndex = items.findIndex((i) => i.tempId === tempId);
    if (itemIndex === -1) return;
    const item = items[itemIndex];
    let config = null;
    let searchField = "code";
    let codeValue = "";
    if (type === "account") {
      config = planDeCuentasModuleConfig;
      codeValue = item.ui_account_code;
    } else if (type === "bank") {
      config = bancosModuleConfig;
      codeValue = item.ui_bank_code;
    } else if (type === "received_check") {
      config = undeliveredChecksConfig;
      searchField = "check_number";
      codeValue = item.ui_check_search;
    }
    if (!codeValue) return;
    try {
      const found = await searchByField(config.endpoint, [{ fieldName: searchField, value: codeValue }]);
      if (found) {
        if (type === "account") {
          handleItemChange(tempId, "chart_account", found);
          handleItemChange(tempId, "ui_account_code", found.code);
        } else if (type === "bank") {
          handleItemChange(tempId, "bank_id", found.id);
          handleItemChange(tempId, "bank_name", found.name);
          handleItemChange(tempId, "ui_bank_code", found.code || String(found.id));
        } else if (type === "received_check") {
          handleItemChange(tempId, "received_check_id", found.id);
          handleItemChange(tempId, "value", Number(found.value) || 0);
          handleItemChange(tempId, "bank_id", found.bank_id);
          handleItemChange(tempId, "bank_name", found.bank_name);
          handleItemChange(tempId, "check_number", found.check_number);
          handleItemChange(tempId, "check_date", found.check_date);
          handleItemChange(tempId, "ui_check_search", found.check_number);
        }
      } else {
        toast.warn(`${type === "account" ? "Cuenta" : type === "bank" ? "Banco" : "Cheque"} no encontrado.`);
      }
    } catch (e) {
      console.error(e);
      toast.error("Error en la búsqueda.");
    }
  };
  const vendorGeneralTaxes = useMemo(
    () => (vendorTaxes || []).filter((t) => t.type !== 3),
    [vendorTaxes]
  );
  const vendorRetentionTaxesAdditional = useMemo(
    () => (vendorTaxes || []).filter((t) => t.type === 3 && t.id !== GANANCIAS_TAX_ID),
    [vendorTaxes]
  );
  const validPurchaseIds = useMemo(() => pendingPurchases.map((p) => p.id), [pendingPurchases]);
  const retentionAppliedPurchases = useMemo(
    () => buildAppliedPurchasesForRetentionPreview(appliedAmounts),
    [appliedAmounts]
  );
  const showRetentionAmountHint = useMemo(
    () => {
      const hasGanancias = Boolean(vendorRetentionInfo?.do_not_retain) && Boolean(vendorRetentionInfo?.vendor_type);
      const hasAdditional = vendorRetentionTaxesAdditional.length > 0;
      return Boolean(headerData.vendor_id) && pendingPurchases.length > 0 && retentionAppliedPurchases.length === 0 && (hasGanancias || hasAdditional);
    },
    [
      headerData.vendor_id,
      pendingPurchases.length,
      retentionAppliedPurchases.length,
      vendorRetentionInfo,
      vendorRetentionTaxesAdditional.length
    ]
  );
  const totals = useMemo(() => {
    const grossAmount = computeGrossAppliedAmount(appliedAmounts, appliedFinancialNoteAmounts);
    const purchasesGrossAmount = sumAppliedAmountsRecord(appliedAmounts);
    const financialNotesGrossAmount = sumAppliedAmountsRecord(appliedFinancialNoteAmounts);
    const discount = headerData.discount || 0;
    const calculatedAppliedTaxes = [];
    if (vendorGeneralTaxes && vendorGeneralTaxes.length > 0) {
      vendorGeneralTaxes.forEach((vTax) => {
        const originalTax = mode === "edit" ? initialData?.applied_taxes?.find((aTax) => aTax.tax_id === vTax.id) : null;
        calculatedAppliedTaxes.push({
          tax_id: vTax.id,
          tax_name: vTax.name,
          rate: vTax.rate,
          amount: discount * (vTax.rate / 100),
          id: originalTax?.id
        });
      });
    }
    const totalTaxes = calculatedAppliedTaxes.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0);
    const netAmountToPay = grossAmount - discount - totalTaxes;
    const totalPaid = items.reduce((sum, item) => sum + (Number(item.value) || 0), 0);
    const remainingToPay = Math.round((netAmountToPay - totalPaid) * 100) / 100;
    return { grossAmount, purchasesGrossAmount, financialNotesGrossAmount, discount, appliedTaxes: calculatedAppliedTaxes, totalTaxes, netAmountToPay, totalPaid, remainingToPay };
  }, [appliedAmounts, appliedFinancialNoteAmounts, headerData.discount, items, vendorGeneralTaxes, mode, initialData]);
  useEffect(
    () => {
      let isCancelled = false;
      const recalculateGananciasRetention = async () => {
        if (Math.abs(Number(totals.netAmountToPay) || 0) <= 0.01) {
          setGananciasRetention(null);
          return;
        }
        if (!headerData.vendor_id || !vendorRetentionInfo) {
          setGananciasRetention(null);
          return;
        }
        if (!vendorRetentionInfo.do_not_retain || !vendorRetentionInfo.vendor_type) {
          setGananciasRetention(null);
          return;
        }
        const previewPayload = buildGananciasRetentionPreviewRequest({
          vendor_id: headerData.vendor_id,
          payment_date: headerData.payment_date,
          appliedAmounts,
          validPurchaseIds,
          case_code: vendorRetentionInfo.vendor_type
        });
        if (!previewPayload) {
          setGananciasRetention(null);
          return;
        }
        try {
          const response = await previewGananciasRetention(previewPayload);
          if (isCancelled) return;
          const valueBaseFromPreview = response.value_base != null && !Number.isNaN(Number(response.value_base)) ? Number(response.value_base) : 0;
          setGananciasRetention({
            amount: Number(response.calculated_retention) || 0,
            tax_id: response.tax_id,
            vendor_id: response.vendor_id,
            case_code: response.case_code,
            value_base: valueBaseFromPreview
          });
        } catch (error) {
          console.error(error);
          if (!isCancelled) {
            toast.error("No se pudo calcular la retención de Ganancias.");
            setGananciasRetention(null);
          }
        }
      };
      const timeoutId = window.setTimeout(() => {
        void recalculateGananciasRetention();
      }, 300);
      return () => {
        isCancelled = true;
        window.clearTimeout(timeoutId);
      };
    },
    [
      headerData.vendor_id,
      headerData.payment_date,
      appliedAmounts,
      validPurchaseIds,
      vendorRetentionInfo,
      totals.netAmountToPay
    ]
  );
  useEffect(
    () => {
      let isCancelled = false;
      const run = async () => {
        if (Math.abs(Number(totals.netAmountToPay) || 0) <= 0.01) {
          if (!isCancelled) setVendorRetentionsPreview({});
          return;
        }
        if (!headerData.vendor_id || vendorRetentionTaxesAdditional.length === 0) {
          if (!isCancelled) setVendorRetentionsPreview({});
          return;
        }
        try {
          const results = {};
          let anyError = false;
          await Promise.all(
            vendorRetentionTaxesAdditional.map(async (vt) => {
              const previewPayload = buildRetentionPreviewRequest({
                tax_id: vt.id,
                vendor_id: headerData.vendor_id,
                payment_date: headerData.payment_date,
                appliedAmounts,
                validPurchaseIds,
                case_code: null
              });
              if (!previewPayload) {
                results[vt.id] = {
                  amount: 0,
                  tax_id: vt.id,
                  tax_name: vt.name,
                  value_base: null
                };
                return;
              }
              try {
                const response = await previewRetention(previewPayload);
                if (isCancelled) return;
                const valueBaseFromPreview = response.value_base != null && !Number.isNaN(Number(response.value_base)) ? Number(response.value_base) : 0;
                results[vt.id] = {
                  amount: Number(response.calculated_retention) || 0,
                  tax_id: vt.id,
                  tax_name: vt.name,
                  value_base: valueBaseFromPreview
                };
              } catch (e) {
                console.error(e);
                anyError = true;
                results[vt.id] = {
                  amount: 0,
                  tax_id: vt.id,
                  tax_name: vt.name,
                  value_base: null
                };
              }
            })
          );
          if (!isCancelled) {
            setVendorRetentionsPreview(results);
            if (anyError) {
              toast.error("No se pudo calcular una o más retenciones adicionales.");
            }
          }
        } catch (e) {
          console.error(e);
          if (!isCancelled) {
            setVendorRetentionsPreview({});
            toast.error("No se pudieron calcular las retenciones adicionales.");
          }
        }
      };
      const timeoutId = window.setTimeout(() => {
        void run();
      }, 300);
      return () => {
        isCancelled = true;
        window.clearTimeout(timeoutId);
      };
    },
    [
      headerData.vendor_id,
      headerData.payment_date,
      appliedAmounts,
      validPurchaseIds,
      vendorRetentionTaxesAdditional,
      totals.netAmountToPay
    ]
  );
  const handleHeaderChange = (field, value) => {
    setHeaderData((prev) => ({ ...prev, [field]: value }));
  };
  const handleSelectVendor = async (vendor) => {
    setHeaderData((prev) => ({ ...prev, vendor_id: vendor.id, vendor_name: vendor.name || "", discount: 0 }));
    setVendorCodeInput(vendor.vendor_code || String(vendor.id));
    setIsLoadingPurchases(true);
    setPendingPurchases([]);
    setPendingFinancialNotes([]);
    setAppliedAmounts({});
    setAppliedFinancialNoteAmounts({});
    setVendorTaxes([]);
    setVendorAdvanceBalance(0);
    setVendorRetentionsPreview({});
    try {
      const fullVendor = await getById("vendors", vendor.id);
      setVendorTaxes(fullVendor.taxes || []);
      setVendorAdvanceBalance((Number(fullVendor.advance_balance) || 0) * -1);
      setVendorRetentionInfo({
        do_not_retain: Boolean(fullVendor.do_not_retain),
        vendor_type: fullVendor.vendor_type ?? null
      });
      const params = new URLSearchParams({ vendor_id: vendor.id.toString(), has_balance: "true" });
      const [purchasesResponse, notesResponse] = await Promise.all(
        [
          search(`purchases?${params.toString()}`),
          search(`purchase-financial-notes?${params.toString()}`)
        ]
      );
      setPendingPurchases(purchasesResponse.data);
      setPendingFinancialNotes(notesResponse.data);
    } catch (error) {
      toast.error("No se pudieron cargar los datos del proveedor.");
      console.error(error);
    } finally {
      setIsLoadingPurchases(false);
    }
  };
  const handleAmountToApplyChange = (purchaseId, value) => {
    const purchase = pendingPurchases.find((p) => p.id === purchaseId);
    if (!purchase) return;
    const numericValue = Number(value) || 0;
    const balance = Number(purchase.balance) || 0;
    if (numericValue > balance) {
      toast.warn(`El monto no puede superar el saldo (${formatValue(balance, "currency")})`);
      value = balance;
    }
    setAppliedAmounts((prev) => ({ ...prev, [purchaseId]: value }));
  };
  const handleFinancialNoteAmountChange = (noteId, value) => {
    const note = pendingFinancialNotes.find((n) => n.id === noteId);
    if (!note) return;
    let numericValue = Number(value) || 0;
    const balance = signedNoteBalance(note);
    if (balance >= 0) {
      if (numericValue < 0) numericValue = 0;
      if (numericValue > balance) {
        toast.warn(`El monto no puede superar el saldo (${formatValue(balance, "currency")})`);
        numericValue = balance;
      }
    } else {
      if (numericValue > 0) numericValue = 0;
      if (numericValue < balance) {
        toast.warn(`El monto no puede superar el saldo (${formatValue(balance, "currency")})`);
        numericValue = balance;
      }
    }
    setAppliedFinancialNoteAmounts((prev) => ({ ...prev, [noteId]: numericValue }));
  };
  const handleAddItem = () => {
    setItems((prev) => [...prev, {
      tempId: crypto.randomUUID(),
      payment_method_code: "EFE",
      value: 0,
      bank_id: null,
      bank_name: null,
      bank_code: null,
      check_number: null,
      check_date: null,
      check_key: null,
      chart_account: null,
      received_check_id: null,
      // Inicializar inputs vacíos
      ui_account_code: "",
      ui_bank_code: "",
      ui_check_search: ""
    }]);
  };
  const handleRemoveItem = (tempId) => {
    const target = items.find((i) => i.tempId === tempId);
    if (target && isSystemRetentionPaymentRow(target)) {
      return;
    }
    setItems((prev) => prev.filter((i) => i.tempId !== tempId));
  };
  const fillPaymentItemFromAppliedTotal = (tempId) => {
    const totalAplicado = totals.grossAmount;
    const sumOtros = items.reduce(
      (s, it) => it.tempId === tempId ? s : s + (Number(it.value) || 0),
      0
    );
    let monto = Math.round((totalAplicado - sumOtros) * 100) / 100;
    if (monto < 0) {
      toast.warn(
        "El total aplicado es menor que la suma de los demás medios de pago; se usará 0 en esta línea."
      );
      monto = 0;
    }
    handleItemChange(tempId, "value", monto);
  };
  useEffect(() => {
    setItems((prevItems) => {
      const hasRetentionItem = prevItems.some(isGananciasRetentionItem);
      if (!gananciasRetention || gananciasRetention.amount <= 0) {
        if (!hasRetentionItem) return prevItems;
        return prevItems.filter((i) => !isGananciasRetentionItem(i));
      }
      const amount = Number(gananciasRetention.amount) || 0;
      const valueBase = gananciasRetention.value_base != null && !Number.isNaN(Number(gananciasRetention.value_base)) ? Number(gananciasRetention.value_base) : void 0;
      if (hasRetentionItem) {
        return prevItems.map((i) => {
          if (isGananciasRetentionItem(i)) {
            const next = {
              ...i,
              is_system_generated: true,
              system_type: "ganancias_retention",
              payment_method_code: PAYMENT_METHOD_RETENTION_GANANCIAS,
              value: i.retention_value_overridden ? i.value : amount
            };
            if (valueBase !== void 0) {
              next.value_base = valueBase;
            } else {
              delete next.value_base;
            }
            return next;
          }
          return i;
        });
      }
      const newItem = {
        tempId: crypto.randomUUID(),
        payment_method_code: PAYMENT_METHOD_RETENTION_GANANCIAS,
        value: amount,
        bank_id: null,
        bank_name: null,
        bank_code: null,
        check_number: null,
        check_date: null,
        check_key: null,
        chart_account: null,
        received_check_id: null,
        ui_account_code: "",
        ui_bank_code: "",
        ui_check_search: "",
        is_system_generated: true,
        system_type: "ganancias_retention",
        ...valueBase !== void 0 ? { value_base: valueBase } : {}
      };
      return [...prevItems, newItem];
    });
  }, [gananciasRetention]);
  useEffect(() => {
    setItems((prevItems) => {
      const withoutVendorRets = prevItems.filter((i) => !isVendorRetentionItem(i));
      const vendorRows = [];
      for (const vt of vendorRetentionTaxesAdditional) {
        const preview = vendorRetentionsPreview[vt.id];
        const amount = preview?.amount ?? 0;
        if (amount <= 0) continue;
        const existing = prevItems.find(
          (i) => isVendorRetentionItem(i) && (i.retention_tax_id === vt.id || parseTaxIdFromVendorRetentionCode(i.payment_method_code) === vt.id)
        );
        const code = buildVendorRetentionPaymentCode(vt.id);
        const valueBase = preview?.value_base != null && !Number.isNaN(Number(preview.value_base)) ? Number(preview.value_base) : void 0;
        vendorRows.push({
          tempId: existing?.tempId ?? crypto.randomUUID(),
          id: existing?.id,
          payment_method_code: code,
          value: existing?.retention_value_overridden ? existing.value : amount,
          bank_id: null,
          bank_name: null,
          bank_code: null,
          check_number: null,
          check_date: null,
          check_key: null,
          chart_account: null,
          received_check_id: null,
          ui_account_code: existing?.ui_account_code ?? "",
          ui_bank_code: existing?.ui_bank_code ?? "",
          ui_check_search: existing?.ui_check_search ?? "",
          is_system_generated: true,
          system_type: "vendor_retention",
          retention_tax_id: vt.id,
          retention_tax_name: vt.name,
          retention_value_overridden: existing?.retention_value_overridden,
          ...valueBase !== void 0 ? { value_base: valueBase } : {}
        });
      }
      return [...withoutVendorRets, ...vendorRows];
    });
  }, [vendorRetentionsPreview, vendorRetentionTaxesAdditional]);
  const handleItemChange = (tempId, field, value) => {
    if (field === "payment_method_code" || field === "chart_account") {
      const target = items.find((i) => i.tempId === tempId);
      if (target && isSystemRetentionPaymentRow(target)) {
        return;
      }
    }
    setItems((prev) => {
      const sumOtherSal = prev.filter((i) => i.payment_method_code === "SAL" && i.tempId !== tempId).reduce((s, i) => s + (Number(i.value) || 0), 0);
      const maxAdvanceForItem = Math.max(0, (vendorAdvanceBalance || 0) - sumOtherSal);
      return prev.map((item) => {
        if (item.tempId !== tempId) return item;
        const updatedItem = { ...item, [field]: value };
        if (field === "payment_method_code") {
          updatedItem.bank_id = null;
          updatedItem.bank_name = null;
          updatedItem.check_number = null;
          updatedItem.check_date = null;
          updatedItem.received_check_id = null;
          updatedItem.ui_bank_code = "";
          updatedItem.ui_check_search = "";
          updatedItem.ui_received_holder = "";
          updatedItem.ui_received_cuit = "";
          updatedItem.ui_received_reference = "";
          if (value !== "CHR") {
            updatedItem.received_check_id = null;
          }
          if (value === "CHR") {
            updatedItem.bank_id = null;
            updatedItem.bank_name = null;
            updatedItem.check_number = null;
            updatedItem.check_date = null;
            updatedItem.value = 0;
          }
          if (value === "EFE" || value === "SAL") {
            updatedItem.bank_id = null;
            updatedItem.bank_name = null;
            updatedItem.check_number = null;
            updatedItem.check_date = null;
            updatedItem.received_check_id = null;
          }
          if (value === "SAL") {
            const grossAmount = computeGrossAppliedAmount(appliedAmounts, appliedFinancialNoteAmounts);
            const discount = headerData.discount || 0;
            const totalTaxes = (vendorGeneralTaxes || []).reduce(
              (sum, vTax) => sum + discount * ((vTax.rate || 0) / 100),
              0
            );
            const netAmountToPay = grossAmount - discount - totalTaxes;
            updatedItem.value = Math.max(0, Math.min(netAmountToPay, maxAdvanceForItem));
          }
        }
        if (field === "value" && item.payment_method_code === "SAL") {
          const numVal = Number(value) || 0;
          if (numVal > maxAdvanceForItem) {
            toast.warn(`El monto no puede superar el saldo anticipado disponible (${formatValue(maxAdvanceForItem, "currency")}).`);
            updatedItem.value = maxAdvanceForItem;
          }
        }
        if (field === "value" && isSystemRetentionPaymentRow(item)) {
          updatedItem.retention_value_overridden = true;
        }
        return updatedItem;
      });
    });
  };
  const openModal = (target) => {
    setEditingTarget(target);
    let config = null;
    if (target === "vendor") {
      config = proveedoresModuleConfig;
    } else if (typeof target === "object" && target.type === "itemBank") {
      config = bancosModuleConfig;
    } else if (typeof target === "object" && target.type === "itemAccount") {
      config = planDeCuentasModuleConfig;
    } else if (typeof target === "object" && target.type === "itemReceivedCheck") {
      config = undeliveredChecksConfig;
    }
    setModalConfig(config);
    setIsModalOpen(true);
  };
  const handleSelectModal = (selectedItem) => {
    if (!editingTarget) return setIsModalOpen(false);
    const index = typeof editingTarget === "object" ? editingTarget.index : -1;
    const tempId = index !== -1 ? items[index].tempId : "";
    if (editingTarget === "vendor") {
      handleSelectVendor(selectedItem);
    } else if (typeof editingTarget === "object" && editingTarget.type === "itemBank") {
      handleItemChange(tempId, "bank_id", selectedItem.id);
      handleItemChange(tempId, "bank_name", selectedItem.name);
      handleItemChange(tempId, "ui_bank_code", selectedItem.code || String(selectedItem.id));
    } else if (typeof editingTarget === "object" && editingTarget.type === "itemAccount") {
      handleItemChange(tempId, "chart_account", selectedItem);
      handleItemChange(tempId, "ui_account_code", selectedItem.code);
    } else if (typeof editingTarget === "object" && editingTarget.type === "itemReceivedCheck") {
      const check = selectedItem;
      handleItemChange(tempId, "received_check_id", check.id);
      handleItemChange(tempId, "value", Number(check.value) || 0);
      handleItemChange(tempId, "bank_id", check.bank_id ?? null);
      handleItemChange(tempId, "bank_name", check.bank_name ?? "");
      handleItemChange(tempId, "check_number", check.check_number ?? "");
      handleItemChange(tempId, "check_date", check.check_date ?? "");
      handleItemChange(tempId, "ui_check_search", check.check_number ?? "");
      handleItemChange(tempId, "ui_received_holder", check.check_holder ?? "");
      handleItemChange(tempId, "ui_received_cuit", check.issuer_cuit ?? "");
      handleItemChange(tempId, "ui_received_reference", check.reference_number ?? "");
    }
    setIsModalOpen(false);
    setEditingTarget(null);
  };
  const performSavePaymentOrder = useCallback(
    async () => {
      const cleanItems = items.map((row) => {
        const {
          tempId,
          chart_account,
          retention_tax_name: _retentionName,
          is_system_generated: _isSys,
          system_type: _sysType,
          retention_tax_id: _retTid,
          retention_value_overridden: _retOverridden,
          ...rest
        } = row;
        const cleanItem = {
          ...rest,
          value: Number(rest.value) || 0,
          chart_account_id: chart_account?.id || null
        };
        if (rest.received_check_id) cleanItem.received_check_id = rest.received_check_id;
        if (rest.id) cleanItem.id = rest.id;
        delete cleanItem.ui_account_code;
        delete cleanItem.ui_bank_code;
        delete cleanItem.ui_check_search;
        delete cleanItem.ui_received_holder;
        delete cleanItem.ui_received_cuit;
        delete cleanItem.ui_received_reference;
        delete cleanItem.received_check;
        const itemForRetentionCheck = rest;
        if (isGananciasRetentionItem(itemForRetentionCheck) || isVendorRetentionItem(itemForRetentionCheck)) {
          if (rest.value_base != null && !Number.isNaN(Number(rest.value_base))) {
            cleanItem.value_base = Number(rest.value_base);
          } else {
            delete cleanItem.value_base;
          }
        } else {
          delete cleanItem.value_base;
        }
        return cleanItem;
      });
      const gananciasItem = items.find(isGananciasRetentionItem);
      const gananciasAmount = gananciasItem ? Number(gananciasItem.value) || 0 : 0;
      const vendorRetentionTaxEntries = vendorRetentionTaxesAdditional.map((vt) => {
        const retentionItem = items.find(
          (i) => isVendorRetentionItem(i) && (i.retention_tax_id === vt.id || parseTaxIdFromVendorRetentionCode(i.payment_method_code) === vt.id)
        );
        const amount = retentionItem ? Number(retentionItem.value) || 0 : vendorRetentionsPreview[vt.id]?.amount ?? 0;
        if (amount <= 0) return null;
        const p = vendorRetentionsPreview[vt.id];
        return {
          tax_id: vt.id,
          tax_name: p?.tax_name || vt.name,
          rate: 0,
          amount
        };
      }).filter((t) => t != null);
      const taxesToSave = [
        ...totals.appliedTaxes.filter((tax) => tax.amount > 0),
        ...gananciasRetention && gananciasAmount > 0 ? [{
          tax_id: gananciasRetention.tax_id,
          tax_name: "Retención Impuesto a las Ganancias",
          rate: 0,
          amount: gananciasAmount
        }] : [],
        ...vendorRetentionTaxEntries
      ];
      const applied_purchases = buildAppliedPurchasesForSave(appliedAmounts);
      const applied_financial_notes = buildAppliedFinancialNotesForSave(appliedFinancialNoteAmounts);
      const payload = {
        payment_date: headerData.payment_date,
        vendor_id: headerData.vendor_id,
        discount: headerData.discount,
        gross_amount: totals.grossAmount,
        items: cleanItems,
        taxes: taxesToSave,
        applied_purchases,
        applied_financial_notes,
        total_amount: totals.totalPaid
      };
      const result = await saveItem(payload);
      if (result) {
        toast.success(mode === "create" ? "Orden de pago creada con éxito." : "Orden de pago actualizada con éxito.");
        navigate(getListReturnPath(ordenesPagoModuleConfig.baseRoute));
      }
    },
    [
      items,
      totals.appliedTaxes,
      totals.grossAmount,
      totals.totalPaid,
      gananciasRetention,
      vendorRetentionsPreview,
      vendorRetentionTaxesAdditional,
      appliedAmounts,
      appliedFinancialNoteAmounts,
      headerData.payment_date,
      headerData.vendor_id,
      headerData.discount,
      saveItem,
      mode,
      navigate
    ]
  );
  const handleSave = async () => {
    if (!headerData.vendor_id) {
      toast.error("Seleccione un proveedor.");
      return;
    }
    const hasAppliedPurchases = buildAppliedPurchasesForSave(appliedAmounts).length > 0;
    const hasAppliedFinancialNotes = buildAppliedFinancialNotesForSave(appliedFinancialNoteAmounts).length > 0;
    const netIsZero = Math.abs(Number(totals.netAmountToPay) || 0) <= 0.01;
    const grossIsZero = Math.abs(Number(totals.grossAmount) || 0) <= 0.01;
    const allowZeroPayments = hasAppliedPurchases && (netIsZero || grossIsZero && hasAppliedFinancialNotes);
    const paymentItemsWithValue = items.filter(
      (i) => Math.abs(Number(i.value) || 0) > 0.01
    );
    if (!allowZeroPayments) {
      if (paymentItemsWithValue.length === 0) {
        toast.error("Debe añadir al menos un medio de pago.");
        return;
      }
      if (totals.totalPaid <= 0) {
        toast.error("La suma de los medios de pago debe ser mayor que 0.");
        return;
      }
    }
    for (const item of items) {
      if ((item.payment_method_code === "CHE" || item.payment_method_code === "TRA") && !item.bank_id) {
        toast.error("Para cheques propios y transferencias debe seleccionar un banco.");
        return;
      }
    }
    const difference = totals.grossAmount - totals.discount - totals.totalTaxes - totals.totalPaid;
    if (difference > 0.01) {
      toast.error(`Diferencia entre totales: falta pagar ${formatValue(difference, "currency")}`);
      return;
    }
    if (difference < -0.01) {
      const advanceAmount = Math.abs(difference);
      showConfirmationModal({
        title: "Saldo a favor del proveedor",
        message: `El total a pagar es menor que el importe de los medios de pago. Se generará saldo a favor (anticipo) por ${formatValue(advanceAmount, "currency")}. ¿Desea continuar?`,
        onConfirm: () => {
          void performSavePaymentOrder();
        }
      });
      return;
    }
    await performSavePaymentOrder();
  };
  if (loadingInitial && mode === "edit") return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
    lineNumber: 1274,
    columnNumber: 49
  }, this);
  const inputStyle = "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Crear Orden de Pago" : `Editando Orden de Pago #${id}` }, void 0, false, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1279,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "payment_date", className: "block text-sm font-medium text-gray-700", children: "Fecha de Pago" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1285,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "payment_date", type: "date", value: headerData.payment_date, onChange: (e) => handleHeaderChange("payment_date", e.target.value), className: inputStyle, autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1286,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1284,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: [
          "Proveedor ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1289,
            columnNumber: 94
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1289,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: vendorCodeInput,
            nameValue: headerData.vendor_name || null,
            onCodeChange: setVendorCodeInput,
            onCodeSubmit: handleVendorCodeSubmit,
            onSearchClick: () => openModal("vendor"),
            onClearClick: () => {
              setHeaderData((prev) => ({ ...prev, vendor_id: null, vendor_name: "", discount: 0 }));
              setVendorTaxes([]);
              setPendingPurchases([]);
              setPendingFinancialNotes([]);
              setAppliedAmounts({});
              setAppliedFinancialNoteAmounts({});
              setVendorCodeInput("");
              setVendorAdvanceBalance(0);
              setVendorRetentionInfo(null);
              setGananciasRetention(null);
              setVendorRetentionsPreview({});
            },
            disabled: mode === "edit"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1290,
            columnNumber: 25
          },
          this
        ),
        vendorAdvanceBalance > 0 && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: [
          "Saldo anticipado disponible: ",
          formatValue(vendorAdvanceBalance, "currency")
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1312,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1288,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1283,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1282,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Facturas Pendientes" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1320,
        columnNumber: 17
      }, this),
      showRetentionAmountHint && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-amber-700", children: "Ingrese el monto a aplicar en cada factura para calcular la retención." }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1322,
        columnNumber: 9
      }, this),
      isLoadingPurchases ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-4", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1327,
        columnNumber: 51
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1327,
        columnNumber: 9
      }, this) : pendingPurchases.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg max-h-96", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3 pl-4 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1333,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900", children: "Nº de Factura" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1334,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900", children: "Total" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1335,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900", children: "Saldo" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1336,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900 w-40", children: "Monto a Aplicar" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1337,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1332,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1331,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: pendingPurchases.map(
          (purchase) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 text-sm", children: formatValue(purchase.purchase_date, "date") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1343,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: purchase.document_number }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1344,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(purchase.total_amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1345,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-medium text-red-600", children: formatValue(purchase.balance, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1346,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: appliedAmounts[purchase.id],
                  onChange: (num) => handleAmountToApplyChange(purchase.id, num),
                  onBlur: () => handleAmountToApplyChange(purchase.id, appliedAmounts[purchase.id] ?? 0),
                  className: "flex-1 min-w-0 text-right input-form border rounded p-1",
                  max: Number(purchase.balance) || 0,
                  "aria-label": `Monto a aplicar para factura ${purchase.document_number}`
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1349,
                  columnNumber: 49
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleAmountToApplyChange(purchase.id, Number(purchase.balance) || 0),
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors",
                  title: "Llenar con saldo pendiente",
                  "aria-label": `Aplicar saldo completo (${formatValue(purchase.balance, "currency")}) para factura ${purchase.document_number}`,
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1365,
                    columnNumber: 53
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1358,
                  columnNumber: 49
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1348,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1347,
              columnNumber: 41
            }, this)
          ] }, purchase.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1342,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1340,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50 sticky bottom-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 4, className: "py-2 pl-4 pr-3 text-right text-sm font-semibold text-gray-900", children: "Total Aplicado:" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1374,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-bold", children: formatValue(totals.purchasesGrossAmount, "currency") }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1375,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1373,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1372,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1330,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1329,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-500", children: headerData.vendor_id ? "Sin facturas pendientes." : "Seleccione un proveedor." }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1381,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1319,
      columnNumber: 13
    }, this),
    pendingFinancialNotes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Notas Financieras Pendientes" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1388,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg max-h-96", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3 pl-4 text-left text-sm font-semibold text-gray-900", children: "Tipo" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1393,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1394,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-sm font-semibold text-gray-900", children: "Nº de Comprobante" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1395,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900", children: "Total" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1396,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900", children: "Saldo" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1397,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-sm font-semibold text-gray-900 w-40", children: "Monto a Aplicar" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1398,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1392,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1391,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: pendingFinancialNotes.map((note) => {
          const balance = signedNoteBalance(note);
          const total = signedNoteTotal(note);
          const docNumber = note.purchase?.document_number || note.voucher_number || "-";
          const isDebit = note.type === "DEBIT";
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 text-sm", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${isDebit ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`, children: isDebit ? "Débito" : "Crédito" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1410,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1409,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: formatValue(note.issue_date, "date") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1414,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: docNumber }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1415,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(total, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1416,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: `px-3 py-4 text-sm text-right font-medium ${balance < 0 ? "text-green-600" : "text-red-600"}`, children: formatValue(balance, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1417,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: appliedFinancialNoteAmounts[note.id],
                  onChange: (num) => handleFinancialNoteAmountChange(note.id, num),
                  onBlur: () => handleFinancialNoteAmountChange(note.id, appliedFinancialNoteAmounts[note.id] ?? 0),
                  className: "flex-1 min-w-0 text-right input-form border rounded p-1",
                  "aria-label": `Monto a aplicar para nota ${docNumber}`
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1422,
                  columnNumber: 53
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleFinancialNoteAmountChange(note.id, balance),
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors",
                  title: "Llenar con saldo pendiente",
                  "aria-label": `Aplicar saldo completo (${formatValue(balance, "currency")}) para nota ${docNumber}`,
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1437,
                    columnNumber: 57
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1430,
                  columnNumber: 53
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1421,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1420,
              columnNumber: 45
            }, this)
          ] }, note.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1408,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1401,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50 sticky bottom-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "py-2 pl-4 pr-3 text-right text-sm font-semibold text-gray-900", children: "Total Aplicado:" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1447,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-bold", children: formatValue(totals.financialNotesGrossAmount, "currency") }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1448,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1446,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1445,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1390,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1389,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1387,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-2", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium", children: "Medios de Pago" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1459,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddItem, className: "inline-flex items-center px-3 py-1 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700", children: [
          /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-1" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1461,
            columnNumber: 25
          }, this),
          " Añadir Medio"
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1460,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1458,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Medio" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1468,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cuenta" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1469,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Banco" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1470,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Cheque" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1471,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1472,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Importe" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1473,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1474,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1467,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1466,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
          const isReceivedCheck = item.payment_method_code === "CHR";
          const isOwnCheckOrTransfer = item.payment_method_code === "CHE" || item.payment_method_code === "TRA";
          const isCash = item.payment_method_code === "EFE";
          const isAdvanceBalance = item.payment_method_code === "SAL";
          const isSystemRetention = isSystemRetentionPaymentRow(item);
          const isGananciasRetention = isGananciasRetentionItem(item);
          const isVendorRet = isVendorRetentionItem(item);
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6 w-2/12 min-w-[140px]", children: /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: item.payment_method_code,
                onChange: (e) => handleItemChange(item.tempId, "payment_method_code", e.target.value),
                className: inputStyle,
                "aria-label": `Medio de pago ${index + 1}`,
                disabled: isSystemRetention,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "EFE", children: "Efectivo" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1498,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CHE", children: "Cheque Propio" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1499,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "TRA", children: "Transferencia" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1500,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CHR", children: "Cheque Recibido" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1501,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "AJU", children: "Ajuste" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1502,
                    columnNumber: 49
                  }, this),
                  vendorAdvanceBalance > 0 && /* @__PURE__ */ jsxDEV("option", { value: "SAL", children: [
                    "Saldo Anticipado (",
                    formatValue(vendorAdvanceBalance, "currency"),
                    ")"
                  ] }, void 0, true, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1504,
                    columnNumber: 25
                  }, this),
                  isGananciasRetention && /* @__PURE__ */ jsxDEV("option", { value: PAYMENT_METHOD_RETENTION_GANANCIAS, children: "Retención de Impuesto a las Ganancias" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1507,
                    columnNumber: 25
                  }, this),
                  isVendorRet && item.retention_tax_id != null && /* @__PURE__ */ jsxDEV("option", { value: buildVendorRetentionPaymentCode(item.retention_tax_id), children: vendorRetentionSelectLabel(item) }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1510,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                lineNumber: 1491,
                columnNumber: 45
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1490,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 w-3/12 min-w-[220px]", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.ui_account_code,
                nameValue: item.chart_account?.name ?? null,
                onCodeChange: (val) => handleItemChange(item.tempId, "ui_account_code", val),
                onCodeSubmit: () => handleItemCodeSubmit(item.tempId, "account"),
                onSearchClick: () => openModal({ type: "itemAccount", index }),
                onClearClick: () => {
                  handleItemChange(item.tempId, "chart_account", null);
                  handleItemChange(item.tempId, "ui_account_code", "");
                },
                disabled: isSystemRetention
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                lineNumber: 1519,
                columnNumber: 45
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1518,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 w-2/12 min-w-[180px]", children: /* @__PURE__ */ jsxDEV("div", { className: isCash || isSystemRetention ? "invisible" : "", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.ui_bank_code,
                nameValue: item.bank_name ?? null,
                onCodeChange: (val) => handleItemChange(item.tempId, "ui_bank_code", val),
                onCodeSubmit: () => handleItemCodeSubmit(item.tempId, "bank"),
                onSearchClick: () => openModal({ type: "itemBank", index }),
                onClearClick: () => {
                  handleItemChange(item.tempId, "bank_id", null);
                  handleItemChange(item.tempId, "bank_name", null);
                  handleItemChange(item.tempId, "ui_bank_code", "");
                },
                disabled: isAdvanceBalance || isReceivedCheck || isSystemRetention
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                lineNumber: 1536,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1535,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1534,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 w-2/12 min-w-[180px]", children: /* @__PURE__ */ jsxDEV("div", { className: isCash || isSystemRetention ? "invisible" : "", children: isReceivedCheck ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxDEV(
                RelationalInput,
                {
                  codeValue: item.ui_check_search,
                  nameValue: item.check_number ? `Cheque #${item.check_number}` : null,
                  onCodeChange: (val) => handleItemChange(item.tempId, "ui_check_search", val),
                  onCodeSubmit: () => handleItemCodeSubmit(item.tempId, "received_check"),
                  onSearchClick: () => openModal({ type: "itemReceivedCheck", index }),
                  onClearClick: () => {
                    handleItemChange(item.tempId, "received_check_id", null);
                    handleItemChange(item.tempId, "value", 0);
                    handleItemChange(item.tempId, "bank_id", null);
                    handleItemChange(item.tempId, "bank_name", null);
                    handleItemChange(item.tempId, "check_number", null);
                    handleItemChange(item.tempId, "check_date", null);
                    handleItemChange(item.tempId, "ui_check_search", "");
                    handleItemChange(item.tempId, "ui_received_holder", "");
                    handleItemChange(item.tempId, "ui_received_cuit", "");
                    handleItemChange(item.tempId, "ui_received_reference", "");
                  }
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1557,
                  columnNumber: 57
                },
                this
              ),
              (() => {
                const holder = item.ui_received_holder ?? item.received_check?.check_holder ?? "";
                const cuit = item.ui_received_cuit ?? item.received_check?.issuer_cuit ?? "";
                const reference = item.ui_received_reference ?? item.received_check?.reference_number ?? "";
                if (!holder && !cuit) return null;
                return /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: [
                  reference ? /* @__PURE__ */ jsxDEV("div", { children: [
                    "Referencia: ",
                    reference
                  ] }, void 0, true, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1583,
                    columnNumber: 82
                  }, this) : null,
                  holder ? /* @__PURE__ */ jsxDEV("div", { children: [
                    "Emisor: ",
                    holder
                  ] }, void 0, true, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1584,
                    columnNumber: 79
                  }, this) : null,
                  cuit ? /* @__PURE__ */ jsxDEV("div", { children: [
                    "CUIT: ",
                    cuit
                  ] }, void 0, true, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1585,
                    columnNumber: 77
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1582,
                  columnNumber: 31
                }, this);
              })()
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1556,
              columnNumber: 25
            }, this) : /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                disabled: isAdvanceBalance || isSystemRetention,
                value: item.check_number || "",
                onChange: (e) => handleItemChange(item.tempId, "check_number", e.target.value),
                className: inputStyle,
                placeholder: isOwnCheckOrTransfer ? "Nº Cheque / Ref." : "",
                "aria-label": `Referencia ${index + 1}`,
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                lineNumber: 1591,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1554,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1553,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 w-1/12 min-w-[130px]", children: /* @__PURE__ */ jsxDEV("div", { className: isCash || isSystemRetention ? "invisible" : "", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                disabled: isAdvanceBalance || isReceivedCheck || isSystemRetention,
                value: item.check_date ? formatDateForInput(new Date(item.check_date)) : "",
                onChange: (e) => handleItemChange(item.tempId, "check_date", e.target.value),
                className: inputStyle,
                "aria-label": `Fecha ${index + 1}`,
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                lineNumber: 1606,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1605,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1604,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 w-1/12 min-w-[120px]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  disabled: isReceivedCheck,
                  value: item.value,
                  onChange: (num) => handleItemChange(item.tempId, "value", num),
                  placeholder: "0.00",
                  className: `${inputStyle} text-right flex-1 min-w-0`,
                  "aria-label": `Importe ${index + 1}`
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1619,
                  columnNumber: 49
                },
                this
              ),
              !isReceivedCheck && !isSystemRetention && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => fillPaymentItemFromAppliedTotal(item.tempId),
                  disabled: totals.grossAmount <= 0,
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors disabled:opacity-40 disabled:pointer-events-none",
                  title: "Completar con el faltante respecto al total aplicado (excluye esta línea)",
                  "aria-label": "Completar valor con el faltante respecto al total aplicado",
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                    lineNumber: 1637,
                    columnNumber: 57
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
                  lineNumber: 1629,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1618,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1617,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6 whitespace-nowrap", children: !isSystemRetention && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveItem(item.tempId), className: "text-red-500 hover:text-red-700 p-1", "aria-label": `Eliminar item ${index + 1}`, children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1647,
              columnNumber: 53
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1646,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1644,
              columnNumber: 41
            }, this)
          ] }, item.tempId, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1488,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1477,
          columnNumber: 25
        }, this),
        items.length > 0 && /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "py-2 pl-4 pr-3 text-right text-sm font-semibold text-gray-900 sm:pl-6", children: "Total Medios de Pago:" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1658,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-bold", children: formatValue(totals.totalPaid, "currency") }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1659,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", {}, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1660,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1657,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1656,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1465,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1464,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1457,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2 p-4 border rounded-lg space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Descuentos y Retenciones" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1671,
          columnNumber: 21
        }, this),
        gananciasRetention && (() => {
          const ganItem = items.find(isGananciasRetentionItem);
          const displayAmount = ganItem ? Number(ganItem.value) || 0 : gananciasRetention.amount ?? 0;
          if (displayAmount <= 0) return null;
          return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-medium text-gray-700 col-span-2", children: [
              "Retención Impuesto a las Ganancias",
              gananciasRetention.case_code ? ` (case ${gananciasRetention.case_code})` : ""
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1705,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "w-full px-2 py-1 text-right text-gray-800 bg-gray-100 rounded-md", children: formatValue(displayAmount, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1708,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1704,
            columnNumber: 15
          }, this);
        })(),
        vendorRetentionTaxesAdditional.map((vt) => {
          const p = vendorRetentionsPreview[vt.id];
          const retentionItem = items.find(
            (i) => isVendorRetentionItem(i) && (i.retention_tax_id === vt.id || parseTaxIdFromVendorRetentionCode(i.payment_method_code) === vt.id)
          );
          const displayAmount = retentionItem ? Number(retentionItem.value) || 0 : p?.amount ?? 0;
          if (displayAmount <= 0) return null;
          const labelName = (p?.tax_name || vt.name || "").trim();
          return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-medium text-gray-700 col-span-2", children: labelName ? `Retención ${labelName}` : "Retención" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1729,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "w-full px-2 py-1 text-right text-gray-800 bg-gray-100 rounded-md", children: formatValue(displayAmount, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1732,
              columnNumber: 33
            }, this)
          ] }, vt.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1728,
            columnNumber: 15
          }, this);
        })
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1670,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 border rounded-lg space-y-2 flex flex-col justify-center h-fit", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800 mb-4", children: "Resumen" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1740,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Importe Bruto:" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1742,
              columnNumber: 71
            }, this),
            " ",
            /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.grossAmount, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1742,
              columnNumber: 99
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1742,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Neto a Pagar:" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1750,
              columnNumber: 73
            }, this),
            " ",
            /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.remainingToPay, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
              lineNumber: 1750,
              columnNumber: 100
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1750,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1741,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold text-lg border-t pt-2 mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "TOTAL PAGADO (medios):" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1752,
            columnNumber: 96
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.totalPaid, "currency") }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
            lineNumber: 1752,
            columnNumber: 132
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1752,
          columnNumber: 21
        }, this),
        (Boolean(gananciasRetention && gananciasRetention.amount > 0) || vendorRetentionTaxesAdditional.some((vt) => (vendorRetentionsPreview[vt.id]?.amount ?? 0) > 0)) && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Incluye retenciones aplicadas como medios de pago." }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1755,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1739,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1669,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(ordenesPagoModuleConfig.baseRoute)), className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1762,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: saving || isLoadingPurchases, className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:opacity-50", children: [
        saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1764,
          columnNumber: 31
        }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
          lineNumber: 1764,
          columnNumber: 85
        }, this),
        "Guardar"
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
        lineNumber: 1763,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1761,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => setIsModalOpen(false), onSelect: handleSelectModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
      lineNumber: 1770,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx",
    lineNumber: 1278,
    columnNumber: 5
  }, this);
};
_s(OrdenesPagoFormPage, "Wt92QB2Sb7qnGl3NI1NY3lGVf0c=", false, function() {
  return [useParams, useNavigate, useCrudItem, useModal];
});
_c = OrdenesPagoFormPage;
var _c;
$RefreshReg$(_c, "OrdenesPagoFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc3VDa0QsU0FtZDlCLFVBbmQ4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFydUNsRCxTQUFTQSxVQUFVQyxXQUFXQyxTQUFTQyxtQkFBbUI7QUFDMUQsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsV0FBV0MsUUFBUUMsU0FBU0Msa0JBQWtCO0FBQy9ELFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxTQUFTQyxRQUFRQyxxQkFBcUI7QUFDL0MsU0FBU0MsMkJBQTJCQyx3QkFBd0I7QUFDNUQ7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1A7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUtBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsU0FBeUJDLCtCQUErQjtBQUN4RCxlQUE4QjtBQUM5QixlQUEyQztBQUMzQyxTQUFTQyxpQ0FBcUQ7QUFDOUQsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLDBCQUEwQjtBQUNoRCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsMEJBQTBCO0FBRW5DLFNBQVNDLHlCQUF5QjtBQWdEbEMsU0FBU0MseUJBQXlCQyxNQUEwRztBQUN4SSxTQUNLQyxRQUFRRCxLQUFLRSxtQkFBbUIsS0FBS0YsS0FBS0csZ0JBQWdCLHlCQUMzREgsS0FBS0ksd0JBQXdCeEI7QUFFckM7QUFFQSxTQUFTeUIsc0JBQXNCTCxNQUEwRztBQUNySSxTQUNLQyxRQUFRRCxLQUFLRSxtQkFBbUIsS0FBS0YsS0FBS0csZ0JBQWdCLHNCQUMzRG5CLG9DQUFvQ2dCLEtBQUtJLG1CQUFtQjtBQUVwRTtBQUdBLFNBQVNFLDRCQUE0Qk4sTUFBMEc7QUFDM0ksU0FBT0QseUJBQXlCQyxJQUFJLEtBQUtLLHNCQUFzQkwsSUFBSTtBQUN2RTtBQUVBLFNBQVNPLDJCQUEyQlAsTUFBb0M7QUFDcEUsUUFBTVEsSUFBSVIsS0FBS1Msb0JBQW9CQyxLQUFLO0FBQ3hDLFNBQU9GLElBQUksYUFBYUEsQ0FBQyxLQUFLO0FBQ2xDO0FBRU8sYUFBTUcsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxFQUFFQyxHQUFHLElBQUl0RCxVQUEwQjtBQUN6QyxRQUFNdUQsV0FBV3hELFlBQVk7QUFDN0IsUUFBTXlELE9BQU9GLEtBQUssU0FBUztBQUUzQixRQUFNLEVBQUViLE1BQU1nQixhQUFhQyxTQUFTQyxnQkFBZ0JDLFVBQVVGLFNBQVNHLE9BQU8sSUFDMUV0RCxZQUEwQmEseUJBQXlCa0MsRUFBRTtBQUN6RCxRQUFNLEVBQUVRLHNCQUFzQixJQUFJekIsU0FBUztBQUczQyxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUlyRSxTQUFTO0FBQUEsSUFDekNzRSxjQUFjN0IsbUJBQW1CLG9CQUFJOEIsS0FBSyxDQUFDO0FBQUEsSUFDM0NDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsSUFDYkMsVUFBVTtBQUFBLEVBQ2QsQ0FBQztBQUdELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTVFLFNBQVMsRUFBRTtBQUV6RCxRQUFNLENBQUM2RSxPQUFPQyxRQUFRLElBQUk5RSxTQUFpQyxFQUFFO0FBQzdELFFBQU0sQ0FBQytFLGFBQWFDLGNBQWMsSUFBSWhGLFNBQXNCLEVBQUU7QUFDOUQsUUFBTSxDQUFDaUYscUJBQXFCQyxzQkFBc0IsSUFBSWxGLFNBQXFDLElBQUk7QUFFL0YsUUFBTSxDQUFDbUYsa0JBQWtCQyxtQkFBbUIsSUFBSXBGLFNBQXFCLEVBQUU7QUFDdkUsUUFBTSxDQUFDcUYsdUJBQXVCQyx3QkFBd0IsSUFBSXRGLFNBQWtDLEVBQUU7QUFDOUYsUUFBTSxDQUFDdUYsb0JBQW9CQyxxQkFBcUIsSUFBSXhGLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUN5RixnQkFBZ0JDLGlCQUFpQixJQUFJMUYsU0FBMEMsQ0FBQyxDQUFDO0FBQ3hGLFFBQU0sQ0FBQzJGLDZCQUE2QkMsOEJBQThCLElBQUk1RixTQUEwQyxDQUFDLENBQUM7QUFDbEgsUUFBTSxDQUFDNkYsc0JBQXNCQyx1QkFBdUIsSUFBSTlGLFNBQVMsQ0FBQztBQUVsRSxRQUFNLENBQUMrRixvQkFBb0JDLHFCQUFxQixJQUFJaEcsU0FPMUMsSUFBSTtBQUdkLFFBQU0sQ0FBQ2lHLHlCQUF5QkMsMEJBQTBCLElBQUlsRztBQUFBQSxJQUU1RCxDQUFDO0FBQUEsRUFBQztBQUdKLFFBQU0sQ0FBQ21HLGFBQWFDLGNBQWMsSUFBSXBHLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNxRyxlQUFlQyxnQkFBZ0IsSUFBSXRHLFNBQStCLElBQUk7QUFDN0UsUUFBTSxDQUFDdUcsYUFBYUMsY0FBYyxJQUFJeEcsU0FBYyxJQUFJO0FBR3hEQyxZQUFVLE1BQU07QUFDWixRQUFJNEQsU0FBUyxVQUFVQyxhQUFhO0FBQ2hDTyxvQkFBYztBQUFBLFFBQ1ZDLGNBQWM3QixtQkFBbUIsSUFBSThCLEtBQUtULFlBQVlRLFlBQVksQ0FBQztBQUFBLFFBQ25FRSxXQUFXVixZQUFZVTtBQUFBQSxRQUN2QkMsYUFBYVgsWUFBWTJDLFFBQVFDLFFBQVE7QUFBQSxRQUN6Q2hDLFVBQVVaLFlBQVlZLFlBQVk7QUFBQSxNQUN0QyxDQUFDO0FBR0QsVUFBSVosWUFBWTJDLFFBQVE7QUFDcEI3QiwyQkFBbUJkLFlBQVkyQyxPQUFPRSxlQUFlQyxPQUFPOUMsWUFBWVUsU0FBUyxDQUFDO0FBQ2xGc0IsaUNBQXlCZSxPQUFPL0MsWUFBWTJDLE9BQU9LLGVBQWUsS0FBSyxLQUFLLEVBQUU7QUFDOUU1QiwrQkFBdUI7QUFBQSxVQUNuQjZCLGVBQWVoRSxRQUFRZSxZQUFZMkMsT0FBT00sYUFBYTtBQUFBLFVBQ3ZEQyxhQUFhbEQsWUFBWTJDLE9BQU9PLGVBQWU7QUFBQSxRQUNuRCxDQUFDO0FBQUEsTUFDTDtBQUdBLFlBQU1DLGNBQWNuRCxZQUFZZSxPQUFPcUMsSUFBSSxDQUFBQyxNQUFLO0FBQzVDLGNBQU1DLFVBQWdDO0FBQUEsVUFDbENsRSxxQkFBcUJpRSxFQUFFakU7QUFBQUEsVUFDdkJtRSxTQUFTRixFQUFFRTtBQUFBQSxVQUNYQyxXQUFXSCxFQUFFRztBQUFBQSxVQUNiQyxXQUFXSixFQUFFSTtBQUFBQSxVQUNiQyxjQUFjTCxFQUFFSztBQUFBQSxVQUNoQkMsWUFBWU4sRUFBRU07QUFBQUEsVUFDZEMsT0FBT2IsT0FBT00sRUFBRU8sS0FBSyxLQUFLO0FBQUEsVUFDMUJDLFdBQVdSLEVBQUVRO0FBQUFBLFVBQ2JDLGVBQWVULEVBQUVTO0FBQUFBLFVBQ2pCQyxtQkFBbUJWLEVBQUVVO0FBQUFBLFVBQ3JCQyxnQkFBZ0JYLEVBQUVXLGtCQUFrQjtBQUFBLFVBQ3BDQyxRQUFRQyxPQUFPQyxXQUFXO0FBQUEsVUFDMUJ0RSxJQUFJd0QsRUFBRXhEO0FBQUFBLFVBQ04sR0FBSXdELEVBQUVlLGNBQWMsUUFBUSxDQUFDckIsT0FBT3NCLE1BQU10QixPQUFPTSxFQUFFZSxVQUFVLENBQUMsSUFDeEQsRUFBRUEsWUFBWXJCLE9BQU9NLEVBQUVlLFVBQVUsRUFBRSxJQUNuQyxDQUFDO0FBQUEsVUFFUEUsaUJBQWlCakIsRUFBRVMsZUFBZVMsUUFBUTtBQUFBLFVBQzFDQyxjQUFjbkIsRUFBRUksYUFBYTtBQUFBLFVBQzdCZ0IsaUJBQWlCcEIsRUFBRUssZ0JBQWdCO0FBQUEsVUFDbkNnQixvQkFBb0JyQixFQUFFVyxnQkFBZ0JXLGdCQUFnQjtBQUFBLFVBQ3REQyxrQkFBa0J2QixFQUFFVyxnQkFBZ0JhLGVBQWU7QUFBQSxVQUNuREMsdUJBQXVCekIsRUFBRVcsZ0JBQWdCZSxvQkFBb0I7QUFBQSxRQUNqRTtBQUNBLFlBQUkxQixFQUFFMkIsTUFBTTtBQUNSMUIsa0JBQVFFLFlBQVlILEVBQUUyQixLQUFLcEM7QUFBQUEsUUFDL0I7QUFDQSxZQUFJUyxFQUFFakUsd0JBQXdCeEIsb0NBQW9DO0FBQzlEMEYsa0JBQVFwRSxzQkFBc0I7QUFDOUJvRSxrQkFBUW5FLGNBQWM7QUFDdEJtRSxrQkFBUTJCLDZCQUE2QjtBQUFBLFFBQ3pDO0FBQ0EsY0FBTUMsaUJBQWlCbkgsa0NBQWtDc0YsRUFBRWpFLG1CQUFtQjtBQUM5RSxZQUFJOEYsa0JBQWtCLE1BQU07QUFDeEI1QixrQkFBUXBFLHNCQUFzQjtBQUM5Qm9FLGtCQUFRbkUsY0FBYztBQUN0Qm1FLGtCQUFRNkIsbUJBQW1CRDtBQUMzQjVCLGtCQUFRMkIsNkJBQTZCO0FBQ3JDLGdCQUFNRyxXQUFXcEYsWUFBWXFGLGVBQWVDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV04sY0FBYztBQUNqRjVCLGtCQUFRN0QscUJBQXFCMkYsVUFBVUssWUFBWUM7QUFBQUEsUUFDdkQ7QUFDQSxlQUFPcEM7QUFBQUEsTUFDWCxDQUFDLEtBQUs7QUFDTixVQUFJcUMsYUFBYTtBQUNqQixZQUFNQyw0QkFBNEIsb0JBQUlDLElBQVk7QUFDbEQsWUFBTUMsZ0JBQWdCM0MsWUFBWTRDLE9BQU8sQ0FBQUMsT0FBTTtBQUMzQyxZQUFJQSxHQUFHNUcsd0JBQXdCeEIsb0NBQW9DO0FBQy9ELGNBQUkrSCxXQUFZLFFBQU87QUFDdkJBLHVCQUFhO0FBQ2IsaUJBQU87QUFBQSxRQUNYO0FBQ0EsY0FBTU0sT0FBT2xJLGtDQUFrQ2lJLEdBQUc1RyxtQkFBbUI7QUFDckUsWUFBSTZHLFFBQVEsTUFBTTtBQUNkLGNBQUlMLDBCQUEwQk0sSUFBSUQsSUFBSSxFQUFHLFFBQU87QUFDaERMLG9DQUEwQk8sSUFBSUYsSUFBSTtBQUNsQyxpQkFBTztBQUFBLFFBQ1g7QUFDQSxlQUFPO0FBQUEsTUFDWCxDQUFDO0FBQ0RqRixlQUFTOEUsYUFBYTtBQUV0QixZQUFNTSxpQkFBaUJOLGNBQWNSLEtBQUssQ0FBQWpDLE1BQUtBLEVBQUVqRSx3QkFBd0J4QixrQ0FBa0M7QUFDM0csWUFBTXlJLDhCQUNGRCxrQkFBa0IsUUFDZEEsZUFBZWhDLGNBQWMsUUFDN0IsQ0FBQ3JCLE9BQU9zQixNQUFNdEIsT0FBT3FELGVBQWVoQyxVQUFVLENBQUMsSUFDN0NyQixPQUFPcUQsZUFBZWhDLFVBQVUsSUFDaENzQjtBQUVWLFlBQU1ZLFNBQVN0RyxZQUFZcUYsZUFBZUM7QUFBQUEsUUFDdEMsQ0FBQUMsTUFBS0EsRUFBRUMsV0FBVzNILG9CQUFxQjBILEVBQUVFLFlBQVlGLEVBQUVFLFNBQVNjLFNBQVMsV0FBVztBQUFBLE1BQ3hGO0FBQ0EsVUFBSUQsVUFBVXZELE9BQU91RCxPQUFPRSxNQUFNLElBQUksR0FBRztBQUNyQ3RFLDhCQUFzQjtBQUFBLFVBQ2xCc0UsUUFBUXpELE9BQU91RCxPQUFPRSxNQUFNO0FBQUEsVUFDNUJoQixRQUFRYyxPQUFPZDtBQUFBQSxVQUNmOUUsV0FBV1YsWUFBWVU7QUFBQUEsVUFDdkIrRixXQUFXekcsWUFBWTJDLFFBQVFPLGVBQWU7QUFBQSxVQUM5QyxHQUFJbUQsZ0NBQWdDWCxTQUFZLEVBQUV0QixZQUFZaUMsNEJBQTRCLElBQUksQ0FBQztBQUFBLFFBQ25HLENBQUM7QUFBQSxNQUNMLE9BQU87QUFDSCxjQUFNSyxRQUFRTjtBQUNkLFlBQUlNLFNBQVMzRCxPQUFPMkQsTUFBTTlDLEtBQUssSUFBSSxHQUFHO0FBQ2xDMUIsZ0NBQXNCO0FBQUEsWUFDbEJzRSxRQUFRekQsT0FBTzJELE1BQU05QyxLQUFLO0FBQUEsWUFDMUI0QixRQUFRM0g7QUFBQUEsWUFDUjZDLFdBQVdWLFlBQVlVO0FBQUFBLFlBQ3ZCK0YsV0FBV3pHLFlBQVkyQyxRQUFRTyxlQUFlO0FBQUEsWUFDOUMsR0FBSW1ELGdDQUFnQ1gsU0FBWSxFQUFFdEIsWUFBWWlDLDRCQUE0QixJQUFJLENBQUM7QUFBQSxVQUNuRyxDQUFDO0FBQUEsUUFDTCxPQUFPO0FBQ0huRSxnQ0FBc0IsSUFBSTtBQUFBLFFBQzlCO0FBQUEsTUFDSjtBQUVBLFlBQU15RSwwQkFHRixDQUFDO0FBQ0wsaUJBQVdYLE1BQU1GLGVBQWU7QUFDNUIsY0FBTWMsTUFBTTdJLGtDQUFrQ2lJLEdBQUc1RyxtQkFBbUI7QUFDcEUsWUFBSXdILE9BQU8sS0FBTTtBQUNqQixjQUFNQyxLQUFLN0csWUFBWXFGLGVBQWVDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsV0FBV29CLEdBQUc7QUFDaEUsY0FBTUUsY0FDRmQsR0FBRzVCLGNBQWMsUUFBUSxDQUFDckIsT0FBT3NCLE1BQU10QixPQUFPaUQsR0FBRzVCLFVBQVUsQ0FBQyxJQUFJckIsT0FBT2lELEdBQUc1QixVQUFVLElBQUlzQjtBQUM1RmlCLGdDQUF3QkMsR0FBRyxJQUFJO0FBQUEsVUFDM0JwQixRQUFRb0I7QUFBQUEsVUFDUm5CLFdBQVdvQixJQUFJcEIsWUFBWU8sR0FBR3ZHLHVCQUF1QjtBQUFBLFVBQ3JEK0csUUFBUXpELE9BQU84RCxJQUFJTCxNQUFNLEtBQUt6RCxPQUFPaUQsR0FBR3BDLEtBQUssS0FBSztBQUFBLFVBQ2xELEdBQUlrRCxnQkFBZ0JwQixTQUFZLEVBQUV0QixZQUFZMEMsWUFBWSxJQUFJLENBQUM7QUFBQSxRQUNuRTtBQUFBLE1BQ0o7QUFDQTFFLGlDQUEyQnVFLHVCQUF1QjtBQUVsRCxZQUFNSSxrQkFBa0IsT0FBT0MsYUFBcUI7QUFDaEQsWUFBSTtBQUNBLGdCQUFNQyxhQUFhLE1BQU1sSyxRQUF3RCxXQUFXaUssUUFBUTtBQUNwRzlGLHlCQUFlK0YsV0FBV0MsU0FBUyxFQUFFO0FBQ3JDbEYsbUNBQXlCZSxPQUFPa0UsV0FBV2pFLGVBQWUsS0FBSyxLQUFLLEVBQUU7QUFDdEU1QixpQ0FBdUI7QUFBQSxZQUNuQjZCLGVBQWVoRSxRQUFRZ0ksV0FBV2hFLGFBQWE7QUFBQSxZQUMvQ0MsYUFBYStELFdBQVcvRCxlQUFlO0FBQUEsVUFDM0MsQ0FBQztBQUFBLFFBQ0wsUUFBUTtBQUFFMUcsZ0JBQU0ySyxNQUFNLDBDQUEwQztBQUFBLFFBQUc7QUFBQSxNQUN2RTtBQUNBLFVBQUluSCxZQUFZVSxXQUFXO0FBQ3ZCcUcsd0JBQWdCL0csWUFBWVUsU0FBUztBQUFBLE1BQ3pDO0FBRUEsWUFBTTBHLGVBQWUsWUFBWTtBQUM3QixZQUFJLENBQUNwSCxZQUFZVSxVQUFXO0FBQzVCZ0IsOEJBQXNCLElBQUk7QUFDMUIsWUFBSTtBQUNBLGdCQUFNMkYsU0FBUyxJQUFJQyxnQkFBZ0IsRUFBRTVHLFdBQVdWLFlBQVlVLFVBQVU2RyxTQUFTLEdBQUdDLGFBQWEsT0FBTyxDQUFDO0FBQ3ZHLGdCQUFNQyx5QkFBeUJ6SyxPQUFpQixhQUFhcUssT0FBT0UsU0FBUyxDQUFDLEVBQUU7QUFDaEYsZ0JBQU1HLHNCQUFzQjFLLE9BQThCLDRCQUE0QnFLLE9BQU9FLFNBQVMsQ0FBQyxFQUFFO0FBQ3pHLGdCQUFNSSxxQkFBcUIzSCxZQUFZNEgsbUJBQW1CeEUsSUFBSSxDQUFBeUUsT0FBTUEsR0FBR0MsU0FBU2pJLEVBQUUsS0FBSztBQUN2RixnQkFBTWtJLDJCQUEyQkosbUJBQW1CdkUsSUFBSSxDQUFBdkQsUUFBTTlDLFFBQWtCLGFBQWE4QyxHQUFFLENBQUM7QUFDaEcsZ0JBQU1tSSxpQkFBaUJoSSxZQUFZaUkseUJBQXlCN0UsSUFBSSxDQUFBOEUsT0FBTUEsR0FBR0Msd0JBQXdCdEksRUFBRSxLQUFLO0FBQ3hHLGdCQUFNdUksdUJBQXVCSixlQUFlNUU7QUFBQUEsWUFBSSxDQUFBaUYsV0FDNUN0TCxRQUErQiw0QkFBNEJzTCxNQUFNO0FBQUEsVUFDckU7QUFFQSxnQkFBTSxDQUFDQyxpQkFBaUJDLHNCQUFzQixHQUFHQyxjQUFjLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsWUFBSTtBQUFBLGNBQ2pGakI7QUFBQUEsY0FDQUM7QUFBQUEsY0FDQSxHQUFHSztBQUFBQSxjQUNILEdBQUdLO0FBQUFBLFlBQW9CO0FBQUEsVUFDMUI7QUFDRCxnQkFBTU8sMEJBQTBCSCxlQUFlSSxNQUFNLEdBQUdiLHlCQUF5QmMsTUFBTTtBQUN2RixnQkFBTUMsc0JBQXNCTixlQUFlSSxNQUFNYix5QkFBeUJjLE1BQU07QUFFaEYsZ0JBQU1FLGtCQUFrQixvQkFBSUMsSUFBc0I7QUFDbERMLGtDQUF3Qk0sUUFBUSxDQUFBQyxNQUFLO0FBQUUsZ0JBQUlBLEVBQUdILGlCQUFnQkksSUFBSUQsRUFBRXJKLElBQUlxSixDQUFDO0FBQUEsVUFBRyxDQUFDO0FBQzdFWiwwQkFBZ0JjLEtBQUtILFFBQVEsQ0FBQUMsTUFBSztBQUFFLGdCQUFJLENBQUNILGdCQUFnQjdDLElBQUlnRCxFQUFFckosRUFBRSxFQUFHa0osaUJBQWdCSSxJQUFJRCxFQUFFckosSUFBSXFKLENBQUM7QUFBQSxVQUFHLENBQUM7QUFFbkcsZ0JBQU1HLGlCQUFpQkMsTUFBTUMsS0FBS1IsZ0JBQWdCUyxPQUFPLENBQUMsRUFBRXBHLElBQUksQ0FBQThGLE1BQUs7QUFDakUsa0JBQU1PLGdCQUFnQnpKLFlBQVk0SCxtQkFBbUJ0QyxLQUFLLENBQUF1QyxPQUFNQSxHQUFHQyxTQUFTakksT0FBT3FKLEVBQUVySixFQUFFO0FBQ3ZGLGdCQUFJNEosZUFBZTtBQUNmLG9CQUFNQyxtQkFBbUIzRyxPQUFPbUcsRUFBRVMsT0FBTyxLQUFLLE1BQU01RyxPQUFPMEcsY0FBY0csY0FBYyxLQUFLO0FBQzVGLHFCQUFPLEVBQUUsR0FBR1YsR0FBR1MsU0FBU0QsZ0JBQWdCO0FBQUEsWUFDNUM7QUFDQSxtQkFBT1I7QUFBQUEsVUFDWCxDQUFDO0FBQ0Q1SCw4QkFBb0IrSCxjQUFjO0FBRWxDLGdCQUFNUSxjQUFjLG9CQUFJYixJQUFtQztBQUMzREYsOEJBQW9CRyxRQUFRLENBQUF6SixNQUFLO0FBQUUsZ0JBQUlBLEVBQUdxSyxhQUFZVixJQUFJM0osRUFBRUssSUFBSUwsQ0FBQztBQUFBLFVBQUcsQ0FBQztBQUNyRStJLCtCQUFxQmEsS0FBS0gsUUFBUSxDQUFBekosTUFBSztBQUFFLGdCQUFJLENBQUNxSyxZQUFZM0QsSUFBSTFHLEVBQUVLLEVBQUUsRUFBR2dLLGFBQVlWLElBQUkzSixFQUFFSyxJQUFJTCxDQUFDO0FBQUEsVUFBRyxDQUFDO0FBRWhHLGdCQUFNc0ssYUFBYVIsTUFBTUMsS0FBS00sWUFBWUwsT0FBTyxDQUFDLEVBQUVwRyxJQUFJLENBQUE1RCxNQUFLO0FBQ3pELGtCQUFNaUssZ0JBQWdCekosWUFBWWlJLHlCQUF5QjNDO0FBQUFBLGNBQ3ZELENBQUE0QyxPQUFNQSxHQUFHQyx3QkFBd0J0SSxPQUFPTCxFQUFFSztBQUFBQSxZQUM5QztBQUNBLGdCQUFJNEosZUFBZTtBQUNmLG9CQUFNTSxpQkFBaUI5TCxrQkFBa0J1QixDQUFDO0FBQzFDLG9CQUFNa0ssa0JBQWtCSyxrQkFBa0JoSCxPQUFPMEcsY0FBY0csY0FBYyxLQUFLO0FBQ2xGLHFCQUFPLEVBQUUsR0FBR3BLLEdBQUdtSyxTQUFTRCxnQkFBZ0I7QUFBQSxZQUM1QztBQUNBLG1CQUFPbEs7QUFBQUEsVUFDWCxDQUFDO0FBQ0RnQyxtQ0FBeUJzSSxVQUFVO0FBRW5DLGNBQUk5SixZQUFZNEgsbUJBQW1CO0FBQy9CLGtCQUFNb0MsaUJBQWlCaEssWUFBWTRILGtCQUFrQnFDLE9BQU8sQ0FBQ0MsS0FBS3JDLE9BQU87QUFDckVxQyxrQkFBSXJDLEdBQUdDLFNBQVNqSSxFQUFFLElBQUlrRCxPQUFPOEUsR0FBRytCLGNBQWMsS0FBSztBQUNuRCxxQkFBT007QUFBQUEsWUFDWCxHQUFHLENBQUMsQ0FBb0M7QUFDeEN0SSw4QkFBa0JvSSxjQUFjO0FBQUEsVUFDcEM7QUFFQSxjQUFJaEssWUFBWWlJLHlCQUF5QjtBQUNyQyxrQkFBTWtDLHFCQUFxQm5LLFlBQVlpSSx3QkFBd0JnQyxPQUFPLENBQUNDLEtBQUtoQyxPQUFPO0FBQy9FZ0Msa0JBQUloQyxHQUFHQyx3QkFBd0J0SSxFQUFFLElBQUlrRCxPQUFPbUYsR0FBRzBCLGNBQWMsS0FBSztBQUNsRSxxQkFBT007QUFBQUEsWUFDWCxHQUFHLENBQUMsQ0FBb0M7QUFDeENwSSwyQ0FBK0JxSSxrQkFBa0I7QUFBQSxVQUNyRDtBQUFBLFFBQ0osU0FBU2hELE9BQU87QUFDWjNLLGdCQUFNMkssTUFBTSxtREFBbUQ7QUFDL0RpRCxrQkFBUWpELE1BQU1BLEtBQUs7QUFBQSxRQUN2QixVQUFDO0FBQ0d6RixnQ0FBc0IsS0FBSztBQUFBLFFBQy9CO0FBQUEsTUFDSjtBQUNBMEYsbUJBQWE7QUFBQSxJQUNqQixXQUNTckgsU0FBUyxVQUFVO0FBQ3hCbUIscUJBQWUsRUFBRTtBQUNqQkUsNkJBQXVCLElBQUk7QUFDM0JjLDRCQUFzQixJQUFJO0FBQzFCRSxpQ0FBMkIsQ0FBQyxDQUFDO0FBQzdCWiwrQkFBeUIsRUFBRTtBQUMzQk0scUNBQStCLENBQUMsQ0FBQztBQUFBLElBQ3JDO0FBQUEsRUFDSixHQUFHLENBQUMvQixNQUFNQyxXQUFXLENBQUM7QUFLdEIsUUFBTXFLLHlCQUF5QixZQUFZO0FBQ3ZDLFFBQUksQ0FBQ3hKLGdCQUFpQjtBQUV0QixRQUFJO0FBRUEsWUFBTXlKLFFBQVEsTUFBTXJOLGNBQStCbUIsd0JBQXdCbU0sVUFBVSxDQUFDLEVBQUVDLFdBQVcsZUFBZTVHLE9BQU8vQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzNJLFVBQUl5SixPQUFPO0FBRVBHLDJCQUFtQkgsS0FBSztBQUV4QnhKLDJCQUFtQndKLE1BQU16SCxlQUFlQyxPQUFPd0gsTUFBTXpLLEVBQUUsQ0FBQztBQUN4RHJELGNBQU1rTyxRQUFRLHVCQUF1QjtBQUFBLE1BQ3pDLE9BQU87QUFDSGxPLGNBQU1tTyxLQUFLLDBCQUEwQjtBQUVyQ3BLLHNCQUFjLENBQUFxSyxVQUFTLEVBQUUsR0FBR0EsTUFBTWxLLFdBQVcsTUFBTUMsYUFBYSxJQUFJQyxVQUFVLEVBQUUsRUFBRTtBQUNsRlUsNEJBQW9CLEVBQUU7QUFDdEJFLGlDQUF5QixFQUFFO0FBQzNCTSx1Q0FBK0IsQ0FBQyxDQUFDO0FBQ2pDWix1QkFBZSxFQUFFO0FBQ2pCRSwrQkFBdUIsSUFBSTtBQUMzQmMsOEJBQXNCLElBQUk7QUFDMUJFLG1DQUEyQixDQUFDLENBQUM7QUFBQSxNQUNqQztBQUFBLElBQ0osU0FBU3lJLEdBQUc7QUFDUlQsY0FBUWpELE1BQU0wRCxDQUFDO0FBQ2ZyTyxZQUFNMkssTUFBTSwyQkFBMkI7QUFBQSxJQUMzQztBQUFBLEVBQ0o7QUFHQSxRQUFNMkQsdUJBQXVCLE9BQU83RyxRQUFnQjhHLFNBQWdEO0FBQ2hHLFVBQU1DLFlBQVlqSyxNQUFNa0ssVUFBVSxDQUFBNUgsTUFBS0EsRUFBRVksV0FBV0EsTUFBTTtBQUMxRCxRQUFJK0csY0FBYyxHQUFJO0FBQ3RCLFVBQU1oTSxPQUFPK0IsTUFBTWlLLFNBQVM7QUFFNUIsUUFBSUUsU0FBYztBQUNsQixRQUFJQyxjQUFjO0FBQ2xCLFFBQUlDLFlBQVk7QUFFaEIsUUFBSUwsU0FBUyxXQUFXO0FBQ3BCRyxlQUFTN007QUFDVCtNLGtCQUFZcE0sS0FBS3NGO0FBQUFBLElBQ3JCLFdBQVd5RyxTQUFTLFFBQVE7QUFDeEJHLGVBQVNyTTtBQUNUdU0sa0JBQVlwTSxLQUFLd0Y7QUFBQUEsSUFDckIsV0FBV3VHLFNBQVMsa0JBQWtCO0FBQ2xDRyxlQUFTL007QUFDVGdOLG9CQUFjO0FBQ2RDLGtCQUFZcE0sS0FBS3lGO0FBQUFBLElBQ3JCO0FBRUEsUUFBSSxDQUFDMkcsVUFBVztBQUVoQixRQUFJO0FBQ0EsWUFBTWQsUUFBUSxNQUFNck4sY0FBbUJpTyxPQUFPWCxVQUFVLENBQUMsRUFBRUMsV0FBV1csYUFBYXZILE9BQU93SCxVQUFVLENBQUMsQ0FBQztBQUV0RyxVQUFJZCxPQUFPO0FBQ1AsWUFBSVMsU0FBUyxXQUFXO0FBQ3BCTSwyQkFBaUJwSCxRQUFRLGlCQUFpQnFHLEtBQUs7QUFDL0NlLDJCQUFpQnBILFFBQVEsbUJBQW1CcUcsTUFBTS9GLElBQUk7QUFBQSxRQUMxRCxXQUFXd0csU0FBUyxRQUFRO0FBQ3hCTSwyQkFBaUJwSCxRQUFRLFdBQVdxRyxNQUFNekssRUFBRTtBQUM1Q3dMLDJCQUFpQnBILFFBQVEsYUFBYXFHLE1BQU0xSCxJQUFJO0FBQ2hEeUksMkJBQWlCcEgsUUFBUSxnQkFBZ0JxRyxNQUFNL0YsUUFBUXpCLE9BQU93SCxNQUFNekssRUFBRSxDQUFDO0FBQUEsUUFDM0UsV0FBV2tMLFNBQVMsa0JBQWtCO0FBRWxDTSwyQkFBaUJwSCxRQUFRLHFCQUFxQnFHLE1BQU16SyxFQUFFO0FBQ3REd0wsMkJBQWlCcEgsUUFBUSxTQUFTbEIsT0FBT3VILE1BQU0xRyxLQUFLLEtBQUssQ0FBQztBQUMxRHlILDJCQUFpQnBILFFBQVEsV0FBV3FHLE1BQU0vRyxPQUFPO0FBQ2pEOEgsMkJBQWlCcEgsUUFBUSxhQUFhcUcsTUFBTTlHLFNBQVM7QUFDckQ2SCwyQkFBaUJwSCxRQUFRLGdCQUFnQnFHLE1BQU01RyxZQUFZO0FBQzNEMkgsMkJBQWlCcEgsUUFBUSxjQUFjcUcsTUFBTTNHLFVBQVU7QUFFdkQwSCwyQkFBaUJwSCxRQUFRLG1CQUFtQnFHLE1BQU01RyxZQUFZO0FBQUEsUUFDbEU7QUFBQSxNQUNKLE9BQU87QUFDSGxILGNBQU1tTyxLQUFLLEdBQUdJLFNBQVMsWUFBWSxXQUFXQSxTQUFTLFNBQVMsVUFBVSxRQUFRLGlCQUFpQjtBQUFBLE1BRXZHO0FBQUEsSUFDSixTQUFTRixHQUFHO0FBQ1JULGNBQVFqRCxNQUFNMEQsQ0FBQztBQUNmck8sWUFBTTJLLE1BQU0sdUJBQXVCO0FBQUEsSUFDdkM7QUFBQSxFQUNKO0FBR0EsUUFBTW1FLHFCQUFxQmxQO0FBQUFBLElBQ3ZCLE9BQU82RSxlQUFlLElBQUk4RSxPQUFPLENBQUFSLE1BQUtBLEVBQUV3RixTQUFTLENBQUM7QUFBQSxJQUNsRCxDQUFDOUosV0FBVztBQUFBLEVBQ2hCO0FBRUEsUUFBTXNLLGlDQUFpQ25QO0FBQUFBLElBQ25DLE9BQU82RSxlQUFlLElBQUk4RSxPQUFPLENBQUFSLE1BQUtBLEVBQUV3RixTQUFTLEtBQUt4RixFQUFFMUYsT0FBT2hDLGdCQUFnQjtBQUFBLElBQy9FLENBQUNvRCxXQUFXO0FBQUEsRUFDaEI7QUFHQSxRQUFNdUssbUJBQW1CcFAsUUFBUSxNQUFNaUYsaUJBQWlCK0IsSUFBSSxDQUFBOEYsTUFBS0EsRUFBRXJKLEVBQUUsR0FBRyxDQUFDd0IsZ0JBQWdCLENBQUM7QUFFMUYsUUFBTW9LLDRCQUE0QnJQO0FBQUFBLElBQzlCLE1BQU1pQix5Q0FBeUNzRSxjQUFjO0FBQUEsSUFDN0QsQ0FBQ0EsY0FBYztBQUFBLEVBQ25CO0FBRUEsUUFBTStKLDBCQUEwQnRQO0FBQUFBLElBQVEsTUFBTTtBQUMxQyxZQUFNdVAsZUFDRjFNLFFBQVFrQyxxQkFBcUI4QixhQUFhLEtBQUtoRSxRQUFRa0MscUJBQXFCK0IsV0FBVztBQUMzRixZQUFNMEksZ0JBQWdCTCwrQkFBK0IxQyxTQUFTO0FBQzlELGFBQ0k1SixRQUFRcUIsV0FBV0ksU0FBUyxLQUM1QlcsaUJBQWlCd0gsU0FBUyxLQUMxQjRDLDBCQUEwQjVDLFdBQVcsTUFDcEM4QyxnQkFBZ0JDO0FBQUFBLElBRXpCO0FBQUEsSUFBRztBQUFBLE1BQ0N0TCxXQUFXSTtBQUFBQSxNQUNYVyxpQkFBaUJ3SDtBQUFBQSxNQUNqQjRDLDBCQUEwQjVDO0FBQUFBLE1BQzFCMUg7QUFBQUEsTUFDQW9LLCtCQUErQjFDO0FBQUFBLElBQU07QUFBQSxFQUN4QztBQUVELFFBQU1nRCxTQUFTelAsUUFBUSxNQUFNO0FBQ3pCLFVBQU0wUCxjQUFjck8sMEJBQTBCa0UsZ0JBQWdCRSwyQkFBMkI7QUFDekYsVUFBTWtLLHVCQUF1QnJPLHdCQUF3QmlFLGNBQWM7QUFDbkUsVUFBTXFLLDRCQUE0QnRPLHdCQUF3Qm1FLDJCQUEyQjtBQUNyRixVQUFNakIsV0FBV04sV0FBV00sWUFBWTtBQUV4QyxVQUFNcUwseUJBQXVDO0FBQzdDLFFBQUlYLHNCQUFzQkEsbUJBQW1CekMsU0FBUyxHQUFHO0FBQ3JEeUMseUJBQW1CckMsUUFBUSxDQUFBaUQsU0FBUTtBQUMvQixjQUFNQyxjQUFjcE0sU0FBUyxTQUFTQyxhQUFhcUYsZUFBZUMsS0FBSyxDQUFBOEcsU0FBUUEsS0FBSzVHLFdBQVcwRyxLQUFLck0sRUFBRSxJQUFJO0FBQzFHb00sK0JBQXVCSSxLQUFLO0FBQUEsVUFDeEI3RyxRQUFRMEcsS0FBS3JNO0FBQUFBLFVBQ2I0RixVQUFVeUcsS0FBS3RKO0FBQUFBLFVBQ2YwSixNQUFNSixLQUFLSTtBQUFBQSxVQUNYOUYsUUFBUTVGLFlBQVlzTCxLQUFLSSxPQUFPO0FBQUEsVUFDaEN6TSxJQUFJc00sYUFBYXRNO0FBQUFBLFFBQ3JCLENBQUM7QUFBQSxNQUNMLENBQUM7QUFBQSxJQUNMO0FBRUEsVUFBTTBNLGFBQWFOLHVCQUF1QmhDLE9BQU8sQ0FBQ3VDLEtBQUtDLFFBQVFELE9BQU96SixPQUFPMEosSUFBSWpHLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDakcsVUFBTWtHLGlCQUFpQlosY0FBY2xMLFdBQVcyTDtBQUNoRCxVQUFNSSxZQUFZNUwsTUFBTWtKLE9BQU8sQ0FBQ3VDLEtBQUt4TixTQUFTd04sT0FBT3pKLE9BQU8vRCxLQUFLNEUsS0FBSyxLQUFLLElBQUksQ0FBQztBQUNoRixVQUFNZ0osaUJBQWlCQyxLQUFLQyxPQUFPSixpQkFBaUJDLGFBQWEsR0FBRyxJQUFJO0FBRXhFLFdBQU8sRUFBRWIsYUFBYUMsc0JBQXNCQywyQkFBMkJwTCxVQUFVbU0sY0FBY2Qsd0JBQXdCTSxZQUFZRyxnQkFBZ0JDLFdBQVdDLGVBQWU7QUFBQSxFQUNqTCxHQUFHLENBQUNqTCxnQkFBZ0JFLDZCQUE2QnZCLFdBQVdNLFVBQVVHLE9BQU91SyxvQkFBb0J2TCxNQUFNQyxXQUFXLENBQUM7QUFJbkg3RDtBQUFBQSxJQUFVLE1BQU07QUFDWixVQUFJNlEsY0FBYztBQUVsQixZQUFNQyxnQ0FBZ0MsWUFBWTtBQUU5QyxZQUFJSixLQUFLSyxJQUFJbkssT0FBTzhJLE9BQU9hLGNBQWMsS0FBSyxDQUFDLEtBQUssTUFBTTtBQUN0RHhLLGdDQUFzQixJQUFJO0FBQzFCO0FBQUEsUUFDSjtBQUNBLFlBQUksQ0FBQzVCLFdBQVdJLGFBQWEsQ0FBQ1MscUJBQXFCO0FBQy9DZSxnQ0FBc0IsSUFBSTtBQUMxQjtBQUFBLFFBQ0o7QUFDQSxZQUFJLENBQUNmLG9CQUFvQjhCLGlCQUFpQixDQUFDOUIsb0JBQW9CK0IsYUFBYTtBQUN4RWhCLGdDQUFzQixJQUFJO0FBQzFCO0FBQUEsUUFDSjtBQUNBLGNBQU1pTCxpQkFBaUI1UCxzQ0FBc0M7QUFBQSxVQUN6RG1ELFdBQVdKLFdBQVdJO0FBQUFBLFVBQ3RCRixjQUFjRixXQUFXRTtBQUFBQSxVQUN6Qm1CO0FBQUFBLFVBQ0E2SjtBQUFBQSxVQUNBL0UsV0FBV3RGLG9CQUFvQitCO0FBQUFBLFFBQ25DLENBQUM7QUFDRCxZQUFJLENBQUNpSyxnQkFBZ0I7QUFDakJqTCxnQ0FBc0IsSUFBSTtBQUMxQjtBQUFBLFFBQ0o7QUFFQSxZQUFJO0FBQ0EsZ0JBQU1rTCxXQUFXLE1BQU1sUSwwQkFBMEJpUSxjQUFjO0FBQy9ELGNBQUlILFlBQWE7QUFDakIsZ0JBQU1LLHVCQUNGRCxTQUFTaEosY0FBYyxRQUFRLENBQUNyQixPQUFPc0IsTUFBTXRCLE9BQU9xSyxTQUFTaEosVUFBVSxDQUFDLElBQ2xFckIsT0FBT3FLLFNBQVNoSixVQUFVLElBQzFCO0FBQ1ZsQyxnQ0FBc0I7QUFBQSxZQUNsQnNFLFFBQVF6RCxPQUFPcUssU0FBU0Usb0JBQW9CLEtBQUs7QUFBQSxZQUNqRDlILFFBQVE0SCxTQUFTNUg7QUFBQUEsWUFDakI5RSxXQUFXME0sU0FBUzFNO0FBQUFBLFlBQ3BCK0YsV0FBVzJHLFNBQVMzRztBQUFBQSxZQUNwQnJDLFlBQVlpSjtBQUFBQSxVQUNoQixDQUFDO0FBQUEsUUFDTCxTQUFTbEcsT0FBTztBQUNaaUQsa0JBQVFqRCxNQUFNQSxLQUFLO0FBQ25CLGNBQUksQ0FBQzZGLGFBQWE7QUFDZHhRLGtCQUFNMkssTUFBTSxnREFBZ0Q7QUFDNURqRixrQ0FBc0IsSUFBSTtBQUFBLFVBQzlCO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFHQSxZQUFNcUwsWUFBWUMsT0FBT0MsV0FBVyxNQUFNO0FBQ3RDLGFBQUtSLDhCQUE4QjtBQUFBLE1BQ3ZDLEdBQUcsR0FBRztBQUVOLGFBQU8sTUFBTTtBQUNURCxzQkFBYztBQUNkUSxlQUFPRSxhQUFhSCxTQUFTO0FBQUEsTUFDakM7QUFBQSxJQUNKO0FBQUEsSUFBRztBQUFBLE1BQ0NqTixXQUFXSTtBQUFBQSxNQUNYSixXQUFXRTtBQUFBQSxNQUNYbUI7QUFBQUEsTUFDQTZKO0FBQUFBLE1BQ0FySztBQUFBQSxNQUNBMEssT0FBT2E7QUFBQUEsSUFBYztBQUFBLEVBQ3hCO0FBR0R2UTtBQUFBQSxJQUFVLE1BQU07QUFDWixVQUFJNlEsY0FBYztBQUVsQixZQUFNVyxNQUFNLFlBQVk7QUFDcEIsWUFBSWQsS0FBS0ssSUFBSW5LLE9BQU84SSxPQUFPYSxjQUFjLEtBQUssQ0FBQyxLQUFLLE1BQU07QUFDdEQsY0FBSSxDQUFDTSxZQUFhNUssNEJBQTJCLENBQUMsQ0FBQztBQUMvQztBQUFBLFFBQ0o7QUFDQSxZQUFJLENBQUM5QixXQUFXSSxhQUFhNkssK0JBQStCMUMsV0FBVyxHQUFHO0FBQ3RFLGNBQUksQ0FBQ21FLFlBQWE1Syw0QkFBMkIsQ0FBQyxDQUFDO0FBQy9DO0FBQUEsUUFDSjtBQUNBLFlBQUk7QUFDQSxnQkFBTXdMLFVBR0YsQ0FBQztBQUNMLGNBQUlDLFdBQVc7QUFDZixnQkFBTXBGLFFBQVFDO0FBQUFBLFlBQ1Y2QywrQkFBK0JuSSxJQUFJLE9BQU0wSyxPQUFNO0FBQzNDLG9CQUFNWCxpQkFBaUIzUCw2QkFBNkI7QUFBQSxnQkFDaERnSSxRQUFRc0ksR0FBR2pPO0FBQUFBLGdCQUNYYSxXQUFXSixXQUFXSTtBQUFBQSxnQkFDdEJGLGNBQWNGLFdBQVdFO0FBQUFBLGdCQUN6Qm1CO0FBQUFBLGdCQUNBNko7QUFBQUEsZ0JBQ0EvRSxXQUFXO0FBQUEsY0FDZixDQUFDO0FBQ0Qsa0JBQUksQ0FBQzBHLGdCQUFnQjtBQUNqQlMsd0JBQVFFLEdBQUdqTyxFQUFFLElBQUk7QUFBQSxrQkFDYjJHLFFBQVE7QUFBQSxrQkFDUmhCLFFBQVFzSSxHQUFHak87QUFBQUEsa0JBQ1g0RixVQUFVcUksR0FBR2xMO0FBQUFBLGtCQUNid0IsWUFBWTtBQUFBLGdCQUNoQjtBQUNBO0FBQUEsY0FDSjtBQUNBLGtCQUFJO0FBQ0Esc0JBQU1nSixXQUFXLE1BQU1qUSxpQkFBaUJnUSxjQUFjO0FBQ3RELG9CQUFJSCxZQUFhO0FBQ2pCLHNCQUFNSyx1QkFDRkQsU0FBU2hKLGNBQWMsUUFBUSxDQUFDckIsT0FBT3NCLE1BQU10QixPQUFPcUssU0FBU2hKLFVBQVUsQ0FBQyxJQUNsRXJCLE9BQU9xSyxTQUFTaEosVUFBVSxJQUMxQjtBQUNWd0osd0JBQVFFLEdBQUdqTyxFQUFFLElBQUk7QUFBQSxrQkFDYjJHLFFBQVF6RCxPQUFPcUssU0FBU0Usb0JBQW9CLEtBQUs7QUFBQSxrQkFDakQ5SCxRQUFRc0ksR0FBR2pPO0FBQUFBLGtCQUNYNEYsVUFBVXFJLEdBQUdsTDtBQUFBQSxrQkFDYndCLFlBQVlpSjtBQUFBQSxnQkFDaEI7QUFBQSxjQUNKLFNBQVN4QyxHQUFHO0FBQ1JULHdCQUFRakQsTUFBTTBELENBQUM7QUFDZmdELDJCQUFXO0FBQ1hELHdCQUFRRSxHQUFHak8sRUFBRSxJQUFJO0FBQUEsa0JBQ2IyRyxRQUFRO0FBQUEsa0JBQ1JoQixRQUFRc0ksR0FBR2pPO0FBQUFBLGtCQUNYNEYsVUFBVXFJLEdBQUdsTDtBQUFBQSxrQkFDYndCLFlBQVk7QUFBQSxnQkFDaEI7QUFBQSxjQUNKO0FBQUEsWUFDSixDQUFDO0FBQUEsVUFDTDtBQUNBLGNBQUksQ0FBQzRJLGFBQWE7QUFDZDVLLHVDQUEyQndMLE9BQU87QUFDbEMsZ0JBQUlDLFVBQVU7QUFDVnJSLG9CQUFNMkssTUFBTSx3REFBd0Q7QUFBQSxZQUN4RTtBQUFBLFVBQ0o7QUFBQSxRQUNKLFNBQVMwRCxHQUFHO0FBQ1JULGtCQUFRakQsTUFBTTBELENBQUM7QUFDZixjQUFJLENBQUNtQyxhQUFhO0FBQ2Q1Syx1Q0FBMkIsQ0FBQyxDQUFDO0FBQzdCNUYsa0JBQU0ySyxNQUFNLHNEQUFzRDtBQUFBLFVBQ3RFO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFFQSxZQUFNb0csWUFBWUMsT0FBT0MsV0FBVyxNQUFNO0FBQ3RDLGFBQUtFLElBQUk7QUFBQSxNQUNiLEdBQUcsR0FBRztBQUVOLGFBQU8sTUFBTTtBQUNUWCxzQkFBYztBQUNkUSxlQUFPRSxhQUFhSCxTQUFTO0FBQUEsTUFDakM7QUFBQSxJQUNKO0FBQUEsSUFBRztBQUFBLE1BQ0NqTixXQUFXSTtBQUFBQSxNQUNYSixXQUFXRTtBQUFBQSxNQUNYbUI7QUFBQUEsTUFDQTZKO0FBQUFBLE1BQ0FEO0FBQUFBLE1BQ0FNLE9BQU9hO0FBQUFBLElBQWM7QUFBQSxFQUN4QjtBQUdELFFBQU1xQixxQkFBcUJBLENBQUNDLE9BQWdDcEssVUFBZTtBQUN2RXJELGtCQUFjLENBQUFxSyxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDb0QsS0FBSyxHQUFHcEssTUFBTSxFQUFFO0FBQUEsRUFDdkQ7QUFFQSxRQUFNNkcscUJBQXFCLE9BQU85SCxXQUE0QjtBQUMxRHBDLGtCQUFjLENBQUFxSyxVQUFTLEVBQUUsR0FBR0EsTUFBTWxLLFdBQVdpQyxPQUFPOUMsSUFBSWMsYUFBYWdDLE9BQU9DLFFBQVEsSUFBSWhDLFVBQVUsRUFBRSxFQUFFO0FBQ3RHRSx1QkFBbUI2QixPQUFPRSxlQUFlQyxPQUFPSCxPQUFPOUMsRUFBRSxDQUFDO0FBRTFENkIsMEJBQXNCLElBQUk7QUFDMUJKLHdCQUFvQixFQUFFO0FBQ3RCRSw2QkFBeUIsRUFBRTtBQUMzQkksc0JBQWtCLENBQUMsQ0FBQztBQUNwQkUsbUNBQStCLENBQUMsQ0FBQztBQUNqQ1osbUJBQWUsRUFBRTtBQUNqQmMsNEJBQXdCLENBQUM7QUFDekJJLCtCQUEyQixDQUFDLENBQUM7QUFFN0IsUUFBSTtBQUNBLFlBQU02RSxhQUFhLE1BQU1sSyxRQUF3RCxXQUFXNEYsT0FBTzlDLEVBQUU7QUFDckdxQixxQkFBZStGLFdBQVdDLFNBQVMsRUFBRTtBQUNyQ2xGLCtCQUF5QmUsT0FBT2tFLFdBQVdqRSxlQUFlLEtBQUssS0FBSyxFQUFFO0FBQ3RFNUIsNkJBQXVCO0FBQUEsUUFDbkI2QixlQUFlaEUsUUFBUWdJLFdBQVdoRSxhQUFhO0FBQUEsUUFDL0NDLGFBQWErRCxXQUFXL0QsZUFBZTtBQUFBLE1BQzNDLENBQUM7QUFDRCxZQUFNbUUsU0FBUyxJQUFJQyxnQkFBZ0IsRUFBRTVHLFdBQVdpQyxPQUFPOUMsR0FBRzBILFNBQVMsR0FBR0MsYUFBYSxPQUFPLENBQUM7QUFDM0YsWUFBTSxDQUFDeUcsbUJBQW1CQyxhQUFhLElBQUksTUFBTXpGLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUN6RDFMLE9BQWlCLGFBQWFxSyxPQUFPRSxTQUFTLENBQUMsRUFBRTtBQUFBLFVBQ2pEdkssT0FBOEIsNEJBQTRCcUssT0FBT0UsU0FBUyxDQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFDakY7QUFDRGpHLDBCQUFvQjJNLGtCQUFrQjdFLElBQUk7QUFDMUM1SCwrQkFBeUIwTSxjQUFjOUUsSUFBSTtBQUFBLElBQy9DLFNBQVNqQyxPQUFPO0FBQ1ozSyxZQUFNMkssTUFBTSxnREFBZ0Q7QUFDNURpRCxjQUFRakQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCLFVBQUM7QUFDR3pGLDRCQUFzQixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNKO0FBRUEsUUFBTXlNLDRCQUE0QkEsQ0FBQ0MsWUFBb0J4SyxVQUEyQjtBQUM5RSxVQUFNa0UsV0FBV3pHLGlCQUFpQmlFLEtBQUssQ0FBQTRELE1BQUtBLEVBQUVySixPQUFPdU8sVUFBVTtBQUMvRCxRQUFJLENBQUN0RyxTQUFVO0FBQ2YsVUFBTXVHLGVBQWV0TCxPQUFPYSxLQUFLLEtBQUs7QUFDdEMsVUFBTStGLFVBQVU1RyxPQUFPK0UsU0FBUzZCLE9BQU8sS0FBSztBQUM1QyxRQUFJMEUsZUFBZTFFLFNBQVM7QUFDeEJuTixZQUFNbU8sS0FBSyx1Q0FBdUNqTSxZQUFZaUwsU0FBUyxVQUFVLENBQUMsR0FBRztBQUNyRi9GLGNBQVErRjtBQUFBQSxJQUNaO0FBQ0EvSCxzQkFBa0IsQ0FBQWdKLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUN3RCxVQUFVLEdBQUd4SyxNQUFNLEVBQUU7QUFBQSxFQUNoRTtBQUVBLFFBQU0wSyxrQ0FBa0NBLENBQUNqRyxRQUFnQnpFLFVBQTJCO0FBQ2hGLFVBQU0ySyxPQUFPaE4sc0JBQXNCK0QsS0FBSyxDQUFBOUYsTUFBS0EsRUFBRUssT0FBT3dJLE1BQU07QUFDNUQsUUFBSSxDQUFDa0csS0FBTTtBQUNYLFFBQUlGLGVBQWV0TCxPQUFPYSxLQUFLLEtBQUs7QUFDcEMsVUFBTStGLFVBQVUxTCxrQkFBa0JzUSxJQUFJO0FBQ3RDLFFBQUk1RSxXQUFXLEdBQUc7QUFDZCxVQUFJMEUsZUFBZSxFQUFHQSxnQkFBZTtBQUNyQyxVQUFJQSxlQUFlMUUsU0FBUztBQUN4Qm5OLGNBQU1tTyxLQUFLLHVDQUF1Q2pNLFlBQVlpTCxTQUFTLFVBQVUsQ0FBQyxHQUFHO0FBQ3JGMEUsdUJBQWUxRTtBQUFBQSxNQUNuQjtBQUFBLElBQ0osT0FBTztBQUNILFVBQUkwRSxlQUFlLEVBQUdBLGdCQUFlO0FBQ3JDLFVBQUlBLGVBQWUxRSxTQUFTO0FBQ3hCbk4sY0FBTW1PLEtBQUssdUNBQXVDak0sWUFBWWlMLFNBQVMsVUFBVSxDQUFDLEdBQUc7QUFDckYwRSx1QkFBZTFFO0FBQUFBLE1BQ25CO0FBQUEsSUFDSjtBQUNBN0gsbUNBQStCLENBQUE4SSxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDdkMsTUFBTSxHQUFHZ0csYUFBYSxFQUFFO0FBQUEsRUFDaEY7QUFFQSxRQUFNRyxnQkFBZ0JBLE1BQU07QUFDeEJ4TixhQUFTLENBQUE0SixTQUFRLENBQUMsR0FBR0EsTUFBTTtBQUFBLE1BQ3ZCM0csUUFBUUMsT0FBT0MsV0FBVztBQUFBLE1BQzFCL0UscUJBQXFCO0FBQUEsTUFDckJ3RSxPQUFPO0FBQUEsTUFDUEwsU0FBUztBQUFBLE1BQU1DLFdBQVc7QUFBQSxNQUFNQyxXQUFXO0FBQUEsTUFBTUMsY0FBYztBQUFBLE1BQU1DLFlBQVk7QUFBQSxNQUFNRSxXQUFXO0FBQUEsTUFBTUMsZUFBZTtBQUFBLE1BQ3ZIQyxtQkFBbUI7QUFBQTtBQUFBLE1BRW5CTyxpQkFBaUI7QUFBQSxNQUNqQkUsY0FBYztBQUFBLE1BQ2RDLGlCQUFpQjtBQUFBLElBQ3JCLENBQUMsQ0FBQztBQUFBLEVBQ047QUFFQSxRQUFNZ0ssbUJBQW1CQSxDQUFDeEssV0FBbUI7QUFDekMsVUFBTXlLLFNBQVMzTixNQUFNdUUsS0FBSyxDQUFBakMsTUFBS0EsRUFBRVksV0FBV0EsTUFBTTtBQUNsRCxRQUFJeUssVUFBVXBQLDRCQUE0Qm9QLE1BQU0sR0FBRztBQUMvQztBQUFBLElBQ0o7QUFDQTFOLGFBQVMsQ0FBQTRKLFNBQVFBLEtBQUs3RSxPQUFPLENBQUExQyxNQUFLQSxFQUFFWSxXQUFXQSxNQUFNLENBQUM7QUFBQSxFQUMxRDtBQUdBLFFBQU0wSyxrQ0FBa0NBLENBQUMxSyxXQUFtQjtBQUN4RCxVQUFNMkssZ0JBQWdCL0MsT0FBT0M7QUFDN0IsVUFBTStDLFdBQVc5TixNQUFNa0o7QUFBQUEsTUFDbkIsQ0FBQzZFLEdBQUc5SSxPQUFRQSxHQUFHL0IsV0FBV0EsU0FBUzZLLElBQUlBLEtBQUsvTCxPQUFPaUQsR0FBR3BDLEtBQUssS0FBSztBQUFBLE1BQ2hFO0FBQUEsSUFDSjtBQUNBLFFBQUltTCxRQUFRbEMsS0FBS0MsT0FBTzhCLGdCQUFnQkMsWUFBWSxHQUFHLElBQUk7QUFDM0QsUUFBSUUsUUFBUSxHQUFHO0FBQ1h2UyxZQUFNbU87QUFBQUEsUUFDRjtBQUFBLE1BQ0o7QUFDQW9FLGNBQVE7QUFBQSxJQUNaO0FBQ0ExRCxxQkFBaUJwSCxRQUFRLFNBQVM4SyxLQUFLO0FBQUEsRUFDM0M7QUFHQTVTLFlBQVUsTUFBTTtBQUNaNkUsYUFBUyxDQUFBZ08sY0FBYTtBQUNsQixZQUFNQyxtQkFBbUJELFVBQVVFLEtBQUtuUSx3QkFBd0I7QUFHaEUsVUFBSSxDQUFDa0Qsc0JBQXNCQSxtQkFBbUJ1RSxVQUFVLEdBQUc7QUFDdkQsWUFBSSxDQUFDeUksaUJBQWtCLFFBQU9EO0FBQzlCLGVBQU9BLFVBQVVqSixPQUFPLENBQUExQyxNQUFLLENBQUN0RSx5QkFBeUJzRSxDQUFDLENBQUM7QUFBQSxNQUM3RDtBQUVBLFlBQU1tRCxTQUFTekQsT0FBT2QsbUJBQW1CdUUsTUFBTSxLQUFLO0FBQ3BELFlBQU0ySSxZQUNGbE4sbUJBQW1CbUMsY0FBYyxRQUFRLENBQUNyQixPQUFPc0IsTUFBTXRCLE9BQU9kLG1CQUFtQm1DLFVBQVUsQ0FBQyxJQUN0RnJCLE9BQU9kLG1CQUFtQm1DLFVBQVUsSUFDcENzQjtBQUdWLFVBQUl1SixrQkFBa0I7QUFDbEIsZUFBT0QsVUFBVTVMLElBQUksQ0FBQUMsTUFBSztBQUN0QixjQUFJdEUseUJBQXlCc0UsQ0FBQyxHQUFHO0FBQzdCLGtCQUFNK0wsT0FBNkI7QUFBQSxjQUMvQixHQUFHL0w7QUFBQUEsY0FDSG5FLHFCQUFxQjtBQUFBLGNBQ3JCQyxhQUFhO0FBQUEsY0FDYkMscUJBQXFCeEI7QUFBQUEsY0FDckJnRyxPQUFPUCxFQUFFNEIsNkJBQTZCNUIsRUFBRU8sUUFBUTRDO0FBQUFBLFlBQ3BEO0FBQ0EsZ0JBQUkySSxjQUFjekosUUFBVztBQUN6QjBKLG1CQUFLaEwsYUFBYStLO0FBQUFBLFlBQ3RCLE9BQU87QUFDSCxxQkFBT0MsS0FBS2hMO0FBQUFBLFlBQ2hCO0FBQ0EsbUJBQU9nTDtBQUFBQSxVQUNYO0FBQ0EsaUJBQU8vTDtBQUFBQSxRQUNYLENBQUM7QUFBQSxNQUNMO0FBR0EsWUFBTUMsVUFBZ0M7QUFBQSxRQUNsQ1csUUFBUUMsT0FBT0MsV0FBVztBQUFBLFFBQzFCL0UscUJBQXFCeEI7QUFBQUEsUUFDckJnRyxPQUFPNEM7QUFBQUEsUUFDUGpELFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsV0FBVztBQUFBLFFBQ1hDLGNBQWM7QUFBQSxRQUNkQyxZQUFZO0FBQUEsUUFDWkUsV0FBVztBQUFBLFFBQ1hDLGVBQWU7QUFBQSxRQUNmQyxtQkFBbUI7QUFBQSxRQUNuQk8saUJBQWlCO0FBQUEsUUFDakJFLGNBQWM7QUFBQSxRQUNkQyxpQkFBaUI7QUFBQSxRQUNqQnZGLHFCQUFxQjtBQUFBLFFBQ3JCQyxhQUFhO0FBQUEsUUFDYixHQUFJZ1EsY0FBY3pKLFNBQVksRUFBRXRCLFlBQVkrSyxVQUFVLElBQUksQ0FBQztBQUFBLE1BQy9EO0FBRUEsYUFBTyxDQUFDLEdBQUdILFdBQVcxTCxPQUFPO0FBQUEsSUFDakMsQ0FBQztBQUFBLEVBQ0wsR0FBRyxDQUFDckIsa0JBQWtCLENBQUM7QUFHdkI5RixZQUFVLE1BQU07QUFDWjZFLGFBQVMsQ0FBQWdPLGNBQWE7QUFDbEIsWUFBTUssb0JBQW9CTCxVQUFVakosT0FBTyxDQUFBMUMsTUFBSyxDQUFDaEUsc0JBQXNCZ0UsQ0FBQyxDQUFDO0FBQ3pFLFlBQU1pTSxhQUFxQztBQUUzQyxpQkFBV3hCLE1BQU12QyxnQ0FBZ0M7QUFDN0MsY0FBTWdFLFVBQVVwTix3QkFBd0IyTCxHQUFHak8sRUFBRTtBQUM3QyxjQUFNMkcsU0FBUytJLFNBQVMvSSxVQUFVO0FBQ2xDLFlBQUlBLFVBQVUsRUFBRztBQUVqQixjQUFNZ0osV0FBV1IsVUFBVTFKO0FBQUFBLFVBQ3ZCLENBQUFqQyxNQUNJaEUsc0JBQXNCZ0UsQ0FBQyxNQUN0QkEsRUFBRThCLHFCQUFxQjJJLEdBQUdqTyxNQUN2QjlCLGtDQUFrQ3NGLEVBQUVqRSxtQkFBbUIsTUFBTTBPLEdBQUdqTztBQUFBQSxRQUM1RTtBQUVBLGNBQU0wRSxPQUFPekcsZ0NBQWdDZ1EsR0FBR2pPLEVBQUU7QUFDbEQsY0FBTXNQLFlBQ0ZJLFNBQVNuTCxjQUFjLFFBQVEsQ0FBQ3JCLE9BQU9zQixNQUFNdEIsT0FBT3dNLFFBQVFuTCxVQUFVLENBQUMsSUFDakVyQixPQUFPd00sUUFBUW5MLFVBQVUsSUFDekJzQjtBQUVWNEosbUJBQVdqRCxLQUFLO0FBQUEsVUFDWnBJLFFBQVF1TCxVQUFVdkwsVUFBVUMsT0FBT0MsV0FBVztBQUFBLFVBQzlDdEUsSUFBSTJQLFVBQVUzUDtBQUFBQSxVQUNkVCxxQkFBcUJtRjtBQUFBQSxVQUNyQlgsT0FBTzRMLFVBQVV2Syw2QkFBNkJ1SyxTQUFTNUwsUUFBUTRDO0FBQUFBLFVBQy9EakQsU0FBUztBQUFBLFVBQ1RDLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWEMsY0FBYztBQUFBLFVBQ2RDLFlBQVk7QUFBQSxVQUNaRSxXQUFXO0FBQUEsVUFDWEMsZUFBZTtBQUFBLFVBQ2ZDLG1CQUFtQjtBQUFBLFVBQ25CTyxpQkFBaUJrTCxVQUFVbEwsbUJBQW1CO0FBQUEsVUFDOUNFLGNBQWNnTCxVQUFVaEwsZ0JBQWdCO0FBQUEsVUFDeENDLGlCQUFpQitLLFVBQVUvSyxtQkFBbUI7QUFBQSxVQUM5Q3ZGLHFCQUFxQjtBQUFBLFVBQ3JCQyxhQUFhO0FBQUEsVUFDYmdHLGtCQUFrQjJJLEdBQUdqTztBQUFBQSxVQUNyQkosb0JBQW9CcU8sR0FBR2xMO0FBQUFBLFVBQ3ZCcUMsNEJBQTRCdUssVUFBVXZLO0FBQUFBLFVBQ3RDLEdBQUlrSyxjQUFjekosU0FBWSxFQUFFdEIsWUFBWStLLFVBQVUsSUFBSSxDQUFDO0FBQUEsUUFDL0QsQ0FBQztBQUFBLE1BQ0w7QUFFQSxhQUFPLENBQUMsR0FBR0UsbUJBQW1CLEdBQUdDLFVBQVU7QUFBQSxJQUMvQyxDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUNuTix5QkFBeUJvSiw4QkFBOEIsQ0FBQztBQUU1RCxRQUFNRixtQkFBbUJBLENBQUNwSCxRQUFnQitKLE9BQW1DcEssVUFBZTtBQUV4RixRQUFJb0ssVUFBVSx5QkFBeUJBLFVBQVUsaUJBQWlCO0FBQzlELFlBQU1VLFNBQVMzTixNQUFNdUUsS0FBSyxDQUFBakMsTUFBS0EsRUFBRVksV0FBV0EsTUFBTTtBQUNsRCxVQUFJeUssVUFBVXBQLDRCQUE0Qm9QLE1BQU0sR0FBRztBQUMvQztBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQ0ExTixhQUFTLENBQUE0SixTQUFRO0FBQ2IsWUFBTTZFLGNBQWM3RSxLQUNmN0UsT0FBTyxDQUFBMUMsTUFBS0EsRUFBRWpFLHdCQUF3QixTQUFTaUUsRUFBRVksV0FBV0EsTUFBTSxFQUNsRWdHLE9BQU8sQ0FBQzZFLEdBQUd6TCxNQUFNeUwsS0FBSy9MLE9BQU9NLEVBQUVPLEtBQUssS0FBSyxJQUFJLENBQUM7QUFDbkQsWUFBTThMLG9CQUFvQjdDLEtBQUs4QyxJQUFJLElBQUk1Tix3QkFBd0IsS0FBSzBOLFdBQVc7QUFFL0UsYUFBTzdFLEtBQUt4SCxJQUFJLENBQUFwRSxTQUFRO0FBQ3BCLFlBQUlBLEtBQUtpRixXQUFXQSxPQUFRLFFBQU9qRjtBQUNuQyxjQUFNNFEsY0FBb0MsRUFBRSxHQUFHNVEsTUFBTSxDQUFDZ1AsS0FBSyxHQUFHcEssTUFBTTtBQUVwRSxZQUFJb0ssVUFBVSx1QkFBdUI7QUFDakM0QixzQkFBWXJNLFVBQVU7QUFBTXFNLHNCQUFZcE0sWUFBWTtBQUNwRG9NLHNCQUFZbE0sZUFBZTtBQUFNa00sc0JBQVlqTSxhQUFhO0FBQzFEaU0sc0JBQVk3TCxvQkFBb0I7QUFDaEM2TCxzQkFBWXBMLGVBQWU7QUFDM0JvTCxzQkFBWW5MLGtCQUFrQjtBQUM5Qm1MLHNCQUFZbEwscUJBQXFCO0FBQ2pDa0wsc0JBQVloTCxtQkFBbUI7QUFDL0JnTCxzQkFBWTlLLHdCQUF3QjtBQUNwQyxjQUFJbEIsVUFBVSxPQUFPO0FBQ2pCZ00sd0JBQVk3TCxvQkFBb0I7QUFBQSxVQUNwQztBQUNBLGNBQUlILFVBQVUsT0FBTztBQUNqQmdNLHdCQUFZck0sVUFBVTtBQUN0QnFNLHdCQUFZcE0sWUFBWTtBQUN4Qm9NLHdCQUFZbE0sZUFBZTtBQUMzQmtNLHdCQUFZak0sYUFBYTtBQUN6QmlNLHdCQUFZaE0sUUFBUTtBQUFBLFVBQ3hCO0FBQ0EsY0FBSUEsVUFBVSxTQUFTQSxVQUFVLE9BQU87QUFDcENnTSx3QkFBWXJNLFVBQVU7QUFDdEJxTSx3QkFBWXBNLFlBQVk7QUFDeEJvTSx3QkFBWWxNLGVBQWU7QUFDM0JrTSx3QkFBWWpNLGFBQWE7QUFDekJpTSx3QkFBWTdMLG9CQUFvQjtBQUFBLFVBQ3BDO0FBQ0EsY0FBSUgsVUFBVSxPQUFPO0FBQ2pCLGtCQUFNa0ksY0FBY3JPLDBCQUEwQmtFLGdCQUFnQkUsMkJBQTJCO0FBQ3pGLGtCQUFNakIsV0FBV04sV0FBV00sWUFBWTtBQUN4QyxrQkFBTTJMLGNBQWNqQixzQkFBc0IsSUFBSXJCO0FBQUFBLGNBQzFDLENBQUN1QyxLQUFLTixTQUFTTSxNQUFNNUwsYUFBYXNMLEtBQUtJLFFBQVEsS0FBSztBQUFBLGNBQ3BEO0FBQUEsWUFDSjtBQUNBLGtCQUFNSSxpQkFBaUJaLGNBQWNsTCxXQUFXMkw7QUFDaERxRCx3QkFBWWhNLFFBQVFpSixLQUFLOEMsSUFBSSxHQUFHOUMsS0FBS2dELElBQUluRCxnQkFBZ0JnRCxpQkFBaUIsQ0FBQztBQUFBLFVBQy9FO0FBQUEsUUFDSjtBQUNBLFlBQUkxQixVQUFVLFdBQVdoUCxLQUFLSSx3QkFBd0IsT0FBTztBQUN6RCxnQkFBTTBRLFNBQVMvTSxPQUFPYSxLQUFLLEtBQUs7QUFDaEMsY0FBSWtNLFNBQVNKLG1CQUFtQjtBQUM1QmxULGtCQUFNbU8sS0FBSyw2REFBNkRqTSxZQUFZZ1IsbUJBQW1CLFVBQVUsQ0FBQyxJQUFJO0FBQ3RIRSx3QkFBWWhNLFFBQVE4TDtBQUFBQSxVQUN4QjtBQUFBLFFBQ0o7QUFDQSxZQUFJMUIsVUFBVSxXQUFXMU8sNEJBQTRCTixJQUFJLEdBQUc7QUFDeEQ0USxzQkFBWTNLLDZCQUE2QjtBQUFBLFFBQzdDO0FBQ0EsZUFBTzJLO0FBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNRyxZQUFZQSxDQUFDckIsV0FBMEI7QUFDekNsTSxxQkFBaUJrTSxNQUFNO0FBQ3ZCLFFBQUl4RCxTQUFTO0FBQ2IsUUFBSXdELFdBQVcsVUFBVTtBQUNyQnhELGVBQVM5TTtBQUFBQSxJQUNiLFdBQVcsT0FBT3NRLFdBQVcsWUFBWUEsT0FBTzNELFNBQVMsWUFBWTtBQUNqRUcsZUFBU3JNO0FBQUFBLElBQ2IsV0FBVyxPQUFPNlAsV0FBVyxZQUFZQSxPQUFPM0QsU0FBUyxlQUFlO0FBQ3BFRyxlQUFTN007QUFBQUEsSUFDYixXQUFXLE9BQU9xUSxXQUFXLFlBQVlBLE9BQU8zRCxTQUFTLHFCQUFxQjtBQUMxRUcsZUFBUy9NO0FBQUFBLElBQ2I7QUFDQXVFLG1CQUFld0ksTUFBTTtBQUNyQjVJLG1CQUFlLElBQUk7QUFBQSxFQUN2QjtBQUVBLFFBQU0wTixvQkFBb0JBLENBQUNDLGlCQUFzQjtBQUM3QyxRQUFJLENBQUMxTixjQUFlLFFBQU9ELGVBQWUsS0FBSztBQUMvQyxVQUFNNE4sUUFBUSxPQUFPM04sa0JBQWtCLFdBQVdBLGNBQWMyTixRQUFRO0FBQ3hFLFVBQU1qTSxTQUFTaU0sVUFBVSxLQUFLblAsTUFBTW1QLEtBQUssRUFBRWpNLFNBQVM7QUFFcEQsUUFBSTFCLGtCQUFrQixVQUFVO0FBQzVCa0kseUJBQW1Cd0YsWUFBK0I7QUFBQSxJQUN0RCxXQUNTLE9BQU8xTixrQkFBa0IsWUFBWUEsY0FBY3dJLFNBQVMsWUFBWTtBQUM3RU0sdUJBQWlCcEgsUUFBUSxXQUFXZ00sYUFBYXBRLEVBQUU7QUFDbkR3TCx1QkFBaUJwSCxRQUFRLGFBQWFnTSxhQUFhck4sSUFBSTtBQUV2RHlJLHVCQUFpQnBILFFBQVEsZ0JBQWdCZ00sYUFBYTFMLFFBQVF6QixPQUFPbU4sYUFBYXBRLEVBQUUsQ0FBQztBQUFBLElBQ3pGLFdBQ1MsT0FBTzBDLGtCQUFrQixZQUFZQSxjQUFjd0ksU0FBUyxlQUFlO0FBQ2hGTSx1QkFBaUJwSCxRQUFRLGlCQUFpQmdNLFlBQTZCO0FBRXZFNUUsdUJBQWlCcEgsUUFBUSxtQkFBbUJnTSxhQUFhMUwsSUFBSTtBQUFBLElBQ2pFLFdBQ1MsT0FBT2hDLGtCQUFrQixZQUFZQSxjQUFjd0ksU0FBUyxxQkFBcUI7QUFDdEYsWUFBTW9GLFFBQVFGO0FBQ2Q1RSx1QkFBaUJwSCxRQUFRLHFCQUFxQmtNLE1BQU10USxFQUFFO0FBQ3REd0wsdUJBQWlCcEgsUUFBUSxTQUFTbEIsT0FBT29OLE1BQU12TSxLQUFLLEtBQUssQ0FBQztBQUMxRHlILHVCQUFpQnBILFFBQVEsV0FBV2tNLE1BQU01TSxXQUFXLElBQUk7QUFDekQ4SCx1QkFBaUJwSCxRQUFRLGFBQWFrTSxNQUFNM00sYUFBYSxFQUFFO0FBQzNENkgsdUJBQWlCcEgsUUFBUSxnQkFBZ0JrTSxNQUFNek0sZ0JBQWdCLEVBQUU7QUFDakUySCx1QkFBaUJwSCxRQUFRLGNBQWNrTSxNQUFNeE0sY0FBYyxFQUFFO0FBQzdEMEgsdUJBQWlCcEgsUUFBUSxtQkFBbUJrTSxNQUFNek0sZ0JBQWdCLEVBQUU7QUFDcEUySCx1QkFBaUJwSCxRQUFRLHNCQUFzQmtNLE1BQU14TCxnQkFBZ0IsRUFBRTtBQUN2RTBHLHVCQUFpQnBILFFBQVEsb0JBQW9Ca00sTUFBTXRMLGVBQWUsRUFBRTtBQUNwRXdHLHVCQUFpQnBILFFBQVEseUJBQXlCa00sTUFBTXBMLG9CQUFvQixFQUFFO0FBQUEsSUFDbEY7QUFDQXpDLG1CQUFlLEtBQUs7QUFDcEJFLHFCQUFpQixJQUFJO0FBQUEsRUFDekI7QUFHQSxRQUFNNE4sMEJBQTBCL1Q7QUFBQUEsSUFBWSxZQUFZO0FBRXBELFlBQU1nVSxhQUFhdFAsTUFBTXFDLElBQUksQ0FBQ2tOLFFBQVE7QUFDbEMsY0FBTTtBQUFBLFVBQ0ZyTTtBQUFBQSxVQUNBSDtBQUFBQSxVQUNBckUsb0JBQW9COFE7QUFBQUEsVUFDcEJyUixxQkFBcUJzUjtBQUFBQSxVQUNyQnJSLGFBQWFzUjtBQUFBQSxVQUNidEwsa0JBQWtCdUw7QUFBQUEsVUFDbEJ6TCw0QkFBNEIwTDtBQUFBQSxVQUM1QixHQUFHQztBQUFBQSxRQUNQLElBQUlOO0FBQ0osY0FBTU8sWUFBaUI7QUFBQSxVQUNuQixHQUFHRDtBQUFBQSxVQUNIaE4sT0FBT2IsT0FBTzZOLEtBQUtoTixLQUFLLEtBQUs7QUFBQSxVQUM3QmtOLGtCQUFrQmhOLGVBQWVqRSxNQUFNO0FBQUEsUUFDM0M7QUFDQSxZQUFJK1EsS0FBSzdNLGtCQUFtQjhNLFdBQVU5TSxvQkFBb0I2TSxLQUFLN007QUFDL0QsWUFBSTZNLEtBQUsvUSxHQUFJZ1IsV0FBVWhSLEtBQUsrUSxLQUFLL1E7QUFFakMsZUFBUWdSLFVBQWtCdk07QUFDMUIsZUFBUXVNLFVBQWtCck07QUFDMUIsZUFBUXFNLFVBQWtCcE07QUFDMUIsZUFBUW9NLFVBQWtCbk07QUFDMUIsZUFBUW1NLFVBQWtCak07QUFDMUIsZUFBUWlNLFVBQWtCL0w7QUFDMUIsZUFBUStMLFVBQWtCN007QUFFMUIsY0FBTStNLHdCQUF3Qkg7QUFDOUIsWUFBSTdSLHlCQUF5QmdTLHFCQUFxQixLQUFLMVIsc0JBQXNCMFIscUJBQXFCLEdBQUc7QUFDakcsY0FBSUgsS0FBS3hNLGNBQWMsUUFBUSxDQUFDckIsT0FBT3NCLE1BQU10QixPQUFPNk4sS0FBS3hNLFVBQVUsQ0FBQyxHQUFHO0FBQ25FeU0sc0JBQVV6TSxhQUFhckIsT0FBTzZOLEtBQUt4TSxVQUFVO0FBQUEsVUFDakQsT0FBTztBQUNILG1CQUFPeU0sVUFBVXpNO0FBQUFBLFVBQ3JCO0FBQUEsUUFDSixPQUFPO0FBQ0gsaUJBQU95TSxVQUFVek07QUFBQUEsUUFDckI7QUFFQSxlQUFPeU07QUFBQUEsTUFDWCxDQUFDO0FBRUQsWUFBTUcsZ0JBQWdCalEsTUFBTXVFLEtBQUt2Ryx3QkFBd0I7QUFDekQsWUFBTWtTLGtCQUFrQkQsZ0JBQWdCak8sT0FBT2lPLGNBQWNwTixLQUFLLEtBQUssSUFBSTtBQUUzRSxZQUFNc04sNEJBQTBDM0YsK0JBQzNDbkksSUFBSSxDQUFBMEssT0FBTTtBQUNQLGNBQU1xRCxnQkFBZ0JwUSxNQUFNdUU7QUFBQUEsVUFDeEIsQ0FBQWpDLE1BQ0loRSxzQkFBc0JnRSxDQUFDLE1BQ3RCQSxFQUFFOEIscUJBQXFCMkksR0FBR2pPLE1BQ3ZCOUIsa0NBQWtDc0YsRUFBRWpFLG1CQUFtQixNQUFNME8sR0FBR2pPO0FBQUFBLFFBQzVFO0FBQ0EsY0FBTTJHLFNBQVMySyxnQkFDVHBPLE9BQU9vTyxjQUFjdk4sS0FBSyxLQUFLLElBQzlCekIsd0JBQXdCMkwsR0FBR2pPLEVBQUUsR0FBRzJHLFVBQVU7QUFDakQsWUFBSUEsVUFBVSxFQUFHLFFBQU87QUFDeEIsY0FBTTBDLElBQUkvRyx3QkFBd0IyTCxHQUFHak8sRUFBRTtBQUN2QyxlQUFPO0FBQUEsVUFDSDJGLFFBQVFzSSxHQUFHak87QUFBQUEsVUFDWDRGLFVBQVV5RCxHQUFHekQsWUFBWXFJLEdBQUdsTDtBQUFBQSxVQUM1QjBKLE1BQU07QUFBQSxVQUNOOUY7QUFBQUEsUUFDSjtBQUFBLE1BQ0osQ0FBQyxFQUNBVCxPQUFPLENBQUNSLE1BQXVCQSxLQUFLLElBQUk7QUFFN0MsWUFBTTZMLGNBQWM7QUFBQSxRQUNoQixHQUFHdkYsT0FBT2tCLGFBQWFoSCxPQUFPLENBQUEwRyxRQUFPQSxJQUFJakcsU0FBUyxDQUFDO0FBQUEsUUFDbkQsR0FBSXZFLHNCQUFzQmdQLGtCQUFrQixJQUN0QyxDQUFDO0FBQUEsVUFDQ3pMLFFBQVF2RCxtQkFBbUJ1RDtBQUFBQSxVQUMzQkMsVUFBVTtBQUFBLFVBQ1Y2RyxNQUFNO0FBQUEsVUFDTjlGLFFBQVF5SztBQUFBQSxRQUNaLENBQWUsSUFDYjtBQUFBLFFBQ04sR0FBR0M7QUFBQUEsTUFBeUI7QUFFaEMsWUFBTXRKLG9CQUF1Q3hLLDZCQUE2QnVFLGNBQWM7QUFDeEYsWUFBTXNHLDBCQUEwQjNLLGtDQUFrQ3VFLDJCQUEyQjtBQUU3RixZQUFNd1AsVUFBVTtBQUFBLFFBQ1o3USxjQUFjRixXQUFXRTtBQUFBQSxRQUN6QkUsV0FBV0osV0FBV0k7QUFBQUEsUUFDdEJFLFVBQVVOLFdBQVdNO0FBQUFBLFFBQ3JCMFEsY0FBY3pGLE9BQU9DO0FBQUFBLFFBQ3JCL0ssT0FBT3NQO0FBQUFBLFFBQ1BuSixPQUFPa0s7QUFBQUEsUUFDUHhKO0FBQUFBLFFBQ0FLO0FBQUFBLFFBQ0FzSixjQUFjMUYsT0FBT2M7QUFBQUEsTUFDekI7QUFFQSxZQUFNNkUsU0FBUyxNQUFNclIsU0FBU2tSLE9BQTJDO0FBQ3pFLFVBQUlHLFFBQVE7QUFDUmhWLGNBQU1rTyxRQUFRM0ssU0FBUyxXQUFXLG9DQUFvQyxzQ0FBc0M7QUFDNUdELGlCQUFTaEIsa0JBQWtCbkIsd0JBQXdCOFQsU0FBUyxDQUFDO0FBQUEsTUFDakU7QUFBQSxJQUNKO0FBQUEsSUFBRztBQUFBLE1BQ0MxUTtBQUFBQSxNQUNBOEssT0FBT2tCO0FBQUFBLE1BQ1BsQixPQUFPQztBQUFBQSxNQUNQRCxPQUFPYztBQUFBQSxNQUNQMUs7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQW9KO0FBQUFBLE1BQ0E1SjtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBdkIsV0FBV0U7QUFBQUEsTUFDWEYsV0FBV0k7QUFBQUEsTUFDWEosV0FBV007QUFBQUEsTUFDWFQ7QUFBQUEsTUFDQUo7QUFBQUEsTUFDQUQ7QUFBQUEsSUFBUTtBQUFBLEVBQ1g7QUFFRCxRQUFNNFIsYUFBYSxZQUFZO0FBQzNCLFFBQUksQ0FBQ3BSLFdBQVdJLFdBQVc7QUFBRWxFLFlBQU0ySyxNQUFNLDBCQUEwQjtBQUFHO0FBQUEsSUFBUTtBQUU5RSxVQUFNd0ssc0JBQXNCdlUsNkJBQTZCdUUsY0FBYyxFQUFFa0gsU0FBUztBQUNsRixVQUFNK0ksMkJBQTJCdFUsa0NBQWtDdUUsMkJBQTJCLEVBQUVnSCxTQUFTO0FBQ3pHLFVBQU1nSixZQUFZaEYsS0FBS0ssSUFBSW5LLE9BQU84SSxPQUFPYSxjQUFjLEtBQUssQ0FBQyxLQUFLO0FBQ2xFLFVBQU1vRixjQUFjakYsS0FBS0ssSUFBSW5LLE9BQU84SSxPQUFPQyxXQUFXLEtBQUssQ0FBQyxLQUFLO0FBQ2pFLFVBQU1pRyxvQkFDRkosd0JBQXdCRSxhQUFjQyxlQUFlRjtBQUV6RCxVQUFNSSx3QkFBd0JqUixNQUFNZ0Y7QUFBQUEsTUFDaEMsQ0FBQzFDLE1BQU13SixLQUFLSyxJQUFJbkssT0FBT00sRUFBRU8sS0FBSyxLQUFLLENBQUMsSUFBSTtBQUFBLElBQzVDO0FBRUEsUUFBSSxDQUFDbU8sbUJBQW1CO0FBQ3BCLFVBQUlDLHNCQUFzQm5KLFdBQVcsR0FBRztBQUNwQ3JNLGNBQU0ySyxNQUFNLHdDQUF3QztBQUNwRDtBQUFBLE1BQ0o7QUFDQSxVQUFJMEUsT0FBT2MsYUFBYSxHQUFHO0FBQ3ZCblEsY0FBTTJLLE1BQU0scURBQXFEO0FBQ2pFO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxlQUFXbkksUUFBUStCLE9BQU87QUFDdEIsV0FBSy9CLEtBQUtJLHdCQUF3QixTQUFTSixLQUFLSSx3QkFBd0IsVUFBVSxDQUFDSixLQUFLdUUsU0FBUztBQUM3Ri9HLGNBQU0ySyxNQUFNLGtFQUFrRTtBQUM5RTtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBRUEsVUFBTThLLGFBQWFwRyxPQUFPQyxjQUFjRCxPQUFPakwsV0FBV2lMLE9BQU9VLGFBQWFWLE9BQU9jO0FBQ3JGLFFBQUlzRixhQUFhLE1BQU07QUFDbkJ6VixZQUFNMkssTUFBTSx5Q0FBeUN6SSxZQUFZdVQsWUFBWSxVQUFVLENBQUMsRUFBRTtBQUMxRjtBQUFBLElBQ0o7QUFDQSxRQUFJQSxhQUFhLE9BQU87QUFDcEIsWUFBTUMsZ0JBQWdCckYsS0FBS0ssSUFBSStFLFVBQVU7QUFDekM1Uiw0QkFBc0I7QUFBQSxRQUNsQjhSLE9BQU87QUFBQSxRQUNQQyxTQUNJLDRHQUE0RzFULFlBQVl3VCxlQUFlLFVBQVUsQ0FBQztBQUFBLFFBQ3RKRyxXQUFXQSxNQUFNO0FBQ2IsZUFBS2pDLHdCQUF3QjtBQUFBLFFBQ2pDO0FBQUEsTUFDSixDQUFDO0FBQ0Q7QUFBQSxJQUNKO0FBRUEsVUFBTUEsd0JBQXdCO0FBQUEsRUFDbEM7QUFHQSxNQUFJbFEsa0JBQWtCSCxTQUFTLE9BQVEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDN0QsUUFBTXVTLGFBQWE7QUFFbkIsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBQ1g7QUFBQSwyQkFBQyxRQUFHLFdBQVUsdUNBQXVDdlMsbUJBQVMsV0FBVyx3QkFBd0IsMkJBQTJCRixFQUFFLE1BQTlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUk7QUFBQSxJQUdqSSx1QkFBQyxTQUFJLFdBQVUseUJBQ1gsaUNBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxnQkFBZSxXQUFVLDJDQUEwQyw2QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFFBQy9GLHVCQUFDLFdBQU0sSUFBRyxnQkFBZSxNQUFLLFFBQU8sT0FBT1MsV0FBV0UsY0FBYyxVQUFVLENBQUFxSyxNQUFLa0QsbUJBQW1CLGdCQUFnQmxELEVBQUU2RCxPQUFPOUssS0FBSyxHQUFHLFdBQVcwTyxZQUFZLGNBQWEsU0FBNUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTDtBQUFBLFdBRnJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEM7QUFBQTtBQUFBLFVBQVUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLGFBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEc7QUFBQSxRQUM1RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBV3pSO0FBQUFBLFlBQ1gsV0FBV1AsV0FBV0ssZUFBZTtBQUFBLFlBQ3JDLGNBQWNHO0FBQUFBLFlBQ2QsY0FBY3VKO0FBQUFBLFlBQ2QsZUFBZSxNQUFNMEYsVUFBVSxRQUFRO0FBQUEsWUFDdkMsY0FBYyxNQUFNO0FBQ2hCeFAsNEJBQWMsQ0FBQXFLLFVBQVMsRUFBRSxHQUFHQSxNQUFNbEssV0FBVyxNQUFNQyxhQUFhLElBQUlDLFVBQVUsRUFBRSxFQUFFO0FBQ2xGTSw2QkFBZSxFQUFFO0FBQ2pCSSxrQ0FBb0IsRUFBRTtBQUN0QkUsdUNBQXlCLEVBQUU7QUFDM0JJLGdDQUFrQixDQUFDLENBQUM7QUFDcEJFLDZDQUErQixDQUFDLENBQUM7QUFDakNoQixpQ0FBbUIsRUFBRTtBQUNyQmtCLHNDQUF3QixDQUFDO0FBQ3pCWixxQ0FBdUIsSUFBSTtBQUMzQmMsb0NBQXNCLElBQUk7QUFDMUJFLHlDQUEyQixDQUFDLENBQUM7QUFBQSxZQUNqQztBQUFBLFlBQ0EsVUFBVXJDLFNBQVM7QUFBQTtBQUFBLFVBbkJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQjhCO0FBQUEsUUFFN0JnQyx1QkFBdUIsS0FDcEIsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsVUFBOEJyRCxZQUFZcUQsc0JBQXNCLFVBQVU7QUFBQSxhQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsV0F4QjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxTQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBLEtBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNwRTJKLDJCQUNHLHVCQUFDLE9BQUUsV0FBVSwrQkFBNkIsc0ZBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUhqSyxxQkFDRyx1QkFBQyxTQUFJLFdBQVUsNEJBQTJCLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRELElBQzVESixpQkFBaUJ3SCxTQUFTLElBQzFCLHVCQUFDLFNBQUksV0FBVSxrRkFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkJBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwyREFBMEQscUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsUUFBRyxXQUFVLDJEQUEwRCw2QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxRQUFHLFdBQVUsNERBQTJELHFCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLFFBQUcsV0FBVSw0REFBMkQscUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsUUFBRyxXQUFVLGlFQUFnRSwrQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxhQUxqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnhILDJCQUFpQitCO0FBQUFBLFVBQUksQ0FBQTBFLGFBQ2xCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUscUJBQXFCcEosc0JBQVlvSixTQUFTeUssZUFBZSxNQUFNLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0UsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQnpLLG1CQUFTMEssbUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFDNUQsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQzlULHNCQUFZb0osU0FBU3lKLGNBQWMsVUFBVSxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzdGLHVCQUFDLFFBQUcsV0FBVSx5REFBeUQ3UyxzQkFBWW9KLFNBQVM2QixTQUFTLFVBQVUsS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUg7QUFBQSxZQUNqSCx1QkFBQyxRQUFHLFdBQVUsYUFDVixpQ0FBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2hJLGVBQWVtRyxTQUFTakksRUFBRTtBQUFBLGtCQUNqQyxVQUFVLENBQUE0UyxRQUFPdEUsMEJBQTBCckcsU0FBU2pJLElBQUk0UyxHQUFHO0FBQUEsa0JBQzNELFFBQVEsTUFBTXRFLDBCQUEwQnJHLFNBQVNqSSxJQUFJOEIsZUFBZW1HLFNBQVNqSSxFQUFFLEtBQUssQ0FBQztBQUFBLGtCQUNyRixXQUFVO0FBQUEsa0JBQ1YsS0FBS2tELE9BQU8rRSxTQUFTNkIsT0FBTyxLQUFLO0FBQUEsa0JBQ2pDLGNBQVksZ0NBQWdDN0IsU0FBUzBLLGVBQWU7QUFBQTtBQUFBLGdCQVB4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPMkU7QUFBQSxjQUUzRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNckUsMEJBQTBCckcsU0FBU2pJLElBQUlrRCxPQUFPK0UsU0FBUzZCLE9BQU8sS0FBSyxDQUFDO0FBQUEsa0JBQ25GLFdBQVU7QUFBQSxrQkFDVixPQUFNO0FBQUEsa0JBQ04sY0FBWSwyQkFBMkJqTCxZQUFZb0osU0FBUzZCLFNBQVMsVUFBVSxDQUFDLGtCQUFrQjdCLFNBQVMwSyxlQUFlO0FBQUEsa0JBRTFILGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsZUExQksxSyxTQUFTakksSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxRQUNILEtBOUJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSw4QkFDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSxpRUFBZ0UsK0JBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlHO0FBQUEsVUFDekcsdUJBQUMsUUFBRyxXQUFVLDBDQUEwQ25CLHNCQUFZbU4sT0FBT0Usc0JBQXNCLFVBQVUsS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkc7QUFBQSxhQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQS9DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0RBLEtBakRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrREEsSUFFQSx1QkFBQyxPQUFFLFdBQVUsOEJBQThCekwscUJBQVdJLFlBQVksNkJBQTZCLDhCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBIO0FBQUEsU0E5RGxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnRUE7QUFBQSxJQUdDYSxzQkFBc0JzSCxTQUFTLEtBQzVCLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNENBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEU7QUFBQSxNQUM5RSx1QkFBQyxTQUFJLFdBQVUsa0ZBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJCQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMkRBQTBELG9CQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFFBQUcsV0FBVSwyREFBMEQscUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsUUFBRyxXQUFVLDJEQUEwRCxpQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxRQUFHLFdBQVUsNERBQTJELHFCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLFFBQUcsV0FBVSw0REFBMkQscUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUUsdUJBQUMsUUFBRyxXQUFVLGlFQUFnRSwrQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxhQU5qRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnRILGdDQUFzQjZCLElBQUksQ0FBQW1MLFNBQVE7QUFDL0IsZ0JBQU01RSxVQUFVMUwsa0JBQWtCc1EsSUFBSTtBQUN0QyxnQkFBTW1FLFFBQVF4VSxnQkFBZ0JxUSxJQUFJO0FBQ2xDLGdCQUFNb0UsWUFBWXBFLEtBQUt6RyxVQUFVMEssbUJBQW1CakUsS0FBS3FFLGtCQUFrQjtBQUMzRSxnQkFBTUMsVUFBVXRFLEtBQUt4RCxTQUFTO0FBQzlCLGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUscUJBQ1YsaUNBQUMsVUFBSyxXQUFXLGlFQUFpRThILFVBQVUsNEJBQTRCLDZCQUE2QixJQUNoSkEsb0JBQVUsV0FBVyxhQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQm5VLHNCQUFZNlAsS0FBS3VFLFlBQVksTUFBTSxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFLHVCQUFDLFFBQUcsV0FBVSxxQkFBcUJILHVCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0NqVSxzQkFBWWdVLE9BQU8sVUFBVSxLQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQzdFLHVCQUFDLFFBQUcsV0FBVyw0Q0FBNEMvSSxVQUFVLElBQUksbUJBQW1CLGNBQWMsSUFDckdqTCxzQkFBWWlMLFNBQVMsVUFBVSxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDVixpQ0FBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsT0FBTzlILDRCQUE0QjBNLEtBQUsxTyxFQUFFO0FBQUEsa0JBQzFDLFVBQVUsQ0FBQTRTLFFBQU9uRSxnQ0FBZ0NDLEtBQUsxTyxJQUFJNFMsR0FBRztBQUFBLGtCQUM3RCxRQUFRLE1BQU1uRSxnQ0FBZ0NDLEtBQUsxTyxJQUFJZ0MsNEJBQTRCME0sS0FBSzFPLEVBQUUsS0FBSyxDQUFDO0FBQUEsa0JBQ2hHLFdBQVU7QUFBQSxrQkFDVixjQUFZLDZCQUE2QjhTLFNBQVM7QUFBQTtBQUFBLGdCQU50RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNeUQ7QUFBQSxjQUV6RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNckUsZ0NBQWdDQyxLQUFLMU8sSUFBSThKLE9BQU87QUFBQSxrQkFDL0QsV0FBVTtBQUFBLGtCQUNWLE9BQU07QUFBQSxrQkFDTixjQUFZLDJCQUEyQmpMLFlBQVlpTCxTQUFTLFVBQVUsQ0FBQyxlQUFlZ0osU0FBUztBQUFBLGtCQUUvRixpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQSxLQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBaENLcEUsS0FBSzFPLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxRQUVSLENBQUMsS0ExQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLDhCQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLGlFQUFnRSwrQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUc7QUFBQSxVQUN6Ryx1QkFBQyxRQUFHLFdBQVUsMENBQTBDbkIsc0JBQVltTixPQUFPRywyQkFBMkIsVUFBVSxLQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSDtBQUFBLGFBRnRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2REEsS0E5REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStEQTtBQUFBLFNBakVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrRUE7QUFBQSxJQUlKLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1QkFBc0IsOEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUNsRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTd0MsZUFBZSxXQUFVLGtIQUNwRDtBQUFBLGlDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFHO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSxxQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHNCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCx5QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsdUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsVUFDbEYsdUJBQUMsUUFBRyxXQUFVLHVDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFQdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p6TixnQkFBTXFDLElBQUksQ0FBQ3BFLE1BQU1rUixVQUFVO0FBQ3hCLGdCQUFNNkMsa0JBQWtCL1QsS0FBS0ksd0JBQXdCO0FBQ3JELGdCQUFNNFQsdUJBQXVCaFUsS0FBS0ksd0JBQXdCLFNBQVNKLEtBQUtJLHdCQUF3QjtBQUNoRyxnQkFBTTZULFNBQVNqVSxLQUFLSSx3QkFBd0I7QUFDNUMsZ0JBQU04VCxtQkFBbUJsVSxLQUFLSSx3QkFBd0I7QUFDdEQsZ0JBQU0rVCxvQkFBb0I3VCw0QkFBNEJOLElBQUk7QUFDMUQsZ0JBQU1vVSx1QkFBdUJyVSx5QkFBeUJDLElBQUk7QUFDMUQsZ0JBQU1xVSxjQUFjaFUsc0JBQXNCTCxJQUFJO0FBRTlDLGlCQUNJLHVCQUFDLFFBRUc7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdURBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxPQUFPQSxLQUFLSTtBQUFBQSxnQkFDWixVQUFVLENBQUF5TCxNQUFLUSxpQkFBaUJyTSxLQUFLaUYsUUFBUSx1QkFBdUI0RyxFQUFFNkQsT0FBTzlLLEtBQUs7QUFBQSxnQkFDbEYsV0FBVzBPO0FBQUFBLGdCQUNYLGNBQVksaUJBQWlCcEMsUUFBUSxDQUFDO0FBQUEsZ0JBQ3RDLFVBQVVpRDtBQUFBQSxnQkFFVjtBQUFBLHlDQUFDLFlBQU8sT0FBTSxPQUFNLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLGtCQUM1Qix1QkFBQyxZQUFPLE9BQU0sT0FBTSw2QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDakMsdUJBQUMsWUFBTyxPQUFNLE9BQU0sNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQ2pDLHVCQUFDLFlBQU8sT0FBTSxPQUFNLCtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLGtCQUNuQyx1QkFBQyxZQUFPLE9BQU0sT0FBTSxzQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQSxrQkFDekJwUix1QkFBdUIsS0FDcEIsdUJBQUMsWUFBTyxPQUFNLE9BQU07QUFBQTtBQUFBLG9CQUFtQnJELFlBQVlxRCxzQkFBc0IsVUFBVTtBQUFBLG9CQUFFO0FBQUEsdUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNGO0FBQUEsa0JBRXpGcVIsd0JBQ0csdUJBQUMsWUFBTyxPQUFPeFYsb0NBQW9DLHFEQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RjtBQUFBLGtCQUUzRnlWLGVBQWVyVSxLQUFLbUcsb0JBQW9CLFFBQ3JDLHVCQUFDLFlBQU8sT0FBT3JILGdDQUFnQ2tCLEtBQUttRyxnQkFBZ0IsR0FDL0Q1RixxQ0FBMkJQLElBQUksS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQXJCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1QkEsS0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUdBLHVCQUFDLFFBQUcsV0FBVSxrQ0FDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVdBLEtBQUtzRjtBQUFBQSxnQkFDaEIsV0FBV3RGLEtBQUs4RSxlQUFlbEIsUUFBUTtBQUFBLGdCQUN2QyxjQUFjLENBQUMwUSxRQUFRakksaUJBQWlCck0sS0FBS2lGLFFBQVEsbUJBQW1CcVAsR0FBRztBQUFBLGdCQUMzRSxjQUFjLE1BQU14SSxxQkFBcUI5TCxLQUFLaUYsUUFBUSxTQUFTO0FBQUEsZ0JBQy9ELGVBQWUsTUFBTThMLFVBQVUsRUFBRWhGLE1BQU0sZUFBZW1GLE1BQU0sQ0FBQztBQUFBLGdCQUM3RCxjQUFjLE1BQU07QUFDaEI3RSxtQ0FBaUJyTSxLQUFLaUYsUUFBUSxpQkFBaUIsSUFBSTtBQUNuRG9ILG1DQUFpQnJNLEtBQUtpRixRQUFRLG1CQUFtQixFQUFFO0FBQUEsZ0JBQ3ZEO0FBQUEsZ0JBQ0EsVUFBVWtQO0FBQUFBO0FBQUFBLGNBVmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVWdDLEtBWHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxZQUdBLHVCQUFDLFFBQUcsV0FBVSxrQ0FDVixpQ0FBQyxTQUFJLFdBQVdGLFVBQVVFLG9CQUFvQixjQUFjLElBQ3hEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV25VLEtBQUt3RjtBQUFBQSxnQkFDaEIsV0FBV3hGLEtBQUt3RSxhQUFhO0FBQUEsZ0JBQzdCLGNBQWMsQ0FBQzhQLFFBQVFqSSxpQkFBaUJyTSxLQUFLaUYsUUFBUSxnQkFBZ0JxUCxHQUFHO0FBQUEsZ0JBQ3hFLGNBQWMsTUFBTXhJLHFCQUFxQjlMLEtBQUtpRixRQUFRLE1BQU07QUFBQSxnQkFDNUQsZUFBZSxNQUFNOEwsVUFBVSxFQUFFaEYsTUFBTSxZQUFZbUYsTUFBTSxDQUFDO0FBQUEsZ0JBQzFELGNBQWMsTUFBTTtBQUNoQjdFLG1DQUFpQnJNLEtBQUtpRixRQUFRLFdBQVcsSUFBSTtBQUM3Q29ILG1DQUFpQnJNLEtBQUtpRixRQUFRLGFBQWEsSUFBSTtBQUMvQ29ILG1DQUFpQnJNLEtBQUtpRixRQUFRLGdCQUFnQixFQUFFO0FBQUEsZ0JBQ3BEO0FBQUEsZ0JBQ0EsVUFBVWlQLG9CQUFvQkgsbUJBQW1CSTtBQUFBQTtBQUFBQSxjQVhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXdUUsS0FaM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQSxLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFHQSx1QkFBQyxRQUFHLFdBQVUsa0NBQ1YsaUNBQUMsU0FBSSxXQUFXRixVQUFVRSxvQkFBb0IsY0FBYyxJQUN2REosNEJBQ0csdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxXQUFXL1QsS0FBS3lGO0FBQUFBLGtCQUNoQixXQUFXekYsS0FBSzBFLGVBQWUsV0FBVzFFLEtBQUswRSxZQUFZLEtBQUs7QUFBQSxrQkFDaEUsY0FBYyxDQUFDNFAsUUFBUWpJLGlCQUFpQnJNLEtBQUtpRixRQUFRLG1CQUFtQnFQLEdBQUc7QUFBQSxrQkFDM0UsY0FBYyxNQUFNeEkscUJBQXFCOUwsS0FBS2lGLFFBQVEsZ0JBQWdCO0FBQUEsa0JBQ3RFLGVBQWUsTUFBTThMLFVBQVUsRUFBRWhGLE1BQU0scUJBQXFCbUYsTUFBTSxDQUFDO0FBQUEsa0JBQ25FLGNBQWMsTUFBTTtBQUNoQjdFLHFDQUFpQnJNLEtBQUtpRixRQUFRLHFCQUFxQixJQUFJO0FBQ3ZEb0gscUNBQWlCck0sS0FBS2lGLFFBQVEsU0FBUyxDQUFDO0FBQ3hDb0gscUNBQWlCck0sS0FBS2lGLFFBQVEsV0FBVyxJQUFJO0FBQzdDb0gscUNBQWlCck0sS0FBS2lGLFFBQVEsYUFBYSxJQUFJO0FBQy9Db0gscUNBQWlCck0sS0FBS2lGLFFBQVEsZ0JBQWdCLElBQUk7QUFDbERvSCxxQ0FBaUJyTSxLQUFLaUYsUUFBUSxjQUFjLElBQUk7QUFDaERvSCxxQ0FBaUJyTSxLQUFLaUYsUUFBUSxtQkFBbUIsRUFBRTtBQUNuRG9ILHFDQUFpQnJNLEtBQUtpRixRQUFRLHNCQUFzQixFQUFFO0FBQ3REb0gscUNBQWlCck0sS0FBS2lGLFFBQVEsb0JBQW9CLEVBQUU7QUFDcERvSCxxQ0FBaUJyTSxLQUFLaUYsUUFBUSx5QkFBeUIsRUFBRTtBQUFBLGtCQUM3RDtBQUFBO0FBQUEsZ0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCTTtBQUFBLGVBRUosTUFBTTtBQUNKLHNCQUFNc1AsU0FBU3ZVLEtBQUswRixzQkFBc0IxRixLQUFLZ0YsZ0JBQWdCVyxnQkFBZ0I7QUFDL0Usc0JBQU02TyxPQUFPeFUsS0FBSzRGLG9CQUFvQjVGLEtBQUtnRixnQkFBZ0JhLGVBQWU7QUFDMUUsc0JBQU00TyxZQUFZelUsS0FBSzhGLHlCQUF5QjlGLEtBQUtnRixnQkFBZ0JlLG9CQUFvQjtBQUN6RixvQkFBSSxDQUFDd08sVUFBVSxDQUFDQyxLQUFNLFFBQU87QUFDN0IsdUJBQ0ksdUJBQUMsU0FBSSxXQUFVLHlCQUNWQztBQUFBQSw4QkFBWSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxvQkFBYUE7QUFBQUEsdUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRCLElBQVM7QUFBQSxrQkFDakRGLFNBQVMsdUJBQUMsU0FBSTtBQUFBO0FBQUEsb0JBQVNBO0FBQUFBLHVCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFCLElBQVM7QUFBQSxrQkFDdkNDLE9BQU8sdUJBQUMsU0FBSTtBQUFBO0FBQUEsb0JBQU9BO0FBQUFBLHVCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlCLElBQVM7QUFBQSxxQkFIdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGNBRVIsR0FBRztBQUFBLGlCQWhDUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQSxJQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFVBQVVOLG9CQUFvQkM7QUFBQUEsZ0JBQzlCLE9BQU9uVSxLQUFLMEUsZ0JBQWdCO0FBQUEsZ0JBQzVCLFVBQVUsQ0FBQW1ILE1BQUtRLGlCQUFpQnJNLEtBQUtpRixRQUFRLGdCQUFnQjRHLEVBQUU2RCxPQUFPOUssS0FBSztBQUFBLGdCQUMzRSxXQUFXME87QUFBQUEsZ0JBQ1gsYUFBYVUsdUJBQXVCLHFCQUFxQjtBQUFBLGdCQUN6RCxjQUFZLGNBQWM5QyxRQUFRLENBQUM7QUFBQSxnQkFBSSxjQUFhO0FBQUE7QUFBQSxjQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPNkQsS0E1Q3JFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOENBLEtBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0RBO0FBQUEsWUFHQSx1QkFBQyxRQUFHLFdBQVUsa0NBQ1YsaUNBQUMsU0FBSSxXQUFXK0MsVUFBVUUsb0JBQW9CLGNBQWMsSUFDeEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsVUFBVUQsb0JBQW9CSCxtQkFBbUJJO0FBQUFBLGdCQUNqRCxPQUFPblUsS0FBSzJFLGFBQWFoRixtQkFBbUIsSUFBSThCLEtBQUt6QixLQUFLMkUsVUFBVSxDQUFDLElBQUk7QUFBQSxnQkFDekUsVUFBVSxDQUFBa0gsTUFBS1EsaUJBQWlCck0sS0FBS2lGLFFBQVEsY0FBYzRHLEVBQUU2RCxPQUFPOUssS0FBSztBQUFBLGdCQUN6RSxXQUFXME87QUFBQUEsZ0JBQ1gsY0FBWSxTQUFTcEMsUUFBUSxDQUFDO0FBQUEsZ0JBQUksY0FBYTtBQUFBO0FBQUEsY0FObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXdELEtBUDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUEsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFHQSx1QkFBQyxRQUFHLFdBQVUsa0NBQ1YsaUNBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFVBQVU2QztBQUFBQSxrQkFDVixPQUFPL1QsS0FBSzRFO0FBQUFBLGtCQUNaLFVBQVUsQ0FBQTZPLFFBQU9wSCxpQkFBaUJyTSxLQUFLaUYsUUFBUSxTQUFTd08sR0FBRztBQUFBLGtCQUMzRCxhQUFZO0FBQUEsa0JBQ1osV0FBVyxHQUFHSCxVQUFVO0FBQUEsa0JBQ3hCLGNBQVksV0FBV3BDLFFBQVEsQ0FBQztBQUFBO0FBQUEsZ0JBUHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU91QztBQUFBLGNBRXRDLENBQUM2QyxtQkFBbUIsQ0FBQ0kscUJBQ2xCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU14RSxnQ0FBZ0MzUCxLQUFLaUYsTUFBTTtBQUFBLGtCQUMxRCxVQUFVNEgsT0FBT0MsZUFBZTtBQUFBLGtCQUNoQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUNOLGNBQVc7QUFBQSxrQkFFWCxpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQXBCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQSxLQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBR0EsdUJBQUMsUUFBRyxXQUFVLHVEQUNULFdBQUNxSCxxQkFDRSx1QkFBQyxZQUFPLFNBQVMsTUFBTTFFLGlCQUFpQnpQLEtBQUtpRixNQUFNLEdBQUcsV0FBVSx1Q0FBc0MsY0FBWSxpQkFBaUJpTSxRQUFRLENBQUMsSUFDeEksaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFRLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQWxLS2xSLEtBQUtpRixRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUtBO0FBQUEsUUFFUixDQUFDLEtBaExMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpTEE7QUFBQSxRQUNDbEQsTUFBTThILFNBQVMsS0FDWix1QkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSx5RUFBd0UscUNBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVIO0FBQUEsVUFDdkgsdUJBQUMsUUFBRyxXQUFVLDBDQUEwQ25LLHNCQUFZbU4sT0FBT2MsV0FBVyxVQUFVLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsVUFDbEcsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFJO0FBQUEsYUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQXJNUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdU1BLEtBeE1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5TUE7QUFBQSxTQWhOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaU5BO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaURBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLHdDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUEwQnpFMUssdUJBQXVCLE1BQU07QUFDMUIsZ0JBQU15UixVQUFVM1MsTUFBTXVFLEtBQUt2Ryx3QkFBd0I7QUFDbkQsZ0JBQU00VSxnQkFBZ0JELFVBQ2hCM1EsT0FBTzJRLFFBQVE5UCxLQUFLLEtBQUssSUFDeEIzQixtQkFBbUJ1RSxVQUFVO0FBQ3BDLGNBQUltTixpQkFBaUIsRUFBRyxRQUFPO0FBQy9CLGlCQUNJLHVCQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBVSxzREFBb0Q7QUFBQTtBQUFBLGNBQzdCMVIsbUJBQW1Cd0UsWUFBWSxVQUFVeEUsbUJBQW1Cd0UsU0FBUyxNQUFNO0FBQUEsaUJBRGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxvRUFDWC9ILHNCQUFZaVYsZUFBZSxVQUFVLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxRQUVSLEdBQUc7QUFBQSxRQUNGcEksK0JBQStCbkksSUFBSSxDQUFBMEssT0FBTTtBQUN0QyxnQkFBTTVFLElBQUkvRyx3QkFBd0IyTCxHQUFHak8sRUFBRTtBQUN2QyxnQkFBTXNSLGdCQUFnQnBRLE1BQU11RTtBQUFBQSxZQUN4QixDQUFBakMsTUFDSWhFLHNCQUFzQmdFLENBQUMsTUFDdEJBLEVBQUU4QixxQkFBcUIySSxHQUFHak8sTUFDdkI5QixrQ0FBa0NzRixFQUFFakUsbUJBQW1CLE1BQU0wTyxHQUFHak87QUFBQUEsVUFDNUU7QUFDQSxnQkFBTThULGdCQUFnQnhDLGdCQUNoQnBPLE9BQU9vTyxjQUFjdk4sS0FBSyxLQUFLLElBQzlCc0YsR0FBRzFDLFVBQVU7QUFDcEIsY0FBSW1OLGlCQUFpQixFQUFHLFFBQU87QUFDL0IsZ0JBQU1DLGFBQWExSyxHQUFHekQsWUFBWXFJLEdBQUdsTCxRQUFRLElBQUlsRCxLQUFLO0FBQ3RELGlCQUNJLHVCQUFDLFNBQWdCLFdBQVUsdUNBQ3ZCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNEQUNYa1Usc0JBQVksYUFBYUEsU0FBUyxLQUFLLGVBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxvRUFDWGxWLHNCQUFZaVYsZUFBZSxVQUFVLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5NN0YsR0FBR2pPLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFFBRVIsQ0FBQztBQUFBLFdBbkVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpRkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSwwQ0FBeUMsdUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUM5RCxtQ0FDSTtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSxtQ0FBQyxVQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CO0FBQUEsWUFBTztBQUFBLFlBQUMsdUJBQUMsVUFBTW5CLHNCQUFZbU4sT0FBT0MsYUFBYSxVQUFVLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsZUFBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0k7QUFBQSxVQVFwSSx1QkFBQyxTQUFJLFdBQVUsa0NBQWlDO0FBQUEsbUNBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQU87QUFBQSxZQUFDLHVCQUFDLFVBQU1wTixzQkFBWW1OLE9BQU9lLGdCQUFnQixVQUFVLEtBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsZUFBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0k7QUFBQSxhQVQ1STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw2REFBNEQ7QUFBQSxpQ0FBQyxVQUFLLHNDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFBTztBQUFBLFVBQUMsdUJBQUMsVUFBTWxPLHNCQUFZbU4sT0FBT2MsV0FBVyxVQUFVLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsYUFBaEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SztBQUFBLFNBQ3JLMU4sUUFBUWdELHNCQUFzQkEsbUJBQW1CdUUsU0FBUyxDQUFDLEtBQ3pEK0UsK0JBQStCMkQsS0FBSyxDQUFBcEIsUUFBTzNMLHdCQUF3QjJMLEdBQUdqTyxFQUFFLEdBQUcyRyxVQUFVLEtBQUssQ0FBQyxNQUN2Rix1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGtFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsV0FoQnhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQXhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUZBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU0xRyxTQUFTaEIsa0JBQWtCbkIsd0JBQXdCOFQsU0FBUyxDQUFDLEdBQUcsV0FBVSw4SUFBNkksd0JBQTVQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb1E7QUFBQSxNQUNwUSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTQyxZQUFZLFVBQVV0UixVQUFVcUIsb0JBQW9CLFdBQVUsNktBQ3hGckI7QUFBQUEsaUJBQVMsdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdELElBQU0sdUJBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBRHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQ2lDLGVBQWVJLGVBQ1osdUJBQUMsZUFBWSxRQUFRSixhQUFhLFNBQVMsTUFBTUMsZUFBZSxLQUFLLEdBQUcsVUFBVTBOLG1CQUFtQixRQUFRdk4sZUFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5SDtBQUFBLE9BNWVqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOGVBO0FBRVI7QUFBRTdDLEdBcm1EV0QscUJBQW1CO0FBQUEsVUFDYnBELFdBQ0VELGFBSWJRLGFBQzhCOEIsUUFBUTtBQUFBO0FBQUFpVixLQVBqQ2xVO0FBQW1CLElBQUFrVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlQ2FsbGJhY2siLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInRvYXN0IiwiRmFTYXZlIiwiRmFTcGlubmVyIiwiRmFQbHVzIiwiRmFUcmFzaCIsIkZhRmlsbERyaXAiLCJ1c2VDcnVkSXRlbSIsImdldEJ5SWQiLCJzZWFyY2giLCJzZWFyY2hCeUZpZWxkIiwicHJldmlld0dhbmFuY2lhc1JldGVudGlvbiIsInByZXZpZXdSZXRlbnRpb24iLCJidWlsZEFwcGxpZWRQdXJjaGFzZXNGb3JTYXZlIiwiYnVpbGRBcHBsaWVkUHVyY2hhc2VzRm9yUmV0ZW50aW9uUHJldmlldyIsImJ1aWxkQXBwbGllZEZpbmFuY2lhbE5vdGVzRm9yU2F2ZSIsImJ1aWxkR2FuYW5jaWFzUmV0ZW50aW9uUHJldmlld1JlcXVlc3QiLCJidWlsZFJldGVudGlvblByZXZpZXdSZXF1ZXN0IiwiY29tcHV0ZUdyb3NzQXBwbGllZEFtb3VudCIsInN1bUFwcGxpZWRBbW91bnRzUmVjb3JkIiwib3JkZW5lc1BhZ29Nb2R1bGVDb25maWciLCJQQVlNRU5UX01FVEhPRF9SRVRFTlRJT05fR0FOQU5DSUFTIiwiR0FOQU5DSUFTX1RBWF9JRCIsImJ1aWxkVmVuZG9yUmV0ZW50aW9uUGF5bWVudENvZGUiLCJwYXJzZVRheElkRnJvbVZlbmRvclJldGVudGlvbkNvZGUiLCJpc1ZlbmRvckR5bmFtaWNSZXRlbnRpb25QYXltZW50Q29kZSIsInNpZ25lZE5vdGVCYWxhbmNlIiwic2lnbmVkTm90ZVRvdGFsIiwidW5kZWxpdmVyZWRDaGVja3NDb25maWciLCJwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsIkxvYWRpbmdTcGlubmVyIiwiZm9ybWF0VmFsdWUiLCJmb3JtYXREYXRlRm9ySW5wdXQiLCJ1c2VNb2RhbCIsImJhbmNvc01vZHVsZUNvbmZpZyIsImdldExpc3RSZXR1cm5QYXRoIiwiaXNHYW5hbmNpYXNSZXRlbnRpb25JdGVtIiwiaXRlbSIsIkJvb2xlYW4iLCJpc19zeXN0ZW1fZ2VuZXJhdGVkIiwic3lzdGVtX3R5cGUiLCJwYXltZW50X21ldGhvZF9jb2RlIiwiaXNWZW5kb3JSZXRlbnRpb25JdGVtIiwiaXNTeXN0ZW1SZXRlbnRpb25QYXltZW50Um93IiwidmVuZG9yUmV0ZW50aW9uU2VsZWN0TGFiZWwiLCJuIiwicmV0ZW50aW9uX3RheF9uYW1lIiwidHJpbSIsIk9yZGVuZXNQYWdvRm9ybVBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJtb2RlIiwiaW5pdGlhbERhdGEiLCJsb2FkaW5nIiwibG9hZGluZ0luaXRpYWwiLCJzYXZlSXRlbSIsInNhdmluZyIsInNob3dDb25maXJtYXRpb25Nb2RhbCIsImhlYWRlckRhdGEiLCJzZXRIZWFkZXJEYXRhIiwicGF5bWVudF9kYXRlIiwiRGF0ZSIsInZlbmRvcl9pZCIsInZlbmRvcl9uYW1lIiwiZGlzY291bnQiLCJ2ZW5kb3JDb2RlSW5wdXQiLCJzZXRWZW5kb3JDb2RlSW5wdXQiLCJpdGVtcyIsInNldEl0ZW1zIiwidmVuZG9yVGF4ZXMiLCJzZXRWZW5kb3JUYXhlcyIsInZlbmRvclJldGVudGlvbkluZm8iLCJzZXRWZW5kb3JSZXRlbnRpb25JbmZvIiwicGVuZGluZ1B1cmNoYXNlcyIsInNldFBlbmRpbmdQdXJjaGFzZXMiLCJwZW5kaW5nRmluYW5jaWFsTm90ZXMiLCJzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMiLCJpc0xvYWRpbmdQdXJjaGFzZXMiLCJzZXRJc0xvYWRpbmdQdXJjaGFzZXMiLCJhcHBsaWVkQW1vdW50cyIsInNldEFwcGxpZWRBbW91bnRzIiwiYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzIiwic2V0QXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzIiwidmVuZG9yQWR2YW5jZUJhbGFuY2UiLCJzZXRWZW5kb3JBZHZhbmNlQmFsYW5jZSIsImdhbmFuY2lhc1JldGVudGlvbiIsInNldEdhbmFuY2lhc1JldGVudGlvbiIsInZlbmRvclJldGVudGlvbnNQcmV2aWV3Iiwic2V0VmVuZG9yUmV0ZW50aW9uc1ByZXZpZXciLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwidmVuZG9yIiwibmFtZSIsInZlbmRvcl9jb2RlIiwiU3RyaW5nIiwiTnVtYmVyIiwiYWR2YW5jZV9iYWxhbmNlIiwiZG9fbm90X3JldGFpbiIsInZlbmRvcl90eXBlIiwibWFwcGVkSXRlbXMiLCJtYXAiLCJpIiwibmV3SXRlbSIsImJhbmtfaWQiLCJiYW5rX25hbWUiLCJiYW5rX2NvZGUiLCJjaGVja19udW1iZXIiLCJjaGVja19kYXRlIiwidmFsdWUiLCJjaGVja19rZXkiLCJjaGFydF9hY2NvdW50IiwicmVjZWl2ZWRfY2hlY2tfaWQiLCJyZWNlaXZlZF9jaGVjayIsInRlbXBJZCIsImNyeXB0byIsInJhbmRvbVVVSUQiLCJ2YWx1ZV9iYXNlIiwiaXNOYU4iLCJ1aV9hY2NvdW50X2NvZGUiLCJjb2RlIiwidWlfYmFua19jb2RlIiwidWlfY2hlY2tfc2VhcmNoIiwidWlfcmVjZWl2ZWRfaG9sZGVyIiwiY2hlY2tfaG9sZGVyIiwidWlfcmVjZWl2ZWRfY3VpdCIsImlzc3Vlcl9jdWl0IiwidWlfcmVjZWl2ZWRfcmVmZXJlbmNlIiwicmVmZXJlbmNlX251bWJlciIsImJhbmsiLCJyZXRlbnRpb25fdmFsdWVfb3ZlcnJpZGRlbiIsInZlbmRvclJldFRheElkIiwicmV0ZW50aW9uX3RheF9pZCIsIm1hdGNoVGF4IiwiYXBwbGllZF90YXhlcyIsImZpbmQiLCJ0IiwidGF4X2lkIiwidGF4X25hbWUiLCJ1bmRlZmluZWQiLCJyZXRSb3dTZWVuIiwic2VlblZlbmRvclJldGVudGlvblRheElkcyIsIlNldCIsIml0ZW1zRmlsdGVyZWQiLCJmaWx0ZXIiLCJpdCIsInZ0aWQiLCJoYXMiLCJhZGQiLCJyZXRJdFBlcnNpc3RlZCIsInBlcnNpc3RlZFJldGVudGlvblZhbHVlQmFzZSIsImdhblRheCIsImluY2x1ZGVzIiwiYW1vdW50IiwiY2FzZV9jb2RlIiwicmV0SXQiLCJpbml0aWFsVmVuZG9yUmV0UHJldmlldyIsInRpZCIsImF0IiwicGVyc2lzdGVkVmIiLCJsb2FkVmVuZG9yVGF4ZXMiLCJ2ZW5kb3JJZCIsImZ1bGxWZW5kb3IiLCJ0YXhlcyIsImVycm9yIiwibG9hZEVkaXREYXRhIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwidG9TdHJpbmciLCJoYXNfYmFsYW5jZSIsInBlbmRpbmdSZXNwb25zZVByb21pc2UiLCJwZW5kaW5nTm90ZXNQcm9taXNlIiwiYXBwbGllZFB1cmNoYXNlSWRzIiwiYXBwbGllZF9wdXJjaGFzZXMiLCJhcCIsInB1cmNoYXNlIiwiYXBwbGllZFB1cmNoYXNlc1Byb21pc2VzIiwiYXBwbGllZE5vdGVJZHMiLCJhcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyIsImFuIiwicHVyY2hhc2VfZmluYW5jaWFsX25vdGUiLCJhcHBsaWVkTm90ZXNQcm9taXNlcyIsIm5vdGVJZCIsInBlbmRpbmdSZXNwb25zZSIsInBlbmRpbmdOb3Rlc1Jlc3BvbnNlIiwiZmV0Y2hlZEFwcGxpZWQiLCJQcm9taXNlIiwiYWxsIiwiZmV0Y2hlZEFwcGxpZWRQdXJjaGFzZXMiLCJzbGljZSIsImxlbmd0aCIsImZldGNoZWRBcHBsaWVkTm90ZXMiLCJhbGxQdXJjaGFzZXNNYXAiLCJNYXAiLCJmb3JFYWNoIiwicCIsInNldCIsImRhdGEiLCJmaW5hbFB1cmNoYXNlcyIsIkFycmF5IiwiZnJvbSIsInZhbHVlcyIsImFwcGxpZWREZXRhaWwiLCJvcmlnaW5hbEJhbGFuY2UiLCJiYWxhbmNlIiwiYW1vdW50X2FwcGxpZWQiLCJhbGxOb3Rlc01hcCIsImZpbmFsTm90ZXMiLCJjdXJyZW50QmFsYW5jZSIsImluaXRpYWxBbW91bnRzIiwicmVkdWNlIiwiYWNjIiwiaW5pdGlhbE5vdGVBbW91bnRzIiwiY29uc29sZSIsImhhbmRsZVZlbmRvckNvZGVTdWJtaXQiLCJmb3VuZCIsImVuZHBvaW50IiwiZmllbGROYW1lIiwiaGFuZGxlU2VsZWN0VmVuZG9yIiwic3VjY2VzcyIsIndhcm4iLCJwcmV2IiwiZSIsImhhbmRsZUl0ZW1Db2RlU3VibWl0IiwidHlwZSIsIml0ZW1JbmRleCIsImZpbmRJbmRleCIsImNvbmZpZyIsInNlYXJjaEZpZWxkIiwiY29kZVZhbHVlIiwiaGFuZGxlSXRlbUNoYW5nZSIsInZlbmRvckdlbmVyYWxUYXhlcyIsInZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbCIsInZhbGlkUHVyY2hhc2VJZHMiLCJyZXRlbnRpb25BcHBsaWVkUHVyY2hhc2VzIiwic2hvd1JldGVudGlvbkFtb3VudEhpbnQiLCJoYXNHYW5hbmNpYXMiLCJoYXNBZGRpdGlvbmFsIiwidG90YWxzIiwiZ3Jvc3NBbW91bnQiLCJwdXJjaGFzZXNHcm9zc0Ftb3VudCIsImZpbmFuY2lhbE5vdGVzR3Jvc3NBbW91bnQiLCJjYWxjdWxhdGVkQXBwbGllZFRheGVzIiwidlRheCIsIm9yaWdpbmFsVGF4IiwiYVRheCIsInB1c2giLCJyYXRlIiwidG90YWxUYXhlcyIsInN1bSIsInRheCIsIm5ldEFtb3VudFRvUGF5IiwidG90YWxQYWlkIiwicmVtYWluaW5nVG9QYXkiLCJNYXRoIiwicm91bmQiLCJhcHBsaWVkVGF4ZXMiLCJpc0NhbmNlbGxlZCIsInJlY2FsY3VsYXRlR2FuYW5jaWFzUmV0ZW50aW9uIiwiYWJzIiwicHJldmlld1BheWxvYWQiLCJyZXNwb25zZSIsInZhbHVlQmFzZUZyb21QcmV2aWV3IiwiY2FsY3VsYXRlZF9yZXRlbnRpb24iLCJ0aW1lb3V0SWQiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwiY2xlYXJUaW1lb3V0IiwicnVuIiwicmVzdWx0cyIsImFueUVycm9yIiwidnQiLCJoYW5kbGVIZWFkZXJDaGFuZ2UiLCJmaWVsZCIsInB1cmNoYXNlc1Jlc3BvbnNlIiwibm90ZXNSZXNwb25zZSIsImhhbmRsZUFtb3VudFRvQXBwbHlDaGFuZ2UiLCJwdXJjaGFzZUlkIiwibnVtZXJpY1ZhbHVlIiwiaGFuZGxlRmluYW5jaWFsTm90ZUFtb3VudENoYW5nZSIsIm5vdGUiLCJoYW5kbGVBZGRJdGVtIiwiaGFuZGxlUmVtb3ZlSXRlbSIsInRhcmdldCIsImZpbGxQYXltZW50SXRlbUZyb21BcHBsaWVkVG90YWwiLCJ0b3RhbEFwbGljYWRvIiwic3VtT3Ryb3MiLCJzIiwibW9udG8iLCJwcmV2SXRlbXMiLCJoYXNSZXRlbnRpb25JdGVtIiwic29tZSIsInZhbHVlQmFzZSIsIm5leHQiLCJ3aXRob3V0VmVuZG9yUmV0cyIsInZlbmRvclJvd3MiLCJwcmV2aWV3IiwiZXhpc3RpbmciLCJzdW1PdGhlclNhbCIsIm1heEFkdmFuY2VGb3JJdGVtIiwibWF4IiwidXBkYXRlZEl0ZW0iLCJtaW4iLCJudW1WYWwiLCJvcGVuTW9kYWwiLCJoYW5kbGVTZWxlY3RNb2RhbCIsInNlbGVjdGVkSXRlbSIsImluZGV4IiwiY2hlY2siLCJwZXJmb3JtU2F2ZVBheW1lbnRPcmRlciIsImNsZWFuSXRlbXMiLCJyb3ciLCJfcmV0ZW50aW9uTmFtZSIsIl9pc1N5cyIsIl9zeXNUeXBlIiwiX3JldFRpZCIsIl9yZXRPdmVycmlkZGVuIiwicmVzdCIsImNsZWFuSXRlbSIsImNoYXJ0X2FjY291bnRfaWQiLCJpdGVtRm9yUmV0ZW50aW9uQ2hlY2siLCJnYW5hbmNpYXNJdGVtIiwiZ2FuYW5jaWFzQW1vdW50IiwidmVuZG9yUmV0ZW50aW9uVGF4RW50cmllcyIsInJldGVudGlvbkl0ZW0iLCJ0YXhlc1RvU2F2ZSIsInBheWxvYWQiLCJncm9zc19hbW91bnQiLCJ0b3RhbF9hbW91bnQiLCJyZXN1bHQiLCJiYXNlUm91dGUiLCJoYW5kbGVTYXZlIiwiaGFzQXBwbGllZFB1cmNoYXNlcyIsImhhc0FwcGxpZWRGaW5hbmNpYWxOb3RlcyIsIm5ldElzWmVybyIsImdyb3NzSXNaZXJvIiwiYWxsb3daZXJvUGF5bWVudHMiLCJwYXltZW50SXRlbXNXaXRoVmFsdWUiLCJkaWZmZXJlbmNlIiwiYWR2YW5jZUFtb3VudCIsInRpdGxlIiwibWVzc2FnZSIsIm9uQ29uZmlybSIsImlucHV0U3R5bGUiLCJwdXJjaGFzZV9kYXRlIiwiZG9jdW1lbnRfbnVtYmVyIiwibnVtIiwidG90YWwiLCJkb2NOdW1iZXIiLCJ2b3VjaGVyX251bWJlciIsImlzRGViaXQiLCJpc3N1ZV9kYXRlIiwiaXNSZWNlaXZlZENoZWNrIiwiaXNPd25DaGVja09yVHJhbnNmZXIiLCJpc0Nhc2giLCJpc0FkdmFuY2VCYWxhbmNlIiwiaXNTeXN0ZW1SZXRlbnRpb24iLCJpc0dhbmFuY2lhc1JldGVudGlvbiIsImlzVmVuZG9yUmV0IiwidmFsIiwiaG9sZGVyIiwiY3VpdCIsInJlZmVyZW5jZSIsImdhbkl0ZW0iLCJkaXNwbGF5QW1vdW50IiwibGFiZWxOYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3JkZW5lc1BhZ29Gb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFTcGlubmVyLCBGYVBsdXMsIEZhVHJhc2gsIEZhRmlsbERyaXAgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbi8vIOKchSBJTVBPUlRBTlRFOiBJbXBvcnRhbW9zIHNlYXJjaEJ5RmllbGRcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaCwgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgcHJldmlld0dhbmFuY2lhc1JldGVudGlvbiwgcHJldmlld1JldGVudGlvbiB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL3JldGVudGlvbnNTZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgYnVpbGRBcHBsaWVkUHVyY2hhc2VzRm9yU2F2ZSxcbiAgICBidWlsZEFwcGxpZWRQdXJjaGFzZXNGb3JSZXRlbnRpb25QcmV2aWV3LFxuICAgIGJ1aWxkQXBwbGllZEZpbmFuY2lhbE5vdGVzRm9yU2F2ZSxcbiAgICBidWlsZEdhbmFuY2lhc1JldGVudGlvblByZXZpZXdSZXF1ZXN0LFxuICAgIGJ1aWxkUmV0ZW50aW9uUHJldmlld1JlcXVlc3QsXG4gICAgY29tcHV0ZUdyb3NzQXBwbGllZEFtb3VudCxcbiAgICBzdW1BcHBsaWVkQW1vdW50c1JlY29yZCxcbn0gZnJvbSAnLi4vYnVpbGRBcHBsaWVkUHVyY2hhc2VzUGF5bG9hZCc7XG5pbXBvcnQge1xuICAgIG9yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLFxuICAgIFBBWU1FTlRfTUVUSE9EX1JFVEVOVElPTl9HQU5BTkNJQVMsXG4gICAgR0FOQU5DSUFTX1RBWF9JRCxcbiAgICBidWlsZFZlbmRvclJldGVudGlvblBheW1lbnRDb2RlLFxuICAgIHBhcnNlVGF4SWRGcm9tVmVuZG9yUmV0ZW50aW9uQ29kZSxcbiAgICBpc1ZlbmRvckR5bmFtaWNSZXRlbnRpb25QYXltZW50Q29kZSxcbiAgICB0eXBlIFBheW1lbnRPcmRlcixcbiAgICB0eXBlIFBheW1lbnRPcmRlckl0ZW0sXG4gICAgdHlwZSBBcHBsaWVkUHVyY2hhc2UsXG4gICAgdHlwZSBSZWNlaXZlZENoZWNrLFxuICAgIHNpZ25lZE5vdGVCYWxhbmNlLFxuICAgIHNpZ25lZE5vdGVUb3RhbCxcbiAgICB1bmRlbGl2ZXJlZENoZWNrc0NvbmZpZ1xufSBmcm9tICcuLi9vcmRlbmVzX3BhZ28uY29uZmlnJztcbmltcG9ydCB7IHR5cGUgUHJvdmVlZG9yLCBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL3Byb3ZlZWRvcmVzL3Byb3ZlZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyB0eXBlIFB1cmNoYXNlIH0gZnJvbSAnLi4vLi4vY29tcHJhcy9jb21wcmFzLmNvbmZpZyc7XG5pbXBvcnQgeyB0eXBlIFB1cmNoYXNlRmluYW5jaWFsTm90ZSB9IGZyb20gJy4uLy4uL25vdGFzX2ZpbmFuY2llcmFzX2NvbXByYS9ub3Rhc19maW5hbmNpZXJhc19jb21wcmEuY29uZmlnJztcbmltcG9ydCB7IHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcsIHR5cGUgUGxhbkRlQ3VlbnRhcyB9IGZyb20gJy4uLy4uL3BsYW5fZGVfY3VlbnRhcy9wbGFuX2RlX2N1ZW50YXMuY29uZmlnJztcbmltcG9ydCB7IFJlbGF0aW9uYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JlbGF0aW9uYWxJbnB1dCc7XG5pbXBvcnQgeyBEZWNpbWFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9EZWNpbWFsSW5wdXQnO1xuaW1wb3J0IHsgU2VhcmNoTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9TZWFyY2hNb2RhbCc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUsIGZvcm1hdERhdGVGb3JJbnB1dCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgdXNlTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb250ZXh0L01vZGFsQ29udGV4dCc7XG5pbXBvcnQgeyBiYW5jb3NNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9iYW5jb3MvYmFuY29zLmNvbmZpZyc7XG5pbXBvcnQgdHlwZSB7IEFwcGxpZWRUYXgsIFJlbGF0ZWRUYXggYXMgVmVuZG9yVGF4IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG50eXBlIEVkaXRpbmdUYXJnZXQgPVxuICAgIHwgJ3ZlbmRvcidcbiAgICB8IHsgdHlwZTogJ2l0ZW1BY2NvdW50JzsgaW5kZXg6IG51bWJlciB9XG4gICAgfCB7IHR5cGU6ICdpdGVtQmFuayc7IGluZGV4OiBudW1iZXIgfVxuICAgIHwgeyB0eXBlOiAnaXRlbVJlY2VpdmVkQ2hlY2snOyBpbmRleDogbnVtYmVyIH07XG5cbnR5cGUgVmVuZG9yV2l0aFRheGVzID0gUHJvdmVlZG9yICYge1xuICAgIHRheGVzPzogVmVuZG9yVGF4W107XG4gICAgZG9fbm90X3JldGFpbj86IGJvb2xlYW47XG4gICAgdmVuZG9yX3R5cGU/OiBzdHJpbmcgfCBudWxsO1xufTtcblxudHlwZSBWZW5kb3JSZXRlbnRpb25JbmZvID0ge1xuICAgIGRvX25vdF9yZXRhaW46IGJvb2xlYW47XG4gICAgdmVuZG9yX3R5cGU6IHN0cmluZyB8IG51bGw7XG59O1xuXG4vLyDinIUgUEFUUsOTTjogRXh0ZW5kZW1vcyBlbCBpdGVtIHBhcmEgaW5jbHVpciBsb3MgZXN0YWRvcyB2aXN1YWxlcyAoaW5wdXRzIGRlIHRleHRvKVxudHlwZSBGb3JtUGF5bWVudE9yZGVySXRlbSA9IE9taXQ8UGF5bWVudE9yZGVySXRlbSwgJ2lkJyB8ICdjaGFydF9hY2NvdW50JyB8ICdiYW5rJyB8ICd2YWx1ZSc+ICYge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIHZhbHVlOiBudW1iZXIgfCBzdHJpbmc7XG4gICAgY2hhcnRfYWNjb3VudDogUGxhbkRlQ3VlbnRhcyB8IG51bGw7XG4gICAgdGVtcElkOiBzdHJpbmc7XG4gICAgcmVjZWl2ZWRfY2hlY2tfaWQ/OiBudW1iZXIgfCBudWxsO1xuXG4gICAgLy8gTWFyY2EgcGFyYSDDrXRlbXMgZ2VuZXJhZG9zIHBvciBlbCBzaXN0ZW1hIChlai4gcmV0ZW5jacOzbiBHYW5hbmNpYXMpXG4gICAgaXNfc3lzdGVtX2dlbmVyYXRlZD86IGJvb2xlYW47XG4gICAgc3lzdGVtX3R5cGU/OiAnZ2FuYW5jaWFzX3JldGVudGlvbicgfCAndmVuZG9yX3JldGVudGlvbic7XG4gICAgLyoqIFBhcmEgbWVkaW9zIFJFVF88dGF4SWQ+ICovXG4gICAgcmV0ZW50aW9uX3RheF9pZD86IG51bWJlcjtcbiAgICAvKiogU29sbyBVSTogbm9tYnJlIGRlbCBpbXB1ZXN0byBkZSByZXRlbmNpw7NuICovXG4gICAgcmV0ZW50aW9uX3RheF9uYW1lPzogc3RyaW5nO1xuICAgIC8qKiBJbXBvcnRlIGRlIHJldGVuY2nDs24gZWRpdGFkbyBtYW51YWxtZW50ZTsgZXZpdGEgcXVlIGVsIHByZXZpZXcgbG8gc29icmVzY3JpYmEgKi9cbiAgICByZXRlbnRpb25fdmFsdWVfb3ZlcnJpZGRlbj86IGJvb2xlYW47XG5cbiAgICAvLyBFc3RhZG9zIFRyaWFuZ3VsYXJlcyBwYXJhIGxhIFVJXG4gICAgdWlfYWNjb3VudF9jb2RlOiBzdHJpbmc7XG4gICAgdWlfYmFua19jb2RlOiBzdHJpbmc7XG4gICAgdWlfY2hlY2tfc2VhcmNoOiBzdHJpbmc7XG4gICAgLyoqIFNvbG8gVUk6IGVtaXNvciBkZWwgY2hlcXVlIChDSFIpLCBwYXJhIG1vc3RyYXIgZW4gbGEgZmlsYSAqL1xuICAgIHVpX3JlY2VpdmVkX2hvbGRlcj86IHN0cmluZztcbiAgICAvKiogU29sbyBVSTogQ1VJVCBkZWwgZW1pc29yIChDSFIpLCBwYXJhIG1vc3RyYXIgZW4gbGEgZmlsYSAqL1xuICAgIHVpX3JlY2VpdmVkX2N1aXQ/OiBzdHJpbmc7XG4gICAgdWlfcmVjZWl2ZWRfcmVmZXJlbmNlPzogc3RyaW5nO1xufTtcblxuZnVuY3Rpb24gaXNHYW5hbmNpYXNSZXRlbnRpb25JdGVtKGl0ZW06IFBpY2s8Rm9ybVBheW1lbnRPcmRlckl0ZW0sICdwYXltZW50X21ldGhvZF9jb2RlJyB8ICdpc19zeXN0ZW1fZ2VuZXJhdGVkJyB8ICdzeXN0ZW1fdHlwZSc+KTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgKEJvb2xlYW4oaXRlbS5pc19zeXN0ZW1fZ2VuZXJhdGVkKSAmJiBpdGVtLnN5c3RlbV90eXBlID09PSAnZ2FuYW5jaWFzX3JldGVudGlvbicpIHx8XG4gICAgICAgIGl0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gUEFZTUVOVF9NRVRIT0RfUkVURU5USU9OX0dBTkFOQ0lBU1xuICAgICk7XG59XG5cbmZ1bmN0aW9uIGlzVmVuZG9yUmV0ZW50aW9uSXRlbShpdGVtOiBQaWNrPEZvcm1QYXltZW50T3JkZXJJdGVtLCAncGF5bWVudF9tZXRob2RfY29kZScgfCAnaXNfc3lzdGVtX2dlbmVyYXRlZCcgfCAnc3lzdGVtX3R5cGUnPik6IGJvb2xlYW4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIChCb29sZWFuKGl0ZW0uaXNfc3lzdGVtX2dlbmVyYXRlZCkgJiYgaXRlbS5zeXN0ZW1fdHlwZSA9PT0gJ3ZlbmRvcl9yZXRlbnRpb24nKSB8fFxuICAgICAgICBpc1ZlbmRvckR5bmFtaWNSZXRlbnRpb25QYXltZW50Q29kZShpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUpXG4gICAgKTtcbn1cblxuLyoqIFJldGVuY2nDs24gYXV0b23DoXRpY2EgKEdhbmFuY2lhcyBvIFJFVF88dGF4SWQ+KTogY2FtcG9zIGJsb3F1ZWFkb3Mgc2Fsdm8gaW1wb3J0ZS4gKi9cbmZ1bmN0aW9uIGlzU3lzdGVtUmV0ZW50aW9uUGF5bWVudFJvdyhpdGVtOiBQaWNrPEZvcm1QYXltZW50T3JkZXJJdGVtLCAncGF5bWVudF9tZXRob2RfY29kZScgfCAnaXNfc3lzdGVtX2dlbmVyYXRlZCcgfCAnc3lzdGVtX3R5cGUnPik6IGJvb2xlYW4ge1xuICAgIHJldHVybiBpc0dhbmFuY2lhc1JldGVudGlvbkl0ZW0oaXRlbSkgfHwgaXNWZW5kb3JSZXRlbnRpb25JdGVtKGl0ZW0pO1xufVxuXG5mdW5jdGlvbiB2ZW5kb3JSZXRlbnRpb25TZWxlY3RMYWJlbChpdGVtOiBGb3JtUGF5bWVudE9yZGVySXRlbSk6IHN0cmluZyB7XG4gICAgY29uc3QgbiA9IGl0ZW0ucmV0ZW50aW9uX3RheF9uYW1lPy50cmltKCk7XG4gICAgcmV0dXJuIG4gPyBgUmV0ZW5jacOzbiAke259YCA6ICdSZXRlbmNpw7NuJztcbn1cblxuZXhwb3J0IGNvbnN0IE9yZGVuZXNQYWdvRm9ybVBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBtb2RlID0gaWQgPyAnZWRpdCcgOiAnY3JlYXRlJztcblxuICAgIGNvbnN0IHsgaXRlbTogaW5pdGlhbERhdGEsIGxvYWRpbmc6IGxvYWRpbmdJbml0aWFsLCBzYXZlSXRlbSwgbG9hZGluZzogc2F2aW5nIH0gPVxuICAgICAgICB1c2VDcnVkSXRlbTxQYXltZW50T3JkZXI+KG9yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgeyBzaG93Q29uZmlybWF0aW9uTW9kYWwgfSA9IHVzZU1vZGFsKCk7XG5cbiAgICAvLyAtLS0gRVNUQURPUyBQUklOQ0lQQUxFUyAtLS1cbiAgICBjb25zdCBbaGVhZGVyRGF0YSwgc2V0SGVhZGVyRGF0YV0gPSB1c2VTdGF0ZSh7XG4gICAgICAgIHBheW1lbnRfZGF0ZTogZm9ybWF0RGF0ZUZvcklucHV0KG5ldyBEYXRlKCkpLFxuICAgICAgICB2ZW5kb3JfaWQ6IG51bGwgYXMgbnVtYmVyIHwgbnVsbCxcbiAgICAgICAgdmVuZG9yX25hbWU6ICcnLFxuICAgICAgICBkaXNjb3VudDogMCxcbiAgICB9KTtcblxuICAgIC8vIOKchSBQQVRSw5NOOiBFc3RhZG8gcGFyYSBlbCBpbnB1dCBkZSB0ZXh0byBkZWwgUHJvdmVlZG9yXG4gICAgY29uc3QgW3ZlbmRvckNvZGVJbnB1dCwgc2V0VmVuZG9yQ29kZUlucHV0XSA9IHVzZVN0YXRlKCcnKTtcblxuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8Rm9ybVBheW1lbnRPcmRlckl0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFt2ZW5kb3JUYXhlcywgc2V0VmVuZG9yVGF4ZXNdID0gdXNlU3RhdGU8VmVuZG9yVGF4W10+KFtdKTtcbiAgICBjb25zdCBbdmVuZG9yUmV0ZW50aW9uSW5mbywgc2V0VmVuZG9yUmV0ZW50aW9uSW5mb10gPSB1c2VTdGF0ZTxWZW5kb3JSZXRlbnRpb25JbmZvIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBbcGVuZGluZ1B1cmNoYXNlcywgc2V0UGVuZGluZ1B1cmNoYXNlc10gPSB1c2VTdGF0ZTxQdXJjaGFzZVtdPihbXSk7XG4gICAgY29uc3QgW3BlbmRpbmdGaW5hbmNpYWxOb3Rlcywgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzXSA9IHVzZVN0YXRlPFB1cmNoYXNlRmluYW5jaWFsTm90ZVtdPihbXSk7XG4gICAgY29uc3QgW2lzTG9hZGluZ1B1cmNoYXNlcywgc2V0SXNMb2FkaW5nUHVyY2hhc2VzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYXBwbGllZEFtb3VudHMsIHNldEFwcGxpZWRBbW91bnRzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIG51bWJlciB8IHN0cmluZz4+KHt9KTtcbiAgICBjb25zdCBbYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzLCBzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPj4oe30pO1xuICAgIGNvbnN0IFt2ZW5kb3JBZHZhbmNlQmFsYW5jZSwgc2V0VmVuZG9yQWR2YW5jZUJhbGFuY2VdID0gdXNlU3RhdGUoMCk7XG5cbiAgICBjb25zdCBbZ2FuYW5jaWFzUmV0ZW50aW9uLCBzZXRHYW5hbmNpYXNSZXRlbnRpb25dID0gdXNlU3RhdGU8e1xuICAgICAgICBhbW91bnQ6IG51bWJlcjtcbiAgICAgICAgdGF4X2lkOiBudW1iZXI7XG4gICAgICAgIHZlbmRvcl9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICAgICAgY2FzZV9jb2RlPzogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgLyoqIEJhc2UgaW1wb25pYmxlIGRldnVlbHRhIHBvciBwcmV2aWV3IC8gcGVyc2lzdGlkYSBlbiBlbCDDrXRlbSBSRVRfR0FOLiAqL1xuICAgICAgICB2YWx1ZV9iYXNlPzogbnVtYmVyIHwgbnVsbDtcbiAgICB9IHwgbnVsbD4obnVsbCk7XG5cbiAgICAvKiogUHJldmlldyBwb3IgdGF4X2lkIHBhcmEgcmV0ZW5jaW9uZXMgYWRpY2lvbmFsZXMgKHR5cGU9MyksIGV4Y2wuIEdhbmFuY2lhcy4gKi9cbiAgICBjb25zdCBbdmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcsIHNldFZlbmRvclJldGVudGlvbnNQcmV2aWV3XSA9IHVzZVN0YXRlPFxuICAgICAgICBSZWNvcmQ8bnVtYmVyLCB7IGFtb3VudDogbnVtYmVyOyB0YXhfaWQ6IG51bWJlcjsgdGF4X25hbWU6IHN0cmluZzsgdmFsdWVfYmFzZT86IG51bWJlciB8IG51bGwgfSB8IG51bGw+XG4gICAgPih7fSk7XG5cbiAgICAvLyAtLS0gRVNUQURPUyBERSBVSSAtLS1cbiAgICBjb25zdCBbaXNNb2RhbE9wZW4sIHNldElzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZWRpdGluZ1RhcmdldCwgc2V0RWRpdGluZ1RhcmdldF0gPSB1c2VTdGF0ZTxFZGl0aW5nVGFyZ2V0IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW21vZGFsQ29uZmlnLCBzZXRNb2RhbENvbmZpZ10gPSB1c2VTdGF0ZTxhbnk+KG51bGwpO1xuXG4gICAgLy8gLS0tIEVGRUNUTyBERSBDQVJHQSBJTklDSUFMIChFRElUKSAtLS1cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobW9kZSA9PT0gJ2VkaXQnICYmIGluaXRpYWxEYXRhKSB7XG4gICAgICAgICAgICBzZXRIZWFkZXJEYXRhKHtcbiAgICAgICAgICAgICAgICBwYXltZW50X2RhdGU6IGZvcm1hdERhdGVGb3JJbnB1dChuZXcgRGF0ZShpbml0aWFsRGF0YS5wYXltZW50X2RhdGUpKSxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGluaXRpYWxEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfbmFtZTogaW5pdGlhbERhdGEudmVuZG9yPy5uYW1lIHx8ICcnLFxuICAgICAgICAgICAgICAgIGRpc2NvdW50OiBpbml0aWFsRGF0YS5kaXNjb3VudCB8fCAwLFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIOKchSBQQVRSw5NOOiBJbmljaWFsaXphciBjw7NkaWdvIGRlIHByb3ZlZWRvciAoYXN1bWllbmRvICdjdWl0JyBvICdjb2RlJylcbiAgICAgICAgICAgIGlmIChpbml0aWFsRGF0YS52ZW5kb3IpIHtcbiAgICAgICAgICAgICAgICBzZXRWZW5kb3JDb2RlSW5wdXQoaW5pdGlhbERhdGEudmVuZG9yLnZlbmRvcl9jb2RlIHx8IFN0cmluZyhpbml0aWFsRGF0YS52ZW5kb3JfaWQpKTtcbiAgICAgICAgICAgICAgICBzZXRWZW5kb3JBZHZhbmNlQmFsYW5jZSgoTnVtYmVyKGluaXRpYWxEYXRhLnZlbmRvci5hZHZhbmNlX2JhbGFuY2UpIHx8IDApICogLTEpO1xuICAgICAgICAgICAgICAgIHNldFZlbmRvclJldGVudGlvbkluZm8oe1xuICAgICAgICAgICAgICAgICAgICBkb19ub3RfcmV0YWluOiBCb29sZWFuKGluaXRpYWxEYXRhLnZlbmRvci5kb19ub3RfcmV0YWluKSxcbiAgICAgICAgICAgICAgICAgICAgdmVuZG9yX3R5cGU6IGluaXRpYWxEYXRhLnZlbmRvci52ZW5kb3JfdHlwZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyDinIUgUEFUUsOTTjogSW5pY2lhbGl6YXIgY8OzZGlnb3MgdmlzdWFsZXMgZW4gbG9zIGl0ZW1zOyBSRVRfR0FOIGRlbCBBUEkgc2UgbWFyY2EgY29tbyBmaWxhIGRlIHNpc3RlbWEgKGV2aXRhIGR1cGxpY2FyIHN5bmMgeSBzZWxlY3Qgc2luIG9wY2nDs24pXG4gICAgICAgICAgICBjb25zdCBtYXBwZWRJdGVtcyA9IGluaXRpYWxEYXRhLml0ZW1zPy5tYXAoaSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3SXRlbTogRm9ybVBheW1lbnRPcmRlckl0ZW0gPSB7XG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRfbWV0aG9kX2NvZGU6IGkucGF5bWVudF9tZXRob2RfY29kZSxcbiAgICAgICAgICAgICAgICAgICAgYmFua19pZDogaS5iYW5rX2lkLFxuICAgICAgICAgICAgICAgICAgICBiYW5rX25hbWU6IGkuYmFua19uYW1lLFxuICAgICAgICAgICAgICAgICAgICBiYW5rX2NvZGU6IGkuYmFua19jb2RlLFxuICAgICAgICAgICAgICAgICAgICBjaGVja19udW1iZXI6IGkuY2hlY2tfbnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICBjaGVja19kYXRlOiBpLmNoZWNrX2RhdGUsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBOdW1iZXIoaS52YWx1ZSkgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tfa2V5OiBpLmNoZWNrX2tleSxcbiAgICAgICAgICAgICAgICAgICAgY2hhcnRfYWNjb3VudDogaS5jaGFydF9hY2NvdW50LFxuICAgICAgICAgICAgICAgICAgICByZWNlaXZlZF9jaGVja19pZDogaS5yZWNlaXZlZF9jaGVja19pZCxcbiAgICAgICAgICAgICAgICAgICAgcmVjZWl2ZWRfY2hlY2s6IGkucmVjZWl2ZWRfY2hlY2sgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICBpZDogaS5pZCxcbiAgICAgICAgICAgICAgICAgICAgLi4uKGkudmFsdWVfYmFzZSAhPSBudWxsICYmICFOdW1iZXIuaXNOYU4oTnVtYmVyKGkudmFsdWVfYmFzZSkpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHsgdmFsdWVfYmFzZTogTnVtYmVyKGkudmFsdWVfYmFzZSkgfVxuICAgICAgICAgICAgICAgICAgICAgICAgOiB7fSksXG5cbiAgICAgICAgICAgICAgICAgICAgdWlfYWNjb3VudF9jb2RlOiBpLmNoYXJ0X2FjY291bnQ/LmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHVpX2JhbmtfY29kZTogaS5iYW5rX2NvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHVpX2NoZWNrX3NlYXJjaDogaS5jaGVja19udW1iZXIgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHVpX3JlY2VpdmVkX2hvbGRlcjogaS5yZWNlaXZlZF9jaGVjaz8uY2hlY2tfaG9sZGVyID8/ICcnLFxuICAgICAgICAgICAgICAgICAgICB1aV9yZWNlaXZlZF9jdWl0OiBpLnJlY2VpdmVkX2NoZWNrPy5pc3N1ZXJfY3VpdCA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgdWlfcmVjZWl2ZWRfcmVmZXJlbmNlOiBpLnJlY2VpdmVkX2NoZWNrPy5yZWZlcmVuY2VfbnVtYmVyID8/ICcnLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgaWYgKGkuYmFuaykge1xuICAgICAgICAgICAgICAgICAgICBuZXdJdGVtLmJhbmtfbmFtZSA9IGkuYmFuay5uYW1lO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoaS5wYXltZW50X21ldGhvZF9jb2RlID09PSBQQVlNRU5UX01FVEhPRF9SRVRFTlRJT05fR0FOQU5DSUFTKSB7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0uaXNfc3lzdGVtX2dlbmVyYXRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0uc3lzdGVtX3R5cGUgPSAnZ2FuYW5jaWFzX3JldGVudGlvbic7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0ucmV0ZW50aW9uX3ZhbHVlX292ZXJyaWRkZW4gPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCB2ZW5kb3JSZXRUYXhJZCA9IHBhcnNlVGF4SWRGcm9tVmVuZG9yUmV0ZW50aW9uQ29kZShpLnBheW1lbnRfbWV0aG9kX2NvZGUpO1xuICAgICAgICAgICAgICAgIGlmICh2ZW5kb3JSZXRUYXhJZCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0uaXNfc3lzdGVtX2dlbmVyYXRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0uc3lzdGVtX3R5cGUgPSAndmVuZG9yX3JldGVudGlvbic7XG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0ucmV0ZW50aW9uX3RheF9pZCA9IHZlbmRvclJldFRheElkO1xuICAgICAgICAgICAgICAgICAgICBuZXdJdGVtLnJldGVudGlvbl92YWx1ZV9vdmVycmlkZGVuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWF0Y2hUYXggPSBpbml0aWFsRGF0YS5hcHBsaWVkX3RheGVzPy5maW5kKHQgPT4gdC50YXhfaWQgPT09IHZlbmRvclJldFRheElkKTtcbiAgICAgICAgICAgICAgICAgICAgbmV3SXRlbS5yZXRlbnRpb25fdGF4X25hbWUgPSBtYXRjaFRheD8udGF4X25hbWUgPz8gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3SXRlbTtcbiAgICAgICAgICAgIH0pIHx8IFtdO1xuICAgICAgICAgICAgbGV0IHJldFJvd1NlZW4gPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IHNlZW5WZW5kb3JSZXRlbnRpb25UYXhJZHMgPSBuZXcgU2V0PG51bWJlcj4oKTtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW1zRmlsdGVyZWQgPSBtYXBwZWRJdGVtcy5maWx0ZXIoaXQgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChpdC5wYXltZW50X21ldGhvZF9jb2RlID09PSBQQVlNRU5UX01FVEhPRF9SRVRFTlRJT05fR0FOQU5DSUFTKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXRSb3dTZWVuKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHJldFJvd1NlZW4gPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgdnRpZCA9IHBhcnNlVGF4SWRGcm9tVmVuZG9yUmV0ZW50aW9uQ29kZShpdC5wYXltZW50X21ldGhvZF9jb2RlKTtcbiAgICAgICAgICAgICAgICBpZiAodnRpZCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWVuVmVuZG9yUmV0ZW50aW9uVGF4SWRzLmhhcyh2dGlkKSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICBzZWVuVmVuZG9yUmV0ZW50aW9uVGF4SWRzLmFkZCh2dGlkKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhpdGVtc0ZpbHRlcmVkKTtcblxuICAgICAgICAgICAgY29uc3QgcmV0SXRQZXJzaXN0ZWQgPSBpdGVtc0ZpbHRlcmVkLmZpbmQoaSA9PiBpLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09IFBBWU1FTlRfTUVUSE9EX1JFVEVOVElPTl9HQU5BTkNJQVMpO1xuICAgICAgICAgICAgY29uc3QgcGVyc2lzdGVkUmV0ZW50aW9uVmFsdWVCYXNlID1cbiAgICAgICAgICAgICAgICByZXRJdFBlcnNpc3RlZCAhPSBudWxsICYmXG4gICAgICAgICAgICAgICAgICAgIHJldEl0UGVyc2lzdGVkLnZhbHVlX2Jhc2UgIT0gbnVsbCAmJlxuICAgICAgICAgICAgICAgICAgICAhTnVtYmVyLmlzTmFOKE51bWJlcihyZXRJdFBlcnNpc3RlZC52YWx1ZV9iYXNlKSlcbiAgICAgICAgICAgICAgICAgICAgPyBOdW1iZXIocmV0SXRQZXJzaXN0ZWQudmFsdWVfYmFzZSlcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG5cbiAgICAgICAgICAgIGNvbnN0IGdhblRheCA9IGluaXRpYWxEYXRhLmFwcGxpZWRfdGF4ZXM/LmZpbmQoXG4gICAgICAgICAgICAgICAgdCA9PiB0LnRheF9pZCA9PT0gR0FOQU5DSUFTX1RBWF9JRCB8fCAodC50YXhfbmFtZSAmJiB0LnRheF9uYW1lLmluY2x1ZGVzKCdHYW5hbmNpYXMnKSlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoZ2FuVGF4ICYmIE51bWJlcihnYW5UYXguYW1vdW50KSA+IDApIHtcbiAgICAgICAgICAgICAgICBzZXRHYW5hbmNpYXNSZXRlbnRpb24oe1xuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihnYW5UYXguYW1vdW50KSxcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiBnYW5UYXgudGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGluaXRpYWxEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgICAgICAgICAgICAgY2FzZV9jb2RlOiBpbml0aWFsRGF0YS52ZW5kb3I/LnZlbmRvcl90eXBlID8/IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIC4uLihwZXJzaXN0ZWRSZXRlbnRpb25WYWx1ZUJhc2UgIT09IHVuZGVmaW5lZCA/IHsgdmFsdWVfYmFzZTogcGVyc2lzdGVkUmV0ZW50aW9uVmFsdWVCYXNlIH0gOiB7fSksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJldEl0ID0gcmV0SXRQZXJzaXN0ZWQ7XG4gICAgICAgICAgICAgICAgaWYgKHJldEl0ICYmIE51bWJlcihyZXRJdC52YWx1ZSkgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEdhbmFuY2lhc1JldGVudGlvbih7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihyZXRJdC52YWx1ZSksXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXhfaWQ6IEdBTkFOQ0lBU19UQVhfSUQsXG4gICAgICAgICAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGluaXRpYWxEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2VfY29kZTogaW5pdGlhbERhdGEudmVuZG9yPy52ZW5kb3JfdHlwZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uKHBlcnNpc3RlZFJldGVudGlvblZhbHVlQmFzZSAhPT0gdW5kZWZpbmVkID8geyB2YWx1ZV9iYXNlOiBwZXJzaXN0ZWRSZXRlbnRpb25WYWx1ZUJhc2UgfSA6IHt9KSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0R2FuYW5jaWFzUmV0ZW50aW9uKG51bGwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgaW5pdGlhbFZlbmRvclJldFByZXZpZXc6IFJlY29yZDxcbiAgICAgICAgICAgICAgICBudW1iZXIsXG4gICAgICAgICAgICAgICAgeyBhbW91bnQ6IG51bWJlcjsgdGF4X2lkOiBudW1iZXI7IHRheF9uYW1lOiBzdHJpbmc7IHZhbHVlX2Jhc2U/OiBudW1iZXIgfCBudWxsIH0gfCBudWxsXG4gICAgICAgICAgICA+ID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGl0IG9mIGl0ZW1zRmlsdGVyZWQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0aWQgPSBwYXJzZVRheElkRnJvbVZlbmRvclJldGVudGlvbkNvZGUoaXQucGF5bWVudF9tZXRob2RfY29kZSk7XG4gICAgICAgICAgICAgICAgaWYgKHRpZCA9PSBudWxsKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjb25zdCBhdCA9IGluaXRpYWxEYXRhLmFwcGxpZWRfdGF4ZXM/LmZpbmQodCA9PiB0LnRheF9pZCA9PT0gdGlkKTtcbiAgICAgICAgICAgICAgICBjb25zdCBwZXJzaXN0ZWRWYiA9XG4gICAgICAgICAgICAgICAgICAgIGl0LnZhbHVlX2Jhc2UgIT0gbnVsbCAmJiAhTnVtYmVyLmlzTmFOKE51bWJlcihpdC52YWx1ZV9iYXNlKSkgPyBOdW1iZXIoaXQudmFsdWVfYmFzZSkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgaW5pdGlhbFZlbmRvclJldFByZXZpZXdbdGlkXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB0aWQsXG4gICAgICAgICAgICAgICAgICAgIHRheF9uYW1lOiAoYXQ/LnRheF9uYW1lID8/IGl0LnJldGVudGlvbl90YXhfbmFtZSkgfHwgJ1JldGVuY2nDs24nLFxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihhdD8uYW1vdW50KSB8fCBOdW1iZXIoaXQudmFsdWUpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgIC4uLihwZXJzaXN0ZWRWYiAhPT0gdW5kZWZpbmVkID8geyB2YWx1ZV9iYXNlOiBwZXJzaXN0ZWRWYiB9IDoge30pLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRWZW5kb3JSZXRlbnRpb25zUHJldmlldyhpbml0aWFsVmVuZG9yUmV0UHJldmlldyk7XG5cbiAgICAgICAgICAgIGNvbnN0IGxvYWRWZW5kb3JUYXhlcyA9IGFzeW5jICh2ZW5kb3JJZDogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZnVsbFZlbmRvciA9IGF3YWl0IGdldEJ5SWQ8VmVuZG9yV2l0aFRheGVzICYgeyBhZHZhbmNlX2JhbGFuY2U/OiBudW1iZXIgfT4oJ3ZlbmRvcnMnLCB2ZW5kb3JJZCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFZlbmRvclRheGVzKGZ1bGxWZW5kb3IudGF4ZXMgfHwgW10pO1xuICAgICAgICAgICAgICAgICAgICBzZXRWZW5kb3JBZHZhbmNlQmFsYW5jZSgoTnVtYmVyKGZ1bGxWZW5kb3IuYWR2YW5jZV9iYWxhbmNlKSB8fCAwKSAqIC0xKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uSW5mbyh7XG4gICAgICAgICAgICAgICAgICAgICAgICBkb19ub3RfcmV0YWluOiBCb29sZWFuKGZ1bGxWZW5kb3IuZG9fbm90X3JldGFpbiksXG4gICAgICAgICAgICAgICAgICAgICAgICB2ZW5kb3JfdHlwZTogZnVsbFZlbmRvci52ZW5kb3JfdHlwZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIHsgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgaW1wdWVzdG9zIGRlbCBwcm92ZWVkb3IuXCIpOyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaW5pdGlhbERhdGEudmVuZG9yX2lkKSB7XG4gICAgICAgICAgICAgICAgbG9hZFZlbmRvclRheGVzKGluaXRpYWxEYXRhLnZlbmRvcl9pZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IGxvYWRFZGl0RGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWluaXRpYWxEYXRhLnZlbmRvcl9pZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHNldElzTG9hZGluZ1B1cmNoYXNlcyh0cnVlKTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHsgdmVuZG9yX2lkOiBpbml0aWFsRGF0YS52ZW5kb3JfaWQudG9TdHJpbmcoKSwgaGFzX2JhbGFuY2U6ICd0cnVlJyB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuZGluZ1Jlc3BvbnNlUHJvbWlzZSA9IHNlYXJjaDxQdXJjaGFzZT4oYHB1cmNoYXNlcz8ke3BhcmFtcy50b1N0cmluZygpfWApO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nTm90ZXNQcm9taXNlID0gc2VhcmNoPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4oYHB1cmNoYXNlLWZpbmFuY2lhbC1ub3Rlcz8ke3BhcmFtcy50b1N0cmluZygpfWApO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBhcHBsaWVkUHVyY2hhc2VJZHMgPSBpbml0aWFsRGF0YS5hcHBsaWVkX3B1cmNoYXNlcz8ubWFwKGFwID0+IGFwLnB1cmNoYXNlLmlkKSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZFB1cmNoYXNlc1Byb21pc2VzID0gYXBwbGllZFB1cmNoYXNlSWRzLm1hcChpZCA9PiBnZXRCeUlkPFB1cmNoYXNlPigncHVyY2hhc2VzJywgaWQpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZE5vdGVJZHMgPSBpbml0aWFsRGF0YS5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcz8ubWFwKGFuID0+IGFuLnB1cmNoYXNlX2ZpbmFuY2lhbF9ub3RlLmlkKSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZE5vdGVzUHJvbWlzZXMgPSBhcHBsaWVkTm90ZUlkcy5tYXAobm90ZUlkID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkPFB1cmNoYXNlRmluYW5jaWFsTm90ZT4oJ3B1cmNoYXNlLWZpbmFuY2lhbC1ub3RlcycsIG5vdGVJZClcbiAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBbcGVuZGluZ1Jlc3BvbnNlLCBwZW5kaW5nTm90ZXNSZXNwb25zZSwgLi4uZmV0Y2hlZEFwcGxpZWRdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ1Jlc3BvbnNlUHJvbWlzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdOb3Rlc1Byb21pc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5hcHBsaWVkUHVyY2hhc2VzUHJvbWlzZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5hcHBsaWVkTm90ZXNQcm9taXNlcyxcbiAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZldGNoZWRBcHBsaWVkUHVyY2hhc2VzID0gZmV0Y2hlZEFwcGxpZWQuc2xpY2UoMCwgYXBwbGllZFB1cmNoYXNlc1Byb21pc2VzLmxlbmd0aCkgYXMgUHVyY2hhc2VbXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmV0Y2hlZEFwcGxpZWROb3RlcyA9IGZldGNoZWRBcHBsaWVkLnNsaWNlKGFwcGxpZWRQdXJjaGFzZXNQcm9taXNlcy5sZW5ndGgpIGFzIFB1cmNoYXNlRmluYW5jaWFsTm90ZVtdO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbFB1cmNoYXNlc01hcCA9IG5ldyBNYXA8bnVtYmVyLCBQdXJjaGFzZT4oKTtcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hlZEFwcGxpZWRQdXJjaGFzZXMuZm9yRWFjaChwID0+IHsgaWYgKHApIGFsbFB1cmNoYXNlc01hcC5zZXQocC5pZCwgcCk7IH0pO1xuICAgICAgICAgICAgICAgICAgICBwZW5kaW5nUmVzcG9uc2UuZGF0YS5mb3JFYWNoKHAgPT4geyBpZiAoIWFsbFB1cmNoYXNlc01hcC5oYXMocC5pZCkpIGFsbFB1cmNoYXNlc01hcC5zZXQocC5pZCwgcCk7IH0pO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbmFsUHVyY2hhc2VzID0gQXJyYXkuZnJvbShhbGxQdXJjaGFzZXNNYXAudmFsdWVzKCkpLm1hcChwID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFwcGxpZWREZXRhaWwgPSBpbml0aWFsRGF0YS5hcHBsaWVkX3B1cmNoYXNlcz8uZmluZChhcCA9PiBhcC5wdXJjaGFzZS5pZCA9PT0gcC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXBwbGllZERldGFpbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsQmFsYW5jZSA9IChOdW1iZXIocC5iYWxhbmNlKSB8fCAwKSArIChOdW1iZXIoYXBwbGllZERldGFpbC5hbW91bnRfYXBwbGllZCkgfHwgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4ucCwgYmFsYW5jZTogb3JpZ2luYWxCYWxhbmNlIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcDtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHNldFBlbmRpbmdQdXJjaGFzZXMoZmluYWxQdXJjaGFzZXMpO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbE5vdGVzTWFwID0gbmV3IE1hcDxudW1iZXIsIFB1cmNoYXNlRmluYW5jaWFsTm90ZT4oKTtcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hlZEFwcGxpZWROb3Rlcy5mb3JFYWNoKG4gPT4geyBpZiAobikgYWxsTm90ZXNNYXAuc2V0KG4uaWQsIG4pOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ05vdGVzUmVzcG9uc2UuZGF0YS5mb3JFYWNoKG4gPT4geyBpZiAoIWFsbE5vdGVzTWFwLmhhcyhuLmlkKSkgYWxsTm90ZXNNYXAuc2V0KG4uaWQsIG4pOyB9KTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaW5hbE5vdGVzID0gQXJyYXkuZnJvbShhbGxOb3Rlc01hcC52YWx1ZXMoKSkubWFwKG4gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZERldGFpbCA9IGluaXRpYWxEYXRhLmFwcGxpZWRfZmluYW5jaWFsX25vdGVzPy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuID0+IGFuLnB1cmNoYXNlX2ZpbmFuY2lhbF9ub3RlLmlkID09PSBuLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFwcGxpZWREZXRhaWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50QmFsYW5jZSA9IHNpZ25lZE5vdGVCYWxhbmNlKG4pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsQmFsYW5jZSA9IGN1cnJlbnRCYWxhbmNlICsgKE51bWJlcihhcHBsaWVkRGV0YWlsLmFtb3VudF9hcHBsaWVkKSB8fCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5uLCBiYWxhbmNlOiBvcmlnaW5hbEJhbGFuY2UgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzKGZpbmFsTm90ZXMpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChpbml0aWFsRGF0YS5hcHBsaWVkX3B1cmNoYXNlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5pdGlhbEFtb3VudHMgPSBpbml0aWFsRGF0YS5hcHBsaWVkX3B1cmNoYXNlcy5yZWR1Y2UoKGFjYywgYXApID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NbYXAucHVyY2hhc2UuaWRdID0gTnVtYmVyKGFwLmFtb3VudF9hcHBsaWVkKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2M7XG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7fSBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXIgfCBzdHJpbmc+KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRBbW91bnRzKGluaXRpYWxBbW91bnRzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChpbml0aWFsRGF0YS5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5pdGlhbE5vdGVBbW91bnRzID0gaW5pdGlhbERhdGEuYXBwbGllZF9maW5hbmNpYWxfbm90ZXMucmVkdWNlKChhY2MsIGFuKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjW2FuLnB1cmNoYXNlX2ZpbmFuY2lhbF9ub3RlLmlkXSA9IE51bWJlcihhbi5hbW91bnRfYXBwbGllZCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMoaW5pdGlhbE5vdGVBbW91bnRzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRpZXJvbiBjYXJnYXIgbGFzIGZhY3R1cmFzIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzTG9hZGluZ1B1cmNoYXNlcyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGxvYWRFZGl0RGF0YSgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1vZGUgPT09ICdjcmVhdGUnKSB7XG4gICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgICAgICBzZXRWZW5kb3JSZXRlbnRpb25JbmZvKG51bGwpO1xuICAgICAgICAgICAgc2V0R2FuYW5jaWFzUmV0ZW50aW9uKG51bGwpO1xuICAgICAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcoe30pO1xuICAgICAgICAgICAgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzKFtdKTtcbiAgICAgICAgICAgIHNldEFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyh7fSk7XG4gICAgICAgIH1cbiAgICB9LCBbbW9kZSwgaW5pdGlhbERhdGFdKTtcblxuICAgIC8vIC0tLSBIQU5ETEVSUyBERSBCw5pTUVVFREEgVFJJQU5HVUxBUiAoTUFHSUEgTlVFVkEg4pyoKSAtLS1cblxuICAgIC8vIDEuIEJ1c2NhZG9yIGRlIFByb3ZlZWRvciAoQ2FiZWNlcmEpXG4gICAgY29uc3QgaGFuZGxlVmVuZG9yQ29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCF2ZW5kb3JDb2RlSW5wdXQpIHJldHVybjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gQXN1bWllbmRvIGLDunNxdWVkYSBwb3IgQ1VJVCBvIENPREVcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxWZW5kb3JXaXRoVGF4ZXM+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBbeyBmaWVsZE5hbWU6ICd2ZW5kb3JfY29kZScsIHZhbHVlOiB2ZW5kb3JDb2RlSW5wdXQgfV0pO1xuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICAgICAgLy8gUmV1dGlsaXphbW9zIGxhIGzDs2dpY2EgZGUgc2VsZWNjacOzbiBjb21wbGV0YVxuICAgICAgICAgICAgICAgIGhhbmRsZVNlbGVjdFZlbmRvcihmb3VuZCk7XG4gICAgICAgICAgICAgICAgLy8gU2luY3Jvbml6YW1vcyBlbCBpbnB1dCB2aXN1YWxcbiAgICAgICAgICAgICAgICBzZXRWZW5kb3JDb2RlSW5wdXQoZm91bmQudmVuZG9yX2NvZGUgfHwgU3RyaW5nKGZvdW5kLmlkKSk7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnUHJvdmVlZG9yIGVuY29udHJhZG8uJyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oJ1Byb3ZlZWRvciBubyBlbmNvbnRyYWRvLicpO1xuICAgICAgICAgICAgICAgIC8vIExpbXBpYW1vcyBzaSBubyBlbmN1ZW50cmFcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJEYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgdmVuZG9yX2lkOiBudWxsLCB2ZW5kb3JfbmFtZTogJycsIGRpc2NvdW50OiAwIH0pKTtcbiAgICAgICAgICAgICAgICBzZXRQZW5kaW5nUHVyY2hhc2VzKFtdKTtcbiAgICAgICAgICAgICAgICBzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMoW10pO1xuICAgICAgICAgICAgICAgIHNldEFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyh7fSk7XG4gICAgICAgICAgICAgICAgc2V0VmVuZG9yVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIHNldFZlbmRvclJldGVudGlvbkluZm8obnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0R2FuYW5jaWFzUmV0ZW50aW9uKG51bGwpO1xuICAgICAgICAgICAgICAgIHNldFZlbmRvclJldGVudGlvbnNQcmV2aWV3KHt9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBidXNjYW5kbyBwcm92ZWVkb3IuJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gMi4gQnVzY2Fkb3IgR2Vuw6lyaWNvIHBhcmEgSXRlbXMgKEN1ZW50YSwgQmFuY28sIENoZXF1ZSBSZWNpYmlkbylcbiAgICBjb25zdCBoYW5kbGVJdGVtQ29kZVN1Ym1pdCA9IGFzeW5jICh0ZW1wSWQ6IHN0cmluZywgdHlwZTogJ2FjY291bnQnIHwgJ2JhbmsnIHwgJ3JlY2VpdmVkX2NoZWNrJykgPT4ge1xuICAgICAgICBjb25zdCBpdGVtSW5kZXggPSBpdGVtcy5maW5kSW5kZXgoaSA9PiBpLnRlbXBJZCA9PT0gdGVtcElkKTtcbiAgICAgICAgaWYgKGl0ZW1JbmRleCA9PT0gLTEpIHJldHVybjtcbiAgICAgICAgY29uc3QgaXRlbSA9IGl0ZW1zW2l0ZW1JbmRleF07XG5cbiAgICAgICAgbGV0IGNvbmZpZzogYW55ID0gbnVsbDtcbiAgICAgICAgbGV0IHNlYXJjaEZpZWxkID0gJ2NvZGUnO1xuICAgICAgICBsZXQgY29kZVZhbHVlID0gJyc7XG5cbiAgICAgICAgaWYgKHR5cGUgPT09ICdhY2NvdW50Jykge1xuICAgICAgICAgICAgY29uZmlnID0gcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZztcbiAgICAgICAgICAgIGNvZGVWYWx1ZSA9IGl0ZW0udWlfYWNjb3VudF9jb2RlO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdiYW5rJykge1xuICAgICAgICAgICAgY29uZmlnID0gYmFuY29zTW9kdWxlQ29uZmlnO1xuICAgICAgICAgICAgY29kZVZhbHVlID0gaXRlbS51aV9iYW5rX2NvZGU7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3JlY2VpdmVkX2NoZWNrJykge1xuICAgICAgICAgICAgY29uZmlnID0gdW5kZWxpdmVyZWRDaGVja3NDb25maWc7XG4gICAgICAgICAgICBzZWFyY2hGaWVsZCA9ICdjaGVja19udW1iZXInOyAvLyBMb3MgY2hlcXVlcyBzZSBidXNjYW4gcG9yIG7Dum1lcm9cbiAgICAgICAgICAgIGNvZGVWYWx1ZSA9IGl0ZW0udWlfY2hlY2tfc2VhcmNoO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFjb2RlVmFsdWUpIHJldHVybjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oY29uZmlnLmVuZHBvaW50LCBbeyBmaWVsZE5hbWU6IHNlYXJjaEZpZWxkLCB2YWx1ZTogY29kZVZhbHVlIH1dKTtcblxuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGUgPT09ICdhY2NvdW50Jykge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ2NoYXJ0X2FjY291bnQnLCBmb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAndWlfYWNjb3VudF9jb2RlJywgZm91bmQuY29kZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAnYmFuaycpIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdiYW5rX2lkJywgZm91bmQuaWQpO1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ2JhbmtfbmFtZScsIGZvdW5kLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ3VpX2JhbmtfY29kZScsIGZvdW5kLmNvZGUgfHwgU3RyaW5nKGZvdW5kLmlkKSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAncmVjZWl2ZWRfY2hlY2snKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEzDs2dpY2EgZXNwZWPDrWZpY2EgcGFyYSBsbGVuYXIgZGF0b3MgZGVsIGNoZXF1ZVxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ3JlY2VpdmVkX2NoZWNrX2lkJywgZm91bmQuaWQpO1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ3ZhbHVlJywgTnVtYmVyKGZvdW5kLnZhbHVlKSB8fCAwKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdiYW5rX2lkJywgZm91bmQuYmFua19pZCk7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAnYmFua19uYW1lJywgZm91bmQuYmFua19uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdjaGVja19udW1iZXInLCBmb3VuZC5jaGVja19udW1iZXIpO1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ2NoZWNrX2RhdGUnLCBmb3VuZC5jaGVja19kYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gU2luY3Jvbml6YXIgaW5wdXQgdmlzdWFsXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAndWlfY2hlY2tfc2VhcmNoJywgZm91bmQuY2hlY2tfbnVtYmVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oYCR7dHlwZSA9PT0gJ2FjY291bnQnID8gJ0N1ZW50YScgOiB0eXBlID09PSAnYmFuaycgPyAnQmFuY28nIDogJ0NoZXF1ZSd9IG5vIGVuY29udHJhZG8uYCk7XG4gICAgICAgICAgICAgICAgLy8gT3BjaW9uYWw6IExpbXBpYXIgZWwgY2FtcG8gcmVsYWNpb25hZG8gc2kgbm8gZW5jdWVudHJhXG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgZW4gbGEgYsO6c3F1ZWRhLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuXG4gICAgY29uc3QgdmVuZG9yR2VuZXJhbFRheGVzID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gKHZlbmRvclRheGVzIHx8IFtdKS5maWx0ZXIodCA9PiB0LnR5cGUgIT09IDMpLFxuICAgICAgICBbdmVuZG9yVGF4ZXNdXG4gICAgKTtcblxuICAgIGNvbnN0IHZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbCA9IHVzZU1lbW8oXG4gICAgICAgICgpID0+ICh2ZW5kb3JUYXhlcyB8fCBbXSkuZmlsdGVyKHQgPT4gdC50eXBlID09PSAzICYmIHQuaWQgIT09IEdBTkFOQ0lBU19UQVhfSUQpLFxuICAgICAgICBbdmVuZG9yVGF4ZXNdXG4gICAgKTtcblxuICAgIC8vIC0tLSBDw4FMQ1VMT1MgREVSSVZBRE9TIC0tLVxuICAgIGNvbnN0IHZhbGlkUHVyY2hhc2VJZHMgPSB1c2VNZW1vKCgpID0+IHBlbmRpbmdQdXJjaGFzZXMubWFwKHAgPT4gcC5pZCksIFtwZW5kaW5nUHVyY2hhc2VzXSk7XG5cbiAgICBjb25zdCByZXRlbnRpb25BcHBsaWVkUHVyY2hhc2VzID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gYnVpbGRBcHBsaWVkUHVyY2hhc2VzRm9yUmV0ZW50aW9uUHJldmlldyhhcHBsaWVkQW1vdW50cyksXG4gICAgICAgIFthcHBsaWVkQW1vdW50c11cbiAgICApO1xuXG4gICAgY29uc3Qgc2hvd1JldGVudGlvbkFtb3VudEhpbnQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFzR2FuYW5jaWFzID1cbiAgICAgICAgICAgIEJvb2xlYW4odmVuZG9yUmV0ZW50aW9uSW5mbz8uZG9fbm90X3JldGFpbikgJiYgQm9vbGVhbih2ZW5kb3JSZXRlbnRpb25JbmZvPy52ZW5kb3JfdHlwZSk7XG4gICAgICAgIGNvbnN0IGhhc0FkZGl0aW9uYWwgPSB2ZW5kb3JSZXRlbnRpb25UYXhlc0FkZGl0aW9uYWwubGVuZ3RoID4gMDtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIEJvb2xlYW4oaGVhZGVyRGF0YS52ZW5kb3JfaWQpICYmXG4gICAgICAgICAgICBwZW5kaW5nUHVyY2hhc2VzLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICAgIHJldGVudGlvbkFwcGxpZWRQdXJjaGFzZXMubGVuZ3RoID09PSAwICYmXG4gICAgICAgICAgICAoaGFzR2FuYW5jaWFzIHx8IGhhc0FkZGl0aW9uYWwpXG4gICAgICAgICk7XG4gICAgfSwgW1xuICAgICAgICBoZWFkZXJEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgcGVuZGluZ1B1cmNoYXNlcy5sZW5ndGgsXG4gICAgICAgIHJldGVudGlvbkFwcGxpZWRQdXJjaGFzZXMubGVuZ3RoLFxuICAgICAgICB2ZW5kb3JSZXRlbnRpb25JbmZvLFxuICAgICAgICB2ZW5kb3JSZXRlbnRpb25UYXhlc0FkZGl0aW9uYWwubGVuZ3RoLFxuICAgIF0pO1xuXG4gICAgY29uc3QgdG90YWxzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IGdyb3NzQW1vdW50ID0gY29tcHV0ZUdyb3NzQXBwbGllZEFtb3VudChhcHBsaWVkQW1vdW50cywgYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzKTtcbiAgICAgICAgY29uc3QgcHVyY2hhc2VzR3Jvc3NBbW91bnQgPSBzdW1BcHBsaWVkQW1vdW50c1JlY29yZChhcHBsaWVkQW1vdW50cyk7XG4gICAgICAgIGNvbnN0IGZpbmFuY2lhbE5vdGVzR3Jvc3NBbW91bnQgPSBzdW1BcHBsaWVkQW1vdW50c1JlY29yZChhcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMpO1xuICAgICAgICBjb25zdCBkaXNjb3VudCA9IGhlYWRlckRhdGEuZGlzY291bnQgfHwgMDtcblxuICAgICAgICBjb25zdCBjYWxjdWxhdGVkQXBwbGllZFRheGVzOiBBcHBsaWVkVGF4W10gPSBbXTtcbiAgICAgICAgaWYgKHZlbmRvckdlbmVyYWxUYXhlcyAmJiB2ZW5kb3JHZW5lcmFsVGF4ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdmVuZG9yR2VuZXJhbFRheGVzLmZvckVhY2godlRheCA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JpZ2luYWxUYXggPSBtb2RlID09PSAnZWRpdCcgPyBpbml0aWFsRGF0YT8uYXBwbGllZF90YXhlcz8uZmluZChhVGF4ID0+IGFUYXgudGF4X2lkID09PSB2VGF4LmlkKSA6IG51bGw7XG4gICAgICAgICAgICAgICAgY2FsY3VsYXRlZEFwcGxpZWRUYXhlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2VGF4LmlkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogdlRheC5uYW1lLFxuICAgICAgICAgICAgICAgICAgICByYXRlOiB2VGF4LnJhdGUsXG4gICAgICAgICAgICAgICAgICAgIGFtb3VudDogZGlzY291bnQgKiAodlRheC5yYXRlIC8gMTAwKSxcbiAgICAgICAgICAgICAgICAgICAgaWQ6IG9yaWdpbmFsVGF4Py5pZFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0b3RhbFRheGVzID0gY2FsY3VsYXRlZEFwcGxpZWRUYXhlcy5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyAoTnVtYmVyKHRheC5hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3QgbmV0QW1vdW50VG9QYXkgPSBncm9zc0Ftb3VudCAtIGRpc2NvdW50IC0gdG90YWxUYXhlcztcbiAgICAgICAgY29uc3QgdG90YWxQYWlkID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS52YWx1ZSkgfHwgMCksIDApO1xuICAgICAgICBjb25zdCByZW1haW5pbmdUb1BheSA9IE1hdGgucm91bmQoKG5ldEFtb3VudFRvUGF5IC0gdG90YWxQYWlkKSAqIDEwMCkgLyAxMDA7XG5cbiAgICAgICAgcmV0dXJuIHsgZ3Jvc3NBbW91bnQsIHB1cmNoYXNlc0dyb3NzQW1vdW50LCBmaW5hbmNpYWxOb3Rlc0dyb3NzQW1vdW50LCBkaXNjb3VudCwgYXBwbGllZFRheGVzOiBjYWxjdWxhdGVkQXBwbGllZFRheGVzLCB0b3RhbFRheGVzLCBuZXRBbW91bnRUb1BheSwgdG90YWxQYWlkLCByZW1haW5pbmdUb1BheSB9O1xuICAgIH0sIFthcHBsaWVkQW1vdW50cywgYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzLCBoZWFkZXJEYXRhLmRpc2NvdW50LCBpdGVtcywgdmVuZG9yR2VuZXJhbFRheGVzLCBtb2RlLCBpbml0aWFsRGF0YV0pO1xuXG4gICAgLy8gLS0tIFJFVEVOQ0nDk04gR0FOQU5DSUFTOiBDw4FMQ1VMTyBZIFNJTkNST05JWkFDScOTTiAtLS1cblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGxldCBpc0NhbmNlbGxlZCA9IGZhbHNlO1xuXG4gICAgICAgIGNvbnN0IHJlY2FsY3VsYXRlR2FuYW5jaWFzUmV0ZW50aW9uID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgLy8gTmV0byBkb2N1bWVudGFsIOKJiCAwIChjb21wcmEgKyBORiBjb21wZW5zYWRhcyk6IG5vIGdlbmVyYXIgcmV0ZW5jacOzbiBuaSBmaWxhcyBSRVRcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyhOdW1iZXIodG90YWxzLm5ldEFtb3VudFRvUGF5KSB8fCAwKSA8PSAwLjAxKSB7XG4gICAgICAgICAgICAgICAgc2V0R2FuYW5jaWFzUmV0ZW50aW9uKG51bGwpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaGVhZGVyRGF0YS52ZW5kb3JfaWQgfHwgIXZlbmRvclJldGVudGlvbkluZm8pIHtcbiAgICAgICAgICAgICAgICBzZXRHYW5hbmNpYXNSZXRlbnRpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCF2ZW5kb3JSZXRlbnRpb25JbmZvLmRvX25vdF9yZXRhaW4gfHwgIXZlbmRvclJldGVudGlvbkluZm8udmVuZG9yX3R5cGUpIHtcbiAgICAgICAgICAgICAgICBzZXRHYW5hbmNpYXNSZXRlbnRpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcHJldmlld1BheWxvYWQgPSBidWlsZEdhbmFuY2lhc1JldGVudGlvblByZXZpZXdSZXF1ZXN0KHtcbiAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGhlYWRlckRhdGEudmVuZG9yX2lkLFxuICAgICAgICAgICAgICAgIHBheW1lbnRfZGF0ZTogaGVhZGVyRGF0YS5wYXltZW50X2RhdGUsXG4gICAgICAgICAgICAgICAgYXBwbGllZEFtb3VudHMsXG4gICAgICAgICAgICAgICAgdmFsaWRQdXJjaGFzZUlkcyxcbiAgICAgICAgICAgICAgICBjYXNlX2NvZGU6IHZlbmRvclJldGVudGlvbkluZm8udmVuZG9yX3R5cGUhLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIXByZXZpZXdQYXlsb2FkKSB7XG4gICAgICAgICAgICAgICAgc2V0R2FuYW5jaWFzUmV0ZW50aW9uKG51bGwpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHByZXZpZXdHYW5hbmNpYXNSZXRlbnRpb24ocHJldmlld1BheWxvYWQpO1xuICAgICAgICAgICAgICAgIGlmIChpc0NhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlQmFzZUZyb21QcmV2aWV3ID1cbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UudmFsdWVfYmFzZSAhPSBudWxsICYmICFOdW1iZXIuaXNOYU4oTnVtYmVyKHJlc3BvbnNlLnZhbHVlX2Jhc2UpKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBOdW1iZXIocmVzcG9uc2UudmFsdWVfYmFzZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogMDtcbiAgICAgICAgICAgICAgICBzZXRHYW5hbmNpYXNSZXRlbnRpb24oe1xuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihyZXNwb25zZS5jYWxjdWxhdGVkX3JldGVudGlvbikgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiByZXNwb25zZS50YXhfaWQsXG4gICAgICAgICAgICAgICAgICAgIHZlbmRvcl9pZDogcmVzcG9uc2UudmVuZG9yX2lkLFxuICAgICAgICAgICAgICAgICAgICBjYXNlX2NvZGU6IHJlc3BvbnNlLmNhc2VfY29kZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVfYmFzZTogdmFsdWVCYXNlRnJvbVByZXZpZXcsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgICAgIGlmICghaXNDYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gY2FsY3VsYXIgbGEgcmV0ZW5jacOzbiBkZSBHYW5hbmNpYXMuJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldEdhbmFuY2lhc1JldGVudGlvbihudWxsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gUGVxdWXDsW8gZGVib3VuY2Ugc2ltcGxlOiBldml0YW1vcyBzcGFtIHNpIGVsIHVzdWFyaW8gZXNjcmliZSByw6FwaWRvXG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHZvaWQgcmVjYWxjdWxhdGVHYW5hbmNpYXNSZXRlbnRpb24oKTtcbiAgICAgICAgfSwgMzAwKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaXNDYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICB9O1xuICAgIH0sIFtcbiAgICAgICAgaGVhZGVyRGF0YS52ZW5kb3JfaWQsXG4gICAgICAgIGhlYWRlckRhdGEucGF5bWVudF9kYXRlLFxuICAgICAgICBhcHBsaWVkQW1vdW50cyxcbiAgICAgICAgdmFsaWRQdXJjaGFzZUlkcyxcbiAgICAgICAgdmVuZG9yUmV0ZW50aW9uSW5mbyxcbiAgICAgICAgdG90YWxzLm5ldEFtb3VudFRvUGF5LFxuICAgIF0pO1xuXG4gICAgLy8gLS0tIFJldGVuY2lvbmVzIGFkaWNpb25hbGVzICh0eXBlPTMgcHJvdmVlZG9yKTogcHJldmlldyBpbmRlcGVuZGllbnRlIGRlIEdhbmFuY2lhcyAtLS1cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBsZXQgaXNDYW5jZWxsZWQgPSBmYWxzZTtcblxuICAgICAgICBjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoTnVtYmVyKHRvdGFscy5uZXRBbW91bnRUb1BheSkgfHwgMCkgPD0gMC4wMSkge1xuICAgICAgICAgICAgICAgIGlmICghaXNDYW5jZWxsZWQpIHNldFZlbmRvclJldGVudGlvbnNQcmV2aWV3KHt9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWhlYWRlckRhdGEudmVuZG9yX2lkIHx8IHZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzQ2FuY2VsbGVkKSBzZXRWZW5kb3JSZXRlbnRpb25zUHJldmlldyh7fSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRzOiBSZWNvcmQ8XG4gICAgICAgICAgICAgICAgICAgIG51bWJlcixcbiAgICAgICAgICAgICAgICAgICAgeyBhbW91bnQ6IG51bWJlcjsgdGF4X2lkOiBudW1iZXI7IHRheF9uYW1lOiBzdHJpbmc7IHZhbHVlX2Jhc2U/OiBudW1iZXIgfCBudWxsIH0gfCBudWxsXG4gICAgICAgICAgICAgICAgPiA9IHt9O1xuICAgICAgICAgICAgICAgIGxldCBhbnlFcnJvciA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgICAgICAgICAgICB2ZW5kb3JSZXRlbnRpb25UYXhlc0FkZGl0aW9uYWwubWFwKGFzeW5jIHZ0ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpZXdQYXlsb2FkID0gYnVpbGRSZXRlbnRpb25QcmV2aWV3UmVxdWVzdCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZW5kb3JfaWQ6IGhlYWRlckRhdGEudmVuZG9yX2lkISxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50X2RhdGU6IGhlYWRlckRhdGEucGF5bWVudF9kYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGxpZWRBbW91bnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkUHVyY2hhc2VJZHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZV9jb2RlOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXByZXZpZXdQYXlsb2FkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0c1t2dC5pZF0gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHZ0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlX2Jhc2U6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcHJldmlld1JldGVudGlvbihwcmV2aWV3UGF5bG9hZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQ2FuY2VsbGVkKSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVCYXNlRnJvbVByZXZpZXcgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZS52YWx1ZV9iYXNlICE9IG51bGwgJiYgIU51bWJlci5pc05hTihOdW1iZXIocmVzcG9uc2UudmFsdWVfYmFzZSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IE51bWJlcihyZXNwb25zZS52YWx1ZV9iYXNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdHNbdnQuaWRdID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcihyZXNwb25zZS5jYWxjdWxhdGVkX3JldGVudGlvbikgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHZ0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlX2Jhc2U6IHZhbHVlQmFzZUZyb21QcmV2aWV3LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbnlFcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0c1t2dC5pZF0gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHZ0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlX2Jhc2U6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGlmICghaXNDYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcocmVzdWx0cyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbnlFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gY2FsY3VsYXIgdW5hIG8gbcOhcyByZXRlbmNpb25lcyBhZGljaW9uYWxlcy4nKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgICAgIGlmICghaXNDYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcoe30pO1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkaWVyb24gY2FsY3VsYXIgbGFzIHJldGVuY2lvbmVzIGFkaWNpb25hbGVzLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCB0aW1lb3V0SWQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB2b2lkIHJ1bigpO1xuICAgICAgICB9LCAzMDApO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpc0NhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgIH07XG4gICAgfSwgW1xuICAgICAgICBoZWFkZXJEYXRhLnZlbmRvcl9pZCxcbiAgICAgICAgaGVhZGVyRGF0YS5wYXltZW50X2RhdGUsXG4gICAgICAgIGFwcGxpZWRBbW91bnRzLFxuICAgICAgICB2YWxpZFB1cmNoYXNlSWRzLFxuICAgICAgICB2ZW5kb3JSZXRlbnRpb25UYXhlc0FkZGl0aW9uYWwsXG4gICAgICAgIHRvdGFscy5uZXRBbW91bnRUb1BheSxcbiAgICBdKTtcblxuICAgIC8vIC0tLSBNQU5FSkFET1JFUyBERSBFVkVOVE9TIC0tLVxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNoYW5nZSA9IChmaWVsZDoga2V5b2YgdHlwZW9mIGhlYWRlckRhdGEsIHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgc2V0SGVhZGVyRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IHZhbHVlIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0VmVuZG9yID0gYXN5bmMgKHZlbmRvcjogVmVuZG9yV2l0aFRheGVzKSA9PiB7XG4gICAgICAgIHNldEhlYWRlckRhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB2ZW5kb3JfaWQ6IHZlbmRvci5pZCwgdmVuZG9yX25hbWU6IHZlbmRvci5uYW1lIHx8ICcnLCBkaXNjb3VudDogMCB9KSk7XG4gICAgICAgIHNldFZlbmRvckNvZGVJbnB1dCh2ZW5kb3IudmVuZG9yX2NvZGUgfHwgU3RyaW5nKHZlbmRvci5pZCkpO1xuXG4gICAgICAgIHNldElzTG9hZGluZ1B1cmNoYXNlcyh0cnVlKTtcbiAgICAgICAgc2V0UGVuZGluZ1B1cmNoYXNlcyhbXSk7XG4gICAgICAgIHNldFBlbmRpbmdGaW5hbmNpYWxOb3RlcyhbXSk7XG4gICAgICAgIHNldEFwcGxpZWRBbW91bnRzKHt9KTtcbiAgICAgICAgc2V0QXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzKHt9KTtcbiAgICAgICAgc2V0VmVuZG9yVGF4ZXMoW10pO1xuICAgICAgICBzZXRWZW5kb3JBZHZhbmNlQmFsYW5jZSgwKTtcbiAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcoe30pO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmdWxsVmVuZG9yID0gYXdhaXQgZ2V0QnlJZDxWZW5kb3JXaXRoVGF4ZXMgJiB7IGFkdmFuY2VfYmFsYW5jZT86IG51bWJlciB9PigndmVuZG9ycycsIHZlbmRvci5pZCk7XG4gICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhmdWxsVmVuZG9yLnRheGVzIHx8IFtdKTtcbiAgICAgICAgICAgIHNldFZlbmRvckFkdmFuY2VCYWxhbmNlKChOdW1iZXIoZnVsbFZlbmRvci5hZHZhbmNlX2JhbGFuY2UpIHx8IDApICogLTEpO1xuICAgICAgICAgICAgc2V0VmVuZG9yUmV0ZW50aW9uSW5mbyh7XG4gICAgICAgICAgICAgICAgZG9fbm90X3JldGFpbjogQm9vbGVhbihmdWxsVmVuZG9yLmRvX25vdF9yZXRhaW4pLFxuICAgICAgICAgICAgICAgIHZlbmRvcl90eXBlOiBmdWxsVmVuZG9yLnZlbmRvcl90eXBlID8/IG51bGwsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyB2ZW5kb3JfaWQ6IHZlbmRvci5pZC50b1N0cmluZygpLCBoYXNfYmFsYW5jZTogJ3RydWUnIH0pO1xuICAgICAgICAgICAgY29uc3QgW3B1cmNoYXNlc1Jlc3BvbnNlLCBub3Rlc1Jlc3BvbnNlXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICBzZWFyY2g8UHVyY2hhc2U+KGBwdXJjaGFzZXM/JHtwYXJhbXMudG9TdHJpbmcoKX1gKSxcbiAgICAgICAgICAgICAgICBzZWFyY2g8UHVyY2hhc2VGaW5hbmNpYWxOb3RlPihgcHVyY2hhc2UtZmluYW5jaWFsLW5vdGVzPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCksXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIHNldFBlbmRpbmdQdXJjaGFzZXMocHVyY2hhc2VzUmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICBzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMobm90ZXNSZXNwb25zZS5kYXRhKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRpZXJvbiBjYXJnYXIgbG9zIGRhdG9zIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzTG9hZGluZ1B1cmNoYXNlcyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQW1vdW50VG9BcHBseUNoYW5nZSA9IChwdXJjaGFzZUlkOiBudW1iZXIsIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3QgcHVyY2hhc2UgPSBwZW5kaW5nUHVyY2hhc2VzLmZpbmQocCA9PiBwLmlkID09PSBwdXJjaGFzZUlkKTtcbiAgICAgICAgaWYgKCFwdXJjaGFzZSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBudW1lcmljVmFsdWUgPSBOdW1iZXIodmFsdWUpIHx8IDA7XG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBOdW1iZXIocHVyY2hhc2UuYmFsYW5jZSkgfHwgMDtcbiAgICAgICAgaWYgKG51bWVyaWNWYWx1ZSA+IGJhbGFuY2UpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIG1vbnRvIG5vIHB1ZWRlIHN1cGVyYXIgZWwgc2FsZG8gKCR7Zm9ybWF0VmFsdWUoYmFsYW5jZSwgJ2N1cnJlbmN5Jyl9KWApO1xuICAgICAgICAgICAgdmFsdWUgPSBiYWxhbmNlO1xuICAgICAgICB9XG4gICAgICAgIHNldEFwcGxpZWRBbW91bnRzKHByZXYgPT4gKHsgLi4ucHJldiwgW3B1cmNoYXNlSWRdOiB2YWx1ZSB9KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUZpbmFuY2lhbE5vdGVBbW91bnRDaGFuZ2UgPSAobm90ZUlkOiBudW1iZXIsIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3Qgbm90ZSA9IHBlbmRpbmdGaW5hbmNpYWxOb3Rlcy5maW5kKG4gPT4gbi5pZCA9PT0gbm90ZUlkKTtcbiAgICAgICAgaWYgKCFub3RlKSByZXR1cm47XG4gICAgICAgIGxldCBudW1lcmljVmFsdWUgPSBOdW1iZXIodmFsdWUpIHx8IDA7XG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBzaWduZWROb3RlQmFsYW5jZShub3RlKTtcbiAgICAgICAgaWYgKGJhbGFuY2UgPj0gMCkge1xuICAgICAgICAgICAgaWYgKG51bWVyaWNWYWx1ZSA8IDApIG51bWVyaWNWYWx1ZSA9IDA7XG4gICAgICAgICAgICBpZiAobnVtZXJpY1ZhbHVlID4gYmFsYW5jZSkge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIG1vbnRvIG5vIHB1ZWRlIHN1cGVyYXIgZWwgc2FsZG8gKCR7Zm9ybWF0VmFsdWUoYmFsYW5jZSwgJ2N1cnJlbmN5Jyl9KWApO1xuICAgICAgICAgICAgICAgIG51bWVyaWNWYWx1ZSA9IGJhbGFuY2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAobnVtZXJpY1ZhbHVlID4gMCkgbnVtZXJpY1ZhbHVlID0gMDtcbiAgICAgICAgICAgIGlmIChudW1lcmljVmFsdWUgPCBiYWxhbmNlKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Qud2FybihgRWwgbW9udG8gbm8gcHVlZGUgc3VwZXJhciBlbCBzYWxkbyAoJHtmb3JtYXRWYWx1ZShiYWxhbmNlLCAnY3VycmVuY3knKX0pYCk7XG4gICAgICAgICAgICAgICAgbnVtZXJpY1ZhbHVlID0gYmFsYW5jZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMocHJldiA9PiAoeyAuLi5wcmV2LCBbbm90ZUlkXTogbnVtZXJpY1ZhbHVlIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQWRkSXRlbSA9ICgpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBbLi4ucHJldiwge1xuICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgcGF5bWVudF9tZXRob2RfY29kZTogJ0VGRScsXG4gICAgICAgICAgICB2YWx1ZTogMCxcbiAgICAgICAgICAgIGJhbmtfaWQ6IG51bGwsIGJhbmtfbmFtZTogbnVsbCwgYmFua19jb2RlOiBudWxsLCBjaGVja19udW1iZXI6IG51bGwsIGNoZWNrX2RhdGU6IG51bGwsIGNoZWNrX2tleTogbnVsbCwgY2hhcnRfYWNjb3VudDogbnVsbCxcbiAgICAgICAgICAgIHJlY2VpdmVkX2NoZWNrX2lkOiBudWxsLFxuICAgICAgICAgICAgLy8gSW5pY2lhbGl6YXIgaW5wdXRzIHZhY8Otb3NcbiAgICAgICAgICAgIHVpX2FjY291bnRfY29kZTogJycsXG4gICAgICAgICAgICB1aV9iYW5rX2NvZGU6ICcnLFxuICAgICAgICAgICAgdWlfY2hlY2tfc2VhcmNoOiAnJ1xuICAgICAgICB9XSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUl0ZW0gPSAodGVtcElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gaXRlbXMuZmluZChpID0+IGkudGVtcElkID09PSB0ZW1wSWQpO1xuICAgICAgICBpZiAodGFyZ2V0ICYmIGlzU3lzdGVtUmV0ZW50aW9uUGF5bWVudFJvdyh0YXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2LmZpbHRlcihpID0+IGkudGVtcElkICE9PSB0ZW1wSWQpKTtcbiAgICB9O1xuXG4gICAgLyoqIENvbXBsZXRhIGVsIGltcG9ydGUgZGUgbGEgbMOtbmVhIGNvbiAodG90YWwgYXBsaWNhZG8gYSBjb21wcmFzKSDiiJIgKHN1bWEgZGUgZGVtw6FzIG1lZGlvcyBkZSBwYWdvKS4gKi9cbiAgICBjb25zdCBmaWxsUGF5bWVudEl0ZW1Gcm9tQXBwbGllZFRvdGFsID0gKHRlbXBJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IHRvdGFsQXBsaWNhZG8gPSB0b3RhbHMuZ3Jvc3NBbW91bnQ7XG4gICAgICAgIGNvbnN0IHN1bU90cm9zID0gaXRlbXMucmVkdWNlKFxuICAgICAgICAgICAgKHMsIGl0KSA9PiAoaXQudGVtcElkID09PSB0ZW1wSWQgPyBzIDogcyArIChOdW1iZXIoaXQudmFsdWUpIHx8IDApKSxcbiAgICAgICAgICAgIDBcbiAgICAgICAgKTtcbiAgICAgICAgbGV0IG1vbnRvID0gTWF0aC5yb3VuZCgodG90YWxBcGxpY2FkbyAtIHN1bU90cm9zKSAqIDEwMCkgLyAxMDA7XG4gICAgICAgIGlmIChtb250byA8IDApIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oXG4gICAgICAgICAgICAgICAgJ0VsIHRvdGFsIGFwbGljYWRvIGVzIG1lbm9yIHF1ZSBsYSBzdW1hIGRlIGxvcyBkZW3DoXMgbWVkaW9zIGRlIHBhZ287IHNlIHVzYXLDoSAwIGVuIGVzdGEgbMOtbmVhLidcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBtb250byA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICd2YWx1ZScsIG1vbnRvKTtcbiAgICB9O1xuXG4gICAgLy8gU2luY3Jvbml6YSBsYSBmaWxhIGVzcGVjaWFsIGRlIG1lZGlvIGRlIHBhZ28gcGFyYSBsYSByZXRlbmNpw7NuIGRlIEdhbmFuY2lhc1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiB7XG4gICAgICAgICAgICBjb25zdCBoYXNSZXRlbnRpb25JdGVtID0gcHJldkl0ZW1zLnNvbWUoaXNHYW5hbmNpYXNSZXRlbnRpb25JdGVtKTtcblxuICAgICAgICAgICAgLy8gU2kgbm8gaGF5IHJldGVuY2nDs24gY2FsY3VsYWRhLCBlbGltaW5hbW9zIGZpbGFzIFJFVF9HQU4gLyBzaXN0ZW1hXG4gICAgICAgICAgICBpZiAoIWdhbmFuY2lhc1JldGVudGlvbiB8fCBnYW5hbmNpYXNSZXRlbnRpb24uYW1vdW50IDw9IDApIHtcbiAgICAgICAgICAgICAgICBpZiAoIWhhc1JldGVudGlvbkl0ZW0pIHJldHVybiBwcmV2SXRlbXM7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByZXZJdGVtcy5maWx0ZXIoaSA9PiAhaXNHYW5hbmNpYXNSZXRlbnRpb25JdGVtKGkpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gTnVtYmVyKGdhbmFuY2lhc1JldGVudGlvbi5hbW91bnQpIHx8IDA7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZUJhc2UgPVxuICAgICAgICAgICAgICAgIGdhbmFuY2lhc1JldGVudGlvbi52YWx1ZV9iYXNlICE9IG51bGwgJiYgIU51bWJlci5pc05hTihOdW1iZXIoZ2FuYW5jaWFzUmV0ZW50aW9uLnZhbHVlX2Jhc2UpKVxuICAgICAgICAgICAgICAgICAgICA/IE51bWJlcihnYW5hbmNpYXNSZXRlbnRpb24udmFsdWVfYmFzZSlcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG5cbiAgICAgICAgICAgIC8vIFNpIHlhIGV4aXN0ZSBsYSBmaWxhIGRlIHJldGVuY2nDs24sIGFjdHVhbGl6YW1vcyBlbCBpbXBvcnRlIHNhbHZvIG92ZXJyaWRlIG1hbnVhbFxuICAgICAgICAgICAgaWYgKGhhc1JldGVudGlvbkl0ZW0pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJldkl0ZW1zLm1hcChpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzR2FuYW5jaWFzUmV0ZW50aW9uSXRlbShpKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV4dDogRm9ybVBheW1lbnRPcmRlckl0ZW0gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc19zeXN0ZW1fZ2VuZXJhdGVkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN5c3RlbV90eXBlOiAnZ2FuYW5jaWFzX3JldGVudGlvbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF5bWVudF9tZXRob2RfY29kZTogUEFZTUVOVF9NRVRIT0RfUkVURU5USU9OX0dBTkFOQ0lBUyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogaS5yZXRlbnRpb25fdmFsdWVfb3ZlcnJpZGRlbiA/IGkudmFsdWUgOiBhbW91bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlQmFzZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV4dC52YWx1ZV9iYXNlID0gdmFsdWVCYXNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbmV4dC52YWx1ZV9iYXNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFNpIG5vIGV4aXN0ZSwgY3JlYW1vcyB1bmEgbnVldmEgZmlsYSBhbCBmaW5hbFxuICAgICAgICAgICAgY29uc3QgbmV3SXRlbTogRm9ybVBheW1lbnRPcmRlckl0ZW0gPSB7XG4gICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgIHBheW1lbnRfbWV0aG9kX2NvZGU6IFBBWU1FTlRfTUVUSE9EX1JFVEVOVElPTl9HQU5BTkNJQVMsXG4gICAgICAgICAgICAgICAgdmFsdWU6IGFtb3VudCxcbiAgICAgICAgICAgICAgICBiYW5rX2lkOiBudWxsLFxuICAgICAgICAgICAgICAgIGJhbmtfbmFtZTogbnVsbCxcbiAgICAgICAgICAgICAgICBiYW5rX2NvZGU6IG51bGwsXG4gICAgICAgICAgICAgICAgY2hlY2tfbnVtYmVyOiBudWxsLFxuICAgICAgICAgICAgICAgIGNoZWNrX2RhdGU6IG51bGwsXG4gICAgICAgICAgICAgICAgY2hlY2tfa2V5OiBudWxsLFxuICAgICAgICAgICAgICAgIGNoYXJ0X2FjY291bnQ6IG51bGwsXG4gICAgICAgICAgICAgICAgcmVjZWl2ZWRfY2hlY2tfaWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgdWlfYWNjb3VudF9jb2RlOiAnJyxcbiAgICAgICAgICAgICAgICB1aV9iYW5rX2NvZGU6ICcnLFxuICAgICAgICAgICAgICAgIHVpX2NoZWNrX3NlYXJjaDogJycsXG4gICAgICAgICAgICAgICAgaXNfc3lzdGVtX2dlbmVyYXRlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBzeXN0ZW1fdHlwZTogJ2dhbmFuY2lhc19yZXRlbnRpb24nLFxuICAgICAgICAgICAgICAgIC4uLih2YWx1ZUJhc2UgIT09IHVuZGVmaW5lZCA/IHsgdmFsdWVfYmFzZTogdmFsdWVCYXNlIH0gOiB7fSksXG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICByZXR1cm4gWy4uLnByZXZJdGVtcywgbmV3SXRlbV07XG4gICAgICAgIH0pO1xuICAgIH0sIFtnYW5hbmNpYXNSZXRlbnRpb25dKTtcblxuICAgIC8vIFNpbmNyb25pemEgZmlsYXMgUkVUXzx0YXhJZD4gcGFyYSByZXRlbmNpb25lcyBhZGljaW9uYWxlcyBkZWwgcHJvdmVlZG9yXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHdpdGhvdXRWZW5kb3JSZXRzID0gcHJldkl0ZW1zLmZpbHRlcihpID0+ICFpc1ZlbmRvclJldGVudGlvbkl0ZW0oaSkpO1xuICAgICAgICAgICAgY29uc3QgdmVuZG9yUm93czogRm9ybVBheW1lbnRPcmRlckl0ZW1bXSA9IFtdO1xuXG4gICAgICAgICAgICBmb3IgKGNvbnN0IHZ0IG9mIHZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpZXcgPSB2ZW5kb3JSZXRlbnRpb25zUHJldmlld1t2dC5pZF07XG4gICAgICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gcHJldmlldz8uYW1vdW50ID8/IDA7XG4gICAgICAgICAgICAgICAgaWYgKGFtb3VudCA8PSAwKSBjb250aW51ZTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nID0gcHJldkl0ZW1zLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgIGkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmVuZG9yUmV0ZW50aW9uSXRlbShpKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGkucmV0ZW50aW9uX3RheF9pZCA9PT0gdnQuaWQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZVRheElkRnJvbVZlbmRvclJldGVudGlvbkNvZGUoaS5wYXltZW50X21ldGhvZF9jb2RlKSA9PT0gdnQuaWQpXG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGNvZGUgPSBidWlsZFZlbmRvclJldGVudGlvblBheW1lbnRDb2RlKHZ0LmlkKTtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZUJhc2UgPVxuICAgICAgICAgICAgICAgICAgICBwcmV2aWV3Py52YWx1ZV9iYXNlICE9IG51bGwgJiYgIU51bWJlci5pc05hTihOdW1iZXIocHJldmlldy52YWx1ZV9iYXNlKSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gTnVtYmVyKHByZXZpZXcudmFsdWVfYmFzZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuXG4gICAgICAgICAgICAgICAgdmVuZG9yUm93cy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBleGlzdGluZz8udGVtcElkID8/IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgICAgICAgICAgICAgIGlkOiBleGlzdGluZz8uaWQsXG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRfbWV0aG9kX2NvZGU6IGNvZGUsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBleGlzdGluZz8ucmV0ZW50aW9uX3ZhbHVlX292ZXJyaWRkZW4gPyBleGlzdGluZy52YWx1ZSA6IGFtb3VudCxcbiAgICAgICAgICAgICAgICAgICAgYmFua19pZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgYmFua19uYW1lOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBiYW5rX2NvZGU6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrX251bWJlcjogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tfZGF0ZTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tfa2V5OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBjaGFydF9hY2NvdW50OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICByZWNlaXZlZF9jaGVja19pZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgdWlfYWNjb3VudF9jb2RlOiBleGlzdGluZz8udWlfYWNjb3VudF9jb2RlID8/ICcnLFxuICAgICAgICAgICAgICAgICAgICB1aV9iYW5rX2NvZGU6IGV4aXN0aW5nPy51aV9iYW5rX2NvZGUgPz8gJycsXG4gICAgICAgICAgICAgICAgICAgIHVpX2NoZWNrX3NlYXJjaDogZXhpc3Rpbmc/LnVpX2NoZWNrX3NlYXJjaCA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgaXNfc3lzdGVtX2dlbmVyYXRlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgc3lzdGVtX3R5cGU6ICd2ZW5kb3JfcmV0ZW50aW9uJyxcbiAgICAgICAgICAgICAgICAgICAgcmV0ZW50aW9uX3RheF9pZDogdnQuaWQsXG4gICAgICAgICAgICAgICAgICAgIHJldGVudGlvbl90YXhfbmFtZTogdnQubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcmV0ZW50aW9uX3ZhbHVlX292ZXJyaWRkZW46IGV4aXN0aW5nPy5yZXRlbnRpb25fdmFsdWVfb3ZlcnJpZGRlbixcbiAgICAgICAgICAgICAgICAgICAgLi4uKHZhbHVlQmFzZSAhPT0gdW5kZWZpbmVkID8geyB2YWx1ZV9iYXNlOiB2YWx1ZUJhc2UgfSA6IHt9KSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIFsuLi53aXRob3V0VmVuZG9yUmV0cywgLi4udmVuZG9yUm93c107XG4gICAgICAgIH0pO1xuICAgIH0sIFt2ZW5kb3JSZXRlbnRpb25zUHJldmlldywgdmVuZG9yUmV0ZW50aW9uVGF4ZXNBZGRpdGlvbmFsXSk7XG5cbiAgICBjb25zdCBoYW5kbGVJdGVtQ2hhbmdlID0gKHRlbXBJZDogc3RyaW5nLCBmaWVsZDoga2V5b2YgRm9ybVBheW1lbnRPcmRlckl0ZW0sIHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgLy8gQmxvcXVlYXIgbWVkaW8vY3VlbnRhIGVuIHJldGVuY2lvbmVzOyBlbCBpbXBvcnRlIHPDrSBlcyBlZGl0YWJsZVxuICAgICAgICBpZiAoZmllbGQgPT09ICdwYXltZW50X21ldGhvZF9jb2RlJyB8fCBmaWVsZCA9PT0gJ2NoYXJ0X2FjY291bnQnKSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBpdGVtcy5maW5kKGkgPT4gaS50ZW1wSWQgPT09IHRlbXBJZCk7XG4gICAgICAgICAgICBpZiAodGFyZ2V0ICYmIGlzU3lzdGVtUmV0ZW50aW9uUGF5bWVudFJvdyh0YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3VtT3RoZXJTYWwgPSBwcmV2XG4gICAgICAgICAgICAgICAgLmZpbHRlcihpID0+IGkucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ1NBTCcgJiYgaS50ZW1wSWQgIT09IHRlbXBJZClcbiAgICAgICAgICAgICAgICAucmVkdWNlKChzLCBpKSA9PiBzICsgKE51bWJlcihpLnZhbHVlKSB8fCAwKSwgMCk7XG4gICAgICAgICAgICBjb25zdCBtYXhBZHZhbmNlRm9ySXRlbSA9IE1hdGgubWF4KDAsICh2ZW5kb3JBZHZhbmNlQmFsYW5jZSB8fCAwKSAtIHN1bU90aGVyU2FsKTtcblxuICAgICAgICAgICAgcmV0dXJuIHByZXYubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLnRlbXBJZCAhPT0gdGVtcElkKSByZXR1cm4gaXRlbTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkSXRlbTogRm9ybVBheW1lbnRPcmRlckl0ZW0gPSB7IC4uLml0ZW0sIFtmaWVsZF06IHZhbHVlIH07XG5cbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgPT09ICdwYXltZW50X21ldGhvZF9jb2RlJykge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5iYW5rX2lkID0gbnVsbDsgdXBkYXRlZEl0ZW0uYmFua19uYW1lID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uY2hlY2tfbnVtYmVyID0gbnVsbDsgdXBkYXRlZEl0ZW0uY2hlY2tfZGF0ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnJlY2VpdmVkX2NoZWNrX2lkID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udWlfYmFua19jb2RlID0gJyc7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnVpX2NoZWNrX3NlYXJjaCA9ICcnO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS51aV9yZWNlaXZlZF9ob2xkZXIgPSAnJztcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udWlfcmVjZWl2ZWRfY3VpdCA9ICcnO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS51aV9yZWNlaXZlZF9yZWZlcmVuY2UgPSAnJztcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlICE9PSAnQ0hSJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0ucmVjZWl2ZWRfY2hlY2tfaWQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJ0NIUicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLmJhbmtfaWQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uYmFua19uYW1lID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLmNoZWNrX251bWJlciA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5jaGVja19kYXRlID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnZhbHVlID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT09ICdFRkUnIHx8IHZhbHVlID09PSAnU0FMJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uYmFua19pZCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5iYW5rX25hbWUgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uY2hlY2tfbnVtYmVyID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLmNoZWNrX2RhdGUgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0ucmVjZWl2ZWRfY2hlY2tfaWQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJ1NBTCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3NzQW1vdW50ID0gY29tcHV0ZUdyb3NzQXBwbGllZEFtb3VudChhcHBsaWVkQW1vdW50cywgYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRpc2NvdW50ID0gaGVhZGVyRGF0YS5kaXNjb3VudCB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxUYXhlcyA9ICh2ZW5kb3JHZW5lcmFsVGF4ZXMgfHwgW10pLnJlZHVjZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCB2VGF4KSA9PiBzdW0gKyBkaXNjb3VudCAqICgodlRheC5yYXRlIHx8IDApIC8gMTAwKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV0QW1vdW50VG9QYXkgPSBncm9zc0Ftb3VudCAtIGRpc2NvdW50IC0gdG90YWxUYXhlcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnZhbHVlID0gTWF0aC5tYXgoMCwgTWF0aC5taW4obmV0QW1vdW50VG9QYXksIG1heEFkdmFuY2VGb3JJdGVtKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSAndmFsdWUnICYmIGl0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ1NBTCcpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbnVtVmFsID0gTnVtYmVyKHZhbHVlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBpZiAobnVtVmFsID4gbWF4QWR2YW5jZUZvckl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIG1vbnRvIG5vIHB1ZWRlIHN1cGVyYXIgZWwgc2FsZG8gYW50aWNpcGFkbyBkaXNwb25pYmxlICgke2Zvcm1hdFZhbHVlKG1heEFkdmFuY2VGb3JJdGVtLCAnY3VycmVuY3knKX0pLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udmFsdWUgPSBtYXhBZHZhbmNlRm9ySXRlbTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgPT09ICd2YWx1ZScgJiYgaXNTeXN0ZW1SZXRlbnRpb25QYXltZW50Um93KGl0ZW0pKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnJldGVudGlvbl92YWx1ZV9vdmVycmlkZGVuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWRJdGVtO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICAvLyAtLS0gTUFORUpPIERFIFNFTEVDQ0nDk04gREUgTU9EQUwgLS0tXG4gICAgY29uc3Qgb3Blbk1vZGFsID0gKHRhcmdldDogRWRpdGluZ1RhcmdldCkgPT4ge1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KHRhcmdldCk7XG4gICAgICAgIGxldCBjb25maWcgPSBudWxsO1xuICAgICAgICBpZiAodGFyZ2V0ID09PSAndmVuZG9yJykge1xuICAgICAgICAgICAgY29uZmlnID0gcHJvdmVlZG9yZXNNb2R1bGVDb25maWc7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ29iamVjdCcgJiYgdGFyZ2V0LnR5cGUgPT09ICdpdGVtQmFuaycpIHtcbiAgICAgICAgICAgIGNvbmZpZyA9IGJhbmNvc01vZHVsZUNvbmZpZztcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnb2JqZWN0JyAmJiB0YXJnZXQudHlwZSA9PT0gJ2l0ZW1BY2NvdW50Jykge1xuICAgICAgICAgICAgY29uZmlnID0gcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZztcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnb2JqZWN0JyAmJiB0YXJnZXQudHlwZSA9PT0gJ2l0ZW1SZWNlaXZlZENoZWNrJykge1xuICAgICAgICAgICAgY29uZmlnID0gdW5kZWxpdmVyZWRDaGVja3NDb25maWc7XG4gICAgICAgIH1cbiAgICAgICAgc2V0TW9kYWxDb25maWcoY29uZmlnKTtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdE1vZGFsID0gKHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG4gICAgICAgIGlmICghZWRpdGluZ1RhcmdldCkgcmV0dXJuIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgY29uc3QgaW5kZXggPSB0eXBlb2YgZWRpdGluZ1RhcmdldCA9PT0gJ29iamVjdCcgPyBlZGl0aW5nVGFyZ2V0LmluZGV4IDogLTE7XG4gICAgICAgIGNvbnN0IHRlbXBJZCA9IGluZGV4ICE9PSAtMSA/IGl0ZW1zW2luZGV4XS50ZW1wSWQgOiAnJztcblxuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ3ZlbmRvcicpIHtcbiAgICAgICAgICAgIGhhbmRsZVNlbGVjdFZlbmRvcihzZWxlY3RlZEl0ZW0gYXMgVmVuZG9yV2l0aFRheGVzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgZWRpdGluZ1RhcmdldCA9PT0gJ29iamVjdCcgJiYgZWRpdGluZ1RhcmdldC50eXBlID09PSAnaXRlbUJhbmsnKSB7XG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ2JhbmtfaWQnLCBzZWxlY3RlZEl0ZW0uaWQpO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdiYW5rX25hbWUnLCBzZWxlY3RlZEl0ZW0ubmFtZSk7XG4gICAgICAgICAgICAvLyDinIUgU2luY3Jvbml6YXIgaW5wdXQgdmlzdWFsXG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ3VpX2JhbmtfY29kZScsIHNlbGVjdGVkSXRlbS5jb2RlIHx8IFN0cmluZyhzZWxlY3RlZEl0ZW0uaWQpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgZWRpdGluZ1RhcmdldCA9PT0gJ29iamVjdCcgJiYgZWRpdGluZ1RhcmdldC50eXBlID09PSAnaXRlbUFjY291bnQnKSB7XG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ2NoYXJ0X2FjY291bnQnLCBzZWxlY3RlZEl0ZW0gYXMgUGxhbkRlQ3VlbnRhcyk7XG4gICAgICAgICAgICAvLyDinIUgU2luY3Jvbml6YXIgaW5wdXQgdmlzdWFsXG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKHRlbXBJZCwgJ3VpX2FjY291bnRfY29kZScsIHNlbGVjdGVkSXRlbS5jb2RlKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgZWRpdGluZ1RhcmdldCA9PT0gJ29iamVjdCcgJiYgZWRpdGluZ1RhcmdldC50eXBlID09PSAnaXRlbVJlY2VpdmVkQ2hlY2snKSB7XG4gICAgICAgICAgICBjb25zdCBjaGVjayA9IHNlbGVjdGVkSXRlbSBhcyBSZWNlaXZlZENoZWNrO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdyZWNlaXZlZF9jaGVja19pZCcsIGNoZWNrLmlkKTtcbiAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAndmFsdWUnLCBOdW1iZXIoY2hlY2sudmFsdWUpIHx8IDApO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICdiYW5rX2lkJywgY2hlY2suYmFua19pZCA/PyBudWxsKTtcbiAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAnYmFua19uYW1lJywgY2hlY2suYmFua19uYW1lID8/ICcnKTtcbiAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAnY2hlY2tfbnVtYmVyJywgY2hlY2suY2hlY2tfbnVtYmVyID8/ICcnKTtcbiAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UodGVtcElkLCAnY2hlY2tfZGF0ZScsIGNoZWNrLmNoZWNrX2RhdGUgPz8gJycpO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICd1aV9jaGVja19zZWFyY2gnLCBjaGVjay5jaGVja19udW1iZXIgPz8gJycpO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICd1aV9yZWNlaXZlZF9ob2xkZXInLCBjaGVjay5jaGVja19ob2xkZXIgPz8gJycpO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICd1aV9yZWNlaXZlZF9jdWl0JywgY2hlY2suaXNzdWVyX2N1aXQgPz8gJycpO1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZSh0ZW1wSWQsICd1aV9yZWNlaXZlZF9yZWZlcmVuY2UnLCBjaGVjay5yZWZlcmVuY2VfbnVtYmVyID8/ICcnKTtcbiAgICAgICAgfVxuICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgICAgIHNldEVkaXRpbmdUYXJnZXQobnVsbCk7XG4gICAgfTtcblxuICAgIC8vIC0tLSBHVUFSREFETyAtLS1cbiAgICBjb25zdCBwZXJmb3JtU2F2ZVBheW1lbnRPcmRlciA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICBjb25zdCBjbGVhbkl0ZW1zID0gaXRlbXMubWFwKChyb3cpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgICB0ZW1wSWQsXG4gICAgICAgICAgICAgICAgY2hhcnRfYWNjb3VudCxcbiAgICAgICAgICAgICAgICByZXRlbnRpb25fdGF4X25hbWU6IF9yZXRlbnRpb25OYW1lLFxuICAgICAgICAgICAgICAgIGlzX3N5c3RlbV9nZW5lcmF0ZWQ6IF9pc1N5cyxcbiAgICAgICAgICAgICAgICBzeXN0ZW1fdHlwZTogX3N5c1R5cGUsXG4gICAgICAgICAgICAgICAgcmV0ZW50aW9uX3RheF9pZDogX3JldFRpZCxcbiAgICAgICAgICAgICAgICByZXRlbnRpb25fdmFsdWVfb3ZlcnJpZGRlbjogX3JldE92ZXJyaWRkZW4sXG4gICAgICAgICAgICAgICAgLi4ucmVzdFxuICAgICAgICAgICAgfSA9IHJvdztcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuSXRlbTogYW55ID0ge1xuICAgICAgICAgICAgICAgIC4uLnJlc3QsXG4gICAgICAgICAgICAgICAgdmFsdWU6IE51bWJlcihyZXN0LnZhbHVlKSB8fCAwLFxuICAgICAgICAgICAgICAgIGNoYXJ0X2FjY291bnRfaWQ6IGNoYXJ0X2FjY291bnQ/LmlkIHx8IG51bGwsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKHJlc3QucmVjZWl2ZWRfY2hlY2tfaWQpIGNsZWFuSXRlbS5yZWNlaXZlZF9jaGVja19pZCA9IHJlc3QucmVjZWl2ZWRfY2hlY2tfaWQ7XG4gICAgICAgICAgICBpZiAocmVzdC5pZCkgY2xlYW5JdGVtLmlkID0gcmVzdC5pZDtcblxuICAgICAgICAgICAgZGVsZXRlIChjbGVhbkl0ZW0gYXMgYW55KS51aV9hY2NvdW50X2NvZGU7XG4gICAgICAgICAgICBkZWxldGUgKGNsZWFuSXRlbSBhcyBhbnkpLnVpX2JhbmtfY29kZTtcbiAgICAgICAgICAgIGRlbGV0ZSAoY2xlYW5JdGVtIGFzIGFueSkudWlfY2hlY2tfc2VhcmNoO1xuICAgICAgICAgICAgZGVsZXRlIChjbGVhbkl0ZW0gYXMgYW55KS51aV9yZWNlaXZlZF9ob2xkZXI7XG4gICAgICAgICAgICBkZWxldGUgKGNsZWFuSXRlbSBhcyBhbnkpLnVpX3JlY2VpdmVkX2N1aXQ7XG4gICAgICAgICAgICBkZWxldGUgKGNsZWFuSXRlbSBhcyBhbnkpLnVpX3JlY2VpdmVkX3JlZmVyZW5jZTtcbiAgICAgICAgICAgIGRlbGV0ZSAoY2xlYW5JdGVtIGFzIGFueSkucmVjZWl2ZWRfY2hlY2s7XG5cbiAgICAgICAgICAgIGNvbnN0IGl0ZW1Gb3JSZXRlbnRpb25DaGVjayA9IHJlc3QgYXMgRm9ybVBheW1lbnRPcmRlckl0ZW07XG4gICAgICAgICAgICBpZiAoaXNHYW5hbmNpYXNSZXRlbnRpb25JdGVtKGl0ZW1Gb3JSZXRlbnRpb25DaGVjaykgfHwgaXNWZW5kb3JSZXRlbnRpb25JdGVtKGl0ZW1Gb3JSZXRlbnRpb25DaGVjaykpIHtcbiAgICAgICAgICAgICAgICBpZiAocmVzdC52YWx1ZV9iYXNlICE9IG51bGwgJiYgIU51bWJlci5pc05hTihOdW1iZXIocmVzdC52YWx1ZV9iYXNlKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYW5JdGVtLnZhbHVlX2Jhc2UgPSBOdW1iZXIocmVzdC52YWx1ZV9iYXNlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgY2xlYW5JdGVtLnZhbHVlX2Jhc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBkZWxldGUgY2xlYW5JdGVtLnZhbHVlX2Jhc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBjbGVhbkl0ZW07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IGdhbmFuY2lhc0l0ZW0gPSBpdGVtcy5maW5kKGlzR2FuYW5jaWFzUmV0ZW50aW9uSXRlbSk7XG4gICAgICAgIGNvbnN0IGdhbmFuY2lhc0Ftb3VudCA9IGdhbmFuY2lhc0l0ZW0gPyBOdW1iZXIoZ2FuYW5jaWFzSXRlbS52YWx1ZSkgfHwgMCA6IDA7XG5cbiAgICAgICAgY29uc3QgdmVuZG9yUmV0ZW50aW9uVGF4RW50cmllczogQXBwbGllZFRheFtdID0gdmVuZG9yUmV0ZW50aW9uVGF4ZXNBZGRpdGlvbmFsXG4gICAgICAgICAgICAubWFwKHZ0ID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXRlbnRpb25JdGVtID0gaXRlbXMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgaSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgaXNWZW5kb3JSZXRlbnRpb25JdGVtKGkpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoaS5yZXRlbnRpb25fdGF4X2lkID09PSB2dC5pZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlVGF4SWRGcm9tVmVuZG9yUmV0ZW50aW9uQ29kZShpLnBheW1lbnRfbWV0aG9kX2NvZGUpID09PSB2dC5pZClcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGNvbnN0IGFtb3VudCA9IHJldGVudGlvbkl0ZW1cbiAgICAgICAgICAgICAgICAgICAgPyBOdW1iZXIocmV0ZW50aW9uSXRlbS52YWx1ZSkgfHwgMFxuICAgICAgICAgICAgICAgICAgICA6ICh2ZW5kb3JSZXRlbnRpb25zUHJldmlld1t2dC5pZF0/LmFtb3VudCA/PyAwKTtcbiAgICAgICAgICAgICAgICBpZiAoYW1vdW50IDw9IDApIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIGNvbnN0IHAgPSB2ZW5kb3JSZXRlbnRpb25zUHJldmlld1t2dC5pZF07XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB2dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHA/LnRheF9uYW1lIHx8IHZ0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHJhdGU6IDAsXG4gICAgICAgICAgICAgICAgICAgIGFtb3VudCxcbiAgICAgICAgICAgICAgICB9IGFzIEFwcGxpZWRUYXg7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmZpbHRlcigodCk6IHQgaXMgQXBwbGllZFRheCA9PiB0ICE9IG51bGwpO1xuXG4gICAgICAgIGNvbnN0IHRheGVzVG9TYXZlID0gW1xuICAgICAgICAgICAgLi4udG90YWxzLmFwcGxpZWRUYXhlcy5maWx0ZXIodGF4ID0+IHRheC5hbW91bnQgPiAwKSxcbiAgICAgICAgICAgIC4uLihnYW5hbmNpYXNSZXRlbnRpb24gJiYgZ2FuYW5jaWFzQW1vdW50ID4gMFxuICAgICAgICAgICAgICAgID8gW3tcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiBnYW5hbmNpYXNSZXRlbnRpb24udGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogJ1JldGVuY2nDs24gSW1wdWVzdG8gYSBsYXMgR2FuYW5jaWFzJyxcbiAgICAgICAgICAgICAgICAgICAgcmF0ZTogMCxcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBnYW5hbmNpYXNBbW91bnQsXG4gICAgICAgICAgICAgICAgfSBhcyBBcHBsaWVkVGF4XVxuICAgICAgICAgICAgICAgIDogW10pLFxuICAgICAgICAgICAgLi4udmVuZG9yUmV0ZW50aW9uVGF4RW50cmllcyxcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgYXBwbGllZF9wdXJjaGFzZXM6IEFwcGxpZWRQdXJjaGFzZVtdID0gYnVpbGRBcHBsaWVkUHVyY2hhc2VzRm9yU2F2ZShhcHBsaWVkQW1vdW50cyk7XG4gICAgICAgIGNvbnN0IGFwcGxpZWRfZmluYW5jaWFsX25vdGVzID0gYnVpbGRBcHBsaWVkRmluYW5jaWFsTm90ZXNGb3JTYXZlKGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyk7XG5cbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgICAgIHBheW1lbnRfZGF0ZTogaGVhZGVyRGF0YS5wYXltZW50X2RhdGUsXG4gICAgICAgICAgICB2ZW5kb3JfaWQ6IGhlYWRlckRhdGEudmVuZG9yX2lkLFxuICAgICAgICAgICAgZGlzY291bnQ6IGhlYWRlckRhdGEuZGlzY291bnQsXG4gICAgICAgICAgICBncm9zc19hbW91bnQ6IHRvdGFscy5ncm9zc0Ftb3VudCxcbiAgICAgICAgICAgIGl0ZW1zOiBjbGVhbkl0ZW1zLFxuICAgICAgICAgICAgdGF4ZXM6IHRheGVzVG9TYXZlLFxuICAgICAgICAgICAgYXBwbGllZF9wdXJjaGFzZXMsXG4gICAgICAgICAgICBhcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyxcbiAgICAgICAgICAgIHRvdGFsX2Ftb3VudDogdG90YWxzLnRvdGFsUGFpZCxcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzYXZlSXRlbShwYXlsb2FkIGFzIHVua25vd24gYXMgUGFydGlhbDxQYXltZW50T3JkZXI+KTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgdG9hc3Quc3VjY2Vzcyhtb2RlID09PSAnY3JlYXRlJyA/ICdPcmRlbiBkZSBwYWdvIGNyZWFkYSBjb24gw6l4aXRvLicgOiAnT3JkZW4gZGUgcGFnbyBhY3R1YWxpemFkYSBjb24gw6l4aXRvLicpO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgob3JkZW5lc1BhZ29Nb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGl0ZW1zLFxuICAgICAgICB0b3RhbHMuYXBwbGllZFRheGVzLFxuICAgICAgICB0b3RhbHMuZ3Jvc3NBbW91bnQsXG4gICAgICAgIHRvdGFscy50b3RhbFBhaWQsXG4gICAgICAgIGdhbmFuY2lhc1JldGVudGlvbixcbiAgICAgICAgdmVuZG9yUmV0ZW50aW9uc1ByZXZpZXcsXG4gICAgICAgIHZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbCxcbiAgICAgICAgYXBwbGllZEFtb3VudHMsXG4gICAgICAgIGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyxcbiAgICAgICAgaGVhZGVyRGF0YS5wYXltZW50X2RhdGUsXG4gICAgICAgIGhlYWRlckRhdGEudmVuZG9yX2lkLFxuICAgICAgICBoZWFkZXJEYXRhLmRpc2NvdW50LFxuICAgICAgICBzYXZlSXRlbSxcbiAgICAgICAgbW9kZSxcbiAgICAgICAgbmF2aWdhdGUsXG4gICAgXSk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWhlYWRlckRhdGEudmVuZG9yX2lkKSB7IHRvYXN0LmVycm9yKFwiU2VsZWNjaW9uZSB1biBwcm92ZWVkb3IuXCIpOyByZXR1cm47IH1cblxuICAgICAgICBjb25zdCBoYXNBcHBsaWVkUHVyY2hhc2VzID0gYnVpbGRBcHBsaWVkUHVyY2hhc2VzRm9yU2F2ZShhcHBsaWVkQW1vdW50cykubGVuZ3RoID4gMDtcbiAgICAgICAgY29uc3QgaGFzQXBwbGllZEZpbmFuY2lhbE5vdGVzID0gYnVpbGRBcHBsaWVkRmluYW5jaWFsTm90ZXNGb3JTYXZlKGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cykubGVuZ3RoID4gMDtcbiAgICAgICAgY29uc3QgbmV0SXNaZXJvID0gTWF0aC5hYnMoTnVtYmVyKHRvdGFscy5uZXRBbW91bnRUb1BheSkgfHwgMCkgPD0gMC4wMTtcbiAgICAgICAgY29uc3QgZ3Jvc3NJc1plcm8gPSBNYXRoLmFicyhOdW1iZXIodG90YWxzLmdyb3NzQW1vdW50KSB8fCAwKSA8PSAwLjAxO1xuICAgICAgICBjb25zdCBhbGxvd1plcm9QYXltZW50cyA9XG4gICAgICAgICAgICBoYXNBcHBsaWVkUHVyY2hhc2VzICYmIChuZXRJc1plcm8gfHwgKGdyb3NzSXNaZXJvICYmIGhhc0FwcGxpZWRGaW5hbmNpYWxOb3RlcykpO1xuXG4gICAgICAgIGNvbnN0IHBheW1lbnRJdGVtc1dpdGhWYWx1ZSA9IGl0ZW1zLmZpbHRlcihcbiAgICAgICAgICAgIChpKSA9PiBNYXRoLmFicyhOdW1iZXIoaS52YWx1ZSkgfHwgMCkgPiAwLjAxXG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKCFhbGxvd1plcm9QYXltZW50cykge1xuICAgICAgICAgICAgaWYgKHBheW1lbnRJdGVtc1dpdGhWYWx1ZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignRGViZSBhw7FhZGlyIGFsIG1lbm9zIHVuIG1lZGlvIGRlIHBhZ28uJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRvdGFscy50b3RhbFBhaWQgPD0gMCkge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdMYSBzdW1hIGRlIGxvcyBtZWRpb3MgZGUgcGFnbyBkZWJlIHNlciBtYXlvciBxdWUgMC4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgICAgICAgIGlmICgoaXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnQ0hFJyB8fCBpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdUUkEnKSAmJiAhaXRlbS5iYW5rX2lkKSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJQYXJhIGNoZXF1ZXMgcHJvcGlvcyB5IHRyYW5zZmVyZW5jaWFzIGRlYmUgc2VsZWNjaW9uYXIgdW4gYmFuY28uXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRpZmZlcmVuY2UgPSB0b3RhbHMuZ3Jvc3NBbW91bnQgLSB0b3RhbHMuZGlzY291bnQgLSB0b3RhbHMudG90YWxUYXhlcyAtIHRvdGFscy50b3RhbFBhaWQ7XG4gICAgICAgIGlmIChkaWZmZXJlbmNlID4gMC4wMSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoYERpZmVyZW5jaWEgZW50cmUgdG90YWxlczogZmFsdGEgcGFnYXIgJHtmb3JtYXRWYWx1ZShkaWZmZXJlbmNlLCAnY3VycmVuY3knKX1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGlmZmVyZW5jZSA8IC0wLjAxKSB7XG4gICAgICAgICAgICBjb25zdCBhZHZhbmNlQW1vdW50ID0gTWF0aC5hYnMoZGlmZmVyZW5jZSk7XG4gICAgICAgICAgICBzaG93Q29uZmlybWF0aW9uTW9kYWwoe1xuICAgICAgICAgICAgICAgIHRpdGxlOiAnU2FsZG8gYSBmYXZvciBkZWwgcHJvdmVlZG9yJyxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOlxuICAgICAgICAgICAgICAgICAgICBgRWwgdG90YWwgYSBwYWdhciBlcyBtZW5vciBxdWUgZWwgaW1wb3J0ZSBkZSBsb3MgbWVkaW9zIGRlIHBhZ28uIFNlIGdlbmVyYXLDoSBzYWxkbyBhIGZhdm9yIChhbnRpY2lwbykgcG9yICR7Zm9ybWF0VmFsdWUoYWR2YW5jZUFtb3VudCwgJ2N1cnJlbmN5Jyl9LiDCv0Rlc2VhIGNvbnRpbnVhcj9gLFxuICAgICAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB2b2lkIHBlcmZvcm1TYXZlUGF5bWVudE9yZGVyKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgYXdhaXQgcGVyZm9ybVNhdmVQYXltZW50T3JkZXIoKTtcbiAgICB9O1xuXG5cbiAgICBpZiAobG9hZGluZ0luaXRpYWwgJiYgbW9kZSA9PT0gJ2VkaXQnKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGNvbnN0IGlucHV0U3R5bGUgPSBcInctZnVsbCBweC0zIHB5LTIgbXQtMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+e21vZGUgPT09ICdjcmVhdGUnID8gJ0NyZWFyIE9yZGVuIGRlIFBhZ28nIDogYEVkaXRhbmRvIE9yZGVuIGRlIFBhZ28gIyR7aWR9YH08L2gxPlxuXG4gICAgICAgICAgICB7LyogLS0tIENBQkVDRVJBIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC02IG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBheW1lbnRfZGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIGRlIFBhZ288L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwicGF5bWVudF9kYXRlXCIgdHlwZT1cImRhdGVcIiB2YWx1ZT17aGVhZGVyRGF0YS5wYXltZW50X2RhdGV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgncGF5bWVudF9kYXRlJywgZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9e2lucHV0U3R5bGV9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlByb3ZlZWRvciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXt2ZW5kb3JDb2RlSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtoZWFkZXJEYXRhLnZlbmRvcl9uYW1lIHx8IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXtzZXRWZW5kb3JDb2RlSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXtoYW5kbGVWZW5kb3JDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IG9wZW5Nb2RhbCgndmVuZG9yJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEhlYWRlckRhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB2ZW5kb3JfaWQ6IG51bGwsIHZlbmRvcl9uYW1lOiAnJywgZGlzY291bnQ6IDAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWZW5kb3JUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBlbmRpbmdQdXJjaGFzZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkQW1vdW50cyh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZlbmRvckNvZGVJbnB1dCgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZlbmRvckFkdmFuY2VCYWxhbmNlKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWZW5kb3JSZXRlbnRpb25JbmZvKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRHYW5hbmNpYXNSZXRlbnRpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZlbmRvclJldGVudGlvbnNQcmV2aWV3KHt9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttb2RlID09PSAnZWRpdCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAge3ZlbmRvckFkdmFuY2VCYWxhbmNlID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5TYWxkbyBhbnRpY2lwYWRvIGRpc3BvbmlibGU6IHtmb3JtYXRWYWx1ZSh2ZW5kb3JBZHZhbmNlQmFsYW5jZSwgJ2N1cnJlbmN5Jyl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBGQUNUVVJBUyBQRU5ESUVOVEVTIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkZhY3R1cmFzIFBlbmRpZW50ZXM8L2gyPlxuICAgICAgICAgICAgICAgIHtzaG93UmV0ZW50aW9uQW1vdW50SGludCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWFtYmVyLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgSW5ncmVzZSBlbCBtb250byBhIGFwbGljYXIgZW4gY2FkYSBmYWN0dXJhIHBhcmEgY2FsY3VsYXIgbGEgcmV0ZW5jacOzbi5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge2lzTG9hZGluZ1B1cmNoYXNlcyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTRcIj48TG9hZGluZ1NwaW5uZXIgLz48L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogcGVuZGluZ1B1cmNoYXNlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZyBtYXgtaC05NlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgc3RpY2t5IHRvcC0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHBsLTQgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmVjaGE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5OwrogZGUgRmFjdHVyYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5TYWxkbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdy00MFwiPk1vbnRvIGEgQXBsaWNhcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nUHVyY2hhc2VzLm1hcChwdXJjaGFzZSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtwdXJjaGFzZS5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCB0ZXh0LXNtXCI+e2Zvcm1hdFZhbHVlKHB1cmNoYXNlLnB1cmNoYXNlX2RhdGUsICdkYXRlJyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj57cHVyY2hhc2UuZG9jdW1lbnRfbnVtYmVyfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHRcIj57Zm9ybWF0VmFsdWUocHVyY2hhc2UudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMFwiPntmb3JtYXRWYWx1ZShwdXJjaGFzZS5iYWxhbmNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbGllZEFtb3VudHNbcHVyY2hhc2UuaWRdfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlQW1vdW50VG9BcHBseUNoYW5nZShwdXJjaGFzZS5pZCwgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI9eygpID0+IGhhbmRsZUFtb3VudFRvQXBwbHlDaGFuZ2UocHVyY2hhc2UuaWQsIGFwcGxpZWRBbW91bnRzW3B1cmNoYXNlLmlkXSA/PyAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMCB0ZXh0LXJpZ2h0IGlucHV0LWZvcm0gYm9yZGVyIHJvdW5kZWQgcC0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9e051bWJlcihwdXJjaGFzZS5iYWxhbmNlKSB8fCAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BNb250byBhIGFwbGljYXIgcGFyYSBmYWN0dXJhICR7cHVyY2hhc2UuZG9jdW1lbnRfbnVtYmVyfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFtb3VudFRvQXBwbHlDaGFuZ2UocHVyY2hhc2UuaWQsIE51bWJlcihwdXJjaGFzZS5iYWxhbmNlKSB8fCAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHAtMS41IHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6YmctaW5kaWdvLTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBob3Zlcjpib3JkZXItaW5kaWdvLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMbGVuYXIgY29uIHNhbGRvIHBlbmRpZW50ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEFwbGljYXIgc2FsZG8gY29tcGxldG8gKCR7Zm9ybWF0VmFsdWUocHVyY2hhc2UuYmFsYW5jZSwgJ2N1cnJlbmN5Jyl9KSBwYXJhIGZhY3R1cmEgJHtwdXJjaGFzZS5kb2N1bWVudF9udW1iZXJ9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFGaWxsRHJpcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBzdGlja3kgYm90dG9tLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezR9IGNsYXNzTmFtZT1cInB5LTIgcGwtNCBwci0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbCBBcGxpY2Fkbzo8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkXCI+e2Zvcm1hdFZhbHVlKHRvdGFscy5wdXJjaGFzZXNHcm9zc0Ftb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rmb290PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aGVhZGVyRGF0YS52ZW5kb3JfaWQgPyAnU2luIGZhY3R1cmFzIHBlbmRpZW50ZXMuJyA6ICdTZWxlY2Npb25lIHVuIHByb3ZlZWRvci4nfTwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gTk9UQVMgRklOQU5DSUVSQVMgUEVORElFTlRFUyAtLS0gKi99XG4gICAgICAgICAgICB7cGVuZGluZ0ZpbmFuY2lhbE5vdGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5Ob3RhcyBGaW5hbmNpZXJhcyBQZW5kaWVudGVzPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGcgbWF4LWgtOTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHN0aWNreSB0b3AtMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBwbC00IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlRpcG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5GZWNoYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk7CuiBkZSBDb21wcm9iYW50ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5TYWxkbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdy00MFwiPk1vbnRvIGEgQXBsaWNhcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRmluYW5jaWFsTm90ZXMubWFwKG5vdGUgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFsYW5jZSA9IHNpZ25lZE5vdGVCYWxhbmNlKG5vdGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWwgPSBzaWduZWROb3RlVG90YWwobm90ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkb2NOdW1iZXIgPSBub3RlLnB1cmNoYXNlPy5kb2N1bWVudF9udW1iZXIgfHwgbm90ZS52b3VjaGVyX251bWJlciB8fCAnLSc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0RlYml0ID0gbm90ZS50eXBlID09PSAnREVCSVQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtub3RlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXNEZWJpdCA/ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCcgOiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNEZWJpdCA/ICdEw6liaXRvJyA6ICdDcsOpZGl0byd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbVwiPntmb3JtYXRWYWx1ZShub3RlLmlzc3VlX2RhdGUsICdkYXRlJyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtXCI+e2RvY051bWJlcn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZSh0b3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gJHtiYWxhbmNlIDwgMCA/ICd0ZXh0LWdyZWVuLTYwMCcgOiAndGV4dC1yZWQtNjAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShiYWxhbmNlLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzW25vdGUuaWRdfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZUZpbmFuY2lhbE5vdGVBbW91bnRDaGFuZ2Uobm90ZS5pZCwgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25CbHVyPXsoKSA9PiBoYW5kbGVGaW5hbmNpYWxOb3RlQW1vdW50Q2hhbmdlKG5vdGUuaWQsIGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50c1tub3RlLmlkXSA/PyAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgdGV4dC1yaWdodCBpbnB1dC1mb3JtIGJvcmRlciByb3VuZGVkIHAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BNb250byBhIGFwbGljYXIgcGFyYSBub3RhICR7ZG9jTnVtYmVyfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVGaW5hbmNpYWxOb3RlQW1vdW50Q2hhbmdlKG5vdGUuaWQsIGJhbGFuY2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHAtMS41IHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6YmctaW5kaWdvLTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBob3Zlcjpib3JkZXItaW5kaWdvLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGxlbmFyIGNvbiBzYWxkbyBwZW5kaWVudGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQXBsaWNhciBzYWxkbyBjb21wbGV0byAoJHtmb3JtYXRWYWx1ZShiYWxhbmNlLCAnY3VycmVuY3knKX0pIHBhcmEgbm90YSAke2RvY051bWJlcn1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRmlsbERyaXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBzdGlja3kgYm90dG9tLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezV9IGNsYXNzTmFtZT1cInB5LTIgcGwtNCBwci0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbCBBcGxpY2Fkbzo8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkXCI+e2Zvcm1hdFZhbHVlKHRvdGFscy5maW5hbmNpYWxOb3Rlc0dyb3NzQW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiAtLS0gTUVESU9TIERFIFBBR08gLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+TWVkaW9zIGRlIFBhZ288L2gzPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVBZGRJdGVtfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIHJvdW5kZWQtbWQgaG92ZXI6YmctaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTFcIiAvPiBBw7FhZGlyIE1lZGlvXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+TWVkaW88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q3VlbnRhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkJhbmNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk7CuiBDaGVxdWU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmVjaGE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkltcG9ydGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicmVsYXRpdmUgcHktMy41IHBsLTMgcHItNCBzbTpwci02XCI+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1JlY2VpdmVkQ2hlY2sgPSBpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSFInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc093bkNoZWNrT3JUcmFuc2ZlciA9IGl0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ0NIRScgfHwgaXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnVFJBJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDYXNoID0gaXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnRUZFJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBZHZhbmNlQmFsYW5jZSA9IGl0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ1NBTCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU3lzdGVtUmV0ZW50aW9uID0gaXNTeXN0ZW1SZXRlbnRpb25QYXltZW50Um93KGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0dhbmFuY2lhc1JldGVudGlvbiA9IGlzR2FuYW5jaWFzUmV0ZW50aW9uSXRlbShpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNWZW5kb3JSZXQgPSBpc1ZlbmRvclJldGVudGlvbkl0ZW0oaXRlbSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0udGVtcElkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTUVESU86IFByb3BvcmNpw7NuIHBlcXVlw7FhICh+MTIlKSBwZXJvIG3DrW5pbW8gMTQwcHggcGFyYSBxdWUgcXVlcGEgZWwgdGV4dG8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gc206cGwtNiB3LTIvMTIgbWluLXctWzE0MHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5wYXltZW50X21ldGhvZF9jb2RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ3BheW1lbnRfbWV0aG9kX2NvZGUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgTWVkaW8gZGUgcGFnbyAke2luZGV4ICsgMX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3lzdGVtUmV0ZW50aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRUZFXCI+RWZlY3Rpdm88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDSEVcIj5DaGVxdWUgUHJvcGlvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVFJBXCI+VHJhbnNmZXJlbmNpYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNIUlwiPkNoZXF1ZSBSZWNpYmlkbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFKVVwiPkFqdXN0ZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZlbmRvckFkdmFuY2VCYWxhbmNlID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNBTFwiPlNhbGRvIEFudGljaXBhZG8gKHtmb3JtYXRWYWx1ZSh2ZW5kb3JBZHZhbmNlQmFsYW5jZSwgJ2N1cnJlbmN5Jyl9KTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0dhbmFuY2lhc1JldGVudGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17UEFZTUVOVF9NRVRIT0RfUkVURU5USU9OX0dBTkFOQ0lBU30+UmV0ZW5jacOzbiBkZSBJbXB1ZXN0byBhIGxhcyBHYW5hbmNpYXM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNWZW5kb3JSZXQgJiYgaXRlbS5yZXRlbnRpb25fdGF4X2lkICE9IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e2J1aWxkVmVuZG9yUmV0ZW50aW9uUGF5bWVudENvZGUoaXRlbS5yZXRlbnRpb25fdGF4X2lkKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2ZW5kb3JSZXRlbnRpb25TZWxlY3RMYWJlbChpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ1VFTlRBIENPTlRBQkxFOiBFcyBlbCBjYW1wbyBtw6FzIGltcG9ydGFudGUsIGxlIGRhbW9zIG3DoXMgZXNwYWNpbyAofjI1JSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB3LTMvMTIgbWluLXctWzIyMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2l0ZW0udWlfYWNjb3VudF9jb2RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtpdGVtLmNoYXJ0X2FjY291bnQ/Lm5hbWUgPz8gbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KHZhbCkgPT4gaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ3VpX2FjY291bnRfY29kZScsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUl0ZW1Db2RlU3VibWl0KGl0ZW0udGVtcElkLCAnYWNjb3VudCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gb3Blbk1vZGFsKHsgdHlwZTogJ2l0ZW1BY2NvdW50JywgaW5kZXggfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAnY2hhcnRfYWNjb3VudCcsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaXRlbS50ZW1wSWQsICd1aV9hY2NvdW50X2NvZGUnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3lzdGVtUmV0ZW50aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQkFOQ086IEVzcGFjaW8gbWVkaW8gKH4xNiUpICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdy0yLzEyIG1pbi13LVsxODBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2lzQ2FzaCB8fCBpc1N5c3RlbVJldGVudGlvbiA/ICdpbnZpc2libGUnIDogJyd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17aXRlbS51aV9iYW5rX2NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtpdGVtLmJhbmtfbmFtZSA/PyBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KHZhbCkgPT4gaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ3VpX2JhbmtfY29kZScsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVJdGVtQ29kZVN1Ym1pdChpdGVtLnRlbXBJZCwgJ2JhbmsnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBvcGVuTW9kYWwoeyB0eXBlOiAnaXRlbUJhbmsnLCBpbmRleCB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ2JhbmtfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ2JhbmtfbmFtZScsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAndWlfYmFua19jb2RlJywgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQWR2YW5jZUJhbGFuY2UgfHwgaXNSZWNlaXZlZENoZWNrIHx8IGlzU3lzdGVtUmV0ZW50aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSRUZFUkVOQ0lBOiBFc3BhY2lvIG1lZGlvICh+MTYlKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHctMi8xMiBtaW4tdy1bMTgwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtpc0Nhc2ggfHwgaXNTeXN0ZW1SZXRlbnRpb24gPyAnaW52aXNpYmxlJyA6ICcnfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1JlY2VpdmVkQ2hlY2sgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtpdGVtLnVpX2NoZWNrX3NlYXJjaH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5jaGVja19udW1iZXIgPyBgQ2hlcXVlICMke2l0ZW0uY2hlY2tfbnVtYmVyfWAgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAndWlfY2hlY2tfc2VhcmNoJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSXRlbUNvZGVTdWJtaXQoaXRlbS50ZW1wSWQsICdyZWNlaXZlZF9jaGVjaycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gb3Blbk1vZGFsKHsgdHlwZTogJ2l0ZW1SZWNlaXZlZENoZWNrJywgaW5kZXggfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAncmVjZWl2ZWRfY2hlY2tfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAndmFsdWUnLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAnYmFua19pZCcsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaXRlbS50ZW1wSWQsICdiYW5rX25hbWUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAnY2hlY2tfbnVtYmVyJywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ2NoZWNrX2RhdGUnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAndWlfY2hlY2tfc2VhcmNoJywgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaXRlbS50ZW1wSWQsICd1aV9yZWNlaXZlZF9ob2xkZXInLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ3VpX3JlY2VpdmVkX2N1aXQnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ3VpX3JlY2VpdmVkX3JlZmVyZW5jZScsICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaG9sZGVyID0gaXRlbS51aV9yZWNlaXZlZF9ob2xkZXIgPz8gaXRlbS5yZWNlaXZlZF9jaGVjaz8uY2hlY2tfaG9sZGVyID8/ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VpdCA9IGl0ZW0udWlfcmVjZWl2ZWRfY3VpdCA/PyBpdGVtLnJlY2VpdmVkX2NoZWNrPy5pc3N1ZXJfY3VpdCA/PyAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZmVyZW5jZSA9IGl0ZW0udWlfcmVjZWl2ZWRfcmVmZXJlbmNlID8/IGl0ZW0ucmVjZWl2ZWRfY2hlY2s/LnJlZmVyZW5jZV9udW1iZXIgPz8gJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWhvbGRlciAmJiAhY3VpdCkgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWZlcmVuY2UgPyA8ZGl2PlJlZmVyZW5jaWE6IHtyZWZlcmVuY2V9PC9kaXY+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2hvbGRlciA/IDxkaXY+RW1pc29yOiB7aG9sZGVyfTwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWl0ID8gPGRpdj5DVUlUOiB7Y3VpdH08L2Rpdj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQWR2YW5jZUJhbGFuY2UgfHwgaXNTeXN0ZW1SZXRlbnRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmNoZWNrX251bWJlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlSXRlbUNoYW5nZShpdGVtLnRlbXBJZCwgJ2NoZWNrX251bWJlcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dFN0eWxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17aXNPd25DaGVja09yVHJhbnNmZXIgPyBcIk7CuiBDaGVxdWUgLyBSZWYuXCIgOiBcIlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgUmVmZXJlbmNpYSAke2luZGV4ICsgMX1gfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGRUNIQTogRXNwYWNpbyBjb21wYWN0byAofjEyJSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB3LTEvMTIgbWluLXctWzEzMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17aXNDYXNoIHx8IGlzU3lzdGVtUmV0ZW50aW9uID8gJ2ludmlzaWJsZScgOiAnJ30+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQWR2YW5jZUJhbGFuY2UgfHwgaXNSZWNlaXZlZENoZWNrIHx8IGlzU3lzdGVtUmV0ZW50aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmNoZWNrX2RhdGUgPyBmb3JtYXREYXRlRm9ySW5wdXQobmV3IERhdGUoaXRlbS5jaGVja19kYXRlKSkgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAnY2hlY2tfZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEZlY2hhICR7aW5kZXggKyAxfWB9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSU1QT1JURTogRXNwYWNpbyBjb21wYWN0byAofjEyJSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB3LTEvMTIgbWluLXctWzEyMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlY2VpdmVkQ2hlY2t9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0udmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGl0ZW0udGVtcElkLCAndmFsdWUnLCBudW0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtpbnB1dFN0eWxlfSB0ZXh0LXJpZ2h0IGZsZXgtMSBtaW4tdy0wYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgSW1wb3J0ZSAke2luZGV4ICsgMX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNSZWNlaXZlZENoZWNrICYmICFpc1N5c3RlbVJldGVudGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsbFBheW1lbnRJdGVtRnJvbUFwcGxpZWRUb3RhbChpdGVtLnRlbXBJZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0b3RhbHMuZ3Jvc3NBbW91bnQgPD0gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBwLTEuNSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOmJnLWluZGlnby01MCByb3VuZGVkIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6Ym9yZGVyLWluZGlnby0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb21wbGV0YXIgY29uIGVsIGZhbHRhbnRlIHJlc3BlY3RvIGFsIHRvdGFsIGFwbGljYWRvIChleGNsdXllIGVzdGEgbMOtbmVhKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDb21wbGV0YXIgdmFsb3IgY29uIGVsIGZhbHRhbnRlIHJlc3BlY3RvIGFsIHRvdGFsIGFwbGljYWRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUZpbGxEcmlwIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCT1TDk04gRUxJTUlOQVI6IEVzcGFjaW8gbcOtbmltbyBhdXRvbcOhdGljbyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC0zIHByLTQgdGV4dC1yaWdodCBzbTpwci02IHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNTeXN0ZW1SZXRlbnRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVJdGVtKGl0ZW0udGVtcElkKX0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMCBwLTFcIiBhcmlhLWxhYmVsPXtgRWxpbWluYXIgaXRlbSAke2luZGV4ICsgMX1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFUcmFzaCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Zm9vdCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs1fSBjbGFzc05hbWU9XCJweS0yIHBsLTQgcHItMyB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5Ub3RhbCBNZWRpb3MgZGUgUGFnbzo8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkXCI+e2Zvcm1hdFZhbHVlKHRvdGFscy50b3RhbFBhaWQsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rmb290PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIFRPVEFMRVMgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC04XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yIHAtNCBib3JkZXIgcm91bmRlZC1sZyBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkRlc2N1ZW50b3MgeSBSZXRlbmNpb25lczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBVSSBvY3VsdGE6IGRlc2N1ZW50byBlIGltcHVlc3RvcyBzb2JyZSBkZXNjdWVudG8gKGzDs2dpY2EgYWN0aXZhIGVuIHVzZU1lbW8geSBndWFyZGFkbylcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkaXNjb3VudFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+RGVzY3VlbnRvICgtKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImRpc2NvdW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hlYWRlckRhdGEuZGlzY291bnQgPT09IDAgfHwgaGVhZGVyRGF0YS5kaXNjb3VudCA9PSBudWxsID8gJycgOiBoZWFkZXJEYXRhLmRpc2NvdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUhlYWRlckNoYW5nZSgnZGlzY291bnQnLCBlLnRhcmdldC52YWx1ZSA9PT0gJycgPyAwIDogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtpbnB1dFN0eWxlfSB0ZXh0LXJpZ2h0YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge3RvdGFscy5hcHBsaWVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFscy5hcHBsaWVkVGF4ZXMubWFwKHRheCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3RheC50YXhfaWQgfHwgdGF4LmlkfSBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgY29sLXNwYW4tMlwiPnt0YXgudGF4X25hbWV9ICh7dGF4LnJhdGV9JSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgdGV4dC1yaWdodCB0ZXh0LWdyYXktODAwIGJnLWdyYXktMTAwIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB0LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2hlYWRlckRhdGEudmVuZG9yX2lkID8gJ1NpbiByZXRlbmNpb25lcyBhdXRvbcOhdGljYXMuJyA6ICdTZWxlY2Npb25lIHVuIHByb3ZlZWRvci4nfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgKi99XG4gICAgICAgICAgICAgICAgICAgIHtnYW5hbmNpYXNSZXRlbnRpb24gJiYgKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdhbkl0ZW0gPSBpdGVtcy5maW5kKGlzR2FuYW5jaWFzUmV0ZW50aW9uSXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkaXNwbGF5QW1vdW50ID0gZ2FuSXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gTnVtYmVyKGdhbkl0ZW0udmFsdWUpIHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IChnYW5hbmNpYXNSZXRlbnRpb24uYW1vdW50ID8/IDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRpc3BsYXlBbW91bnQgPD0gMCkgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJldGVuY2nDs24gSW1wdWVzdG8gYSBsYXMgR2FuYW5jaWFze2dhbmFuY2lhc1JldGVudGlvbi5jYXNlX2NvZGUgPyBgIChjYXNlICR7Z2FuYW5jaWFzUmV0ZW50aW9uLmNhc2VfY29kZX0pYCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgdGV4dC1yaWdodCB0ZXh0LWdyYXktODAwIGJnLWdyYXktMTAwIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShkaXNwbGF5QW1vdW50LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSkoKX1cbiAgICAgICAgICAgICAgICAgICAge3ZlbmRvclJldGVudGlvblRheGVzQWRkaXRpb25hbC5tYXAodnQgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcCA9IHZlbmRvclJldGVudGlvbnNQcmV2aWV3W3Z0LmlkXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJldGVudGlvbkl0ZW0gPSBpdGVtcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWZW5kb3JSZXRlbnRpb25JdGVtKGkpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChpLnJldGVudGlvbl90YXhfaWQgPT09IHZ0LmlkIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZVRheElkRnJvbVZlbmRvclJldGVudGlvbkNvZGUoaS5wYXltZW50X21ldGhvZF9jb2RlKSA9PT0gdnQuaWQpXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzcGxheUFtb3VudCA9IHJldGVudGlvbkl0ZW1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IE51bWJlcihyZXRlbnRpb25JdGVtLnZhbHVlKSB8fCAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAocD8uYW1vdW50ID8/IDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRpc3BsYXlBbW91bnQgPD0gMCkgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsYWJlbE5hbWUgPSAocD8udGF4X25hbWUgfHwgdnQubmFtZSB8fCAnJykudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dnQuaWR9IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFiZWxOYW1lID8gYFJldGVuY2nDs24gJHtsYWJlbE5hbWV9YCA6ICdSZXRlbmNpw7NuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgdGV4dC1ncmF5LTgwMCBiZy1ncmF5LTEwMCByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoZGlzcGxheUFtb3VudCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWdyYXktNTAgYm9yZGVyIHJvdW5kZWQtbGcgc3BhY2UteS0yIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaC1maXRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBtYi00XCI+UmVzdW1lbjwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc21cIj48c3Bhbj5JbXBvcnRlIEJydXRvOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy5ncm9zc0Ftb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFVJIG9jdWx0YTogZGVzY3VlbnRvIHkgcmV0ZW5jaW9uZXMgc29icmUgZGVzY3VlbnRvIGVuIHJlc3VtZW4gKHRvdGFscy5yZW1haW5pbmdUb1BheSB5YSB1c2EgbmV0QW1vdW50VG9QYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+PHNwYW4+RGVzY3VlbnRvOjwvc3Bhbj4gPHNwYW4+LSB7Zm9ybWF0VmFsdWUodG90YWxzLmRpc2NvdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmV0ZW5jaW9uZXMgKHNvYnJlIGRlc2N1ZW50byk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPi0ge2Zvcm1hdFZhbHVlKHRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBmb250LWJvbGRcIj48c3Bhbj5OZXRvIGEgUGFnYXI6PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLnJlbWFpbmluZ1RvUGF5LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGZvbnQtYm9sZCB0ZXh0LWxnIGJvcmRlci10IHB0LTIgbXQtMlwiPjxzcGFuPlRPVEFMIFBBR0FETyAobWVkaW9zKTo8L3NwYW4+IDxzcGFuPntmb3JtYXRWYWx1ZSh0b3RhbHMudG90YWxQYWlkLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsoQm9vbGVhbihnYW5hbmNpYXNSZXRlbnRpb24gJiYgZ2FuYW5jaWFzUmV0ZW50aW9uLmFtb3VudCA+IDApIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICB2ZW5kb3JSZXRlbnRpb25UYXhlc0FkZGl0aW9uYWwuc29tZSh2dCA9PiAodmVuZG9yUmV0ZW50aW9uc1ByZXZpZXdbdnQuaWRdPy5hbW91bnQgPz8gMCkgPiAwKSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+SW5jbHV5ZSByZXRlbmNpb25lcyBhcGxpY2FkYXMgY29tbyBtZWRpb3MgZGUgcGFnby48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQk9UT05FUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG9yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIj5DYW5jZWxhcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVNhdmV9IGRpc2FibGVkPXtzYXZpbmcgfHwgaXNMb2FkaW5nUHVyY2hhc2VzfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyZWVuLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9IG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RNb2RhbH0gY29uZmlnPXttb2RhbENvbmZpZ30gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9vcmRlbmVzX3BhZ28vcGFnZXMvT3JkZW5lc1BhZ29Gb3JtUGFnZS50c3gifQ==