import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { notasFinancierasCompraModuleConfig } from "/src/features/notas_financieras_compra/notas_financieras_compra.config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getModuleBasePermission, getRequiredPermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const NotasFinancierasCompraListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(notasFinancierasCompraModuleConfig, getDefaultListDateRange());
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(notasFinancierasCompraModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const hasEditPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const hasDeletePermission = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEdit = (_note) => hasEditPermission;
  const canDelete = (_note) => hasDeletePermission;
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: notasFinancierasCompraModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit,
      canDelete
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx",
      lineNumber: 45,
      columnNumber: 5
    },
    this
  );
};
_s(NotasFinancierasCompraListPage, "yjB/rutd0ICjbFA72BDSbAuQTHI=", false, function() {
  return [useCrud, usePermissions];
});
_c = NotasFinancierasCompraListPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasCompraListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLDBDQUFzRTtBQUMvRSxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCQyw2QkFBNkI7QUFDL0QsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLGlDQUFpQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2hELFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJbkIsUUFBK0JDLG9DQUFvQ0ksd0JBQXdCLENBQUM7QUFFaEcsUUFBTSxFQUFFZSxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTW1CLG1CQUFtQmpCLHNCQUFzQkgsbUNBQW1DcUIsU0FBUztBQUMzRixRQUFNQyxhQUFhRixtQkFBbUJsQix3QkFBd0JrQixnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxvQkFBb0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFDakYsUUFBTUUsc0JBQXNCRixhQUFhSCxvQkFBb0JHLFlBQVksUUFBUSxJQUFJO0FBRXJGLFFBQU1HLFVBQVVBLENBQUNDLFVBQWlDSDtBQUNsRCxRQUFNSSxZQUFZQSxDQUFDRCxVQUFpQ0Y7QUFFcEQsTUFBSWQsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRXZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFWO0FBQUFBLE1BQ1Isb0JBQW9CTztBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFVLFFBQVE7QUFBQSxNQUNqQyxpQkFBaUJWLGFBQWFXLGFBQWE7QUFBQSxNQUMzQyxlQUFlWCxhQUFhWSxXQUFXO0FBQUEsTUFDdkMsdUJBQXVCO0FBQUEsTUFDdkI7QUFBQSxNQUNBO0FBQUE7QUFBQSxJQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQnlCO0FBR2pDO0FBQUV4QixHQXRDV0QsZ0NBQThCO0FBQUEsVUFJbkNOLFNBRTRCRSxjQUFjO0FBQUE7QUFBQThCLEtBTnJDMUI7QUFBOEIsSUFBQTBCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwibm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZyIsInVzZVBlcm1pc3Npb25zIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXREZWZhdWx0TGlzdERhdGVSYW5nZSIsIk5vdGFzRmluYW5jaWVyYXNDb21wcmFMaXN0UGFnZSIsIl9zIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiaXNBcHBlbmRpbmciLCJlcnJvciIsImRlbGV0ZUl0ZW0iLCJoYW5kbGVTb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVMb2FkTW9yZSIsImhhbmRsZVNlYXJjaCIsInNlYXJjaFBhcmFtcyIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJtb2R1bGVQZXJtaXNzaW9uIiwiYmFzZVJvdXRlIiwibW9kdWxlQmFzZSIsImhhc0VkaXRQZXJtaXNzaW9uIiwiaGFzRGVsZXRlUGVybWlzc2lvbiIsImNhbkVkaXQiLCJfbm90ZSIsImNhbkRlbGV0ZSIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90YXNGaW5hbmNpZXJhc0NvbXByYUxpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgbm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZywgdHlwZSBQdXJjaGFzZUZpbmFuY2lhbE5vdGUgfSBmcm9tICcuLi9ub3Rhc19maW5hbmNpZXJhc19jb21wcmEuY29uZmlnJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24sIGdldFJlcXVpcmVkUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdERhdGVSYW5nZSc7XG5cbmV4cG9ydCBjb25zdCBOb3Rhc0ZpbmFuY2llcmFzQ29tcHJhTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxQdXJjaGFzZUZpbmFuY2lhbE5vdGU+KG5vdGFzRmluYW5jaWVyYXNDb21wcmFNb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IG1vZHVsZVBlcm1pc3Npb24gPSBnZXRSZXF1aXJlZFBlcm1pc3Npb24obm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGhhc0VkaXRQZXJtaXNzaW9uID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG4gICAgY29uc3QgaGFzRGVsZXRlUGVybWlzc2lvbiA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdkZWxldGUnKSA6IHRydWU7XG5cbiAgICBjb25zdCBjYW5FZGl0ID0gKF9ub3RlOiBQdXJjaGFzZUZpbmFuY2lhbE5vdGUpID0+IGhhc0VkaXRQZXJtaXNzaW9uO1xuICAgIGNvbnN0IGNhbkRlbGV0ZSA9IChfbm90ZTogUHVyY2hhc2VGaW5hbmNpYWxOb3RlKSA9PiBoYXNEZWxldGVQZXJtaXNzaW9uO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxQdXJjaGFzZUZpbmFuY2lhbE5vdGU+XG4gICAgICAgICAgICBjb25maWc9e25vdGFzRmluYW5jaWVyYXNDb21wcmFNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfVxuICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgc2VhcmNoVGVybT17c2VhcmNoUGFyYW1zLnRlcm0gPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyU3RhcnQ9e3NlYXJjaFBhcmFtcy5zdGFydERhdGUgPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyRW5kPXtzZWFyY2hQYXJhbXMuZW5kRGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlcj17dHJ1ZX1cbiAgICAgICAgICAgIGNhbkVkaXQ9e2NhbkVkaXR9XG4gICAgICAgICAgICBjYW5EZWxldGU9e2NhbkRlbGV0ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXNfY29tcHJhL3BhZ2VzL05vdGFzRmluYW5jaWVyYXNDb21wcmFMaXN0UGFnZS50c3gifQ==