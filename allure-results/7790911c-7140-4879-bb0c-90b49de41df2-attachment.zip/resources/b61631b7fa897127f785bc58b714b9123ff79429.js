import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboards/pages/DashboardPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/dashboards/pages/DashboardPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ExchangeRateCard } from "/src/features/dashboards/components/ExchangeRateCard.tsx";
import { UpcomingPaymentsWidget } from "/src/features/dashboards/components/UpcomingPaymentsWidget.tsx";
import { ClientBalancesWidget } from "/src/features/dashboards/components/ClientBalancesWidget.tsx";
export const DashboardPage = () => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800", children: "Dashboard" }, void 0, false, {
      fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
      lineNumber: 30,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-gray-600", children: "Bienvenido al sistema ERP." }, void 0, false, {
      fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
      lineNumber: 31,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 mt-6", children: [
      /* @__PURE__ */ jsxDEV(ExchangeRateCard, {}, void 0, false, {
        fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
        lineNumber: 35,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 flex flex-col gap-6", children: [
        /* @__PURE__ */ jsxDEV(ClientBalancesWidget, {}, void 0, false, {
          fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
          lineNumber: 37,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(UpcomingPaymentsWidget, {}, void 0, false, {
          fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
          lineNumber: 38,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
        lineNumber: 36,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
      lineNumber: 34,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/dashboards/pages/DashboardPage.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
};
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/dashboards/pages/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/dashboards/pages/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSWixTQUFTQSx3QkFBd0I7QUFDakMsU0FBU0MsOEJBQThCO0FBQ3ZDLFNBQVNDLDRCQUE0QjtBQUU5QixhQUFNQyxnQkFBZ0JBLE1BQU07QUFFL0IsU0FDSSx1QkFBQyxTQUNHO0FBQUEsMkJBQUMsUUFBRyxXQUFVLG9DQUFtQyx5QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLElBQzFELHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsMENBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUc1RCx1QkFBQyxTQUFJLFdBQVUsOENBQ1g7QUFBQSw2QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsK0JBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBQ3JCLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRVI7QUFBRUMsS0FqQldEO0FBQWEsSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkV4Y2hhbmdlUmF0ZUNhcmQiLCJVcGNvbWluZ1BheW1lbnRzV2lkZ2V0IiwiQ2xpZW50QmFsYW5jZXNXaWRnZXQiLCJEYXNoYm9hcmRQYWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL2Rhc2hib2FyZC9wYWdlcy9EYXNoYm9hcmRQYWdlLnRzeFxuXG5pbXBvcnQgeyBFeGNoYW5nZVJhdGVDYXJkIH0gZnJvbSAnLi4vY29tcG9uZW50cy9FeGNoYW5nZVJhdGVDYXJkJztcbmltcG9ydCB7IFVwY29taW5nUGF5bWVudHNXaWRnZXQgfSBmcm9tICcuLi9jb21wb25lbnRzL1VwY29taW5nUGF5bWVudHNXaWRnZXQnO1xuaW1wb3J0IHsgQ2xpZW50QmFsYW5jZXNXaWRnZXQgfSBmcm9tICcuLi9jb21wb25lbnRzL0NsaWVudEJhbGFuY2VzV2lkZ2V0JztcblxuZXhwb3J0IGNvbnN0IERhc2hib2FyZFBhZ2UgPSAoKSA9PiB7XG4gICAgLy8gwqFBZGnDs3MgYSBsb3MgdXNlU3RhdGUgeSB1c2VFZmZlY3QgYXF1w60hXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPkRhc2hib2FyZDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtZ3JheS02MDBcIj5CaWVudmVuaWRvIGFsIHNpc3RlbWEgRVJQLjwvcD5cblxuICAgICAgICAgICAgey8qIEVsIGxheW91dCBzaWd1ZSBzaWVuZG8gcmVzcG9uc2FiaWxpZGFkIGRlbCBEYXNoYm9hcmQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTYgbXQtNlwiPlxuICAgICAgICAgICAgICAgIDxFeGNoYW5nZVJhdGVDYXJkIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIGZsZXggZmxleC1jb2wgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPENsaWVudEJhbGFuY2VzV2lkZ2V0IC8+XG4gICAgICAgICAgICAgICAgICAgIDxVcGNvbWluZ1BheW1lbnRzV2lkZ2V0IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9kYXNoYm9hcmRzL3BhZ2VzL0Rhc2hib2FyZFBhZ2UudHN4In0=