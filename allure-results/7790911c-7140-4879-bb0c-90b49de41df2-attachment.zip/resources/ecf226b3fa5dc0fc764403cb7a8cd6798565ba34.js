import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { searchByField } from "/src/services/apiService.ts";
import { ArrayStringInput } from "/src/components/common/ArrayStringInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { applyMask, validateMask, getMask } from "/src/utils/masks.ts";
import { isValidEmailList, isValidSingleEmail } from "/src/utils/emailValidation.ts";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getSelectOptionValues = (field, formData, dynamicOptions) => {
  const options = field.getOptions?.(formData) ?? dynamicOptions[String(field.name)] ?? field.options ?? [];
  return options.map((option) => {
    if (field.valueType === "boolean") {
      const val = option.value;
      if (typeof val === "boolean" && val === true) return "1";
      if (typeof val === "boolean" && val === false) return "0";
      if (val === 1 || val === "1" || val === "true") return "1";
      if (val === 0 || val === "0" || val === "false") return "0";
    }
    return String(option.value);
  });
};
const getSelectValueForForm = (field, rawValue) => {
  if (field.valueType === "boolean") {
    return rawValue === true ? "1" : rawValue === false ? "0" : "";
  }
  return rawValue == null ? "" : String(rawValue);
};
export const GenericFormPage = ({ config, initialData, onSave, mode, children, renderExtraContent, readOnly = false }) => {
  _s();
  const navigate = useNavigate();
  const [formData, setFormData] = useState(initialData || {});
  const [errors, setErrors] = useState({});
  const fieldRefs = useRef({});
  const [dynamicOptions, setDynamicOptions] = useState({});
  const [loadingOptions, setLoadingOptions] = useState(true);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [currentField, setCurrentField] = useState(null);
  useEffect(() => {
    const loadAllOptions = async () => {
      setLoadingOptions(true);
      const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly));
      const fieldsToLoad = allFields.filter((field) => field.loadOptions);
      const promises = fieldsToLoad.map((field) => field.loadOptions());
      try {
        const results = await Promise.all(promises);
        const newOptions = {};
        fieldsToLoad.forEach((field, index) => {
          newOptions[String(field.name)] = results[index];
        });
        setDynamicOptions(newOptions);
      } catch (error) {
        console.error("Error al cargar las opciones dinámicas del formulario:", error);
      } finally {
        setLoadingOptions(false);
      }
    };
    loadAllOptions();
  }, [config]);
  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);
  useEffect(() => {
    if (loadingOptions) return;
    const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly && f.type === "select"));
    setFormData((prev) => {
      let changed = false;
      const next = { ...prev };
      allFields.forEach((field) => {
        const rawValue = prev[field.name];
        const valueForSelect = getSelectValueForForm(field, rawValue);
        if (!valueForSelect) return;
        const optionValues = getSelectOptionValues(field, prev, dynamicOptions);
        if (optionValues.length > 0 && !optionValues.includes(valueForSelect)) {
          next[field.name] = null;
          changed = true;
        }
      });
      return changed ? next : prev;
    });
  }, [loadingOptions, dynamicOptions, config]);
  const clearFieldError = (name) => {
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  const applyFieldValue = (name, finalValue) => {
    setFormData((currentFormData) => {
      const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly));
      const fieldConfig = allFields.find((f) => String(f.name) === name);
      const updatedFormData = { ...currentFormData, [name]: finalValue };
      if (fieldConfig?.onChangeEffect) {
        const applyUpdates = (updates) => {
          Object.assign(updatedFormData, updates);
        };
        fieldConfig.onChangeEffect(finalValue, updatedFormData, applyUpdates);
      }
      allFields.forEach((field) => {
        if (String(field.name) === name) return;
        const isVisible = field.visibleWhen ? field.visibleWhen(updatedFormData) : true;
        const wasVisible = field.visibleWhen ? field.visibleWhen(currentFormData) : true;
        if (wasVisible && !isVisible) {
          updatedFormData[field.name] = null;
        }
      });
      return updatedFormData;
    });
  };
  const handleNumericFieldChange = (name, value) => {
    clearFieldError(name);
    applyFieldValue(name, value);
  };
  const handleChange = (e) => {
    const { name, value, type } = e.target;
    const { checked } = e.target;
    clearFieldError(name);
    let finalValue = value;
    const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly));
    const fieldConfig = allFields.find((f) => String(f.name) === name);
    if (fieldConfig?.mask && type === "text") {
      finalValue = applyMask(fieldConfig.mask, value);
    }
    if (type === "checkbox" && fieldConfig?.type !== "checkbox-group") {
      finalValue = checked;
    } else if (type === "checkbox" && fieldConfig?.type === "checkbox-group") {
      setFormData((currentFormData) => {
        const raw = currentFormData[name];
        const currentValues = Array.isArray(raw) ? raw.map(String) : [];
        const checkValue = String(value);
        const nextValues = checked ? [...currentValues, checkValue] : currentValues.filter((v) => v !== checkValue);
        const updatedFormData = { ...currentFormData, [name]: nextValues };
        if (fieldConfig?.onChangeEffect) {
          const applyUpdates = (updates) => {
            Object.assign(updatedFormData, updates);
          };
          fieldConfig.onChangeEffect(nextValues, updatedFormData, applyUpdates);
        }
        return updatedFormData;
      });
      return;
    } else if (fieldConfig?.valueType === "boolean") {
      finalValue = value === "1" || value === "true";
    } else if (fieldConfig?.valueType === "number") {
      finalValue = parseFloat(value) || 0;
    }
    applyFieldValue(name, finalValue);
  };
  const validate = () => {
    const newErrors = {};
    const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly));
    allFields.forEach((field) => {
      const isVisible = field.visibleWhen ? field.visibleWhen(formData) : true;
      if (!isVisible) return;
      const isMandatory = typeof field.mandatory === "function" ? field.mandatory(formData) : !!field.mandatory;
      const value = formData[field.name];
      let isEmpty = false;
      if (field.type === "checkbox-group") {
        isEmpty = !Array.isArray(value) || value.length === 0;
      } else {
        isEmpty = value == null || String(value).trim() === "";
      }
      if (isMandatory && isEmpty) {
        newErrors[String(field.name)] = "Este campo es requerido";
      }
      if (field.type === "email" && !isEmpty) {
        const stringValue = String(value);
        const isValid = field.allowMultipleEmails ? isValidEmailList(stringValue) : isValidSingleEmail(stringValue);
        if (!isValid) {
          newErrors[String(field.name)] = field.allowMultipleEmails ? "Uno o más emails no tienen un formato válido" : "El formato del email no es válido";
        }
      }
      if (field.type === "url" && !isEmpty && !/^https?:\/\//i.test(String(value).trim())) {
        newErrors[String(field.name)] = "La URL debe comenzar con http:// o https://";
      }
      if (isMandatory && field.mask && !isEmpty) {
        const stringValue = String(value);
        if (!validateMask(field.mask, stringValue)) {
          const mask = getMask(field.mask);
          newErrors[String(field.name)] = mask?.errorMessage || `${field.label} tiene un formato inválido`;
        }
      }
    });
    return newErrors;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (readOnly) return;
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      onSave(formData);
    } else {
      const allFields = config.form.block.flatMap((b) => b.fields.filter((f) => !f.detailOnly));
      const firstErrorFieldName = allFields.find((field) => validationErrors[String(field.name)])?.name;
      if (firstErrorFieldName) {
        fieldRefs.current[String(firstErrorFieldName)]?.focus();
      }
    }
  };
  const handleOpenSearchModal = (field) => {
    setCurrentField(field);
    setIsSearchModalOpen(true);
  };
  const handleCloseSearchModal = () => {
    setIsSearchModalOpen(false);
    setCurrentField(null);
  };
  const handleSelect = (selectedItem) => {
    if (!currentField || !currentField.relationalConfig) return;
    const { nameField, codeField } = currentField.relationalConfig;
    const idField = currentField.name;
    const mod = currentField.relationalConfig.moduleConfig;
    const itemCodeKey = mod?.listItemCodeKey ?? codeField;
    const itemNameKey = mod?.listItemNameKey ?? nameField;
    setFormData((prev) => ({
      ...prev,
      [idField]: selectedItem.id,
      [nameField]: selectedItem[itemNameKey],
      [codeField]: selectedItem[itemCodeKey]
    }));
    handleCloseSearchModal();
  };
  const resolveFieldReadonly = (field) => {
    if (readOnly) return true;
    if (typeof field.readonly === "function") return field.readonly(formData);
    return !!field.readonly;
  };
  const renderField = (field) => {
    const rawValue = formData[field.name];
    const arrayValue = Array.isArray(rawValue) ? rawValue.map(String) : [];
    const isFieldReadonly = resolveFieldReadonly(field);
    const assignRef = (el) => {
      fieldRefs.current[String(field.name)] = el;
    };
    switch (field.type) {
      case "select": {
        let valueForSelect = getSelectValueForForm(field, rawValue);
        const options = field.getOptions?.(formData) ?? dynamicOptions[String(field.name)] ?? field.options ?? [];
        const optionValues = getSelectOptionValues(field, formData, dynamicOptions);
        if (valueForSelect && optionValues.length > 0 && !optionValues.includes(valueForSelect)) {
          valueForSelect = "";
        }
        const showPlaceholder = !(isFieldReadonly && options.length === 1);
        return /* @__PURE__ */ jsxDEV(
          "select",
          {
            ref: assignRef,
            id: String(field.name),
            name: String(field.name),
            value: valueForSelect,
            onChange: handleChange,
            className: "block w-full px-3 py-2 mt-1 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            disabled: field.loadOptions && loadingOptions || isFieldReadonly,
            children: [
              loadingOptions && field.loadOptions && /* @__PURE__ */ jsxDEV("option", { children: "Cargando..." }, void 0, false, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 380,
                columnNumber: 65
              }, this),
              showPlaceholder && /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecciona una opción" }, void 0, false, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 381,
                columnNumber: 45
              }, this),
              options.map((option) => {
                let optionValue;
                if (field.valueType === "boolean") {
                  const val = option.value;
                  if (typeof val === "boolean" && val === true) {
                    optionValue = "1";
                  } else if (typeof val === "boolean" && val === false) {
                    optionValue = "0";
                  } else if (val === 1 || val === "1" || val === "true") {
                    optionValue = "1";
                  } else if (val === 0 || val === "0" || val === "false") {
                    optionValue = "0";
                  } else {
                    optionValue = String(option.value);
                  }
                } else {
                  optionValue = String(option.value);
                }
                return /* @__PURE__ */ jsxDEV("option", { value: optionValue, children: option.label }, optionValue, false, {
                  fileName: "/app/src/components/common/GenericFormPage.tsx",
                  lineNumber: 404,
                  columnNumber: 19
                }, this);
              })
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 371,
            columnNumber: 13
          },
          this
        );
      }
      case "checkbox-group":
        return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mt-2 md:grid-cols-3 lg:grid-cols-4", children: field.options?.map(
          (option, index) => (
            // ✅ CORRECCIÓN: Se convierte el valor a string para la key.
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center h-5", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  ref: index === 0 ? (el) => {
                    fieldRefs.current[String(field.name)] = el;
                  } : void 0,
                  id: `${String(field.name)}-${option.value}`,
                  name: String(field.name),
                  type: "checkbox",
                  value: String(option.value),
                  checked: arrayValue.includes(String(option.value)),
                  onChange: handleChange,
                  disabled: readOnly,
                  autoComplete: "off",
                  className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/components/common/GenericFormPage.tsx",
                  lineNumber: 417,
                  columnNumber: 37
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 416,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ml-3 text-sm", children: /* @__PURE__ */ jsxDEV("label", { htmlFor: `${String(field.name)}-${option.value}`, className: "font-medium text-gray-700", children: option.label }, void 0, false, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 432,
                columnNumber: 37
              }, this) }, void 0, false, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 431,
                columnNumber: 33
              }, this)
            ] }, String(option.value), true, {
              fileName: "/app/src/components/common/GenericFormPage.tsx",
              lineNumber: 415,
              columnNumber: 13
            }, this)
          )
        ) }, void 0, false, {
          fileName: "/app/src/components/common/GenericFormPage.tsx",
          lineNumber: 412,
          columnNumber: 11
        }, this);
      case "textarea": {
        const singleValueTextarea = rawValue == null ? "" : String(rawValue);
        return /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            ref: assignRef,
            id: String(field.name),
            name: String(field.name),
            value: singleValueTextarea,
            onChange: handleChange,
            placeholder: field.placeholder || "",
            rows: 4,
            autoComplete: "off",
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 443,
            columnNumber: 13
          },
          this
        );
      }
      case "date": {
        const singleValue = rawValue == null ? "" : String(rawValue);
        const dateValue = singleValue ? singleValue.split("T")[0] : "";
        return /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: assignRef,
            type: "date",
            id: String(field.name),
            name: String(field.name),
            value: dateValue,
            onChange: handleChange,
            autoComplete: "off",
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 460,
            columnNumber: 13
          },
          this
        );
      }
      case "url": {
        const urlValue = rawValue == null ? "" : String(rawValue);
        return /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: assignRef,
            type: "url",
            id: String(field.name),
            name: String(field.name),
            value: urlValue,
            onChange: handleChange,
            placeholder: field.placeholder || "",
            readOnly: isFieldReadonly,
            autoComplete: "off",
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 475,
            columnNumber: 13
          },
          this
        );
      }
      case "relational": {
        if (!field.relationalConfig) return null;
        const { codeField, nameField } = field.relationalConfig;
        const codeValue = formData[codeField];
        const nameValue = formData[nameField];
        const isProductField = field.relationalConfig.moduleConfig?.endpoint === articulosModuleConfig.endpoint || field.relationalConfig.moduleConfig?.relationalFields?.codeField === "sku";
        const maskToApply = isProductField ? "sku" : field.mask;
        const handleCodeChange = (newCode) => {
          setFormData((prev) => ({
            ...prev,
            [field.name]: null,
            // Limpiamos el ID
            [codeField]: newCode,
            // Actualizamos el código que se tipea
            [nameField]: null
            // Limpiamos el nombre
          }));
        };
        const handleCodeSubmit = async () => {
          if (!codeValue) return;
          if (!field.relationalConfig) return;
          const mod = field.relationalConfig.moduleConfig;
          const itemCodeKey = mod?.listItemCodeKey ?? codeField;
          const itemNameKey = mod?.listItemNameKey ?? nameField;
          try {
            const endpoint = field.relationalConfig.moduleConfig.endpoint;
            const item = await searchByField(endpoint, [{ fieldName: itemCodeKey, value: codeValue }]);
            if (item) {
              setFormData((prev) => ({
                ...prev,
                [field.name]: item.id,
                [codeField]: item[itemCodeKey],
                [nameField]: item[itemNameKey]
              }));
              toast.success(`'${item[itemNameKey]}' seleccionado.`);
            } else {
              toast.error(`No se encontró ningún ítem con el código "${codeValue}".`);
              setFormData((prev) => ({ ...prev, [field.name]: null, [nameField]: null }));
            }
          } catch (err) {
            toast.error("Error al buscar por código.");
            console.log(err);
          }
        };
        const handleClear = () => {
          setFormData((prev) => ({
            ...prev,
            [field.name]: null,
            [codeField]: null,
            [nameField]: null
          }));
        };
        return /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue,
            nameValue,
            onCodeChange: readOnly ? () => {
            } : handleCodeChange,
            onCodeSubmit: readOnly ? () => {
            } : handleCodeSubmit,
            onSearchClick: readOnly ? () => {
            } : () => handleOpenSearchModal(field),
            onClearClick: readOnly ? () => {
            } : handleClear,
            hasError: !!errors[String(field.name)],
            mask: maskToApply,
            disabled: readOnly
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 551,
            columnNumber: 13
          },
          this
        );
      }
      // ✅ NUEVO CASO: array-string
      case "array-string": {
        const arrayValues = Array.isArray(rawValue) ? rawValue : [];
        return /* @__PURE__ */ jsxDEV(
          ArrayStringInput,
          {
            values: arrayValues,
            onChange: (newValues) => {
              if (readOnly) return;
              setFormData((prev) => ({ ...prev, [field.name]: newValues }));
            },
            placeholder: field.placeholder,
            disabled: isFieldReadonly
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 568,
            columnNumber: 13
          },
          this
        );
      }
      case "number": {
        const numericValue = typeof rawValue === "number" ? rawValue : Number(rawValue) || 0;
        return /* @__PURE__ */ jsxDEV(
          DecimalInput,
          {
            ref: assignRef,
            id: String(field.name),
            name: String(field.name),
            value: numericValue,
            onChange: readOnly ? () => {
            } : (num) => handleNumericFieldChange(String(field.name), num),
            placeholder: field.placeholder || "",
            readOnly: isFieldReadonly,
            disabled: isFieldReadonly,
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 582,
            columnNumber: 13
          },
          this
        );
      }
      case "text":
      case "email":
      case "password":
      default: {
        const singleValue = rawValue == null ? "" : String(rawValue);
        const displayValue = field.mask ? applyMask(field.mask, singleValue) : singleValue;
        const mask = field.mask ? getMask(field.mask) : void 0;
        const inputType = field.type === "email" && field.allowMultipleEmails ? "text" : field.type;
        return /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: assignRef,
            type: inputType,
            id: String(field.name),
            name: String(field.name),
            value: displayValue,
            onChange: handleChange,
            placeholder: field.placeholder || "",
            readOnly: isFieldReadonly,
            autoComplete: "off",
            maxLength: mask?.maxLength,
            className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 605,
            columnNumber: 13
          },
          this
        );
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "edit" ? `Editar ${config.moduleName}` : `Crear Nuevo ${config.moduleName}` }, void 0, false, {
        fileName: "/app/src/components/common/GenericFormPage.tsx",
        lineNumber: 626,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "mt-6 space-y-8", noValidate: true, autoComplete: "off", children: [
        config.form.block.map(
          (block, blockIndex) => /* @__PURE__ */ jsxDEV("div", { className: blockIndex > 0 ? "pt-8 border-t border-gray-200" : "", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: block.name }, void 0, false, {
              fileName: "/app/src/components/common/GenericFormPage.tsx",
              lineNumber: 632,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 mt-4 md:grid-cols-2", children: block.fields.filter((f) => !f.detailOnly).map((field) => {
              const isVisible = field.visibleWhen ? field.visibleWhen(formData) : true;
              if (!isVisible) return null;
              const hasError = !!errors[String(field.name)];
              return /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { htmlFor: String(field.name), className: "block text-sm font-medium text-gray-700", children: [
                  field.label,
                  " ",
                  (typeof field.mandatory === "function" ? field.mandatory(formData) : !!field.mandatory) && isVisible && /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericFormPage.tsx",
                    lineNumber: 641,
                    columnNumber: 168
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/src/components/common/GenericFormPage.tsx",
                  lineNumber: 640,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: hasError ? "has-error" : "", children: renderField(field) }, void 0, false, {
                  fileName: "/app/src/components/common/GenericFormPage.tsx",
                  lineNumber: 643,
                  columnNumber: 45
                }, this),
                hasError && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors[String(field.name)] }, void 0, false, {
                  fileName: "/app/src/components/common/GenericFormPage.tsx",
                  lineNumber: 647,
                  columnNumber: 21
                }, this)
              ] }, String(field.name), true, {
                fileName: "/app/src/components/common/GenericFormPage.tsx",
                lineNumber: 639,
                columnNumber: 19
              }, this);
            }) }, void 0, false, {
              fileName: "/app/src/components/common/GenericFormPage.tsx",
              lineNumber: 633,
              columnNumber: 29
            }, this)
          ] }, block.name, true, {
            fileName: "/app/src/components/common/GenericFormPage.tsx",
            lineNumber: 631,
            columnNumber: 11
          }, this)
        ),
        children,
        renderExtraContent?.(formData),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 mt-6 border-t", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => navigate(getListReturnPath(config.baseRoute)),
              className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
              children: "Volver"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericFormPage.tsx",
              lineNumber: 659,
              columnNumber: 25
            },
            this
          ),
          !readOnly && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
              children: "Guardar Cambios"
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericFormPage.tsx",
              lineNumber: 667,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericFormPage.tsx",
          lineNumber: 658,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericFormPage.tsx",
        lineNumber: 629,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericFormPage.tsx",
      lineNumber: 625,
      columnNumber: 13
    }, this),
    currentField && currentField.relationalConfig && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isSearchModalOpen,
        onClose: handleCloseSearchModal,
        onSelect: handleSelect,
        config: currentField.relationalConfig.moduleConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/GenericFormPage.tsx",
        lineNumber: 678,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/components/common/GenericFormPage.tsx",
    lineNumber: 624,
    columnNumber: 5
  }, this);
};
_s(GenericFormPage, "4EqjWFED+WugmZWpPTeRWa0eoYU=", false, function() {
  return [useNavigate];
});
_c = GenericFormPage;
var _c;
$RefreshReg$(_c, "GenericFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd1dnRSxTQW9QeEQsVUFwUHdEOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZXaEUsT0FBT0EsU0FBU0MsVUFBVUMsV0FBV0MsY0FBYztBQUNuRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUV0QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFdBQVdDLGNBQWNDLGVBQWU7QUFDakQsU0FBU0Msa0JBQWtCQywwQkFBMEI7QUFDckQsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLHlCQUF5QjtBQWtCbEMsTUFBTUMsd0JBQXdCLENBQzFCQyxPQUNBQyxVQUNBQyxtQkFDVztBQUNYLFFBQU1DLFVBQVVILE1BQU1JLGFBQWFILFFBQVEsS0FBS0MsZUFBZUcsT0FBT0wsTUFBTU0sSUFBSSxDQUFDLEtBQUtOLE1BQU1HLFdBQVc7QUFDdkcsU0FBT0EsUUFBUUksSUFBSSxDQUFBQyxXQUFVO0FBQ3pCLFFBQUlSLE1BQU1TLGNBQWMsV0FBVztBQUMvQixZQUFNQyxNQUFNRixPQUFPRztBQUNuQixVQUFJLE9BQU9ELFFBQVEsYUFBYUEsUUFBUSxLQUFNLFFBQU87QUFDckQsVUFBSSxPQUFPQSxRQUFRLGFBQWFBLFFBQVEsTUFBTyxRQUFPO0FBQ3RELFVBQUlBLFFBQVEsS0FBS0EsUUFBUSxPQUFPQSxRQUFRLE9BQVEsUUFBTztBQUN2RCxVQUFJQSxRQUFRLEtBQUtBLFFBQVEsT0FBT0EsUUFBUSxRQUFTLFFBQU87QUFBQSxJQUM1RDtBQUNBLFdBQU9MLE9BQU9HLE9BQU9HLEtBQUs7QUFBQSxFQUM5QixDQUFDO0FBQ0w7QUFFQSxNQUFNQyx3QkFBd0IsQ0FDMUJaLE9BQ0FhLGFBQ1M7QUFDVCxNQUFJYixNQUFNUyxjQUFjLFdBQVc7QUFDL0IsV0FBT0ksYUFBYSxPQUFPLE1BQU1BLGFBQWEsUUFBUSxNQUFNO0FBQUEsRUFDaEU7QUFDQSxTQUFPQSxZQUFZLE9BQU8sS0FBS1IsT0FBT1EsUUFBUTtBQUNsRDtBQUVPLGFBQU1DLGtCQUFrQixDQUFtQixFQUFFQyxRQUFRQyxhQUFhQyxRQUFRQyxNQUFNQyxVQUFVQyxvQkFBb0JDLFdBQVcsTUFBK0IsTUFBTTtBQUFBQyxLQUFBO0FBQ2pLLFFBQU1DLFdBQVd0QyxZQUFZO0FBQzdCLFFBQU0sQ0FBQ2dCLFVBQVV1QixXQUFXLElBQUkxQyxTQUFZa0MsZUFBZSxDQUFDLENBQU07QUFDbEUsUUFBTSxDQUFDUyxRQUFRQyxTQUFTLElBQUk1QyxTQUFpQyxDQUFDLENBQUM7QUFDL0QsUUFBTTZDLFlBQVkzQyxPQUEyQyxDQUFDLENBQUM7QUFFL0QsUUFBTSxDQUFDa0IsZ0JBQWdCMEIsaUJBQWlCLElBQUk5QyxTQUF5QixDQUFDLENBQUM7QUFDdkUsUUFBTSxDQUFDK0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWhELFNBQVMsSUFBSTtBQUV6RCxRQUFNLENBQUNpRCxtQkFBbUJDLG9CQUFvQixJQUFJbEQsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ21ELGNBQWNDLGVBQWUsSUFBSXBELFNBQW9DLElBQUk7QUFHaEZDLFlBQVUsTUFBTTtBQUNaLFVBQU1vRCxpQkFBaUIsWUFBWTtBQUMvQkwsd0JBQWtCLElBQUk7QUFDdEIsWUFBTU0sWUFBWXJCLE9BQU9zQixLQUFLQyxNQUFNQyxRQUFRLENBQUFDLE1BQUtBLEVBQUVDLE9BQU9DLE9BQU8sQ0FBQUMsTUFBSyxDQUFDQSxFQUFFQyxVQUFVLENBQUM7QUFDcEYsWUFBTUMsZUFBZVQsVUFBVU0sT0FBTyxDQUFBMUMsVUFBU0EsTUFBTThDLFdBQVc7QUFFaEUsWUFBTUMsV0FBV0YsYUFBYXRDLElBQUksQ0FBQVAsVUFBU0EsTUFBTThDLFlBQWEsQ0FBQztBQUUvRCxVQUFJO0FBQ0EsY0FBTUUsVUFBVSxNQUFNQyxRQUFRQyxJQUFJSCxRQUFRO0FBQzFDLGNBQU1JLGFBQTZCLENBQUM7QUFDcENOLHFCQUFhTyxRQUFRLENBQUNwRCxPQUFPcUQsVUFBVTtBQUNuQ0YscUJBQVc5QyxPQUFPTCxNQUFNTSxJQUFJLENBQUMsSUFBSTBDLFFBQVFLLEtBQUs7QUFBQSxRQUNsRCxDQUFDO0FBQ0R6QiwwQkFBa0J1QixVQUFVO0FBQUEsTUFDaEMsU0FBU0csT0FBTztBQUNaQyxnQkFBUUQsTUFBTSwwREFBMERBLEtBQUs7QUFBQSxNQUNqRixVQUFDO0FBQ0d4QiwwQkFBa0IsS0FBSztBQUFBLE1BQzNCO0FBQUEsSUFDSjtBQUVBSyxtQkFBZTtBQUFBLEVBQ25CLEdBQUcsQ0FBQ3BCLE1BQU0sQ0FBQztBQUVYaEMsWUFBVSxNQUFNO0FBQ1osUUFBSWlDLGFBQWE7QUFDYlEsa0JBQVlSLFdBQVc7QUFBQSxJQUMzQjtBQUFBLEVBQ0osR0FBRyxDQUFDQSxXQUFXLENBQUM7QUFFaEJqQyxZQUFVLE1BQU07QUFDWixRQUFJOEMsZUFBZ0I7QUFFcEIsVUFBTU8sWUFBWXJCLE9BQU9zQixLQUFLQyxNQUFNQyxRQUFRLENBQUFDLE1BQUtBLEVBQUVDLE9BQU9DLE9BQU8sQ0FBQUMsTUFBSyxDQUFDQSxFQUFFQyxjQUFjRCxFQUFFYSxTQUFTLFFBQVEsQ0FBQztBQUUzR2hDLGdCQUFZLENBQUFpQyxTQUFRO0FBQ2hCLFVBQUlDLFVBQVU7QUFDZCxZQUFNQyxPQUFPLEVBQUUsR0FBR0YsS0FBSztBQUV2QnJCLGdCQUFVZ0IsUUFBUSxDQUFBcEQsVUFBUztBQUN2QixjQUFNYSxXQUFXNEMsS0FBS3pELE1BQU1NLElBQWU7QUFDM0MsY0FBTXNELGlCQUFpQmhELHNCQUFzQlosT0FBT2EsUUFBUTtBQUM1RCxZQUFJLENBQUMrQyxlQUFnQjtBQUVyQixjQUFNQyxlQUFlOUQsc0JBQXNCQyxPQUFPeUQsTUFBTXZELGNBQWM7QUFDdEUsWUFBSTJELGFBQWFDLFNBQVMsS0FBSyxDQUFDRCxhQUFhRSxTQUFTSCxjQUFjLEdBQUc7QUFFbkUsVUFBQ0QsS0FBOEIzRCxNQUFNTSxJQUFJLElBQUk7QUFDN0NvRCxvQkFBVTtBQUFBLFFBQ2Q7QUFBQSxNQUNKLENBQUM7QUFFRCxhQUFPQSxVQUFXQyxPQUFhRjtBQUFBQSxJQUNuQyxDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUM1QixnQkFBZ0IzQixnQkFBZ0JhLE1BQU0sQ0FBQztBQUUzQyxRQUFNaUQsa0JBQWtCQSxDQUFDMUQsU0FBaUI7QUFDdEMsUUFBSW1CLE9BQU9uQixJQUFJLEdBQUc7QUFDZG9CLGdCQUFVLENBQUErQixTQUFRO0FBQ2QsY0FBTVEsWUFBWSxFQUFFLEdBQUdSLEtBQUs7QUFDNUIsZUFBT1EsVUFBVTNELElBQUk7QUFDckIsZUFBTzJEO0FBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKO0FBRUEsUUFBTUMsa0JBQWtCQSxDQUNwQjVELE1BQ0E2RCxlQUNDO0FBQ0QzQyxnQkFBWSxDQUFBNEMsb0JBQW1CO0FBQzNCLFlBQU1oQyxZQUFZckIsT0FBT3NCLEtBQUtDLE1BQU1DLFFBQVEsQ0FBQUMsTUFBS0EsRUFBRUMsT0FBT0MsT0FBTyxDQUFBQyxNQUFLLENBQUNBLEVBQUVDLFVBQVUsQ0FBQztBQUNwRixZQUFNeUIsY0FBY2pDLFVBQVVrQyxLQUFLLENBQUEzQixNQUFLdEMsT0FBT3NDLEVBQUVyQyxJQUFJLE1BQU1BLElBQUk7QUFDL0QsWUFBTWlFLGtCQUFrQixFQUFFLEdBQUdILGlCQUFpQixDQUFDOUQsSUFBSSxHQUFHNkQsV0FBVztBQUVqRSxVQUFJRSxhQUFhRyxnQkFBZ0I7QUFDN0IsY0FBTUMsZUFBZUEsQ0FBQ0MsWUFBd0I7QUFDMUNDLGlCQUFPQyxPQUFPTCxpQkFBaUJHLE9BQU87QUFBQSxRQUMxQztBQUNBTCxvQkFBWUcsZUFBZUwsWUFBWUksaUJBQWlCRSxZQUFZO0FBQUEsTUFDeEU7QUFFQXJDLGdCQUFVZ0IsUUFBUSxDQUFBcEQsVUFBUztBQUN2QixZQUFJSyxPQUFPTCxNQUFNTSxJQUFJLE1BQU1BLEtBQU07QUFFakMsY0FBTXVFLFlBQVk3RSxNQUFNOEUsY0FBYzlFLE1BQU04RSxZQUFZUCxlQUFvQixJQUFJO0FBQ2hGLGNBQU1RLGFBQWEvRSxNQUFNOEUsY0FBYzlFLE1BQU04RSxZQUFZVixlQUFlLElBQUk7QUFFNUUsWUFBSVcsY0FBYyxDQUFDRixXQUFXO0FBRTFCLFVBQUNOLGdCQUF5Q3ZFLE1BQU1NLElBQUksSUFBSTtBQUFBLFFBQzVEO0FBQUEsTUFDSixDQUFDO0FBRUQsYUFBT2lFO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNUywyQkFBMkJBLENBQUMxRSxNQUFjSyxVQUFrQjtBQUM5RHFELG9CQUFnQjFELElBQUk7QUFDcEI0RCxvQkFBZ0I1RCxNQUFNSyxLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNc0UsZUFBZUEsQ0FBQ0MsTUFBcUY7QUFDdkcsVUFBTSxFQUFFNUUsTUFBTUssT0FBTzZDLEtBQUssSUFBSTBCLEVBQUVDO0FBQ2hDLFVBQU0sRUFBRUMsUUFBUSxJQUFJRixFQUFFQztBQUV0Qm5CLG9CQUFnQjFELElBQUk7QUFFcEIsUUFBSTZELGFBQTBEeEQ7QUFDOUQsVUFBTXlCLFlBQVlyQixPQUFPc0IsS0FBS0MsTUFBTUMsUUFBUSxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPQyxPQUFPLENBQUFDLE1BQUssQ0FBQ0EsRUFBRUMsVUFBVSxDQUFDO0FBQ3BGLFVBQU15QixjQUFjakMsVUFBVWtDLEtBQUssQ0FBQTNCLE1BQUt0QyxPQUFPc0MsRUFBRXJDLElBQUksTUFBTUEsSUFBSTtBQUcvRCxRQUFJK0QsYUFBYWdCLFFBQVE3QixTQUFTLFFBQVE7QUFDdENXLG1CQUFhM0UsVUFBVTZFLFlBQVlnQixNQUFNMUUsS0FBSztBQUFBLElBQ2xEO0FBRUEsUUFBSTZDLFNBQVMsY0FBY2EsYUFBYWIsU0FBUyxrQkFBa0I7QUFDL0RXLG1CQUFhaUI7QUFBQUEsSUFDakIsV0FBVzVCLFNBQVMsY0FBY2EsYUFBYWIsU0FBUyxrQkFBa0I7QUFDdEVoQyxrQkFBWSxDQUFBNEMsb0JBQW1CO0FBQzNCLGNBQU1rQixNQUFNbEIsZ0JBQWdCOUQsSUFBZTtBQUMzQyxjQUFNaUYsZ0JBQTBCQyxNQUFNQyxRQUFRSCxHQUFHLElBQUlBLElBQUkvRSxJQUFJRixNQUFNLElBQUk7QUFDdkUsY0FBTXFGLGFBQWFyRixPQUFPTSxLQUFLO0FBQy9CLGNBQU1nRixhQUFhUCxVQUNiLENBQUMsR0FBR0csZUFBZUcsVUFBVSxJQUM3QkgsY0FBYzdDLE9BQU8sQ0FBQWtELE1BQUtBLE1BQU1GLFVBQVU7QUFDaEQsY0FBTW5CLGtCQUFrQixFQUFFLEdBQUdILGlCQUFpQixDQUFDOUQsSUFBSSxHQUFHcUYsV0FBVztBQUVqRSxZQUFJdEIsYUFBYUcsZ0JBQWdCO0FBQzdCLGdCQUFNQyxlQUFlQSxDQUFDQyxZQUF3QjtBQUMxQ0MsbUJBQU9DLE9BQU9MLGlCQUFpQkcsT0FBTztBQUFBLFVBQzFDO0FBQ0FMLHNCQUFZRyxlQUFlbUIsWUFBWXBCLGlCQUFpQkUsWUFBWTtBQUFBLFFBQ3hFO0FBRUEsZUFBT0Y7QUFBQUEsTUFDWCxDQUFDO0FBQ0Q7QUFBQSxJQUNKLFdBQVdGLGFBQWE1RCxjQUFjLFdBQVc7QUFDN0MwRCxtQkFBYXhELFVBQVUsT0FBT0EsVUFBVTtBQUFBLElBQzVDLFdBQVcwRCxhQUFhNUQsY0FBYyxVQUFVO0FBQzVDMEQsbUJBQWEwQixXQUFXbEYsS0FBSyxLQUFLO0FBQUEsSUFDdEM7QUFFQXVELG9CQUFnQjVELE1BQU02RCxVQUFVO0FBQUEsRUFDcEM7QUFFQSxRQUFNMkIsV0FBV0EsTUFBOEI7QUFDM0MsVUFBTTdCLFlBQW9DLENBQUM7QUFDM0MsVUFBTTdCLFlBQVlyQixPQUFPc0IsS0FBS0MsTUFBTUMsUUFBUSxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPQyxPQUFPLENBQUFDLE1BQUssQ0FBQ0EsRUFBRUMsVUFBVSxDQUFDO0FBRXBGUixjQUFVZ0IsUUFBUSxDQUFBcEQsVUFBUztBQUN2QixZQUFNNkUsWUFBWTdFLE1BQU04RSxjQUFjOUUsTUFBTThFLFlBQVk3RSxRQUFRLElBQUk7QUFDcEUsVUFBSSxDQUFDNEUsVUFBVztBQUVoQixZQUFNa0IsY0FBYyxPQUFPL0YsTUFBTWdHLGNBQWMsYUFBYWhHLE1BQU1nRyxVQUFVL0YsUUFBUSxJQUFJLENBQUMsQ0FBQ0QsTUFBTWdHO0FBQ2hHLFlBQU1yRixRQUFRVixTQUFTRCxNQUFNTSxJQUFlO0FBQzVDLFVBQUkyRixVQUFVO0FBQ2QsVUFBSWpHLE1BQU13RCxTQUFTLGtCQUFrQjtBQUNqQ3lDLGtCQUFVLENBQUNULE1BQU1DLFFBQVE5RSxLQUFLLEtBQUtBLE1BQU1tRCxXQUFXO0FBQUEsTUFDeEQsT0FBTztBQUNIbUMsa0JBQVV0RixTQUFTLFFBQVFOLE9BQU9NLEtBQUssRUFBRXVGLEtBQUssTUFBTTtBQUFBLE1BQ3hEO0FBR0EsVUFBSUgsZUFBZUUsU0FBUztBQUN4QmhDLGtCQUFVNUQsT0FBT0wsTUFBTU0sSUFBSSxDQUFDLElBQUk7QUFBQSxNQUNwQztBQUdBLFVBQUlOLE1BQU13RCxTQUFTLFdBQVcsQ0FBQ3lDLFNBQVM7QUFDcEMsY0FBTUUsY0FBYzlGLE9BQU9NLEtBQUs7QUFDaEMsY0FBTXlGLFVBQVVwRyxNQUFNcUcsc0JBQ2hCMUcsaUJBQWlCd0csV0FBVyxJQUM1QnZHLG1CQUFtQnVHLFdBQVc7QUFDcEMsWUFBSSxDQUFDQyxTQUFTO0FBQ1ZuQyxvQkFBVTVELE9BQU9MLE1BQU1NLElBQUksQ0FBQyxJQUFJTixNQUFNcUcsc0JBQ2hDLGlEQUNBO0FBQUEsUUFDVjtBQUFBLE1BQ0o7QUFHQSxVQUFJckcsTUFBTXdELFNBQVMsU0FBUyxDQUFDeUMsV0FBVyxDQUFDLGdCQUFnQkssS0FBS2pHLE9BQU9NLEtBQUssRUFBRXVGLEtBQUssQ0FBQyxHQUFHO0FBQ2pGakMsa0JBQVU1RCxPQUFPTCxNQUFNTSxJQUFJLENBQUMsSUFBSTtBQUFBLE1BQ3BDO0FBR0EsVUFBSXlGLGVBQWUvRixNQUFNcUYsUUFBUSxDQUFDWSxTQUFTO0FBQ3ZDLGNBQU1FLGNBQWM5RixPQUFPTSxLQUFLO0FBQ2hDLFlBQUksQ0FBQ2xCLGFBQWFPLE1BQU1xRixNQUFNYyxXQUFXLEdBQUc7QUFDeEMsZ0JBQU1kLE9BQU8zRixRQUFRTSxNQUFNcUYsSUFBSTtBQUMvQnBCLG9CQUFVNUQsT0FBT0wsTUFBTU0sSUFBSSxDQUFDLElBQUkrRSxNQUFNa0IsZ0JBQWdCLEdBQUd2RyxNQUFNd0csS0FBSztBQUFBLFFBQ3hFO0FBQUEsTUFDSjtBQUFBLElBQ0osQ0FBQztBQUVELFdBQU92QztBQUFBQSxFQUNYO0FBRUEsUUFBTXdDLGVBQWVBLENBQUN2QixNQUF1QjtBQUN6Q0EsTUFBRXdCLGVBQWU7QUFDakIsUUFBSXJGLFNBQVU7QUFFZCxVQUFNc0YsbUJBQW1CYixTQUFTO0FBQ2xDcEUsY0FBVWlGLGdCQUFnQjtBQUUxQixRQUFJaEMsT0FBT2lDLEtBQUtELGdCQUFnQixFQUFFN0MsV0FBVyxHQUFHO0FBQzVDN0MsYUFBT2hCLFFBQVE7QUFBQSxJQUNuQixPQUFPO0FBQ0gsWUFBTW1DLFlBQVlyQixPQUFPc0IsS0FBS0MsTUFBTUMsUUFBUSxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPQyxPQUFPLENBQUFDLE1BQUssQ0FBQ0EsRUFBRUMsVUFBVSxDQUFDO0FBQ3BGLFlBQU1pRSxzQkFBc0J6RSxVQUFVa0MsS0FBSyxDQUFBdEUsVUFBUzJHLGlCQUFpQnRHLE9BQU9MLE1BQU1NLElBQUksQ0FBQyxDQUFDLEdBQUdBO0FBRTNGLFVBQUl1RyxxQkFBcUI7QUFDckJsRixrQkFBVW1GLFFBQVF6RyxPQUFPd0csbUJBQW1CLENBQUMsR0FBR0UsTUFBTTtBQUFBLE1BQzFEO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxRQUFNQyx3QkFBd0JBLENBQUNoSCxVQUE4QjtBQUN6RGtDLG9CQUFnQmxDLEtBQUs7QUFDckJnQyx5QkFBcUIsSUFBSTtBQUFBLEVBQzdCO0FBRUEsUUFBTWlGLHlCQUF5QkEsTUFBTTtBQUNqQ2pGLHlCQUFxQixLQUFLO0FBQzFCRSxvQkFBZ0IsSUFBSTtBQUFBLEVBQ3hCO0FBR0EsUUFBTWdGLGVBQWVBLENBQUNDLGlCQUFzQjtBQUN4QyxRQUFJLENBQUNsRixnQkFBZ0IsQ0FBQ0EsYUFBYW1GLGlCQUFrQjtBQUVyRCxVQUFNLEVBQUVDLFdBQVdDLFVBQVUsSUFBSXJGLGFBQWFtRjtBQUM5QyxVQUFNRyxVQUFVdEYsYUFBYTNCO0FBQzdCLFVBQU1rSCxNQUFNdkYsYUFBYW1GLGlCQUFpQks7QUFDMUMsVUFBTUMsY0FBY0YsS0FBS0csbUJBQW1CTDtBQUM1QyxVQUFNTSxjQUFjSixLQUFLSyxtQkFBbUJSO0FBRTVDN0YsZ0JBQVksQ0FBQWlDLFVBQVM7QUFBQSxNQUNqQixHQUFHQTtBQUFBQSxNQUNILENBQUM4RCxPQUFPLEdBQUdKLGFBQWFXO0FBQUFBLE1BQ3hCLENBQUNULFNBQVMsR0FBR0YsYUFBYVMsV0FBVztBQUFBLE1BQ3JDLENBQUNOLFNBQVMsR0FBR0gsYUFBYU8sV0FBVztBQUFBLElBQ3pDLEVBQUU7QUFFRlQsMkJBQXVCO0FBQUEsRUFDM0I7QUFFQSxRQUFNYyx1QkFBdUJBLENBQUMvSCxVQUF1QztBQUNqRSxRQUFJcUIsU0FBVSxRQUFPO0FBQ3JCLFFBQUksT0FBT3JCLE1BQU1nSSxhQUFhLFdBQVksUUFBT2hJLE1BQU1nSSxTQUFTL0gsUUFBUTtBQUN4RSxXQUFPLENBQUMsQ0FBQ0QsTUFBTWdJO0FBQUFBLEVBQ25CO0FBRUEsUUFBTUMsY0FBY0EsQ0FBQ2pJLFVBQThCO0FBQy9DLFVBQU1hLFdBQVdaLFNBQVNELE1BQU1NLElBQWU7QUFDL0MsVUFBTTRILGFBQWExQyxNQUFNQyxRQUFRNUUsUUFBUSxJQUFJQSxTQUFTTixJQUFJRixNQUFNLElBQUk7QUFDcEUsVUFBTThILGtCQUFrQkoscUJBQXFCL0gsS0FBSztBQUVsRCxVQUFNb0ksWUFBWUEsQ0FBQ0MsT0FBMkI7QUFDMUMxRyxnQkFBVW1GLFFBQVF6RyxPQUFPTCxNQUFNTSxJQUFJLENBQUMsSUFBSStIO0FBQUFBLElBQzVDO0FBRUEsWUFBUXJJLE1BQU13RCxNQUFJO0FBQUEsTUFDZCxLQUFLLFVBQVU7QUFDWCxZQUFJSSxpQkFBaUJoRCxzQkFBc0JaLE9BQU9hLFFBQVE7QUFFMUQsY0FBTVYsVUFBVUgsTUFBTUksYUFBYUgsUUFBUSxLQUFLQyxlQUFlRyxPQUFPTCxNQUFNTSxJQUFJLENBQUMsS0FBS04sTUFBTUcsV0FBVztBQUN2RyxjQUFNMEQsZUFBZTlELHNCQUFzQkMsT0FBT0MsVUFBVUMsY0FBYztBQUMxRSxZQUFJMEQsa0JBQWtCQyxhQUFhQyxTQUFTLEtBQUssQ0FBQ0QsYUFBYUUsU0FBU0gsY0FBYyxHQUFHO0FBQ3JGQSwyQkFBaUI7QUFBQSxRQUNyQjtBQUVBLGNBQU0wRSxrQkFBa0IsRUFBRUgsbUJBQW1CaEksUUFBUTJELFdBQVc7QUFDeEQsZUFDSjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csS0FBS3NFO0FBQUFBLFlBQ0wsSUFBSS9ILE9BQU9MLE1BQU1NLElBQUk7QUFBQSxZQUNyQixNQUFNRCxPQUFPTCxNQUFNTSxJQUFJO0FBQUEsWUFDdkIsT0FBT3NEO0FBQUFBLFlBQ1AsVUFBVXFCO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBQ1YsVUFBV2pGLE1BQU04QyxlQUFlakIsa0JBQW1Cc0c7QUFBQUEsWUFFbER0RztBQUFBQSxnQ0FBa0I3QixNQUFNOEMsZUFBZSx1QkFBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDMUR3RixtQkFBbUIsdUJBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FDekRuSSxRQUFRSSxJQUFJLENBQUFDLFdBQVU7QUFFbkIsb0JBQUkrSDtBQUNKLG9CQUFJdkksTUFBTVMsY0FBYyxXQUFXO0FBRS9CLHdCQUFNQyxNQUFNRixPQUFPRztBQUVuQixzQkFBSSxPQUFPRCxRQUFRLGFBQWFBLFFBQVEsTUFBTTtBQUMxQzZILGtDQUFjO0FBQUEsa0JBQ2xCLFdBQVcsT0FBTzdILFFBQVEsYUFBYUEsUUFBUSxPQUFPO0FBQ2xENkgsa0NBQWM7QUFBQSxrQkFDbEIsV0FBVzdILFFBQVEsS0FBS0EsUUFBUSxPQUFPQSxRQUFRLFFBQVE7QUFDbkQ2SCxrQ0FBYztBQUFBLGtCQUNsQixXQUFXN0gsUUFBUSxLQUFLQSxRQUFRLE9BQU9BLFFBQVEsU0FBUztBQUNwRDZILGtDQUFjO0FBQUEsa0JBQ2xCLE9BQU87QUFDSEEsa0NBQWNsSSxPQUFPRyxPQUFPRyxLQUFLO0FBQUEsa0JBQ3JDO0FBQUEsZ0JBQ0osT0FBTztBQUNINEgsZ0NBQWNsSSxPQUFPRyxPQUFPRyxLQUFLO0FBQUEsZ0JBQ3JDO0FBQ0EsdUJBQ0ksdUJBQUMsWUFBeUIsT0FBTzRILGFBQWMvSCxpQkFBT2dHLFNBQXpDK0IsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLGNBRXBFLENBQUM7QUFBQTtBQUFBO0FBQUEsVUFuQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0NBO0FBQUEsTUFFUjtBQUFBLE1BQ0EsS0FBSztBQUNPLGVBQ0osdUJBQUMsU0FBSSxXQUFVLDZEQUNWdkksZ0JBQU1HLFNBQVNJO0FBQUFBLFVBQUksQ0FBQ0MsUUFBUTZDO0FBQUFBO0FBQUFBLFlBRXpCLHVCQUFDLFNBQStCLFdBQVUsb0JBQ3RDO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLEtBQUtBLFVBQVUsSUFBSSxDQUFDZ0YsT0FBTztBQUFFMUcsOEJBQVVtRixRQUFRekcsT0FBT0wsTUFBTU0sSUFBSSxDQUFDLElBQUkrSDtBQUFBQSxrQkFBSSxJQUFJRztBQUFBQSxrQkFDN0UsSUFBSSxHQUFHbkksT0FBT0wsTUFBTU0sSUFBSSxDQUFDLElBQUlFLE9BQU9HLEtBQUs7QUFBQSxrQkFDekMsTUFBTU4sT0FBT0wsTUFBTU0sSUFBSTtBQUFBLGtCQUN2QixNQUFLO0FBQUEsa0JBRUwsT0FBT0QsT0FBT0csT0FBT0csS0FBSztBQUFBLGtCQUMxQixTQUFTdUgsV0FBV25FLFNBQVMxRCxPQUFPRyxPQUFPRyxLQUFLLENBQUM7QUFBQSxrQkFDakQsVUFBVXNFO0FBQUFBLGtCQUNWLFVBQVU1RDtBQUFBQSxrQkFDVixjQUFhO0FBQUEsa0JBQ2IsV0FBVTtBQUFBO0FBQUEsZ0JBWGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV3FGLEtBWnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDWCxpQ0FBQyxXQUFNLFNBQVMsR0FBR2hCLE9BQU9MLE1BQU1NLElBQUksQ0FBQyxJQUFJRSxPQUFPRyxLQUFLLElBQUksV0FBVSw2QkFDOURILGlCQUFPZ0csU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQXBCTW5HLE9BQU9HLE9BQU9HLEtBQUssR0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQTtBQUFBLFFBQ0gsS0F6Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLE1BRVIsS0FBSyxZQUFZO0FBQ2IsY0FBTThILHNCQUFzQjVILFlBQVksT0FBTyxLQUFLUixPQUFPUSxRQUFRO0FBQzNELGVBQ0o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLEtBQUt1SDtBQUFBQSxZQUNMLElBQUkvSCxPQUFPTCxNQUFNTSxJQUFJO0FBQUEsWUFDckIsTUFBTUQsT0FBT0wsTUFBTU0sSUFBSTtBQUFBLFlBQ3ZCLE9BQU9tSTtBQUFBQSxZQUNQLFVBQVV4RDtBQUFBQSxZQUNWLGFBQWFqRixNQUFNMEksZUFBZTtBQUFBLFlBQ2xDLE1BQU07QUFBQSxZQUNOLGNBQWE7QUFBQSxZQUNiLFdBQVU7QUFBQTtBQUFBLFVBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU21LO0FBQUEsTUFHM0s7QUFBQSxNQUNBLEtBQUssUUFBUTtBQUNULGNBQU1DLGNBQWM5SCxZQUFZLE9BQU8sS0FBS1IsT0FBT1EsUUFBUTtBQUMzRCxjQUFNK0gsWUFBWUQsY0FBY0EsWUFBWUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJO0FBQ3BELGVBQ0o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLEtBQUtUO0FBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsSUFBSS9ILE9BQU9MLE1BQU1NLElBQUk7QUFBQSxZQUNyQixNQUFNRCxPQUFPTCxNQUFNTSxJQUFJO0FBQUEsWUFDdkIsT0FBT3NJO0FBQUFBLFlBQ1AsVUFBVTNEO0FBQUFBLFlBQ1YsY0FBYTtBQUFBLFlBQ2IsV0FBVTtBQUFBO0FBQUEsVUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRbUs7QUFBQSxNQUczSztBQUFBLE1BQ0EsS0FBSyxPQUFPO0FBQ1IsY0FBTTZELFdBQVdqSSxZQUFZLE9BQU8sS0FBS1IsT0FBT1EsUUFBUTtBQUN4RCxlQUNJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxLQUFLdUg7QUFBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxJQUFJL0gsT0FBT0wsTUFBTU0sSUFBSTtBQUFBLFlBQ3JCLE1BQU1ELE9BQU9MLE1BQU1NLElBQUk7QUFBQSxZQUN2QixPQUFPd0k7QUFBQUEsWUFDUCxVQUFVN0Q7QUFBQUEsWUFDVixhQUFhakYsTUFBTTBJLGVBQWU7QUFBQSxZQUNsQyxVQUFVUDtBQUFBQSxZQUNWLGNBQWE7QUFBQSxZQUNiLFdBQVU7QUFBQTtBQUFBLFVBVmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVW1LO0FBQUEsTUFHM0s7QUFBQSxNQUNBLEtBQUssY0FBYztBQUNmLFlBQUksQ0FBQ25JLE1BQU1vSCxpQkFBa0IsUUFBTztBQUVwQyxjQUFNLEVBQUVFLFdBQVdELFVBQVUsSUFBSXJILE1BQU1vSDtBQUN2QyxjQUFNMkIsWUFBWTlJLFNBQVNxSCxTQUFvQjtBQUMvQyxjQUFNMEIsWUFBWS9JLFNBQVNvSCxTQUFvQjtBQUcvQyxjQUFNNEIsaUJBQWlCakosTUFBTW9ILGlCQUFpQkssY0FBY3lCLGFBQWFySixzQkFBc0JxSixZQUMzRmxKLE1BQU1vSCxpQkFBaUJLLGNBQWMwQixrQkFBa0I3QixjQUFjO0FBQ3pFLGNBQU04QixjQUFjSCxpQkFBaUIsUUFBUWpKLE1BQU1xRjtBQUVuRCxjQUFNZ0UsbUJBQW1CQSxDQUFDQyxZQUFvQjtBQUMxQzlILHNCQUFZLENBQUFpQyxVQUFTO0FBQUEsWUFDakIsR0FBR0E7QUFBQUEsWUFDSCxDQUFDekQsTUFBTU0sSUFBSSxHQUFHO0FBQUE7QUFBQSxZQUNkLENBQUNnSCxTQUFTLEdBQUdnQztBQUFBQTtBQUFBQSxZQUNiLENBQUNqQyxTQUFTLEdBQUc7QUFBQTtBQUFBLFVBQ2pCLEVBQUU7QUFBQSxRQUNOO0FBRUEsY0FBTWtDLG1CQUFtQixZQUFZO0FBQ2pDLGNBQUksQ0FBQ1IsVUFBVztBQUVoQixjQUFJLENBQUMvSSxNQUFNb0gsaUJBQWtCO0FBRTdCLGdCQUFNSSxNQUFNeEgsTUFBTW9ILGlCQUFpQks7QUFDbkMsZ0JBQU1DLGNBQWNGLEtBQUtHLG1CQUFtQkw7QUFDNUMsZ0JBQU1NLGNBQWNKLEtBQUtLLG1CQUFtQlI7QUFFNUMsY0FBSTtBQUNBLGtCQUFNNkIsV0FBV2xKLE1BQU1vSCxpQkFBaUJLLGFBQWF5QjtBQUNyRCxrQkFBTU0sT0FBTyxNQUFNbkssY0FBOEI2SixVQUFVLENBQUMsRUFBRU8sV0FBVy9CLGFBQWEvRyxPQUFPb0ksVUFBVSxDQUFDLENBQUM7QUFFekcsZ0JBQUlTLE1BQU07QUFDTmhJLDBCQUFZLENBQUFpQyxVQUFTO0FBQUEsZ0JBQ2pCLEdBQUdBO0FBQUFBLGdCQUNILENBQUN6RCxNQUFNTSxJQUFJLEdBQUdrSixLQUFLMUI7QUFBQUEsZ0JBQ25CLENBQUNSLFNBQVMsR0FBR2tDLEtBQUs5QixXQUFXO0FBQUEsZ0JBQzdCLENBQUNMLFNBQVMsR0FBR21DLEtBQUs1QixXQUFXO0FBQUEsY0FDakMsRUFBRTtBQUNGMUksb0JBQU13SyxRQUFRLElBQUlGLEtBQUs1QixXQUFXLENBQUMsaUJBQWlCO0FBQUEsWUFDeEQsT0FBTztBQUNIMUksb0JBQU1vRSxNQUFNLDZDQUE2Q3lGLFNBQVMsSUFBSTtBQUN0RXZILDBCQUFZLENBQUFpQyxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDekQsTUFBTU0sSUFBSSxHQUFHLE1BQU0sQ0FBQytHLFNBQVMsR0FBRyxLQUFLLEVBQUU7QUFBQSxZQUM1RTtBQUFBLFVBQ0osU0FBU3NDLEtBQUs7QUFDVnpLLGtCQUFNb0UsTUFBTSw2QkFBNkI7QUFDekNDLG9CQUFRcUcsSUFBSUQsR0FBRztBQUFBLFVBQ25CO0FBQUEsUUFDSjtBQUVBLGNBQU1FLGNBQWNBLE1BQU07QUFDdEJySSxzQkFBWSxDQUFBaUMsVUFBUztBQUFBLFlBQ2pCLEdBQUdBO0FBQUFBLFlBQ0gsQ0FBQ3pELE1BQU1NLElBQUksR0FBRztBQUFBLFlBQ2QsQ0FBQ2dILFNBQVMsR0FBRztBQUFBLFlBQ2IsQ0FBQ0QsU0FBUyxHQUFHO0FBQUEsVUFDakIsRUFBRTtBQUFBLFFBQ047QUFFQSxlQUNJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRztBQUFBLFlBQ0E7QUFBQSxZQUNBLGNBQWNoRyxXQUFXLE1BQU07QUFBQSxZQUFDLElBQUlnSTtBQUFBQSxZQUNwQyxjQUFjaEksV0FBVyxNQUFNO0FBQUEsWUFBQyxJQUFJa0k7QUFBQUEsWUFDcEMsZUFBZWxJLFdBQVcsTUFBTTtBQUFBLFlBQUMsSUFBSSxNQUFNMkYsc0JBQXNCaEgsS0FBSztBQUFBLFlBQ3RFLGNBQWNxQixXQUFXLE1BQU07QUFBQSxZQUFDLElBQUl3STtBQUFBQSxZQUNwQyxVQUFVLENBQUMsQ0FBQ3BJLE9BQU9wQixPQUFPTCxNQUFNTSxJQUFJLENBQUM7QUFBQSxZQUNyQyxNQUFNOEk7QUFBQUEsWUFDTixVQUFVL0g7QUFBQUE7QUFBQUEsVUFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTdUI7QUFBQSxNQUcvQjtBQUFBO0FBQUEsTUFFQSxLQUFLLGdCQUFnQjtBQUNqQixjQUFNeUksY0FBY3RFLE1BQU1DLFFBQVE1RSxRQUFRLElBQUlBLFdBQVc7QUFDekQsZUFDSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csUUFBUWlKO0FBQUFBLFlBQ1IsVUFBVSxDQUFDQyxjQUFjO0FBQ3JCLGtCQUFJMUksU0FBVTtBQUNkRywwQkFBWSxDQUFBaUMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3pELE1BQU1NLElBQUksR0FBR3lKLFVBQVUsRUFBRTtBQUFBLFlBQzlEO0FBQUEsWUFDQSxhQUFhL0osTUFBTTBJO0FBQUFBLFlBQ25CLFVBQVVQO0FBQUFBO0FBQUFBLFVBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTzhCO0FBQUEsTUFHdEM7QUFBQSxNQUNBLEtBQUssVUFBVTtBQUNYLGNBQU02QixlQUFlLE9BQU9uSixhQUFhLFdBQVdBLFdBQVdvSixPQUFPcEosUUFBUSxLQUFLO0FBQ25GLGVBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLEtBQUt1SDtBQUFBQSxZQUNMLElBQUkvSCxPQUFPTCxNQUFNTSxJQUFJO0FBQUEsWUFDckIsTUFBTUQsT0FBT0wsTUFBTU0sSUFBSTtBQUFBLFlBQ3ZCLE9BQU8wSjtBQUFBQSxZQUNQLFVBQVUzSSxXQUFXLE1BQU07QUFBQSxZQUFDLElBQUksQ0FBQzZJLFFBQVFsRix5QkFBeUIzRSxPQUFPTCxNQUFNTSxJQUFJLEdBQUc0SixHQUFHO0FBQUEsWUFDekYsYUFBYWxLLE1BQU0wSSxlQUFlO0FBQUEsWUFDbEMsVUFBVVA7QUFBQUEsWUFDVixVQUFVQTtBQUFBQSxZQUNWLFdBQVU7QUFBQTtBQUFBLFVBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU21LO0FBQUEsTUFHM0s7QUFBQSxNQUNBLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVM7QUFDTCxjQUFNUSxjQUFjOUgsWUFBWSxPQUFPLEtBQUtSLE9BQU9RLFFBQVE7QUFDM0QsY0FBTXNKLGVBQWVuSyxNQUFNcUYsT0FBTzdGLFVBQVVRLE1BQU1xRixNQUFNc0QsV0FBVyxJQUFJQTtBQUN2RSxjQUFNdEQsT0FBT3JGLE1BQU1xRixPQUFPM0YsUUFBUU0sTUFBTXFGLElBQUksSUFBSW1EO0FBQ2hELGNBQU00QixZQUFZcEssTUFBTXdELFNBQVMsV0FBV3hELE1BQU1xRyxzQkFBc0IsU0FBU3JHLE1BQU13RDtBQUV2RixlQUNJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxLQUFLNEU7QUFBQUEsWUFDTCxNQUFNZ0M7QUFBQUEsWUFDTixJQUFJL0osT0FBT0wsTUFBTU0sSUFBSTtBQUFBLFlBQ3JCLE1BQU1ELE9BQU9MLE1BQU1NLElBQUk7QUFBQSxZQUN2QixPQUFPNko7QUFBQUEsWUFDUCxVQUFVbEY7QUFBQUEsWUFDVixhQUFhakYsTUFBTTBJLGVBQWU7QUFBQSxZQUNsQyxVQUFVUDtBQUFBQSxZQUNWLGNBQWE7QUFBQSxZQUNiLFdBQVc5QyxNQUFNZ0Y7QUFBQUEsWUFDakIsV0FBVTtBQUFBO0FBQUEsVUFYZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXbUs7QUFBQSxNQUczSztBQUFBLElBQ0o7QUFBQSxFQUNKO0FBRUEsU0FDSSxtQ0FDSTtBQUFBLDJCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSx1Q0FDVG5KLG1CQUFTLFNBQVMsVUFBVUgsT0FBT3VKLFVBQVUsS0FBSyxlQUFldkosT0FBT3VKLFVBQVUsTUFEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVU3RCxjQUFjLFdBQVUsa0JBQWlCLFlBQVUsTUFBQyxjQUFhLE9BQzVFMUY7QUFBQUEsZUFBT3NCLEtBQUtDLE1BQU0vQjtBQUFBQSxVQUFJLENBQUMrQixPQUFPaUksZUFDM0IsdUJBQUMsU0FBcUIsV0FBV0EsYUFBYSxJQUFJLGtDQUFrQyxJQUNoRjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBcUNqSSxnQkFBTWhDLFFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsWUFDOUQsdUJBQUMsU0FBSSxXQUFVLDhDQUNWZ0MsZ0JBQU1HLE9BQU9DLE9BQU8sQ0FBQUMsTUFBSyxDQUFDQSxFQUFFQyxVQUFVLEVBQUVyQyxJQUFJLENBQUFQLFVBQVM7QUFDbEQsb0JBQU02RSxZQUFZN0UsTUFBTThFLGNBQWM5RSxNQUFNOEUsWUFBWTdFLFFBQVEsSUFBSTtBQUNwRSxrQkFBSSxDQUFDNEUsVUFBVyxRQUFPO0FBQ3ZCLG9CQUFNMkYsV0FBVyxDQUFDLENBQUMvSSxPQUFPcEIsT0FBT0wsTUFBTU0sSUFBSSxDQUFDO0FBQzVDLHFCQUNJLHVCQUFDLFNBQ0c7QUFBQSx1Q0FBQyxXQUFNLFNBQVNELE9BQU9MLE1BQU1NLElBQUksR0FBRyxXQUFVLDJDQUN6Q047QUFBQUEsd0JBQU13RztBQUFBQSxrQkFBTTtBQUFBLG1CQUFHLE9BQU94RyxNQUFNZ0csY0FBYyxhQUFhaEcsTUFBTWdHLFVBQVUvRixRQUFRLElBQUksQ0FBQyxDQUFDRCxNQUFNZ0csY0FBY25CLGFBQWEsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFXMkYsV0FBVyxjQUFjLElBQ3BDdkMsc0JBQVlqSSxLQUFLLEtBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ3dLLFlBQ0csdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qi9JLGlCQUFPcEIsT0FBT0wsTUFBTU0sSUFBSSxDQUFDLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsbUJBUm5FRCxPQUFPTCxNQUFNTSxJQUFJLEdBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxZQUVSLENBQUMsS0FsQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXJCTWdDLE1BQU1oQyxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFFBQ0g7QUFBQSxRQUVBYTtBQUFBQSxRQUNBQyxxQkFBcUJuQixRQUFRO0FBQUEsUUFDOUIsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXNCLFNBQVN6QixrQkFBa0JpQixPQUFPMEosU0FBUyxDQUFDO0FBQUEsY0FDM0QsV0FBVTtBQUFBLGNBQW1IO0FBQUE7QUFBQSxZQUhqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0MsQ0FBQ3BKLFlBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFnSTtBQUFBO0FBQUEsWUFGOUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOENBO0FBQUEsU0FsREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1EQTtBQUFBLElBQ0NZLGdCQUFnQkEsYUFBYW1GLG9CQUMxQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUXJGO0FBQUFBLFFBQ1IsU0FBU2tGO0FBQUFBLFFBQ1QsVUFBVUM7QUFBQUEsUUFDVixRQUFRakYsYUFBYW1GLGlCQUFpQks7QUFBQUE7QUFBQUEsTUFKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXVEO0FBQUEsT0ExRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2REE7QUFFUjtBQUFFbkcsR0FobUJXUixpQkFBZTtBQUFBLFVBQ1A3QixXQUFXO0FBQUE7QUFBQXlMLEtBRG5CNUo7QUFBZSxJQUFBNEo7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwiUmVsYXRpb25hbElucHV0IiwiU2VhcmNoTW9kYWwiLCJzZWFyY2hCeUZpZWxkIiwiQXJyYXlTdHJpbmdJbnB1dCIsIkRlY2ltYWxJbnB1dCIsImFwcGx5TWFzayIsInZhbGlkYXRlTWFzayIsImdldE1hc2siLCJpc1ZhbGlkRW1haWxMaXN0IiwiaXNWYWxpZFNpbmdsZUVtYWlsIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJnZXRTZWxlY3RPcHRpb25WYWx1ZXMiLCJmaWVsZCIsImZvcm1EYXRhIiwiZHluYW1pY09wdGlvbnMiLCJvcHRpb25zIiwiZ2V0T3B0aW9ucyIsIlN0cmluZyIsIm5hbWUiLCJtYXAiLCJvcHRpb24iLCJ2YWx1ZVR5cGUiLCJ2YWwiLCJ2YWx1ZSIsImdldFNlbGVjdFZhbHVlRm9yRm9ybSIsInJhd1ZhbHVlIiwiR2VuZXJpY0Zvcm1QYWdlIiwiY29uZmlnIiwiaW5pdGlhbERhdGEiLCJvblNhdmUiLCJtb2RlIiwiY2hpbGRyZW4iLCJyZW5kZXJFeHRyYUNvbnRlbnQiLCJyZWFkT25seSIsIl9zIiwibmF2aWdhdGUiLCJzZXRGb3JtRGF0YSIsImVycm9ycyIsInNldEVycm9ycyIsImZpZWxkUmVmcyIsInNldER5bmFtaWNPcHRpb25zIiwibG9hZGluZ09wdGlvbnMiLCJzZXRMb2FkaW5nT3B0aW9ucyIsImlzU2VhcmNoTW9kYWxPcGVuIiwic2V0SXNTZWFyY2hNb2RhbE9wZW4iLCJjdXJyZW50RmllbGQiLCJzZXRDdXJyZW50RmllbGQiLCJsb2FkQWxsT3B0aW9ucyIsImFsbEZpZWxkcyIsImZvcm0iLCJibG9jayIsImZsYXRNYXAiLCJiIiwiZmllbGRzIiwiZmlsdGVyIiwiZiIsImRldGFpbE9ubHkiLCJmaWVsZHNUb0xvYWQiLCJsb2FkT3B0aW9ucyIsInByb21pc2VzIiwicmVzdWx0cyIsIlByb21pc2UiLCJhbGwiLCJuZXdPcHRpb25zIiwiZm9yRWFjaCIsImluZGV4IiwiZXJyb3IiLCJjb25zb2xlIiwidHlwZSIsInByZXYiLCJjaGFuZ2VkIiwibmV4dCIsInZhbHVlRm9yU2VsZWN0Iiwib3B0aW9uVmFsdWVzIiwibGVuZ3RoIiwiaW5jbHVkZXMiLCJjbGVhckZpZWxkRXJyb3IiLCJuZXdFcnJvcnMiLCJhcHBseUZpZWxkVmFsdWUiLCJmaW5hbFZhbHVlIiwiY3VycmVudEZvcm1EYXRhIiwiZmllbGRDb25maWciLCJmaW5kIiwidXBkYXRlZEZvcm1EYXRhIiwib25DaGFuZ2VFZmZlY3QiLCJhcHBseVVwZGF0ZXMiLCJ1cGRhdGVzIiwiT2JqZWN0IiwiYXNzaWduIiwiaXNWaXNpYmxlIiwidmlzaWJsZVdoZW4iLCJ3YXNWaXNpYmxlIiwiaGFuZGxlTnVtZXJpY0ZpZWxkQ2hhbmdlIiwiaGFuZGxlQ2hhbmdlIiwiZSIsInRhcmdldCIsImNoZWNrZWQiLCJtYXNrIiwicmF3IiwiY3VycmVudFZhbHVlcyIsIkFycmF5IiwiaXNBcnJheSIsImNoZWNrVmFsdWUiLCJuZXh0VmFsdWVzIiwidiIsInBhcnNlRmxvYXQiLCJ2YWxpZGF0ZSIsImlzTWFuZGF0b3J5IiwibWFuZGF0b3J5IiwiaXNFbXB0eSIsInRyaW0iLCJzdHJpbmdWYWx1ZSIsImlzVmFsaWQiLCJhbGxvd011bHRpcGxlRW1haWxzIiwidGVzdCIsImVycm9yTWVzc2FnZSIsImxhYmVsIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJ2YWxpZGF0aW9uRXJyb3JzIiwia2V5cyIsImZpcnN0RXJyb3JGaWVsZE5hbWUiLCJjdXJyZW50IiwiZm9jdXMiLCJoYW5kbGVPcGVuU2VhcmNoTW9kYWwiLCJoYW5kbGVDbG9zZVNlYXJjaE1vZGFsIiwiaGFuZGxlU2VsZWN0Iiwic2VsZWN0ZWRJdGVtIiwicmVsYXRpb25hbENvbmZpZyIsIm5hbWVGaWVsZCIsImNvZGVGaWVsZCIsImlkRmllbGQiLCJtb2QiLCJtb2R1bGVDb25maWciLCJpdGVtQ29kZUtleSIsImxpc3RJdGVtQ29kZUtleSIsIml0ZW1OYW1lS2V5IiwibGlzdEl0ZW1OYW1lS2V5IiwiaWQiLCJyZXNvbHZlRmllbGRSZWFkb25seSIsInJlYWRvbmx5IiwicmVuZGVyRmllbGQiLCJhcnJheVZhbHVlIiwiaXNGaWVsZFJlYWRvbmx5IiwiYXNzaWduUmVmIiwiZWwiLCJzaG93UGxhY2Vob2xkZXIiLCJvcHRpb25WYWx1ZSIsInVuZGVmaW5lZCIsInNpbmdsZVZhbHVlVGV4dGFyZWEiLCJwbGFjZWhvbGRlciIsInNpbmdsZVZhbHVlIiwiZGF0ZVZhbHVlIiwic3BsaXQiLCJ1cmxWYWx1ZSIsImNvZGVWYWx1ZSIsIm5hbWVWYWx1ZSIsImlzUHJvZHVjdEZpZWxkIiwiZW5kcG9pbnQiLCJyZWxhdGlvbmFsRmllbGRzIiwibWFza1RvQXBwbHkiLCJoYW5kbGVDb2RlQ2hhbmdlIiwibmV3Q29kZSIsImhhbmRsZUNvZGVTdWJtaXQiLCJpdGVtIiwiZmllbGROYW1lIiwic3VjY2VzcyIsImVyciIsImxvZyIsImhhbmRsZUNsZWFyIiwiYXJyYXlWYWx1ZXMiLCJuZXdWYWx1ZXMiLCJudW1lcmljVmFsdWUiLCJOdW1iZXIiLCJudW0iLCJkaXNwbGF5VmFsdWUiLCJpbnB1dFR5cGUiLCJtYXhMZW5ndGgiLCJtb2R1bGVOYW1lIiwiYmxvY2tJbmRleCIsImhhc0Vycm9yIiwiYmFzZVJvdXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2VuZXJpY0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlLnRzeFxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB0eXBlIHsgRm9ybUZpZWxkQ29uZmlnLCBNb2R1bGVDb25maWcgfSBmcm9tICcuL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBSZWxhdGlvbmFsSW5wdXQgfSBmcm9tICcuL1JlbGF0aW9uYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgQXJyYXlTdHJpbmdJbnB1dCB9IGZyb20gJy4vQXJyYXlTdHJpbmdJbnB1dCc7XG5pbXBvcnQgeyBEZWNpbWFsSW5wdXQgfSBmcm9tICcuL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBhcHBseU1hc2ssIHZhbGlkYXRlTWFzaywgZ2V0TWFzayB9IGZyb20gJy4uLy4uL3V0aWxzL21hc2tzJztcbmltcG9ydCB7IGlzVmFsaWRFbWFpbExpc3QsIGlzVmFsaWRTaW5nbGVFbWFpbCB9IGZyb20gJy4uLy4uL3V0aWxzL2VtYWlsVmFsaWRhdGlvbic7XG5pbXBvcnQgeyBhcnRpY3Vsb3NNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9mZWF0dXJlcy9hcnRpY3Vsb3MvYXJ0aWN1bG9zLmNvbmZpZyc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuaW50ZXJmYWNlIEdlbmVyaWNGb3JtUGFnZVByb3BzPFQ+IHtcbiAgICBjb25maWc6IE1vZHVsZUNvbmZpZzxUPjtcbiAgICBpbml0aWFsRGF0YT86IFQ7XG4gICAgb25TYXZlOiAoZGF0YTogVCkgPT4gdm9pZDtcbiAgICBtb2RlOiAnY3JlYXRlJyB8ICdlZGl0JztcbiAgICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgICBjaGlsZHJlbj86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgICAvKiogQ29udGVuaWRvIGV4dHJhIHF1ZSBwdWVkZSBkZXBlbmRlciBkZWwgZXN0YWRvIGRlbCBmb3JtdWxhcmlvIChmb3JtRGF0YSkuIFNlIHJlbmRlcml6YSBkZW50cm8gZGVsIGZvcm0sIGFudGVzIGRlIGxvcyBib3RvbmVzLiAqL1xuICAgIHJlbmRlckV4dHJhQ29udGVudD86IChmb3JtRGF0YTogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xuICAgIC8qKiBTaSBlcyB0cnVlLCBlbCBmb3JtdWxhcmlvIHNlIG11ZXN0cmEgZW4gbW9kbyBzb2xvIGxlY3R1cmEgKHNpbiBndWFyZGFyKS4gKi9cbiAgICByZWFkT25seT86IGJvb2xlYW47XG59XG5cbnR5cGUgRHluYW1pY09wdGlvbnMgPSBSZWNvcmQ8c3RyaW5nLCB7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfVtdPjtcbnR5cGUgUmVsYXRpb25hbEl0ZW0gPSB7IGlkOiBzdHJpbmcgfCBudW1iZXIgfSAmIFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bWJlciB8IG51bGwgfCB1bmRlZmluZWQ+OyAvLyDinIUgRklYOiAnYW55JyByZWVtcGxhemFkb1xuXG5jb25zdCBnZXRTZWxlY3RPcHRpb25WYWx1ZXMgPSA8VCBleHRlbmRzIG9iamVjdD4oXG4gICAgZmllbGQ6IEZvcm1GaWVsZENvbmZpZzxUPixcbiAgICBmb3JtRGF0YTogVCxcbiAgICBkeW5hbWljT3B0aW9uczogRHluYW1pY09wdGlvbnMsXG4pOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IGZpZWxkLmdldE9wdGlvbnM/Lihmb3JtRGF0YSkgPz8gZHluYW1pY09wdGlvbnNbU3RyaW5nKGZpZWxkLm5hbWUpXSA/PyBmaWVsZC5vcHRpb25zID8/IFtdO1xuICAgIHJldHVybiBvcHRpb25zLm1hcChvcHRpb24gPT4ge1xuICAgICAgICBpZiAoZmllbGQudmFsdWVUeXBlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbi52YWx1ZTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsID09PSAnYm9vbGVhbicgJiYgdmFsID09PSB0cnVlKSByZXR1cm4gJzEnO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdib29sZWFuJyAmJiB2YWwgPT09IGZhbHNlKSByZXR1cm4gJzAnO1xuICAgICAgICAgICAgaWYgKHZhbCA9PT0gMSB8fCB2YWwgPT09ICcxJyB8fCB2YWwgPT09ICd0cnVlJykgcmV0dXJuICcxJztcbiAgICAgICAgICAgIGlmICh2YWwgPT09IDAgfHwgdmFsID09PSAnMCcgfHwgdmFsID09PSAnZmFsc2UnKSByZXR1cm4gJzAnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBTdHJpbmcob3B0aW9uLnZhbHVlKTtcbiAgICB9KTtcbn07XG5cbmNvbnN0IGdldFNlbGVjdFZhbHVlRm9yRm9ybSA9IDxUIGV4dGVuZHMgb2JqZWN0PihcbiAgICBmaWVsZDogRm9ybUZpZWxkQ29uZmlnPFQ+LFxuICAgIHJhd1ZhbHVlOiB1bmtub3duLFxuKTogc3RyaW5nID0+IHtcbiAgICBpZiAoZmllbGQudmFsdWVUeXBlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHJhd1ZhbHVlID09PSB0cnVlID8gJzEnIDogcmF3VmFsdWUgPT09IGZhbHNlID8gJzAnIDogJyc7XG4gICAgfVxuICAgIHJldHVybiByYXdWYWx1ZSA9PSBudWxsID8gJycgOiBTdHJpbmcocmF3VmFsdWUpO1xufTtcblxuZXhwb3J0IGNvbnN0IEdlbmVyaWNGb3JtUGFnZSA9IDxUIGV4dGVuZHMgb2JqZWN0Pih7IGNvbmZpZywgaW5pdGlhbERhdGEsIG9uU2F2ZSwgbW9kZSwgY2hpbGRyZW4sIHJlbmRlckV4dHJhQ29udGVudCwgcmVhZE9ubHkgPSBmYWxzZSB9OiBHZW5lcmljRm9ybVBhZ2VQcm9wczxUPikgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPFQ+KGluaXRpYWxEYXRhIHx8IHt9IGFzIFQpO1xuICAgIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XG4gICAgY29uc3QgZmllbGRSZWZzID0gdXNlUmVmPFJlY29yZDxzdHJpbmcsIEhUTUxFbGVtZW50IHwgbnVsbD4+KHt9KTtcblxuICAgIGNvbnN0IFtkeW5hbWljT3B0aW9ucywgc2V0RHluYW1pY09wdGlvbnNdID0gdXNlU3RhdGU8RHluYW1pY09wdGlvbnM+KHt9KTtcbiAgICBjb25zdCBbbG9hZGluZ09wdGlvbnMsIHNldExvYWRpbmdPcHRpb25zXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gICAgY29uc3QgW2lzU2VhcmNoTW9kYWxPcGVuLCBzZXRJc1NlYXJjaE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2N1cnJlbnRGaWVsZCwgc2V0Q3VycmVudEZpZWxkXSA9IHVzZVN0YXRlPEZvcm1GaWVsZENvbmZpZzxUPiB8IG51bGw+KG51bGwpO1xuXG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2FkQWxsT3B0aW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldExvYWRpbmdPcHRpb25zKHRydWUpO1xuICAgICAgICAgICAgY29uc3QgYWxsRmllbGRzID0gY29uZmlnLmZvcm0uYmxvY2suZmxhdE1hcChiID0+IGIuZmllbGRzLmZpbHRlcihmID0+ICFmLmRldGFpbE9ubHkpKTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkc1RvTG9hZCA9IGFsbEZpZWxkcy5maWx0ZXIoZmllbGQgPT4gZmllbGQubG9hZE9wdGlvbnMpO1xuXG4gICAgICAgICAgICBjb25zdCBwcm9taXNlcyA9IGZpZWxkc1RvTG9hZC5tYXAoZmllbGQgPT4gZmllbGQubG9hZE9wdGlvbnMhKCkpO1xuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcyk7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3T3B0aW9uczogRHluYW1pY09wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgICAgICBmaWVsZHNUb0xvYWQuZm9yRWFjaCgoZmllbGQsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIG5ld09wdGlvbnNbU3RyaW5nKGZpZWxkLm5hbWUpXSA9IHJlc3VsdHNbaW5kZXhdO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHNldER5bmFtaWNPcHRpb25zKG5ld09wdGlvbnMpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgY2FyZ2FyIGxhcyBvcGNpb25lcyBkaW7DoW1pY2FzIGRlbCBmb3JtdWxhcmlvOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmdPcHRpb25zKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBsb2FkQWxsT3B0aW9ucygpO1xuICAgIH0sIFtjb25maWddKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpbml0aWFsRGF0YSkge1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEoaW5pdGlhbERhdGEpO1xuICAgICAgICB9XG4gICAgfSwgW2luaXRpYWxEYXRhXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobG9hZGluZ09wdGlvbnMpIHJldHVybjtcblxuICAgICAgICBjb25zdCBhbGxGaWVsZHMgPSBjb25maWcuZm9ybS5ibG9jay5mbGF0TWFwKGIgPT4gYi5maWVsZHMuZmlsdGVyKGYgPT4gIWYuZGV0YWlsT25seSAmJiBmLnR5cGUgPT09ICdzZWxlY3QnKSk7XG5cbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiB7XG4gICAgICAgICAgICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHsgLi4ucHJldiB9O1xuXG4gICAgICAgICAgICBhbGxGaWVsZHMuZm9yRWFjaChmaWVsZCA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmF3VmFsdWUgPSBwcmV2W2ZpZWxkLm5hbWUgYXMga2V5b2YgVF07XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWVGb3JTZWxlY3QgPSBnZXRTZWxlY3RWYWx1ZUZvckZvcm0oZmllbGQsIHJhd1ZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbHVlRm9yU2VsZWN0KSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25WYWx1ZXMgPSBnZXRTZWxlY3RPcHRpb25WYWx1ZXMoZmllbGQsIHByZXYsIGR5bmFtaWNPcHRpb25zKTtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9uVmFsdWVzLmxlbmd0aCA+IDAgJiYgIW9wdGlvblZhbHVlcy5pbmNsdWRlcyh2YWx1ZUZvclNlbGVjdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgICAgICAgICAgKG5leHQgYXMgUmVjb3JkPGtleW9mIFQsIGFueT4pW2ZpZWxkLm5hbWVdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiBjaGFuZ2VkID8gKG5leHQgYXMgVCkgOiBwcmV2O1xuICAgICAgICB9KTtcbiAgICB9LCBbbG9hZGluZ09wdGlvbnMsIGR5bmFtaWNPcHRpb25zLCBjb25maWddKTtcblxuICAgIGNvbnN0IGNsZWFyRmllbGRFcnJvciA9IChuYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKGVycm9yc1tuYW1lXSkge1xuICAgICAgICAgICAgc2V0RXJyb3JzKHByZXYgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5ld0Vycm9ycyA9IHsgLi4ucHJldiB9O1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBuZXdFcnJvcnNbbmFtZV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ld0Vycm9ycztcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGFwcGx5RmllbGRWYWx1ZSA9IChcbiAgICAgICAgbmFtZTogc3RyaW5nLFxuICAgICAgICBmaW5hbFZhbHVlOiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgc3RyaW5nW10gfCBudWxsLFxuICAgICkgPT4ge1xuICAgICAgICBzZXRGb3JtRGF0YShjdXJyZW50Rm9ybURhdGEgPT4ge1xuICAgICAgICAgICAgY29uc3QgYWxsRmllbGRzID0gY29uZmlnLmZvcm0uYmxvY2suZmxhdE1hcChiID0+IGIuZmllbGRzLmZpbHRlcihmID0+ICFmLmRldGFpbE9ubHkpKTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkQ29uZmlnID0gYWxsRmllbGRzLmZpbmQoZiA9PiBTdHJpbmcoZi5uYW1lKSA9PT0gbmFtZSk7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkRm9ybURhdGEgPSB7IC4uLmN1cnJlbnRGb3JtRGF0YSwgW25hbWVdOiBmaW5hbFZhbHVlIH07XG5cbiAgICAgICAgICAgIGlmIChmaWVsZENvbmZpZz8ub25DaGFuZ2VFZmZlY3QpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcHBseVVwZGF0ZXMgPSAodXBkYXRlczogUGFydGlhbDxUPikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHVwZGF0ZWRGb3JtRGF0YSwgdXBkYXRlcyk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBmaWVsZENvbmZpZy5vbkNoYW5nZUVmZmVjdChmaW5hbFZhbHVlLCB1cGRhdGVkRm9ybURhdGEsIGFwcGx5VXBkYXRlcyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGFsbEZpZWxkcy5mb3JFYWNoKGZpZWxkID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoU3RyaW5nKGZpZWxkLm5hbWUpID09PSBuYW1lKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICBjb25zdCBpc1Zpc2libGUgPSBmaWVsZC52aXNpYmxlV2hlbiA/IGZpZWxkLnZpc2libGVXaGVuKHVwZGF0ZWRGb3JtRGF0YSBhcyBUKSA6IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc3Qgd2FzVmlzaWJsZSA9IGZpZWxkLnZpc2libGVXaGVuID8gZmllbGQudmlzaWJsZVdoZW4oY3VycmVudEZvcm1EYXRhKSA6IHRydWU7XG5cbiAgICAgICAgICAgICAgICBpZiAod2FzVmlzaWJsZSAmJiAhaXNWaXNpYmxlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgICAgICh1cGRhdGVkRm9ybURhdGEgYXMgUmVjb3JkPGtleW9mIFQsIGFueT4pW2ZpZWxkLm5hbWVdID0gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWRGb3JtRGF0YSBhcyBUO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlTnVtZXJpY0ZpZWxkQ2hhbmdlID0gKG5hbWU6IHN0cmluZywgdmFsdWU6IG51bWJlcikgPT4ge1xuICAgICAgICBjbGVhckZpZWxkRXJyb3IobmFtZSk7XG4gICAgICAgIGFwcGx5RmllbGRWYWx1ZShuYW1lLCB2YWx1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFNlbGVjdEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB7IG5hbWUsIHZhbHVlLCB0eXBlIH0gPSBlLnRhcmdldDtcbiAgICAgICAgY29uc3QgeyBjaGVja2VkIH0gPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuXG4gICAgICAgIGNsZWFyRmllbGRFcnJvcihuYW1lKTtcblxuICAgICAgICBsZXQgZmluYWxWYWx1ZTogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbiB8IHN0cmluZ1tdIHwgbnVsbCA9IHZhbHVlO1xuICAgICAgICBjb25zdCBhbGxGaWVsZHMgPSBjb25maWcuZm9ybS5ibG9jay5mbGF0TWFwKGIgPT4gYi5maWVsZHMuZmlsdGVyKGYgPT4gIWYuZGV0YWlsT25seSkpO1xuICAgICAgICBjb25zdCBmaWVsZENvbmZpZyA9IGFsbEZpZWxkcy5maW5kKGYgPT4gU3RyaW5nKGYubmFtZSkgPT09IG5hbWUpO1xuXG4gICAgICAgIC8vIOKchSBBcGxpY2FyIG3DoXNjYXJhIGdlbsOpcmljYSBzaSBlc3TDoSBjb25maWd1cmFkYVxuICAgICAgICBpZiAoZmllbGRDb25maWc/Lm1hc2sgJiYgdHlwZSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgICBmaW5hbFZhbHVlID0gYXBwbHlNYXNrKGZpZWxkQ29uZmlnLm1hc2ssIHZhbHVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlID09PSAnY2hlY2tib3gnICYmIGZpZWxkQ29uZmlnPy50eXBlICE9PSAnY2hlY2tib3gtZ3JvdXAnKSB7XG4gICAgICAgICAgICBmaW5hbFZhbHVlID0gY2hlY2tlZDtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAnY2hlY2tib3gnICYmIGZpZWxkQ29uZmlnPy50eXBlID09PSAnY2hlY2tib3gtZ3JvdXAnKSB7XG4gICAgICAgICAgICBzZXRGb3JtRGF0YShjdXJyZW50Rm9ybURhdGEgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJhdyA9IGN1cnJlbnRGb3JtRGF0YVtuYW1lIGFzIGtleW9mIFRdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRWYWx1ZXM6IHN0cmluZ1tdID0gQXJyYXkuaXNBcnJheShyYXcpID8gcmF3Lm1hcChTdHJpbmcpIDogW107XG4gICAgICAgICAgICAgICAgY29uc3QgY2hlY2tWYWx1ZSA9IFN0cmluZyh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dFZhbHVlcyA9IGNoZWNrZWRcbiAgICAgICAgICAgICAgICAgICAgPyBbLi4uY3VycmVudFZhbHVlcywgY2hlY2tWYWx1ZV1cbiAgICAgICAgICAgICAgICAgICAgOiBjdXJyZW50VmFsdWVzLmZpbHRlcih2ID0+IHYgIT09IGNoZWNrVmFsdWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRGb3JtRGF0YSA9IHsgLi4uY3VycmVudEZvcm1EYXRhLCBbbmFtZV06IG5leHRWYWx1ZXMgfTtcblxuICAgICAgICAgICAgICAgIGlmIChmaWVsZENvbmZpZz8ub25DaGFuZ2VFZmZlY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbHlVcGRhdGVzID0gKHVwZGF0ZXM6IFBhcnRpYWw8VD4pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24odXBkYXRlZEZvcm1EYXRhLCB1cGRhdGVzKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRDb25maWcub25DaGFuZ2VFZmZlY3QobmV4dFZhbHVlcywgdXBkYXRlZEZvcm1EYXRhLCBhcHBseVVwZGF0ZXMpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiB1cGRhdGVkRm9ybURhdGEgYXMgVDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKGZpZWxkQ29uZmlnPy52YWx1ZVR5cGUgPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgZmluYWxWYWx1ZSA9IHZhbHVlID09PSAnMScgfHwgdmFsdWUgPT09ICd0cnVlJztcbiAgICAgICAgfSBlbHNlIGlmIChmaWVsZENvbmZpZz8udmFsdWVUeXBlID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgZmluYWxWYWx1ZSA9IHBhcnNlRmxvYXQodmFsdWUpIHx8IDA7XG4gICAgICAgIH1cblxuICAgICAgICBhcHBseUZpZWxkVmFsdWUobmFtZSwgZmluYWxWYWx1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHZhbGlkYXRlID0gKCk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPT4ge1xuICAgICAgICBjb25zdCBuZXdFcnJvcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcbiAgICAgICAgY29uc3QgYWxsRmllbGRzID0gY29uZmlnLmZvcm0uYmxvY2suZmxhdE1hcChiID0+IGIuZmllbGRzLmZpbHRlcihmID0+ICFmLmRldGFpbE9ubHkpKTtcblxuICAgICAgICBhbGxGaWVsZHMuZm9yRWFjaChmaWVsZCA9PiB7XG4gICAgICAgICAgICBjb25zdCBpc1Zpc2libGUgPSBmaWVsZC52aXNpYmxlV2hlbiA/IGZpZWxkLnZpc2libGVXaGVuKGZvcm1EYXRhKSA6IHRydWU7XG4gICAgICAgICAgICBpZiAoIWlzVmlzaWJsZSkgcmV0dXJuOyAvLyBTaSBubyBlcyB2aXNpYmxlLCBubyBzZSB2YWxpZGFcblxuICAgICAgICAgICAgY29uc3QgaXNNYW5kYXRvcnkgPSB0eXBlb2YgZmllbGQubWFuZGF0b3J5ID09PSAnZnVuY3Rpb24nID8gZmllbGQubWFuZGF0b3J5KGZvcm1EYXRhKSA6ICEhZmllbGQubWFuZGF0b3J5O1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBmb3JtRGF0YVtmaWVsZC5uYW1lIGFzIGtleW9mIFRdO1xuICAgICAgICAgICAgbGV0IGlzRW1wdHkgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChmaWVsZC50eXBlID09PSAnY2hlY2tib3gtZ3JvdXAnKSB7XG4gICAgICAgICAgICAgICAgaXNFbXB0eSA9ICFBcnJheS5pc0FycmF5KHZhbHVlKSB8fCB2YWx1ZS5sZW5ndGggPT09IDA7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlzRW1wdHkgPSB2YWx1ZSA9PSBudWxsIHx8IFN0cmluZyh2YWx1ZSkudHJpbSgpID09PSAnJztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gMS4gVmFsaWRhY2nDs24gZGUgY2FtcG9zIG9ibGlnYXRvcmlvc1xuICAgICAgICAgICAgaWYgKGlzTWFuZGF0b3J5ICYmIGlzRW1wdHkpIHtcbiAgICAgICAgICAgICAgICBuZXdFcnJvcnNbU3RyaW5nKGZpZWxkLm5hbWUpXSA9ICdFc3RlIGNhbXBvIGVzIHJlcXVlcmlkbyc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDIuIFZhbGlkYWNpw7NuIGRlIGZvcm1hdG8gZGUgZW1haWwgKHNpIG5vIGVzdMOhIHlhIHZhY8OtbylcbiAgICAgICAgICAgIGlmIChmaWVsZC50eXBlID09PSAnZW1haWwnICYmICFpc0VtcHR5KSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3RyaW5nVmFsdWUgPSBTdHJpbmcodmFsdWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzVmFsaWQgPSBmaWVsZC5hbGxvd011bHRpcGxlRW1haWxzXG4gICAgICAgICAgICAgICAgICAgID8gaXNWYWxpZEVtYWlsTGlzdChzdHJpbmdWYWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgOiBpc1ZhbGlkU2luZ2xlRW1haWwoc3RyaW5nVmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmICghaXNWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICBuZXdFcnJvcnNbU3RyaW5nKGZpZWxkLm5hbWUpXSA9IGZpZWxkLmFsbG93TXVsdGlwbGVFbWFpbHNcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ1VubyBvIG3DoXMgZW1haWxzIG5vIHRpZW5lbiB1biBmb3JtYXRvIHbDoWxpZG8nXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdFbCBmb3JtYXRvIGRlbCBlbWFpbCBubyBlcyB2w6FsaWRvJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDMuIFVSTDogc29sbyBodHRwKHMpIHNpIGhheSB2YWxvclxuICAgICAgICAgICAgaWYgKGZpZWxkLnR5cGUgPT09ICd1cmwnICYmICFpc0VtcHR5ICYmICEvXmh0dHBzPzpcXC9cXC8vaS50ZXN0KFN0cmluZyh2YWx1ZSkudHJpbSgpKSkge1xuICAgICAgICAgICAgICAgIG5ld0Vycm9yc1tTdHJpbmcoZmllbGQubmFtZSldID0gJ0xhIFVSTCBkZWJlIGNvbWVuemFyIGNvbiBodHRwOi8vIG8gaHR0cHM6Ly8nO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyDinIUgVmFsaWRhY2nDs24gZ2Vuw6lyaWNhIGRlIG3DoXNjYXJhXG4gICAgICAgICAgICBpZiAoaXNNYW5kYXRvcnkgJiYgZmllbGQubWFzayAmJiAhaXNFbXB0eSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0cmluZ1ZhbHVlID0gU3RyaW5nKHZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoIXZhbGlkYXRlTWFzayhmaWVsZC5tYXNrLCBzdHJpbmdWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWFzayA9IGdldE1hc2soZmllbGQubWFzayk7XG4gICAgICAgICAgICAgICAgICAgIG5ld0Vycm9yc1tTdHJpbmcoZmllbGQubmFtZSldID0gbWFzaz8uZXJyb3JNZXNzYWdlIHx8IGAke2ZpZWxkLmxhYmVsfSB0aWVuZSB1biBmb3JtYXRvIGludsOhbGlkb2A7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gbmV3RXJyb3JzO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9ycyA9IHZhbGlkYXRlKCk7XG4gICAgICAgIHNldEVycm9ycyh2YWxpZGF0aW9uRXJyb3JzKTtcblxuICAgICAgICBpZiAoT2JqZWN0LmtleXModmFsaWRhdGlvbkVycm9ycykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBvblNhdmUoZm9ybURhdGEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgYWxsRmllbGRzID0gY29uZmlnLmZvcm0uYmxvY2suZmxhdE1hcChiID0+IGIuZmllbGRzLmZpbHRlcihmID0+ICFmLmRldGFpbE9ubHkpKTtcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0RXJyb3JGaWVsZE5hbWUgPSBhbGxGaWVsZHMuZmluZChmaWVsZCA9PiB2YWxpZGF0aW9uRXJyb3JzW1N0cmluZyhmaWVsZC5uYW1lKV0pPy5uYW1lO1xuXG4gICAgICAgICAgICBpZiAoZmlyc3RFcnJvckZpZWxkTmFtZSkge1xuICAgICAgICAgICAgICAgIGZpZWxkUmVmcy5jdXJyZW50W1N0cmluZyhmaXJzdEVycm9yRmllbGROYW1lKV0/LmZvY3VzKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlT3BlblNlYXJjaE1vZGFsID0gKGZpZWxkOiBGb3JtRmllbGRDb25maWc8VD4pID0+IHtcbiAgICAgICAgc2V0Q3VycmVudEZpZWxkKGZpZWxkKTtcbiAgICAgICAgc2V0SXNTZWFyY2hNb2RhbE9wZW4odHJ1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNsb3NlU2VhcmNoTW9kYWwgPSAoKSA9PiB7XG4gICAgICAgIHNldElzU2VhcmNoTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgc2V0Q3VycmVudEZpZWxkKG51bGwpO1xuICAgIH07XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdCA9IChzZWxlY3RlZEl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoIWN1cnJlbnRGaWVsZCB8fCAhY3VycmVudEZpZWxkLnJlbGF0aW9uYWxDb25maWcpIHJldHVybjtcblxuICAgICAgICBjb25zdCB7IG5hbWVGaWVsZCwgY29kZUZpZWxkIH0gPSBjdXJyZW50RmllbGQucmVsYXRpb25hbENvbmZpZztcbiAgICAgICAgY29uc3QgaWRGaWVsZCA9IGN1cnJlbnRGaWVsZC5uYW1lO1xuICAgICAgICBjb25zdCBtb2QgPSBjdXJyZW50RmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWcgYXMgeyBsaXN0SXRlbUNvZGVLZXk/OiBzdHJpbmc7IGxpc3RJdGVtTmFtZUtleT86IHN0cmluZyB9IHwgdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBpdGVtQ29kZUtleSA9IG1vZD8ubGlzdEl0ZW1Db2RlS2V5ID8/IGNvZGVGaWVsZDtcbiAgICAgICAgY29uc3QgaXRlbU5hbWVLZXkgPSBtb2Q/Lmxpc3RJdGVtTmFtZUtleSA/PyBuYW1lRmllbGQ7XG5cbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtpZEZpZWxkXTogc2VsZWN0ZWRJdGVtLmlkLFxuICAgICAgICAgICAgW25hbWVGaWVsZF06IHNlbGVjdGVkSXRlbVtpdGVtTmFtZUtleV0sXG4gICAgICAgICAgICBbY29kZUZpZWxkXTogc2VsZWN0ZWRJdGVtW2l0ZW1Db2RlS2V5XSxcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIGhhbmRsZUNsb3NlU2VhcmNoTW9kYWwoKTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVzb2x2ZUZpZWxkUmVhZG9ubHkgPSAoZmllbGQ6IEZvcm1GaWVsZENvbmZpZzxUPik6IGJvb2xlYW4gPT4ge1xuICAgICAgICBpZiAocmVhZE9ubHkpIHJldHVybiB0cnVlO1xuICAgICAgICBpZiAodHlwZW9mIGZpZWxkLnJlYWRvbmx5ID09PSAnZnVuY3Rpb24nKSByZXR1cm4gZmllbGQucmVhZG9ubHkoZm9ybURhdGEpO1xuICAgICAgICByZXR1cm4gISFmaWVsZC5yZWFkb25seTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVuZGVyRmllbGQgPSAoZmllbGQ6IEZvcm1GaWVsZENvbmZpZzxUPikgPT4ge1xuICAgICAgICBjb25zdCByYXdWYWx1ZSA9IGZvcm1EYXRhW2ZpZWxkLm5hbWUgYXMga2V5b2YgVF07XG4gICAgICAgIGNvbnN0IGFycmF5VmFsdWUgPSBBcnJheS5pc0FycmF5KHJhd1ZhbHVlKSA/IHJhd1ZhbHVlLm1hcChTdHJpbmcpIDogW107XG4gICAgICAgIGNvbnN0IGlzRmllbGRSZWFkb25seSA9IHJlc29sdmVGaWVsZFJlYWRvbmx5KGZpZWxkKTtcblxuICAgICAgICBjb25zdCBhc3NpZ25SZWYgPSAoZWw6IEhUTUxFbGVtZW50IHwgbnVsbCkgPT4ge1xuICAgICAgICAgICAgZmllbGRSZWZzLmN1cnJlbnRbU3RyaW5nKGZpZWxkLm5hbWUpXSA9IGVsO1xuICAgICAgICB9O1xuXG4gICAgICAgIHN3aXRjaCAoZmllbGQudHlwZSkge1xuICAgICAgICAgICAgY2FzZSAnc2VsZWN0Jzoge1xuICAgICAgICAgICAgICAgIGxldCB2YWx1ZUZvclNlbGVjdCA9IGdldFNlbGVjdFZhbHVlRm9yRm9ybShmaWVsZCwgcmF3VmFsdWUpO1xuXG4gICAgICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IGZpZWxkLmdldE9wdGlvbnM/Lihmb3JtRGF0YSkgPz8gZHluYW1pY09wdGlvbnNbU3RyaW5nKGZpZWxkLm5hbWUpXSA/PyBmaWVsZC5vcHRpb25zID8/IFtdO1xuICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvblZhbHVlcyA9IGdldFNlbGVjdE9wdGlvblZhbHVlcyhmaWVsZCwgZm9ybURhdGEsIGR5bmFtaWNPcHRpb25zKTtcbiAgICAgICAgICAgICAgICBpZiAodmFsdWVGb3JTZWxlY3QgJiYgb3B0aW9uVmFsdWVzLmxlbmd0aCA+IDAgJiYgIW9wdGlvblZhbHVlcy5pbmNsdWRlcyh2YWx1ZUZvclNlbGVjdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVGb3JTZWxlY3QgPSAnJztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCBzaG93UGxhY2Vob2xkZXIgPSAhKGlzRmllbGRSZWFkb25seSAmJiBvcHRpb25zLmxlbmd0aCA9PT0gMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e2Fzc2lnblJlZiBhcyBSZWFjdC5SZWY8SFRNTFNlbGVjdEVsZW1lbnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e1N0cmluZyhmaWVsZC5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e1N0cmluZyhmaWVsZC5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZUZvclNlbGVjdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyhmaWVsZC5sb2FkT3B0aW9ucyAmJiBsb2FkaW5nT3B0aW9ucykgfHwgaXNGaWVsZFJlYWRvbmx5fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZ09wdGlvbnMgJiYgZmllbGQubG9hZE9wdGlvbnMgJiYgPG9wdGlvbj5DYXJnYW5kby4uLjwvb3B0aW9uPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93UGxhY2Vob2xkZXIgJiYgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjY2lvbmEgdW5hIG9wY2nDs248L29wdGlvbj59XG4gICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9ucy5tYXAob3B0aW9uID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDinIUgQ09SUkVDQ0nDk046IE5vcm1hbGl6YXIgdmFsb3JlcyBib29sZWFub3MgYSAnMScvJzAnIHBhcmEgZWwgc2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG9wdGlvblZhbHVlOiBzdHJpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkLnZhbHVlVHlwZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5vcm1hbGl6YXIgdGFudG8gYm9vbGVhbm9zICh0cnVlL2ZhbHNlKSBjb21vIG7Dum1lcm9zICgxLzApIGEgc3RyaW5ncyAnMScvJzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbi52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmVyaWZpY2FyIHRpcG8gYm9vbGVhbm8gcHJpbWVyb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHZhbCA9PT0gJ2Jvb2xlYW4nICYmIHZhbCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVmFsdWUgPSAnMSc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ2Jvb2xlYW4nICYmIHZhbCA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvblZhbHVlID0gJzAnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHZhbCA9PT0gMSB8fCB2YWwgPT09ICcxJyB8fCB2YWwgPT09ICd0cnVlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVmFsdWUgPSAnMSc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsID09PSAwIHx8IHZhbCA9PT0gJzAnIHx8IHZhbCA9PT0gJ2ZhbHNlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVmFsdWUgPSAnMCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25WYWx1ZSA9IFN0cmluZyhvcHRpb24udmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVmFsdWUgPSBTdHJpbmcob3B0aW9uLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e29wdGlvblZhbHVlfSB2YWx1ZT17b3B0aW9uVmFsdWV9PntvcHRpb24ubGFiZWx9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnY2hlY2tib3gtZ3JvdXAnOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IG10LTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZC5vcHRpb25zPy5tYXAoKG9wdGlvbiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDinIUgQ09SUkVDQ0nDk046IFNlIGNvbnZpZXJ0ZSBlbCB2YWxvciBhIHN0cmluZyBwYXJhIGxhIGtleS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17U3RyaW5nKG9wdGlvbi52YWx1ZSl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBoLTVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17aW5kZXggPT09IDAgPyAoZWwpID0+IHsgZmllbGRSZWZzLmN1cnJlbnRbU3RyaW5nKGZpZWxkLm5hbWUpXSA9IGVsOyB9IDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgJHtTdHJpbmcoZmllbGQubmFtZSl9LSR7b3B0aW9uLnZhbHVlfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17U3RyaW5nKGZpZWxkLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBTZSBjb252aWVydGUgZWwgdmFsb3IgYSBzdHJpbmcgcGFyYSBlbCBpbnB1dC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17U3RyaW5nKG9wdGlvbi52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17YXJyYXlWYWx1ZS5pbmNsdWRlcyhTdHJpbmcob3B0aW9uLnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTYwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YCR7U3RyaW5nKGZpZWxkLm5hbWUpfS0ke29wdGlvbi52YWx1ZX1gfSBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjYXNlICd0ZXh0YXJlYSc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzaW5nbGVWYWx1ZVRleHRhcmVhID0gcmF3VmFsdWUgPT0gbnVsbCA/ICcnIDogU3RyaW5nKHJhd1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXthc3NpZ25SZWYgYXMgUmVhY3QuUmVmPEhUTUxUZXh0QXJlYUVsZW1lbnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e1N0cmluZyhmaWVsZC5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e1N0cmluZyhmaWVsZC5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaW5nbGVWYWx1ZVRleHRhcmVhfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmaWVsZC5wbGFjZWhvbGRlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnZGF0ZSc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzaW5nbGVWYWx1ZSA9IHJhd1ZhbHVlID09IG51bGwgPyAnJyA6IFN0cmluZyhyYXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF0ZVZhbHVlID0gc2luZ2xlVmFsdWUgPyBzaW5nbGVWYWx1ZS5zcGxpdCgnVCcpWzBdIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17YXNzaWduUmVmIGFzIFJlYWN0LlJlZjxIVE1MSW5wdXRFbGVtZW50Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtTdHJpbmcoZmllbGQubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtTdHJpbmcoZmllbGQubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0ZVZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICd1cmwnOiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXJsVmFsdWUgPSByYXdWYWx1ZSA9PSBudWxsID8gJycgOiBTdHJpbmcocmF3VmFsdWUpO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXthc3NpZ25SZWYgYXMgUmVhY3QuUmVmPEhUTUxJbnB1dEVsZW1lbnQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInVybFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD17U3RyaW5nKGZpZWxkLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17U3RyaW5nKGZpZWxkLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VybFZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmaWVsZC5wbGFjZWhvbGRlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5PXtpc0ZpZWxkUmVhZG9ubHl9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAncmVsYXRpb25hbCc6IHtcbiAgICAgICAgICAgICAgICBpZiAoIWZpZWxkLnJlbGF0aW9uYWxDb25maWcpIHJldHVybiBudWxsO1xuXG4gICAgICAgICAgICAgICAgY29uc3QgeyBjb2RlRmllbGQsIG5hbWVGaWVsZCB9ID0gZmllbGQucmVsYXRpb25hbENvbmZpZztcbiAgICAgICAgICAgICAgICBjb25zdCBjb2RlVmFsdWUgPSBmb3JtRGF0YVtjb2RlRmllbGQgYXMga2V5b2YgVF0gYXMgc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgICAgICAgICBjb25zdCBuYW1lVmFsdWUgPSBmb3JtRGF0YVtuYW1lRmllbGQgYXMga2V5b2YgVF0gYXMgc3RyaW5nIHwgbnVsbDtcblxuICAgICAgICAgICAgICAgIC8vIOKchSBERVRFQ1RBUiBTSSBFUyBVTiBDQU1QTyBERSBQUk9EVUNUTyAoU0tVKVxuICAgICAgICAgICAgICAgIGNvbnN0IGlzUHJvZHVjdEZpZWxkID0gZmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWc/LmVuZHBvaW50ID09PSBhcnRpY3Vsb3NNb2R1bGVDb25maWcuZW5kcG9pbnQgfHxcbiAgICAgICAgICAgICAgICAgICAgZmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWc/LnJlbGF0aW9uYWxGaWVsZHM/LmNvZGVGaWVsZCA9PT0gJ3NrdSc7XG4gICAgICAgICAgICAgICAgY29uc3QgbWFza1RvQXBwbHkgPSBpc1Byb2R1Y3RGaWVsZCA/ICdza3UnIDogZmllbGQubWFzaztcblxuICAgICAgICAgICAgICAgIGNvbnN0IGhhbmRsZUNvZGVDaGFuZ2UgPSAobmV3Q29kZTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgICAgICBbZmllbGQubmFtZV06IG51bGwsICAgICAgICAvLyBMaW1waWFtb3MgZWwgSURcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb2RlRmllbGRdOiBuZXdDb2RlLCAgICAgIC8vIEFjdHVhbGl6YW1vcyBlbCBjw7NkaWdvIHF1ZSBzZSB0aXBlYVxuICAgICAgICAgICAgICAgICAgICAgICAgW25hbWVGaWVsZF06IG51bGwsICAgICAgICAgLy8gTGltcGlhbW9zIGVsIG5vbWJyZVxuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGhhbmRsZUNvZGVTdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFmaWVsZC5yZWxhdGlvbmFsQ29uZmlnKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbW9kID0gZmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWcgYXMgeyBsaXN0SXRlbUNvZGVLZXk/OiBzdHJpbmc7IGxpc3RJdGVtTmFtZUtleT86IHN0cmluZyB9IHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtQ29kZUtleSA9IG1vZD8ubGlzdEl0ZW1Db2RlS2V5ID8/IGNvZGVGaWVsZDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXRlbU5hbWVLZXkgPSBtb2Q/Lmxpc3RJdGVtTmFtZUtleSA/PyBuYW1lRmllbGQ7XG5cbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gZmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWcuZW5kcG9pbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxSZWxhdGlvbmFsSXRlbT4oZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogaXRlbUNvZGVLZXksIHZhbHVlOiBjb2RlVmFsdWUgfV0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ZpZWxkLm5hbWVdOiBpdGVtLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY29kZUZpZWxkXTogaXRlbVtpdGVtQ29kZUtleV0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuYW1lRmllbGRdOiBpdGVtW2l0ZW1OYW1lS2V5XSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgJyR7aXRlbVtpdGVtTmFtZUtleV19JyBzZWxlY2Npb25hZG8uYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKGBObyBzZSBlbmNvbnRyw7MgbmluZ8O6biDDrXRlbSBjb24gZWwgY8OzZGlnbyBcIiR7Y29kZVZhbHVlfVwiLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkLm5hbWVdOiBudWxsLCBbbmFtZUZpZWxkXTogbnVsbCB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgcG9yIGPDs2RpZ28uXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICBjb25zdCBoYW5kbGVDbGVhciA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgIFtmaWVsZC5uYW1lXTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb2RlRmllbGRdOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgW25hbWVGaWVsZF06IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtjb2RlVmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e25hbWVWYWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17cmVhZE9ubHkgPyAoKSA9PiB7fSA6IGhhbmRsZUNvZGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e3JlYWRPbmx5ID8gKCkgPT4ge30gOiBoYW5kbGVDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17cmVhZE9ubHkgPyAoKSA9PiB7fSA6ICgpID0+IGhhbmRsZU9wZW5TZWFyY2hNb2RhbChmaWVsZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9e3JlYWRPbmx5ID8gKCkgPT4ge30gOiBoYW5kbGVDbGVhcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGhhc0Vycm9yPXshIWVycm9yc1tTdHJpbmcoZmllbGQubmFtZSldfVxuICAgICAgICAgICAgICAgICAgICAgICAgbWFzaz17bWFza1RvQXBwbHl9IC8vIOKchSBBR1JFR0FSIE3DgVNDQVJBXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOKchSBOVUVWTyBDQVNPOiBhcnJheS1zdHJpbmdcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LXN0cmluZyc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcnJheVZhbHVlcyA9IEFycmF5LmlzQXJyYXkocmF3VmFsdWUpID8gcmF3VmFsdWUgOiBbXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8QXJyYXlTdHJpbmdJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVzPXthcnJheVZhbHVlcyBhcyBzdHJpbmdbXX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsobmV3VmFsdWVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBbZmllbGQubmFtZV06IG5ld1ZhbHVlcyB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2ZpZWxkLnBsYWNlaG9sZGVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRmllbGRSZWFkb25seX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnbnVtYmVyJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IG51bWVyaWNWYWx1ZSA9IHR5cGVvZiByYXdWYWx1ZSA9PT0gJ251bWJlcicgPyByYXdWYWx1ZSA6IE51bWJlcihyYXdWYWx1ZSkgfHwgMDtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e2Fzc2lnblJlZiBhcyBSZWFjdC5SZWY8SFRNTElucHV0RWxlbWVudD59XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD17U3RyaW5nKGZpZWxkLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17U3RyaW5nKGZpZWxkLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e251bWVyaWNWYWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtyZWFkT25seSA/ICgpID0+IHt9IDogKG51bSkgPT4gaGFuZGxlTnVtZXJpY0ZpZWxkQ2hhbmdlKFN0cmluZyhmaWVsZC5uYW1lKSwgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmaWVsZC5wbGFjZWhvbGRlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5PXtpc0ZpZWxkUmVhZG9ubHl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNGaWVsZFJlYWRvbmx5fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAndGV4dCc6XG4gICAgICAgICAgICBjYXNlICdlbWFpbCc6XG4gICAgICAgICAgICBjYXNlICdwYXNzd29yZCc6XG4gICAgICAgICAgICBkZWZhdWx0OiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2luZ2xlVmFsdWUgPSByYXdWYWx1ZSA9PSBudWxsID8gJycgOiBTdHJpbmcocmF3VmFsdWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3BsYXlWYWx1ZSA9IGZpZWxkLm1hc2sgPyBhcHBseU1hc2soZmllbGQubWFzaywgc2luZ2xlVmFsdWUpIDogc2luZ2xlVmFsdWU7XG4gICAgICAgICAgICAgICAgY29uc3QgbWFzayA9IGZpZWxkLm1hc2sgPyBnZXRNYXNrKGZpZWxkLm1hc2spIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0VHlwZSA9IGZpZWxkLnR5cGUgPT09ICdlbWFpbCcgJiYgZmllbGQuYWxsb3dNdWx0aXBsZUVtYWlscyA/ICd0ZXh0JyA6IGZpZWxkLnR5cGU7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17YXNzaWduUmVmIGFzIFJlYWN0LlJlZjxIVE1MSW5wdXRFbGVtZW50Pn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e2lucHV0VHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtTdHJpbmcoZmllbGQubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtTdHJpbmcoZmllbGQubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlzcGxheVZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmaWVsZC5wbGFjZWhvbGRlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5PXtpc0ZpZWxkUmVhZG9ubHl9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXttYXNrPy5tYXhMZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNlwiPlxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2VkaXQnID8gYEVkaXRhciAke2NvbmZpZy5tb2R1bGVOYW1lfWAgOiBgQ3JlYXIgTnVldm8gJHtjb25maWcubW9kdWxlTmFtZX1gfVxuICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwibXQtNiBzcGFjZS15LThcIiBub1ZhbGlkYXRlIGF1dG9Db21wbGV0ZT1cIm9mZlwiPlxuICAgICAgICAgICAgICAgICAgICB7Y29uZmlnLmZvcm0uYmxvY2subWFwKChibG9jaywgYmxvY2tJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Jsb2NrLm5hbWV9IGNsYXNzTmFtZT17YmxvY2tJbmRleCA+IDAgPyBcInB0LTggYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCIgOiBcIlwifT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+e2Jsb2NrLm5hbWV9PC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgbXQtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmxvY2suZmllbGRzLmZpbHRlcihmID0+ICFmLmRldGFpbE9ubHkpLm1hcChmaWVsZCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1Zpc2libGUgPSBmaWVsZC52aXNpYmxlV2hlbiA/IGZpZWxkLnZpc2libGVXaGVuKGZvcm1EYXRhKSA6IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzVmlzaWJsZSkgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNFcnJvciA9ICEhZXJyb3JzW1N0cmluZyhmaWVsZC5uYW1lKV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtTdHJpbmcoZmllbGQubmFtZSl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17U3RyaW5nKGZpZWxkLm5hbWUpfSBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZC5sYWJlbH0geyh0eXBlb2YgZmllbGQubWFuZGF0b3J5ID09PSAnZnVuY3Rpb24nID8gZmllbGQubWFuZGF0b3J5KGZvcm1EYXRhKSA6ICEhZmllbGQubWFuZGF0b3J5KSAmJiBpc1Zpc2libGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtoYXNFcnJvciA/ICdoYXMtZXJyb3InIDogJyd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckZpZWxkKGZpZWxkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoYXNFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9yc1tTdHJpbmcoZmllbGQubmFtZSldfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIEFRVcONIEVTVMOBIExBIE1BR0lBOiBSZW5kZXJpemFtb3MgbG8gcXVlIGVsIHBhZHJlIHF1aWVyYSBpbnllY3RhciAqL31cbiAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgICAgICAgICAgICB7cmVuZGVyRXh0cmFDb250ZW50Py4oZm9ybURhdGEpfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBtdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgoY29uZmlnLmJhc2VSb3V0ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWb2x2ZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyFyZWFkT25seSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgQ2FtYmlvc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7Y3VycmVudEZpZWxkICYmIGN1cnJlbnRGaWVsZC5yZWxhdGlvbmFsQ29uZmlnICYmIChcbiAgICAgICAgICAgICAgICA8U2VhcmNoTW9kYWxcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXtpc1NlYXJjaE1vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VTZWFyY2hNb2RhbH1cbiAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9e2hhbmRsZVNlbGVjdH1cbiAgICAgICAgICAgICAgICAgICAgY29uZmlnPXtjdXJyZW50RmllbGQucmVsYXRpb25hbENvbmZpZy5tb2R1bGVDb25maWd9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVBhZ2UudHN4In0=