import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboards/components/ExchangeRateCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/dashboards/components/ExchangeRateCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { getExchangeRate } from "/src/services/apiService.ts";
export const ExchangeRateCard = () => {
  _s();
  const [exchangeData, setExchangeData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    const fetchExchangeRate = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await getExchangeRate();
        setExchangeData(data);
      } catch (err) {
        setError("No se pudo cargar la cotización.");
        console.error("Error fetching exchange rate:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchExchangeRate();
  }, []);
  const getFormattedDate = (utcDateString) => {
    const date = /* @__PURE__ */ new Date(utcDateString + "Z");
    const formatter = new Intl.DateTimeFormat("es-AR", {
      timeZone: "America/Argentina/Buenos_Aires",
      // Zona horaria para GMT-3
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
      // Forzamos el formato de 24 horas.
    });
    return formatter.format(date);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-white rounded-lg shadow-md h-full", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-700", children: "Cotización Dólar (Venta)" }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
      lineNumber: 70,
      columnNumber: 13
    }, this),
    loading && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500", children: "Cargando..." }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
      lineNumber: 72,
      columnNumber: 25
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 font-semibold text-red-500", children: error }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
      lineNumber: 74,
      columnNumber: 23
    }, this),
    exchangeData && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold text-green-600", children: [
        "$",
        parseFloat(exchangeData.valor_venta).toLocaleString("es-AR", { minimumFractionDigits: 2 })
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
        lineNumber: 78,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: [
        "Fuente: ",
        exchangeData.fuente
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
        lineNumber: 81,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: [
        "Actualizado: ",
        getFormattedDate(exchangeData.fecha_consulta)
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
        lineNumber: 84,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/dashboards/components/ExchangeRateCard.tsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
};
_s(ExchangeRateCard, "g+i5IPCJppa5ev199BD15Fp3JZE=");
_c = ExchangeRateCard;
var _c;
$RefreshReg$(_c, "ExchangeRateCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/dashboards/components/ExchangeRateCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/dashboards/components/ExchangeRateCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhEWixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsdUJBQXVCO0FBR3pCLGFBQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJTixTQUE4QixJQUFJO0FBQzFFLFFBQU0sQ0FBQ08sU0FBU0MsVUFBVSxJQUFJUixTQUFrQixJQUFJO0FBQ3BELFFBQU0sQ0FBQ1MsT0FBT0MsUUFBUSxJQUFJVixTQUF3QixJQUFJO0FBRXREQyxZQUFVLE1BQU07QUFDWixVQUFNVSxvQkFBb0IsWUFBWTtBQUNsQyxVQUFJO0FBQ0FILG1CQUFXLElBQUk7QUFDZkUsaUJBQVMsSUFBSTtBQUNiLGNBQU1FLE9BQU8sTUFBTVYsZ0JBQWdCO0FBQ25DSSx3QkFBZ0JNLElBQUk7QUFBQSxNQUN4QixTQUFTQyxLQUFLO0FBQ1ZILGlCQUFTLGtDQUFrQztBQUMzQ0ksZ0JBQVFMLE1BQU0saUNBQWlDSSxHQUFHO0FBQUEsTUFDdEQsVUFBQztBQUNHTCxtQkFBVyxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNKO0FBRUFHLHNCQUFrQjtBQUFBLEVBQ3RCLEdBQUcsRUFBRTtBQUVMLFFBQU1JLG1CQUFtQkEsQ0FBQ0Msa0JBQTBCO0FBRWhELFVBQU1DLE9BQU8sb0JBQUlDLEtBQUtGLGdCQUFnQixHQUFHO0FBR3pDLFVBQU1HLFlBQVksSUFBSUMsS0FBS0MsZUFBZSxTQUFTO0FBQUEsTUFDL0NDLFVBQVU7QUFBQTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsUUFBUTtBQUFBO0FBQUEsSUFDWixDQUFDO0FBR0QsV0FBT1QsVUFBVVUsT0FBT1osSUFBSTtBQUFBLEVBQ2hDO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSwyQkFBQyxRQUFHLFdBQVUsdUNBQXNDLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFO0FBQUEsSUFFM0VWLFdBQVcsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQiwyQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBRXhERSxTQUFTLHVCQUFDLE9BQUUsV0FBVSxtQ0FBbUNBLG1CQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNEO0FBQUEsSUFFL0RKLGdCQUNHLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHFDQUFtQztBQUFBO0FBQUEsUUFDMUN5QixXQUFXekIsYUFBYTBCLFdBQVcsRUFBRUMsZUFBZSxTQUFTLEVBQUVDLHVCQUF1QixFQUFFLENBQUM7QUFBQSxXQUQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEI7QUFBQTtBQUFBLFFBQzVCNUIsYUFBYTZCO0FBQUFBLFdBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUMyRDtBQUFBO0FBQUEsUUFDdERuQixpQkFBaUJWLGFBQWE4QixjQUFjO0FBQUEsV0FGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxPQW5CUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRVI7QUFBRS9CLEdBbEVXRCxrQkFBZ0I7QUFBQWlDLEtBQWhCakM7QUFBZ0IsSUFBQWlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImdldEV4Y2hhbmdlUmF0ZSIsIkV4Y2hhbmdlUmF0ZUNhcmQiLCJfcyIsImV4Y2hhbmdlRGF0YSIsInNldEV4Y2hhbmdlRGF0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImZldGNoRXhjaGFuZ2VSYXRlIiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJnZXRGb3JtYXR0ZWREYXRlIiwidXRjRGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwiZm9ybWF0dGVyIiwiSW50bCIsIkRhdGVUaW1lRm9ybWF0IiwidGltZVpvbmUiLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJob3VyIiwibWludXRlIiwiaG91cjEyIiwiZm9ybWF0IiwicGFyc2VGbG9hdCIsInZhbG9yX3ZlbnRhIiwidG9Mb2NhbGVTdHJpbmciLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJmdWVudGUiLCJmZWNoYV9jb25zdWx0YSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkV4Y2hhbmdlUmF0ZUNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9kYXNoYm9hcmQvY29tcG9uZW50cy9FeGNoYW5nZVJhdGVDYXJkLnRzeFxuXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0RXhjaGFuZ2VSYXRlIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgdHlwZSB7IEV4Y2hhbmdlUmF0ZSB9IGZyb20gJy4uLy4uLy4uL2ludGVyZmFjZXMvRXhjaGFuZ2UnO1xuXG5leHBvcnQgY29uc3QgRXhjaGFuZ2VSYXRlQ2FyZCA9ICgpID0+IHtcbiAgICBjb25zdCBbZXhjaGFuZ2VEYXRhLCBzZXRFeGNoYW5nZURhdGFdID0gdXNlU3RhdGU8RXhjaGFuZ2VSYXRlIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZldGNoRXhjaGFuZ2VSYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRFeGNoYW5nZVJhdGUoKTtcbiAgICAgICAgICAgICAgICBzZXRFeGNoYW5nZURhdGEoZGF0YSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBzZXRFcnJvcignTm8gc2UgcHVkbyBjYXJnYXIgbGEgY290aXphY2nDs24uJyk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZXhjaGFuZ2UgcmF0ZTonLCBlcnIpO1xuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBmZXRjaEV4Y2hhbmdlUmF0ZSgpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGdldEZvcm1hdHRlZERhdGUgPSAodXRjRGF0ZVN0cmluZzogc3RyaW5nKSA9PiB7XG4gICAgICAgIC8vIDEuIEFzZWd1cmFtb3MgcXVlIGxhIGZlY2hhIHNlIGludGVycHJldGUgY29tbyBVVEMgYcOxYWRpZW5kbyAnWicgYWwgZmluYWwuXG4gICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh1dGNEYXRlU3RyaW5nICsgJ1onKTtcblxuICAgICAgICAvLyAyLiBDcmVhbW9zIHVuIGZvcm1hdGVhZG9yIHBhcmEgJ2VzLUFSJyBjb24gbGFzIG9wY2lvbmVzIGRlc2VhZGFzLlxuICAgICAgICBjb25zdCBmb3JtYXR0ZXIgPSBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgnZXMtQVInLCB7XG4gICAgICAgICAgICB0aW1lWm9uZTogJ0FtZXJpY2EvQXJnZW50aW5hL0J1ZW5vc19BaXJlcycsIC8vIFpvbmEgaG9yYXJpYSBwYXJhIEdNVC0zXG4gICAgICAgICAgICB5ZWFyOiAnbnVtZXJpYycsXG4gICAgICAgICAgICBtb250aDogJzItZGlnaXQnLFxuICAgICAgICAgICAgZGF5OiAnMi1kaWdpdCcsXG4gICAgICAgICAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgICAgICAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgICAgICAgICAgIGhvdXIxMjogZmFsc2UsIC8vIEZvcnphbW9zIGVsIGZvcm1hdG8gZGUgMjQgaG9yYXMuXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIDMuIFJldG9ybmFtb3MgbGEgZmVjaGEgZm9ybWF0ZWFkYS5cbiAgICAgICAgcmV0dXJuIGZvcm1hdHRlci5mb3JtYXQoZGF0ZSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LW1kIGgtZnVsbFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+Q290aXphY2nDs24gRMOzbGFyIChWZW50YSk8L2gyPlxuXG4gICAgICAgICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtZ3JheS01MDBcIj5DYXJnYW5kby4uLjwvcD59XG5cbiAgICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJtdC00IGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvcD59XG5cbiAgICAgICAgICAgIHtleGNoYW5nZURhdGEgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICR7cGFyc2VGbG9hdChleGNoYW5nZURhdGEudmFsb3JfdmVudGEpLnRvTG9jYWxlU3RyaW5nKCdlcy1BUicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBGdWVudGU6IHtleGNoYW5nZURhdGEuZnVlbnRlfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIFVzYW1vcyBsYSBudWV2YSBmdW5jacOzbiBwYXJhIG1vc3RyYXIgbGEgZmVjaGEgY29ycmVjdGFtZW50ZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIEFjdHVhbGl6YWRvOiB7Z2V0Rm9ybWF0dGVkRGF0ZShleGNoYW5nZURhdGEuZmVjaGFfY29uc3VsdGEpfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2Rhc2hib2FyZHMvY29tcG9uZW50cy9FeGNoYW5nZVJhdGVDYXJkLnRzeCJ9