import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericCardList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericCardList.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { GenericCard } from "/src/components/common/GenericCard.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { FaSort } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const GenericCardList = ({
  data,
  columns,
  baseRoute,
  onDelete,
  paginationLinks,
  isAppending,
  onLoadMore,
  onSort,
  sortBy,
  sortDirection,
  disableEdit,
  onRowClick,
  canEdit = true,
  canDelete = true,
  enableRowSelection = false,
  selectedIds,
  onToggleRow,
  onTogglePage
}) => {
  const columnSortKey = (col) => col.sortField ?? String(col.accessor);
  const handleSortChange = (e) => {
    const value = e.target.value;
    if (value) {
      onSort(value);
    }
  };
  const pageIds = data.map((item) => Number(item.id)).filter((id) => Number.isFinite(id));
  const allPageSelected = enableRowSelection && pageIds.length > 0 && pageIds.every((id) => selectedIds?.has(id));
  const somePageSelected = enableRowSelection && pageIds.some((id) => selectedIds?.has(id)) && !allPageSelected;
  const handlePageCheckboxChange = () => {
    if (!onTogglePage) return;
    onTogglePage(pageIds, !allPageSelected);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
    enableRowSelection && pageIds.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-4", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: allPageSelected,
          ref: (el) => {
            if (el) el.indeterminate = somePageSelected;
          },
          onChange: handlePageCheckboxChange,
          "aria-label": "Seleccionar todos los de la página",
          className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
          autoComplete: "off"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/GenericCardList.tsx",
          lineNumber: 101,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-sm text-gray-700", children: "Seleccionar todos (página)" }, void 0, false, {
        fileName: "/app/src/components/common/GenericCardList.tsx",
        lineNumber: 110,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericCardList.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "sort-by", className: "mr-2 text-sm font-medium text-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaSort, { className: "inline mr-1" }, void 0, false, {
          fileName: "/app/src/components/common/GenericCardList.tsx",
          lineNumber: 116,
          columnNumber: 21
        }, this),
        "Ordenar por:"
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericCardList.tsx",
        lineNumber: 115,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          id: "sort-by",
          value: sortBy ? String(sortBy) : "",
          onChange: handleSortChange,
          className: "block w-48 py-2 pl-3 pr-10 text-base border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccionar..." }, void 0, false, {
              fileName: "/app/src/components/common/GenericCardList.tsx",
              lineNumber: 125,
              columnNumber: 21
            }, this),
            columns.map(
              (col) => /* @__PURE__ */ jsxDEV("option", { value: columnSortKey(col), children: col.header }, String(col.accessor), false, {
                fileName: "/app/src/components/common/GenericCardList.tsx",
                lineNumber: 127,
                columnNumber: 11
              }, this)
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/common/GenericCardList.tsx",
          lineNumber: 119,
          columnNumber: 17
        },
        this
      ),
      sortBy && /* @__PURE__ */ jsxDEV("button", { onClick: () => onSort(sortBy), className: "p-2 ml-2 border rounded-md", children: sortDirection === "asc" ? "ASC" : "DESC" }, void 0, false, {
        fileName: "/app/src/components/common/GenericCardList.tsx",
        lineNumber: 134,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericCardList.tsx",
      lineNumber: 114,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: data.map(
      (item) => /* @__PURE__ */ jsxDEV(
        GenericCard,
        {
          item,
          columns,
          baseRoute,
          onDelete,
          disableEdit,
          onRowClick,
          canEdit,
          canDelete,
          enableRowSelection,
          selected: selectedIds?.has(Number(item.id)) ?? false,
          onToggleSelect: () => onToggleRow?.(Number(item.id))
        },
        item.id,
        false,
        {
          fileName: "/app/src/components/common/GenericCardList.tsx",
          lineNumber: 142,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/app/src/components/common/GenericCardList.tsx",
      lineNumber: 140,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center mt-6", children: paginationLinks?.next && /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: onLoadMore,
        disabled: isAppending,
        className: "inline-flex items-center justify-center w-full px-6 py-3 text-base font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-indigo-400 disabled:cursor-wait",
        children: isAppending ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(LoadingSpinner, { className: "w-5 h-5 mr-3 -ml-1" }, void 0, false, {
            fileName: "/app/src/components/common/GenericCardList.tsx",
            lineNumber: 168,
            columnNumber: 33
          }, this),
          "Cargando..."
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericCardList.tsx",
          lineNumber: 167,
          columnNumber: 11
        }, this) : "Cargar más"
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/GenericCardList.tsx",
        lineNumber: 161,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/common/GenericCardList.tsx",
      lineNumber: 159,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/GenericCardList.tsx",
    lineNumber: 98,
    columnNumber: 5
  }, this);
};
_c = GenericCardList;
var _c;
$RefreshReg$(_c, "GenericCardList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericCardList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericCardList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZvQixTQWtFUSxVQWxFUjs7Ozs7Ozs7Ozs7Ozs7OztBQS9FcEIsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0Msc0JBQXNCO0FBRS9CLFNBQVNDLGNBQWM7QUF3QmhCLGFBQU1DLGtCQUFrQixDQUF3QjtBQUFBLEVBQ25EQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUFBLEVBQ1pDLHFCQUFxQjtBQUFBLEVBQ3JCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNxQixNQUFNO0FBRzNCLFFBQU1DLGdCQUFnQkEsQ0FBQ0MsUUFBNkJBLElBQUlDLGFBQWFDLE9BQU9GLElBQUlHLFFBQVE7QUFFeEYsUUFBTUMsbUJBQW1CQSxDQUFDQyxNQUE0QztBQUNsRSxVQUFNQyxRQUFRRCxFQUFFRSxPQUFPRDtBQUN2QixRQUFJQSxPQUFPO0FBQ1BsQixhQUFPa0IsS0FBSztBQUFBLElBQ2hCO0FBQUEsRUFDSjtBQUVBLFFBQU1FLFVBQVUzQixLQUFLNEIsSUFBSSxDQUFBQyxTQUFRQyxPQUFPRCxLQUFLRSxFQUFFLENBQUMsRUFBRUMsT0FBTyxDQUFBRCxPQUFNRCxPQUFPRyxTQUFTRixFQUFFLENBQUM7QUFDbEYsUUFBTUcsa0JBQ0ZwQixzQkFDQWEsUUFBUVEsU0FBUyxLQUNqQlIsUUFBUVMsTUFBTSxDQUFBTCxPQUFNaEIsYUFBYXNCLElBQUlOLEVBQUUsQ0FBQztBQUM1QyxRQUFNTyxtQkFDRnhCLHNCQUNBYSxRQUFRWSxLQUFLLENBQUFSLE9BQU1oQixhQUFhc0IsSUFBSU4sRUFBRSxDQUFDLEtBQ3ZDLENBQUNHO0FBRUwsUUFBTU0sMkJBQTJCQSxNQUFNO0FBQ25DLFFBQUksQ0FBQ3ZCLGFBQWM7QUFDbkJBLGlCQUFhVSxTQUFTLENBQUNPLGVBQWU7QUFBQSxFQUMxQztBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLFFBQ1ZwQjtBQUFBQSwwQkFBc0JhLFFBQVFRLFNBQVMsS0FDcEMsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVNEO0FBQUFBLFVBQ1QsS0FBSyxDQUFBTyxPQUFNO0FBQ1AsZ0JBQUlBLEdBQUlBLElBQUdDLGdCQUFnQko7QUFBQUEsVUFDL0I7QUFBQSxVQUNBLFVBQVVFO0FBQUFBLFVBQ1YsY0FBVztBQUFBLFVBQ1gsV0FBVTtBQUFBLFVBQXdFLGNBQWE7QUFBQTtBQUFBLFFBUm5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVF3RztBQUFBLE1BQ3hHLHVCQUFDLFVBQUssV0FBVSw4QkFBNkIsMENBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxTQVYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdKLHVCQUFDLFNBQUksV0FBVSxzQ0FDWDtBQUFBLDZCQUFDLFdBQU0sU0FBUSxXQUFVLFdBQVUsMENBQy9CO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUE7QUFBQSxXQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxJQUFHO0FBQUEsVUFDSCxPQUFPaEMsU0FBU2EsT0FBT2IsTUFBTSxJQUFJO0FBQUEsVUFDakMsVUFBVWU7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFlBQU8sT0FBTSxJQUFHLDhCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQzlCdEIsUUFBUTJCO0FBQUFBLGNBQUksQ0FBQVQsUUFDVCx1QkFBQyxZQUFrQyxPQUFPRCxjQUFjQyxHQUFHLEdBQ3REQSxjQUFJd0IsVUFESXRCLE9BQU9GLElBQUlHLFFBQVEsR0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0g7QUFBQTtBQUFBO0FBQUEsUUFYTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLE1BRUNkLFVBQ0csdUJBQUMsWUFBTyxTQUFTLE1BQU1ELE9BQU9DLE1BQU0sR0FBRyxXQUFVLDhCQUM1Q0MsNEJBQWtCLFFBQVEsUUFBUSxVQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXRCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDVlQsZUFBSzRCO0FBQUFBLE1BQUksQ0FBQ0MsU0FDUDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUc7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsVUFBVWQsYUFBYXNCLElBQUlQLE9BQU9ELEtBQUtFLEVBQUUsQ0FBQyxLQUFLO0FBQUEsVUFDL0MsZ0JBQWdCLE1BQU1mLGNBQWNjLE9BQU9ELEtBQUtFLEVBQUUsQ0FBQztBQUFBO0FBQUEsUUFYOUNGLEtBQUtFO0FBQUFBLFFBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVl5RDtBQUFBLElBRTVELEtBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDVjNCLDJCQUFpQndDLFFBQ2Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFNBQVN0QztBQUFBQSxRQUNULFVBQVVEO0FBQUFBLFFBQ1YsV0FBVTtBQUFBLFFBRVRBLHdCQUNHLG1DQUNJO0FBQUEsaUNBQUMsa0JBQWUsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQTtBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUVBO0FBQUE7QUFBQSxNQVhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWFBLEtBZlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BOUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFUjtBQUFFd0MsS0FoSVc5QztBQUFlLElBQUE4QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJHZW5lcmljQ2FyZCIsIkxvYWRpbmdTcGlubmVyIiwiRmFTb3J0IiwiR2VuZXJpY0NhcmRMaXN0IiwiZGF0YSIsImNvbHVtbnMiLCJiYXNlUm91dGUiLCJvbkRlbGV0ZSIsInBhZ2luYXRpb25MaW5rcyIsImlzQXBwZW5kaW5nIiwib25Mb2FkTW9yZSIsIm9uU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJkaXNhYmxlRWRpdCIsIm9uUm93Q2xpY2siLCJjYW5FZGl0IiwiY2FuRGVsZXRlIiwiZW5hYmxlUm93U2VsZWN0aW9uIiwic2VsZWN0ZWRJZHMiLCJvblRvZ2dsZVJvdyIsIm9uVG9nZ2xlUGFnZSIsImNvbHVtblNvcnRLZXkiLCJjb2wiLCJzb3J0RmllbGQiLCJTdHJpbmciLCJhY2Nlc3NvciIsImhhbmRsZVNvcnRDaGFuZ2UiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJwYWdlSWRzIiwibWFwIiwiaXRlbSIsIk51bWJlciIsImlkIiwiZmlsdGVyIiwiaXNGaW5pdGUiLCJhbGxQYWdlU2VsZWN0ZWQiLCJsZW5ndGgiLCJldmVyeSIsImhhcyIsInNvbWVQYWdlU2VsZWN0ZWQiLCJzb21lIiwiaGFuZGxlUGFnZUNoZWNrYm94Q2hhbmdlIiwiZWwiLCJpbmRldGVybWluYXRlIiwiaGVhZGVyIiwibmV4dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkdlbmVyaWNDYXJkTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuLy8gc3JjL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNDYXJkTGlzdC50c3hcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBHZW5lcmljQ2FyZCB9IGZyb20gJy4vR2VuZXJpY0NhcmQnO1xuaW1wb3J0IHR5cGUgeyBDb2x1bW5EZWZpbml0aW9uIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgdHlwZSB7IFBhZ2luYXRlZFJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy9BcGknO1xuaW1wb3J0IHsgRmFTb3J0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuXG5pbnRlcmZhY2UgR2VuZXJpY0NhcmRMaXN0UHJvcHM8VCBleHRlbmRzIHsgaWQ6IGFueSB9PiB7XG4gICAgZGF0YTogVFtdO1xuICAgIGNvbHVtbnM6IENvbHVtbkRlZmluaXRpb248VD5bXTtcbiAgICBiYXNlUm91dGU6IHN0cmluZztcbiAgICBvbkRlbGV0ZT86IChpZDogbnVtYmVyIHwgc3RyaW5nKSA9PiB2b2lkO1xuICAgIHBhZ2luYXRpb25MaW5rczogUGFnaW5hdGVkUmVzcG9uc2U8YW55PlsnbGlua3MnXSB8IG51bGw7XG4gICAgaXNBcHBlbmRpbmc6IGJvb2xlYW47XG4gICAgb25Mb2FkTW9yZTogKCkgPT4gdm9pZDtcbiAgICAvLyDinIUgTlVFVk86IEHDsWFkaW1vcyBsYXMgcHJvcHMgZGUgb3JkZW5hbWllbnRvIHF1ZSB5YSByZWNpYsOtYW1vcyBwZXJvIG5vIHVzw6FiYW1vc1xuICAgIG9uU29ydDogKHNvcnRGaWVsZDogc3RyaW5nKSA9PiB2b2lkO1xuICAgIHNvcnRCeTogc3RyaW5nIHwgbnVsbDtcbiAgICBzb3J0RGlyZWN0aW9uOiAnYXNjJyB8ICdkZXNjJyB8IG51bGw7XG4gICAgZGlzYWJsZUVkaXQ/OiBib29sZWFuO1xuICAgIG9uUm93Q2xpY2s/OiAoaXRlbTogYW55KSA9PiB2b2lkO1xuICAgIGNhbkVkaXQ/OiBib29sZWFuIHwgKChpdGVtOiBUKSA9PiBib29sZWFuKTsgLy8g4pyFIFBlcm1pc28gcGFyYSBlZGl0YXIgKHB1ZWRlIHNlciBmdW5jacOzbilcbiAgICBjYW5EZWxldGU/OiBib29sZWFuIHwgKChpdGVtOiBUKSA9PiBib29sZWFuKTsgLy8g4pyFIFBlcm1pc28gcGFyYSBlbGltaW5hciAocHVlZGUgc2VyIGZ1bmNpw7NuKVxuICAgIGVuYWJsZVJvd1NlbGVjdGlvbj86IGJvb2xlYW47XG4gICAgc2VsZWN0ZWRJZHM/OiBTZXQ8bnVtYmVyPjtcbiAgICBvblRvZ2dsZVJvdz86IChpZDogbnVtYmVyKSA9PiB2b2lkO1xuICAgIG9uVG9nZ2xlUGFnZT86IChpZHM6IG51bWJlcltdLCBjaGVja2VkOiBib29sZWFuKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgR2VuZXJpY0NhcmRMaXN0ID0gPFQgZXh0ZW5kcyB7IGlkOiBhbnkgfT4oe1xuICAgIGRhdGEsXG4gICAgY29sdW1ucyxcbiAgICBiYXNlUm91dGUsXG4gICAgb25EZWxldGUsXG4gICAgcGFnaW5hdGlvbkxpbmtzLFxuICAgIGlzQXBwZW5kaW5nLFxuICAgIG9uTG9hZE1vcmUsXG4gICAgb25Tb3J0LFxuICAgIHNvcnRCeSxcbiAgICBzb3J0RGlyZWN0aW9uLFxuICAgIGRpc2FibGVFZGl0LFxuICAgIG9uUm93Q2xpY2ssXG4gICAgY2FuRWRpdCA9IHRydWUsXG4gICAgY2FuRGVsZXRlID0gdHJ1ZSxcbiAgICBlbmFibGVSb3dTZWxlY3Rpb24gPSBmYWxzZSxcbiAgICBzZWxlY3RlZElkcyxcbiAgICBvblRvZ2dsZVJvdyxcbiAgICBvblRvZ2dsZVBhZ2UsXG59OiBHZW5lcmljQ2FyZExpc3RQcm9wczxUPikgPT4ge1xuXG4gICAgLy8g4pyFIE5VRVZPOiBIYW5kbGVyIHBhcmEgZWwgY2FtYmlvIGVuIGVsIHNlbGVjdCBkZSBvcmRlbmFtaWVudG9cbiAgICBjb25zdCBjb2x1bW5Tb3J0S2V5ID0gKGNvbDogQ29sdW1uRGVmaW5pdGlvbjxUPikgPT4gY29sLnNvcnRGaWVsZCA/PyBTdHJpbmcoY29sLmFjY2Vzc29yKTtcblxuICAgIGNvbnN0IGhhbmRsZVNvcnRDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTFNlbGVjdEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgb25Tb3J0KHZhbHVlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBwYWdlSWRzID0gZGF0YS5tYXAoaXRlbSA9PiBOdW1iZXIoaXRlbS5pZCkpLmZpbHRlcihpZCA9PiBOdW1iZXIuaXNGaW5pdGUoaWQpKTtcbiAgICBjb25zdCBhbGxQYWdlU2VsZWN0ZWQgPVxuICAgICAgICBlbmFibGVSb3dTZWxlY3Rpb24gJiZcbiAgICAgICAgcGFnZUlkcy5sZW5ndGggPiAwICYmXG4gICAgICAgIHBhZ2VJZHMuZXZlcnkoaWQgPT4gc2VsZWN0ZWRJZHM/LmhhcyhpZCkpO1xuICAgIGNvbnN0IHNvbWVQYWdlU2VsZWN0ZWQgPVxuICAgICAgICBlbmFibGVSb3dTZWxlY3Rpb24gJiZcbiAgICAgICAgcGFnZUlkcy5zb21lKGlkID0+IHNlbGVjdGVkSWRzPy5oYXMoaWQpKSAmJlxuICAgICAgICAhYWxsUGFnZVNlbGVjdGVkO1xuXG4gICAgY29uc3QgaGFuZGxlUGFnZUNoZWNrYm94Q2hhbmdlID0gKCkgPT4ge1xuICAgICAgICBpZiAoIW9uVG9nZ2xlUGFnZSkgcmV0dXJuO1xuICAgICAgICBvblRvZ2dsZVBhZ2UocGFnZUlkcywgIWFsbFBhZ2VTZWxlY3RlZCk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxuICAgICAgICAgICAge2VuYWJsZVJvd1NlbGVjdGlvbiAmJiBwYWdlSWRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItNFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXthbGxQYWdlU2VsZWN0ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e2VsID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZWwpIGVsLmluZGV0ZXJtaW5hdGUgPSBzb21lUGFnZVNlbGVjdGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYWdlQ2hlY2tib3hDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VsZWNjaW9uYXIgdG9kb3MgbG9zIGRlIGxhIHDDoWdpbmFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDAgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5TZWxlY2Npb25hciB0b2RvcyAocMOhZ2luYSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgey8qIOKchSBOVUVWTzogQ29udHJvbGVzIGRlIG9yZGVuYW1pZW50byBwYXJhIG3Ds3ZpbCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgbWItNFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic29ydC1ieVwiIGNsYXNzTmFtZT1cIm1yLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYVNvcnQgY2xhc3NOYW1lPVwiaW5saW5lIG1yLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICBPcmRlbmFyIHBvcjpcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzb3J0LWJ5XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NvcnRCeSA/IFN0cmluZyhzb3J0QnkpIDogJyd9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTb3J0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LTQ4IHB5LTIgcGwtMyBwci0xMCB0ZXh0LWJhc2UgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25hci4uLjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICB7Y29sdW1ucy5tYXAoY29sID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtTdHJpbmcoY29sLmFjY2Vzc29yKX0gdmFsdWU9e2NvbHVtblNvcnRLZXkoY29sKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5oZWFkZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgey8qIE9wY2lvbmFsOiB1biBib3TDs24gcGFyYSBjYW1iaWFyIGxhIGRpcmVjY2nDs24gKi99XG4gICAgICAgICAgICAgICAge3NvcnRCeSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb25Tb3J0KHNvcnRCeSl9IGNsYXNzTmFtZT1cInAtMiBtbC0yIGJvcmRlciByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c29ydERpcmVjdGlvbiA9PT0gJ2FzYycgPyAnQVNDJyA6ICdERVNDJ31cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIHtkYXRhLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8R2VuZXJpY0NhcmRcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxuICAgICAgICAgICAgICAgICAgICAgICAgYmFzZVJvdXRlPXtiYXNlUm91dGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17b25EZWxldGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlRWRpdD17ZGlzYWJsZUVkaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblJvd0NsaWNrPXtvblJvd0NsaWNrfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FuRWRpdD17Y2FuRWRpdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbkRlbGV0ZT17Y2FuRGVsZXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgZW5hYmxlUm93U2VsZWN0aW9uPXtlbmFibGVSb3dTZWxlY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZD17c2VsZWN0ZWRJZHM/LmhhcyhOdW1iZXIoaXRlbS5pZCkpID8/IGZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Ub2dnbGVTZWxlY3Q9eygpID0+IG9uVG9nZ2xlUm93Py4oTnVtYmVyKGl0ZW0uaWQpKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgbXQtNlwiPlxuICAgICAgICAgICAgICAgIHtwYWdpbmF0aW9uTGlua3M/Lm5leHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkxvYWRNb3JlfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbCBweC02IHB5LTMgdGV4dC1iYXNlIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6cmluZy1vZmZzZXQtMiBkaXNhYmxlZDpiZy1pbmRpZ28tNDAwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzQXBwZW5kaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkaW5nU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTMgLW1sLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYXJnYW5kby4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnQ2FyZ2FyIG3DoXMnXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0NhcmRMaXN0LnRzeCJ9