import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/clientes/pages/ClientesEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/clientes/pages/ClientesEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { ClientesFormPage } from "/src/features/clientes/pages/ClientesFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { resolveInvoiceSeriesForTaxChange } from "/src/utils/invoiceSeries.ts";
function normalizeCredit(value) {
  if (value == null || String(value).trim() === "") return 0;
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}
export const ClienteEditPage = () => {
  _s();
  const { id } = useParams();
  const { item: cliente, loading, error } = useCrudItem(clientesModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesEditPage.tsx",
    lineNumber: 38,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesEditPage.tsx",
    lineNumber: 39,
    columnNumber: 21
  }, this);
  if (!cliente) return /* @__PURE__ */ jsxDEV("div", { children: "Cliente no encontrado." }, void 0, false, {
    fileName: "/app/src/features/clientes/pages/ClientesEditPage.tsx",
    lineNumber: 40,
    columnNumber: 24
  }, this);
  const initialData = {
    ...cliente,
    credit: normalizeCredit(cliente.credit),
    serie: resolveInvoiceSeriesForTaxChange(String(cliente.tax ?? ""), cliente.serie) || cliente.serie
  };
  return /* @__PURE__ */ jsxDEV(
    ClientesFormPage,
    {
      mode: "edit",
      initialData,
      loading,
      error
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/clientes/pages/ClientesEditPage.tsx",
      lineNumber: 49,
      columnNumber: 5
    },
    this
  );
};
_s(ClienteEditPage, "ghzHQnGCnt9TkZMmZ1mPHx8koHo=", false, function() {
  return [useParams, useCrudItem];
});
_c = ClienteEditPage;
var _c;
$RefreshReg$(_c, "ClienteEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/clientes/pages/ClientesEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/clientes/pages/ClientesEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0J3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqQnhCLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDRCQUEwQztBQUNuRCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msd0NBQXdDO0FBRWpELFNBQVNDLGdCQUFnQkMsT0FBd0I7QUFDN0MsTUFBSUEsU0FBUyxRQUFRQyxPQUFPRCxLQUFLLEVBQUVFLEtBQUssTUFBTSxHQUFJLFFBQU87QUFDekQsUUFBTUMsSUFBSUMsT0FBT0osS0FBSztBQUN0QixTQUFPSSxPQUFPQyxTQUFTRixDQUFDLElBQUlBLElBQUk7QUFDcEM7QUFFTyxhQUFNRyxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLEVBQUVDLEdBQUcsSUFBSWYsVUFBMEI7QUFDekMsUUFBTSxFQUFFZ0IsTUFBTUMsU0FBU0MsU0FBU0MsTUFBTSxJQUFJakIsWUFBcUJDLHNCQUFzQlksRUFBRTtBQUV2RixNQUFJRyxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLFFBQVMsUUFBTyx1QkFBQyxTQUFJLHNDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkI7QUFFaEQsUUFBTUcsY0FBdUI7QUFBQSxJQUN6QixHQUFHSDtBQUFBQSxJQUNISSxRQUFRZixnQkFBZ0JXLFFBQVFJLE1BQU07QUFBQSxJQUN0Q0MsT0FBT2pCLGlDQUFpQ0csT0FBT1MsUUFBUU0sT0FBTyxFQUFFLEdBQUdOLFFBQVFLLEtBQUssS0FBS0wsUUFBUUs7QUFBQUEsRUFDakc7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUE7QUFBQSxJQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlpQjtBQUd6QjtBQUFFUixHQXRCV0QsaUJBQWU7QUFBQSxVQUNUYixXQUMyQkUsV0FBVztBQUFBO0FBQUFzQixLQUY1Q1g7QUFBZSxJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiQ2xpZW50ZXNGb3JtUGFnZSIsInVzZUNydWRJdGVtIiwiY2xpZW50ZXNNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsInJlc29sdmVJbnZvaWNlU2VyaWVzRm9yVGF4Q2hhbmdlIiwibm9ybWFsaXplQ3JlZGl0IiwidmFsdWUiLCJTdHJpbmciLCJ0cmltIiwibiIsIk51bWJlciIsImlzRmluaXRlIiwiQ2xpZW50ZUVkaXRQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJjbGllbnRlIiwibG9hZGluZyIsImVycm9yIiwiaW5pdGlhbERhdGEiLCJjcmVkaXQiLCJzZXJpZSIsInRheCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudGVzRWRpdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9jbGllbnRlcy9wYWdlcy9DbGllbnRlc0VkaXRQYWdlLnRzeFxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBDbGllbnRlc0Zvcm1QYWdlIH0gZnJvbSAnLi9DbGllbnRlc0Zvcm1QYWdlJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgY2xpZW50ZXNNb2R1bGVDb25maWcsIHR5cGUgQ2xpZW50ZSB9IGZyb20gJy4uL2NsaWVudGVzLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JUYXhDaGFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9pbnZvaWNlU2VyaWVzJztcblxuZnVuY3Rpb24gbm9ybWFsaXplQ3JlZGl0KHZhbHVlOiB1bmtub3duKTogbnVtYmVyIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCB8fCBTdHJpbmcodmFsdWUpLnRyaW0oKSA9PT0gJycpIHJldHVybiAwO1xuICAgIGNvbnN0IG4gPSBOdW1iZXIodmFsdWUpO1xuICAgIHJldHVybiBOdW1iZXIuaXNGaW5pdGUobikgPyBuIDogMDtcbn1cblxuZXhwb3J0IGNvbnN0IENsaWVudGVFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgeyBpdGVtOiBjbGllbnRlLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08Q2xpZW50ZT4oY2xpZW50ZXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWNsaWVudGUpIHJldHVybiA8ZGl2PkNsaWVudGUgbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICBjb25zdCBpbml0aWFsRGF0YTogQ2xpZW50ZSA9IHtcbiAgICAgICAgLi4uY2xpZW50ZSxcbiAgICAgICAgY3JlZGl0OiBub3JtYWxpemVDcmVkaXQoY2xpZW50ZS5jcmVkaXQpLFxuICAgICAgICBzZXJpZTogcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JUYXhDaGFuZ2UoU3RyaW5nKGNsaWVudGUudGF4ID8/ICcnKSwgY2xpZW50ZS5zZXJpZSkgfHwgY2xpZW50ZS5zZXJpZSxcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPENsaWVudGVzRm9ybVBhZ2VcbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsRGF0YX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBlcnJvcj17ZXJyb3J9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jbGllbnRlcy9wYWdlcy9DbGllbnRlc0VkaXRQYWdlLnRzeCJ9