import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/TopNavbar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/TopNavbar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link, NavLink, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { RxChevronDown } from "/node_modules/.vite/deps/react-icons_rx.js?v=cc4fbb62";
import { HiOutlineMenu, HiOutlineX } from "/node_modules/.vite/deps/react-icons_hi.js?v=cc4fbb62";
import { useAuth } from "/src/hooks/useAuth.ts";
import { filterMenuItems } from "/src/utils/menuFilter.ts";
import { MENU_ITEMS, getMenuIcon } from "/src/config/menuItems.tsx";
import { NavDropdownPanel } from "/src/components/layouts/NavDropdownPanel.tsx";
import {
  MenuNavFlatResults,
  MenuNavSearchBar,
  useMenuNavSearchResults
} from "/src/components/layouts/MenuNavSearch.tsx";
import { OrganizationLogo } from "/src/components/common/OrganizationLogo.tsx";
export const TopNavbar = () => {
  _s();
  const { user, permissions, logout } = useAuth();
  const [openDropdown, setOpenDropdown] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openMobileSection, setOpenMobileSection] = useState(null);
  const [navSearchQuery, setNavSearchQuery] = useState("");
  const navRef = useRef(null);
  const location = useLocation();
  const filteredItems = filterMenuItems(MENU_ITEMS, permissions);
  const navSearchResults = useMenuNavSearchResults(filteredItems, navSearchQuery);
  const isNavSearchActive = navSearchQuery.trim().length > 0;
  useEffect(() => {
    setOpenDropdown(null);
    setMobileMenuOpen(false);
    setNavSearchQuery("");
  }, [location.pathname]);
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (navRef.current && !navRef.current.contains(e.target)) {
        setOpenDropdown(null);
        setNavSearchQuery("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key !== "Escape") return;
      if (navSearchQuery.trim()) {
        setNavSearchQuery("");
      } else {
        setMobileMenuOpen(false);
      }
    };
    if (mobileMenuOpen) {
      document.addEventListener("keydown", handleEscape);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen, navSearchQuery]);
  const closeDropdown = () => setOpenDropdown(null);
  const toggleDropdown = (label) => {
    setOpenDropdown((prev) => prev === label ? null : label);
  };
  const closeMobileMenu = () => setMobileMenuOpen(false);
  const toggleMobileSection = (label) => {
    setOpenMobileSection((prev) => prev === label ? null : label);
  };
  const childrenToPanelItems = (children) => children.map((c) => ({
    path: c.path,
    label: c.label,
    icon: getMenuIcon(c.iconKey, 20),
    description: c.description
  }));
  const renderDesktopNav = () => /* @__PURE__ */ jsxDEV("nav", { className: "hidden lg:flex items-center gap-2 relative", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative shrink-0", children: [
      /* @__PURE__ */ jsxDEV(
        MenuNavSearchBar,
        {
          variant: "topDesktop",
          query: navSearchQuery,
          onQueryChange: setNavSearchQuery
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/layouts/TopNavbar.tsx",
          lineNumber: 107,
          columnNumber: 17
        },
        this
      ),
      isNavSearchActive && /* @__PURE__ */ jsxDEV("div", { className: "absolute left-0 top-full mt-1 z-50", children: /* @__PURE__ */ jsxDEV(
        MenuNavFlatResults,
        {
          entries: navSearchResults,
          variant: "topDesktop",
          onNavigate: () => setNavSearchQuery("")
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/layouts/TopNavbar.tsx",
          lineNumber: 114,
          columnNumber: 25
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/components/layouts/TopNavbar.tsx",
        lineNumber: 113,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/layouts/TopNavbar.tsx",
      lineNumber: 106,
      columnNumber: 13
    }, this),
    !isNavSearchActive && filteredItems.map((item) => {
      if (item.path && !item.children) {
        if (item.iconOnly) {
          return /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: item.path,
              className: "flex items-center justify-center w-10 h-10 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900",
              title: item.label,
              children: getMenuIcon(item.iconKey, 22)
            },
            item.label,
            false,
            {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 128,
              columnNumber: 13
            },
            this
          );
        }
        return /* @__PURE__ */ jsxDEV(
          NavLink,
          {
            to: item.path,
            className: ({ isActive }) => `flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"}`,
            children: [
              getMenuIcon(item.iconKey, 20),
              /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 147,
                columnNumber: 33
              }, this)
            ]
          },
          item.label,
          true,
          {
            fileName: "/app/src/components/layouts/TopNavbar.tsx",
            lineNumber: 139,
            columnNumber: 11
          },
          this
        );
      }
      if (item.children) {
        const isOpen = openDropdown === item.label;
        const isIconOnly = item.iconOnly;
        return /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => toggleDropdown(item.label),
              className: `flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isOpen ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"} ${isIconOnly ? "w-10 h-10 justify-center" : ""}`,
              title: isIconOnly ? item.label : void 0,
              children: [
                getMenuIcon(item.iconKey, isIconOnly ? 22 : 20),
                !isIconOnly && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                    fileName: "/app/src/components/layouts/TopNavbar.tsx",
                    lineNumber: 166,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    RxChevronDown,
                    {
                      className: `w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/components/layouts/TopNavbar.tsx",
                      lineNumber: 167,
                      columnNumber: 45
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 165,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 157,
              columnNumber: 33
            },
            this
          ),
          isOpen && /* @__PURE__ */ jsxDEV("div", { className: "absolute left-0 top-full mt-1 z-50", children: /* @__PURE__ */ jsxDEV(
            NavDropdownPanel,
            {
              items: childrenToPanelItems(item.children),
              onNavigate: closeDropdown
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 175,
              columnNumber: 41
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/components/layouts/TopNavbar.tsx",
            lineNumber: 174,
            columnNumber: 13
          }, this)
        ] }, item.label, true, {
          fileName: "/app/src/components/layouts/TopNavbar.tsx",
          lineNumber: 156,
          columnNumber: 11
        }, this);
      }
      return null;
    })
  ] }, void 0, true, {
    fileName: "/app/src/components/layouts/TopNavbar.tsx",
    lineNumber: 105,
    columnNumber: 3
  }, this);
  const renderMobileDrawer = () => {
    if (!mobileMenuOpen) return null;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          role: "button",
          tabIndex: 0,
          "aria-label": "Cerrar menú",
          className: "fixed inset-0 bg-black/50 z-40 lg:hidden",
          onClick: closeMobileMenu,
          onKeyDown: (e) => e.key === "Enter" && closeMobileMenu()
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/layouts/TopNavbar.tsx",
          lineNumber: 194,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "fixed left-0 top-0 h-full w-[280px] max-w-[85vw] bg-white shadow-xl z-50 overflow-y-auto lg:hidden",
          "aria-modal": "true",
          "aria-label": "Menú de navegación",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 border-b border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: "Menú" }, void 0, false, {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 208,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: closeMobileMenu,
                  className: "p-2 rounded-lg text-gray-600 hover:bg-gray-100",
                  "aria-label": "Cerrar menú",
                  children: /* @__PURE__ */ jsxDEV(HiOutlineX, { className: "w-6 h-6" }, void 0, false, {
                    fileName: "/app/src/components/layouts/TopNavbar.tsx",
                    lineNumber: 215,
                    columnNumber: 29
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 209,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 207,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              MenuNavSearchBar,
              {
                variant: "topMobile",
                query: navSearchQuery,
                onQueryChange: setNavSearchQuery
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 218,
                columnNumber: 21
              },
              this
            ),
            isNavSearchActive ? /* @__PURE__ */ jsxDEV(
              MenuNavFlatResults,
              {
                entries: navSearchResults,
                variant: "topMobile",
                onNavigate: () => {
                  setNavSearchQuery("");
                  closeMobileMenu();
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 224,
                columnNumber: 11
              },
              this
            ) : /* @__PURE__ */ jsxDEV("nav", { className: "p-2 flex flex-col gap-0.5", children: filteredItems.map((item) => {
              if (item.path && !item.children) {
                return /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: item.path,
                    onClick: closeMobileMenu,
                    className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-700 hover:bg-gray-100 font-medium",
                    children: [
                      getMenuIcon(item.iconKey, 22),
                      /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                        fileName: "/app/src/components/layouts/TopNavbar.tsx",
                        lineNumber: 244,
                        columnNumber: 45
                      }, this)
                    ]
                  },
                  item.label,
                  true,
                  {
                    fileName: "/app/src/components/layouts/TopNavbar.tsx",
                    lineNumber: 237,
                    columnNumber: 19
                  },
                  this
                );
              }
              if (item.children) {
                const isOpen = openMobileSection === item.label;
                return /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => toggleMobileSection(item.label),
                      className: "flex items-center justify-between w-full gap-3 px-3 py-2.5 rounded-lg text-gray-700 hover:bg-gray-100 font-medium text-left",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-3", children: [
                          getMenuIcon(item.iconKey, 22),
                          /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                            fileName: "/app/src/components/layouts/TopNavbar.tsx",
                            lineNumber: 259,
                            columnNumber: 53
                          }, this)
                        ] }, void 0, true, {
                          fileName: "/app/src/components/layouts/TopNavbar.tsx",
                          lineNumber: 257,
                          columnNumber: 49
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          RxChevronDown,
                          {
                            className: `w-5 h-5 flex-shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`
                          },
                          void 0,
                          false,
                          {
                            fileName: "/app/src/components/layouts/TopNavbar.tsx",
                            lineNumber: 261,
                            columnNumber: 49
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/app/src/components/layouts/TopNavbar.tsx",
                      lineNumber: 252,
                      columnNumber: 45
                    },
                    this
                  ),
                  isOpen && /* @__PURE__ */ jsxDEV("div", { className: "pl-4 mt-0.5 flex flex-col gap-0.5", children: item.children.map(
                    (child) => /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: child.path,
                        onClick: closeMobileMenu,
                        className: "flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-100 hover:text-gray-900",
                        children: [
                          getMenuIcon(child.iconKey, 18),
                          /* @__PURE__ */ jsxDEV("span", { children: child.label }, void 0, false, {
                            fileName: "/app/src/components/layouts/TopNavbar.tsx",
                            lineNumber: 275,
                            columnNumber: 61
                          }, this)
                        ]
                      },
                      child.path,
                      true,
                      {
                        fileName: "/app/src/components/layouts/TopNavbar.tsx",
                        lineNumber: 268,
                        columnNumber: 23
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "/app/src/components/layouts/TopNavbar.tsx",
                    lineNumber: 266,
                    columnNumber: 21
                  }, this)
                ] }, item.label, true, {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 251,
                  columnNumber: 19
                }, this);
              }
              return null;
            }) }, void 0, false, {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 233,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/layouts/TopNavbar.tsx",
          lineNumber: 202,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/layouts/TopNavbar.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "header",
      {
        ref: navRef,
        className: "flex items-center justify-between w-full h-16 px-4 bg-white border-b border-gray-200 shadow-sm",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 lg:gap-8", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setMobileMenuOpen(true),
                className: "flex lg:hidden p-2 rounded-lg text-gray-600 hover:bg-gray-100",
                "aria-label": "Abrir menú",
                "aria-expanded": mobileMenuOpen,
                children: /* @__PURE__ */ jsxDEV(HiOutlineMenu, { className: "w-6 h-6" }, void 0, false, {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 306,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 299,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Link, { to: "/dashboard", className: "flex items-center gap-2 shrink-0", children: [
              /* @__PURE__ */ jsxDEV(
                OrganizationLogo,
                {
                  className: "block h-9 w-auto max-w-[120px] object-contain object-left",
                  alt: "Logo"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 309,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-900 hidden sm:inline", children: [
                "ERP",
                /* @__PURE__ */ jsxDEV("span", { className: "text-secondary", children: "Pro" }, void 0, false, {
                  fileName: "/app/src/components/layouts/TopNavbar.tsx",
                  lineNumber: 314,
                  columnNumber: 32
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 313,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 308,
              columnNumber: 21
            }, this),
            renderDesktopNav()
          ] }, void 0, true, {
            fileName: "/app/src/components/layouts/TopNavbar.tsx",
            lineNumber: 298,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 pl-4 border-l border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-medium text-sm", children: user?.name?.charAt(0)?.toUpperCase() ?? "U" }, void 0, false, {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 322,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:block text-left", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: user?.name ?? "Usuario" }, void 0, false, {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 326,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: user?.roles?.[0]?.name ?? "Usuario" }, void 0, false, {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 327,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/TopNavbar.tsx",
              lineNumber: 325,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => logout(),
                className: "ml-1 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50 rounded-md transition-colors",
                children: "Cerrar sesión"
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/layouts/TopNavbar.tsx",
                lineNumber: 331,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/components/layouts/TopNavbar.tsx",
            lineNumber: 321,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/app/src/components/layouts/TopNavbar.tsx",
            lineNumber: 320,
            columnNumber: 17
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/layouts/TopNavbar.tsx",
        lineNumber: 294,
        columnNumber: 13
      },
      this
    ),
    renderMobileDrawer()
  ] }, void 0, true, {
    fileName: "/app/src/components/layouts/TopNavbar.tsx",
    lineNumber: 293,
    columnNumber: 5
  }, this);
};
_s(TopNavbar, "O+IiqGkfeQGlPR1J2cBFXt+t6d0=", false, function() {
  return [useAuth, useLocation, useMenuNavSearchResults];
});
_c = TopNavbar;
var _c;
$RefreshReg$(_c, "TopNavbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/TopNavbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/TopNavbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZnQixTQTBEd0IsVUExRHhCOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZGaEIsU0FBU0EsVUFBVUMsUUFBUUMsaUJBQWlCO0FBQzVDLFNBQVNDLE1BQU1DLFNBQVNDLG1CQUFtQjtBQUMzQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZUFBZUMsa0JBQWtCO0FBQzFDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFlBQVlDLG1CQUF1QztBQUM1RCxTQUFTQyx3QkFBOEM7QUFDdkQ7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsU0FBU0Msd0JBQXdCO0FBRTFCLGFBQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLEVBQUVDLE1BQU1DLGFBQWFDLE9BQU8sSUFBSWIsUUFBUTtBQUM5QyxRQUFNLENBQUNjLGNBQWNDLGVBQWUsSUFBSXhCLFNBQXdCLElBQUk7QUFDcEUsUUFBTSxDQUFDeUIsZ0JBQWdCQyxpQkFBaUIsSUFBSTFCLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUMyQixtQkFBbUJDLG9CQUFvQixJQUFJNUIsU0FBd0IsSUFBSTtBQUM5RSxRQUFNLENBQUM2QixnQkFBZ0JDLGlCQUFpQixJQUFJOUIsU0FBUyxFQUFFO0FBQ3ZELFFBQU0rQixTQUFTOUIsT0FBdUIsSUFBSTtBQUMxQyxRQUFNK0IsV0FBVzNCLFlBQVk7QUFFN0IsUUFBTTRCLGdCQUFnQnZCLGdCQUFnQkMsWUFBWVUsV0FBVztBQUM3RCxRQUFNYSxtQkFBbUJsQix3QkFBd0JpQixlQUFlSixjQUFjO0FBQzlFLFFBQU1NLG9CQUFvQk4sZUFBZU8sS0FBSyxFQUFFQyxTQUFTO0FBRXpEbkMsWUFBVSxNQUFNO0FBQ1pzQixvQkFBZ0IsSUFBSTtBQUNwQkUsc0JBQWtCLEtBQUs7QUFDdkJJLHNCQUFrQixFQUFFO0FBQUEsRUFDeEIsR0FBRyxDQUFDRSxTQUFTTSxRQUFRLENBQUM7QUFFdEJwQyxZQUFVLE1BQU07QUFDWixVQUFNcUMscUJBQXFCQSxDQUFDQyxNQUFrQjtBQUMxQyxVQUFJVCxPQUFPVSxXQUFXLENBQUNWLE9BQU9VLFFBQVFDLFNBQVNGLEVBQUVHLE1BQWMsR0FBRztBQUM5RG5CLHdCQUFnQixJQUFJO0FBQ3BCTSwwQkFBa0IsRUFBRTtBQUFBLE1BQ3hCO0FBQUEsSUFDSjtBQUNBYyxhQUFTQyxpQkFBaUIsYUFBYU4sa0JBQWtCO0FBQ3pELFdBQU8sTUFBTUssU0FBU0Usb0JBQW9CLGFBQWFQLGtCQUFrQjtBQUFBLEVBQzdFLEdBQUcsRUFBRTtBQUVMckMsWUFBVSxNQUFNO0FBQ1osVUFBTTZDLGVBQWVBLENBQUNQLE1BQXFCO0FBQ3ZDLFVBQUlBLEVBQUVRLFFBQVEsU0FBVTtBQUN4QixVQUFJbkIsZUFBZU8sS0FBSyxHQUFHO0FBQ3ZCTiwwQkFBa0IsRUFBRTtBQUFBLE1BQ3hCLE9BQU87QUFDSEosMEJBQWtCLEtBQUs7QUFBQSxNQUMzQjtBQUFBLElBQ0o7QUFDQSxRQUFJRCxnQkFBZ0I7QUFDaEJtQixlQUFTQyxpQkFBaUIsV0FBV0UsWUFBWTtBQUNqREgsZUFBU0ssS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ25DO0FBQ0EsV0FBTyxNQUFNO0FBQ1RQLGVBQVNFLG9CQUFvQixXQUFXQyxZQUFZO0FBQ3BESCxlQUFTSyxLQUFLQyxNQUFNQyxXQUFXO0FBQUEsSUFDbkM7QUFBQSxFQUNKLEdBQUcsQ0FBQzFCLGdCQUFnQkksY0FBYyxDQUFDO0FBRW5DLFFBQU11QixnQkFBZ0JBLE1BQU01QixnQkFBZ0IsSUFBSTtBQUVoRCxRQUFNNkIsaUJBQWlCQSxDQUFDQyxVQUFrQjtBQUN0QzlCLG9CQUFnQixDQUFDK0IsU0FBVUEsU0FBU0QsUUFBUSxPQUFPQSxLQUFNO0FBQUEsRUFDN0Q7QUFFQSxRQUFNRSxrQkFBa0JBLE1BQU05QixrQkFBa0IsS0FBSztBQUVyRCxRQUFNK0Isc0JBQXNCQSxDQUFDSCxVQUFrQjtBQUMzQzFCLHlCQUFxQixDQUFDMkIsU0FBVUEsU0FBU0QsUUFBUSxPQUFPQSxLQUFNO0FBQUEsRUFDbEU7QUFFQSxRQUFNSSx1QkFBdUJBLENBQUNDLGFBQzFCQSxTQUFTQyxJQUFJLENBQUNDLE9BQU87QUFBQSxJQUNqQkMsTUFBTUQsRUFBRUM7QUFBQUEsSUFDUlIsT0FBT08sRUFBRVA7QUFBQUEsSUFDVFMsTUFBTW5ELFlBQVlpRCxFQUFFRyxTQUFTLEVBQUU7QUFBQSxJQUMvQkMsYUFBYUosRUFBRUk7QUFBQUEsRUFDbkIsRUFBRTtBQUVOLFFBQU1DLG1CQUFtQkEsTUFDckIsdUJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVE7QUFBQSxVQUNSLE9BQU9yQztBQUFBQSxVQUNQLGVBQWVDO0FBQUFBO0FBQUFBLFFBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdxQztBQUFBLE1BRXBDSyxxQkFDRyx1QkFBQyxTQUFJLFdBQVUsc0NBQ1g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVNEO0FBQUFBLFVBQ1QsU0FBUTtBQUFBLFVBQ1IsWUFBWSxNQUFNSixrQkFBa0IsRUFBRTtBQUFBO0FBQUEsUUFIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzRDLEtBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBYlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFFQyxDQUFDSyxxQkFDRUYsY0FBYzJCLElBQUksQ0FBQ08sU0FBUztBQUN4QixVQUFJQSxLQUFLTCxRQUFRLENBQUNLLEtBQUtSLFVBQVU7QUFDN0IsWUFBSVEsS0FBS0MsVUFBVTtBQUNmLGlCQUNJO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFRyxJQUFJRCxLQUFLTDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUNWLE9BQU9LLEtBQUtiO0FBQUFBLGNBRVgxQyxzQkFBWXVELEtBQUtILFNBQVMsRUFBRTtBQUFBO0FBQUEsWUFMeEJHLEtBQUtiO0FBQUFBLFlBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsUUFFUjtBQUNBLGVBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVHLElBQUlhLEtBQUtMO0FBQUFBLFlBQ1QsV0FBVyxDQUFDLEVBQUVPLFNBQVMsTUFDbkIsc0ZBQXNGQSxXQUFXLGlDQUFpQyxxREFBcUQ7QUFBQSxZQUcxTHpEO0FBQUFBLDBCQUFZdUQsS0FBS0gsU0FBUyxFQUFFO0FBQUEsY0FDN0IsdUJBQUMsVUFBTUcsZUFBS2IsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBO0FBQUE7QUFBQSxVQVBiYSxLQUFLYjtBQUFBQSxVQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLE1BRVI7QUFFQSxVQUFJYSxLQUFLUixVQUFVO0FBQ2YsY0FBTVcsU0FBUy9DLGlCQUFpQjRDLEtBQUtiO0FBQ3JDLGNBQU1pQixhQUFhSixLQUFLQztBQUN4QixlQUNJLHVCQUFDLFNBQXFCLFdBQVUsWUFDNUI7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNZixlQUFlYyxLQUFLYixLQUFLO0FBQUEsY0FDeEMsV0FBVyxzRkFBc0ZnQixTQUFTLGlDQUFpQyxxREFBcUQsSUFBSUMsYUFBYSw2QkFBNkIsRUFBRTtBQUFBLGNBQ2hQLE9BQU9BLGFBQWFKLEtBQUtiLFFBQVFrQjtBQUFBQSxjQUVoQzVEO0FBQUFBLDRCQUFZdUQsS0FBS0gsU0FBU08sYUFBYSxLQUFLLEVBQUU7QUFBQSxnQkFDOUMsQ0FBQ0EsY0FDRSxtQ0FDSTtBQUFBLHlDQUFDLFVBQU1KLGVBQUtiLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0I7QUFBQSxrQkFDbEI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csV0FBVyxnQ0FBZ0NnQixTQUFTLGVBQWUsRUFBRTtBQUFBO0FBQUEsb0JBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFDNEU7QUFBQSxxQkFIaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBO0FBQUE7QUFBQSxZQWJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWVBO0FBQUEsVUFDQ0EsVUFDRyx1QkFBQyxTQUFJLFdBQVUsc0NBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU9aLHFCQUFxQlMsS0FBS1IsUUFBUTtBQUFBLGNBQ3pDLFlBQVlQO0FBQUFBO0FBQUFBLFlBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUU4QixLQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUF2QkVlLEtBQUtiLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLE1BRVI7QUFFQSxhQUFPO0FBQUEsSUFDWCxDQUFDO0FBQUEsT0FqRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtGQTtBQUdKLFFBQU1tQixxQkFBcUJBLE1BQU07QUFDN0IsUUFBSSxDQUFDaEQsZUFBZ0IsUUFBTztBQUM1QixXQUNJLG1DQUNJO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFVBQVU7QUFBQSxVQUNWLGNBQVc7QUFBQSxVQUNYLFdBQVU7QUFBQSxVQUNWLFNBQVMrQjtBQUFBQSxVQUNULFdBQVcsQ0FBQ2hCLE1BQU1BLEVBQUVRLFFBQVEsV0FBV1EsZ0JBQWdCO0FBQUE7QUFBQSxRQU4zRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNNkQ7QUFBQSxNQUU3RDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csV0FBVTtBQUFBLFVBQ1YsY0FBVztBQUFBLFVBQ1gsY0FBVztBQUFBLFVBRVg7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0VBQ1g7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsK0JBQThCLG9CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQ2xEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTQTtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBQ1YsY0FBVztBQUFBLGtCQUVYLGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFRO0FBQUEsZ0JBQ1IsT0FBTzNCO0FBQUFBLGdCQUNQLGVBQWVDO0FBQUFBO0FBQUFBLGNBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdxQztBQUFBLFlBRXBDSyxvQkFDRztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFNBQVNEO0FBQUFBLGdCQUNULFNBQVE7QUFBQSxnQkFDUixZQUFZLE1BQU07QUFDZEosb0NBQWtCLEVBQUU7QUFDcEIwQixrQ0FBZ0I7QUFBQSxnQkFDcEI7QUFBQTtBQUFBLGNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTU0sSUFHTix1QkFBQyxTQUFJLFdBQVUsNkJBQ1Z2Qix3QkFBYzJCLElBQUksQ0FBQ08sU0FBUztBQUN6QixrQkFBSUEsS0FBS0wsUUFBUSxDQUFDSyxLQUFLUixVQUFVO0FBQzdCLHVCQUNJO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVHLElBQUlRLEtBQUtMO0FBQUFBLG9CQUNULFNBQVNOO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFFVDVDO0FBQUFBLGtDQUFZdUQsS0FBS0gsU0FBUyxFQUFFO0FBQUEsc0JBQzdCLHVCQUFDLFVBQU1HLGVBQUtiLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0I7QUFBQTtBQUFBO0FBQUEsa0JBTmJhLEtBQUtiO0FBQUFBLGtCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxjQUVSO0FBQ0Esa0JBQUlhLEtBQUtSLFVBQVU7QUFDZixzQkFBTVcsU0FBUzNDLHNCQUFzQndDLEtBQUtiO0FBQzFDLHVCQUNJLHVCQUFDLFNBQ0c7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNRyxvQkFBb0JVLEtBQUtiLEtBQUs7QUFBQSxzQkFDN0MsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDJCQUNYMUM7QUFBQUEsc0NBQVl1RCxLQUFLSCxTQUFTLEVBQUU7QUFBQSwwQkFDN0IsdUJBQUMsVUFBTUcsZUFBS2IsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFrQjtBQUFBLDZCQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csV0FBVyw4Q0FBOENnQixTQUFTLGVBQWUsRUFBRTtBQUFBO0FBQUEsMEJBRHZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFDMEY7QUFBQTtBQUFBO0FBQUEsb0JBVjlGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLGtCQUNDQSxVQUNHLHVCQUFDLFNBQUksV0FBVSxxQ0FDVkgsZUFBS1IsU0FBU0M7QUFBQUEsb0JBQUksQ0FBQ2MsVUFDaEI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBRUcsSUFBSUEsTUFBTVo7QUFBQUEsd0JBQ1YsU0FBU047QUFBQUEsd0JBQ1QsV0FBVTtBQUFBLHdCQUVUNUM7QUFBQUEsc0NBQVk4RCxNQUFNVixTQUFTLEVBQUU7QUFBQSwwQkFDOUIsdUJBQUMsVUFBTVUsZ0JBQU1wQixTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1CO0FBQUE7QUFBQTtBQUFBLHNCQU5kb0IsTUFBTVo7QUFBQUEsc0JBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQTtBQUFBLGtCQUNILEtBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQTNCRUssS0FBS2IsT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZCQTtBQUFBLGNBRVI7QUFDQSxxQkFBTztBQUFBLFlBQ1gsQ0FBQyxLQW5ETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBO0FBQUE7QUFBQSxRQW5GUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFxRkE7QUFBQSxTQTlGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0ZBO0FBQUEsRUFFUjtBQUVBLFNBQ0ksbUNBQ0k7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csS0FBS3ZCO0FBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0NBQ1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1MLGtCQUFrQixJQUFJO0FBQUEsZ0JBQ3JDLFdBQVU7QUFBQSxnQkFDVixjQUFXO0FBQUEsZ0JBQ1gsaUJBQWVEO0FBQUFBLGdCQUVmLGlDQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQTtBQUFBLGNBUHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLElBQUcsY0FBYSxXQUFVLG9DQUM1QjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLFdBQVU7QUFBQSxrQkFDVixLQUFJO0FBQUE7QUFBQSxnQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFYztBQUFBLGNBRWQsdUJBQUMsVUFBSyxXQUFVLGdEQUE4QztBQUFBO0FBQUEsZ0JBQ3ZELHVCQUFDLFVBQUssV0FBVSxrQkFBaUIsbUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQ3lDLGlCQUFpQjtBQUFBLGVBbkJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNYLGlDQUFDLFNBQUksV0FBVSx5REFDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSwyR0FDVjlDLGdCQUFNdUQsTUFBTUMsT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FBSyxPQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQXFDekQsZ0JBQU11RCxRQUFRLGFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsY0FDMUUsdUJBQUMsT0FBRSxXQUFVLHlCQUNSdkQsZ0JBQU0wRCxRQUFRLENBQUMsR0FBR0gsUUFBUSxhQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNckQsT0FBTztBQUFBLGdCQUN0QixXQUFVO0FBQUEsZ0JBQWdHO0FBQUE7QUFBQSxjQUg5RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUE7QUFBQTtBQUFBLE1BN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQThDQTtBQUFBLElBQ0NtRCxtQkFBbUI7QUFBQSxPQWhEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlEQTtBQUVSO0FBQUV0RCxHQXJUV0QsV0FBUztBQUFBLFVBQ29CVCxTQU1yQkosYUFHUVcsdUJBQXVCO0FBQUE7QUFBQStELEtBVnZDN0Q7QUFBUyxJQUFBNkQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUmVmIiwidXNlRWZmZWN0IiwiTGluayIsIk5hdkxpbmsiLCJ1c2VMb2NhdGlvbiIsIlJ4Q2hldnJvbkRvd24iLCJIaU91dGxpbmVNZW51IiwiSGlPdXRsaW5lWCIsInVzZUF1dGgiLCJmaWx0ZXJNZW51SXRlbXMiLCJNRU5VX0lURU1TIiwiZ2V0TWVudUljb24iLCJOYXZEcm9wZG93blBhbmVsIiwiTWVudU5hdkZsYXRSZXN1bHRzIiwiTWVudU5hdlNlYXJjaEJhciIsInVzZU1lbnVOYXZTZWFyY2hSZXN1bHRzIiwiT3JnYW5pemF0aW9uTG9nbyIsIlRvcE5hdmJhciIsIl9zIiwidXNlciIsInBlcm1pc3Npb25zIiwibG9nb3V0Iiwib3BlbkRyb3Bkb3duIiwic2V0T3BlbkRyb3Bkb3duIiwibW9iaWxlTWVudU9wZW4iLCJzZXRNb2JpbGVNZW51T3BlbiIsIm9wZW5Nb2JpbGVTZWN0aW9uIiwic2V0T3Blbk1vYmlsZVNlY3Rpb24iLCJuYXZTZWFyY2hRdWVyeSIsInNldE5hdlNlYXJjaFF1ZXJ5IiwibmF2UmVmIiwibG9jYXRpb24iLCJmaWx0ZXJlZEl0ZW1zIiwibmF2U2VhcmNoUmVzdWx0cyIsImlzTmF2U2VhcmNoQWN0aXZlIiwidHJpbSIsImxlbmd0aCIsInBhdGhuYW1lIiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZSIsImN1cnJlbnQiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJoYW5kbGVFc2NhcGUiLCJrZXkiLCJib2R5Iiwic3R5bGUiLCJvdmVyZmxvdyIsImNsb3NlRHJvcGRvd24iLCJ0b2dnbGVEcm9wZG93biIsImxhYmVsIiwicHJldiIsImNsb3NlTW9iaWxlTWVudSIsInRvZ2dsZU1vYmlsZVNlY3Rpb24iLCJjaGlsZHJlblRvUGFuZWxJdGVtcyIsImNoaWxkcmVuIiwibWFwIiwiYyIsInBhdGgiLCJpY29uIiwiaWNvbktleSIsImRlc2NyaXB0aW9uIiwicmVuZGVyRGVza3RvcE5hdiIsIml0ZW0iLCJpY29uT25seSIsImlzQWN0aXZlIiwiaXNPcGVuIiwiaXNJY29uT25seSIsInVuZGVmaW5lZCIsInJlbmRlck1vYmlsZURyYXdlciIsImNoaWxkIiwibmFtZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwicm9sZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUb3BOYXZiYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIE5hdkxpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBSeENoZXZyb25Eb3duIH0gZnJvbSAncmVhY3QtaWNvbnMvcngnO1xuaW1wb3J0IHsgSGlPdXRsaW5lTWVudSwgSGlPdXRsaW5lWCB9IGZyb20gJ3JlYWN0LWljb25zL2hpJztcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9ob29rcy91c2VBdXRoJztcbmltcG9ydCB7IGZpbHRlck1lbnVJdGVtcyB9IGZyb20gJy4uLy4uL3V0aWxzL21lbnVGaWx0ZXInO1xuaW1wb3J0IHsgTUVOVV9JVEVNUywgZ2V0TWVudUljb24sIHR5cGUgTWVudUl0ZW1DaGlsZCB9IGZyb20gJy4uLy4uL2NvbmZpZy9tZW51SXRlbXMnO1xuaW1wb3J0IHsgTmF2RHJvcGRvd25QYW5lbCwgdHlwZSBOYXZEcm9wZG93bkl0ZW0gfSBmcm9tICcuL05hdkRyb3Bkb3duUGFuZWwnO1xuaW1wb3J0IHtcbiAgICBNZW51TmF2RmxhdFJlc3VsdHMsXG4gICAgTWVudU5hdlNlYXJjaEJhcixcbiAgICB1c2VNZW51TmF2U2VhcmNoUmVzdWx0cyxcbn0gZnJvbSAnLi9NZW51TmF2U2VhcmNoJztcbmltcG9ydCB7IE9yZ2FuaXphdGlvbkxvZ28gfSBmcm9tICcuLi9jb21tb24vT3JnYW5pemF0aW9uTG9nbyc7XG5cbmV4cG9ydCBjb25zdCBUb3BOYXZiYXIgPSAoKSA9PiB7XG4gICAgY29uc3QgeyB1c2VyLCBwZXJtaXNzaW9ucywgbG9nb3V0IH0gPSB1c2VBdXRoKCk7XG4gICAgY29uc3QgW29wZW5Ecm9wZG93biwgc2V0T3BlbkRyb3Bkb3duXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFttb2JpbGVNZW51T3Blbiwgc2V0TW9iaWxlTWVudU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtvcGVuTW9iaWxlU2VjdGlvbiwgc2V0T3Blbk1vYmlsZVNlY3Rpb25dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW25hdlNlYXJjaFF1ZXJ5LCBzZXROYXZTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgbmF2UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgICBjb25zdCBmaWx0ZXJlZEl0ZW1zID0gZmlsdGVyTWVudUl0ZW1zKE1FTlVfSVRFTVMsIHBlcm1pc3Npb25zKTtcbiAgICBjb25zdCBuYXZTZWFyY2hSZXN1bHRzID0gdXNlTWVudU5hdlNlYXJjaFJlc3VsdHMoZmlsdGVyZWRJdGVtcywgbmF2U2VhcmNoUXVlcnkpO1xuICAgIGNvbnN0IGlzTmF2U2VhcmNoQWN0aXZlID0gbmF2U2VhcmNoUXVlcnkudHJpbSgpLmxlbmd0aCA+IDA7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRPcGVuRHJvcGRvd24obnVsbCk7XG4gICAgICAgIHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgc2V0TmF2U2VhcmNoUXVlcnkoJycpO1xuICAgIH0sIFtsb2NhdGlvbi5wYXRobmFtZV0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKGU6IE1vdXNlRXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChuYXZSZWYuY3VycmVudCAmJiAhbmF2UmVmLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICAgICAgICAgICAgICBzZXRPcGVuRHJvcGRvd24obnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0TmF2U2VhcmNoUXVlcnkoJycpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgICAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBoYW5kbGVFc2NhcGUgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGUua2V5ICE9PSAnRXNjYXBlJykgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKG5hdlNlYXJjaFF1ZXJ5LnRyaW0oKSkge1xuICAgICAgICAgICAgICAgIHNldE5hdlNlYXJjaFF1ZXJ5KCcnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBpZiAobW9iaWxlTWVudU9wZW4pIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVFc2NhcGUpO1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlRXNjYXBlKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAnJztcbiAgICAgICAgfTtcbiAgICB9LCBbbW9iaWxlTWVudU9wZW4sIG5hdlNlYXJjaFF1ZXJ5XSk7XG5cbiAgICBjb25zdCBjbG9zZURyb3Bkb3duID0gKCkgPT4gc2V0T3BlbkRyb3Bkb3duKG51bGwpO1xuXG4gICAgY29uc3QgdG9nZ2xlRHJvcGRvd24gPSAobGFiZWw6IHN0cmluZykgPT4ge1xuICAgICAgICBzZXRPcGVuRHJvcGRvd24oKHByZXYpID0+IChwcmV2ID09PSBsYWJlbCA/IG51bGwgOiBsYWJlbCkpO1xuICAgIH07XG5cbiAgICBjb25zdCBjbG9zZU1vYmlsZU1lbnUgPSAoKSA9PiBzZXRNb2JpbGVNZW51T3BlbihmYWxzZSk7XG5cbiAgICBjb25zdCB0b2dnbGVNb2JpbGVTZWN0aW9uID0gKGxhYmVsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0T3Blbk1vYmlsZVNlY3Rpb24oKHByZXYpID0+IChwcmV2ID09PSBsYWJlbCA/IG51bGwgOiBsYWJlbCkpO1xuICAgIH07XG5cbiAgICBjb25zdCBjaGlsZHJlblRvUGFuZWxJdGVtcyA9IChjaGlsZHJlbjogTWVudUl0ZW1DaGlsZFtdKTogTmF2RHJvcGRvd25JdGVtW10gPT5cbiAgICAgICAgY2hpbGRyZW4ubWFwKChjKSA9PiAoe1xuICAgICAgICAgICAgcGF0aDogYy5wYXRoLFxuICAgICAgICAgICAgbGFiZWw6IGMubGFiZWwsXG4gICAgICAgICAgICBpY29uOiBnZXRNZW51SWNvbihjLmljb25LZXksIDIwKSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBjLmRlc2NyaXB0aW9uLFxuICAgICAgICB9KSk7XG5cbiAgICBjb25zdCByZW5kZXJEZXNrdG9wTmF2ID0gKCkgPT4gKFxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgIDxNZW51TmF2U2VhcmNoQmFyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJ0b3BEZXNrdG9wXCJcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk9e25hdlNlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICAgICAgICBvblF1ZXJ5Q2hhbmdlPXtzZXROYXZTZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtpc05hdlNlYXJjaEFjdGl2ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC1mdWxsIG10LTEgei01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVOYXZGbGF0UmVzdWx0c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJpZXM9e25hdlNlYXJjaFJlc3VsdHN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInRvcERlc2t0b3BcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9eygpID0+IHNldE5hdlNlYXJjaFF1ZXJ5KCcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgeyFpc05hdlNlYXJjaEFjdGl2ZSAmJlxuICAgICAgICAgICAgICAgIGZpbHRlcmVkSXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpdGVtLnBhdGggJiYgIWl0ZW0uY2hpbGRyZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpdGVtLmljb25Pbmx5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEwIGgtMTAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS05MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRNZW51SWNvbihpdGVtLmljb25LZXksIDIyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTMgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtpc0FjdGl2ZSA/ICdiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwJyA6ICd0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS05MDAnfWBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldE1lbnVJY29uKGl0ZW0uaWNvbktleSwgMjApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChpdGVtLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc09wZW4gPSBvcGVuRHJvcGRvd24gPT09IGl0ZW0ubGFiZWw7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0ljb25Pbmx5ID0gaXRlbS5pY29uT25seTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0ubGFiZWx9IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlRHJvcGRvd24oaXRlbS5sYWJlbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0zIHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzICR7aXNPcGVuID8gJ2JnLWluZGlnby01MCB0ZXh0LWluZGlnby03MDAnIDogJ3RleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS0xMDAgaG92ZXI6dGV4dC1ncmF5LTkwMCd9ICR7aXNJY29uT25seSA/ICd3LTEwIGgtMTAganVzdGlmeS1jZW50ZXInIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtpc0ljb25Pbmx5ID8gaXRlbS5sYWJlbCA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldE1lbnVJY29uKGl0ZW0uaWNvbktleSwgaXNJY29uT25seSA/IDIyIDogMjApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0ljb25Pbmx5ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSeENoZXZyb25Eb3duXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTQgaC00IHRyYW5zaXRpb24tdHJhbnNmb3JtICR7aXNPcGVuID8gJ3JvdGF0ZS0xODAnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC1mdWxsIG10LTEgei01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZEcm9wZG93blBhbmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zPXtjaGlsZHJlblRvUGFuZWxJdGVtcyhpdGVtLmNoaWxkcmVuKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17Y2xvc2VEcm9wZG93bn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgIDwvbmF2PlxuICAgICk7XG5cbiAgICBjb25zdCByZW5kZXJNb2JpbGVEcmF3ZXIgPSAoKSA9PiB7XG4gICAgICAgIGlmICghbW9iaWxlTWVudU9wZW4pIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17MH1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNlcnJhciBtZW7DulwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNTAgei00MCBsZzpoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZU1vYmlsZU1lbnV9XG4gICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSAnRW50ZXInICYmIGNsb3NlTW9iaWxlTWVudSgpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBsZWZ0LTAgdG9wLTAgaC1mdWxsIHctWzI4MHB4XSBtYXgtdy1bODV2d10gYmctd2hpdGUgc2hhZG93LXhsIHotNTAgb3ZlcmZsb3cteS1hdXRvIGxnOmhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk1lbsO6IGRlIG5hdmVnYWNpw7NuXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPk1lbsO6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlTW9iaWxlTWVudX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2VycmFyIG1lbsO6XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGlPdXRsaW5lWCBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPE1lbnVOYXZTZWFyY2hCYXJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJ0b3BNb2JpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnk9e25hdlNlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25RdWVyeUNoYW5nZT17c2V0TmF2U2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHtpc05hdlNlYXJjaEFjdGl2ZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51TmF2RmxhdFJlc3VsdHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyaWVzPXtuYXZTZWFyY2hSZXN1bHRzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJ0b3BNb2JpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmF2U2VhcmNoUXVlcnkoJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zZU1vYmlsZU1lbnUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwicC0yIGZsZXggZmxleC1jb2wgZ2FwLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5wYXRoICYmICFpdGVtLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2xvc2VNb2JpbGVNZW51fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDAgZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldE1lbnVJY29uKGl0ZW0uaWNvbktleSwgMjIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5jaGlsZHJlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNPcGVuID0gb3Blbk1vYmlsZVNlY3Rpb24gPT09IGl0ZW0ubGFiZWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLmxhYmVsfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVNb2JpbGVTZWN0aW9uKGl0ZW0ubGFiZWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDAgZm9udC1tZWRpdW0gdGV4dC1sZWZ0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0TWVudUljb24oaXRlbS5pY29uS2V5LCAyMil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJ4Q2hldnJvbkRvd25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTUgaC01IGZsZXgtc2hyaW5rLTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gJHtpc09wZW4gPyAncm90YXRlLTE4MCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc09wZW4gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC00IG10LTAuNSBmbGV4IGZsZXgtY29sIGdhcC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jaGlsZHJlbi5tYXAoKGNoaWxkKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NoaWxkLnBhdGh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Y2hpbGQucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlTW9iaWxlTWVudX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTMgcHktMiByb3VuZGVkLWxnIHRleHQtc20gdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktOTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldE1lbnVJY29uKGNoaWxkLmljb25LZXksIDE4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntjaGlsZC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbmF2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8aGVhZGVyXG4gICAgICAgICAgICAgICAgcmVmPXtuYXZSZWZ9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCBoLTE2IHB4LTQgYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBsZzpnYXAtOFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBsZzpoaWRkZW4gcC0yIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQWJyaXIgbWVuw7pcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1leHBhbmRlZD17bW9iaWxlTWVudU9wZW59XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxIaU91dGxpbmVNZW51IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvZGFzaGJvYXJkXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxPcmdhbml6YXRpb25Mb2dvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgaC05IHctYXV0byBtYXgtdy1bMTIwcHhdIG9iamVjdC1jb250YWluIG9iamVjdC1sZWZ0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJMb2dvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgaGlkZGVuIHNtOmlubGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVSUDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5XCI+UHJvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgIHtyZW5kZXJEZXNrdG9wTmF2KCl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcGwtNCBib3JkZXItbCBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctb3JhbmdlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LW9yYW5nZS02MDAgZm9udC1tZWRpdW0gdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyPy5uYW1lPy5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCkgPz8gJ1UnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9jayB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57dXNlcj8ubmFtZSA/PyAnVXN1YXJpbyd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlcj8ucm9sZXM/LlswXT8ubmFtZSA/PyAnVXN1YXJpbyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbG9nb3V0KCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMSBweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMCBob3ZlcjpiZy1yZWQtNTAgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2VycmFyIHNlc2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvaGVhZGVyPlxuICAgICAgICAgICAge3JlbmRlck1vYmlsZURyYXdlcigpfVxuICAgICAgICA8Lz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9sYXlvdXRzL1RvcE5hdmJhci50c3gifQ==