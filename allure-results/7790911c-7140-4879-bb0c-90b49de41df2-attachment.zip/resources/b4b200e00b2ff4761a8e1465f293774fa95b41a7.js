import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/Sidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/Sidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { RxChevronDown } from "/node_modules/.vite/deps/react-icons_rx.js?v=cc4fbb62";
import { HiOutlineChevronDoubleLeft, HiOutlineChevronDoubleRight } from "/node_modules/.vite/deps/react-icons_hi.js?v=cc4fbb62";
import { useAuth } from "/src/hooks/useAuth.ts";
import { filterMenuItems } from "/src/utils/menuFilter.ts";
import { MENU_ITEMS, getMenuIcon } from "/src/config/menuItems.tsx";
import { OrganizationLogo } from "/src/components/common/OrganizationLogo.tsx";
import { MenuNavFlatResults, MenuNavSearchBar, useMenuNavSearchResults } from "/src/components/layouts/MenuNavSearch.tsx";
export const Sidebar = () => {
  _s();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [openSubmenus, setOpenSubmenus] = useState({});
  const [menuSearchQuery, setMenuSearchQuery] = useState("");
  const searchInputRef = useRef(null);
  const { permissions } = useAuth();
  const filteredMenuItems = filterMenuItems(MENU_ITEMS, permissions);
  const searchResults = useMenuNavSearchResults(filteredMenuItems, menuSearchQuery);
  const isSearchActive = menuSearchQuery.trim().length > 0;
  const toggleSidebar = () => {
    const willCollapse = !isCollapsed;
    setIsCollapsed(!isCollapsed);
    if (willCollapse) {
      setOpenSubmenus({});
      setMenuSearchQuery("");
    }
  };
  const expandSidebarForSearch = () => {
    setIsCollapsed(false);
    requestAnimationFrame(() => searchInputRef.current?.focus());
  };
  const handleSubmenuClick = (label) => {
    if (isCollapsed) {
      setIsCollapsed(false);
      setOpenSubmenus({ [label]: true });
    } else {
      setOpenSubmenus((prev) => ({
        ...prev,
        [label]: !prev[label]
      }));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "aside",
    {
      className: `relative min-h-screen p-4 text-white bg-primary transition-all duration-300 ease-in-out flex flex-col ${isCollapsed ? "w-20" : "w-64"}`,
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `mb-8 flex h-12 w-full shrink-0 items-center overflow-hidden transition-all duration-300 ${isCollapsed ? "justify-center" : "justify-start"}`,
            children: /* @__PURE__ */ jsxDEV(
              OrganizationLogo,
              {
                className: `block object-contain transition-all duration-300 ${isCollapsed ? "h-10 w-10 max-h-10 max-w-10 object-center" : "h-12 w-full max-w-[192px] object-left"}`,
                alt: "Logo"
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 76,
                columnNumber: 17
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/layouts/Sidebar.tsx",
            lineNumber: 71,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("nav", { className: "flex-1 overflow-auto flex flex-col min-h-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2 shrink-0", children: /* @__PURE__ */ jsxDEV(
            MenuNavSearchBar,
            {
              variant: "sidebar",
              query: menuSearchQuery,
              onQueryChange: setMenuSearchQuery,
              inputRef: searchInputRef,
              sidebarCollapsed: isCollapsed,
              onExpandSidebarForSearch: expandSidebarForSearch
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/layouts/Sidebar.tsx",
              lineNumber: 88,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "/app/src/components/layouts/Sidebar.tsx",
            lineNumber: 87,
            columnNumber: 17
          }, this),
          isSearchActive ? /* @__PURE__ */ jsxDEV(
            MenuNavFlatResults,
            {
              entries: searchResults,
              variant: "sidebar",
              onNavigate: () => setMenuSearchQuery("")
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/layouts/Sidebar.tsx",
              lineNumber: 99,
              columnNumber: 9
            },
            this
          ) : /* @__PURE__ */ jsxDEV("ul", { children: filteredMenuItems.map(
            (item) => /* @__PURE__ */ jsxDEV("li", { className: "mb-2", children: item.children ? /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleSubmenuClick(item.label),
                  className: `flex items-center w-full p-2 rounded-md transition-colors duration-200 cursor-pointer hover:bg-gray-700 ${isCollapsed ? "justify-center" : ""}`,
                  children: [
                    getMenuIcon(item.iconKey, 24),
                    !isCollapsed && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "flex-1 ml-4 text-left", children: item.label }, void 0, false, {
                        fileName: "/app/src/components/layouts/Sidebar.tsx",
                        lineNumber: 118,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        RxChevronDown,
                        {
                          className: `transition-transform duration-200 ${openSubmenus[item.label] ? "rotate-180" : ""}`
                        },
                        void 0,
                        false,
                        {
                          fileName: "/app/src/components/layouts/Sidebar.tsx",
                          lineNumber: 119,
                          columnNumber: 53
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "/app/src/components/layouts/Sidebar.tsx",
                      lineNumber: 117,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/app/src/components/layouts/Sidebar.tsx",
                  lineNumber: 110,
                  columnNumber: 41
                },
                this
              ),
              !isCollapsed && openSubmenus[item.label] && /* @__PURE__ */ jsxDEV("ul", { className: "pl-8 mt-1 space-y-1", children: item.children.map(
                (child) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
                  NavLink,
                  {
                    to: child.path,
                    className: ({ isActive }) => `flex items-center w-full p-2 text-sm rounded-md transition-colors duration-200 ${isActive ? "bg-indigo-600" : "hover:bg-gray-700"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: getMenuIcon(child.iconKey, 20) }, void 0, false, {
                        fileName: "/app/src/components/layouts/Sidebar.tsx",
                        lineNumber: 135,
                        columnNumber: 61
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: child.label }, void 0, false, {
                        fileName: "/app/src/components/layouts/Sidebar.tsx",
                        lineNumber: 138,
                        columnNumber: 61
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/src/components/layouts/Sidebar.tsx",
                    lineNumber: 129,
                    columnNumber: 57
                  },
                  this
                ) }, child.path, false, {
                  fileName: "/app/src/components/layouts/Sidebar.tsx",
                  lineNumber: 128,
                  columnNumber: 17
                }, this)
              ) }, void 0, false, {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 126,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/components/layouts/Sidebar.tsx",
              lineNumber: 109,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(
              NavLink,
              {
                to: item.path,
                onClick: () => {
                  if (isCollapsed) {
                    setIsCollapsed(false);
                  }
                },
                className: ({ isActive }) => `flex items-center p-2 rounded-md transition-colors duration-200 ${isCollapsed ? "justify-center" : ""} ${isActive ? "bg-indigo-600" : "hover:bg-gray-700"}`,
                children: [
                  getMenuIcon(item.iconKey, 24),
                  !isCollapsed && /* @__PURE__ */ jsxDEV("span", { className: "ml-4", children: item.label }, void 0, false, {
                    fileName: "/app/src/components/layouts/Sidebar.tsx",
                    lineNumber: 158,
                    columnNumber: 58
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 146,
                columnNumber: 13
              },
              this
            ) }, item.label, false, {
              fileName: "/app/src/components/layouts/Sidebar.tsx",
              lineNumber: 107,
              columnNumber: 11
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/components/layouts/Sidebar.tsx",
            lineNumber: 105,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/layouts/Sidebar.tsx",
          lineNumber: 86,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 mt-auto border-t border-gray-700", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: toggleSidebar,
            className: "flex items-center w-full p-2 text-white rounded-md hover:bg-gray-700",
            style: { justifyContent: isCollapsed ? "center" : "flex-start" },
            children: [
              isCollapsed ? /* @__PURE__ */ jsxDEV(HiOutlineChevronDoubleRight, { size: 24 }, void 0, false, {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 175,
                columnNumber: 11
              }, this) : /* @__PURE__ */ jsxDEV(HiOutlineChevronDoubleLeft, { size: 24 }, void 0, false, {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 177,
                columnNumber: 11
              }, this),
              !isCollapsed && /* @__PURE__ */ jsxDEV("span", { className: "ml-4", children: "Contraer" }, void 0, false, {
                fileName: "/app/src/components/layouts/Sidebar.tsx",
                lineNumber: 179,
                columnNumber: 38
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/components/layouts/Sidebar.tsx",
            lineNumber: 168,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/components/layouts/Sidebar.tsx",
          lineNumber: 167,
          columnNumber: 13
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/components/layouts/Sidebar.tsx",
      lineNumber: 68,
      columnNumber: 5
    },
    this
  );
};
_s(Sidebar, "aczXi52X7Iz0yMXAkbVeKZjKSaw=", false, function() {
  return [useAuth, useMenuNavSearchResults];
});
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RnQixTQXlDZ0MsVUF6Q2hDOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhEaEIsU0FBU0EsUUFBUUMsZ0JBQWdCO0FBQ2pDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDRCQUE0QkMsbUNBQW1DO0FBQ3hFLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFlBQVlDLG1CQUFtQjtBQUN4QyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msb0JBQW9CQyxrQkFBa0JDLCtCQUErQjtBQUV2RSxhQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDekIsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUloQixTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDaUIsY0FBY0MsZUFBZSxJQUFJbEIsU0FBa0MsQ0FBQyxDQUFDO0FBQzVFLFFBQU0sQ0FBQ21CLGlCQUFpQkMsa0JBQWtCLElBQUlwQixTQUFTLEVBQUU7QUFDekQsUUFBTXFCLGlCQUFpQnRCLE9BQXlCLElBQUk7QUFDcEQsUUFBTSxFQUFFdUIsWUFBWSxJQUFJakIsUUFBUTtBQUVoQyxRQUFNa0Isb0JBQW9CakIsZ0JBQWdCQyxZQUFZZSxXQUFXO0FBQ2pFLFFBQU1FLGdCQUFnQlosd0JBQXdCVyxtQkFBbUJKLGVBQWU7QUFDaEYsUUFBTU0saUJBQWlCTixnQkFBZ0JPLEtBQUssRUFBRUMsU0FBUztBQUV2RCxRQUFNQyxnQkFBZ0JBLE1BQU07QUFDeEIsVUFBTUMsZUFBZSxDQUFDZDtBQUN0QkMsbUJBQWUsQ0FBQ0QsV0FBVztBQUMzQixRQUFJYyxjQUFjO0FBQ2RYLHNCQUFnQixDQUFDLENBQUM7QUFDbEJFLHlCQUFtQixFQUFFO0FBQUEsSUFDekI7QUFBQSxFQUNKO0FBRUEsUUFBTVUseUJBQXlCQSxNQUFNO0FBQ2pDZCxtQkFBZSxLQUFLO0FBQ3BCZSwwQkFBc0IsTUFBTVYsZUFBZVcsU0FBU0MsTUFBTSxDQUFDO0FBQUEsRUFDL0Q7QUFFQSxRQUFNQyxxQkFBcUJBLENBQUNDLFVBQWtCO0FBQzFDLFFBQUlwQixhQUFhO0FBQ2JDLHFCQUFlLEtBQUs7QUFDcEJFLHNCQUFnQixFQUFFLENBQUNpQixLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQUEsSUFDckMsT0FBTztBQUNIakIsc0JBQWdCLENBQUNrQixVQUFVO0FBQUEsUUFDdkIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDRCxLQUFLLEdBQUcsQ0FBQ0MsS0FBS0QsS0FBSztBQUFBLE1BQ3hCLEVBQUU7QUFBQSxJQUNOO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFdBQVcseUdBQXlHcEIsY0FBYyxTQUFTLE1BQU07QUFBQSxNQUVqSjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFXLDJGQUNQQSxjQUFjLG1CQUFtQixlQUFlO0FBQUEsWUFHcEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFXLG9EQUNQQSxjQUNNLDhDQUNBLHVDQUF1QztBQUFBLGdCQUVqRCxLQUFJO0FBQUE7QUFBQSxjQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1jO0FBQUE7QUFBQSxVQVhsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixPQUFPSTtBQUFBQSxjQUNQLGVBQWVDO0FBQUFBLGNBQ2YsVUFBVUM7QUFBQUEsY0FDVixrQkFBa0JOO0FBQUFBLGNBQ2xCLDBCQUEwQmU7QUFBQUE7QUFBQUEsWUFOOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXFELEtBUHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVDTCxpQkFDRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBU0Q7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixZQUFZLE1BQU1KLG1CQUFtQixFQUFFO0FBQUE7QUFBQSxZQUgzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHNkMsSUFHN0MsdUJBQUMsUUFDSUcsNEJBQWtCYztBQUFBQSxZQUFJLENBQUNDLFNBQ3BCLHVCQUFDLFFBQW9CLFdBQVUsUUFDMUJBLGVBQUtDLFdBQ0YsdUJBQUMsU0FDRztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU1MLG1CQUFtQkksS0FBS0gsS0FBSztBQUFBLGtCQUM1QyxXQUFXLDJHQUEyR3BCLGNBQWMsbUJBQW1CLEVBQUU7QUFBQSxrQkFFeEpQO0FBQUFBLGdDQUFZOEIsS0FBS0UsU0FBUyxFQUFFO0FBQUEsb0JBQzVCLENBQUN6QixlQUNFLG1DQUNJO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHlCQUF5QnVCLGVBQUtILFNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9EO0FBQUEsc0JBQ3BEO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNHLFdBQVcscUNBQXFDbEIsYUFBYXFCLEtBQUtILEtBQUssSUFBSSxlQUFlLEVBQUU7QUFBQTtBQUFBLHdCQURoRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQ21HO0FBQUEseUJBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQTtBQUFBO0FBQUEsZ0JBWlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY0E7QUFBQSxjQUNDLENBQUNwQixlQUFlRSxhQUFhcUIsS0FBS0gsS0FBSyxLQUNwQyx1QkFBQyxRQUFHLFdBQVUsdUJBQ1RHLGVBQUtDLFNBQVNGO0FBQUFBLGdCQUFJLENBQUNJLFVBQ2hCLHVCQUFDLFFBQ0c7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csSUFBSUEsTUFBTUM7QUFBQUEsb0JBQ1YsV0FBVyxDQUFDLEVBQUVDLFNBQVMsTUFDbkIsa0ZBQWtGQSxXQUFXLGtCQUFrQixtQkFBbUI7QUFBQSxvQkFHdEk7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsUUFDWG5DLHNCQUFZaUMsTUFBTUQsU0FBUyxFQUFFLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFNQyxnQkFBTU4sU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQjtBQUFBO0FBQUE7QUFBQSxrQkFUdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVBLEtBWEtNLE1BQU1DLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLGNBQ0gsS0FmTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQWpDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1DQSxJQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSUosS0FBS0k7QUFBQUEsZ0JBQ1QsU0FBUyxNQUFNO0FBQ1gsc0JBQUkzQixhQUFhO0FBQ2JDLG1DQUFlLEtBQUs7QUFBQSxrQkFDeEI7QUFBQSxnQkFDSjtBQUFBLGdCQUNBLFdBQVcsQ0FBQyxFQUFFMkIsU0FBUyxNQUNuQixtRUFBbUU1QixjQUFjLG1CQUFtQixFQUFFLElBQUk0QixXQUFXLGtCQUFrQixtQkFBbUI7QUFBQSxnQkFHN0puQztBQUFBQSw4QkFBWThCLEtBQUtFLFNBQVMsRUFBRTtBQUFBLGtCQUM1QixDQUFDekIsZUFBZSx1QkFBQyxVQUFLLFdBQVUsUUFBUXVCLGVBQUtILFNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUE7QUFBQTtBQUFBLGNBWnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBLEtBcERDRyxLQUFLSCxPQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0RBO0FBQUEsVUFDSCxLQXpETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBEQTtBQUFBLGFBN0VSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU1A7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVnQixnQkFBZ0I3QixjQUFjLFdBQVcsYUFBYTtBQUFBLFlBRTlEQTtBQUFBQSw0QkFDRyx1QkFBQywrQkFBNEIsTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQyxJQUV0Qyx1QkFBQyw4QkFBMkIsTUFBTSxNQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGNBRXhDLENBQUNBLGVBQWUsdUJBQUMsVUFBSyxXQUFVLFFBQU8sd0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQTtBQUFBLFVBWHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBLEtBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUE7QUFBQTtBQUFBLElBakhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtIQTtBQUVSO0FBQUVELEdBMUpXRCxTQUFPO0FBQUEsVUFLUVIsU0FHRk8sdUJBQXVCO0FBQUE7QUFBQWlDLEtBUnBDaEM7QUFBTyxJQUFBZ0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVJlZiIsInVzZVN0YXRlIiwiTmF2TGluayIsIlJ4Q2hldnJvbkRvd24iLCJIaU91dGxpbmVDaGV2cm9uRG91YmxlTGVmdCIsIkhpT3V0bGluZUNoZXZyb25Eb3VibGVSaWdodCIsInVzZUF1dGgiLCJmaWx0ZXJNZW51SXRlbXMiLCJNRU5VX0lURU1TIiwiZ2V0TWVudUljb24iLCJPcmdhbml6YXRpb25Mb2dvIiwiTWVudU5hdkZsYXRSZXN1bHRzIiwiTWVudU5hdlNlYXJjaEJhciIsInVzZU1lbnVOYXZTZWFyY2hSZXN1bHRzIiwiU2lkZWJhciIsIl9zIiwiaXNDb2xsYXBzZWQiLCJzZXRJc0NvbGxhcHNlZCIsIm9wZW5TdWJtZW51cyIsInNldE9wZW5TdWJtZW51cyIsIm1lbnVTZWFyY2hRdWVyeSIsInNldE1lbnVTZWFyY2hRdWVyeSIsInNlYXJjaElucHV0UmVmIiwicGVybWlzc2lvbnMiLCJmaWx0ZXJlZE1lbnVJdGVtcyIsInNlYXJjaFJlc3VsdHMiLCJpc1NlYXJjaEFjdGl2ZSIsInRyaW0iLCJsZW5ndGgiLCJ0b2dnbGVTaWRlYmFyIiwid2lsbENvbGxhcHNlIiwiZXhwYW5kU2lkZWJhckZvclNlYXJjaCIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsImN1cnJlbnQiLCJmb2N1cyIsImhhbmRsZVN1Ym1lbnVDbGljayIsImxhYmVsIiwicHJldiIsIm1hcCIsIml0ZW0iLCJjaGlsZHJlbiIsImljb25LZXkiLCJjaGlsZCIsInBhdGgiLCJpc0FjdGl2ZSIsImp1c3RpZnlDb250ZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2lkZWJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE5hdkxpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IFJ4Q2hldnJvbkRvd24gfSBmcm9tICdyZWFjdC1pY29ucy9yeCc7XG5pbXBvcnQgeyBIaU91dGxpbmVDaGV2cm9uRG91YmxlTGVmdCwgSGlPdXRsaW5lQ2hldnJvbkRvdWJsZVJpZ2h0IH0gZnJvbSAncmVhY3QtaWNvbnMvaGknO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2hvb2tzL3VzZUF1dGgnO1xuaW1wb3J0IHsgZmlsdGVyTWVudUl0ZW1zIH0gZnJvbSAnLi4vLi4vdXRpbHMvbWVudUZpbHRlcic7XG5pbXBvcnQgeyBNRU5VX0lURU1TLCBnZXRNZW51SWNvbiB9IGZyb20gJy4uLy4uL2NvbmZpZy9tZW51SXRlbXMnO1xuaW1wb3J0IHsgT3JnYW5pemF0aW9uTG9nbyB9IGZyb20gJy4uL2NvbW1vbi9Pcmdhbml6YXRpb25Mb2dvJztcbmltcG9ydCB7IE1lbnVOYXZGbGF0UmVzdWx0cywgTWVudU5hdlNlYXJjaEJhciwgdXNlTWVudU5hdlNlYXJjaFJlc3VsdHMgfSBmcm9tICcuL01lbnVOYXZTZWFyY2gnO1xuXG5leHBvcnQgY29uc3QgU2lkZWJhciA9ICgpID0+IHtcbiAgICBjb25zdCBbaXNDb2xsYXBzZWQsIHNldElzQ29sbGFwc2VkXSA9IHVzZVN0YXRlKHRydWUpO1xuICAgIGNvbnN0IFtvcGVuU3VibWVudXMsIHNldE9wZW5TdWJtZW51c10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBib29sZWFuPj4oe30pO1xuICAgIGNvbnN0IFttZW51U2VhcmNoUXVlcnksIHNldE1lbnVTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3Qgc2VhcmNoSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gICAgY29uc3QgeyBwZXJtaXNzaW9ucyB9ID0gdXNlQXV0aCgpO1xuXG4gICAgY29uc3QgZmlsdGVyZWRNZW51SXRlbXMgPSBmaWx0ZXJNZW51SXRlbXMoTUVOVV9JVEVNUywgcGVybWlzc2lvbnMpO1xuICAgIGNvbnN0IHNlYXJjaFJlc3VsdHMgPSB1c2VNZW51TmF2U2VhcmNoUmVzdWx0cyhmaWx0ZXJlZE1lbnVJdGVtcywgbWVudVNlYXJjaFF1ZXJ5KTtcbiAgICBjb25zdCBpc1NlYXJjaEFjdGl2ZSA9IG1lbnVTZWFyY2hRdWVyeS50cmltKCkubGVuZ3RoID4gMDtcblxuICAgIGNvbnN0IHRvZ2dsZVNpZGViYXIgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHdpbGxDb2xsYXBzZSA9ICFpc0NvbGxhcHNlZDtcbiAgICAgICAgc2V0SXNDb2xsYXBzZWQoIWlzQ29sbGFwc2VkKTtcbiAgICAgICAgaWYgKHdpbGxDb2xsYXBzZSkge1xuICAgICAgICAgICAgc2V0T3BlblN1Ym1lbnVzKHt9KTtcbiAgICAgICAgICAgIHNldE1lbnVTZWFyY2hRdWVyeSgnJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgZXhwYW5kU2lkZWJhckZvclNlYXJjaCA9ICgpID0+IHtcbiAgICAgICAgc2V0SXNDb2xsYXBzZWQoZmFsc2UpO1xuICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gc2VhcmNoSW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1lbnVDbGljayA9IChsYWJlbDogc3RyaW5nKSA9PiB7XG4gICAgICAgIGlmIChpc0NvbGxhcHNlZCkge1xuICAgICAgICAgICAgc2V0SXNDb2xsYXBzZWQoZmFsc2UpO1xuICAgICAgICAgICAgc2V0T3BlblN1Ym1lbnVzKHsgW2xhYmVsXTogdHJ1ZSB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldE9wZW5TdWJtZW51cygocHJldikgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIFtsYWJlbF06ICFwcmV2W2xhYmVsXSxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8YXNpZGVcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIG1pbi1oLXNjcmVlbiBwLTQgdGV4dC13aGl0ZSBiZy1wcmltYXJ5IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCBmbGV4IGZsZXgtY29sICR7aXNDb2xsYXBzZWQgPyAndy0yMCcgOiAndy02NCd9YH1cbiAgICAgICAgPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1iLTggZmxleCBoLTEyIHctZnVsbCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xuICAgICAgICAgICAgICAgICAgICBpc0NvbGxhcHNlZCA/ICdqdXN0aWZ5LWNlbnRlcicgOiAnanVzdGlmeS1zdGFydCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8T3JnYW5pemF0aW9uTG9nb1xuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BibG9jayBvYmplY3QtY29udGFpbiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29sbGFwc2VkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnaC0xMCB3LTEwIG1heC1oLTEwIG1heC13LTEwIG9iamVjdC1jZW50ZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnaC0xMiB3LWZ1bGwgbWF4LXctWzE5MnB4XSBvYmplY3QtbGVmdCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIGFsdD1cIkxvZ29cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3ctYXV0byBmbGV4IGZsZXgtY29sIG1pbi1oLTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPE1lbnVOYXZTZWFyY2hCYXJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzaWRlYmFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5PXttZW51U2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblF1ZXJ5Q2hhbmdlPXtzZXRNZW51U2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICBpbnB1dFJlZj17c2VhcmNoSW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICBzaWRlYmFyQ29sbGFwc2VkPXtpc0NvbGxhcHNlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXhwYW5kU2lkZWJhckZvclNlYXJjaD17ZXhwYW5kU2lkZWJhckZvclNlYXJjaH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHtpc1NlYXJjaEFjdGl2ZSA/IChcbiAgICAgICAgICAgICAgICAgICAgPE1lbnVOYXZGbGF0UmVzdWx0c1xuICAgICAgICAgICAgICAgICAgICAgICAgZW50cmllcz17c2VhcmNoUmVzdWx0c31cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzaWRlYmFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9eygpID0+IHNldE1lbnVTZWFyY2hRdWVyeSgnJyl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkTWVudUl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0ubGFiZWx9IGNsYXNzTmFtZT1cIm1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY2hpbGRyZW4gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1lbnVDbGljayhpdGVtLmxhYmVsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgdy1mdWxsIHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1ncmF5LTcwMCAke2lzQ29sbGFwc2VkID8gJ2p1c3RpZnktY2VudGVyJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0TWVudUljb24oaXRlbS5pY29uS2V5LCAyNCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTEgbWwtNCB0ZXh0LWxlZnRcIj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJ4Q2hldnJvbkRvd25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwICR7b3BlblN1Ym1lbnVzW2l0ZW0ubGFiZWxdID8gJ3JvdGF0ZS0xODAnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NvbGxhcHNlZCAmJiBvcGVuU3VibWVudXNbaXRlbS5sYWJlbF0gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwicGwtOCBtdC0xIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY2hpbGRyZW4ubWFwKChjaGlsZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2NoaWxkLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2NoaWxkLnBhdGh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIHctZnVsbCBwLTIgdGV4dC1zbSByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCAke2lzQWN0aXZlID8gJ2JnLWluZGlnby02MDAnIDogJ2hvdmVyOmJnLWdyYXktNzAwJ31gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1yLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0TWVudUljb24oY2hpbGQuaWNvbktleSwgMjApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2NoaWxkLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGghfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQ29sbGFwc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0NvbGxhcHNlZChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCAke2lzQ29sbGFwc2VkID8gJ2p1c3RpZnktY2VudGVyJyA6ICcnfSAke2lzQWN0aXZlID8gJ2JnLWluZGlnby02MDAnIDogJ2hvdmVyOmJnLWdyYXktNzAwJ31gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRNZW51SWNvbihpdGVtLmljb25LZXksIDI0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ29sbGFwc2VkICYmIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTRcIj57aXRlbS5sYWJlbH08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9uYXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBtdC1hdXRvIGJvcmRlci10IGJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVNpZGViYXJ9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHctZnVsbCBwLTIgdGV4dC13aGl0ZSByb3VuZGVkLW1kIGhvdmVyOmJnLWdyYXktNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IGlzQ29sbGFwc2VkID8gJ2NlbnRlcicgOiAnZmxleC1zdGFydCcgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpc0NvbGxhcHNlZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxIaU91dGxpbmVDaGV2cm9uRG91YmxlUmlnaHQgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8SGlPdXRsaW5lQ2hldnJvbkRvdWJsZUxlZnQgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHshaXNDb2xsYXBzZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtNFwiPkNvbnRyYWVyPC9zcGFuPn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2FzaWRlPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhci50c3gifQ==