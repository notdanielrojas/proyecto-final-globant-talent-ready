import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/Header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/layouts/Header.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useAuth } from "/src/hooks/useAuth.ts";
export const Header = () => {
  _s();
  const { logout } = useAuth();
  return /* @__PURE__ */ jsxDEV("header", { className: "flex items-center justify-end w-full h-16 px-6 bg-white shadow-sm", children: /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick: () => logout(),
      className: "px-4 py-2 font-semibold text-white bg-red-600 rounded-md hover:bg-red-700",
      children: "Cerrar Sesión"
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/layouts/Header.tsx",
      lineNumber: 27,
      columnNumber: 13
    },
    this
  ) }, void 0, false, {
    fileName: "/app/src/components/layouts/Header.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_s(Header, "JN45pPWTCN0QEZFRvGkjOxroHA0=", false, function() {
  return [useAuth];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/layouts/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/layouts/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1k7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBUFosU0FBU0EsZUFBZTtBQUVqQixhQUFNQyxTQUFTQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxFQUFFQyxPQUFPLElBQUlILFFBQVE7QUFFM0IsU0FDSSx1QkFBQyxZQUFPLFdBQVUscUVBQ2Q7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLE1BQUs7QUFBQSxNQUNMLFNBQVMsTUFBTUcsT0FBTztBQUFBLE1BQ3RCLFdBQVU7QUFBQSxNQUEyRTtBQUFBO0FBQUEsSUFIekY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFUjtBQUFFRCxHQWRXRCxRQUFNO0FBQUEsVUFDSUQsT0FBTztBQUFBO0FBQUFJLEtBRGpCSDtBQUFNLElBQUFHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VBdXRoIiwiSGVhZGVyIiwiX3MiLCJsb2dvdXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9ob29rcy91c2VBdXRoJztcblxuZXhwb3J0IGNvbnN0IEhlYWRlciA9ICgpID0+IHtcbiAgICBjb25zdCB7IGxvZ291dCB9ID0gdXNlQXV0aCgpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCB3LWZ1bGwgaC0xNiBweC02IGJnLXdoaXRlIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGxvZ291dCgpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgYmctcmVkLTYwMCByb3VuZGVkLW1kIGhvdmVyOmJnLXJlZC03MDBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENlcnJhciBTZXNpw7NuXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9oZWFkZXI+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvbGF5b3V0cy9IZWFkZXIudHN4In0=