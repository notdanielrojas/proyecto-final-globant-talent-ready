import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/OrganizationContext.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/context/OrganizationContext.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"]





;
import { useAuth } from "/src/hooks/useAuth.ts";
import { fetchOrganizationBranding } from "/src/services/organizationDetailsService.ts";
import {
  applyOrganizationTheme,
  buildDocumentTitle,
  clearOrganizationBrandingFromSession,
  readOrganizationBrandingFromSession,
  sanitizeOrganizationBranding,
  writeOrganizationBrandingToSession
} from "/src/context/organizationBranding.ts";
export const OrganizationContext = createContext(void 0);
function applyDocumentTitle(branding) {
  document.title = buildDocumentTitle(branding?.name);
}
function applyBrandingSideEffects(branding) {
  applyDocumentTitle(branding);
  applyOrganizationTheme(branding);
}
export const OrganizationProvider = ({ children }) => {
  _s();
  const { isAuthenticated } = useAuth();
  const [branding, setBrandingState] = useState(null);
  const [loading, setLoading] = useState(false);
  const setBranding = useCallback((next) => {
    if (!next) {
      clearOrganizationBrandingFromSession();
      setBrandingState(null);
      applyBrandingSideEffects(null);
      return;
    }
    const safe = sanitizeOrganizationBranding(next);
    if (!safe) return;
    writeOrganizationBrandingToSession(safe);
    setBrandingState(safe);
    applyBrandingSideEffects(safe);
  }, []);
  const refreshBranding = useCallback(async () => {
    setLoading(true);
    try {
      const safe = await fetchOrganizationBranding();
      if (safe) {
        writeOrganizationBrandingToSession(safe);
        setBrandingState(safe);
        applyBrandingSideEffects(safe);
      } else {
        applyBrandingSideEffects(null);
      }
    } catch (error) {
      console.error("No se pudo cargar la identidad de la organización.", error);
      applyBrandingSideEffects(null);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    const cached = readOrganizationBrandingFromSession();
    if (cached) {
      setBrandingState(cached);
      applyBrandingSideEffects(cached);
      setLoading(false);
      return;
    }
    void refreshBranding();
  }, [isAuthenticated, refreshBranding]);
  const value = useMemo(
    () => ({
      branding,
      loading,
      setBranding,
      refreshBranding
    }),
    [branding, loading, setBranding, refreshBranding]
  );
  return /* @__PURE__ */ jsxDEV(OrganizationContext.Provider, { value, children }, void 0, false, {
    fileName: "/app/src/context/OrganizationContext.tsx",
    lineNumber: 121,
    columnNumber: 5
  }, this);
};
_s(OrganizationProvider, "ICKcvZF+fm8b0cTQE/WKEsAulKU=", false, function() {
  return [useAuth];
});
_c = OrganizationProvider;
var _c;
$RefreshReg$(_c, "OrganizationProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/context/OrganizationContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/context/OrganizationContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJHUjtBQUFBLEVBQ0lBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUc7QUFDUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlDQUFpQztBQUMxQztBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUc7QUFTQSxhQUFNQyxzQkFBc0JiLGNBQW1EYyxNQUFTO0FBRS9GLFNBQVNDLG1CQUFtQkMsVUFBNkM7QUFDckVDLFdBQVNDLFFBQVFWLG1CQUFtQlEsVUFBVUcsSUFBSTtBQUN0RDtBQUVBLFNBQVNDLHlCQUF5QkosVUFBNkM7QUFDM0VELHFCQUFtQkMsUUFBUTtBQUMzQlQseUJBQXVCUyxRQUFRO0FBQ25DO0FBRU8sYUFBTUssdUJBQXVCQSxDQUFDLEVBQUVDLFNBQWtDLE1BQU07QUFBQUMsS0FBQTtBQUMzRSxRQUFNLEVBQUVDLGdCQUFnQixJQUFJbkIsUUFBUTtBQUNwQyxRQUFNLENBQUNXLFVBQVVTLGdCQUFnQixJQUFJckIsU0FBc0MsSUFBSTtBQUMvRSxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEtBQUs7QUFFNUMsUUFBTXdCLGNBQWMzQixZQUFZLENBQUM0QixTQUFzQztBQUNuRSxRQUFJLENBQUNBLE1BQU07QUFDUHBCLDJDQUFxQztBQUNyQ2dCLHVCQUFpQixJQUFJO0FBQ3JCTCwrQkFBeUIsSUFBSTtBQUM3QjtBQUFBLElBQ0o7QUFFQSxVQUFNVSxPQUFPbkIsNkJBQTZCa0IsSUFBSTtBQUM5QyxRQUFJLENBQUNDLEtBQU07QUFFWGxCLHVDQUFtQ2tCLElBQUk7QUFDdkNMLHFCQUFpQkssSUFBSTtBQUNyQlYsNkJBQXlCVSxJQUFJO0FBQUEsRUFDakMsR0FBRyxFQUFFO0FBRUwsUUFBTUMsa0JBQWtCOUIsWUFBWSxZQUFZO0FBQzVDMEIsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNBLFlBQU1HLE9BQU8sTUFBTXhCLDBCQUEwQjtBQUM3QyxVQUFJd0IsTUFBTTtBQUNObEIsMkNBQW1Da0IsSUFBSTtBQUN2Q0wseUJBQWlCSyxJQUFJO0FBQ3JCVixpQ0FBeUJVLElBQUk7QUFBQSxNQUNqQyxPQUFPO0FBQ0hWLGlDQUF5QixJQUFJO0FBQUEsTUFDakM7QUFBQSxJQUNKLFNBQVNZLE9BQU87QUFDWkMsY0FBUUQsTUFBTSxzREFBc0RBLEtBQUs7QUFDekVaLCtCQUF5QixJQUFJO0FBQUEsSUFDakMsVUFBQztBQUNHTyxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKLEdBQUcsRUFBRTtBQUVMekIsWUFBVSxNQUFNO0FBQ1osVUFBTWdDLFNBQVN4QixvQ0FBb0M7QUFDbkQsUUFBSXdCLFFBQVE7QUFDUlQsdUJBQWlCUyxNQUFNO0FBQ3ZCZCwrQkFBeUJjLE1BQU07QUFDL0JQLGlCQUFXLEtBQUs7QUFDaEI7QUFBQSxJQUNKO0FBRUEsU0FBS0ksZ0JBQWdCO0FBQUEsRUFDekIsR0FBRyxDQUFDUCxpQkFBaUJPLGVBQWUsQ0FBQztBQUVyQyxRQUFNSSxRQUFRaEM7QUFBQUEsSUFDVixPQUFPO0FBQUEsTUFDSGE7QUFBQUEsTUFDQVU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUc7QUFBQUEsSUFDSjtBQUFBLElBQ0EsQ0FBQ2YsVUFBVVUsU0FBU0UsYUFBYUcsZUFBZTtBQUFBLEVBQ3BEO0FBRUEsU0FDSSx1QkFBQyxvQkFBb0IsVUFBcEIsRUFBNkIsT0FBZVQsWUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzRDtBQUU5RDtBQUFFQyxHQWpFV0Ysc0JBQW9CO0FBQUEsVUFDRGhCLE9BQU87QUFBQTtBQUFBK0IsS0FEMUJmO0FBQW9CLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VBdXRoIiwiZmV0Y2hPcmdhbml6YXRpb25CcmFuZGluZyIsImFwcGx5T3JnYW5pemF0aW9uVGhlbWUiLCJidWlsZERvY3VtZW50VGl0bGUiLCJjbGVhck9yZ2FuaXphdGlvbkJyYW5kaW5nRnJvbVNlc3Npb24iLCJyZWFkT3JnYW5pemF0aW9uQnJhbmRpbmdGcm9tU2Vzc2lvbiIsInNhbml0aXplT3JnYW5pemF0aW9uQnJhbmRpbmciLCJ3cml0ZU9yZ2FuaXphdGlvbkJyYW5kaW5nVG9TZXNzaW9uIiwiT3JnYW5pemF0aW9uQ29udGV4dCIsInVuZGVmaW5lZCIsImFwcGx5RG9jdW1lbnRUaXRsZSIsImJyYW5kaW5nIiwiZG9jdW1lbnQiLCJ0aXRsZSIsIm5hbWUiLCJhcHBseUJyYW5kaW5nU2lkZUVmZmVjdHMiLCJPcmdhbml6YXRpb25Qcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJpc0F1dGhlbnRpY2F0ZWQiLCJzZXRCcmFuZGluZ1N0YXRlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZXRCcmFuZGluZyIsIm5leHQiLCJzYWZlIiwicmVmcmVzaEJyYW5kaW5nIiwiZXJyb3IiLCJjb25zb2xlIiwiY2FjaGVkIiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcmdhbml6YXRpb25Db250ZXh0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICAgIGNyZWF0ZUNvbnRleHQsXG4gICAgdXNlQ2FsbGJhY2ssXG4gICAgdXNlRWZmZWN0LFxuICAgIHVzZU1lbW8sXG4gICAgdXNlU3RhdGUsXG4gICAgdHlwZSBSZWFjdE5vZGUsXG59IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9ob29rcy91c2VBdXRoJztcbmltcG9ydCB7IGZldGNoT3JnYW5pemF0aW9uQnJhbmRpbmcgfSBmcm9tICcuLi9zZXJ2aWNlcy9vcmdhbml6YXRpb25EZXRhaWxzU2VydmljZSc7XG5pbXBvcnQge1xuICAgIGFwcGx5T3JnYW5pemF0aW9uVGhlbWUsXG4gICAgYnVpbGREb2N1bWVudFRpdGxlLFxuICAgIGNsZWFyT3JnYW5pemF0aW9uQnJhbmRpbmdGcm9tU2Vzc2lvbixcbiAgICByZWFkT3JnYW5pemF0aW9uQnJhbmRpbmdGcm9tU2Vzc2lvbixcbiAgICBzYW5pdGl6ZU9yZ2FuaXphdGlvbkJyYW5kaW5nLFxuICAgIHdyaXRlT3JnYW5pemF0aW9uQnJhbmRpbmdUb1Nlc3Npb24sXG4gICAgdHlwZSBPcmdhbml6YXRpb25CcmFuZGluZyxcbn0gZnJvbSAnLi9vcmdhbml6YXRpb25CcmFuZGluZyc7XG5cbmludGVyZmFjZSBPcmdhbml6YXRpb25Db250ZXh0VHlwZSB7XG4gICAgYnJhbmRpbmc6IE9yZ2FuaXphdGlvbkJyYW5kaW5nIHwgbnVsbDtcbiAgICBsb2FkaW5nOiBib29sZWFuO1xuICAgIHNldEJyYW5kaW5nOiAoYnJhbmRpbmc6IE9yZ2FuaXphdGlvbkJyYW5kaW5nIHwgbnVsbCkgPT4gdm9pZDtcbiAgICByZWZyZXNoQnJhbmRpbmc6ICgpID0+IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCBjb25zdCBPcmdhbml6YXRpb25Db250ZXh0ID0gY3JlYXRlQ29udGV4dDxPcmdhbml6YXRpb25Db250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuZnVuY3Rpb24gYXBwbHlEb2N1bWVudFRpdGxlKGJyYW5kaW5nOiBPcmdhbml6YXRpb25CcmFuZGluZyB8IG51bGwpOiB2b2lkIHtcbiAgICBkb2N1bWVudC50aXRsZSA9IGJ1aWxkRG9jdW1lbnRUaXRsZShicmFuZGluZz8ubmFtZSk7XG59XG5cbmZ1bmN0aW9uIGFwcGx5QnJhbmRpbmdTaWRlRWZmZWN0cyhicmFuZGluZzogT3JnYW5pemF0aW9uQnJhbmRpbmcgfCBudWxsKTogdm9pZCB7XG4gICAgYXBwbHlEb2N1bWVudFRpdGxlKGJyYW5kaW5nKTtcbiAgICBhcHBseU9yZ2FuaXphdGlvblRoZW1lKGJyYW5kaW5nKTtcbn1cblxuZXhwb3J0IGNvbnN0IE9yZ2FuaXphdGlvblByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pID0+IHtcbiAgICBjb25zdCB7IGlzQXV0aGVudGljYXRlZCB9ID0gdXNlQXV0aCgpO1xuICAgIGNvbnN0IFticmFuZGluZywgc2V0QnJhbmRpbmdTdGF0ZV0gPSB1c2VTdGF0ZTxPcmdhbml6YXRpb25CcmFuZGluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IHNldEJyYW5kaW5nID0gdXNlQ2FsbGJhY2soKG5leHQ6IE9yZ2FuaXphdGlvbkJyYW5kaW5nIHwgbnVsbCkgPT4ge1xuICAgICAgICBpZiAoIW5leHQpIHtcbiAgICAgICAgICAgIGNsZWFyT3JnYW5pemF0aW9uQnJhbmRpbmdGcm9tU2Vzc2lvbigpO1xuICAgICAgICAgICAgc2V0QnJhbmRpbmdTdGF0ZShudWxsKTtcbiAgICAgICAgICAgIGFwcGx5QnJhbmRpbmdTaWRlRWZmZWN0cyhudWxsKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHNhZmUgPSBzYW5pdGl6ZU9yZ2FuaXphdGlvbkJyYW5kaW5nKG5leHQpO1xuICAgICAgICBpZiAoIXNhZmUpIHJldHVybjtcblxuICAgICAgICB3cml0ZU9yZ2FuaXphdGlvbkJyYW5kaW5nVG9TZXNzaW9uKHNhZmUpO1xuICAgICAgICBzZXRCcmFuZGluZ1N0YXRlKHNhZmUpO1xuICAgICAgICBhcHBseUJyYW5kaW5nU2lkZUVmZmVjdHMoc2FmZSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgcmVmcmVzaEJyYW5kaW5nID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2FmZSA9IGF3YWl0IGZldGNoT3JnYW5pemF0aW9uQnJhbmRpbmcoKTtcbiAgICAgICAgICAgIGlmIChzYWZlKSB7XG4gICAgICAgICAgICAgICAgd3JpdGVPcmdhbml6YXRpb25CcmFuZGluZ1RvU2Vzc2lvbihzYWZlKTtcbiAgICAgICAgICAgICAgICBzZXRCcmFuZGluZ1N0YXRlKHNhZmUpO1xuICAgICAgICAgICAgICAgIGFwcGx5QnJhbmRpbmdTaWRlRWZmZWN0cyhzYWZlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgYXBwbHlCcmFuZGluZ1NpZGVFZmZlY3RzKG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignTm8gc2UgcHVkbyBjYXJnYXIgbGEgaWRlbnRpZGFkIGRlIGxhIG9yZ2FuaXphY2nDs24uJywgZXJyb3IpO1xuICAgICAgICAgICAgYXBwbHlCcmFuZGluZ1NpZGVFZmZlY3RzKG51bGwpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBjYWNoZWQgPSByZWFkT3JnYW5pemF0aW9uQnJhbmRpbmdGcm9tU2Vzc2lvbigpO1xuICAgICAgICBpZiAoY2FjaGVkKSB7XG4gICAgICAgICAgICBzZXRCcmFuZGluZ1N0YXRlKGNhY2hlZCk7XG4gICAgICAgICAgICBhcHBseUJyYW5kaW5nU2lkZUVmZmVjdHMoY2FjaGVkKTtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdm9pZCByZWZyZXNoQnJhbmRpbmcoKTtcbiAgICB9LCBbaXNBdXRoZW50aWNhdGVkLCByZWZyZXNoQnJhbmRpbmddKTtcblxuICAgIGNvbnN0IHZhbHVlID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gKHtcbiAgICAgICAgICAgIGJyYW5kaW5nLFxuICAgICAgICAgICAgbG9hZGluZyxcbiAgICAgICAgICAgIHNldEJyYW5kaW5nLFxuICAgICAgICAgICAgcmVmcmVzaEJyYW5kaW5nLFxuICAgICAgICB9KSxcbiAgICAgICAgW2JyYW5kaW5nLCBsb2FkaW5nLCBzZXRCcmFuZGluZywgcmVmcmVzaEJyYW5kaW5nXVxuICAgICk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8T3JnYW5pemF0aW9uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PntjaGlsZHJlbn08L09yZ2FuaXphdGlvbkNvbnRleHQuUHJvdmlkZXI+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbnRleHQvT3JnYW5pemF0aW9uQ29udGV4dC50c3gifQ==