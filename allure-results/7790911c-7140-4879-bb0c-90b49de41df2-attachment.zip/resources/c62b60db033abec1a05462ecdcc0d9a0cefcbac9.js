import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { movimientosBancosModuleConfig } from "/src/features/movimientos_bancos/movimientos_bancos.config.tsx";
export const MovimientosBancosListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(movimientosBancosModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  const isOriginated = (item) => !!item.source_type && !!item.source_id && (item.source_type.includes("Collection") || item.source_type.includes("PaymentOrder"));
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: movimientosBancosModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canDelete: (item) => !isOriginated(item),
      canEdit: (item) => !isOriginated(item)
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
};
_s(MovimientosBancosListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = MovimientosBancosListPage;
var _c;
$RefreshReg$(_c, "MovimientosBancosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyxxQ0FBd0Q7QUFFMUQsYUFBTUMsNEJBQTRCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0MsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSWhCLFFBQXNCRSwrQkFBK0JELHdCQUF3QixDQUFDO0FBRWxGLE1BQUlPLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUd2RCxRQUFNUyxlQUFlQSxDQUFDQyxTQUNsQixDQUFDLENBQUNBLEtBQUtDLGVBQ1AsQ0FBQyxDQUFDRCxLQUFLRSxjQUNORixLQUFLQyxZQUFZRSxTQUFTLFlBQVksS0FBS0gsS0FBS0MsWUFBWUUsU0FBUyxjQUFjO0FBRXhGLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFuQjtBQUFBQSxNQUNSLG9CQUFvQkc7QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhTSxRQUFRO0FBQUEsTUFDakMsaUJBQWlCTixhQUFhTyxhQUFhO0FBQUEsTUFDM0MsZUFBZVAsYUFBYVEsV0FBVztBQUFBLE1BQ3ZDLHVCQUF1QjtBQUFBLE1BQ3ZCLFdBQVcsQ0FBQ04sU0FBUyxDQUFDRCxhQUFhQyxJQUFJO0FBQUEsTUFDdkMsU0FBUyxDQUFDQSxTQUFTLENBQUNELGFBQWFDLElBQUk7QUFBQTtBQUFBLElBakJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQjJDO0FBR25EO0FBQUVkLEdBN0NXRCwyQkFBeUI7QUFBQSxVQWM5QkgsT0FBTztBQUFBO0FBQUF5QixLQWRGdEI7QUFBeUIsSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJtb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZyIsIk1vdmltaWVudG9zQmFuY29zTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJpc09yaWdpbmF0ZWQiLCJpdGVtIiwic291cmNlX3R5cGUiLCJzb3VyY2VfaWQiLCJpbmNsdWRlcyIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW92aW1pZW50b3NCYW5jb3NMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL21vdmltaWVudG9zX2JhbmNvcy9wYWdlcy9Nb3ZpbWllbnRvc0JhbmNvc0xpc3RQYWdlLnRzeFxuaW1wb3J0IHsgR2VuZXJpY0xpc3RQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IHVzZUNydWQgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkJztcbmltcG9ydCB7IGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdERhdGVSYW5nZSc7XG5pbXBvcnQgeyBtb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZywgdHlwZSBCYW5rTW92ZW1lbnQgfSBmcm9tICcuLi9tb3ZpbWllbnRvc19iYW5jb3MuY29uZmlnJztcblxuZXhwb3J0IGNvbnN0IE1vdmltaWVudG9zQmFuY29zTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxCYW5rTW92ZW1lbnQ+KG1vdmltaWVudG9zQmFuY29zTW9kdWxlQ29uZmlnLCBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSgpKTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIC8vIE1vdmltaWVudG9zIG9yaWdpbmFkb3MgcG9yIGNvYnJhbnphcyB1IMOzcmRlbmVzIGRlIHBhZ28gbm8gZGViZW4gcG9kZXIgYm9ycmFyc2UgbmkgZWRpdGFyc2UuXG4gICAgY29uc3QgaXNPcmlnaW5hdGVkID0gKGl0ZW06IEJhbmtNb3ZlbWVudCkgPT5cbiAgICAgICAgISFpdGVtLnNvdXJjZV90eXBlICYmXG4gICAgICAgICEhaXRlbS5zb3VyY2VfaWQgJiZcbiAgICAgICAgKGl0ZW0uc291cmNlX3R5cGUuaW5jbHVkZXMoJ0NvbGxlY3Rpb24nKSB8fCBpdGVtLnNvdXJjZV90eXBlLmluY2x1ZGVzKCdQYXltZW50T3JkZXInKSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPEJhbmtNb3ZlbWVudD5cbiAgICAgICAgICAgIGNvbmZpZz17bW92aW1pZW50b3NCYW5jb3NNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfVxuICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgc2VhcmNoVGVybT17c2VhcmNoUGFyYW1zLnRlcm0gPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyU3RhcnQ9e3NlYXJjaFBhcmFtcy5zdGFydERhdGUgPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyRW5kPXtzZWFyY2hQYXJhbXMuZW5kRGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlcj17dHJ1ZX1cbiAgICAgICAgICAgIGNhbkRlbGV0ZT17KGl0ZW0pID0+ICFpc09yaWdpbmF0ZWQoaXRlbSl9XG4gICAgICAgICAgICBjYW5FZGl0PXsoaXRlbSkgPT4gIWlzT3JpZ2luYXRlZChpdGVtKX1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbW92aW1pZW50b3NfYmFuY29zL3BhZ2VzL01vdmltaWVudG9zQmFuY29zTGlzdFBhZ2UudHN4In0=