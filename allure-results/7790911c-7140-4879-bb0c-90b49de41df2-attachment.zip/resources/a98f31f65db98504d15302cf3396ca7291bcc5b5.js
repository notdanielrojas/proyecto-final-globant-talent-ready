import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/proveedores/pages/ProveedoresEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/proveedores/pages/ProveedoresEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { ProveedoresFormPage } from "/src/features/proveedores/pages/ProveedoresFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { searchByField } from "/src/services/apiService.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { resolveInvoiceSeriesForTaxChange } from "/src/utils/invoiceSeries.ts";
export const ProveedorEditPage = () => {
  _s();
  const { id } = useParams();
  const { item: proveedor, loading, error } = useCrudItem(proveedoresModuleConfig, id);
  const [hydratedData, setHydratedData] = useState(null);
  useEffect(() => {
    if (!proveedor) {
      setHydratedData(null);
      return;
    }
    const code = proveedor.account_code;
    if (!code || proveedor.account_name != null && proveedor.account_name !== "") {
      setHydratedData(proveedor);
      return;
    }
    let cancelled = false;
    searchByField(
      planDeCuentasModuleConfig.endpoint,
      [{ fieldName: "code", value: code }]
    ).then((account) => {
      if (cancelled || !account) return;
      setHydratedData({
        ...proveedor,
        account_id: account.id,
        account_code: account.code,
        account_name: account.name ?? null
      });
    }).catch(() => setHydratedData(proveedor));
    return () => {
      cancelled = true;
    };
  }, [proveedor]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresEditPage.tsx",
    lineNumber: 66,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresEditPage.tsx",
    lineNumber: 67,
    columnNumber: 21
  }, this);
  if (!proveedor) return /* @__PURE__ */ jsxDEV("div", { children: "Proveedor no encontrado." }, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresEditPage.tsx",
    lineNumber: 68,
    columnNumber: 26
  }, this);
  const raw = hydratedData ?? proveedor;
  const initialData = {
    ...raw,
    payment_condition: raw.payment_condition != null ? Number(raw.payment_condition) : null,
    serie: resolveInvoiceSeriesForTaxChange(
      String(raw.legacy_tax_condition ?? ""),
      raw.serie,
      { includeNoTributable: true }
    ) || raw.serie
  };
  return /* @__PURE__ */ jsxDEV(
    ProveedoresFormPage,
    {
      mode: "edit",
      initialData,
      loading,
      error
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/proveedores/pages/ProveedoresEditPage.tsx",
      lineNumber: 82,
      columnNumber: 5
    },
    this
  );
};
_s(ProveedorEditPage, "V/NjGqp4aOxgWziws4NNaaatBSg=", false, function() {
  return [useParams, useCrudItem];
});
_c = ProveedorEditPage;
var _c;
$RefreshReg$(_c, "ProveedorEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/proveedores/pages/ProveedoresEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/proveedores/pages/ProveedoresEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEN3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3Q3hCLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywrQkFBK0M7QUFDeEQsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msd0NBQXdDO0FBRTFDLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsR0FBRyxJQUFJWixVQUEwQjtBQUN6QyxRQUFNLEVBQUVhLE1BQU1DLFdBQVdDLFNBQVNDLE1BQU0sSUFBSVosWUFBdUJDLHlCQUF5Qk8sRUFBRTtBQUM5RixRQUFNLENBQUNLLGNBQWNDLGVBQWUsSUFBSWhCLFNBQTJCLElBQUk7QUFHdkVELFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ2EsV0FBVztBQUNaSSxzQkFBZ0IsSUFBSTtBQUNwQjtBQUFBLElBQ0o7QUFDQSxVQUFNQyxPQUFPTCxVQUFVTTtBQUN2QixRQUFJLENBQUNELFFBQVNMLFVBQVVPLGdCQUFnQixRQUFRUCxVQUFVTyxpQkFBaUIsSUFBSztBQUM1RUgsc0JBQWdCSixTQUFTO0FBQ3pCO0FBQUEsSUFDSjtBQUNBLFFBQUlRLFlBQVk7QUFDaEJmO0FBQUFBLE1BQ0lELDBCQUEwQmlCO0FBQUFBLE1BQzFCLENBQUMsRUFBRUMsV0FBVyxRQUFRQyxPQUFPTixLQUFLLENBQUM7QUFBQSxJQUN2QyxFQUNLTyxLQUFLLENBQUNDLFlBQVk7QUFDZixVQUFJTCxhQUFhLENBQUNLLFFBQVM7QUFDM0JULHNCQUFnQjtBQUFBLFFBQ1osR0FBR0o7QUFBQUEsUUFDSGMsWUFBWUQsUUFBUWY7QUFBQUEsUUFDcEJRLGNBQWNPLFFBQVFSO0FBQUFBLFFBQ3RCRSxjQUFjTSxRQUFRRSxRQUFRO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0wsQ0FBQyxFQUNBQyxNQUFNLE1BQU1aLGdCQUFnQkosU0FBUyxDQUFDO0FBRTNDLFdBQU8sTUFBTTtBQUFFUSxrQkFBWTtBQUFBLElBQU07QUFBQSxFQUNyQyxHQUFHLENBQUNSLFNBQVMsQ0FBQztBQUVkLE1BQUlDLFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsVUFBVyxRQUFPLHVCQUFDLFNBQUksd0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2QjtBQUVwRCxRQUFNaUIsTUFBTWQsZ0JBQWdCSDtBQUM1QixRQUFNa0IsY0FBeUI7QUFBQSxJQUMzQixHQUFHRDtBQUFBQSxJQUNIRSxtQkFBbUJGLElBQUlFLHFCQUFxQixPQUFPQyxPQUFPSCxJQUFJRSxpQkFBaUIsSUFBSTtBQUFBLElBQ25GRSxPQUFPMUI7QUFBQUEsTUFDSDJCLE9BQU9MLElBQUlNLHdCQUF3QixFQUFFO0FBQUEsTUFDckNOLElBQUlJO0FBQUFBLE1BQ0osRUFBRUcscUJBQXFCLEtBQUs7QUFBQSxJQUNoQyxLQUFLUCxJQUFJSTtBQUFBQSxFQUNiO0FBRUEsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csTUFBSztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUI7QUFHekI7QUFBRXhCLEdBMURXRCxtQkFBaUI7QUFBQSxVQUNYVixXQUM2QkksV0FBVztBQUFBO0FBQUFtQyxLQUY5QzdCO0FBQWlCLElBQUE2QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJQcm92ZWVkb3Jlc0Zvcm1QYWdlIiwidXNlQ3J1ZEl0ZW0iLCJwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJzZWFyY2hCeUZpZWxkIiwiTG9hZGluZ1NwaW5uZXIiLCJyZXNvbHZlSW52b2ljZVNlcmllc0ZvclRheENoYW5nZSIsIlByb3ZlZWRvckVkaXRQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJwcm92ZWVkb3IiLCJsb2FkaW5nIiwiZXJyb3IiLCJoeWRyYXRlZERhdGEiLCJzZXRIeWRyYXRlZERhdGEiLCJjb2RlIiwiYWNjb3VudF9jb2RlIiwiYWNjb3VudF9uYW1lIiwiY2FuY2VsbGVkIiwiZW5kcG9pbnQiLCJmaWVsZE5hbWUiLCJ2YWx1ZSIsInRoZW4iLCJhY2NvdW50IiwiYWNjb3VudF9pZCIsIm5hbWUiLCJjYXRjaCIsInJhdyIsImluaXRpYWxEYXRhIiwicGF5bWVudF9jb25kaXRpb24iLCJOdW1iZXIiLCJzZXJpZSIsIlN0cmluZyIsImxlZ2FjeV90YXhfY29uZGl0aW9uIiwiaW5jbHVkZU5vVHJpYnV0YWJsZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb3ZlZWRvcmVzRWRpdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9wcm92ZWVkb3Jlcy9wYWdlcy9Qcm92ZWVkb3Jlc0VkaXRQYWdlLnRzeFxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUHJvdmVlZG9yZXNGb3JtUGFnZSB9IGZyb20gJy4vUHJvdmVlZG9yZXNGb3JtUGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLCB0eXBlIFByb3ZlZWRvciB9IGZyb20gJy4uL3Byb3ZlZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vcGxhbl9kZV9jdWVudGFzL3BsYW5fZGVfY3VlbnRhcy5jb25maWcnO1xuaW1wb3J0IHsgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IHJlc29sdmVJbnZvaWNlU2VyaWVzRm9yVGF4Q2hhbmdlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvaW52b2ljZVNlcmllcyc7XG5cbmV4cG9ydCBjb25zdCBQcm92ZWVkb3JFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgeyBpdGVtOiBwcm92ZWVkb3IsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxQcm92ZWVkb3I+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgW2h5ZHJhdGVkRGF0YSwgc2V0SHlkcmF0ZWREYXRhXSA9IHVzZVN0YXRlPFByb3ZlZWRvciB8IG51bGw+KG51bGwpO1xuXG4gICAgLy8gSGlkcmF0YXIgYWNjb3VudF9uYW1lICh5IGFjY291bnRfaWQpIGN1YW5kbyBsYSBBUEkgc29sbyBkZXZ1ZWx2ZSBhY2NvdW50X2NvZGVcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIXByb3ZlZWRvcikge1xuICAgICAgICAgICAgc2V0SHlkcmF0ZWREYXRhKG51bGwpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNvZGUgPSBwcm92ZWVkb3IuYWNjb3VudF9jb2RlO1xuICAgICAgICBpZiAoIWNvZGUgfHwgKHByb3ZlZWRvci5hY2NvdW50X25hbWUgIT0gbnVsbCAmJiBwcm92ZWVkb3IuYWNjb3VudF9uYW1lICE9PSAnJykpIHtcbiAgICAgICAgICAgIHNldEh5ZHJhdGVkRGF0YShwcm92ZWVkb3IpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICAgICAgc2VhcmNoQnlGaWVsZDx7IGlkOiBudW1iZXI7IGNvZGU6IHN0cmluZzsgbmFtZTogc3RyaW5nIH0+KFxuICAgICAgICAgICAgcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ2NvZGUnLCB2YWx1ZTogY29kZSB9XVxuICAgICAgICApXG4gICAgICAgICAgICAudGhlbigoYWNjb3VudCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjYW5jZWxsZWQgfHwgIWFjY291bnQpIHJldHVybjtcbiAgICAgICAgICAgICAgICBzZXRIeWRyYXRlZERhdGEoe1xuICAgICAgICAgICAgICAgICAgICAuLi5wcm92ZWVkb3IsXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnRfaWQ6IGFjY291bnQuaWQsXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnRfY29kZTogYWNjb3VudC5jb2RlLFxuICAgICAgICAgICAgICAgICAgICBhY2NvdW50X25hbWU6IGFjY291bnQubmFtZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoKSA9PiBzZXRIeWRyYXRlZERhdGEocHJvdmVlZG9yKSk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHsgY2FuY2VsbGVkID0gdHJ1ZTsgfTtcbiAgICB9LCBbcHJvdmVlZG9yXSk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFwcm92ZWVkb3IpIHJldHVybiA8ZGl2PlByb3ZlZWRvciBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IHJhdyA9IGh5ZHJhdGVkRGF0YSA/PyBwcm92ZWVkb3I7XG4gICAgY29uc3QgaW5pdGlhbERhdGE6IFByb3ZlZWRvciA9IHtcbiAgICAgICAgLi4ucmF3LFxuICAgICAgICBwYXltZW50X2NvbmRpdGlvbjogcmF3LnBheW1lbnRfY29uZGl0aW9uICE9IG51bGwgPyBOdW1iZXIocmF3LnBheW1lbnRfY29uZGl0aW9uKSA6IG51bGwsXG4gICAgICAgIHNlcmllOiByZXNvbHZlSW52b2ljZVNlcmllc0ZvclRheENoYW5nZShcbiAgICAgICAgICAgIFN0cmluZyhyYXcubGVnYWN5X3RheF9jb25kaXRpb24gPz8gJycpLFxuICAgICAgICAgICAgcmF3LnNlcmllLFxuICAgICAgICAgICAgeyBpbmNsdWRlTm9UcmlidXRhYmxlOiB0cnVlIH1cbiAgICAgICAgKSB8fCByYXcuc2VyaWUsXG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxQcm92ZWVkb3Jlc0Zvcm1QYWdlXG4gICAgICAgICAgICBtb2RlPVwiZWRpdFwiXG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbERhdGF9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgZXJyb3I9e2Vycm9yfVxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNFZGl0UGFnZS50c3gifQ==