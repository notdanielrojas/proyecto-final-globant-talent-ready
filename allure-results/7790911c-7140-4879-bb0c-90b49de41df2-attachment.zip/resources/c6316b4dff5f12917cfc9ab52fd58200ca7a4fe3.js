import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ProductHistoryClientTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/ProductHistoryClientTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { search } from "/src/services/apiService.ts";
import { formatValue, formatSalesInvoiceNumber } from "/src/utils/formatters.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { FaTags } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { ProductHistoryModal } from "/src/components/common/ProductHistoryModal.tsx";
import { initialHistoryModalState, priceListColumns } from "/src/types/historyModal.ts";
export const ProductHistoryClientTab = ({ entityId, endpoint }) => {
  _s();
  const [historyItems, setHistoryItems] = useState([]);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [historyModalState, setHistoryModalState] = useState(initialHistoryModalState);
  const fetchHistory = useCallback(async (pageUrl) => {
    setLoading(true);
    try {
      let url;
      if (pageUrl) {
        url = pageUrl;
      } else {
        const params = new URLSearchParams();
        const baseUrl = `clients/${entityId}/${endpoint}`;
        url = `${baseUrl}?${params.toString()}`;
      }
      const response = await search(url);
      if ("data" in response && Array.isArray(response.data)) {
        setHistoryItems(response.data);
        setPaginationMeta(response.meta);
      } else if (Array.isArray(response)) {
        setHistoryItems(response);
        setPaginationMeta(null);
      } else {
        console.error("Formato de respuesta inesperado", response);
        setHistoryItems([]);
      }
    } catch (error) {
      toast.error("Error al cargar el historial de productos.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [endpoint, entityId]);
  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);
  const handlePageChange = (url) => {
    fetchHistory(url);
  };
  const handleOpenHistoryModal = (productId, type, productName) => {
    const clientId = entityId;
    if (!productId) {
      toast.warn("El ítem no tiene un producto seleccionado.");
      return;
    }
    if (type === "price") {
      setHistoryModalState({
        isOpen: true,
        title: `Historial de Precios de Venta del Producto: ${productName}`,
        endpoint: "products/sales-history",
        productId,
        clientId,
        columns: priceListColumns
      });
    }
  };
  const handleCloseHistoryModal = () => setHistoryModalState(initialHistoryModalState);
  const columns = [
    { key: "invoice_date", label: "Fecha" },
    { key: "sku", label: "SKU" },
    { key: "product_name", label: "Producto" },
    { key: "quantity", label: "Cant." },
    { key: "base_sales_price", label: "Precio Base" },
    { key: "invoice_number", label: "Factura" },
    // Puedes agregar más columnas si quieres mostrar exchange_rate, profit, etc.
    { key: "profit", label: "% Utilidad" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
      lineNumber: 158,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          columns.map(
            (col) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: `py-3.5 px-3 text-left text-sm font-semibold text-gray-900 ${["quantity", "base_sales_price", "profit"].includes(col.key) ? "text-right" : ""}`, children: col.label }, col.key, false, {
              fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
              lineNumber: 166,
              columnNumber: 17
            }, this)
          ),
          /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "relative py-3.5 px-3", children: /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Acciones" }, void 0, false, {
            fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
            lineNumber: 171,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
            lineNumber: 170,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 164,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 163,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: historyItems.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: columns.length, className: "py-4 text-center text-sm text-gray-500", children: "No hay historial de ventas disponible." }, void 0, false, {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 178,
          columnNumber: 41
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 177,
          columnNumber: 15
        }, this) : historyItems.map(
          (item, index) => (
            // Usamos index como fallback key si no hay ID único natural
            /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6 text-gray-900", children: formatValue(item.invoice_date, "date") }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 186,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.sku }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 189,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-900 font-medium", children: [
                item.product_name,
                item.purchase_order_number && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400", children: [
                  "OC: ",
                  item.purchase_order_number
                ] }, void 0, true, {
                  fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                  lineNumber: 196,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 192,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-900", children: formatValue(item.quantity, "number") }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 199,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-900", children: formatValue(item.base_sales_price, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 202,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: [
                /* @__PURE__ */ jsxDEV(Link, { to: `/facturas-de-venta/${item.invoice_id}`, className: "text-indigo-600 hover:text-indigo-900 hover:underline", children: formatSalesInvoiceNumber(item.series, item.afip_pos, item.invoice_number) }, void 0, false, {
                  fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                  lineNumber: 207,
                  columnNumber: 49
                }, this),
                item.order_number && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400", children: [
                  "Ped: ",
                  item.order_number
                ] }, void 0, true, {
                  fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                  lineNumber: 212,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 205,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${Number(item.profit) > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`, children: formatValue(Number(item.profit), "percentual") }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 216,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 215,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-medium space-x-2", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenHistoryModal(item.product_id, "price", item.product_name), className: "p-2 text-blue-600 hover:text-blue-900", title: "Ver historial de precios", children: /* @__PURE__ */ jsxDEV(FaTags, {}, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 223,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 222,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
                lineNumber: 221,
                columnNumber: 45
              }, this)
            ] }, `${item.invoice_number}-${item.sku}-${index}`, true, {
              fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
              lineNumber: 185,
              columnNumber: 15
            }, this)
          )
        ) }, void 0, false, {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 175,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
        lineNumber: 162,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
        lineNumber: 161,
        columnNumber: 21
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          meta: paginationMeta,
          onPageChange: handlePageChange
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
          lineNumber: 234,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    historyModalState.isOpen && /* @__PURE__ */ jsxDEV(
      ProductHistoryModal,
      {
        isOpen: historyModalState.isOpen,
        onClose: handleCloseHistoryModal,
        title: historyModalState.title,
        endpoint: historyModalState.endpoint,
        productId: historyModalState.productId,
        clientId: historyModalState.clientId,
        columns: historyModalState.columns
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
        lineNumber: 244,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/components/common/ProductHistoryClientTab.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
};
_s(ProductHistoryClientTab, "pmspd4blgtaeqeQxg9M6dgGRCnc=");
_c = ProductHistoryClientTab;
var _c;
$RefreshReg$(_c, "ProductHistoryClientTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/ProductHistoryClientTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/ProductHistoryClientTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMElnQixTQUVBLFVBRkE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBekloQixTQUFTQSxVQUFVQyxXQUFXQyxtQkFBbUI7QUFDakQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsYUFBYUMsZ0NBQWdDO0FBQ3RELFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsMEJBQTBCQyx3QkFBZ0Q7QUFnQzVFLGFBQU1DLDBCQUEwQkEsQ0FBQyxFQUFFQyxVQUFVQyxTQUF1QyxNQUFNO0FBQUFDLEtBQUE7QUFDN0YsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUluQixTQUFxQyxFQUFFO0FBQy9FLFFBQU0sQ0FBQ29CLGdCQUFnQkMsaUJBQWlCLElBQUlyQixTQUFxRSxJQUFJO0FBQ3JILFFBQU0sQ0FBQ3NCLFNBQVNDLFVBQVUsSUFBSXZCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUN3QixtQkFBbUJDLG9CQUFvQixJQUFJekIsU0FBNEJZLHdCQUF3QjtBQU90RyxRQUFNYyxlQUFleEIsWUFBWSxPQUFPeUIsWUFBcUI7QUFDekRKLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxVQUFJSztBQUVKLFVBQUlELFNBQVM7QUFDVEMsY0FBTUQ7QUFBQUEsTUFDVixPQUFPO0FBQ0gsY0FBTUUsU0FBUyxJQUFJQyxnQkFBZ0I7QUFHbkMsY0FBTUMsVUFBVSxXQUFXaEIsUUFBUSxJQUFJQyxRQUFRO0FBQy9DWSxjQUFNLEdBQUdHLE9BQU8sSUFBSUYsT0FBT0csU0FBUyxDQUFDO0FBQUEsTUFDekM7QUFHQSxZQUFNQyxXQUFXLE1BQU01QixPQUFpQ3VCLEdBQUc7QUFHM0QsVUFBSSxVQUFVSyxZQUFZQyxNQUFNQyxRQUFRRixTQUFTRyxJQUFJLEdBQUc7QUFDcERqQix3QkFBZ0JjLFNBQVNHLElBQUk7QUFDN0JmLDBCQUFrQlksU0FBU0ksSUFBSTtBQUFBLE1BQ25DLFdBQVdILE1BQU1DLFFBQVFGLFFBQVEsR0FBRztBQUVoQ2Qsd0JBQWdCYyxRQUFzQztBQUN0RFosMEJBQWtCLElBQUk7QUFBQSxNQUMxQixPQUFPO0FBQ0hpQixnQkFBUUMsTUFBTSxtQ0FBbUNOLFFBQVE7QUFDekRkLHdCQUFnQixFQUFFO0FBQUEsTUFDdEI7QUFBQSxJQUVKLFNBQVNvQixPQUFPO0FBQ1puQyxZQUFNbUMsTUFBTSw0Q0FBNEM7QUFDeERELGNBQVFDLE1BQU1BLEtBQUs7QUFBQSxJQUN2QixVQUFDO0FBQ0doQixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ1AsVUFBVUQsUUFBUSxDQUFDO0FBRXZCZCxZQUFVLE1BQU07QUFDWnlCLGlCQUFhO0FBQUEsRUFDakIsR0FBRyxDQUFDQSxZQUFZLENBQUM7QUFFakIsUUFBTWMsbUJBQW1CQSxDQUFDWixRQUFnQjtBQUN0Q0YsaUJBQWFFLEdBQUc7QUFBQSxFQUNwQjtBQUVBLFFBQU1hLHlCQUF5QkEsQ0FBQ0MsV0FBbUJDLE1BQXdCQyxnQkFBd0I7QUFFL0YsVUFBTUMsV0FBVzlCO0FBR2pCLFFBQUksQ0FBQzJCLFdBQVc7QUFBRXRDLFlBQU0wQyxLQUFLLDRDQUE0QztBQUFHO0FBQUEsSUFBUTtBQUNwRixRQUFJSCxTQUFTLFNBQVM7QUFDbEJsQiwyQkFBcUI7QUFBQSxRQUNqQnNCLFFBQVE7QUFBQSxRQUNSQyxPQUFPLCtDQUErQ0osV0FBVztBQUFBLFFBQ2pFNUIsVUFBVTtBQUFBLFFBQ1YwQjtBQUFBQSxRQUNBRztBQUFBQSxRQUNBSSxTQUFTcEM7QUFBQUEsTUFDYixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFFQSxRQUFNcUMsMEJBQTBCQSxNQUFNekIscUJBQXFCYix3QkFBd0I7QUFHbkYsUUFBTXFDLFVBQVU7QUFBQSxJQUNaLEVBQUVFLEtBQUssZ0JBQWdCQyxPQUFPLFFBQVE7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLE9BQU9DLE9BQU8sTUFBTTtBQUFBLElBQzNCLEVBQUVELEtBQUssZ0JBQWdCQyxPQUFPLFdBQVc7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFlBQVlDLE9BQU8sUUFBUTtBQUFBLElBQ2xDLEVBQUVELEtBQUssb0JBQW9CQyxPQUFPLGNBQWM7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLGtCQUFrQkMsT0FBTyxVQUFVO0FBQUE7QUFBQSxJQUUxQyxFQUFFRCxLQUFLLFVBQVVDLE9BQU8sYUFBYTtBQUFBLEVBQUM7QUFHMUMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsUUFHVjlCO0FBQUFBLGNBQ0csdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLElBRWYsbUNBQ0k7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDSTJCO0FBQUFBLGtCQUFRSTtBQUFBQSxZQUFJLENBQUFDLFFBQ1QsdUJBQUMsUUFBaUIsT0FBTSxPQUFNLFdBQVcsNkRBQTZELENBQUMsWUFBWSxvQkFBb0IsUUFBUSxFQUFFQyxTQUFTRCxJQUFJSCxHQUFHLElBQUksZUFBZSxFQUFFLElBQ2pMRyxjQUFJRixTQURBRSxJQUFJSCxLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNIO0FBQUEsVUFDRCx1QkFBQyxRQUFHLE9BQU0sT0FBTSxXQUFVLHdCQUN0QixpQ0FBQyxVQUFLLFdBQVUsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pqQyx1QkFBYXNDLFdBQVcsSUFDckIsdUJBQUMsUUFDRyxpQ0FBQyxRQUFHLFNBQVNQLFFBQVFPLFFBQVEsV0FBVSwwQ0FBd0Msc0RBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxJQUVBdEMsYUFBYW1DO0FBQUFBLFVBQUksQ0FBQ0ksTUFBTUM7QUFBQUE7QUFBQUEsWUFFcEIsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSw0REFDVHBELHNCQUFZbUQsS0FBS0UsY0FBYyxNQUFNLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDVEYsZUFBS0csT0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsK0NBQ1RIO0FBQUFBLHFCQUFLSTtBQUFBQSxnQkFFTEosS0FBS0sseUJBQ0YsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsa0JBQUtMLEtBQUtLO0FBQUFBLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLG1CQUovRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsOENBQ1R4RCxzQkFBWW1ELEtBQUtNLFVBQVUsUUFBUSxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsOENBQ1R6RCxzQkFBWW1ELEtBQUtPLGtCQUFrQixVQUFVLEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FFVjtBQUFBLHVDQUFDLFFBQUssSUFBSSxzQkFBc0JQLEtBQUtRLFVBQVUsSUFBSSxXQUFVLHlEQUN4RDFELG1DQUF5QmtELEtBQUtTLFFBQVFULEtBQUtVLFVBQVVWLEtBQUtXLGNBQWMsS0FEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVDWCxLQUFLWSxnQkFDRix1QkFBQyxTQUFJLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxrQkFBTVosS0FBS1k7QUFBQUEscUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBUHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxnQ0FDVixpQ0FBQyxVQUFLLFdBQVcsb0VBQW9FQyxPQUFPYixLQUFLYyxNQUFNLElBQUksSUFBSSxnQ0FBZ0MseUJBQXlCLElBRW5LakUsc0JBQVlnRSxPQUFPYixLQUFLYyxNQUFNLEdBQUcsWUFBWSxLQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDZEQUNWLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTlCLHVCQUF1QmdCLEtBQUtlLFlBQVksU0FBU2YsS0FBS0ksWUFBWSxHQUFHLFdBQVUseUNBQXdDLE9BQU0sNEJBQzlKLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTyxLQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBeENLLEdBQUdKLEtBQUtXLGNBQWMsSUFBSVgsS0FBS0csR0FBRyxJQUFJRixLQUFLLElBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUNBO0FBQUE7QUFBQSxRQUNILEtBcERUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzREE7QUFBQSxXQW5FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0VBLEtBckVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzRUE7QUFBQSxNQUVDdEMsa0JBQ0c7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQU1BO0FBQUFBLFVBQ04sY0FBY29CO0FBQUFBO0FBQUFBLFFBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQztBQUFBLFNBNUUzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0VBO0FBQUEsSUFJSGhCLGtCQUFrQnVCLFVBQ2Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVF2QixrQkFBa0J1QjtBQUFBQSxRQUMxQixTQUFTRztBQUFBQSxRQUNULE9BQU8xQixrQkFBa0J3QjtBQUFBQSxRQUN6QixVQUFVeEIsa0JBQWtCUjtBQUFBQSxRQUM1QixXQUFXUSxrQkFBa0JrQjtBQUFBQSxRQUM3QixVQUFVbEIsa0JBQWtCcUI7QUFBQUEsUUFDNUIsU0FBU3JCLGtCQUFrQnlCO0FBQUFBO0FBQUFBLE1BUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU91QztBQUFBLE9BakcvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0dBO0FBRVI7QUFBRWhDLEdBak1XSCx5QkFBdUI7QUFBQTJELEtBQXZCM0Q7QUFBdUIsSUFBQTJEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwiTGluayIsInRvYXN0Iiwic2VhcmNoIiwiZm9ybWF0VmFsdWUiLCJmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIiLCJMb2FkaW5nU3Bpbm5lciIsIlBhZ2luYXRpb24iLCJGYVRhZ3MiLCJQcm9kdWN0SGlzdG9yeU1vZGFsIiwiaW5pdGlhbEhpc3RvcnlNb2RhbFN0YXRlIiwicHJpY2VMaXN0Q29sdW1ucyIsIlByb2R1Y3RIaXN0b3J5Q2xpZW50VGFiIiwiZW50aXR5SWQiLCJlbmRwb2ludCIsIl9zIiwiaGlzdG9yeUl0ZW1zIiwic2V0SGlzdG9yeUl0ZW1zIiwicGFnaW5hdGlvbk1ldGEiLCJzZXRQYWdpbmF0aW9uTWV0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaGlzdG9yeU1vZGFsU3RhdGUiLCJzZXRIaXN0b3J5TW9kYWxTdGF0ZSIsImZldGNoSGlzdG9yeSIsInBhZ2VVcmwiLCJ1cmwiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJiYXNlVXJsIiwidG9TdHJpbmciLCJyZXNwb25zZSIsIkFycmF5IiwiaXNBcnJheSIsImRhdGEiLCJtZXRhIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZU9wZW5IaXN0b3J5TW9kYWwiLCJwcm9kdWN0SWQiLCJ0eXBlIiwicHJvZHVjdE5hbWUiLCJjbGllbnRJZCIsIndhcm4iLCJpc09wZW4iLCJ0aXRsZSIsImNvbHVtbnMiLCJoYW5kbGVDbG9zZUhpc3RvcnlNb2RhbCIsImtleSIsImxhYmVsIiwibWFwIiwiY29sIiwiaW5jbHVkZXMiLCJsZW5ndGgiLCJpdGVtIiwiaW5kZXgiLCJpbnZvaWNlX2RhdGUiLCJza3UiLCJwcm9kdWN0X25hbWUiLCJwdXJjaGFzZV9vcmRlcl9udW1iZXIiLCJxdWFudGl0eSIsImJhc2Vfc2FsZXNfcHJpY2UiLCJpbnZvaWNlX2lkIiwic2VyaWVzIiwiYWZpcF9wb3MiLCJpbnZvaWNlX251bWJlciIsIm9yZGVyX251bWJlciIsIk51bWJlciIsInByb2ZpdCIsInByb2R1Y3RfaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9kdWN0SGlzdG9yeUNsaWVudFRhYi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IHNlYXJjaCB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHR5cGUgeyBQYWdpbmF0ZWRSZXNwb25zZSB9IGZyb20gJy4uLy4uL2ludGVyZmFjZXMvQXBpJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlLCBmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgUGFnaW5hdGlvbiB9IGZyb20gJy4vUGFnaW5hdGlvbic7XG5pbXBvcnQgeyBGYVRhZ3MgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyBQcm9kdWN0SGlzdG9yeU1vZGFsIH0gZnJvbSAnLi9Qcm9kdWN0SGlzdG9yeU1vZGFsJztcbmltcG9ydCB7IGluaXRpYWxIaXN0b3J5TW9kYWxTdGF0ZSwgcHJpY2VMaXN0Q29sdW1ucywgdHlwZSBIaXN0b3J5TW9kYWxTdGF0ZSB9IGZyb20gJy4uLy4uL3R5cGVzL2hpc3RvcnlNb2RhbCc7XG4vLyBpbXBvcnQgeyBGYUZpbHRlciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJzsgLy8gU2kgZGVjaWRlcyBhZ3JlZ2FyIGZpbHRyb3MgZGUgZmVjaGEgZGVzcHXDqXNcblxuLy8gLS0tIFRJUE9TIC0tLVxuXG4vLyBJbnRlcmZheiBiYXNhZGEgZW4gZWwgSlNPTiBxdWUgbWUgcGFzYXN0ZVxuZXhwb3J0IGludGVyZmFjZSBDbGllbnRQcm9kdWN0SGlzdG9yeUl0ZW0ge1xuICAgIHNrdTogc3RyaW5nO1xuICAgIHByb2R1Y3RfaWQ6IG51bWJlcjtcbiAgICBwcm9kdWN0X25hbWU6IHN0cmluZztcbiAgICBpbnZvaWNlX2RhdGU6IHN0cmluZztcbiAgICBpbnZvaWNlX2lkOiBudW1iZXI7XG4gICAgaW52b2ljZV9udW1iZXI6IHN0cmluZztcbiAgICBzZXJpZXM/OiBzdHJpbmcgfCBudWxsO1xuICAgIGFmaXBfcG9zPzogc3RyaW5nIHwgbnVtYmVyIHwgbnVsbDtcbiAgICBiYXNlX3NhbGVzX3ByaWNlOiBzdHJpbmcgfCBudW1iZXI7IC8vIFB1ZWRlIHZlbmlyIGNvbW8gc3RyaW5nIGRlIGxhIEFQSVxuICAgIGNvc3RfcHJpY2U6IHN0cmluZyB8IG51bWJlcjtcbiAgICBxdWFudGl0eTogc3RyaW5nIHwgbnVtYmVyO1xuICAgIGV4Y2hhbmdlX3JhdGU6IHN0cmluZyB8IG51bWJlcjtcbiAgICBhbHRlcm5hdGl2ZV9wcmljZTogc3RyaW5nIHwgbnVtYmVyO1xuICAgIHB1cmNoYXNlX29yZGVyX251bWJlcjogc3RyaW5nO1xuICAgIG9yZGVyX251bWJlcjogbnVtYmVyO1xuICAgIHByb2ZpdDogc3RyaW5nIHwgbnVtYmVyO1xuICAgIGlkPzogbnVtYmVyOyAvLyBPcGNpb25hbCwgcG9yIHNpIGFjYXNvIGxvIG5lY2VzaXRhbW9zIHBhcmEga2V5cyDDum5pY2FzIHNpIG5vIHVzYW1vcyBza3UraW52b2ljZVxufVxuXG4vLyBJbnRlcmZheiBwYXJhIGxhcyBwcm9wcyBkZWwgY29tcG9uZW50ZVxuaW50ZXJmYWNlIFByb2R1Y3RIaXN0b3J5Q2xpZW50VGFiUHJvcHMge1xuICAgIGVudGl0eUlkOiBzdHJpbmcgfCBudW1iZXI7XG4gICAgZW5kcG9pbnQ6IHN0cmluZzsgLy8gRWo6ICdsYXRlc3QtcHJvZHVjdHMnXG59XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0SGlzdG9yeUNsaWVudFRhYiA9ICh7IGVudGl0eUlkLCBlbmRwb2ludCB9OiBQcm9kdWN0SGlzdG9yeUNsaWVudFRhYlByb3BzKSA9PiB7XG4gICAgY29uc3QgW2hpc3RvcnlJdGVtcywgc2V0SGlzdG9yeUl0ZW1zXSA9IHVzZVN0YXRlPENsaWVudFByb2R1Y3RIaXN0b3J5SXRlbVtdPihbXSk7XG4gICAgY29uc3QgW3BhZ2luYXRpb25NZXRhLCBzZXRQYWdpbmF0aW9uTWV0YV0gPSB1c2VTdGF0ZTxQYWdpbmF0ZWRSZXNwb25zZTxDbGllbnRQcm9kdWN0SGlzdG9yeUl0ZW0+WydtZXRhJ10gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2hpc3RvcnlNb2RhbFN0YXRlLCBzZXRIaXN0b3J5TW9kYWxTdGF0ZV0gPSB1c2VTdGF0ZTxIaXN0b3J5TW9kYWxTdGF0ZT4oaW5pdGlhbEhpc3RvcnlNb2RhbFN0YXRlKTtcblxuICAgIC8vIFNpIG5lY2VzaXRhcyBmaWx0cm9zIGRlIGZlY2hhLCBkZXNjb21lbnRhIGVzdG8geSBhZ3LDqWdhbG9zIGFsIGZldGNoXG4gICAgLy8gY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICAvLyBjb25zdCBvbmVNb250aEFnbyA9IG5ldyBEYXRlKERhdGUubm93KCkgLSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICAvLyBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUoeyBmcm9tOiBvbmVNb250aEFnbywgdG86IHRvZGF5IH0pO1xuXG4gICAgY29uc3QgZmV0Y2hIaXN0b3J5ID0gdXNlQ2FsbGJhY2soYXN5bmMgKHBhZ2VVcmw/OiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCB1cmw6IHN0cmluZztcblxuICAgICAgICAgICAgaWYgKHBhZ2VVcmwpIHtcbiAgICAgICAgICAgICAgICB1cmwgPSBwYWdlVXJsO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XG4gICAgICAgICAgICAgICAgLy8gcGFyYW1zLnNldCgnc3RhcnRfZGF0ZScsIGRhdGVSYW5nZS5mcm9tKTsgLy8gU2kgdXNhcyBmaWx0cm9zXG4gICAgICAgICAgICAgICAgLy8gcGFyYW1zLnNldCgnZW5kX2RhdGUnLCBkYXRlUmFuZ2UudG8pOyAgICAgLy8gU2kgdXNhcyBmaWx0cm9zXG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZVVybCA9IGBjbGllbnRzLyR7ZW50aXR5SWR9LyR7ZW5kcG9pbnR9YDtcbiAgICAgICAgICAgICAgICB1cmwgPSBgJHtiYXNlVXJsfT8ke3BhcmFtcy50b1N0cmluZygpfWA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIEFzdW1pbW9zIHF1ZSBsYSByZXNwdWVzdGEgZXMgcGFnaW5hZGEgZXN0w6FuZGFyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHNlYXJjaDxDbGllbnRQcm9kdWN0SGlzdG9yeUl0ZW0+KHVybCk7XG5cbiAgICAgICAgICAgIC8vIFZlcmlmaWNhbW9zIHNpIHJlc3BvbnNlIHRpZW5lICdkYXRhJyAocGFnaW5hZG8pIG8gZXMgdW4gYXJyYXkgZGlyZWN0b1xuICAgICAgICAgICAgaWYgKCdkYXRhJyBpbiByZXNwb25zZSAmJiBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEpKSB7XG4gICAgICAgICAgICAgICAgc2V0SGlzdG9yeUl0ZW1zKHJlc3BvbnNlLmRhdGEpO1xuICAgICAgICAgICAgICAgIHNldFBhZ2luYXRpb25NZXRhKHJlc3BvbnNlLm1ldGEpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHJlc3BvbnNlKSkge1xuICAgICAgICAgICAgICAgIC8vIEZhbGxiYWNrIHBvciBzaSBsYSBBUEkgZGV2dWVsdmUgZWwgYXJyYXkgZGlyZWN0byBzaW4gcGFnaW5hY2nDs25cbiAgICAgICAgICAgICAgICBzZXRIaXN0b3J5SXRlbXMocmVzcG9uc2UgYXMgQ2xpZW50UHJvZHVjdEhpc3RvcnlJdGVtW10pO1xuICAgICAgICAgICAgICAgIHNldFBhZ2luYXRpb25NZXRhKG51bGwpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRm9ybWF0byBkZSByZXNwdWVzdGEgaW5lc3BlcmFkb1wiLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgc2V0SGlzdG9yeUl0ZW1zKFtdKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBlbCBoaXN0b3JpYWwgZGUgcHJvZHVjdG9zLicpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH0sIFtlbmRwb2ludCwgZW50aXR5SWRdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGZldGNoSGlzdG9yeSgpO1xuICAgIH0sIFtmZXRjaEhpc3RvcnldKTtcblxuICAgIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgZmV0Y2hIaXN0b3J5KHVybCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZU9wZW5IaXN0b3J5TW9kYWwgPSAocHJvZHVjdElkOiBudW1iZXIsIHR5cGU6ICdwcmljZScgfCAnY29zdCcsIHByb2R1Y3ROYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgLy8gRW4gZXN0ZSBjb21wb25lbnRlLCBlbnRpdHlJZCBFUyBlbCBjbGllbnRJZFxuICAgICAgICBjb25zdCBjbGllbnRJZCA9IGVudGl0eUlkIGFzIG51bWJlcjtcblxuICAgICAgICAvLyBBYnJpbW9zIHNvbG8gZWwgaGlzdG9yaWFsIGRlIHByZWNpb3MgKFZlbnRhKVxuICAgICAgICBpZiAoIXByb2R1Y3RJZCkgeyB0b2FzdC53YXJuKCdFbCDDrXRlbSBubyB0aWVuZSB1biBwcm9kdWN0byBzZWxlY2Npb25hZG8uJyk7IHJldHVybjsgfVxuICAgICAgICBpZiAodHlwZSA9PT0gJ3ByaWNlJykge1xuICAgICAgICAgICAgc2V0SGlzdG9yeU1vZGFsU3RhdGUoe1xuICAgICAgICAgICAgICAgIGlzT3BlbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB0aXRsZTogYEhpc3RvcmlhbCBkZSBQcmVjaW9zIGRlIFZlbnRhIGRlbCBQcm9kdWN0bzogJHtwcm9kdWN0TmFtZX1gLFxuICAgICAgICAgICAgICAgIGVuZHBvaW50OiAncHJvZHVjdHMvc2FsZXMtaGlzdG9yeScsXG4gICAgICAgICAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0SWQsXG4gICAgICAgICAgICAgICAgY2xpZW50SWQ6IGNsaWVudElkLFxuICAgICAgICAgICAgICAgIGNvbHVtbnM6IHByaWNlTGlzdENvbHVtbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDbG9zZUhpc3RvcnlNb2RhbCA9ICgpID0+IHNldEhpc3RvcnlNb2RhbFN0YXRlKGluaXRpYWxIaXN0b3J5TW9kYWxTdGF0ZSk7XG5cbiAgICAvLyBDb2x1bW5hcyBhIG1vc3RyYXJcbiAgICBjb25zdCBjb2x1bW5zID0gW1xuICAgICAgICB7IGtleTogJ2ludm9pY2VfZGF0ZScsIGxhYmVsOiAnRmVjaGEnIH0sXG4gICAgICAgIHsga2V5OiAnc2t1JywgbGFiZWw6ICdTS1UnIH0sXG4gICAgICAgIHsga2V5OiAncHJvZHVjdF9uYW1lJywgbGFiZWw6ICdQcm9kdWN0bycgfSxcbiAgICAgICAgeyBrZXk6ICdxdWFudGl0eScsIGxhYmVsOiAnQ2FudC4nIH0sXG4gICAgICAgIHsga2V5OiAnYmFzZV9zYWxlc19wcmljZScsIGxhYmVsOiAnUHJlY2lvIEJhc2UnIH0sXG4gICAgICAgIHsga2V5OiAnaW52b2ljZV9udW1iZXInLCBsYWJlbDogJ0ZhY3R1cmEnIH0sXG4gICAgICAgIC8vIFB1ZWRlcyBhZ3JlZ2FyIG3DoXMgY29sdW1uYXMgc2kgcXVpZXJlcyBtb3N0cmFyIGV4Y2hhbmdlX3JhdGUsIHByb2ZpdCwgZXRjLlxuICAgICAgICB7IGtleTogJ3Byb2ZpdCcsIGxhYmVsOiAnJSBVdGlsaWRhZCcgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02XCI+XG4gICAgICAgICAgICB7LyogQXF1w60gaXLDrWEgZWwgZm9ybXVsYXJpbyBkZSBmaWx0cm9zIHNpIGRlY2lkZXMgYWdyZWdhcmxvICovfVxuXG4gICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2x1bW5zLm1hcChjb2wgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBrZXk9e2NvbC5rZXl9IHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPXtgcHktMy41IHB4LTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwICR7WydxdWFudGl0eScsICdiYXNlX3NhbGVzX3ByaWNlJywgJ3Byb2ZpdCddLmluY2x1ZGVzKGNvbC5rZXkpID8gJ3RleHQtcmlnaHQnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2wubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHktMy41IHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+QWNjaW9uZXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aGlzdG9yeUl0ZW1zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Y29sdW1ucy5sZW5ndGh9IGNsYXNzTmFtZT1cInB5LTQgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGhheSBoaXN0b3JpYWwgZGUgdmVudGFzIGRpc3BvbmlibGUuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoaXN0b3J5SXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVzYW1vcyBpbmRleCBjb21vIGZhbGxiYWNrIGtleSBzaSBubyBoYXkgSUQgw7puaWNvIG5hdHVyYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtgJHtpdGVtLmludm9pY2VfbnVtYmVyfS0ke2l0ZW0uc2t1fS0ke2luZGV4fWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02IHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtLmludm9pY2VfZGF0ZSwgJ2RhdGUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnNrdX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2R1Y3RfbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNb3N0cmFyIE5ybyBPcmRlbiBDb21wcmEgc2kgZXhpc3RlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHVyY2hhc2Vfb3JkZXJfbnVtYmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPk9DOiB7aXRlbS5wdXJjaGFzZV9vcmRlcl9udW1iZXJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoaXRlbS5xdWFudGl0eSwgJ251bWJlcicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoaXRlbS5iYXNlX3NhbGVzX3ByaWNlLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaW5rIGEgbGEgZmFjdHVyYSBzaSB0aWVuZXMgbGEgcnV0YSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2ZhY3R1cmFzLWRlLXZlbnRhLyR7aXRlbS5pbnZvaWNlX2lkfWB9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby05MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFNhbGVzSW52b2ljZU51bWJlcihpdGVtLnNlcmllcywgaXRlbS5hZmlwX3BvcywgaXRlbS5pbnZvaWNlX251bWJlcil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTW9zdHJhciBQZWRpZG8gc2kgZXhpc3RlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ub3JkZXJfbnVtYmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlBlZDoge2l0ZW0ub3JkZXJfbnVtYmVyfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQteHMgZm9udC1tZWRpdW0gJHtOdW1iZXIoaXRlbS5wcm9maXQpID4gMCA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoTnVtYmVyKGl0ZW0ucHJvZml0KSwgJ3BlcmNlbnR1YWwnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNwYWNlLXgtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbkhpc3RvcnlNb2RhbChpdGVtLnByb2R1Y3RfaWQsICdwcmljZScsIGl0ZW0ucHJvZHVjdF9uYW1lKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTkwMFwiIHRpdGxlPVwiVmVyIGhpc3RvcmlhbCBkZSBwcmVjaW9zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhVGFncyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0aW9uTWV0YSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnaW5hdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGE9e3BhZ2luYXRpb25NZXRhfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Lyog4pyFIFJFTkRFUklaQVIgTU9EQUwgREUgSElTVE9SSUFMIChEVVBMSUNBRE8pICovfVxuICAgICAgICAgICAge2hpc3RvcnlNb2RhbFN0YXRlLmlzT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPFByb2R1Y3RIaXN0b3J5TW9kYWxcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXtoaXN0b3J5TW9kYWxTdGF0ZS5pc09wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlSGlzdG9yeU1vZGFsfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17aGlzdG9yeU1vZGFsU3RhdGUudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIGVuZHBvaW50PXtoaXN0b3J5TW9kYWxTdGF0ZS5lbmRwb2ludH1cbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdElkPXtoaXN0b3J5TW9kYWxTdGF0ZS5wcm9kdWN0SWQhfVxuICAgICAgICAgICAgICAgICAgICBjbGllbnRJZD17aGlzdG9yeU1vZGFsU3RhdGUuY2xpZW50SWQhfVxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtoaXN0b3J5TW9kYWxTdGF0ZS5jb2x1bW5zfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL1Byb2R1Y3RIaXN0b3J5Q2xpZW50VGFiLnRzeCJ9