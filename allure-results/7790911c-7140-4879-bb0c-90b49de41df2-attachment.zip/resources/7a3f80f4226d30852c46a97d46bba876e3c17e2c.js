import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/context/AuthContext.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {} from "/src/features/usuarios/usuarios.config.tsx";
import * as apiService from "/src/services/apiService.ts";
export const AuthContext = createContext(void 0);
export const AuthProvider = ({ children }) => {
  _s();
  const [user, setUser] = useState(null);
  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem("authToken");
      if (token) {
        try {
          const storedUser = localStorage.getItem("authUser");
          const storedPermissions = localStorage.getItem("authPermissions");
          if (storedUser) {
            const parsedUser = JSON.parse(storedUser);
            setUser(parsedUser);
            setPermissions(JSON.parse(storedPermissions || "[]"));
          }
        } catch (error) {
          localStorage.removeItem("authToken");
          localStorage.removeItem("authUser");
          localStorage.removeItem("authPermissions");
        }
      }
      setLoading(false);
    };
    checkAuth();
  }, []);
  const login = async (credentials) => {
    const response = await apiService.login(credentials);
    const { access_token, user: loggedInUser, permissions: userPermissions } = response;
    const finalPermissions = userPermissions || loggedInUser.permissions || (loggedInUser.roles && loggedInUser.roles.length > 0 ? loggedInUser.roles.flatMap((role) => role.permissions || []) : []);
    localStorage.setItem("authToken", access_token);
    localStorage.setItem("authUser", JSON.stringify(loggedInUser));
    localStorage.setItem("authPermissions", JSON.stringify(finalPermissions));
    setUser(loggedInUser);
    setPermissions(finalPermissions);
  };
  const logout = async () => {
    try {
      await apiService.logout();
    } catch (error) {
      console.error("Error en el logout de la API, cerrando sesión localmente.", error);
    } finally {
      localStorage.removeItem("authToken");
      localStorage.removeItem("authUser");
      localStorage.removeItem("authPermissions");
      setUser(null);
      setPermissions([]);
    }
  };
  const hasPermission = (permission) => {
    return permissions.includes(permission);
  };
  const authContextValue = useMemo(() => ({
    isAuthenticated: !!user,
    user,
    permissions,
    // ✅ Incluir permisos en el contexto
    login,
    logout,
    hasPermission
    // ✅ Incluir helper
  }), [user, permissions]);
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { children: "Cargando aplicación..." }, void 0, false, {
      fileName: "/app/src/context/AuthContext.tsx",
      lineNumber: 120,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: authContextValue, children }, void 0, false, {
    fileName: "/app/src/context/AuthContext.tsx",
    lineNumber: 124,
    columnNumber: 5
  }, this);
};
_s(AuthProvider, "G2JTV6io7hBL+ucDDFTSXYjry8k=");
_c = AuthProvider;
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/context/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/context/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0dlOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5HZixTQUFTQSxlQUFlQyxVQUFVQyxXQUFXQyxlQUErQjtBQUM1RSxlQUE2QjtBQUM3QixZQUFZQyxnQkFBZ0I7QUFXckIsYUFBTUMsY0FBY0wsY0FBMkNNLE1BQVM7QUFFeEUsYUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxTQUFrQyxNQUFNO0FBQUFDLEtBQUE7QUFDbkUsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlWLFNBQXlCLElBQUk7QUFDckQsUUFBTSxDQUFDVyxhQUFhQyxjQUFjLElBQUlaLFNBQW1CLEVBQUU7QUFDM0QsUUFBTSxDQUFDYSxTQUFTQyxVQUFVLElBQUlkLFNBQVMsSUFBSTtBQUczQ0MsWUFBVSxNQUFNO0FBQ1osVUFBTWMsWUFBWSxZQUFZO0FBQzFCLFlBQU1DLFFBQVFDLGFBQWFDLFFBQVEsV0FBVztBQUM5QyxVQUFJRixPQUFPO0FBQ1AsWUFBSTtBQUdBLGdCQUFNRyxhQUFhRixhQUFhQyxRQUFRLFVBQVU7QUFDbEQsZ0JBQU1FLG9CQUFvQkgsYUFBYUMsUUFBUSxpQkFBaUI7QUFDaEUsY0FBSUMsWUFBWTtBQUNaLGtCQUFNRSxhQUFhQyxLQUFLQyxNQUFNSixVQUFVO0FBQ3hDVCxvQkFBUVcsVUFBVTtBQUNsQlQsMkJBQWVVLEtBQUtDLE1BQU1ILHFCQUFxQixJQUFJLENBQUM7QUFBQSxVQUN4RDtBQUFBLFFBQ0osU0FBU0ksT0FBTztBQUVaUCx1QkFBYVEsV0FBVyxXQUFXO0FBQ25DUix1QkFBYVEsV0FBVyxVQUFVO0FBQ2xDUix1QkFBYVEsV0FBVyxpQkFBaUI7QUFBQSxRQUM3QztBQUFBLE1BQ0o7QUFDQVgsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQ0FDLGNBQVU7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMLFFBQU1XLFFBQVEsT0FBT0MsZ0JBQXFCO0FBQ3RDLFVBQU1DLFdBQVcsTUFBTXpCLFdBQVd1QixNQUFNQyxXQUFXO0FBQ25ELFVBQU0sRUFBRUUsY0FBY3BCLE1BQU1xQixjQUFjbkIsYUFBYW9CLGdCQUFnQixJQUFJSDtBQUczRSxVQUFNSSxtQkFBbUJELG1CQUNyQkQsYUFBYW5CLGdCQUNabUIsYUFBYUcsU0FBU0gsYUFBYUcsTUFBTUMsU0FBUyxJQUM3Q0osYUFBYUcsTUFBTUUsUUFBUSxDQUFDQyxTQUFjQSxLQUFLekIsZUFBZSxFQUFFLElBQ2hFO0FBR1ZNLGlCQUFhb0IsUUFBUSxhQUFhUixZQUFZO0FBQzlDWixpQkFBYW9CLFFBQVEsWUFBWWYsS0FBS2dCLFVBQVVSLFlBQVksQ0FBQztBQUM3RGIsaUJBQWFvQixRQUFRLG1CQUFtQmYsS0FBS2dCLFVBQVVOLGdCQUFnQixDQUFDO0FBR3hFdEIsWUFBUW9CLFlBQVk7QUFDcEJsQixtQkFBZW9CLGdCQUFnQjtBQUFBLEVBQ25DO0FBRUEsUUFBTU8sU0FBUyxZQUFZO0FBQ3ZCLFFBQUk7QUFDQSxZQUFNcEMsV0FBV29DLE9BQU87QUFBQSxJQUM1QixTQUFTZixPQUFPO0FBQ1pnQixjQUFRaEIsTUFBTSw2REFBNkRBLEtBQUs7QUFBQSxJQUNwRixVQUFDO0FBRUdQLG1CQUFhUSxXQUFXLFdBQVc7QUFDbkNSLG1CQUFhUSxXQUFXLFVBQVU7QUFDbENSLG1CQUFhUSxXQUFXLGlCQUFpQjtBQUN6Q2YsY0FBUSxJQUFJO0FBQ1pFLHFCQUFlLEVBQUU7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFHQSxRQUFNNkIsZ0JBQWdCQSxDQUFDQyxlQUFnQztBQUNuRCxXQUFPL0IsWUFBWWdDLFNBQVNELFVBQVU7QUFBQSxFQUMxQztBQUVBLFFBQU1FLG1CQUFtQjFDLFFBQVEsT0FBTztBQUFBLElBQ3BDMkMsaUJBQWlCLENBQUMsQ0FBQ3BDO0FBQUFBLElBQ25CQTtBQUFBQSxJQUNBRTtBQUFBQTtBQUFBQSxJQUNBZTtBQUFBQSxJQUNBYTtBQUFBQSxJQUNBRTtBQUFBQTtBQUFBQSxFQUNKLElBQUksQ0FBQ2hDLE1BQU1FLFdBQVcsQ0FBQztBQUd2QixNQUFJRSxTQUFTO0FBQ1QsV0FBTyx1QkFBQyxTQUFJLHNDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxFQUN0QztBQUVBLFNBQ0ksdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU8rQixrQkFDeEJyQyxZQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVSO0FBQUVDLEdBNUZXRixjQUFZO0FBQUF3QyxLQUFaeEM7QUFBWSxJQUFBd0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJhcGlTZXJ2aWNlIiwiQXV0aENvbnRleHQiLCJ1bmRlZmluZWQiLCJBdXRoUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zIiwidXNlciIsInNldFVzZXIiLCJwZXJtaXNzaW9ucyIsInNldFBlcm1pc3Npb25zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJjaGVja0F1dGgiLCJ0b2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzdG9yZWRVc2VyIiwic3RvcmVkUGVybWlzc2lvbnMiLCJwYXJzZWRVc2VyIiwiSlNPTiIsInBhcnNlIiwiZXJyb3IiLCJyZW1vdmVJdGVtIiwibG9naW4iLCJjcmVkZW50aWFscyIsInJlc3BvbnNlIiwiYWNjZXNzX3Rva2VuIiwibG9nZ2VkSW5Vc2VyIiwidXNlclBlcm1pc3Npb25zIiwiZmluYWxQZXJtaXNzaW9ucyIsInJvbGVzIiwibGVuZ3RoIiwiZmxhdE1hcCIsInJvbGUiLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwibG9nb3V0IiwiY29uc29sZSIsImhhc1Blcm1pc3Npb24iLCJwZXJtaXNzaW9uIiwiaW5jbHVkZXMiLCJhdXRoQ29udGV4dFZhbHVlIiwiaXNBdXRoZW50aWNhdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aENvbnRleHQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9jb250ZXh0L0F1dGhDb250ZXh0LnRzeFxuaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdHlwZSBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB0eXBlIFVzdWFyaW8gfSBmcm9tICcuLi9mZWF0dXJlcy91c3Vhcmlvcy91c3Vhcmlvcy5jb25maWcnO1xuaW1wb3J0ICogYXMgYXBpU2VydmljZSBmcm9tICcuLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcblxuaW50ZXJmYWNlIEF1dGhDb250ZXh0VHlwZSB7XG4gICAgaXNBdXRoZW50aWNhdGVkOiBib29sZWFuO1xuICAgIHVzZXI6IFVzdWFyaW8gfCBudWxsO1xuICAgIHBlcm1pc3Npb25zOiBzdHJpbmdbXTsgLy8g4pyFIFBlcm1pc29zIGRlbCB1c3VhcmlvXG4gICAgbG9naW46IChjcmVkZW50aWFsczogYW55KSA9PiBQcm9taXNlPHZvaWQ+OyAvLyBBaG9yYSBlcyB1bmEgcHJvbWVzYVxuICAgIGxvZ291dDogKCkgPT4gdm9pZDtcbiAgICBoYXNQZXJtaXNzaW9uOiAocGVybWlzc2lvbjogc3RyaW5nKSA9PiBib29sZWFuOyAvLyDinIUgSGVscGVyIHBhcmEgdmFsaWRhciBwZXJtaXNvc1xufVxuXG5leHBvcnQgY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuZXhwb3J0IGNvbnN0IEF1dGhQcm92aWRlciA9ICh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSA9PiB7XG4gICAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGU8VXN1YXJpbyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtwZXJtaXNzaW9ucywgc2V0UGVybWlzc2lvbnNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTsgLy8g4pyFIEVzdGFkbyBwYXJhIHBlcm1pc29zXG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7IC8vIEVzdGFkbyBwYXJhIGxhIGNhcmdhIGluaWNpYWxcblxuICAgIC8vIEVmZWN0byBwYXJhIHZlcmlmaWNhciBsYSBzZXNpw7NuIGFsIGNhcmdhciBsYSBhcHBcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBjaGVja0F1dGggPSBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0b2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhdXRoVG9rZW4nKTtcbiAgICAgICAgICAgIGlmICh0b2tlbikge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFNpIGhheSB1biB0b2tlbiwgcG9kcsOtYW1vcyB2YWxpZGFyIGNvbnRyYSB1biBlbmRwb2ludCAvbWUgZW4gZWwgZnV0dXJvLlxuICAgICAgICAgICAgICAgICAgICAvLyBQb3IgYWhvcmEsIGFzdW1pbW9zIHF1ZSBlbCB0b2tlbiBlcyB2w6FsaWRvIHkgcmVjdXBlcmFtb3MgZWwgdXN1YXJpbyBkZSBsb2NhbFN0b3JhZ2UuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0b3JlZFVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYXV0aFVzZXInKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RvcmVkUGVybWlzc2lvbnMgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYXV0aFBlcm1pc3Npb25zJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdG9yZWRVc2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWRVc2VyID0gSlNPTi5wYXJzZShzdG9yZWRVc2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFVzZXIocGFyc2VkVXNlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQZXJtaXNzaW9ucyhKU09OLnBhcnNlKHN0b3JlZFBlcm1pc3Npb25zIHx8ICdbXScpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFNpIGVsIHRva2VuIGVzIGludsOhbGlkbywgbG8gbGltcGlhbW9zXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdhdXRoVG9rZW4nKTtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2F1dGhVc2VyJyk7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdhdXRoUGVybWlzc2lvbnMnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfTtcbiAgICAgICAgY2hlY2tBdXRoKCk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgbG9naW4gPSBhc3luYyAoY3JlZGVudGlhbHM6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaVNlcnZpY2UubG9naW4oY3JlZGVudGlhbHMpO1xuICAgICAgICBjb25zdCB7IGFjY2Vzc190b2tlbiwgdXNlcjogbG9nZ2VkSW5Vc2VyLCBwZXJtaXNzaW9uczogdXNlclBlcm1pc3Npb25zIH0gPSByZXNwb25zZTtcblxuICAgICAgICAvLyDinIUgUHJpb3JpZGFkOiBwZXJtaXNzaW9ucyBkaXJlY3RvcyA+IHVzZXIucGVybWlzc2lvbnMgPiB1c2VyLnJvbGVzW10ucGVybWlzc2lvbnNcbiAgICAgICAgY29uc3QgZmluYWxQZXJtaXNzaW9ucyA9IHVzZXJQZXJtaXNzaW9ucyB8fFxuICAgICAgICAgICAgbG9nZ2VkSW5Vc2VyLnBlcm1pc3Npb25zIHx8XG4gICAgICAgICAgICAobG9nZ2VkSW5Vc2VyLnJvbGVzICYmIGxvZ2dlZEluVXNlci5yb2xlcy5sZW5ndGggPiAwXG4gICAgICAgICAgICAgICAgPyBsb2dnZWRJblVzZXIucm9sZXMuZmxhdE1hcCgocm9sZTogYW55KSA9PiByb2xlLnBlcm1pc3Npb25zIHx8IFtdKVxuICAgICAgICAgICAgICAgIDogW10pO1xuXG4gICAgICAgIC8vIEd1YXJkYW1vcyBlbCB0b2tlbiwgdXN1YXJpbyB5IHBlcm1pc29zIGVuIGxvY2FsU3RvcmFnZVxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYXV0aFRva2VuJywgYWNjZXNzX3Rva2VuKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2F1dGhVc2VyJywgSlNPTi5zdHJpbmdpZnkobG9nZ2VkSW5Vc2VyKSk7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdhdXRoUGVybWlzc2lvbnMnLCBKU09OLnN0cmluZ2lmeShmaW5hbFBlcm1pc3Npb25zKSk7XG5cbiAgICAgICAgLy8gQWN0dWFsaXphbW9zIGVsIGVzdGFkbyBkZSBsYSBhcGxpY2FjacOzblxuICAgICAgICBzZXRVc2VyKGxvZ2dlZEluVXNlcik7XG4gICAgICAgIHNldFBlcm1pc3Npb25zKGZpbmFsUGVybWlzc2lvbnMpO1xuICAgIH07XG5cbiAgICBjb25zdCBsb2dvdXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBhcGlTZXJ2aWNlLmxvZ291dCgpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGVuIGVsIGxvZ291dCBkZSBsYSBBUEksIGNlcnJhbmRvIHNlc2nDs24gbG9jYWxtZW50ZS5cIiwgZXJyb3IpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgLy8gTGltcGlhbW9zIHRvZG8gc2luIGltcG9ydGFyIHNpIGxhIGxsYW1hZGEgYSBsYSBBUEkgZmFsbMOzXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYXV0aFRva2VuJyk7XG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYXV0aFVzZXInKTtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdhdXRoUGVybWlzc2lvbnMnKTtcbiAgICAgICAgICAgIHNldFVzZXIobnVsbCk7XG4gICAgICAgICAgICBzZXRQZXJtaXNzaW9ucyhbXSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8g4pyFIEhlbHBlciBwYXJhIHZhbGlkYXIgcGVybWlzb3NcbiAgICBjb25zdCBoYXNQZXJtaXNzaW9uID0gKHBlcm1pc3Npb246IHN0cmluZyk6IGJvb2xlYW4gPT4ge1xuICAgICAgICByZXR1cm4gcGVybWlzc2lvbnMuaW5jbHVkZXMocGVybWlzc2lvbik7XG4gICAgfTtcblxuICAgIGNvbnN0IGF1dGhDb250ZXh0VmFsdWUgPSB1c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIGlzQXV0aGVudGljYXRlZDogISF1c2VyLFxuICAgICAgICB1c2VyLFxuICAgICAgICBwZXJtaXNzaW9ucywgLy8g4pyFIEluY2x1aXIgcGVybWlzb3MgZW4gZWwgY29udGV4dG9cbiAgICAgICAgbG9naW4sXG4gICAgICAgIGxvZ291dCxcbiAgICAgICAgaGFzUGVybWlzc2lvbiwgLy8g4pyFIEluY2x1aXIgaGVscGVyXG4gICAgfSksIFt1c2VyLCBwZXJtaXNzaW9uc10pO1xuXG4gICAgLy8gTm8gcmVuZGVyaXphbW9zIG5hZGEgaGFzdGEgcXVlIHNlIGhheWEgdmVyaWZpY2FkbyBsYSBzZXNpw7NuIGluaWNpYWxcbiAgICBpZiAobG9hZGluZykge1xuICAgICAgICByZXR1cm4gPGRpdj5DYXJnYW5kbyBhcGxpY2FjacOzbi4uLjwvZGl2PjtcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2F1dGhDb250ZXh0VmFsdWV9PlxuICAgICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L0F1dGhDb250ZXh0LlByb3ZpZGVyPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb250ZXh0L0F1dGhDb250ZXh0LnRzeCJ9