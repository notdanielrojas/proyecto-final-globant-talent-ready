import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericTable.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaPencilAlt, FaRegTrashAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { TiArrowSortedDown, TiArrowSortedUp, TiArrowUnsorted } from "/node_modules/.vite/deps/react-icons_ti.js?v=cc4fbb62";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { formatValue } from "/src/utils/formatters.ts";
export const GenericTable = ({
  data,
  columns,
  baseRoute,
  onDelete,
  onSort,
  sortBy,
  sortDirection,
  paginationMeta,
  onPageChange,
  onRowClick,
  disableEdit,
  disableActions = false,
  canEdit = true,
  // ✅ Por defecto permitido
  canDelete = true,
  // ✅ Por defecto permitido
  enableRowSelection = false,
  selectedIds,
  onToggleRow,
  onTogglePage
}) => {
  _s();
  const navigate = useNavigate();
  const handleRowClick = (item) => {
    if (onRowClick) {
      onRowClick(item);
    } else {
      navigate(`${baseRoute}/${item.id}`);
    }
  };
  const handleEdit = (e, id) => {
    e.stopPropagation();
    navigate(`${baseRoute}/${id}/editar`);
  };
  const handleDelete = (e, id) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete(id);
    }
  };
  const canEditItem = (item) => {
    if (typeof canEdit === "function") {
      return canEdit(item);
    }
    return canEdit;
  };
  const canDeleteItem = (item) => {
    if (typeof canDelete === "function") {
      return canDelete(item);
    }
    return canDelete;
  };
  const columnSortKey = (col) => col.sortField ?? String(col.accessor);
  const pageIds = data.map((item) => Number(item.id)).filter((id) => Number.isFinite(id));
  const allPageSelected = enableRowSelection && pageIds.length > 0 && pageIds.every((id) => selectedIds?.has(id));
  const somePageSelected = enableRowSelection && pageIds.some((id) => selectedIds?.has(id)) && !allPageSelected;
  const handlePageCheckboxChange = () => {
    if (!onTogglePage) return;
    onTogglePage(pageIds, !allPageSelected);
  };
  const renderSortIcon = (col) => {
    const key = columnSortKey(col);
    if (sortBy !== key) {
      return /* @__PURE__ */ jsxDEV(TiArrowUnsorted, { className: "inline ml-1 text-gray-400" }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 128,
        columnNumber: 14
      }, this);
    }
    if (sortDirection === "asc") {
      return /* @__PURE__ */ jsxDEV(TiArrowSortedUp, { className: "inline ml-1" }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 131,
        columnNumber: 14
      }, this);
    }
    if (sortDirection === "desc") {
      return /* @__PURE__ */ jsxDEV(TiArrowSortedDown, { className: "inline ml-1" }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 134,
        columnNumber: 14
      }, this);
    }
    return /* @__PURE__ */ jsxDEV(TiArrowUnsorted, { className: "inline ml-1 text-gray-400" }, void 0, false, {
      fileName: "/app/src/components/common/GenericTable.tsx",
      lineNumber: 136,
      columnNumber: 12
    }, this);
  };
  return (
    /* 1. EL TRUCO DEL GRID: 
       'grid grid-cols-1' fuerza al contenedor a no crecer más allá de su padre.
       Esto "rompe" el comportamiento expansivo de las tablas en layouts flexibles.
    */
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-full overflow-x-auto shadow ring-1 ring-black ring-opacity-5 md:rounded-lg bg-white", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full border-separate border-spacing-0", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          enableRowSelection && /* @__PURE__ */ jsxDEV(
            "th",
            {
              scope: "col",
              className: "w-10 px-3 py-3.5 text-left border-b border-gray-200",
              children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: allPageSelected,
                  ref: (el) => {
                    if (el) el.indeterminate = somePageSelected;
                  },
                  onChange: handlePageCheckboxChange,
                  "aria-label": "Seleccionar todos los de la página",
                  className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/components/common/GenericTable.tsx",
                  lineNumber: 161,
                  columnNumber: 37
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/GenericTable.tsx",
              lineNumber: 157,
              columnNumber: 15
            },
            this
          ),
          columns.map(
            (col) => /* @__PURE__ */ jsxDEV(
              "th",
              {
                scope: "col",
                className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900 border-b border-gray-200 whitespace-nowrap",
                children: /* @__PURE__ */ jsxDEV("button", { onClick: () => onSort(columnSortKey(col)), className: "flex items-center w-full focus:outline-none group", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: col.header }, void 0, false, {
                    fileName: "/app/src/components/common/GenericTable.tsx",
                    lineNumber: 179,
                    columnNumber: 41
                  }, this),
                  renderSortIcon(col)
                ] }, void 0, true, {
                  fileName: "/app/src/components/common/GenericTable.tsx",
                  lineNumber: 178,
                  columnNumber: 37
                }, this)
              },
              String(col.accessor),
              false,
              {
                fileName: "/app/src/components/common/GenericTable.tsx",
                lineNumber: 173,
                columnNumber: 15
              },
              this
            )
          ),
          !disableActions && /* 4. HEADER STICKY (Acciones) */
          /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "sticky right-0 z-20 py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 bg-gray-50 border-b border-l border-gray-200 shadow-sm whitespace-nowrap sm:pr-6", children: "Acciones" }, void 0, false, {
            fileName: "/app/src/components/common/GenericTable.tsx",
            lineNumber: 187,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericTable.tsx",
          lineNumber: 155,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/GenericTable.tsx",
          lineNumber: 154,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white", children: data.map(
          (item) => /* @__PURE__ */ jsxDEV(
            "tr",
            {
              onClick: () => handleRowClick(item),
              className: "cursor-pointer hover:bg-gray-50 group",
              children: [
                enableRowSelection && /* @__PURE__ */ jsxDEV(
                  "td",
                  {
                    className: "w-10 px-3 py-4 border-b border-gray-200",
                    onClick: (e) => e.stopPropagation(),
                    children: /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "checkbox",
                        checked: selectedIds?.has(Number(item.id)) ?? false,
                        onChange: () => onToggleRow?.(Number(item.id)),
                        "aria-label": `Seleccionar fila ${item.id}`,
                        className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
                        autoComplete: "off"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/components/common/GenericTable.tsx",
                        lineNumber: 205,
                        columnNumber: 41
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/components/common/GenericTable.tsx",
                    lineNumber: 201,
                    columnNumber: 15
                  },
                  this
                ),
                columns.map(
                  (col) => /* @__PURE__ */ jsxDEV(
                    "td",
                    {
                      className: "px-3 py-4 text-sm text-gray-500 border-b border-gray-200 whitespace-nowrap",
                      children: col.render ? col.render(item) : formatValue(item[col.accessor], col.format)
                    },
                    String(col.accessor),
                    false,
                    {
                      fileName: "/app/src/components/common/GenericTable.tsx",
                      lineNumber: 214,
                      columnNumber: 15
                    },
                    this
                  )
                ),
                !disableActions && (canEditItem(item) || canDeleteItem(item)) && /* 5. BODY STICKY (Botones) */
                /* @__PURE__ */ jsxDEV("td", { className: "sticky right-0 z-10 py-4 pl-3 pr-4 text-sm font-medium text-right bg-white border-b border-l border-gray-200 whitespace-nowrap group-hover:bg-gray-50 shadow-sm sm:pr-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2", children: [
                  !disableEdit && canEditItem(item) && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: (e) => handleEdit(e, item.id),
                      className: "p-1 text-indigo-600 hover:text-indigo-900 hover:bg-indigo-50 rounded",
                      title: "Editar",
                      children: /* @__PURE__ */ jsxDEV(FaPencilAlt, {}, void 0, false, {
                        fileName: "/app/src/components/common/GenericTable.tsx",
                        lineNumber: 232,
                        columnNumber: 53
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/components/common/GenericTable.tsx",
                      lineNumber: 227,
                      columnNumber: 19
                    },
                    this
                  ),
                  canDeleteItem(item) && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: (e) => handleDelete(e, item.id),
                      className: "p-1 text-red-600 hover:text-red-900 hover:bg-red-50 rounded",
                      title: "Eliminar",
                      children: /* @__PURE__ */ jsxDEV(FaRegTrashAlt, {}, void 0, false, {
                        fileName: "/app/src/components/common/GenericTable.tsx",
                        lineNumber: 241,
                        columnNumber: 53
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/components/common/GenericTable.tsx",
                      lineNumber: 236,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/src/components/common/GenericTable.tsx",
                  lineNumber: 225,
                  columnNumber: 41
                }, this) }, void 0, false, {
                  fileName: "/app/src/components/common/GenericTable.tsx",
                  lineNumber: 224,
                  columnNumber: 15
                }, this)
              ]
            },
            item.id,
            true,
            {
              fileName: "/app/src/components/common/GenericTable.tsx",
              lineNumber: 195,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/app/src/components/common/GenericTable.tsx",
          lineNumber: 193,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 153,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 150,
        columnNumber: 13
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(Pagination, { meta: paginationMeta, onPageChange }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 255,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericTable.tsx",
        lineNumber: 254,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericTable.tsx",
      lineNumber: 144,
      columnNumber: 5
    }, this)
  );
};
_s(GenericTable, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = GenericTable;
var _c;
$RefreshReg$(_c, "GenericTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEdtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzR25CLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWFDLHFCQUFxQjtBQUUzQyxTQUFTQyxtQkFBbUJDLGlCQUFpQkMsdUJBQXVCO0FBQ3BFLFNBQVNDLGtCQUFrQjtBQUUzQixTQUFTQyxtQkFBbUI7QUF1QnJCLGFBQU1DLGVBQWUsQ0FBb0M7QUFBQSxFQUM1REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsaUJBQWlCO0FBQUEsRUFDakJDLFVBQVU7QUFBQTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQTtBQUFBLEVBQ1pDLHFCQUFxQjtBQUFBLEVBQ3JCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNrQixNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTUMsV0FBVzVCLFlBQVk7QUFFN0IsUUFBTTZCLGlCQUFpQkEsQ0FBQ0MsU0FBWTtBQUNoQyxRQUFJWixZQUFZO0FBQ1pBLGlCQUFXWSxJQUFJO0FBQUEsSUFDbkIsT0FBTztBQUNIRixlQUFTLEdBQUdqQixTQUFTLElBQUltQixLQUFLQyxFQUFFLEVBQUU7QUFBQSxJQUN0QztBQUFBLEVBQ0o7QUFFQSxRQUFNQyxhQUFhQSxDQUFDQyxHQUFxQkYsT0FBd0I7QUFDN0RFLE1BQUVDLGdCQUFnQjtBQUNsQk4sYUFBUyxHQUFHakIsU0FBUyxJQUFJb0IsRUFBRSxTQUFTO0FBQUEsRUFDeEM7QUFFQSxRQUFNSSxlQUFlQSxDQUFDRixHQUFxQkYsT0FBd0I7QUFDL0RFLE1BQUVDLGdCQUFnQjtBQUNsQixRQUFJdEIsVUFBVTtBQUNWQSxlQUFTbUIsRUFBRTtBQUFBLElBQ2Y7QUFBQSxFQUNKO0FBR0EsUUFBTUssY0FBY0EsQ0FBQ04sU0FBcUI7QUFDdEMsUUFBSSxPQUFPVCxZQUFZLFlBQVk7QUFDL0IsYUFBT0EsUUFBUVMsSUFBSTtBQUFBLElBQ3ZCO0FBQ0EsV0FBT1Q7QUFBQUEsRUFDWDtBQUVBLFFBQU1nQixnQkFBZ0JBLENBQUNQLFNBQXFCO0FBQ3hDLFFBQUksT0FBT1IsY0FBYyxZQUFZO0FBQ2pDLGFBQU9BLFVBQVVRLElBQUk7QUFBQSxJQUN6QjtBQUNBLFdBQU9SO0FBQUFBLEVBQ1g7QUFFQSxRQUFNZ0IsZ0JBQWdCQSxDQUFDQyxRQUE2QkEsSUFBSUMsYUFBYUMsT0FBT0YsSUFBSUcsUUFBUTtBQUV4RixRQUFNQyxVQUFVbEMsS0FBS21DLElBQUksQ0FBQWQsU0FBUWUsT0FBT2YsS0FBS0MsRUFBRSxDQUFDLEVBQUVlLE9BQU8sQ0FBQWYsT0FBTWMsT0FBT0UsU0FBU2hCLEVBQUUsQ0FBQztBQUNsRixRQUFNaUIsa0JBQ0Z6QixzQkFDQW9CLFFBQVFNLFNBQVMsS0FDakJOLFFBQVFPLE1BQU0sQ0FBQW5CLE9BQU1QLGFBQWEyQixJQUFJcEIsRUFBRSxDQUFDO0FBQzVDLFFBQU1xQixtQkFDRjdCLHNCQUNBb0IsUUFBUVUsS0FBSyxDQUFBdEIsT0FBTVAsYUFBYTJCLElBQUlwQixFQUFFLENBQUMsS0FDdkMsQ0FBQ2lCO0FBRUwsUUFBTU0sMkJBQTJCQSxNQUFNO0FBQ25DLFFBQUksQ0FBQzVCLGFBQWM7QUFDbkJBLGlCQUFhaUIsU0FBUyxDQUFDSyxlQUFlO0FBQUEsRUFDMUM7QUFFQSxRQUFNTyxpQkFBaUJBLENBQUNoQixRQUE2QjtBQUNqRCxVQUFNaUIsTUFBTWxCLGNBQWNDLEdBQUc7QUFDN0IsUUFBSXpCLFdBQVcwQyxLQUFLO0FBQ2hCLGFBQU8sdUJBQUMsbUJBQWdCLFdBQVUsK0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxJQUNqRTtBQUNBLFFBQUl6QyxrQkFBa0IsT0FBTztBQUN6QixhQUFPLHVCQUFDLG1CQUFnQixXQUFVLGlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsSUFDbkQ7QUFDQSxRQUFJQSxrQkFBa0IsUUFBUTtBQUMxQixhQUFPLHVCQUFDLHFCQUFrQixXQUFVLGlCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsSUFDckQ7QUFDQSxXQUFPLHVCQUFDLG1CQUFnQixXQUFVLCtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNEO0FBQUEsRUFDakU7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLSSx1QkFBQyxTQUFJLFdBQVUsb0JBTVg7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkZBR1gsaUNBQUMsV0FBTSxXQUFVLCtDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDSVE7QUFBQUEsZ0NBQ0c7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU07QUFBQSxjQUNOLFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTeUI7QUFBQUEsa0JBQ1QsS0FBSyxDQUFBUyxPQUFNO0FBQ1Asd0JBQUlBLEdBQUlBLElBQUdDLGdCQUFnQk47QUFBQUEsa0JBQy9CO0FBQUEsa0JBQ0EsVUFBVUU7QUFBQUEsa0JBQ1YsY0FBVztBQUFBLGtCQUNYLFdBQVU7QUFBQSxrQkFBd0UsY0FBYTtBQUFBO0FBQUEsZ0JBUm5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVF3RztBQUFBO0FBQUEsWUFaNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUE7QUFBQSxVQUVINUMsUUFBUWtDO0FBQUFBLFlBQUksQ0FBQ0wsUUFDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVHLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsWUFBTyxTQUFTLE1BQU0xQixPQUFPeUIsY0FBY0MsR0FBRyxDQUFDLEdBQUcsV0FBVSxxREFDekQ7QUFBQSx5Q0FBQyxVQUFNQSxjQUFJb0IsVUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQjtBQUFBLGtCQUNqQkosZUFBZWhCLEdBQUc7QUFBQSxxQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBO0FBQUEsY0FQS0UsT0FBT0YsSUFBSUcsUUFBUTtBQUFBLGNBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFVBQ0g7QUFBQSxVQUVBLENBQUN0QjtBQUFBQSxVQUVFLHVCQUFDLFFBQUcsT0FBTSxPQUFNLFdBQVUsd0tBQXNLLHdCQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFsQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQSxLQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUsWUFDWlgsZUFBS21DO0FBQUFBLFVBQUksQ0FBQ2QsU0FDUDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsU0FBUyxNQUFNRCxlQUFlQyxJQUFJO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBRVRQO0FBQUFBLHNDQUNHO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLFdBQVU7QUFBQSxvQkFDVixTQUFTLENBQUFVLE1BQUtBLEVBQUVDLGdCQUFnQjtBQUFBLG9CQUVoQztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxNQUFLO0FBQUEsd0JBQ0wsU0FBU1YsYUFBYTJCLElBQUlOLE9BQU9mLEtBQUtDLEVBQUUsQ0FBQyxLQUFLO0FBQUEsd0JBQzlDLFVBQVUsTUFBTU4sY0FBY29CLE9BQU9mLEtBQUtDLEVBQUUsQ0FBQztBQUFBLHdCQUM3QyxjQUFZLG9CQUFvQkQsS0FBS0MsRUFBRTtBQUFBLHdCQUN2QyxXQUFVO0FBQUEsd0JBQXdFLGNBQWE7QUFBQTtBQUFBLHNCQUxuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS3dHO0FBQUE7QUFBQSxrQkFUNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVBO0FBQUEsZ0JBRUhyQixRQUFRa0M7QUFBQUEsa0JBQUksQ0FBQ0wsUUFDVjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFRyxXQUFVO0FBQUEsc0JBRVRBLGNBQUlxQixTQUFTckIsSUFBSXFCLE9BQU85QixJQUFJLElBQUl2QixZQUFZdUIsS0FBS1MsSUFBSUcsUUFBUSxHQUFHSCxJQUFJc0IsTUFBTTtBQUFBO0FBQUEsb0JBSHRFcEIsT0FBT0YsSUFBSUcsUUFBUTtBQUFBLG9CQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsZ0JBQ0g7QUFBQSxnQkFFQSxDQUFDdEIsbUJBQW1CZ0IsWUFBWU4sSUFBSSxLQUFLTyxjQUFjUCxJQUFJO0FBQUEsZ0JBRXhELHVCQUFDLFFBQUcsV0FBVSwyS0FDVixpQ0FBQyxTQUFJLFdBQVUsdUNBQ1Y7QUFBQSxtQkFBQ1gsZUFBZWlCLFlBQVlOLElBQUksS0FDN0I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csU0FBUyxDQUFDRyxNQUFNRCxXQUFXQyxHQUFHSCxLQUFLQyxFQUFFO0FBQUEsc0JBQ3JDLFdBQVU7QUFBQSxzQkFDVixPQUFNO0FBQUEsc0JBRU4saUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBWTtBQUFBO0FBQUEsb0JBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUVITSxjQUFjUCxJQUFJLEtBQ2Y7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csU0FBUyxDQUFDRyxNQUFNRSxhQUFhRixHQUFHSCxLQUFLQyxFQUFFO0FBQUEsc0JBQ3ZDLFdBQVU7QUFBQSxzQkFDVixPQUFNO0FBQUEsc0JBRU4saUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBYztBQUFBO0FBQUEsb0JBTGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLHFCQWpCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBO0FBQUE7QUFBQSxZQWpEQ0QsS0FBS0M7QUFBQUEsWUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0RBO0FBQUEsUUFDSCxLQXZETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0RBO0FBQUEsV0FoR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlHQSxLQXBHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUdBO0FBQUEsTUFFQ2Ysa0JBQ0csdUJBQUMsU0FBSSxXQUFVLFFBQ1gsaUNBQUMsY0FBVyxNQUFNQSxnQkFBZ0IsZ0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FoSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtIQTtBQUFBO0FBRVI7QUFBRVcsR0FqTlduQixjQUFZO0FBQUEsVUFvQkpSLFdBQVc7QUFBQTtBQUFBOEQsS0FwQm5CdEQ7QUFBWSxJQUFBc0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlTmF2aWdhdGUiLCJGYVBlbmNpbEFsdCIsIkZhUmVnVHJhc2hBbHQiLCJUaUFycm93U29ydGVkRG93biIsIlRpQXJyb3dTb3J0ZWRVcCIsIlRpQXJyb3dVbnNvcnRlZCIsIlBhZ2luYXRpb24iLCJmb3JtYXRWYWx1ZSIsIkdlbmVyaWNUYWJsZSIsImRhdGEiLCJjb2x1bW5zIiwiYmFzZVJvdXRlIiwib25EZWxldGUiLCJvblNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwicGFnaW5hdGlvbk1ldGEiLCJvblBhZ2VDaGFuZ2UiLCJvblJvd0NsaWNrIiwiZGlzYWJsZUVkaXQiLCJkaXNhYmxlQWN0aW9ucyIsImNhbkVkaXQiLCJjYW5EZWxldGUiLCJlbmFibGVSb3dTZWxlY3Rpb24iLCJzZWxlY3RlZElkcyIsIm9uVG9nZ2xlUm93Iiwib25Ub2dnbGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsImhhbmRsZVJvd0NsaWNrIiwiaXRlbSIsImlkIiwiaGFuZGxlRWRpdCIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJoYW5kbGVEZWxldGUiLCJjYW5FZGl0SXRlbSIsImNhbkRlbGV0ZUl0ZW0iLCJjb2x1bW5Tb3J0S2V5IiwiY29sIiwic29ydEZpZWxkIiwiU3RyaW5nIiwiYWNjZXNzb3IiLCJwYWdlSWRzIiwibWFwIiwiTnVtYmVyIiwiZmlsdGVyIiwiaXNGaW5pdGUiLCJhbGxQYWdlU2VsZWN0ZWQiLCJsZW5ndGgiLCJldmVyeSIsImhhcyIsInNvbWVQYWdlU2VsZWN0ZWQiLCJzb21lIiwiaGFuZGxlUGFnZUNoZWNrYm94Q2hhbmdlIiwicmVuZGVyU29ydEljb24iLCJrZXkiLCJlbCIsImluZGV0ZXJtaW5hdGUiLCJoZWFkZXIiLCJyZW5kZXIiLCJmb3JtYXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJHZW5lcmljVGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljVGFibGUudHN4XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEZhUGVuY2lsQWx0LCBGYVJlZ1RyYXNoQWx0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHR5cGUgeyBDb2x1bW5EZWZpbml0aW9uIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgVGlBcnJvd1NvcnRlZERvd24sIFRpQXJyb3dTb3J0ZWRVcCwgVGlBcnJvd1Vuc29ydGVkIH0gZnJvbSAncmVhY3QtaWNvbnMvdGknO1xuaW1wb3J0IHsgUGFnaW5hdGlvbiB9IGZyb20gJy4vUGFnaW5hdGlvbic7XG5pbXBvcnQgdHlwZSB7IFBhZ2luYXRlZFJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy9BcGknO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcblxuaW50ZXJmYWNlIEdlbmVyaWNUYWJsZVByb3BzPFQgZXh0ZW5kcyB7IGlkOiBzdHJpbmcgfCBudW1iZXIgfT4ge1xuICAgIGRhdGE6IFRbXTtcbiAgICBjb2x1bW5zOiBDb2x1bW5EZWZpbml0aW9uPFQ+W107XG4gICAgYmFzZVJvdXRlOiBzdHJpbmc7XG4gICAgb25EZWxldGU/OiAoaWQ6IG51bWJlciB8IHN0cmluZykgPT4gdm9pZDtcbiAgICBvblNvcnQ6IChzb3J0RmllbGQ6IHN0cmluZykgPT4gdm9pZDtcbiAgICBzb3J0Qnk6IHN0cmluZyB8IG51bGw7XG4gICAgc29ydERpcmVjdGlvbjogJ2FzYycgfCAnZGVzYycgfCBudWxsO1xuICAgIHBhZ2luYXRpb25NZXRhOiBQYWdpbmF0ZWRSZXNwb25zZTxUPlsnbWV0YSddIHwgbnVsbDtcbiAgICBvblBhZ2VDaGFuZ2U6ICh1cmw6IHN0cmluZykgPT4gdm9pZDtcbiAgICBvblJvd0NsaWNrPzogKGl0ZW06IFQpID0+IHZvaWQ7XG4gICAgZGlzYWJsZUVkaXQ/OiBib29sZWFuO1xuICAgIGRpc2FibGVBY3Rpb25zPzogYm9vbGVhbjtcbiAgICBjYW5FZGl0PzogYm9vbGVhbiB8ICgoaXRlbTogVCkgPT4gYm9vbGVhbik7IC8vIOKchSBQZXJtaXNvIHBhcmEgZWRpdGFyIChwdWVkZSBzZXIgZnVuY2nDs24pXG4gICAgY2FuRGVsZXRlPzogYm9vbGVhbiB8ICgoaXRlbTogVCkgPT4gYm9vbGVhbik7IC8vIOKchSBQZXJtaXNvIHBhcmEgZWxpbWluYXIgKHB1ZWRlIHNlciBmdW5jacOzbilcbiAgICBlbmFibGVSb3dTZWxlY3Rpb24/OiBib29sZWFuO1xuICAgIHNlbGVjdGVkSWRzPzogU2V0PG51bWJlcj47XG4gICAgb25Ub2dnbGVSb3c/OiAoaWQ6IG51bWJlcikgPT4gdm9pZDtcbiAgICBvblRvZ2dsZVBhZ2U/OiAoaWRzOiBudW1iZXJbXSwgY2hlY2tlZDogYm9vbGVhbikgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEdlbmVyaWNUYWJsZSA9IDxUIGV4dGVuZHMgeyBpZDogc3RyaW5nIHwgbnVtYmVyIH0+KHtcbiAgICBkYXRhLFxuICAgIGNvbHVtbnMsXG4gICAgYmFzZVJvdXRlLFxuICAgIG9uRGVsZXRlLFxuICAgIG9uU29ydCxcbiAgICBzb3J0QnksXG4gICAgc29ydERpcmVjdGlvbixcbiAgICBwYWdpbmF0aW9uTWV0YSxcbiAgICBvblBhZ2VDaGFuZ2UsXG4gICAgb25Sb3dDbGljayxcbiAgICBkaXNhYmxlRWRpdCxcbiAgICBkaXNhYmxlQWN0aW9ucyA9IGZhbHNlLFxuICAgIGNhbkVkaXQgPSB0cnVlLCAvLyDinIUgUG9yIGRlZmVjdG8gcGVybWl0aWRvXG4gICAgY2FuRGVsZXRlID0gdHJ1ZSwgLy8g4pyFIFBvciBkZWZlY3RvIHBlcm1pdGlkb1xuICAgIGVuYWJsZVJvd1NlbGVjdGlvbiA9IGZhbHNlLFxuICAgIHNlbGVjdGVkSWRzLFxuICAgIG9uVG9nZ2xlUm93LFxuICAgIG9uVG9nZ2xlUGFnZSxcbn06IEdlbmVyaWNUYWJsZVByb3BzPFQ+KSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgY29uc3QgaGFuZGxlUm93Q2xpY2sgPSAoaXRlbTogVCkgPT4ge1xuICAgICAgICBpZiAob25Sb3dDbGljaykge1xuICAgICAgICAgICAgb25Sb3dDbGljayhpdGVtKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5hdmlnYXRlKGAke2Jhc2VSb3V0ZX0vJHtpdGVtLmlkfWApO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUVkaXQgPSAoZTogUmVhY3QuTW91c2VFdmVudCwgaWQ6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBuYXZpZ2F0ZShgJHtiYXNlUm91dGV9LyR7aWR9L2VkaXRhcmApO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVEZWxldGUgPSAoZTogUmVhY3QuTW91c2VFdmVudCwgaWQ6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAob25EZWxldGUpIHtcbiAgICAgICAgICAgIG9uRGVsZXRlKGlkKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDinIUgTlVFVk86IEhlbHBlcnMgcGFyYSBldmFsdWFyIGNhbkVkaXQvY2FuRGVsZXRlIChwdWVkZW4gc2VyIGZ1bmNpb25lcyBvIGJvb2xlYW5vcylcbiAgICBjb25zdCBjYW5FZGl0SXRlbSA9IChpdGVtOiBUKTogYm9vbGVhbiA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgY2FuRWRpdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgcmV0dXJuIGNhbkVkaXQoaXRlbSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNhbkVkaXQ7XG4gICAgfTtcblxuICAgIGNvbnN0IGNhbkRlbGV0ZUl0ZW0gPSAoaXRlbTogVCk6IGJvb2xlYW4gPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGNhbkRlbGV0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgcmV0dXJuIGNhbkRlbGV0ZShpdGVtKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY2FuRGVsZXRlO1xuICAgIH07XG5cbiAgICBjb25zdCBjb2x1bW5Tb3J0S2V5ID0gKGNvbDogQ29sdW1uRGVmaW5pdGlvbjxUPikgPT4gY29sLnNvcnRGaWVsZCA/PyBTdHJpbmcoY29sLmFjY2Vzc29yKTtcblxuICAgIGNvbnN0IHBhZ2VJZHMgPSBkYXRhLm1hcChpdGVtID0+IE51bWJlcihpdGVtLmlkKSkuZmlsdGVyKGlkID0+IE51bWJlci5pc0Zpbml0ZShpZCkpO1xuICAgIGNvbnN0IGFsbFBhZ2VTZWxlY3RlZCA9XG4gICAgICAgIGVuYWJsZVJvd1NlbGVjdGlvbiAmJlxuICAgICAgICBwYWdlSWRzLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgcGFnZUlkcy5ldmVyeShpZCA9PiBzZWxlY3RlZElkcz8uaGFzKGlkKSk7XG4gICAgY29uc3Qgc29tZVBhZ2VTZWxlY3RlZCA9XG4gICAgICAgIGVuYWJsZVJvd1NlbGVjdGlvbiAmJlxuICAgICAgICBwYWdlSWRzLnNvbWUoaWQgPT4gc2VsZWN0ZWRJZHM/LmhhcyhpZCkpICYmXG4gICAgICAgICFhbGxQYWdlU2VsZWN0ZWQ7XG5cbiAgICBjb25zdCBoYW5kbGVQYWdlQ2hlY2tib3hDaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgIGlmICghb25Ub2dnbGVQYWdlKSByZXR1cm47XG4gICAgICAgIG9uVG9nZ2xlUGFnZShwYWdlSWRzLCAhYWxsUGFnZVNlbGVjdGVkKTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVuZGVyU29ydEljb24gPSAoY29sOiBDb2x1bW5EZWZpbml0aW9uPFQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IGtleSA9IGNvbHVtblNvcnRLZXkoY29sKTtcbiAgICAgICAgaWYgKHNvcnRCeSAhPT0ga2V5KSB7XG4gICAgICAgICAgICByZXR1cm4gPFRpQXJyb3dVbnNvcnRlZCBjbGFzc05hbWU9XCJpbmxpbmUgbWwtMSB0ZXh0LWdyYXktNDAwXCIgLz47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNvcnREaXJlY3Rpb24gPT09ICdhc2MnKSB7XG4gICAgICAgICAgICByZXR1cm4gPFRpQXJyb3dTb3J0ZWRVcCBjbGFzc05hbWU9XCJpbmxpbmUgbWwtMVwiIC8+O1xuICAgICAgICB9XG4gICAgICAgIGlmIChzb3J0RGlyZWN0aW9uID09PSAnZGVzYycpIHtcbiAgICAgICAgICAgIHJldHVybiA8VGlBcnJvd1NvcnRlZERvd24gY2xhc3NOYW1lPVwiaW5saW5lIG1sLTFcIiAvPjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gPFRpQXJyb3dVbnNvcnRlZCBjbGFzc05hbWU9XCJpbmxpbmUgbWwtMSB0ZXh0LWdyYXktNDAwXCIgLz47XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIC8qIDEuIEVMIFRSVUNPIERFTCBHUklEOiBcbiAgICAgICAgICAgJ2dyaWQgZ3JpZC1jb2xzLTEnIGZ1ZXJ6YSBhbCBjb250ZW5lZG9yIGEgbm8gY3JlY2VyIG3DoXMgYWxsw6EgZGUgc3UgcGFkcmUuXG4gICAgICAgICAgIEVzdG8gXCJyb21wZVwiIGVsIGNvbXBvcnRhbWllbnRvIGV4cGFuc2l2byBkZSBsYXMgdGFibGFzIGVuIGxheW91dHMgZmxleGlibGVzLlxuICAgICAgICAqL1xuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTFcIj5cblxuICAgICAgICAgICAgey8qIDIuIENPTlRFTkVET1IgREUgU0NST0xMOiBcbiAgICAgICAgICAgICAgIC0gb3ZlcmZsb3cteC1hdXRvOiBBaG9yYSBzw60gZnVuY2lvbmFyw6EgcG9ycXVlIGVsIHBhZHJlIChncmlkKSBsbyBsaW1pdGEuXG4gICAgICAgICAgICAgICAtIG1pbi13LWZ1bGw6IEFzZWd1cmEgcXVlIG9jdXBlIHRvZG8gZWwgZXNwYWNpbyBkaXNwb25pYmxlLlxuICAgICAgICAgICAgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgb3ZlcmZsb3cteC1hdXRvIHNoYWRvdyByaW5nLTEgcmluZy1ibGFjayByaW5nLW9wYWNpdHktNSBtZDpyb3VuZGVkLWxnIGJnLXdoaXRlXCI+XG5cbiAgICAgICAgICAgICAgICB7LyogMy4gVEFCTEE6IGJvcmRlci1zZXBhcmF0ZSBwYXJhIHF1ZSBlbCBzdGlja3kgZnVuY2lvbmUgcGVyZmVjdG8gKi99XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgYm9yZGVyLXNlcGFyYXRlIGJvcmRlci1zcGFjaW5nLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW5hYmxlUm93U2VsZWN0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzY29wZT1cImNvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEwIHB4LTMgcHktMy41IHRleHQtbGVmdCBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2FsbFBhZ2VTZWxlY3RlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2VsID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVsKSBlbC5pbmRldGVybWluYXRlID0gc29tZVBhZ2VTZWxlY3RlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYWdlQ2hlY2tib3hDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNlbGVjY2lvbmFyIHRvZG9zIGxvcyBkZSBsYSBww6FnaW5hXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTYwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpyaW5nLWluZGlnby01MDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbHVtbnMubWFwKChjb2wpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e1N0cmluZyhjb2wuYWNjZXNzb3IpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU9XCJjb2xcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb25Tb3J0KGNvbHVtblNvcnRLZXkoY29sKSl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Y29sLmhlYWRlcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlclNvcnRJY29uKGNvbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshZGlzYWJsZUFjdGlvbnMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiA0LiBIRUFERVIgU1RJQ0tZIChBY2Npb25lcykgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwic3RpY2t5IHJpZ2h0LTAgei0yMCBweS0zLjUgcGwtMyBwci00IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgYmctZ3JheS01MCBib3JkZXItYiBib3JkZXItbCBib3JkZXItZ3JheS0yMDAgc2hhZG93LXNtIHdoaXRlc3BhY2Utbm93cmFwIHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjY2lvbmVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2RhdGEubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUm93Q2xpY2soaXRlbSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktNTAgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VuYWJsZVJvd1NlbGVjdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEwIHB4LTMgcHktNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2UgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRJZHM/LmhhcyhOdW1iZXIoaXRlbS5pZCkpID8/IGZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gb25Ub2dnbGVSb3c/LihOdW1iZXIoaXRlbS5pZCkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgU2VsZWNjaW9uYXIgZmlsYSAke2l0ZW0uaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDAgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2x1bW5zLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e1N0cmluZyhjb2wuYWNjZXNzb3IpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHdoaXRlc3BhY2Utbm93cmFwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29sLnJlbmRlciA/IGNvbC5yZW5kZXIoaXRlbSkgOiBmb3JtYXRWYWx1ZShpdGVtW2NvbC5hY2Nlc3Nvcl0sIGNvbC5mb3JtYXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFkaXNhYmxlQWN0aW9ucyAmJiAoY2FuRWRpdEl0ZW0oaXRlbSkgfHwgY2FuRGVsZXRlSXRlbShpdGVtKSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogNS4gQk9EWSBTVElDS1kgKEJvdG9uZXMpICovXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic3RpY2t5IHJpZ2h0LTAgei0xMCBweS00IHBsLTMgcHItNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmlnaHQgYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLWwgYm9yZGVyLWdyYXktMjAwIHdoaXRlc3BhY2Utbm93cmFwIGdyb3VwLWhvdmVyOmJnLWdyYXktNTAgc2hhZG93LXNtIHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshZGlzYWJsZUVkaXQgJiYgY2FuRWRpdEl0ZW0oaXRlbSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVFZGl0KGUsIGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tOTAwIGhvdmVyOmJnLWluZGlnby01MCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXRhclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGVuY2lsQWx0IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbkRlbGV0ZUl0ZW0oaXRlbSkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVEZWxldGUoZSwgaXRlbS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtcmVkLTYwMCBob3Zlcjp0ZXh0LXJlZC05MDAgaG92ZXI6YmctcmVkLTUwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJlZ1RyYXNoQWx0IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3BhZ2luYXRpb25NZXRhICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPFBhZ2luYXRpb24gbWV0YT17cGFnaW5hdGlvbk1ldGF9IG9uUGFnZUNoYW5nZT17b25QYWdlQ2hhbmdlfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljVGFibGUudHN4In0=