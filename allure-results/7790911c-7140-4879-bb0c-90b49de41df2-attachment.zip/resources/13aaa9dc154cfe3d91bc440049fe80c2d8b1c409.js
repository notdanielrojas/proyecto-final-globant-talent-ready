import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/DecimalInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/DecimalInput.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import {
  asDecimalValue,
  formatDecimalDisplay,
  isValidDecimalDraft,
  normalizeDecimalDraft,
  parseDecimalDraft
} from "/src/utils/decimalInput.ts";
export const DecimalInput = _s(forwardRef(_c = _s(function DecimalInput2(props, ref) {
  _s();
  const {
    value,
    onChange,
    emptyWhenZero = true,
    whenEmpty = 0,
    nullable = false,
    onFocus,
    onBlur,
    className,
    disabled,
    ...rest
  } = props;
  const numericValue = asDecimalValue(value);
  const [draft, setDraft] = useState(() => formatDecimalDisplay(numericValue, emptyWhenZero));
  const isFocusedRef = useRef(false);
  const lastExternalValueRef = useRef(numericValue);
  useEffect(() => {
    if (isFocusedRef.current) return;
    if (lastExternalValueRef.current === numericValue) return;
    lastExternalValueRef.current = numericValue;
    setDraft(formatDecimalDisplay(numericValue, emptyWhenZero));
  }, [numericValue, emptyWhenZero]);
  const emitValue = (raw) => {
    const normalized = normalizeDecimalDraft(raw.trim());
    if (normalized === "" || normalized === "." || normalized === "-" || normalized === "-.") {
      return whenEmpty;
    }
    return parseDecimalDraft(normalized);
  };
  const notifyChange = (raw) => {
    const emitted = emitValue(raw);
    if (nullable) {
      onChange(emitted);
    } else {
      onChange(emitted ?? whenEmpty ?? 0);
    }
  };
  const handleChange = (e) => {
    const raw = e.target.value;
    if (!isValidDecimalDraft(raw)) return;
    const normalized = normalizeDecimalDraft(raw);
    setDraft(normalized);
    notifyChange(normalized);
  };
  const handleFocus = (e) => {
    isFocusedRef.current = true;
    onFocus?.(e);
  };
  const handleBlur = (e) => {
    isFocusedRef.current = false;
    const parsed = emitValue(draft);
    lastExternalValueRef.current = parsed;
    setDraft(formatDecimalDisplay(parsed, emptyWhenZero));
    notifyChange(draft);
    onBlur?.(e);
  };
  return /* @__PURE__ */ jsxDEV(
    "input",
    {
      ...rest,
      ref,
      type: "text",
      inputMode: "decimal",
      autoComplete: "off",
      value: draft,
      onChange: handleChange,
      onFocus: handleFocus,
      onBlur: handleBlur,
      disabled,
      className
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/DecimalInput.tsx",
      lineNumber: 120,
      columnNumber: 5
    },
    this
  );
}, "CCZE1IqzWPLidRsjJfzFdGVpUKM=")), "CCZE1IqzWPLidRsjJfzFdGVpUKM=");
_c2 = DecimalInput;
var _c, _c2;
$RefreshReg$(_c, "DecimalInput$forwardRef");
$RefreshReg$(_c2, "DecimalInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/DecimalInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/DecimalInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0dROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBHUixTQUFTQSxZQUFZQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDeEQ7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBdUJBLGFBQU1DLGVBQVlDLEdBQUdWLFdBQStDVyxLQUFBRCxHQUFDLFNBQVNELGNBQ2pGRyxPQUNBQyxLQUNGO0FBQUFILEtBQUE7QUFDRSxRQUFNO0FBQUEsSUFDRkk7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsZ0JBQWdCO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxXQUFXO0FBQUEsSUFDWEM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQSxHQUFHQztBQUFBQSxFQUNQLElBQUlYO0FBRUosUUFBTVksZUFBZXBCLGVBQWVVLEtBQUs7QUFDekMsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUl2QixTQUFTLE1BQU1FLHFCQUFxQm1CLGNBQWNSLGFBQWEsQ0FBQztBQUMxRixRQUFNVyxlQUFlekIsT0FBTyxLQUFLO0FBQ2pDLFFBQU0wQix1QkFBdUIxQixPQUFPc0IsWUFBWTtBQUVoRHZCLFlBQVUsTUFBTTtBQUNaLFFBQUkwQixhQUFhRSxRQUFTO0FBQzFCLFFBQUlELHFCQUFxQkMsWUFBWUwsYUFBYztBQUNuREkseUJBQXFCQyxVQUFVTDtBQUMvQkUsYUFBU3JCLHFCQUFxQm1CLGNBQWNSLGFBQWEsQ0FBQztBQUFBLEVBQzlELEdBQUcsQ0FBQ1EsY0FBY1IsYUFBYSxDQUFDO0FBRWhDLFFBQU1jLFlBQVlBLENBQUNDLFFBQStCO0FBQzlDLFVBQU1DLGFBQWF6QixzQkFBc0J3QixJQUFJRSxLQUFLLENBQUM7QUFDbkQsUUFBSUQsZUFBZSxNQUFNQSxlQUFlLE9BQU9BLGVBQWUsT0FBT0EsZUFBZSxNQUFNO0FBQ3RGLGFBQU9mO0FBQUFBLElBQ1g7QUFDQSxXQUFPVCxrQkFBa0J3QixVQUFVO0FBQUEsRUFDdkM7QUFFQSxRQUFNRSxlQUFlQSxDQUFDSCxRQUFnQjtBQUNsQyxVQUFNSSxVQUFVTCxVQUFVQyxHQUFHO0FBQzdCLFFBQUliLFVBQVU7QUFDVixNQUFDSCxTQUE0Q29CLE9BQU87QUFBQSxJQUN4RCxPQUFPO0FBQ0gsTUFBQ3BCLFNBQXFDb0IsV0FBV2xCLGFBQWEsQ0FBQztBQUFBLElBQ25FO0FBQUEsRUFDSjtBQUVBLFFBQU1tQixlQUFlQSxDQUFDQyxNQUEyQztBQUM3RCxVQUFNTixNQUFNTSxFQUFFQyxPQUFPeEI7QUFDckIsUUFBSSxDQUFDUixvQkFBb0J5QixHQUFHLEVBQUc7QUFFL0IsVUFBTUMsYUFBYXpCLHNCQUFzQndCLEdBQUc7QUFDNUNMLGFBQVNNLFVBQVU7QUFDbkJFLGlCQUFhRixVQUFVO0FBQUEsRUFDM0I7QUFFQSxRQUFNTyxjQUFjQSxDQUFDRixNQUEwQztBQUMzRFYsaUJBQWFFLFVBQVU7QUFDdkJWLGNBQVVrQixDQUFDO0FBQUEsRUFDZjtBQUVBLFFBQU1HLGFBQWFBLENBQUNILE1BQTBDO0FBQzFEVixpQkFBYUUsVUFBVTtBQUN2QixVQUFNWSxTQUFTWCxVQUFVTCxLQUFLO0FBQzlCRyx5QkFBcUJDLFVBQVVZO0FBQy9CZixhQUFTckIscUJBQXFCb0MsUUFBUXpCLGFBQWEsQ0FBQztBQUNwRGtCLGlCQUFhVCxLQUFLO0FBQ2xCTCxhQUFTaUIsQ0FBQztBQUFBLEVBQ2Q7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxHQUFJZDtBQUFBQSxNQUNKO0FBQUEsTUFDQSxNQUFLO0FBQUEsTUFDTCxXQUFVO0FBQUEsTUFDVixjQUFhO0FBQUEsTUFDYixPQUFPRTtBQUFBQSxNQUNQLFVBQVVXO0FBQUFBLE1BQ1YsU0FBU0c7QUFBQUEsTUFDVCxRQUFRQztBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXeUI7QUFHakMsR0FBQyxrQ0FBQztBQUFDRSxNQXBGVWpDO0FBQVksSUFBQUUsSUFBQStCO0FBQUFDLGFBQUFoQyxJQUFBO0FBQUFnQyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiZm9yd2FyZFJlZiIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiYXNEZWNpbWFsVmFsdWUiLCJmb3JtYXREZWNpbWFsRGlzcGxheSIsImlzVmFsaWREZWNpbWFsRHJhZnQiLCJub3JtYWxpemVEZWNpbWFsRHJhZnQiLCJwYXJzZURlY2ltYWxEcmFmdCIsIkRlY2ltYWxJbnB1dCIsIl9zIiwiX2MiLCJwcm9wcyIsInJlZiIsInZhbHVlIiwib25DaGFuZ2UiLCJlbXB0eVdoZW5aZXJvIiwid2hlbkVtcHR5IiwibnVsbGFibGUiLCJvbkZvY3VzIiwib25CbHVyIiwiY2xhc3NOYW1lIiwiZGlzYWJsZWQiLCJyZXN0IiwibnVtZXJpY1ZhbHVlIiwiZHJhZnQiLCJzZXREcmFmdCIsImlzRm9jdXNlZFJlZiIsImxhc3RFeHRlcm5hbFZhbHVlUmVmIiwiY3VycmVudCIsImVtaXRWYWx1ZSIsInJhdyIsIm5vcm1hbGl6ZWQiLCJ0cmltIiwibm90aWZ5Q2hhbmdlIiwiZW1pdHRlZCIsImhhbmRsZUNoYW5nZSIsImUiLCJ0YXJnZXQiLCJoYW5kbGVGb2N1cyIsImhhbmRsZUJsdXIiLCJwYXJzZWQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGVjaW1hbElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3J3YXJkUmVmLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICAgIGFzRGVjaW1hbFZhbHVlLFxuICAgIGZvcm1hdERlY2ltYWxEaXNwbGF5LFxuICAgIGlzVmFsaWREZWNpbWFsRHJhZnQsXG4gICAgbm9ybWFsaXplRGVjaW1hbERyYWZ0LFxuICAgIHBhcnNlRGVjaW1hbERyYWZ0LFxufSBmcm9tICcuLi8uLi91dGlscy9kZWNpbWFsSW5wdXQnO1xuXG50eXBlIERlY2ltYWxJbnB1dEJhc2VQcm9wcyA9IE9taXQ8XG4gICAgUmVhY3QuSW5wdXRIVE1MQXR0cmlidXRlczxIVE1MSW5wdXRFbGVtZW50PixcbiAgICAndmFsdWUnIHwgJ29uQ2hhbmdlJyB8ICd0eXBlJ1xuPiAmIHtcbiAgICB2YWx1ZTogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcbiAgICAvKiogTXVlc3RyYSBjYW1wbyB2YWPDrW8gY3VhbmRvIGVsIHZhbG9yIG51bcOpcmljbyBlcyAwLiBQb3IgZGVmZWN0byB0cnVlLiAqL1xuICAgIGVtcHR5V2hlblplcm8/OiBib29sZWFuO1xuICAgIC8qKiBWYWxvciBlbWl0aWRvIGN1YW5kbyBlbCBjYW1wbyBxdWVkYSB2YWPDrW8uIFBvciBkZWZlY3RvIDAuICovXG4gICAgd2hlbkVtcHR5PzogbnVtYmVyIHwgbnVsbDtcbn07XG5cbmV4cG9ydCB0eXBlIERlY2ltYWxJbnB1dFByb3BzID1cbiAgICB8IChEZWNpbWFsSW5wdXRCYXNlUHJvcHMgJiB7XG4gICAgICAgICAgbnVsbGFibGU/OiBmYWxzZTtcbiAgICAgICAgICBvbkNoYW5nZTogKHZhbHVlOiBudW1iZXIpID0+IHZvaWQ7XG4gICAgICB9KVxuICAgIHwgKERlY2ltYWxJbnB1dEJhc2VQcm9wcyAmIHtcbiAgICAgICAgICBudWxsYWJsZTogdHJ1ZTtcbiAgICAgICAgICBvbkNoYW5nZTogKHZhbHVlOiBudW1iZXIgfCBudWxsKSA9PiB2b2lkO1xuICAgICAgfSk7XG5cbmV4cG9ydCBjb25zdCBEZWNpbWFsSW5wdXQgPSBmb3J3YXJkUmVmPEhUTUxJbnB1dEVsZW1lbnQsIERlY2ltYWxJbnB1dFByb3BzPihmdW5jdGlvbiBEZWNpbWFsSW5wdXQoXG4gICAgcHJvcHMsXG4gICAgcmVmLFxuKSB7XG4gICAgY29uc3Qge1xuICAgICAgICB2YWx1ZSxcbiAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgIGVtcHR5V2hlblplcm8gPSB0cnVlLFxuICAgICAgICB3aGVuRW1wdHkgPSAwLFxuICAgICAgICBudWxsYWJsZSA9IGZhbHNlLFxuICAgICAgICBvbkZvY3VzLFxuICAgICAgICBvbkJsdXIsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIC4uLnJlc3RcbiAgICB9ID0gcHJvcHM7XG5cbiAgICBjb25zdCBudW1lcmljVmFsdWUgPSBhc0RlY2ltYWxWYWx1ZSh2YWx1ZSk7XG4gICAgY29uc3QgW2RyYWZ0LCBzZXREcmFmdF0gPSB1c2VTdGF0ZSgoKSA9PiBmb3JtYXREZWNpbWFsRGlzcGxheShudW1lcmljVmFsdWUsIGVtcHR5V2hlblplcm8pKTtcbiAgICBjb25zdCBpc0ZvY3VzZWRSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IGxhc3RFeHRlcm5hbFZhbHVlUmVmID0gdXNlUmVmKG51bWVyaWNWYWx1ZSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNGb2N1c2VkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgaWYgKGxhc3RFeHRlcm5hbFZhbHVlUmVmLmN1cnJlbnQgPT09IG51bWVyaWNWYWx1ZSkgcmV0dXJuO1xuICAgICAgICBsYXN0RXh0ZXJuYWxWYWx1ZVJlZi5jdXJyZW50ID0gbnVtZXJpY1ZhbHVlO1xuICAgICAgICBzZXREcmFmdChmb3JtYXREZWNpbWFsRGlzcGxheShudW1lcmljVmFsdWUsIGVtcHR5V2hlblplcm8pKTtcbiAgICB9LCBbbnVtZXJpY1ZhbHVlLCBlbXB0eVdoZW5aZXJvXSk7XG5cbiAgICBjb25zdCBlbWl0VmFsdWUgPSAocmF3OiBzdHJpbmcpOiBudW1iZXIgfCBudWxsID0+IHtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZURlY2ltYWxEcmFmdChyYXcudHJpbSgpKTtcbiAgICAgICAgaWYgKG5vcm1hbGl6ZWQgPT09ICcnIHx8IG5vcm1hbGl6ZWQgPT09ICcuJyB8fCBub3JtYWxpemVkID09PSAnLScgfHwgbm9ybWFsaXplZCA9PT0gJy0uJykge1xuICAgICAgICAgICAgcmV0dXJuIHdoZW5FbXB0eTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcGFyc2VEZWNpbWFsRHJhZnQobm9ybWFsaXplZCk7XG4gICAgfTtcblxuICAgIGNvbnN0IG5vdGlmeUNoYW5nZSA9IChyYXc6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBlbWl0dGVkID0gZW1pdFZhbHVlKHJhdyk7XG4gICAgICAgIGlmIChudWxsYWJsZSkge1xuICAgICAgICAgICAgKG9uQ2hhbmdlIGFzICh2YWx1ZTogbnVtYmVyIHwgbnVsbCkgPT4gdm9pZCkoZW1pdHRlZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAob25DaGFuZ2UgYXMgKHZhbHVlOiBudW1iZXIpID0+IHZvaWQpKGVtaXR0ZWQgPz8gd2hlbkVtcHR5ID8/IDApO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCByYXcgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgaWYgKCFpc1ZhbGlkRGVjaW1hbERyYWZ0KHJhdykpIHJldHVybjtcblxuICAgICAgICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplRGVjaW1hbERyYWZ0KHJhdyk7XG4gICAgICAgIHNldERyYWZ0KG5vcm1hbGl6ZWQpO1xuICAgICAgICBub3RpZnlDaGFuZ2Uobm9ybWFsaXplZCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUZvY3VzID0gKGU6IFJlYWN0LkZvY3VzRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICAgICAgaXNGb2N1c2VkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBvbkZvY3VzPy4oZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUJsdXIgPSAoZTogUmVhY3QuRm9jdXNFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBpc0ZvY3VzZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBwYXJzZWQgPSBlbWl0VmFsdWUoZHJhZnQpO1xuICAgICAgICBsYXN0RXh0ZXJuYWxWYWx1ZVJlZi5jdXJyZW50ID0gcGFyc2VkO1xuICAgICAgICBzZXREcmFmdChmb3JtYXREZWNpbWFsRGlzcGxheShwYXJzZWQsIGVtcHR5V2hlblplcm8pKTtcbiAgICAgICAgbm90aWZ5Q2hhbmdlKGRyYWZ0KTtcbiAgICAgICAgb25CbHVyPy4oZSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgey4uLnJlc3R9XG4gICAgICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgIHZhbHVlPXtkcmFmdH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XG4gICAgICAgICAgICBvbkZvY3VzPXtoYW5kbGVGb2N1c31cbiAgICAgICAgICAgIG9uQmx1cj17aGFuZGxlQmx1cn1cbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgICAgICAvPlxuICAgICk7XG59KTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vRGVjaW1hbElucHV0LnRzeCJ9