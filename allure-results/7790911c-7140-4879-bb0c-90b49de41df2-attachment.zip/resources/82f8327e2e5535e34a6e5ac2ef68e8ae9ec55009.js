import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { comisionesVendedoresConfig } from "/src/features/comisiones_vendedores/comisiones_vendedores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const ComisionesVendedoresDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error } = useCrudItem(comisionesVendedoresConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando tramo..." }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx",
    lineNumber: 29,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Tramo no encontrado." }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: comisionesVendedoresConfig, item }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(ComisionesVendedoresDetailPage, "6YQMcrxNTGjd60HB6xOhIbiA4BI=", false, function() {
  return [useParams, useCrudItem];
});
_c = ComisionesVendedoresDetailPage;
var _c;
$RefreshReg$(_c, "ComisionesVendedoresDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGtDQUE2RDtBQUN0RSxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsaUNBQWlDQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEQsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsU0FBU0MsTUFBTSxJQUFJTixZQUFrQ0QsNEJBQTRCSSxFQUFFO0FBRWpHLE1BQUlFLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGlDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc0I7QUFDMUMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsS0FBTSxRQUFPLHVCQUFDLFNBQUksb0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QjtBQUUzQyxTQUFPLHVCQUFDLHFCQUF3QyxRQUFRTCw0QkFBNEIsUUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3RjtBQUNuRztBQUFFRyxHQVRXRCxnQ0FBOEI7QUFBQSxVQUN4QkosV0FDa0JHLFdBQVc7QUFBQTtBQUFBTyxLQUZuQ047QUFBOEIsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWciLCJ1c2VDcnVkSXRlbSIsIkNvbWlzaW9uZXNWZW5kZWRvcmVzRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJpdGVtIiwibG9hZGluZyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29taXNpb25lc1ZlbmRlZG9yZXNEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcsIHR5cGUgQ29tbWlzc2lvbk1hcmdpblRpZXIgfSBmcm9tICcuLi9jb21pc2lvbmVzX3ZlbmRlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuXG5leHBvcnQgY29uc3QgQ29taXNpb25lc1ZlbmRlZG9yZXNEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxDb21taXNzaW9uTWFyZ2luVGllcj4oY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyB0cmFtby4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFpdGVtKSByZXR1cm4gPGRpdj5UcmFtbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiA8R2VuZXJpY0RldGFpbFBhZ2U8Q29tbWlzc2lvbk1hcmdpblRpZXI+IGNvbmZpZz17Y29taXNpb25lc1ZlbmRlZG9yZXNDb25maWd9IGl0ZW09e2l0ZW19IC8+O1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY29taXNpb25lc192ZW5kZWRvcmVzL3BhZ2VzL0NvbWlzaW9uZXNWZW5kZWRvcmVzRGV0YWlsUGFnZS50c3gifQ==