import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito/pages/NotasCreditoFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaTrash, FaInfoCircle, FaPercentage } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, searchByField } from "/src/services/apiService.ts";
import { notasCreditoModuleConfig } from "/src/features/notas_credito/notas_credito.config.tsx";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { ItemTaxModal } from "/src/components/common/ItemTaxModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import {} from "/src/types/appliedTaxes.ts";
import {
  computeExemptDocumentTotal,
  getEffectiveClientTaxes,
  isClientLeyExportacionTdfExempt,
  sanitizeTaxPayloadForExemptClient
} from "/src/utils/clientTaxExemption.ts";
import { computeSalesAppliedTaxes } from "/src/utils/salesRelatedTaxComputation.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const buildItemTaxes = (item, clientTaxes, clientTaxCondition) => {
  if (!clientTaxes || clientTaxes.length === 0) return [];
  const taxBase = Number(item.quantity) * Number(item.unit_price) - (Number(item.discount_amount) || 0);
  return computeSalesAppliedTaxes({
    netBase: taxBase,
    clientTaxCondition,
    taxes: clientTaxes
  });
};
const defaultInitialData = {
  id: 0,
  credit_note_number: "",
  series: "",
  status: "1",
  issue_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  total_amount: 0,
  discount_amount: 0,
  exchange_rate: 1,
  client_id: null,
  salesperson_id: null,
  buyer_id: null,
  currency_id: null,
  sales_invoice_id: null,
  items: [],
  has_item_level_taxes: false,
  taxes: []
};
export const NotasCreditoFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData, saveItem } = useCrudItem(notasCreditoModuleConfig, id);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState([]);
  const [clientTaxes, setClientTaxes] = useState([]);
  const [clientTaxCondition, setClientTaxCondition] = useState(null);
  const [isClientTaxExempt, setIsClientTaxExempt] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const [isItemTaxModalOpen, setIsItemTaxModalOpen] = useState(false);
  const [currentItemIndexForTax, setCurrentItemIndexForTax] = useState(null);
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      if (loadedData.cae_number) {
        toast.error("No se puede editar una Nota de Crédito que ya tiene CAE.");
        navigate(getListReturnPath(notasCreditoModuleConfig.baseRoute));
        return;
      }
      const hydrated = {
        ...defaultInitialData,
        ...loadedData,
        // ✅ 2. Recuperamos la serie al editar
        series: loadedData.series,
        sales_invoice_number: loadedData.sales_invoice?.invoice_number,
        client_code: loadedData.client?.code,
        client_name: loadedData.client?.name,
        salesperson_code: loadedData.salesperson?.code,
        salesperson_name: loadedData.salesperson?.name
      };
      setFormData(hydrated);
      setItems(hydrated.items.map((i) => ({ ...i, tempId: crypto.randomUUID() })));
      if (loadedData.client_id) {
        getById(clientesModuleConfig.endpoint, loadedData.client_id).then((c) => {
          const exempt = isClientLeyExportacionTdfExempt(c);
          setIsClientTaxExempt(exempt);
          setClientTaxes(getEffectiveClientTaxes(c, c.relatedTaxes));
          setClientTaxCondition(c.tax ?? null);
          if (exempt) {
            setFormData((prev) => ({ ...prev, taxes: [], has_item_level_taxes: false }));
            setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
          }
        });
      }
    }
  }, [mode, loadedData, navigate]);
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((sum, i) => sum + Number(i.quantity) * Number(i.unit_price), 0);
    const totalDiscount = items.reduce((sum, i) => sum + (Number(i.discount_amount) || 0), 0);
    const globalDiscount = Number(formData.discount_amount) || 0;
    const taxBase = subtotal - totalDiscount - globalDiscount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (formData.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => {
          return sum + (item.taxes || []).reduce((tSum, t) => tSum + Number(t.amount), 0);
        }, 0);
      } else {
        totalTaxes = (formData.taxes || []).reduce((sum, t) => sum + Number(t.amount), 0);
      }
    }
    const total = isClientTaxExempt ? computeExemptDocumentTotal(subtotal, totalDiscount, globalDiscount) : taxBase + totalTaxes;
    return { subtotal, total, taxBase, totalTaxes };
  }, [items, formData.discount_amount, formData.taxes, formData.has_item_level_taxes, isClientTaxExempt]);
  useEffect(() => {
    if (isClientTaxExempt) {
      setFormData((prev) => prev.taxes?.length ? { ...prev, taxes: [] } : prev);
      return;
    }
    if (!formData.has_item_level_taxes && clientTaxes.length > 0) {
      const { taxBase } = calculatedTotals;
      const newAppliedTaxes = computeSalesAppliedTaxes({
        netBase: taxBase,
        clientTaxCondition,
        taxes: clientTaxes
      });
      setFormData((prev) => {
        const currentTotal = (prev.taxes || []).reduce((s, t) => s + Number(t.amount), 0);
        const newTotal = newAppliedTaxes.reduce((s, t) => s + Number(t.amount), 0);
        if (Math.abs(currentTotal - newTotal) > 0.01) {
          return { ...prev, taxes: newAppliedTaxes };
        }
        return prev;
      });
    }
  }, [calculatedTotals.taxBase, clientTaxes, formData.has_item_level_taxes, clientTaxCondition, isClientTaxExempt]);
  const handleInvoiceSelected = async (invoice) => {
    setLoading(true);
    try {
      const fullInvoice = await getById(salesInvoicesModuleConfig.endpoint, invoice.id);
      let loadedClientTaxes = [];
      let invoiceClientExempt = false;
      if (fullInvoice.client_id) {
        const client = await getById(clientesModuleConfig.endpoint, fullInvoice.client_id);
        invoiceClientExempt = isClientLeyExportacionTdfExempt(client);
        loadedClientTaxes = getEffectiveClientTaxes(client, client.relatedTaxes);
        setIsClientTaxExempt(invoiceClientExempt);
        setClientTaxCondition(client.tax ?? null);
        setClientTaxes(loadedClientTaxes);
      }
      setFormData((prev) => ({
        ...prev,
        sales_invoice_id: fullInvoice.id,
        sales_invoice_number: fullInvoice.invoice_number,
        // ✅ 3. Copiamos la serie de la factura automáticamente
        series: fullInvoice.series,
        client_id: fullInvoice.client_id,
        client_name: fullInvoice.client?.name,
        client_code: fullInvoice.client?.code,
        salesperson_id: fullInvoice.salesperson_id,
        salesperson_name: fullInvoice.salesperson?.name,
        salesperson_code: fullInvoice.salesperson?.code,
        buyer_id: fullInvoice.buyer_id,
        buyer_name: fullInvoice.buyer?.name,
        buyer_code: fullInvoice.buyer?.code,
        currency_id: fullInvoice.currency_id,
        currency_name: fullInvoice.currency?.name,
        currency_code: fullInvoice.currency?.code,
        exchange_rate: fullInvoice.exchange_rate,
        has_item_level_taxes: invoiceClientExempt ? false : fullInvoice.has_item_level_taxes,
        taxes: invoiceClientExempt ? [] : fullInvoice.taxes || []
      }));
      const newItems = fullInvoice.items.map((item) => ({
        ...item,
        tempId: crypto.randomUUID(),
        id: 0,
        taxes: invoiceClientExempt ? [] : item.taxes || []
      }));
      setItems(newItems);
      toast.success(`Factura cargada. Serie ${fullInvoice.series} copiada.`);
    } catch (error) {
      console.error(error);
      toast.error("Error al cargar los datos de la factura.");
    } finally {
      setLoading(false);
    }
  };
  const handleInvoiceCodeSubmit = async () => {
    const codeValue = formData.sales_invoice_number;
    if (!codeValue) return;
    setLoading(true);
    try {
      const result = await searchByField(
        salesInvoicesModuleConfig.endpoint,
        [{ fieldName: "invoice_number", value: codeValue }]
      );
      if (result) {
        await handleInvoiceSelected(result);
      } else {
        toast.error(`No se encontró ninguna factura con el número "${codeValue}".`);
        setFormData((prev) => ({
          ...prev,
          sales_invoice_id: null,
          series: "",
          // ✅ 4. Limpiamos serie si no encuentra
          client_id: null,
          client_name: "",
          items: []
        }));
        setItems([]);
      }
    } catch (error) {
      console.error(error);
      toast.error("Error al buscar la factura por código.");
    } finally {
      setLoading(false);
    }
  };
  const handleOpenSearch = (target, config) => {
    setEditingTarget(target);
    setModalConfig(config);
    setIsModalOpen(true);
  };
  const handleSelectFromModal = (item) => {
    if (editingTarget === "sales_invoice") {
      handleInvoiceSelected(item);
    }
    setIsModalOpen(false);
  };
  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    const newItem = { ...newItems[index], [field]: value };
    if (formData.has_item_level_taxes && !isClientTaxExempt && (field === "quantity" || field === "unit_price")) {
      newItem.taxes = buildItemTaxes(newItem, clientTaxes, clientTaxCondition);
    }
    newItems[index] = newItem;
    setItems(newItems);
  };
  const handleOpenItemTaxModal = (index) => {
    if (isClientTaxExempt) return;
    setCurrentItemIndexForTax(index);
    setIsItemTaxModalOpen(true);
  };
  const handleSaveItemTaxes = (taxes) => {
    if (currentItemIndexForTax === null) return;
    setItems((prev) => prev.map((item, index) => index === currentItemIndexForTax ? { ...item, taxes } : item));
    setCurrentItemIndexForTax(null);
    setIsItemTaxModalOpen(false);
  };
  const handleRemoveItem = (index) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };
  const handleSave = async () => {
    if (isSaving) return;
    if (!formData.client_id || items.length === 0) {
      toast.warn("Faltan datos obligatorios (Cliente o Ítems).");
      return;
    }
    if (!formData.series) {
      toast.warn("La Serie (Letra) es obligatoria.");
      return;
    }
    setIsSaving(true);
    const cleanItems = items.map(({ tempId, ...rest }) => rest);
    const sanitized = isClientTaxExempt ? sanitizeTaxPayloadForExemptClient({
      taxes: formData.taxes || [],
      items: cleanItems,
      has_item_level_taxes: formData.has_item_level_taxes
    }) : null;
    const payload = {
      ...formData,
      items: sanitized?.items ?? cleanItems,
      has_item_level_taxes: sanitized?.has_item_level_taxes ?? !!formData.has_item_level_taxes,
      total_amount: calculatedTotals.total,
      taxes: sanitized ? sanitized.taxes : !formData.has_item_level_taxes ? (formData.taxes || []).filter((t) => t.amount > 0) : []
    };
    try {
      const saved = await saveItem(payload);
      if (saved) {
        toast.success("Nota de Crédito generada con éxito.");
        navigate(getListReturnPath(notasCreditoModuleConfig.baseRoute));
      }
    } catch (e) {
      toast.error("Error al guardar.");
    } finally {
      setIsSaving(false);
    }
  };
  if (loadingData) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
    lineNumber: 372,
    columnNumber: 27
  }, this);
  const totalLabelStyle = "text-sm text-gray-700";
  const totalValueStyle = "text-sm font-semibold text-gray-800 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6 relative", children: [
    isSaving && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px] transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-6 bg-white shadow-xl rounded-2xl border border-indigo-100", children: [
      /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-10 h-10 text-indigo-600 animate-spin mb-3" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 384,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-800", children: "Conectando con ARCA" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 385,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 animate-pulse", children: "Obteniendo CAE y validando datos..." }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 386,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 383,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 382,
      columnNumber: 7
    }, this),
    isLoading && !isSaving && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px]", children: [
      /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-8 h-8 text-indigo-600 animate-spin mb-2" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 393,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Procesando..." }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 394,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 392,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Nueva Nota de Crédito" : `Editar Nota #${formData.credit_note_number}` }, void 0, false, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 398,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Factura Origen (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 407,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: formData.sales_invoice_number || "",
            nameValue: formData.sales_invoice_number ? `Factura ${formData.sales_invoice_number}` : "",
            onCodeChange: (c) => setFormData((prev) => ({ ...prev, sales_invoice_number: c })),
            onCodeSubmit: handleInvoiceCodeSubmit,
            onSearchClick: () => handleOpenSearch("sales_invoice", salesInvoicesModuleConfig),
            onClearClick: () => {
              setFormData(defaultInitialData);
              setItems([]);
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 408,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-1 text-xs text-blue-600", children: [
          /* @__PURE__ */ jsxDEV(FaInfoCircle, { className: "mr-1" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 417,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Escriba el Nº y presione Enter." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 418,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 416,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 406,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 flex space-x-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 425,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              maxLength: 1,
              placeholder: "A",
              value: formData.series || "",
              onChange: (e) => setFormData((prev) => ({ ...prev, series: e.target.value.toUpperCase() })),
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm text-center uppercase font-bold text-gray-700 focus:ring-indigo-500 focus:border-indigo-500",
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 426,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 424,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-2/3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Emisión" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 435,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: formData.issue_date || "",
              onChange: (e) => setFormData({ ...formData, issue_date: e.target.value }),
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm focus:ring-indigo-500 focus:border-indigo-500",
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 436,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 434,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 423,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 446,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "text", disabled: true, value: formData.client_name || "", autoComplete: "off", className: "mt-1 block w-full px-3 py-2 border border-gray-200 bg-gray-50 rounded-md text-gray-500 sm:text-sm" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 447,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 445,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 452,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "text", disabled: true, value: formData.salesperson_name || "", autoComplete: "off", className: "mt-1 block w-full px-3 py-2 bg-gray-50 border-gray-200 rounded-md sm:text-sm" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 453,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 451,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Moneda / Tasa" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 457,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV("input", { type: "text", disabled: true, value: formData.currency_name || "", autoComplete: "off", className: "mt-1 block w-1/2 px-3 py-2 bg-gray-50 border-gray-200 rounded-md sm:text-sm" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 459,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "number", disabled: true, value: formData.exchange_rate || 1, autoComplete: "off", className: "mt-1 block w-1/2 px-3 py-2 bg-gray-50 border-gray-200 rounded-md sm:text-sm" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 460,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 458,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 456,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 465,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 403,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Productos a Devolver" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 472,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 477,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 478,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Precio Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 479,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 480,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 482,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase", children: "Acción" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 484,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 476,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 475,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
          const itemTaxAmount = !isClientTaxExempt && formData.has_item_level_taxes ? (item.taxes || []).reduce((acc, t) => acc + Number(t.amount), 0) : 0;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: [
              item.product_name,
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 495,
                columnNumber: 65
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 494,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                value: item.quantity,
                onChange: (num) => handleItemChange(index, "quantity", num),
                className: "w-20 px-2 py-2 text-right border border-gray-300 rounded-md text-sm focus:ring-indigo-500 focus:border-indigo-500"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 498,
                columnNumber: 45
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 497,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 504,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-medium", children: formatValue(item.quantity * item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 507,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm text-gray-500", children: formatValue(itemTaxAmount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 511,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-center flex justify-center space-x-2", children: [
              !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenItemTaxModal(index), className: "p-1 text-indigo-600 hover:text-indigo-900", children: /* @__PURE__ */ jsxDEV(FaPercentage, {}, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 518,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 517,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveItem(index), className: "p-1 text-red-600 hover:text-red-900", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 522,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
                lineNumber: 521,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 515,
              columnNumber: 41
            }, this)
          ] }, item.tempId || index, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 493,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 487,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 474,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 473,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 471,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 536,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 3,
            autoComplete: "off",
            className: "mt-1 block w-full border border-gray-300 rounded-md shadow-sm sm:text-sm focus:ring-indigo-500 focus:border-indigo-500",
            value: formData.notes || "",
            onChange: (e) => setFormData({ ...formData, notes: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 537,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 535,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !formData.has_item_level_taxes && (formData.taxes || []).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-3 rounded-md border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-500 uppercase mb-2", children: "Impuestos Aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 548,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: (formData.taxes || []).map(
          (tax, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%)"
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 552,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-800", children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 553,
              columnNumber: 41
            }, this)
          ] }, idx, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 551,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 549,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 547,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 545,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 563,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 564,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 562,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 569,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 570,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 568,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Total Impuestos:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 573,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 574,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 572,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 567,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-900", children: "Total Devolución:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 579,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-indigo-600", children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 580,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 578,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 561,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 534,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(notasCreditoModuleConfig.baseRoute)), className: "px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
        lineNumber: 587,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: isLoading || isSaving,
          className: `inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white disabled:opacity-50 ${isSaving ? "bg-indigo-500 cursor-wait" : "bg-indigo-600 hover:bg-indigo-700"}`,
          children: isSaving ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 596,
              columnNumber: 29
            }, this),
            "Procesando en ARCA..."
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 595,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
              lineNumber: 601,
              columnNumber: 29
            }, this),
            " Generar Nota"
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
            lineNumber: 600,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
          lineNumber: 588,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 586,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => setIsModalOpen(false), onSelect: handleSelectFromModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 609,
      columnNumber: 7
    }, this),
    isItemTaxModalOpen && currentItemIndexForTax !== null && /* @__PURE__ */ jsxDEV(ItemTaxModal, { isOpen: isItemTaxModalOpen, onClose: () => setIsItemTaxModalOpen(false), onSave: handleSaveItemTaxes, item: items[currentItemIndexForTax], clientTaxes, clientTaxCondition }, void 0, false, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
      lineNumber: 612,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx",
    lineNumber: 379,
    columnNumber: 5
  }, this);
};
_s(NotasCreditoFormPage, "XcDlYuPfr6UY9ZK2FrSYAJZO6DM=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = NotasCreditoFormPage;
var _c;
$RefreshReg$(_c, "NotasCreditoFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito/pages/NotasCreditoFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1c0QixTQW1NSixVQW5NSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5VjVCLFNBQVNBLFVBQVVDLFdBQVdDLGVBQWU7QUFDN0MsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsV0FBV0MsU0FBU0MsY0FBY0Msb0JBQW9CO0FBQ3ZFLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxTQUFTQyxxQkFBcUI7QUFDdkMsU0FBU0MsZ0NBQWlEO0FBQzFELFNBQVNDLGlDQUFvRDtBQUM3RCxTQUFTQyw0QkFBMEM7QUFFbkQsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFFNUIsZUFBOEQ7QUFDOUQ7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLHlCQUF5QjtBQUdsQyxNQUFNQyxpQkFBaUJBLENBQ25CQyxNQUNBQyxhQUNBQyx1QkFDZTtBQUNmLE1BQUksQ0FBQ0QsZUFBZUEsWUFBWUUsV0FBVyxFQUFHLFFBQU87QUFDckQsUUFBTUMsVUFBV0MsT0FBT0wsS0FBS00sUUFBUSxJQUFJRCxPQUFPTCxLQUFLTyxVQUFVLEtBQU1GLE9BQU9MLEtBQUtRLGVBQWUsS0FBSztBQUNyRyxTQUFPWCx5QkFBeUI7QUFBQSxJQUM1QlksU0FBU0w7QUFBQUEsSUFDVEY7QUFBQUEsSUFDQVEsT0FBT1Q7QUFBQUEsRUFDWCxDQUFDO0FBQ0w7QUFHQSxNQUFNVSxxQkFBMEM7QUFBQSxFQUM1Q0MsSUFBSTtBQUFBLEVBQUdDLG9CQUFvQjtBQUFBLEVBQUlDLFFBQVE7QUFBQSxFQUFJQyxRQUFRO0FBQUEsRUFDbkRDLGFBQVksb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDakRDLGNBQWM7QUFBQSxFQUFHWixpQkFBaUI7QUFBQSxFQUFHYSxlQUFlO0FBQUEsRUFDcERDLFdBQVc7QUFBQSxFQUFNQyxnQkFBZ0I7QUFBQSxFQUFNQyxVQUFVO0FBQUEsRUFBTUMsYUFBYTtBQUFBLEVBQU1DLGtCQUFrQjtBQUFBLEVBQzVGQyxPQUFPO0FBQUEsRUFBSUMsc0JBQXNCO0FBQUEsRUFBT2xCLE9BQU87QUFDbkQ7QUFFTyxhQUFNbUIsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxFQUFFbEIsR0FBRyxJQUFJdEMsVUFBMEI7QUFDekMsUUFBTXlELFdBQVcxRCxZQUFZO0FBQzdCLFFBQU0yRCxPQUFPcEIsS0FBSyxTQUFTO0FBRTNCLFFBQU0sRUFBRVosTUFBTWlDLFlBQVlDLFNBQVNDLGFBQWFDLFNBQVMsSUFBSXZELFlBQXdCRywwQkFBMEI0QixFQUFFO0FBR2pILFFBQU0sQ0FBQ3lCLFVBQVVDLFdBQVcsSUFBSXBFLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNxRSxVQUFVQyxXQUFXLElBQUl0RSxTQUE4QnlDLGtCQUFrQjtBQUNoRixRQUFNLENBQUNnQixPQUFPYyxRQUFRLElBQUl2RSxTQUFnQixFQUFFO0FBQzVDLFFBQU0sQ0FBQytCLGFBQWF5QyxjQUFjLElBQUl4RSxTQUFzQixFQUFFO0FBQzlELFFBQU0sQ0FBQ2dDLG9CQUFvQnlDLHFCQUFxQixJQUFJekUsU0FBd0IsSUFBSTtBQUNoRixRQUFNLENBQUMwRSxtQkFBbUJDLG9CQUFvQixJQUFJM0UsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzRFLFdBQVdDLFVBQVUsSUFBSTdFLFNBQVMsS0FBSztBQUc5QyxRQUFNLENBQUM4RSxhQUFhQyxjQUFjLElBQUkvRSxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDZ0YsYUFBYUMsY0FBYyxJQUFJakYsU0FBbUMsSUFBSTtBQUM3RSxRQUFNLENBQUNrRixlQUFlQyxnQkFBZ0IsSUFBSW5GLFNBQXdCLElBQUk7QUFHdEUsUUFBTSxDQUFDb0Ysb0JBQW9CQyxxQkFBcUIsSUFBSXJGLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNzRix3QkFBd0JDLHlCQUF5QixJQUFJdkYsU0FBd0IsSUFBSTtBQUd4RkMsWUFBVSxNQUFNO0FBQ1osUUFBSTZELFNBQVMsVUFBVUMsWUFBWTtBQUUvQixVQUFJQSxXQUFXeUIsWUFBWTtBQUN2Qm5GLGNBQU1vRixNQUFNLDBEQUEwRDtBQUN0RTVCLGlCQUFTakMsa0JBQWtCZCx5QkFBeUI0RSxTQUFTLENBQUM7QUFDOUQ7QUFBQSxNQUNKO0FBRUEsWUFBTUMsV0FBVztBQUFBLFFBQ2IsR0FBR2xEO0FBQUFBLFFBQ0gsR0FBR3NCO0FBQUFBO0FBQUFBLFFBRUhuQixRQUFRbUIsV0FBV25CO0FBQUFBLFFBQ25CZ0Qsc0JBQXNCN0IsV0FBVzhCLGVBQWVDO0FBQUFBLFFBQ2hEQyxhQUFjaEMsV0FBV2lDLFFBQWdCQztBQUFBQSxRQUN6Q0MsYUFBYW5DLFdBQVdpQyxRQUFRRztBQUFBQSxRQUNoQ0Msa0JBQW1CckMsV0FBV3NDLGFBQXFCSjtBQUFBQSxRQUNuREssa0JBQWtCdkMsV0FBV3NDLGFBQWFGO0FBQUFBLE1BQzlDO0FBQ0E3QixrQkFBWXFCLFFBQVE7QUFDcEJwQixlQUFTb0IsU0FBU2xDLE1BQU04QyxJQUFJLENBQUFDLE9BQU0sRUFBRSxHQUFHQSxHQUFHQyxRQUFRQyxPQUFPQyxXQUFXLEVBQUUsRUFBRSxDQUFDO0FBRXpFLFVBQUk1QyxXQUFXWCxXQUFXO0FBQ3RCeEMsZ0JBQWlCSSxxQkFBcUI0RixVQUFVN0MsV0FBV1gsU0FBUyxFQUMvRHlELEtBQUssQ0FBQUMsTUFBSztBQUNQLGdCQUFNQyxTQUFTdEYsZ0NBQWdDcUYsQ0FBQztBQUNoRG5DLCtCQUFxQm9DLE1BQU07QUFDM0J2Qyx5QkFBZWhELHdCQUF3QnNGLEdBQUdBLEVBQUVFLFlBQVksQ0FBQztBQUN6RHZDLGdDQUFzQnFDLEVBQUVHLE9BQU8sSUFBSTtBQUNuQyxjQUFJRixRQUFRO0FBQ1J6Qyx3QkFBWSxDQUFBNEMsVUFBUyxFQUFFLEdBQUdBLE1BQU0xRSxPQUFPLElBQUlrQixzQkFBc0IsTUFBTSxFQUFFO0FBQ3pFYSxxQkFBUyxDQUFBMkMsU0FBUUEsS0FBS1gsSUFBSSxDQUFBekUsVUFBUyxFQUFFLEdBQUdBLE1BQU1VLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUMvRDtBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ1Q7QUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUNzQixNQUFNQyxZQUFZRixRQUFRLENBQUM7QUFHL0IsUUFBTXNELG1CQUFtQmpILFFBQVEsTUFBTTtBQUNuQyxVQUFNa0gsV0FBVzNELE1BQU00RCxPQUFPLENBQUNDLEtBQUtkLE1BQU1jLE1BQU9uRixPQUFPcUUsRUFBRXBFLFFBQVEsSUFBSUQsT0FBT3FFLEVBQUVuRSxVQUFVLEdBQUksQ0FBQztBQUM5RixVQUFNa0YsZ0JBQWdCOUQsTUFBTTRELE9BQU8sQ0FBQ0MsS0FBS2QsTUFBTWMsT0FBT25GLE9BQU9xRSxFQUFFbEUsZUFBZSxLQUFLLElBQUksQ0FBQztBQUN4RixVQUFNa0YsaUJBQWlCckYsT0FBT2tDLFNBQVMvQixlQUFlLEtBQUs7QUFDM0QsVUFBTUosVUFBVWtGLFdBQVdHLGdCQUFnQkM7QUFFM0MsUUFBSUMsYUFBYTtBQUNqQixRQUFJLENBQUMvQyxtQkFBbUI7QUFDcEIsVUFBSUwsU0FBU1gsc0JBQXNCO0FBQy9CK0QscUJBQWFoRSxNQUFNNEQsT0FBTyxDQUFDQyxLQUFLeEYsU0FBUztBQUNyQyxpQkFBT3dGLE9BQU94RixLQUFLVSxTQUFTLElBQUk2RSxPQUFPLENBQUNLLE1BQWNDLE1BQVdELE9BQU92RixPQUFPd0YsRUFBRUMsTUFBTSxHQUFHLENBQUM7QUFBQSxRQUMvRixHQUFHLENBQUM7QUFBQSxNQUNSLE9BQU87QUFDSEgsc0JBQWNwRCxTQUFTN0IsU0FBUyxJQUFJNkUsT0FBTyxDQUFDQyxLQUFLSyxNQUFNTCxNQUFNbkYsT0FBT3dGLEVBQUVDLE1BQU0sR0FBRyxDQUFDO0FBQUEsTUFDcEY7QUFBQSxJQUNKO0FBRUEsVUFBTUMsUUFBUW5ELG9CQUNSbkQsMkJBQTJCNkYsVUFBVUcsZUFBZUMsY0FBYyxJQUNsRXRGLFVBQVV1RjtBQUNoQixXQUFPLEVBQUVMLFVBQVVTLE9BQU8zRixTQUFTdUYsV0FBVztBQUFBLEVBQ2xELEdBQUcsQ0FBQ2hFLE9BQU9ZLFNBQVMvQixpQkFBaUIrQixTQUFTN0IsT0FBTzZCLFNBQVNYLHNCQUFzQmdCLGlCQUFpQixDQUFDO0FBR3RHekUsWUFBVSxNQUFNO0FBQ1osUUFBSXlFLG1CQUFtQjtBQUNuQkosa0JBQVksQ0FBQTRDLFNBQVNBLEtBQUsxRSxPQUFPUCxTQUFTLEVBQUUsR0FBR2lGLE1BQU0xRSxPQUFPLEdBQUcsSUFBSTBFLElBQUs7QUFDeEU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDN0MsU0FBU1gsd0JBQXdCM0IsWUFBWUUsU0FBUyxHQUFHO0FBQzFELFlBQU0sRUFBRUMsUUFBUSxJQUFJaUY7QUFDcEIsWUFBTVcsa0JBQWtCbkcseUJBQXlCO0FBQUEsUUFDN0NZLFNBQVNMO0FBQUFBLFFBQ1RGO0FBQUFBLFFBQ0FRLE9BQU9UO0FBQUFBLE1BQ1gsQ0FBQztBQUNEdUMsa0JBQVksQ0FBQTRDLFNBQVE7QUFDaEIsY0FBTWEsZ0JBQWdCYixLQUFLMUUsU0FBUyxJQUFJNkUsT0FBTyxDQUFDVyxHQUFHTCxNQUFNSyxJQUFJN0YsT0FBT3dGLEVBQUVDLE1BQU0sR0FBRyxDQUFDO0FBQ2hGLGNBQU1LLFdBQVdILGdCQUFnQlQsT0FBTyxDQUFDVyxHQUFHTCxNQUFNSyxJQUFJN0YsT0FBT3dGLEVBQUVDLE1BQU0sR0FBRyxDQUFDO0FBQ3pFLFlBQUlNLEtBQUtDLElBQUlKLGVBQWVFLFFBQVEsSUFBSSxNQUFNO0FBQzFDLGlCQUFPLEVBQUUsR0FBR2YsTUFBTTFFLE9BQU9zRixnQkFBZ0I7QUFBQSxRQUM3QztBQUNBLGVBQU9aO0FBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKLEdBQUcsQ0FBQ0MsaUJBQWlCakYsU0FBU0gsYUFBYXNDLFNBQVNYLHNCQUFzQjFCLG9CQUFvQjBDLGlCQUFpQixDQUFDO0FBTWhILFFBQU0wRCx3QkFBd0IsT0FBT0MsWUFBMEI7QUFDM0R4RCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsWUFBTXlELGNBQWMsTUFBTTFILFFBQXNCRywwQkFBMEI2RixVQUFVeUIsUUFBUTNGLEVBQUU7QUFFOUYsVUFBSTZGLG9CQUFpQztBQUNyQyxVQUFJQyxzQkFBc0I7QUFDMUIsVUFBSUYsWUFBWWxGLFdBQVc7QUFDdkIsY0FBTTRDLFNBQVMsTUFBTXBGLFFBQWlCSSxxQkFBcUI0RixVQUFVMEIsWUFBWWxGLFNBQVM7QUFDMUZvRiw4QkFBc0IvRyxnQ0FBZ0N1RSxNQUFNO0FBQzVEdUMsNEJBQW9CL0csd0JBQXdCd0UsUUFBUUEsT0FBT2dCLFlBQVk7QUFDdkVyQyw2QkFBcUI2RCxtQkFBbUI7QUFDeEMvRCw4QkFBc0J1QixPQUFPaUIsT0FBTyxJQUFJO0FBQ3hDekMsdUJBQWUrRCxpQkFBaUI7QUFBQSxNQUNwQztBQUVBakUsa0JBQVksQ0FBQTRDLFVBQVM7QUFBQSxRQUNqQixHQUFHQTtBQUFBQSxRQUNIMUQsa0JBQWtCOEUsWUFBWTVGO0FBQUFBLFFBQzlCa0Qsc0JBQXNCMEMsWUFBWXhDO0FBQUFBO0FBQUFBLFFBR2xDbEQsUUFBUTBGLFlBQVkxRjtBQUFBQSxRQUVwQlEsV0FBV2tGLFlBQVlsRjtBQUFBQSxRQUN2QjhDLGFBQWFvQyxZQUFZdEMsUUFBUUc7QUFBQUEsUUFDakNKLGFBQWN1QyxZQUFZdEMsUUFBZ0JDO0FBQUFBLFFBRTFDNUMsZ0JBQWdCaUYsWUFBWWpGO0FBQUFBLFFBQzVCaUQsa0JBQWtCZ0MsWUFBWWpDLGFBQWFGO0FBQUFBLFFBQzNDQyxrQkFBbUJrQyxZQUFZakMsYUFBcUJKO0FBQUFBLFFBRXBEM0MsVUFBVWdGLFlBQVloRjtBQUFBQSxRQUN0Qm1GLFlBQVlILFlBQVlJLE9BQU92QztBQUFBQSxRQUMvQndDLFlBQWFMLFlBQVlJLE9BQWV6QztBQUFBQSxRQUV4QzFDLGFBQWErRSxZQUFZL0U7QUFBQUEsUUFDekJxRixlQUFlTixZQUFZTyxVQUFVMUM7QUFBQUEsUUFDckMyQyxlQUFnQlIsWUFBWU8sVUFBa0I1QztBQUFBQSxRQUM5QzlDLGVBQWVtRixZQUFZbkY7QUFBQUEsUUFFM0JPLHNCQUFzQjhFLHNCQUFzQixRQUFRRixZQUFZNUU7QUFBQUEsUUFDaEVsQixPQUFPZ0csc0JBQXNCLEtBQU1GLFlBQVk5RixTQUFTO0FBQUEsTUFDNUQsRUFBRTtBQUVGLFlBQU11RyxXQUFXVCxZQUFZN0UsTUFBTThDLElBQUksQ0FBQXpFLFVBQVM7QUFBQSxRQUM1QyxHQUFHQTtBQUFBQSxRQUNIMkUsUUFBUUMsT0FBT0MsV0FBVztBQUFBLFFBQzFCakUsSUFBSTtBQUFBLFFBQ0pGLE9BQU9nRyxzQkFBc0IsS0FBTTFHLEtBQUtVLFNBQVM7QUFBQSxNQUNyRCxFQUFFO0FBQ0YrQixlQUFTd0UsUUFBUTtBQUVqQjFJLFlBQU0ySSxRQUFRLDBCQUEwQlYsWUFBWTFGLE1BQU0sV0FBVztBQUFBLElBRXpFLFNBQVM2QyxPQUFPO0FBQ1p3RCxjQUFReEQsTUFBTUEsS0FBSztBQUNuQnBGLFlBQU1vRixNQUFNLDBDQUEwQztBQUFBLElBQzFELFVBQUM7QUFDR1osaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU1xRSwwQkFBMEIsWUFBWTtBQUN4QyxVQUFNQyxZQUFZOUUsU0FBU3VCO0FBQzNCLFFBQUksQ0FBQ3VELFVBQVc7QUFFaEJ0RSxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsWUFBTXVFLFNBQVMsTUFBTXZJO0FBQUFBLFFBQ2pCRSwwQkFBMEI2RjtBQUFBQSxRQUMxQixDQUFDLEVBQUV5QyxXQUFXLGtCQUFrQkMsT0FBT0gsVUFBVSxDQUFDO0FBQUEsTUFDdEQ7QUFFQSxVQUFJQyxRQUFRO0FBQ1IsY0FBTWhCLHNCQUFzQmdCLE1BQU07QUFBQSxNQUN0QyxPQUFPO0FBQ0gvSSxjQUFNb0YsTUFBTSxpREFBaUQwRCxTQUFTLElBQUk7QUFDMUU3RSxvQkFBWSxDQUFBNEMsVUFBUztBQUFBLFVBQ2pCLEdBQUdBO0FBQUFBLFVBQ0gxRCxrQkFBa0I7QUFBQSxVQUNsQlosUUFBUTtBQUFBO0FBQUEsVUFDUlEsV0FBVztBQUFBLFVBQ1g4QyxhQUFhO0FBQUEsVUFDYnpDLE9BQU87QUFBQSxRQUNYLEVBQUU7QUFDRmMsaUJBQVMsRUFBRTtBQUFBLE1BQ2Y7QUFBQSxJQUNKLFNBQVNrQixPQUFPO0FBQ1p3RCxjQUFReEQsTUFBTUEsS0FBSztBQUNuQnBGLFlBQU1vRixNQUFNLHdDQUF3QztBQUFBLElBQ3hELFVBQUM7QUFDR1osaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU0wRSxtQkFBbUJBLENBQUNDLFFBQWdCQyxXQUE4QjtBQUNwRXRFLHFCQUFpQnFFLE1BQU07QUFDdkJ2RSxtQkFBZXdFLE1BQU07QUFDckIxRSxtQkFBZSxJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNMkUsd0JBQXdCQSxDQUFDNUgsU0FBYztBQUN6QyxRQUFJb0Qsa0JBQWtCLGlCQUFpQjtBQUNuQ2tELDRCQUFzQnRHLElBQUk7QUFBQSxJQUM5QjtBQUNBaUQsbUJBQWUsS0FBSztBQUFBLEVBQ3hCO0FBRUEsUUFBTTRFLG1CQUFtQkEsQ0FBQ0MsT0FBZUMsT0FBZVAsVUFBa0I7QUFDdEUsVUFBTVAsV0FBVyxDQUFDLEdBQUd0RixLQUFLO0FBQzFCLFVBQU1xRyxVQUFVLEVBQUUsR0FBR2YsU0FBU2EsS0FBSyxHQUFHLENBQUNDLEtBQUssR0FBR1AsTUFBTTtBQUNyRCxRQUFJakYsU0FBU1gsd0JBQXdCLENBQUNnQixzQkFBc0JtRixVQUFVLGNBQWNBLFVBQVUsZUFBZTtBQUN6R0MsY0FBUXRILFFBQVFYLGVBQWVpSSxTQUFTL0gsYUFBYUMsa0JBQWtCO0FBQUEsSUFDM0U7QUFDQStHLGFBQVNhLEtBQUssSUFBSUU7QUFDbEJ2RixhQUFTd0UsUUFBUTtBQUFBLEVBQ3JCO0FBR0EsUUFBTWdCLHlCQUF5QkEsQ0FBQ0gsVUFBa0I7QUFDOUMsUUFBSWxGLGtCQUFtQjtBQUN2QmEsOEJBQTBCcUUsS0FBSztBQUMvQnZFLDBCQUFzQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNMkUsc0JBQXNCQSxDQUFDeEgsVUFBd0I7QUFDakQsUUFBSThDLDJCQUEyQixLQUFNO0FBQ3JDZixhQUFTLENBQUEyQyxTQUFRQSxLQUFLWCxJQUFJLENBQUN6RSxNQUFNOEgsVUFBVUEsVUFBVXRFLHlCQUF5QixFQUFFLEdBQUd4RCxNQUFNVSxNQUFhLElBQUlWLElBQUksQ0FBQztBQUMvR3lELDhCQUEwQixJQUFJO0FBQzlCRiwwQkFBc0IsS0FBSztBQUFBLEVBQy9CO0FBRUEsUUFBTTRFLG1CQUFtQkEsQ0FBQ0wsVUFBa0I7QUFDeENyRixhQUFTLENBQUEyQyxTQUFRQSxLQUFLZ0QsT0FBTyxDQUFDQyxHQUFHM0QsTUFBTUEsTUFBTW9ELEtBQUssQ0FBQztBQUFBLEVBQ3ZEO0FBRUEsUUFBTVEsYUFBYSxZQUFZO0FBQzNCLFFBQUlqRyxTQUFVO0FBRWQsUUFBSSxDQUFDRSxTQUFTakIsYUFBYUssTUFBTXhCLFdBQVcsR0FBRztBQUMzQzVCLFlBQU1nSyxLQUFLLDhDQUE4QztBQUN6RDtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNoRyxTQUFTekIsUUFBUTtBQUNsQnZDLFlBQU1nSyxLQUFLLGtDQUFrQztBQUM3QztBQUFBLElBQ0o7QUFFQWpHLGdCQUFZLElBQUk7QUFDaEIsVUFBTWtHLGFBQWE3RyxNQUFNOEMsSUFBSSxDQUFDLEVBQUVFLFFBQVEsR0FBRzhELEtBQUssTUFBTUEsSUFBSTtBQUMxRCxVQUFNQyxZQUFZOUYsb0JBQ1poRCxrQ0FBa0M7QUFBQSxNQUNoQ2MsT0FBTzZCLFNBQVM3QixTQUFTO0FBQUEsTUFDekJpQixPQUFPNkc7QUFBQUEsTUFDUDVHLHNCQUFzQlcsU0FBU1g7QUFBQUEsSUFDbkMsQ0FBQyxJQUNDO0FBRU4sVUFBTStHLFVBQXNCO0FBQUEsTUFDeEIsR0FBSXBHO0FBQUFBLE1BQ0paLE9BQU8rRyxXQUFXL0csU0FBUzZHO0FBQUFBLE1BQzNCNUcsc0JBQXNCOEcsV0FBVzlHLHdCQUF3QixDQUFDLENBQUNXLFNBQVNYO0FBQUFBLE1BQ3BFUixjQUFjaUUsaUJBQWlCVTtBQUFBQSxNQUMvQnJGLE9BQU9nSSxZQUNEQSxVQUFVaEksUUFDVCxDQUFDNkIsU0FBU1gsd0JBQXdCVyxTQUFTN0IsU0FBUyxJQUFJMEgsT0FBTyxDQUFBdkMsTUFBS0EsRUFBRUMsU0FBUyxDQUFDLElBQUk7QUFBQSxJQUMvRjtBQUVBLFFBQUk7QUFDQSxZQUFNOEMsUUFBUSxNQUFNeEcsU0FBU3VHLE9BQU87QUFDcEMsVUFBSUMsT0FBTztBQUNQckssY0FBTTJJLFFBQVEscUNBQXFDO0FBQ25EbkYsaUJBQVNqQyxrQkFBa0JkLHlCQUF5QjRFLFNBQVMsQ0FBQztBQUFBLE1BQ2xFO0FBQUEsSUFDSixTQUFTaUYsR0FBRztBQUNSdEssWUFBTW9GLE1BQU0sbUJBQW1CO0FBQUEsSUFDbkMsVUFBQztBQUNHckIsa0JBQVksS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDSjtBQUVBLE1BQUlILFlBQWEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFHdkMsUUFBTTJHLGtCQUFrQjtBQUN4QixRQUFNQyxrQkFBa0I7QUFFeEIsU0FDSSx1QkFBQyxTQUFJLFdBQVUsK0RBRVYxRztBQUFBQSxnQkFDRyx1QkFBQyxTQUFJLFdBQVUsMElBQ1gsaUNBQUMsU0FBSSxXQUFVLDBGQUNYO0FBQUEsNkJBQUMsYUFBVSxXQUFVLGlEQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDbEUsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQyxtQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQ25FLHVCQUFDLE9BQUUsV0FBVSx1Q0FBc0MsbURBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxTQUgxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUdIUyxhQUFhLENBQUNULFlBQ1gsdUJBQUMsU0FBSSxXQUFVLDhHQUNYO0FBQUEsNkJBQUMsYUFBVSxXQUFVLCtDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLFNBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0osdUJBQUMsUUFBRyxXQUFVLHVDQUNUTCxtQkFBUyxXQUFXLDBCQUEwQixnQkFBZ0JPLFNBQVMxQixrQkFBa0IsTUFEOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBR1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLGtDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsUUFDN0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVcwQixTQUFTdUIsd0JBQXdCO0FBQUEsWUFDNUMsV0FBV3ZCLFNBQVN1Qix1QkFBdUIsV0FBV3ZCLFNBQVN1QixvQkFBb0IsS0FBSztBQUFBLFlBQ3hGLGNBQWMsQ0FBQ2tCLE1BQU14QyxZQUFZLENBQUE0QyxVQUFTLEVBQUUsR0FBR0EsTUFBTXRCLHNCQUFzQmtCLEVBQUUsRUFBRTtBQUFBLFlBQy9FLGNBQWNvQztBQUFBQSxZQUNkLGVBQWUsTUFBTUssaUJBQWlCLGlCQUFpQnhJLHlCQUF5QjtBQUFBLFlBQ2hGLGNBQWMsTUFBTTtBQUFFdUQsMEJBQVk3QixrQkFBa0I7QUFBRzhCLHVCQUFTLEVBQUU7QUFBQSxZQUFHO0FBQUE7QUFBQSxVQU56RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNMkU7QUFBQSxRQUUzRSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ1g7QUFBQSxpQ0FBQyxnQkFBYSxXQUFVLFVBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsVUFBSywrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLGFBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FDWDtBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMseUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVc7QUFBQSxjQUNYLGFBQVk7QUFBQSxjQUNaLE9BQU9GLFNBQVN6QixVQUFVO0FBQUEsY0FDMUIsVUFBVSxDQUFDK0gsTUFBTXJHLFlBQVksQ0FBQTRDLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEUsUUFBUStILEVBQUVuQixPQUFPRixNQUFNd0IsWUFBWSxFQUFFLEVBQUU7QUFBQSxjQUN4RixXQUFVO0FBQUEsY0FBaUwsY0FBYTtBQUFBO0FBQUEsWUFONU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTWlOO0FBQUEsYUFSck47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDWDtBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsVUFDeEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE9BQU96RyxTQUFTdkIsY0FBYztBQUFBLGNBQzlCLFVBQVUsQ0FBQzZILE1BQU1yRyxZQUFZLEVBQUUsR0FBR0QsVUFBVXZCLFlBQVk2SCxFQUFFbkIsT0FBT0YsTUFBTSxDQUFDO0FBQUEsY0FDeEUsV0FBVTtBQUFBLGNBQW1JLGNBQWE7QUFBQTtBQUFBLFlBSjlKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUltSztBQUFBLGFBTnZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNsRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxVQUFRLE1BQUMsT0FBT2pGLFNBQVM2QixlQUFlLElBQUksY0FBYSxPQUFNLFdBQVUsdUdBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0w7QUFBQSxXQUZuTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxVQUFRLE1BQUMsT0FBTzdCLFNBQVNpQyxvQkFBb0IsSUFBSSxjQUFhLE9BQU0sV0FBVSxrRkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSztBQUFBLFdBRm5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFLHVCQUFDLFNBQUksV0FBVSxjQUNYO0FBQUEsaUNBQUMsV0FBTSxNQUFLLFFBQU8sVUFBUSxNQUFDLE9BQU9qQyxTQUFTdUUsaUJBQWlCLElBQUksY0FBYSxPQUFNLFdBQVUsaUZBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJLO0FBQUEsVUFDM0ssdUJBQUMsV0FBTSxNQUFLLFVBQVMsVUFBUSxNQUFDLE9BQU92RSxTQUFTbEIsaUJBQWlCLEdBQUcsY0FBYSxPQUFNLFdBQVUsaUZBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRLO0FBQUEsYUFGaEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxtQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWhFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0RBQW1ELG9DQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFDckYsdUJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsbUVBQWtFLHdCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUscUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFDdEYsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSw0QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxVQUM3Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHdCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3hGLENBQUN1QixxQkFBcUJMLFNBQVNYLHdCQUM1Qix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHlCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBRTlGLHVCQUFDLFFBQUcsV0FBVSxxRUFBb0Usc0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsYUFSNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pELGdCQUFNOEMsSUFBSSxDQUFDekUsTUFBTThILFVBQVU7QUFDeEIsZ0JBQU1tQixnQkFBZ0IsQ0FBQ3JHLHFCQUFxQkwsU0FBU1gsd0JBQzlDNUIsS0FBS1UsU0FBUyxJQUFJNkUsT0FBTyxDQUFDMkQsS0FBYXJELE1BQVdxRCxNQUFNN0ksT0FBT3dGLEVBQUVDLE1BQU0sR0FBRyxDQUFDLElBQzVFO0FBQ04saUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxtQ0FDVDlGO0FBQUFBLG1CQUFLbUo7QUFBQUEsY0FBYTtBQUFBLGNBQUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsZ0JBQUVuSixLQUFLb0o7QUFBQUEsZ0JBQWE7QUFBQSxtQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csT0FBT3BKLEtBQUtNO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQStJLFFBQU94QixpQkFBaUJDLE9BQU8sWUFBWXVCLEdBQUc7QUFBQSxnQkFDeEQsV0FBVTtBQUFBO0FBQUEsY0FIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHaUksS0FKckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDhDQUNUN0osc0JBQVlRLEtBQUtPLFlBQVksVUFBVSxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsNENBQ1RmLHNCQUFZUSxLQUFLTSxXQUFXTixLQUFLTyxZQUFZLFVBQVUsS0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0MsQ0FBQ3FDLHFCQUFxQkwsU0FBU1gsd0JBQzVCLHVCQUFDLFFBQUcsV0FBVSw4Q0FDVHBDLHNCQUFZeUosZUFBZSxVQUFVLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVKLHVCQUFDLFFBQUcsV0FBVSx1REFDVDtBQUFBLGVBQUNyRyxxQkFBcUJMLFNBQVNYLHdCQUM1Qix1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1xRyx1QkFBdUJILEtBQUssR0FBRyxXQUFVLDZDQUMxRSxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVKLHVCQUFDLFlBQU8sU0FBUyxNQUFNSyxpQkFBaUJMLEtBQUssR0FBRyxXQUFVLHVDQUN0RCxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVEsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBL0JLOUgsS0FBSzJFLFVBQVVtRCxPQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLFFBRVIsQ0FBQyxLQXhDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsV0F0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQSxLQXhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeURBO0FBQUEsU0EzREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTREQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHVEQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxxQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFNO0FBQUEsWUFDTixjQUFhO0FBQUEsWUFBTSxXQUFVO0FBQUEsWUFDN0IsT0FBT3ZGLFNBQVMrRyxTQUFTO0FBQUEsWUFDekIsVUFBVSxDQUFBVCxNQUFLckcsWUFBWSxFQUFFLEdBQUdELFVBQVUrRyxPQUFPVCxFQUFFbkIsT0FBT0YsTUFBTSxDQUFDO0FBQUE7QUFBQSxVQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdUU7QUFBQSxXQU4zRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDVixXQUFDNUUscUJBQXFCLENBQUNMLFNBQVNYLHlCQUF5QlcsU0FBUzdCLFNBQVMsSUFBSVAsU0FBUyxLQUNyRix1QkFBQyxTQUFJLFdBQVUsb0RBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsa0RBQWlELG1DQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEYsdUJBQUMsU0FBSSxXQUFVLGFBQ1RvQyxvQkFBUzdCLFNBQVMsSUFBSStEO0FBQUFBLFVBQUksQ0FBQ1UsS0FBS29FLFFBQzlCLHVCQUFDLFNBQWMsV0FBVSxnQ0FDckI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWlCcEU7QUFBQUEsa0JBQUlxRTtBQUFBQSxjQUFTO0FBQUEsY0FBR3JFLElBQUlzRTtBQUFBQSxjQUFLO0FBQUEsaUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFDNUQsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QmpLLHNCQUFZMkYsSUFBSVcsUUFBUSxVQUFVLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsZUFGM0V5RCxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxRQUNILEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FaUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLGlDQUFDLFVBQUssV0FBV1QsaUJBQWlCLHlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQzNDLHVCQUFDLFVBQUssV0FBV0MsaUJBQWtCdkosc0JBQVk2RixpQkFBaUJDLFVBQVUsVUFBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLGFBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0MsQ0FBQzFDLHFCQUNFLG1DQUNJO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXLEdBQUdrRyxlQUFlLGtCQUFrQiwrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZUFBZSxrQkFBbUJ2SixzQkFBWTZGLGlCQUFpQmpGLFNBQVMsVUFBVSxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLGVBRjVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBVzBJLGlCQUFpQixnQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsY0FBR3ZKLFlBQVk2RixpQkFBaUJNLFlBQVksVUFBVTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUosdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1DQUFrQyxpQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxVQUFLLFdBQVUscUNBQXFDbkcsc0JBQVk2RixpQkFBaUJVLE9BQU8sVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRztBQUFBLGFBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1oRSxTQUFTakMsa0JBQWtCZCx5QkFBeUI0RSxTQUFTLENBQUMsR0FBRyxXQUFVLHFIQUFvSCx3QkFBcE87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0TztBQUFBLE1BQzVPO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTMEU7QUFBQUEsVUFDVCxVQUFVeEYsYUFBYVQ7QUFBQUEsVUFDdkIsV0FBVyx3SUFBd0lBLFdBQVcsOEJBQThCLG1DQUFtQztBQUFBLFVBRTlOQSxxQkFDRyxtQ0FDSTtBQUFBLG1DQUFDLGFBQVUsV0FBVSwrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQTtBQUFBLGVBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsSUFFQSxtQ0FDSTtBQUFBLG1DQUFDLFVBQU8sV0FBVSxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBLFlBQUc7QUFBQSxlQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQSxRQWRSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWdCQTtBQUFBLFNBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUdDVyxlQUFlRSxlQUNaLHVCQUFDLGVBQVksUUFBUUYsYUFBYSxTQUFTLE1BQU1DLGVBQWUsS0FBSyxHQUFHLFVBQVUyRSx1QkFBdUIsUUFBUTFFLGVBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkg7QUFBQSxJQUVoSUksc0JBQXNCRSwyQkFBMkIsUUFDOUMsdUJBQUMsZ0JBQWEsUUFBUUYsb0JBQW9CLFNBQVMsTUFBTUMsc0JBQXNCLEtBQUssR0FBRyxRQUFRMkUscUJBQXFCLE1BQU12RyxNQUFNNkIsc0JBQXNCLEdBQUcsYUFBMEIsc0JBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBME47QUFBQSxPQXpPbE87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJPQTtBQUVSO0FBQUUxQixHQS9oQldELHNCQUFvQjtBQUFBLFVBQ2R2RCxXQUNFRCxhQUc0Q1EsV0FBVztBQUFBO0FBQUE2SyxLQUwvRDdIO0FBQW9CLElBQUE2SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ0b2FzdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhVHJhc2giLCJGYUluZm9DaXJjbGUiLCJGYVBlcmNlbnRhZ2UiLCJ1c2VDcnVkSXRlbSIsImdldEJ5SWQiLCJzZWFyY2hCeUZpZWxkIiwibm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnIiwic2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZyIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwiUmVsYXRpb25hbElucHV0IiwiRGVjaW1hbElucHV0IiwiU2VhcmNoTW9kYWwiLCJJdGVtVGF4TW9kYWwiLCJMb2FkaW5nU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiY29tcHV0ZUV4ZW1wdERvY3VtZW50VG90YWwiLCJnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJzYW5pdGl6ZVRheFBheWxvYWRGb3JFeGVtcHRDbGllbnQiLCJjb21wdXRlU2FsZXNBcHBsaWVkVGF4ZXMiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImJ1aWxkSXRlbVRheGVzIiwiaXRlbSIsImNsaWVudFRheGVzIiwiY2xpZW50VGF4Q29uZGl0aW9uIiwibGVuZ3RoIiwidGF4QmFzZSIsIk51bWJlciIsInF1YW50aXR5IiwidW5pdF9wcmljZSIsImRpc2NvdW50X2Ftb3VudCIsIm5ldEJhc2UiLCJ0YXhlcyIsImRlZmF1bHRJbml0aWFsRGF0YSIsImlkIiwiY3JlZGl0X25vdGVfbnVtYmVyIiwic2VyaWVzIiwic3RhdHVzIiwiaXNzdWVfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwidG90YWxfYW1vdW50IiwiZXhjaGFuZ2VfcmF0ZSIsImNsaWVudF9pZCIsInNhbGVzcGVyc29uX2lkIiwiYnV5ZXJfaWQiLCJjdXJyZW5jeV9pZCIsInNhbGVzX2ludm9pY2VfaWQiLCJpdGVtcyIsImhhc19pdGVtX2xldmVsX3RheGVzIiwiTm90YXNDcmVkaXRvRm9ybVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwibW9kZSIsImxvYWRlZERhdGEiLCJsb2FkaW5nIiwibG9hZGluZ0RhdGEiLCJzYXZlSXRlbSIsImlzU2F2aW5nIiwic2V0SXNTYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0SXRlbXMiLCJzZXRDbGllbnRUYXhlcyIsInNldENsaWVudFRheENvbmRpdGlvbiIsImlzQ2xpZW50VGF4RXhlbXB0Iiwic2V0SXNDbGllbnRUYXhFeGVtcHQiLCJpc0xvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNNb2RhbE9wZW4iLCJzZXRJc01vZGFsT3BlbiIsIm1vZGFsQ29uZmlnIiwic2V0TW9kYWxDb25maWciLCJlZGl0aW5nVGFyZ2V0Iiwic2V0RWRpdGluZ1RhcmdldCIsImlzSXRlbVRheE1vZGFsT3BlbiIsInNldElzSXRlbVRheE1vZGFsT3BlbiIsImN1cnJlbnRJdGVtSW5kZXhGb3JUYXgiLCJzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4IiwiY2FlX251bWJlciIsImVycm9yIiwiYmFzZVJvdXRlIiwiaHlkcmF0ZWQiLCJzYWxlc19pbnZvaWNlX251bWJlciIsInNhbGVzX2ludm9pY2UiLCJpbnZvaWNlX251bWJlciIsImNsaWVudF9jb2RlIiwiY2xpZW50IiwiY29kZSIsImNsaWVudF9uYW1lIiwibmFtZSIsInNhbGVzcGVyc29uX2NvZGUiLCJzYWxlc3BlcnNvbiIsInNhbGVzcGVyc29uX25hbWUiLCJtYXAiLCJpIiwidGVtcElkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsImVuZHBvaW50IiwidGhlbiIsImMiLCJleGVtcHQiLCJyZWxhdGVkVGF4ZXMiLCJ0YXgiLCJwcmV2IiwiY2FsY3VsYXRlZFRvdGFscyIsInN1YnRvdGFsIiwicmVkdWNlIiwic3VtIiwidG90YWxEaXNjb3VudCIsImdsb2JhbERpc2NvdW50IiwidG90YWxUYXhlcyIsInRTdW0iLCJ0IiwiYW1vdW50IiwidG90YWwiLCJuZXdBcHBsaWVkVGF4ZXMiLCJjdXJyZW50VG90YWwiLCJzIiwibmV3VG90YWwiLCJNYXRoIiwiYWJzIiwiaGFuZGxlSW52b2ljZVNlbGVjdGVkIiwiaW52b2ljZSIsImZ1bGxJbnZvaWNlIiwibG9hZGVkQ2xpZW50VGF4ZXMiLCJpbnZvaWNlQ2xpZW50RXhlbXB0IiwiYnV5ZXJfbmFtZSIsImJ1eWVyIiwiYnV5ZXJfY29kZSIsImN1cnJlbmN5X25hbWUiLCJjdXJyZW5jeSIsImN1cnJlbmN5X2NvZGUiLCJuZXdJdGVtcyIsInN1Y2Nlc3MiLCJjb25zb2xlIiwiaGFuZGxlSW52b2ljZUNvZGVTdWJtaXQiLCJjb2RlVmFsdWUiLCJyZXN1bHQiLCJmaWVsZE5hbWUiLCJ2YWx1ZSIsImhhbmRsZU9wZW5TZWFyY2giLCJ0YXJnZXQiLCJjb25maWciLCJoYW5kbGVTZWxlY3RGcm9tTW9kYWwiLCJoYW5kbGVJdGVtQ2hhbmdlIiwiaW5kZXgiLCJmaWVsZCIsIm5ld0l0ZW0iLCJoYW5kbGVPcGVuSXRlbVRheE1vZGFsIiwiaGFuZGxlU2F2ZUl0ZW1UYXhlcyIsImhhbmRsZVJlbW92ZUl0ZW0iLCJmaWx0ZXIiLCJfIiwiaGFuZGxlU2F2ZSIsIndhcm4iLCJjbGVhbkl0ZW1zIiwicmVzdCIsInNhbml0aXplZCIsInBheWxvYWQiLCJzYXZlZCIsImUiLCJ0b3RhbExhYmVsU3R5bGUiLCJ0b3RhbFZhbHVlU3R5bGUiLCJ0b1VwcGVyQ2FzZSIsIml0ZW1UYXhBbW91bnQiLCJhY2MiLCJwcm9kdWN0X25hbWUiLCJwcm9kdWN0X2NvZGUiLCJudW0iLCJub3RlcyIsImlkeCIsInRheF9uYW1lIiwicmF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzQ3JlZGl0b0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnMgKi9cbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFTcGlubmVyLCBGYVRyYXNoLCBGYUluZm9DaXJjbGUsIEZhUGVyY2VudGFnZSB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgZ2V0QnlJZCwgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgbm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLCB0eXBlIENyZWRpdE5vdGUgfSBmcm9tICcuLi9ub3Rhc19jcmVkaXRvLmNvbmZpZyc7XG5pbXBvcnQgeyBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLCB0eXBlIFNhbGVzSW52b2ljZSB9IGZyb20gJy4uLy4uL2ZhY3R1cmFzX3ZlbnRhL2ZhY3R1cmFzX3ZlbnRhLmNvbmZpZyc7XG5pbXBvcnQgeyBjbGllbnRlc01vZHVsZUNvbmZpZywgdHlwZSBDbGllbnRlIH0gZnJvbSAnLi4vLi4vY2xpZW50ZXMvY2xpZW50ZXMuY29uZmlnJztcblxuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IEl0ZW1UYXhNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0l0ZW1UYXhNb2RhbCc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IHR5cGUgQXBwbGllZFRheCwgdHlwZSBSZWxhdGVkVGF4IGFzIENsaWVudFRheCB9IGZyb20gJy4uLy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQge1xuICAgIGNvbXB1dGVFeGVtcHREb2N1bWVudFRvdGFsLFxuICAgIGdldEVmZmVjdGl2ZUNsaWVudFRheGVzLFxuICAgIGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQsXG4gICAgc2FuaXRpemVUYXhQYXlsb2FkRm9yRXhlbXB0Q2xpZW50LFxufSBmcm9tICcuLi8uLi8uLi91dGlscy9jbGllbnRUYXhFeGVtcHRpb24nO1xuaW1wb3J0IHsgY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvc2FsZXNSZWxhdGVkVGF4Q29tcHV0YXRpb24nO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbi8vIEhlbHBlciBkZSBjw6FsY3VsbyBkZSBpbXB1ZXN0b3NcbmNvbnN0IGJ1aWxkSXRlbVRheGVzID0gKFxuICAgIGl0ZW06IHsgcXVhbnRpdHk6IG51bWJlcjsgdW5pdF9wcmljZTogbnVtYmVyOyBkaXNjb3VudF9hbW91bnQ/OiBudW1iZXIgfSxcbiAgICBjbGllbnRUYXhlczogQ2xpZW50VGF4W10sXG4gICAgY2xpZW50VGF4Q29uZGl0aW9uOiBzdHJpbmcgfCBudWxsXG4pOiBBcHBsaWVkVGF4W10gPT4ge1xuICAgIGlmICghY2xpZW50VGF4ZXMgfHwgY2xpZW50VGF4ZXMubGVuZ3RoID09PSAwKSByZXR1cm4gW107XG4gICAgY29uc3QgdGF4QmFzZSA9IChOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKSkgLSAoTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwKTtcbiAgICByZXR1cm4gY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgbmV0QmFzZTogdGF4QmFzZSxcbiAgICAgICAgY2xpZW50VGF4Q29uZGl0aW9uLFxuICAgICAgICB0YXhlczogY2xpZW50VGF4ZXMsXG4gICAgfSk7XG59O1xuXG4vLyDinIUgMS4gQWdyZWdhbW9zIHNlcmllcyBhbCBlc3RhZG8gaW5pY2lhbFxuY29uc3QgZGVmYXVsdEluaXRpYWxEYXRhOiBQYXJ0aWFsPENyZWRpdE5vdGU+ID0ge1xuICAgIGlkOiAwLCBjcmVkaXRfbm90ZV9udW1iZXI6ICcnLCBzZXJpZXM6ICcnLCBzdGF0dXM6ICcxJyxcbiAgICBpc3N1ZV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICB0b3RhbF9hbW91bnQ6IDAsIGRpc2NvdW50X2Ftb3VudDogMCwgZXhjaGFuZ2VfcmF0ZTogMSxcbiAgICBjbGllbnRfaWQ6IG51bGwsIHNhbGVzcGVyc29uX2lkOiBudWxsLCBidXllcl9pZDogbnVsbCwgY3VycmVuY3lfaWQ6IG51bGwsIHNhbGVzX2ludm9pY2VfaWQ6IG51bGwsXG4gICAgaXRlbXM6IFtdLCBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsIHRheGVzOiBbXVxufTtcblxuZXhwb3J0IGNvbnN0IE5vdGFzQ3JlZGl0b0Zvcm1QYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCB7IGl0ZW06IGxvYWRlZERhdGEsIGxvYWRpbmc6IGxvYWRpbmdEYXRhLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08Q3JlZGl0Tm90ZT4obm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICAvLyBFc3RhZG9zXG4gICAgY29uc3QgW2lzU2F2aW5nLCBzZXRJc1NhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZTxQYXJ0aWFsPENyZWRpdE5vdGU+PihkZWZhdWx0SW5pdGlhbERhdGEpO1xuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8YW55W10+KFtdKTtcbiAgICBjb25zdCBbY2xpZW50VGF4ZXMsIHNldENsaWVudFRheGVzXSA9IHVzZVN0YXRlPENsaWVudFRheFtdPihbXSk7XG4gICAgY29uc3QgW2NsaWVudFRheENvbmRpdGlvbiwgc2V0Q2xpZW50VGF4Q29uZGl0aW9uXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtpc0NsaWVudFRheEV4ZW1wdCwgc2V0SXNDbGllbnRUYXhFeGVtcHRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8gRXN0YWRvcyBNb2RhbGVzXG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21vZGFsQ29uZmlnLCBzZXRNb2RhbENvbmZpZ10gPSB1c2VTdGF0ZTxNb2R1bGVDb25maWc8YW55PiB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gICAgLy8gRXN0YWRvcyBwYXJhIE1vZGFsIGRlIEltcHVlc3RvcyBwb3Igw410ZW1cbiAgICBjb25zdCBbaXNJdGVtVGF4TW9kYWxPcGVuLCBzZXRJc0l0ZW1UYXhNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjdXJyZW50SXRlbUluZGV4Rm9yVGF4LCBzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4XSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuXG4gICAgLy8gQ2FyZ2EgaW5pY2lhbCBlbiBtb2RvIEVkaWNpw7NuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1vZGUgPT09ICdlZGl0JyAmJiBsb2FkZWREYXRhKSB7XG4gICAgICAgICAgICAvLyDim5QgU2kgeWEgdGllbmUgQ0FFLCBubyBwZXJtaXRpbW9zIGVkaXRhclxuICAgICAgICAgICAgaWYgKGxvYWRlZERhdGEuY2FlX251bWJlcikge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWVkZSBlZGl0YXIgdW5hIE5vdGEgZGUgQ3LDqWRpdG8gcXVlIHlhIHRpZW5lIENBRS4nKTtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChub3Rhc0NyZWRpdG9Nb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBoeWRyYXRlZCA9IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0SW5pdGlhbERhdGEsXG4gICAgICAgICAgICAgICAgLi4ubG9hZGVkRGF0YSxcbiAgICAgICAgICAgICAgICAvLyDinIUgMi4gUmVjdXBlcmFtb3MgbGEgc2VyaWUgYWwgZWRpdGFyXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBsb2FkZWREYXRhLnNlcmllcyxcbiAgICAgICAgICAgICAgICBzYWxlc19pbnZvaWNlX251bWJlcjogbG9hZGVkRGF0YS5zYWxlc19pbnZvaWNlPy5pbnZvaWNlX251bWJlcixcbiAgICAgICAgICAgICAgICBjbGllbnRfY29kZTogKGxvYWRlZERhdGEuY2xpZW50IGFzIGFueSk/LmNvZGUsXG4gICAgICAgICAgICAgICAgY2xpZW50X25hbWU6IGxvYWRlZERhdGEuY2xpZW50Py5uYW1lLFxuICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX2NvZGU6IChsb2FkZWREYXRhLnNhbGVzcGVyc29uIGFzIGFueSk/LmNvZGUsXG4gICAgICAgICAgICAgICAgc2FsZXNwZXJzb25fbmFtZTogbG9hZGVkRGF0YS5zYWxlc3BlcnNvbj8ubmFtZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzZXRGb3JtRGF0YShoeWRyYXRlZCk7XG4gICAgICAgICAgICBzZXRJdGVtcyhoeWRyYXRlZC5pdGVtcy5tYXAoaSA9PiAoeyAuLi5pLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfSkpKTtcblxuICAgICAgICAgICAgaWYgKGxvYWRlZERhdGEuY2xpZW50X2lkKSB7XG4gICAgICAgICAgICAgICAgZ2V0QnlJZDxDbGllbnRlPihjbGllbnRlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgbG9hZGVkRGF0YS5jbGllbnRfaWQpXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKGMgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhlbXB0ID0gaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdChjKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGV4ZW1wdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyhjLCBjLnJlbGF0ZWRUYXhlcykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGMudGF4ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgdGF4ZXM6IFtdLCBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiAoeyAuLi5pdGVtLCB0YXhlczogW10gfSkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbbW9kZSwgbG9hZGVkRGF0YSwgbmF2aWdhdGVdKTtcblxuICAgIC8vIC0tLSBDw4FMQ1VMT1MgQ09NUExFVE9TIC0tLVxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaSkgPT4gc3VtICsgKE51bWJlcihpLnF1YW50aXR5KSAqIE51bWJlcihpLnVuaXRfcHJpY2UpKSwgMCk7XG4gICAgICAgIGNvbnN0IHRvdGFsRGlzY291bnQgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaSkgPT4gc3VtICsgKE51bWJlcihpLmRpc2NvdW50X2Ftb3VudCkgfHwgMCksIDApO1xuICAgICAgICBjb25zdCBnbG9iYWxEaXNjb3VudCA9IE51bWJlcihmb3JtRGF0YS5kaXNjb3VudF9hbW91bnQpIHx8IDA7XG4gICAgICAgIGNvbnN0IHRheEJhc2UgPSBzdWJ0b3RhbCAtIHRvdGFsRGlzY291bnQgLSBnbG9iYWxEaXNjb3VudDtcblxuICAgICAgICBsZXQgdG90YWxUYXhlcyA9IDA7XG4gICAgICAgIGlmICghaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3VtICsgKGl0ZW0udGF4ZXMgfHwgW10pLnJlZHVjZSgodFN1bTogbnVtYmVyLCB0OiBhbnkpID0+IHRTdW0gKyBOdW1iZXIodC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG90YWxUYXhlcyA9IChmb3JtRGF0YS50YXhlcyB8fCBbXSkucmVkdWNlKChzdW0sIHQpID0+IHN1bSArIE51bWJlcih0LmFtb3VudCksIDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdG90YWwgPSBpc0NsaWVudFRheEV4ZW1wdFxuICAgICAgICAgICAgPyBjb21wdXRlRXhlbXB0RG9jdW1lbnRUb3RhbChzdWJ0b3RhbCwgdG90YWxEaXNjb3VudCwgZ2xvYmFsRGlzY291bnQpXG4gICAgICAgICAgICA6IHRheEJhc2UgKyB0b3RhbFRheGVzO1xuICAgICAgICByZXR1cm4geyBzdWJ0b3RhbCwgdG90YWwsIHRheEJhc2UsIHRvdGFsVGF4ZXMgfTtcbiAgICB9LCBbaXRlbXMsIGZvcm1EYXRhLmRpc2NvdW50X2Ftb3VudCwgZm9ybURhdGEudGF4ZXMsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG4gICAgLy8gUmVjw6FsY3VsbyBkZSBpbXB1ZXN0b3MgZ2xvYmFsZXNcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHByZXYudGF4ZXM/Lmxlbmd0aCA/IHsgLi4ucHJldiwgdGF4ZXM6IFtdIH0gOiBwcmV2KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiBjbGllbnRUYXhlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCB7IHRheEJhc2UgfSA9IGNhbGN1bGF0ZWRUb3RhbHM7XG4gICAgICAgICAgICBjb25zdCBuZXdBcHBsaWVkVGF4ZXMgPSBjb21wdXRlU2FsZXNBcHBsaWVkVGF4ZXMoe1xuICAgICAgICAgICAgICAgIG5ldEJhc2U6IHRheEJhc2UsXG4gICAgICAgICAgICAgICAgY2xpZW50VGF4Q29uZGl0aW9uLFxuICAgICAgICAgICAgICAgIHRheGVzOiBjbGllbnRUYXhlcyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFRvdGFsID0gKHByZXYudGF4ZXMgfHwgW10pLnJlZHVjZSgocywgdCkgPT4gcyArIE51bWJlcih0LmFtb3VudCksIDApO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5ld1RvdGFsID0gbmV3QXBwbGllZFRheGVzLnJlZHVjZSgocywgdCkgPT4gcyArIE51bWJlcih0LmFtb3VudCksIDApO1xuICAgICAgICAgICAgICAgIGlmIChNYXRoLmFicyhjdXJyZW50VG90YWwgLSBuZXdUb3RhbCkgPiAwLjAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLnByZXYsIHRheGVzOiBuZXdBcHBsaWVkVGF4ZXMgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFtjYWxjdWxhdGVkVG90YWxzLnRheEJhc2UsIGNsaWVudFRheGVzLCBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcywgY2xpZW50VGF4Q29uZGl0aW9uLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG5cbiAgICAvLyAtLS0gSEFORExFUlMgLS0tXG5cbiAgICAvLyAxLiBMw7NnaWNhIGNlbnRyYWwgZGUgY2FyZ2EgZGUgRmFjdHVyYVxuICAgIGNvbnN0IGhhbmRsZUludm9pY2VTZWxlY3RlZCA9IGFzeW5jIChpbnZvaWNlOiBTYWxlc0ludm9pY2UpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxJbnZvaWNlID0gYXdhaXQgZ2V0QnlJZDxTYWxlc0ludm9pY2U+KHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGludm9pY2UuaWQpO1xuXG4gICAgICAgICAgICBsZXQgbG9hZGVkQ2xpZW50VGF4ZXM6IENsaWVudFRheFtdID0gW107XG4gICAgICAgICAgICBsZXQgaW52b2ljZUNsaWVudEV4ZW1wdCA9IGZhbHNlO1xuICAgICAgICAgICAgaWYgKGZ1bGxJbnZvaWNlLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IGdldEJ5SWQ8Q2xpZW50ZT4oY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGZ1bGxJbnZvaWNlLmNsaWVudF9pZCk7XG4gICAgICAgICAgICAgICAgaW52b2ljZUNsaWVudEV4ZW1wdCA9IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQoY2xpZW50KTtcbiAgICAgICAgICAgICAgICBsb2FkZWRDbGllbnRUYXhlcyA9IGdldEVmZmVjdGl2ZUNsaWVudFRheGVzKGNsaWVudCwgY2xpZW50LnJlbGF0ZWRUYXhlcyk7XG4gICAgICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoaW52b2ljZUNsaWVudEV4ZW1wdCk7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGNsaWVudC50YXggPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMobG9hZGVkQ2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICBzYWxlc19pbnZvaWNlX2lkOiBmdWxsSW52b2ljZS5pZCxcbiAgICAgICAgICAgICAgICBzYWxlc19pbnZvaWNlX251bWJlcjogZnVsbEludm9pY2UuaW52b2ljZV9udW1iZXIsXG5cbiAgICAgICAgICAgICAgICAvLyDinIUgMy4gQ29waWFtb3MgbGEgc2VyaWUgZGUgbGEgZmFjdHVyYSBhdXRvbcOhdGljYW1lbnRlXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBmdWxsSW52b2ljZS5zZXJpZXMsXG5cbiAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IGZ1bGxJbnZvaWNlLmNsaWVudF9pZCxcbiAgICAgICAgICAgICAgICBjbGllbnRfbmFtZTogZnVsbEludm9pY2UuY2xpZW50Py5uYW1lLFxuICAgICAgICAgICAgICAgIGNsaWVudF9jb2RlOiAoZnVsbEludm9pY2UuY2xpZW50IGFzIGFueSk/LmNvZGUsXG5cbiAgICAgICAgICAgICAgICBzYWxlc3BlcnNvbl9pZDogZnVsbEludm9pY2Uuc2FsZXNwZXJzb25faWQsXG4gICAgICAgICAgICAgICAgc2FsZXNwZXJzb25fbmFtZTogZnVsbEludm9pY2Uuc2FsZXNwZXJzb24/Lm5hbWUsXG4gICAgICAgICAgICAgICAgc2FsZXNwZXJzb25fY29kZTogKGZ1bGxJbnZvaWNlLnNhbGVzcGVyc29uIGFzIGFueSk/LmNvZGUsXG5cbiAgICAgICAgICAgICAgICBidXllcl9pZDogZnVsbEludm9pY2UuYnV5ZXJfaWQsXG4gICAgICAgICAgICAgICAgYnV5ZXJfbmFtZTogZnVsbEludm9pY2UuYnV5ZXI/Lm5hbWUsXG4gICAgICAgICAgICAgICAgYnV5ZXJfY29kZTogKGZ1bGxJbnZvaWNlLmJ1eWVyIGFzIGFueSk/LmNvZGUsXG5cbiAgICAgICAgICAgICAgICBjdXJyZW5jeV9pZDogZnVsbEludm9pY2UuY3VycmVuY3lfaWQsXG4gICAgICAgICAgICAgICAgY3VycmVuY3lfbmFtZTogZnVsbEludm9pY2UuY3VycmVuY3k/Lm5hbWUsXG4gICAgICAgICAgICAgICAgY3VycmVuY3lfY29kZTogKGZ1bGxJbnZvaWNlLmN1cnJlbmN5IGFzIGFueSk/LmNvZGUsXG4gICAgICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogZnVsbEludm9pY2UuZXhjaGFuZ2VfcmF0ZSxcblxuICAgICAgICAgICAgICAgIGhhc19pdGVtX2xldmVsX3RheGVzOiBpbnZvaWNlQ2xpZW50RXhlbXB0ID8gZmFsc2UgOiBmdWxsSW52b2ljZS5oYXNfaXRlbV9sZXZlbF90YXhlcyxcbiAgICAgICAgICAgICAgICB0YXhlczogaW52b2ljZUNsaWVudEV4ZW1wdCA/IFtdIDogKGZ1bGxJbnZvaWNlLnRheGVzIHx8IFtdKSxcbiAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBmdWxsSW52b2ljZS5pdGVtcy5tYXAoaXRlbSA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgIGlkOiAwLFxuICAgICAgICAgICAgICAgIHRheGVzOiBpbnZvaWNlQ2xpZW50RXhlbXB0ID8gW10gOiAoaXRlbS50YXhlcyB8fCBbXSksXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzZXRJdGVtcyhuZXdJdGVtcyk7XG5cbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYEZhY3R1cmEgY2FyZ2FkYS4gU2VyaWUgJHtmdWxsSW52b2ljZS5zZXJpZXN9IGNvcGlhZGEuYCk7XG5cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgbG9zIGRhdG9zIGRlIGxhIGZhY3R1cmEuXCIpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSW52b2ljZUNvZGVTdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvZGVWYWx1ZSA9IGZvcm1EYXRhLnNhbGVzX2ludm9pY2VfbnVtYmVyO1xuICAgICAgICBpZiAoIWNvZGVWYWx1ZSkgcmV0dXJuO1xuXG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPFNhbGVzSW52b2ljZT4oXG4gICAgICAgICAgICAgICAgc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6ICdpbnZvaWNlX251bWJlcicsIHZhbHVlOiBjb2RlVmFsdWUgfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBoYW5kbGVJbnZvaWNlU2VsZWN0ZWQocmVzdWx0KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyBuaW5ndW5hIGZhY3R1cmEgY29uIGVsIG7Dum1lcm8gXCIke2NvZGVWYWx1ZX1cIi5gKTtcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzX2ludm9pY2VfaWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHNlcmllczogJycsIC8vIOKchSA0LiBMaW1waWFtb3Mgc2VyaWUgc2kgbm8gZW5jdWVudHJhXG4gICAgICAgICAgICAgICAgICAgIGNsaWVudF9pZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgY2xpZW50X25hbWU6ICcnLFxuICAgICAgICAgICAgICAgICAgICBpdGVtczogW11cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGJ1c2NhciBsYSBmYWN0dXJhIHBvciBjw7NkaWdvLlwiKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZU9wZW5TZWFyY2ggPSAodGFyZ2V0OiBzdHJpbmcsIGNvbmZpZzogTW9kdWxlQ29uZmlnPGFueT4pID0+IHtcbiAgICAgICAgc2V0RWRpdGluZ1RhcmdldCh0YXJnZXQpO1xuICAgICAgICBzZXRNb2RhbENvbmZpZyhjb25maWcpO1xuICAgICAgICBzZXRJc01vZGFsT3Blbih0cnVlKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0RnJvbU1vZGFsID0gKGl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ3NhbGVzX2ludm9pY2UnKSB7XG4gICAgICAgICAgICBoYW5kbGVJbnZvaWNlU2VsZWN0ZWQoaXRlbSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVJdGVtQ2hhbmdlID0gKGluZGV4OiBudW1iZXIsIGZpZWxkOiBzdHJpbmcsIHZhbHVlOiBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBbLi4uaXRlbXNdO1xuICAgICAgICBjb25zdCBuZXdJdGVtID0geyAuLi5uZXdJdGVtc1tpbmRleF0sIFtmaWVsZF06IHZhbHVlIH07XG4gICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAhaXNDbGllbnRUYXhFeGVtcHQgJiYgKGZpZWxkID09PSAncXVhbnRpdHknIHx8IGZpZWxkID09PSAndW5pdF9wcmljZScpKSB7XG4gICAgICAgICAgICBuZXdJdGVtLnRheGVzID0gYnVpbGRJdGVtVGF4ZXMobmV3SXRlbSwgY2xpZW50VGF4ZXMsIGNsaWVudFRheENvbmRpdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gbmV3SXRlbTtcbiAgICAgICAgc2V0SXRlbXMobmV3SXRlbXMpO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGVycyBwYXJhIGltcHVlc3Rvc1xuICAgIGNvbnN0IGhhbmRsZU9wZW5JdGVtVGF4TW9kYWwgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBpZiAoaXNDbGllbnRUYXhFeGVtcHQpIHJldHVybjtcbiAgICAgICAgc2V0Q3VycmVudEl0ZW1JbmRleEZvclRheChpbmRleCk7XG4gICAgICAgIHNldElzSXRlbVRheE1vZGFsT3Blbih0cnVlKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZUl0ZW1UYXhlcyA9ICh0YXhlczogQXBwbGllZFRheFtdKSA9PiB7XG4gICAgICAgIGlmIChjdXJyZW50SXRlbUluZGV4Rm9yVGF4ID09PSBudWxsKSByZXR1cm47XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoKGl0ZW0sIGluZGV4KSA9PiBpbmRleCA9PT0gY3VycmVudEl0ZW1JbmRleEZvclRheCA/IHsgLi4uaXRlbSwgdGF4ZXM6IHRheGVzIH0gOiBpdGVtKSk7XG4gICAgICAgIHNldEN1cnJlbnRJdGVtSW5kZXhGb3JUYXgobnVsbCk7XG4gICAgICAgIHNldElzSXRlbVRheE1vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUl0ZW0gPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoaXNTYXZpbmcpIHJldHVybjtcblxuICAgICAgICBpZiAoIWZvcm1EYXRhLmNsaWVudF9pZCB8fCBpdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oXCJGYWx0YW4gZGF0b3Mgb2JsaWdhdG9yaW9zIChDbGllbnRlIG8gw410ZW1zKS5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5zZXJpZXMpIHsgLy8g4pyFIFZhbGlkYWNpw7NuIGRlIHNlcmllXG4gICAgICAgICAgICB0b2FzdC53YXJuKFwiTGEgU2VyaWUgKExldHJhKSBlcyBvYmxpZ2F0b3JpYS5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc1NhdmluZyh0cnVlKTtcbiAgICAgICAgY29uc3QgY2xlYW5JdGVtcyA9IGl0ZW1zLm1hcCgoeyB0ZW1wSWQsIC4uLnJlc3QgfSkgPT4gcmVzdCk7XG4gICAgICAgIGNvbnN0IHNhbml0aXplZCA9IGlzQ2xpZW50VGF4RXhlbXB0XG4gICAgICAgICAgICA/IHNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCh7XG4gICAgICAgICAgICAgICAgdGF4ZXM6IGZvcm1EYXRhLnRheGVzIHx8IFtdLFxuICAgICAgICAgICAgICAgIGl0ZW1zOiBjbGVhbkl0ZW1zLFxuICAgICAgICAgICAgICAgIGhhc19pdGVtX2xldmVsX3RheGVzOiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICA6IG51bGw7XG5cbiAgICAgICAgY29uc3QgcGF5bG9hZDogQ3JlZGl0Tm90ZSA9IHtcbiAgICAgICAgICAgIC4uLihmb3JtRGF0YSBhcyBDcmVkaXROb3RlKSxcbiAgICAgICAgICAgIGl0ZW1zOiBzYW5pdGl6ZWQ/Lml0ZW1zID8/IGNsZWFuSXRlbXMsXG4gICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogc2FuaXRpemVkPy5oYXNfaXRlbV9sZXZlbF90YXhlcyA/PyAhIWZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLFxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiBjYWxjdWxhdGVkVG90YWxzLnRvdGFsLFxuICAgICAgICAgICAgdGF4ZXM6IHNhbml0aXplZFxuICAgICAgICAgICAgICAgID8gc2FuaXRpemVkLnRheGVzXG4gICAgICAgICAgICAgICAgOiAoIWZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzID8gKGZvcm1EYXRhLnRheGVzIHx8IFtdKS5maWx0ZXIodCA9PiB0LmFtb3VudCA+IDApIDogW10pLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBzYXZlZCA9IGF3YWl0IHNhdmVJdGVtKHBheWxvYWQpO1xuICAgICAgICAgICAgaWYgKHNhdmVkKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIk5vdGEgZGUgQ3LDqWRpdG8gZ2VuZXJhZGEgY29uIMOpeGl0by5cIik7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGd1YXJkYXIuXCIpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNTYXZpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nRGF0YSkgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcblxuICAgIC8vIEVzdGlsb3NcbiAgICBjb25zdCB0b3RhbExhYmVsU3R5bGUgPSBcInRleHQtc20gdGV4dC1ncmF5LTcwMFwiO1xuICAgIGNvbnN0IHRvdGFsVmFsdWVTdHlsZSA9IFwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1yaWdodFwiO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktNiByZWxhdGl2ZVwiPlxuXG4gICAgICAgICAgICB7aXNTYXZpbmcgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTUwIGJnLXdoaXRlLzgwIHJvdW5kZWQtbGcgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmFja2Ryb3AtYmx1ci1bMXB4XSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBwLTYgYmctd2hpdGUgc2hhZG93LXhsIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItaW5kaWdvLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1pbmRpZ28tNjAwIGFuaW1hdGUtc3BpbiBtYi0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+Q29uZWN0YW5kbyBjb24gQVJDQTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgYW5pbWF0ZS1wdWxzZVwiPk9idGVuaWVuZG8gQ0FFIHkgdmFsaWRhbmRvIGRhdG9zLi4uPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtpc0xvYWRpbmcgJiYgIWlzU2F2aW5nICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgei01MCBiZy13aGl0ZS84MCByb3VuZGVkLWxnIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJhY2tkcm9wLWJsdXItWzFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtaW5kaWdvLTYwMCBhbmltYXRlLXNwaW4gbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlByb2Nlc2FuZG8uLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZScgPyAnTnVldmEgTm90YSBkZSBDcsOpZGl0bycgOiBgRWRpdGFyIE5vdGEgIyR7Zm9ybURhdGEuY3JlZGl0X25vdGVfbnVtYmVyfWB9XG4gICAgICAgICAgICA8L2gxPlxuXG4gICAgICAgICAgICB7LyogQ0FCRUNFUkEgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cblxuICAgICAgICAgICAgICAgIHsvKiBDT0xVTU5BIDE6IEZhY3R1cmEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GYWN0dXJhIE9yaWdlbiAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLnNhbGVzX2ludm9pY2VfbnVtYmVyIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5zYWxlc19pbnZvaWNlX251bWJlciA/IGBGYWN0dXJhICR7Zm9ybURhdGEuc2FsZXNfaW52b2ljZV9udW1iZXJ9YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBzYWxlc19pbnZvaWNlX251bWJlcjogYyB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZUludm9pY2VDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3BlblNlYXJjaCgnc2FsZXNfaW52b2ljZScsIHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7IHNldEZvcm1EYXRhKGRlZmF1bHRJbml0aWFsRGF0YSk7IHNldEl0ZW1zKFtdKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC0xIHRleHQteHMgdGV4dC1ibHVlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhSW5mb0NpcmNsZSBjbGFzc05hbWU9XCJtci0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkVzY3JpYmEgZWwgTsK6IHkgcHJlc2lvbmUgRW50ZXIuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiDinIUgNS4gQ09MVU1OQSAyOiBTZXJpZSB5IEZlY2hhIChBZ3J1cGFkb3MgcGFyYSBhcHJvdmVjaGFyIGVzcGFjaW8pICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBmbGV4IHNwYWNlLXgtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+U2VyaWUgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2VyaWVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBzZXJpZXM6IGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc20gdGV4dC1jZW50ZXIgdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMi8zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmVjaGEgRW1pc2nDs248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5pc3N1ZV9kYXRlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgaXNzdWVfZGF0ZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDT0xVTU5BIDM6IENsaWVudGUgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5DbGllbnRlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgZGlzYWJsZWQgdmFsdWU9e2Zvcm1EYXRhLmNsaWVudF9uYW1lIHx8ICcnfSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy1ncmF5LTUwIHJvdW5kZWQtbWQgdGV4dC1ncmF5LTUwMCBzbTp0ZXh0LXNtXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBGSUxBIDIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5WZW5kZWRvcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGRpc2FibGVkIHZhbHVlPXtmb3JtRGF0YS5zYWxlc3BlcnNvbl9uYW1lIHx8ICcnfSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYmctZ3JheS01MCBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1tZCBzbTp0ZXh0LXNtXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TW9uZWRhIC8gVGFzYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgZGlzYWJsZWQgdmFsdWU9e2Zvcm1EYXRhLmN1cnJlbmN5X25hbWUgfHwgJyd9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy0xLzIgcHgtMyBweS0yIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbWQgc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIGRpc2FibGVkIHZhbHVlPXtmb3JtRGF0YS5leGNoYW5nZV9yYXRlIHx8IDF9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy0xLzIgcHgtMyBweS0yIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbWQgc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEVzcGFjaW8gbGlicmUgbyBOb3RhIHLDoXBpZGEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBQbGFjZWhvbGRlciBwYXJhIGJhbGFuY2VhciBsYSBncmlkIHNpIGVzIG5lY2VzYXJpbyAqL31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogVEFCTEEgREUgw41URU1TICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDAgbWItNFwiPlByb2R1Y3RvcyBhIERldm9sdmVyPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+UHJvZHVjdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5QcmVjaW8gVW5pdC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkltcHVlc3RvczwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkFjY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXhBbW91bnQgPSAhaXNDbGllbnRUYXhFeGVtcHQgJiYgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKGl0ZW0udGF4ZXMgfHwgW10pLnJlZHVjZSgoYWNjOiBudW1iZXIsIHQ6IGFueSkgPT4gYWNjICsgTnVtYmVyKHQuYW1vdW50KSwgMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0udGVtcElkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9kdWN0X25hbWV9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0ucXVhbnRpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdxdWFudGl0eScsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIwIHB4LTIgcHktMiB0ZXh0LXJpZ2h0IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCB0ZXh0LXNtIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtLnVuaXRfcHJpY2UsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGl0ZW0ucXVhbnRpdHkgKiBpdGVtLnVuaXRfcHJpY2UsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtVGF4QW1vdW50LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1jZW50ZXIgZmxleCBqdXN0aWZ5LWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuSXRlbVRheE1vZGFsKGluZGV4KX0gY2xhc3NOYW1lPVwicC0xIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQZXJjZW50YWdlIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVJdGVtKGluZGV4KX0gY2xhc3NOYW1lPVwicC0xIHRleHQtcmVkLTYwMCBob3Zlcjp0ZXh0LXJlZC05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gREUgVE9UQUxFUyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Ob3RhczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vdGVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbm90ZXM6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgIWZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmIChmb3JtRGF0YS50YXhlcyB8fCBbXSkubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0yXCI+SW1wdWVzdG9zIEFwbGljYWRvczwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhmb3JtRGF0YS50YXhlcyB8fCBbXSkubWFwKCh0YXgsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj57dGF4LnRheF9uYW1lfSAoe3RheC5yYXRlfSUpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TdWJ0b3RhbDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IGZvbnQtc2VtaWJvbGRgfT5CYXNlIEltcG9uaWJsZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlfSBmb250LXNlbWlib2xkYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Ub3RhbCBJbXB1ZXN0b3M6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+VG90YWwgRGV2b2x1Y2nDs246PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJPVE9ORVJBICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgaG92ZXI6YmctZ3JheS01MFwiPkNhbmNlbGFyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZyB8fCBpc1NhdmluZ31cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBkaXNhYmxlZDpvcGFjaXR5LTUwICR7aXNTYXZpbmcgPyAnYmctaW5kaWdvLTUwMCBjdXJzb3Itd2FpdCcgOiAnYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNzAwJ31gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzU2F2aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Nlc2FuZG8gZW4gQVJDQS4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNhdmUgY2xhc3NOYW1lPVwibXItMlwiIC8+IEdlbmVyYXIgTm90YVxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1vZGFsZXMgKi99XG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9IG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RGcm9tTW9kYWx9IGNvbmZpZz17bW9kYWxDb25maWd9IC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge2lzSXRlbVRheE1vZGFsT3BlbiAmJiBjdXJyZW50SXRlbUluZGV4Rm9yVGF4ICE9PSBudWxsICYmIChcbiAgICAgICAgICAgICAgICA8SXRlbVRheE1vZGFsIGlzT3Blbj17aXNJdGVtVGF4TW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc0l0ZW1UYXhNb2RhbE9wZW4oZmFsc2UpfSBvblNhdmU9e2hhbmRsZVNhdmVJdGVtVGF4ZXN9IGl0ZW09e2l0ZW1zW2N1cnJlbnRJdGVtSW5kZXhGb3JUYXhdfSBjbGllbnRUYXhlcz17Y2xpZW50VGF4ZXN9IGNsaWVudFRheENvbmRpdGlvbj17Y2xpZW50VGF4Q29uZGl0aW9ufSAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG8vcGFnZXMvTm90YXNDcmVkaXRvRm9ybVBhZ2UudHN4In0=