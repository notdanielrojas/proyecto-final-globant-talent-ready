import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/Pagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/Pagination.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { FaChevronLeft, FaChevronRight } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const Pagination = ({ meta, onPageChange }) => {
  if (!meta || meta.last_page <= 1) {
    return null;
  }
  const handlePageClick = (linkUrl) => {
    if (linkUrl) {
      onPageChange(linkUrl);
    }
  };
  return /* @__PURE__ */ jsxDEV("nav", { className: "flex items-center justify-between px-4 py-3 bg-white border-t border-gray-200 sm:px-6", "aria-label": "Pagination", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:block", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: [
      "Mostrando ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: meta.from }, void 0, false, {
        fileName: "/app/src/components/common/Pagination.tsx",
        lineNumber: 46,
        columnNumber: 31
      }, this),
      " a ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: meta.to }, void 0, false, {
        fileName: "/app/src/components/common/Pagination.tsx",
        lineNumber: 46,
        columnNumber: 82
      }, this),
      " de",
      " ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: meta.total }, void 0, false, {
        fileName: "/app/src/components/common/Pagination.tsx",
        lineNumber: 47,
        columnNumber: 21
      }, this),
      " resultados"
    ] }, void 0, true, {
      fileName: "/app/src/components/common/Pagination.tsx",
      lineNumber: 45,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/Pagination.tsx",
      lineNumber: 44,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between flex-1 sm:justify-end", children: meta.links.map((link, index) => {
      const isPrev = link.label.includes("Previous");
      const isNext = link.label.includes("Next");
      const isPageNumber = !isPrev && !isNext && link.label !== "...";
      if (isPrev || isNext) {
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handlePageClick(link.url),
            disabled: !link.url,
            className: `relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed ${isNext ? "ml-3" : ""}`,
            children: isPrev ? /* @__PURE__ */ jsxDEV(FaChevronLeft, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/components/common/Pagination.tsx",
              lineNumber: 64,
              columnNumber: 43
            }, this) : /* @__PURE__ */ jsxDEV(FaChevronRight, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/components/common/Pagination.tsx",
              lineNumber: 64,
              columnNumber: 83
            }, this)
          },
          index,
          false,
          {
            fileName: "/app/src/components/common/Pagination.tsx",
            lineNumber: 58,
            columnNumber: 15
          },
          this
        );
      }
      if (isPageNumber) {
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handlePageClick(link.url),
            className: `relative hidden md:inline-flex items-center px-4 py-2 text-sm font-medium border ${link.active ? "z-10 bg-indigo-50 border-indigo-500 text-indigo-600" : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"}`,
            children: link.label
          },
          index,
          false,
          {
            fileName: "/app/src/components/common/Pagination.tsx",
            lineNumber: 71,
            columnNumber: 15
          },
          this
        );
      }
      if (link.label === "...") {
        return /* @__PURE__ */ jsxDEV("span", { className: "relative hidden md:inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300", children: "..." }, index, false, {
          fileName: "/app/src/components/common/Pagination.tsx",
          lineNumber: 82,
          columnNumber: 20
        }, this);
      }
      return null;
    }) }, void 0, false, {
      fileName: "/app/src/components/common/Pagination.tsx",
      lineNumber: 50,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/Pagination.tsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
};
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/Pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/Pagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEI4Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXpCOUIsU0FBU0EsZUFBZUMsc0JBQXNCO0FBVXZDLGFBQU1DLGFBQWFBLENBQUMsRUFBRUMsTUFBTUMsYUFBOEIsTUFBTTtBQUNuRSxNQUFJLENBQUNELFFBQVFBLEtBQUtFLGFBQWEsR0FBRztBQUM5QixXQUFPO0FBQUEsRUFDWDtBQUVBLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsWUFBMkI7QUFDaEQsUUFBSUEsU0FBUztBQUNUSCxtQkFBYUcsT0FBTztBQUFBLElBQ3hCO0FBQUEsRUFDSjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHlGQUF3RixjQUFXLGNBQzlHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1CQUNYLGlDQUFDLE9BQUUsV0FBVSx5QkFBdUI7QUFBQTtBQUFBLE1BQ3RCLHVCQUFDLFVBQUssV0FBVSxlQUFlSixlQUFLSyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFBTztBQUFBLE1BQUcsdUJBQUMsVUFBSyxXQUFVLGVBQWVMLGVBQUtNLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUFPO0FBQUEsTUFBSTtBQUFBLE1BQy9HLHVCQUFDLFVBQUssV0FBVSxlQUFlTixlQUFLTyxTQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsTUFBTztBQUFBLFNBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNWUCxlQUFLUSxNQUFNQyxJQUFJLENBQUNDLE1BQU1DLFVBQVU7QUFDN0IsWUFBTUMsU0FBU0YsS0FBS0csTUFBTUMsU0FBUyxVQUFVO0FBQzdDLFlBQU1DLFNBQVNMLEtBQUtHLE1BQU1DLFNBQVMsTUFBTTtBQUN6QyxZQUFNRSxlQUFlLENBQUNKLFVBQVUsQ0FBQ0csVUFBVUwsS0FBS0csVUFBVTtBQUUxRCxVQUFJRCxVQUFVRyxRQUFRO0FBQ2xCLGVBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVHLFNBQVMsTUFBTVosZ0JBQWdCTyxLQUFLTyxHQUFHO0FBQUEsWUFDdkMsVUFBVSxDQUFDUCxLQUFLTztBQUFBQSxZQUNoQixXQUFXLDZMQUE2TEYsU0FBUyxTQUFTLEVBQUU7QUFBQSxZQUUzTkgsbUJBQVMsdUJBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQyxJQUFNLHVCQUFDLGtCQUFlLFdBQVUsYUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQTtBQUFBLFVBTGhGRDtBQUFBQSxVQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLE1BRVI7QUFFQSxVQUFJSyxjQUFjO0FBQ2QsZUFDSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUcsU0FBUyxNQUFNYixnQkFBZ0JPLEtBQUtPLEdBQUc7QUFBQSxZQUN2QyxXQUFXLG9GQUFvRlAsS0FBS1EsU0FBUyx3REFBd0QseURBQXlEO0FBQUEsWUFFN05SLGVBQUtHO0FBQUFBO0FBQUFBLFVBSkRGO0FBQUFBLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsTUFFUjtBQUVBLFVBQUlELEtBQUtHLFVBQVUsT0FBTztBQUN0QixlQUFPLHVCQUFDLFVBQWlCLFdBQVUsMkhBQTBILG1CQUEzSUYsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlKO0FBQUEsTUFDcEs7QUFFQSxhQUFPO0FBQUEsSUFDWCxDQUFDLEtBcENMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQ0E7QUFBQSxPQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNBO0FBRVI7QUFBRVEsS0EzRFdwQjtBQUFVLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRmFDaGV2cm9uTGVmdCIsIkZhQ2hldnJvblJpZ2h0IiwiUGFnaW5hdGlvbiIsIm1ldGEiLCJvblBhZ2VDaGFuZ2UiLCJsYXN0X3BhZ2UiLCJoYW5kbGVQYWdlQ2xpY2siLCJsaW5rVXJsIiwiZnJvbSIsInRvIiwidG90YWwiLCJsaW5rcyIsIm1hcCIsImxpbmsiLCJpbmRleCIsImlzUHJldiIsImxhYmVsIiwiaW5jbHVkZXMiLCJpc05leHQiLCJpc1BhZ2VOdW1iZXIiLCJ1cmwiLCJhY3RpdmUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYWdpbmF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IEZhQ2hldnJvbkxlZnQsIEZhQ2hldnJvblJpZ2h0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHR5cGUgeyBQYWdpbmF0ZWRSZXNwb25zZSB9IGZyb20gJy4uLy4uL2ludGVyZmFjZXMvQXBpJztcblxuXG5cbmludGVyZmFjZSBQYWdpbmF0aW9uUHJvcHMge1xuICAgIG1ldGE6IFBhZ2luYXRlZFJlc3BvbnNlPGFueT5bJ21ldGEnXTtcbiAgICBvblBhZ2VDaGFuZ2U6ICh1cmw6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFBhZ2luYXRpb24gPSAoeyBtZXRhLCBvblBhZ2VDaGFuZ2UgfTogUGFnaW5hdGlvblByb3BzKSA9PiB7XG4gICAgaWYgKCFtZXRhIHx8IG1ldGEubGFzdF9wYWdlIDw9IDEpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgY29uc3QgaGFuZGxlUGFnZUNsaWNrID0gKGxpbmtVcmw6IHN0cmluZyB8IG51bGwpID0+IHtcbiAgICAgICAgaWYgKGxpbmtVcmwpIHtcbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZShsaW5rVXJsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC00IHB5LTMgYmctd2hpdGUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHNtOnB4LTZcIiBhcmlhLWxhYmVsPVwiUGFnaW5hdGlvblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206YmxvY2tcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgTW9zdHJhbmRvIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e21ldGEuZnJvbX08L3NwYW4+IGEgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57bWV0YS50b308L3NwYW4+IGRleycgJ31cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57bWV0YS50b3RhbH08L3NwYW4+IHJlc3VsdGFkb3NcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gZmxleC0xIHNtOmp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAge21ldGEubGlua3MubWFwKChsaW5rLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1ByZXYgPSBsaW5rLmxhYmVsLmluY2x1ZGVzKCdQcmV2aW91cycpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc05leHQgPSBsaW5rLmxhYmVsLmluY2x1ZGVzKCdOZXh0Jyk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUGFnZU51bWJlciA9ICFpc1ByZXYgJiYgIWlzTmV4dCAmJiBsaW5rLmxhYmVsICE9PSAnLi4uJztcblxuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcmV2IHx8IGlzTmV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBhZ2VDbGljayhsaW5rLnVybCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbGluay51cmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkICR7aXNOZXh0ID8gJ21sLTMnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ByZXYgPyA8RmFDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4gOiA8RmFDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1BhZ2VOdW1iZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQYWdlQ2xpY2sobGluay51cmwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBoaWRkZW4gbWQ6aW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIGJvcmRlciAke2xpbmsuYWN0aXZlID8gJ3otMTAgYmctaW5kaWdvLTUwIGJvcmRlci1pbmRpZ28tNTAwIHRleHQtaW5kaWdvLTYwMCcgOiAnYmctd2hpdGUgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS01MCd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5rLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChsaW5rLmxhYmVsID09PSAnLi4uJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxzcGFuIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInJlbGF0aXZlIGhpZGRlbiBtZDppbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCI+Li4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uYXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9QYWdpbmF0aW9uLnRzeCJ9