import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
const renderTypeBadge = (item) => {
  let text = "General";
  let className = "bg-blue-100 text-blue-800";
  if (item.type === "cliente_especifico") {
    text = "Cliente Específico";
    className = "bg-purple-100 text-purple-800";
  }
  return /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${className}`, children: text }, void 0, false, {
    fileName: "/app/src/features/lista_precios/listas_precios.config.tsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
};
export const renderActiveBadge = (item) => {
  const text = item.is_active ? "Activa" : "Inactiva";
  const className = item.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800";
  return /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${className}`, children: text }, void 0, false, {
    fileName: "/app/src/features/lista_precios/listas_precios.config.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
};
export const priceListsModuleConfig = {
  endpoint: "pricelists",
  moduleName: "Lista de Precios",
  moduleNamePlural: "Listas de Precios",
  baseRoute: "/listas-de-precios",
  detail: {
    displayNameKey: "name"
  },
  list: {
    columns: [
      { header: "Nombre", accessor: "name" },
      { header: "Tipo", accessor: "type", render: renderTypeBadge },
      { header: "Cliente", accessor: "client", render: (item) => item.client_name || "-" },
      { header: "Desde", accessor: "valid_from", format: "date" },
      { header: "Hasta", accessor: "valid_to", format: "date" },
      { header: "Estado", accessor: "is_active", render: renderActiveBadge }
    ]
  },
  form: {
    block: [
      {
        name: "Datos Principales",
        fields: [
          { name: "name", label: "Nombre", type: "text", mandatory: true },
          { name: "description", label: "Descripción", type: "textarea" },
          {
            name: "type",
            label: "Tipo",
            type: "select",
            mandatory: true,
            options: [
              { value: "general", label: "General" },
              { value: "cliente_especifico", label: "Cliente Específico" }
            ],
            render: (item) => renderTypeBadge(item)
          },
          {
            name: "client_id",
            label: "Cliente",
            type: "relational",
            relationalConfig: {
              moduleConfig: clientesModuleConfig,
              codeField: "customer_code",
              // ✅ Agregado
              nameField: "name"
            },
            visibleWhen: (formData) => formData.type === "cliente_especifico",
            mandatory: (formData) => formData.type === "cliente_especifico",
            render: (item) => item.client?.name || item.client_name || "-"
          },
          { name: "valid_from", label: "Válido Desde", type: "date", mandatory: true },
          { name: "valid_to", label: "Válido Hasta", type: "date" },
          {
            name: "is_active",
            label: "Activa",
            type: "select",
            mandatory: true,
            options: [
              { value: true, label: "Sí" },
              { value: false, label: "No" }
            ],
            defaultValue: true,
            render: (item) => renderActiveBadge(item)
          }
        ]
      }
    ]
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNXO0FBckNYLFNBQVNBLDRCQUEwQztBQThCbkQsTUFBTUMsa0JBQWtCQSxDQUFDQyxTQUFvQjtBQUN6QyxNQUFJQyxPQUFPO0FBQ1gsTUFBSUMsWUFBWTtBQUNoQixNQUFJRixLQUFLRyxTQUFTLHNCQUFzQjtBQUNwQ0YsV0FBTztBQUNQQyxnQkFBWTtBQUFBLEVBQ2hCO0FBQ0EsU0FBTyx1QkFBQyxVQUFLLFdBQVcsaUVBQWlFQSxTQUFTLElBQUtELGtCQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFHO0FBQ2hIO0FBR08sYUFBTUcsb0JBQW9CQSxDQUFDSixTQUFvQjtBQUNsRCxRQUFNQyxPQUFPRCxLQUFLSyxZQUFZLFdBQVc7QUFDekMsUUFBTUgsWUFBWUYsS0FBS0ssWUFBWSxnQ0FBZ0M7QUFDbkUsU0FBTyx1QkFBQyxVQUFLLFdBQVcsaUVBQWlFSCxTQUFTLElBQUtELGtCQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFHO0FBQ2hIO0FBSU8sYUFBTUsseUJBQWtEO0FBQUEsRUFDM0RDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsa0JBQWtCO0FBQUEsRUFDbEJDLFdBQVc7QUFBQSxFQUVYQyxRQUFRO0FBQUEsSUFDSkMsZ0JBQWdCO0FBQUEsRUFDcEI7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsU0FBUztBQUFBLE1BQ0wsRUFBRUMsUUFBUSxVQUFVQyxVQUFVLE9BQU87QUFBQSxNQUNyQyxFQUFFRCxRQUFRLFFBQVFDLFVBQVUsUUFBUUMsUUFBUWxCLGdCQUFnQjtBQUFBLE1BQzVELEVBQUVnQixRQUFRLFdBQVdDLFVBQVUsVUFBVUMsUUFBUUEsQ0FBQ2pCLFNBQVNBLEtBQUtrQixlQUFlLElBQUk7QUFBQSxNQUNuRixFQUFFSCxRQUFRLFNBQVNDLFVBQVUsY0FBY0csUUFBUSxPQUFPO0FBQUEsTUFDMUQsRUFBRUosUUFBUSxTQUFTQyxVQUFVLFlBQVlHLFFBQVEsT0FBTztBQUFBLE1BQ3hELEVBQUVKLFFBQVEsVUFBVUMsVUFBVSxhQUFhQyxRQUFRYixrQkFBa0I7QUFBQSxJQUFDO0FBQUEsRUFFOUU7QUFBQSxFQUVBZ0IsTUFBTTtBQUFBLElBQ0ZDLE9BQU87QUFBQSxNQUNIO0FBQUEsUUFDSUMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxVQUNKLEVBQUVELE1BQU0sUUFBUUUsT0FBTyxVQUFVckIsTUFBTSxRQUFRc0IsV0FBVyxLQUFLO0FBQUEsVUFDL0QsRUFBRUgsTUFBTSxlQUFlRSxPQUFPLGVBQWVyQixNQUFNLFdBQVc7QUFBQSxVQUM5RDtBQUFBLFlBQ0ltQixNQUFNO0FBQUEsWUFBUUUsT0FBTztBQUFBLFlBQVFyQixNQUFNO0FBQUEsWUFBVXNCLFdBQVc7QUFBQSxZQUN4REMsU0FBUztBQUFBLGNBQ0wsRUFBRUMsT0FBTyxXQUFXSCxPQUFPLFVBQVU7QUFBQSxjQUNyQyxFQUFFRyxPQUFPLHNCQUFzQkgsT0FBTyxxQkFBcUI7QUFBQSxZQUFDO0FBQUEsWUFFaEVQLFFBQVFBLENBQUNqQixTQUFvQkQsZ0JBQWdCQyxJQUFJO0FBQUEsVUFDckQ7QUFBQSxVQUNBO0FBQUEsWUFDSXNCLE1BQU07QUFBQSxZQUFhRSxPQUFPO0FBQUEsWUFBV3JCLE1BQU07QUFBQSxZQUMzQ3lCLGtCQUFrQjtBQUFBLGNBQ2RDLGNBQWMvQjtBQUFBQSxjQUNkZ0MsV0FBVztBQUFBO0FBQUEsY0FDWEMsV0FBVztBQUFBLFlBQ2Y7QUFBQSxZQUNBQyxhQUFhQSxDQUFDQyxhQUF3QkEsU0FBUzlCLFNBQVM7QUFBQSxZQUN4RHNCLFdBQVdBLENBQUNRLGFBQXdCQSxTQUFTOUIsU0FBUztBQUFBLFlBQ3REYyxRQUFRQSxDQUFDakIsU0FBb0JBLEtBQUtrQyxRQUFRWixRQUFRdEIsS0FBS2tCLGVBQWU7QUFBQSxVQUMxRTtBQUFBLFVBQ0EsRUFBRUksTUFBTSxjQUFjRSxPQUFPLGdCQUFnQnJCLE1BQU0sUUFBUXNCLFdBQVcsS0FBSztBQUFBLFVBQzNFLEVBQUVILE1BQU0sWUFBWUUsT0FBTyxnQkFBZ0JyQixNQUFNLE9BQU87QUFBQSxVQUN4RDtBQUFBLFlBQ0ltQixNQUFNO0FBQUEsWUFBYUUsT0FBTztBQUFBLFlBQVVyQixNQUFNO0FBQUEsWUFBVXNCLFdBQVc7QUFBQSxZQUMvREMsU0FBUztBQUFBLGNBQ0wsRUFBRUMsT0FBTyxNQUFNSCxPQUFPLEtBQUs7QUFBQSxjQUMzQixFQUFFRyxPQUFPLE9BQU9ILE9BQU8sS0FBSztBQUFBLFlBQUM7QUFBQSxZQUVqQ1csY0FBYztBQUFBLFlBQ2RsQixRQUFRQSxDQUFDakIsU0FBb0JJLGtCQUFrQkosSUFBSTtBQUFBLFVBQ3ZEO0FBQUEsUUFBQztBQUFBLE1BRVQ7QUFBQSxJQUFDO0FBQUEsRUFFVDtBQUNKIiwibmFtZXMiOlsiY2xpZW50ZXNNb2R1bGVDb25maWciLCJyZW5kZXJUeXBlQmFkZ2UiLCJpdGVtIiwidGV4dCIsImNsYXNzTmFtZSIsInR5cGUiLCJyZW5kZXJBY3RpdmVCYWRnZSIsImlzX2FjdGl2ZSIsInByaWNlTGlzdHNNb2R1bGVDb25maWciLCJlbmRwb2ludCIsIm1vZHVsZU5hbWUiLCJtb2R1bGVOYW1lUGx1cmFsIiwiYmFzZVJvdXRlIiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJsaXN0IiwiY29sdW1ucyIsImhlYWRlciIsImFjY2Vzc29yIiwicmVuZGVyIiwiY2xpZW50X25hbWUiLCJmb3JtYXQiLCJmb3JtIiwiYmxvY2siLCJuYW1lIiwiZmllbGRzIiwibGFiZWwiLCJtYW5kYXRvcnkiLCJvcHRpb25zIiwidmFsdWUiLCJyZWxhdGlvbmFsQ29uZmlnIiwibW9kdWxlQ29uZmlnIiwiY29kZUZpZWxkIiwibmFtZUZpZWxkIiwidmlzaWJsZVdoZW4iLCJmb3JtRGF0YSIsImNsaWVudCIsImRlZmF1bHRWYWx1ZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJsaXN0YXNfcHJlY2lvcy5jb25maWcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9tb2R1bGVzL2xpc3Rhc19kZV9wcmVjaW9zL2xpc3Rhc19kZV9wcmVjaW9zLmNvbmZpZy50c3hcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnLCBGb3JtRmllbGRDb25maWcgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlXCI7XG5pbXBvcnQgeyBjbGllbnRlc01vZHVsZUNvbmZpZywgdHlwZSBDbGllbnRlIH0gZnJvbSBcIi4uL2NsaWVudGVzL2NsaWVudGVzLmNvbmZpZ1wiOy8vIFBhcmEgc2VsZWNjaW9uYXIgcHJvZHVjdG9zXG5cbi8vIC0tLSBJTlRFUkZBQ0VTIC0tLVxuXG5leHBvcnQgaW50ZXJmYWNlIFByaWNlTGlzdEl0ZW0ge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIHByaWNlYWJsZV9pZDogbnVtYmVyO1xuICAgIHByaWNlYWJsZV90eXBlOiBzdHJpbmc7XG4gICAgcHJpY2U6IHN0cmluZyB8IG51bWJlcjtcbiAgICB0ZW1wSWQ/OiBzdHJpbmc7XG4gICAgcHJpY2VhYmxlX25hbWU/OiBzdHJpbmc7XG4gICAgcHJpY2VhYmxlX2NvZGU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJpY2VMaXN0IHtcbiAgICBpZDogbnVtYmVyO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbDtcbiAgICB0eXBlOiAnZ2VuZXJhbCcgfCAnY2xpZW50ZV9lc3BlY2lmaWNvJztcbiAgICBpc19hY3RpdmU6IGJvb2xlYW47XG4gICAgdmFsaWRfZnJvbTogc3RyaW5nO1xuICAgIHZhbGlkX3RvOiBzdHJpbmcgfCBudWxsO1xuICAgIGNsaWVudF9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICBjbGllbnQ/OiBDbGllbnRlO1xuICAgIGl0ZW1zOiBQcmljZUxpc3RJdGVtW107XG4gICAgY2xpZW50X25hbWU/OiBzdHJpbmc7XG4gICAgY3VzdG9tZXJfY29kZT86IHN0cmluZzsgLy8g4pyFIENhbXBvIGRlIGPDs2RpZ28gZGVsIGNsaWVudGUgKHVzYWRvIHBvciBHZW5lcmljRm9ybVBhZ2UpXG59XG5cbi8vIEhlbHBlciBwYXJhIHRpcG8gZGUgbGlzdGFcbmNvbnN0IHJlbmRlclR5cGVCYWRnZSA9IChpdGVtOiBQcmljZUxpc3QpID0+IHtcbiAgICBsZXQgdGV4dCA9ICdHZW5lcmFsJztcbiAgICBsZXQgY2xhc3NOYW1lID0gJ2JnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAnO1xuICAgIGlmIChpdGVtLnR5cGUgPT09ICdjbGllbnRlX2VzcGVjaWZpY28nKSB7XG4gICAgICAgIHRleHQgPSAnQ2xpZW50ZSBFc3BlY8OtZmljbyc7XG4gICAgICAgIGNsYXNzTmFtZSA9ICdiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMCc7XG4gICAgfVxuICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7Y2xhc3NOYW1lfWB9Pnt0ZXh0fTwvc3Bhbj47XG59XG5cbi8vIEhlbHBlciBwYXJhIGVzdGFkbyBhY3Rpdm8vaW5hY3Rpdm9cbmV4cG9ydCBjb25zdCByZW5kZXJBY3RpdmVCYWRnZSA9IChpdGVtOiBQcmljZUxpc3QpID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gaXRlbS5pc19hY3RpdmUgPyAnQWN0aXZhJyA6ICdJbmFjdGl2YSc7XG4gICAgY29uc3QgY2xhc3NOYW1lID0gaXRlbS5pc19hY3RpdmUgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCc7XG4gICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgaW5saW5lLWZsZXggdGV4dC14cyBsZWFkaW5nLTUgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgJHtjbGFzc05hbWV9YH0+e3RleHR9PC9zcGFuPjtcbn1cblxuXG4vLyAtLS0gQ09ORklHVVJBQ0nDk04gREVMIE3Dk0RVTE8gLS0tXG5leHBvcnQgY29uc3QgcHJpY2VMaXN0c01vZHVsZUNvbmZpZzogTW9kdWxlQ29uZmlnPFByaWNlTGlzdD4gPSB7XG4gICAgZW5kcG9pbnQ6ICdwcmljZWxpc3RzJyxcbiAgICBtb2R1bGVOYW1lOiAnTGlzdGEgZGUgUHJlY2lvcycsXG4gICAgbW9kdWxlTmFtZVBsdXJhbDogJ0xpc3RhcyBkZSBQcmVjaW9zJyxcbiAgICBiYXNlUm91dGU6ICcvbGlzdGFzLWRlLXByZWNpb3MnLFxuXG4gICAgZGV0YWlsOiB7XG4gICAgICAgIGRpc3BsYXlOYW1lS2V5OiAnbmFtZScsXG4gICAgfSxcblxuICAgIGxpc3Q6IHtcbiAgICAgICAgY29sdW1uczogW1xuICAgICAgICAgICAgeyBoZWFkZXI6ICdOb21icmUnLCBhY2Nlc3NvcjogJ25hbWUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1RpcG8nLCBhY2Nlc3NvcjogJ3R5cGUnLCByZW5kZXI6IHJlbmRlclR5cGVCYWRnZSB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdDbGllbnRlJywgYWNjZXNzb3I6ICdjbGllbnQnLCByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmNsaWVudF9uYW1lIHx8ICctJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdEZXNkZScsIGFjY2Vzc29yOiAndmFsaWRfZnJvbScsIGZvcm1hdDogJ2RhdGUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0hhc3RhJywgYWNjZXNzb3I6ICd2YWxpZF90bycsIGZvcm1hdDogJ2RhdGUnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0VzdGFkbycsIGFjY2Vzc29yOiAnaXNfYWN0aXZlJywgcmVuZGVyOiByZW5kZXJBY3RpdmVCYWRnZSB9LFxuICAgICAgICBdLFxuICAgIH0sXG5cbiAgICBmb3JtOiB7XG4gICAgICAgIGJsb2NrOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogJ0RhdG9zIFByaW5jaXBhbGVzJyxcbiAgICAgICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnbmFtZScsIGxhYmVsOiAnTm9tYnJlJywgdHlwZTogJ3RleHQnLCBtYW5kYXRvcnk6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnZGVzY3JpcHRpb24nLCBsYWJlbDogJ0Rlc2NyaXBjacOzbicsIHR5cGU6ICd0ZXh0YXJlYScgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3R5cGUnLCBsYWJlbDogJ1RpcG8nLCB0eXBlOiAnc2VsZWN0JywgbWFuZGF0b3J5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdnZW5lcmFsJywgbGFiZWw6ICdHZW5lcmFsJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdjbGllbnRlX2VzcGVjaWZpY28nLCBsYWJlbDogJ0NsaWVudGUgRXNwZWPDrWZpY28nIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtOiBQcmljZUxpc3QpID0+IHJlbmRlclR5cGVCYWRnZShpdGVtKVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY2xpZW50X2lkJywgbGFiZWw6ICdDbGllbnRlJywgdHlwZTogJ3JlbGF0aW9uYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbENvbmZpZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZHVsZUNvbmZpZzogY2xpZW50ZXNNb2R1bGVDb25maWcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnY3VzdG9tZXJfY29kZScsIC8vIOKchSBBZ3JlZ2Fkb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ25hbWUnXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZVdoZW46IChmb3JtRGF0YTogUHJpY2VMaXN0KSA9PiBmb3JtRGF0YS50eXBlID09PSAnY2xpZW50ZV9lc3BlY2lmaWNvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hbmRhdG9yeTogKGZvcm1EYXRhOiBQcmljZUxpc3QpID0+IGZvcm1EYXRhLnR5cGUgPT09ICdjbGllbnRlX2VzcGVjaWZpY28nLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbTogUHJpY2VMaXN0KSA9PiBpdGVtLmNsaWVudD8ubmFtZSB8fCBpdGVtLmNsaWVudF9uYW1lIHx8ICctJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICd2YWxpZF9mcm9tJywgbGFiZWw6ICdWw6FsaWRvIERlc2RlJywgdHlwZTogJ2RhdGUnLCBtYW5kYXRvcnk6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAndmFsaWRfdG8nLCBsYWJlbDogJ1bDoWxpZG8gSGFzdGEnLCB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2lzX2FjdGl2ZScsIGxhYmVsOiAnQWN0aXZhJywgdHlwZTogJ3NlbGVjdCcsIG1hbmRhdG9yeTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiB0cnVlLCBsYWJlbDogJ1PDrScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiBmYWxzZSwgbGFiZWw6ICdObycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtOiBQcmljZUxpc3QpID0+IHJlbmRlckFjdGl2ZUJhZGdlKGl0ZW0pXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXSBhcyBGb3JtRmllbGRDb25maWc8UHJpY2VMaXN0PltdXG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGlzdGFfcHJlY2lvcy9saXN0YXNfcHJlY2lvcy5jb25maWcudHN4In0=