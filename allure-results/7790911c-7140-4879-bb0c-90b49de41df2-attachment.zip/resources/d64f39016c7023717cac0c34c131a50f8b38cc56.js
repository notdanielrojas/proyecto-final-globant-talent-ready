import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profiles/pages/ProfilesListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/profiles/pages/ProfilesListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { profilesModuleConfig } from "/src/features/profiles/profiles.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
export const ProfilesListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(profilesModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/profiles/pages/ProfilesListPage.tsx",
    lineNumber: 41,
    columnNumber: 21
  }, this);
  return (
    // ✅ Se pasan todas las props nuevas a GenericListPage
    /* @__PURE__ */ jsxDEV(
      GenericListPage,
      {
        config: profilesModuleConfig,
        paginationResponse: response,
        loading,
        isAppending,
        onDelete: deleteItem,
        onSort: handleSort,
        sortBy,
        sortDirection,
        onPageChange: handlePageChange,
        onLoadMore: handleLoadMore,
        onSearch: handleSearch,
        searchTerm: searchParams.term ?? ""
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/profiles/pages/ProfilesListPage.tsx",
        lineNumber: 45,
        columnNumber: 5
      },
      this
    )
  );
};
_s(ProfilesListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = ProfilesListPage;
var _c;
$RefreshReg$(_c, "ProfilesListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/profiles/pages/ProfilesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/profiles/pages/ProfilesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyw0QkFBMEM7QUFDbkQsU0FBU0MsZUFBZTtBQUVqQixhQUFNQyxtQkFBbUJBLE1BQU07QUFBQUMsS0FBQTtBQUVsQyxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZCxRQUFpQkQsb0JBQW9CO0FBRXpDLE1BQUlPLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RDtBQUFBO0FBQUEsSUFFSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUVA7QUFBQUEsUUFDUixvQkFBb0JJO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVUk7QUFBQUEsUUFDVixRQUFRQztBQUFBQSxRQUNSO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBY0c7QUFBQUEsUUFDZCxZQUFZQztBQUFBQSxRQUNaLFVBQVVDO0FBQUFBLFFBQ1YsWUFBWUMsYUFBYUMsUUFBUTtBQUFBO0FBQUEsTUFackM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWXdDO0FBQUE7QUFHaEQ7QUFBRWIsR0FwQ1dELGtCQUFnQjtBQUFBLFVBZXJCRCxPQUFPO0FBQUE7QUFBQWdCLEtBZkZmO0FBQWdCLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJwcm9maWxlc01vZHVsZUNvbmZpZyIsInVzZUNydWQiLCJQcm9maWxlc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb2ZpbGVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBwcm9maWxlc01vZHVsZUNvbmZpZywgdHlwZSBQcm9maWxlIH0gZnJvbSAnLi4vcHJvZmlsZXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWQgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkJztcblxuZXhwb3J0IGNvbnN0IFByb2ZpbGVzTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgLy8g4pyFIFNlIGRlc2VzdHJ1Y3R1cmEgbGEgbnVldmEgaW50ZXJmYXogY29tcGxldGEgZGVsIGhvb2sgdXNlQ3J1ZFxuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGlzQXBwZW5kaW5nLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgZGVsZXRlSXRlbSxcbiAgICAgICAgaGFuZGxlU29ydCxcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVMb2FkTW9yZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8UHJvZmlsZT4ocHJvZmlsZXNNb2R1bGVDb25maWcpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgLy8g4pyFIFNlIHBhc2FuIHRvZGFzIGxhcyBwcm9wcyBudWV2YXMgYSBHZW5lcmljTGlzdFBhZ2VcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxQcm9maWxlPlxuICAgICAgICAgICAgY29uZmlnPXtwcm9maWxlc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgb25EZWxldGU9e2RlbGV0ZUl0ZW19XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvcHJvZmlsZXMvcGFnZXMvUHJvZmlsZXNMaXN0UGFnZS50c3gifQ==