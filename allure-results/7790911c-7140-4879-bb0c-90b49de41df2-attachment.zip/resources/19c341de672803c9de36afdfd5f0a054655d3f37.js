import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { salesOrdersModuleConfig, isSalesOrderEditable } from "/src/features/pedidos_venta/pedidos_venta_config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { isClientLeyExportacionTdfExempt } from "/src/utils/clientTaxExemption.ts";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport10_react["useMemo"]; const useState = __vite__cjsImport10_react["useState"];
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) {
    return 0;
  }
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const PedidosVentaDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const [isPrinting, setIsPrinting] = useState(false);
  const { item: order, loading, error } = useCrudItem(salesOrdersModuleConfig, id);
  const modulePermission = getRequiredPermission(salesOrdersModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const isClientTaxExempt = useMemo(
    () => isClientLeyExportacionTdfExempt(order?.client),
    [order?.client]
  );
  const calculatedTotals = useMemo(() => {
    if (!order) {
      return { subtotal: 0, totalItemDiscounts: 0, globalDiscountAmount: 0, taxBase: 0, totalTaxes: 0 };
    }
    const items = order.items || [];
    const subtotal = items.reduce((sum, item) => {
      return sum + Number(item.quantity) * Number(item.unit_price);
    }, 0);
    const totalItemDiscounts = items.reduce((sum, item) => {
      return sum + (Number(item.discount_amount) || 0);
    }, 0);
    const globalDiscountAmount = Number(order.discount_amount) || 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (order.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => {
          const itemTaxAmount = (item.taxes || []).reduce((itemSum, tax) => itemSum + Number(tax.amount), 0);
          return sum + itemTaxAmount;
        }, 0);
      } else {
        totalTaxes = (order.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes };
  }, [order, isClientTaxExempt]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
    lineNumber: 96,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar el pedido: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
    lineNumber: 97,
    columnNumber: 21
  }, this);
  if (!order) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el pedido." }, void 0, false, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
    lineNumber: 98,
    columnNumber: 22
  }, this);
  const canEditOrder = canEdit && isSalesOrderEditable(order);
  const getStatusText = (status) => {
    switch (String(status)) {
      case "1":
        return "Pendiente";
      case "2":
        return "Procesado";
      case "3":
        return "Autorizado";
      case "0":
        return "Anulado";
      default:
        return "Desconocido";
    }
  };
  const getStatusClassName = (status) => {
    switch (String(status)) {
      case "1":
        return "bg-yellow-100 text-yellow-800";
      case "2":
        return "bg-green-100 text-green-800";
      case "3":
        return "bg-green-100 text-green-800";
      case "0":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const handlePrint = async () => {
    if (!order) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/sales-orders/${order.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(salesOrdersModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 154,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 153,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "Pedido: ",
            order.order_number
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 157,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClassName(order.status)}`, children: getStatusText(order.status) }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 160,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 156,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 152,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "mx-4 inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 175,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 177,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 167,
            columnNumber: 21
          },
          this
        ),
        canEditOrder && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(`${salesOrdersModuleConfig.baseRoute}/${id}/editar`),
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
            children: [
              /* @__PURE__ */ jsxDEV(IoPencil, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
                lineNumber: 186,
                columnNumber: 29
              }, this),
              "Editar"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 181,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 166,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
      lineNumber: 151,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 196,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/clientes/${order.client?.id}`,
            className: "text-indigo-600 hover:text-indigo-800 hover:underline",
            children: order.client?.name || order.client_name || "N/A"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 198,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 197,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 195,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Pedido" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 207,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: formatValue(order.order_date, "date") }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 208,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 206,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Entrega" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 211,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.delivery_date ? formatValue(order.delivery_date, "date") : "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 212,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 210,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 215,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.salesperson?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 216,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 214,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Comprador" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 220,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.buyer?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 219,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Transporte" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 224,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.transport?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 225,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 223,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 228,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.currency?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 229,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 227,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Nº O.C." }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 232,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.purchase_order_number || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 233,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 231,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Dirección Entrega" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 236,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.delivery_address || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 237,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 235,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 240,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.notes || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 241,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 239,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de cambio" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 244,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.exchange_rate || "N/A" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 245,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 243,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
      lineNumber: 194,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Items del Pedido" }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 252,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 259,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 260,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 261,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Desc. (Monto)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 263,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 264,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && order.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 267,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 269,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 258,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 257,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: (order.items || []).map((item, index) => {
          const subtotal = Number(item.quantity) * Number(item.unit_price);
          const discount = Number(item.discount_amount) || 0;
          const lineSubtotal = subtotal - discount;
          const itemTax = !isClientTaxExempt && order.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSubtotal + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: item.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${item.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
                lineNumber: 288,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
                lineNumber: 289,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 287,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
                lineNumber: 293,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
                lineNumber: 294,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 292,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 285,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: item.quantity }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 298,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 299,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(discount, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 301,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 302,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && order.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(itemTax, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 306,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 311,
              columnNumber: 41
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 284,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 272,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 256,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 255,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
      lineNumber: 251,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1" }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 324,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !order.has_item_level_taxes && order.taxes && order.taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 332,
          columnNumber: 29
        }, this),
        order.taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle.replace("text-gray-600", "text-gray-700"), children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%):"
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 335,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 336,
              columnNumber: 37
            }, this)
          ] }, tax.tax_id || index, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 334,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 331,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 329,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 346,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 347,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 345,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Items):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 350,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.totalItemDiscounts, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 351,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 349,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Global):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 354,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.globalDiscountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 355,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 353,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 360,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-base")} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 361,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 359,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: order.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 364,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
              lineNumber: 367,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 363,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 358,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 372,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-lg")} font-bold text-indigo-600`, children: formatValue(order.total_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
            lineNumber: 374,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
          lineNumber: 371,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
        lineNumber: 344,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
      lineNumber: 323,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx",
    lineNumber: 148,
    columnNumber: 5
  }, this);
};
_s(PedidosVentaDetailPage, "tufYLAoZ3L8fHSjbqal9n6MLFm8=", false, function() {
  return [useParams, useNavigate, usePermissions, useCrudItem];
});
_c = PedidosVentaDetailPage;
var _c;
$RefreshReg$(_c, "PedidosVentaDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEV3QixTQW9Nd0IsVUFwTXhCOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVFeEIsU0FBU0EsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MseUJBQXlCQyw0QkFBa0U7QUFDcEcsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLFVBQVVDLGVBQWU7QUFDL0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHVDQUF1QztBQUNoRCxTQUFTQyxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFDbEQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLHlCQUF5QjtBQUdsQyxNQUFNQyxrQkFBa0JBLENBQUNDLFNBQXlCO0FBQzlDLE1BQUksQ0FBQ0EsS0FBS0MsU0FBU0QsS0FBS0MsTUFBTUMsV0FBVyxHQUFHO0FBQ3hDLFdBQU87QUFBQSxFQUNYO0FBQ0EsU0FBT0YsS0FBS0MsTUFBTUUsT0FBTyxDQUFDQyxLQUFLQyxRQUFRRCxNQUFNRSxPQUFPRCxJQUFJRSxNQUFNLEdBQUcsQ0FBQztBQUN0RTtBQUVPLGFBQU1DLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3hDLFFBQU0sRUFBRUMsR0FBRyxJQUFJakMsVUFBMEI7QUFDekMsUUFBTWtDLFdBQVdqQyxZQUFZO0FBQzdCLFFBQU0sRUFBRWtDLG9CQUFvQixJQUFJakIsZUFBZTtBQUMvQyxRQUFNLENBQUNrQixZQUFZQyxhQUFhLElBQUl4QixTQUFTLEtBQUs7QUFDbEQsUUFBTSxFQUFFVSxNQUFNZSxPQUFPQyxTQUFTQyxNQUFNLElBQUlyQyxZQUF3QkMseUJBQXlCNkIsRUFBRTtBQUczRixRQUFNUSxtQkFBbUJ0QixzQkFBc0JmLHdCQUF3QnNDLFNBQVM7QUFDaEYsUUFBTUMsYUFBYUYsbUJBQW1CckIsd0JBQXdCcUIsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsVUFBVUQsYUFBYVIsb0JBQW9CUSxZQUFZLE1BQU0sSUFBSTtBQUV2RSxRQUFNRSxvQkFBb0JqQztBQUFBQSxJQUN0QixNQUFNRCxnQ0FBZ0MyQixPQUFPUSxNQUFNO0FBQUEsSUFDbkQsQ0FBQ1IsT0FBT1EsTUFBTTtBQUFBLEVBQ2xCO0FBRUEsUUFBTUMsbUJBQW1CbkMsUUFBUSxNQUFNO0FBQ25DLFFBQUksQ0FBQzBCLE9BQU87QUFDUixhQUFPLEVBQUVVLFVBQVUsR0FBR0Msb0JBQW9CLEdBQUdDLHNCQUFzQixHQUFHQyxTQUFTLEdBQUdDLFlBQVksRUFBRTtBQUFBLElBQ3BHO0FBRUEsVUFBTUMsUUFBUWYsTUFBTWUsU0FBUztBQUU3QixVQUFNTCxXQUFXSyxNQUFNM0IsT0FBTyxDQUFDQyxLQUFLSixTQUFTO0FBQ3pDLGFBQU9JLE1BQU9FLE9BQU9OLEtBQUsrQixRQUFRLElBQUl6QixPQUFPTixLQUFLZ0MsVUFBVTtBQUFBLElBQ2hFLEdBQUcsQ0FBQztBQUVKLFVBQU1OLHFCQUFxQkksTUFBTTNCLE9BQU8sQ0FBQ0MsS0FBS0osU0FBUztBQUNuRCxhQUFPSSxPQUFPRSxPQUFPTixLQUFLaUMsZUFBZSxLQUFLO0FBQUEsSUFDbEQsR0FBRyxDQUFDO0FBRUosVUFBTU4sdUJBQXVCckIsT0FBT1MsTUFBTWtCLGVBQWUsS0FBSztBQUU5RCxVQUFNTCxVQUFVSCxXQUFXQyxxQkFBcUJDO0FBRWhELFFBQUlFLGFBQWE7QUFDakIsUUFBSSxDQUFDUCxtQkFBbUI7QUFDcEIsVUFBSVAsTUFBTW1CLHNCQUFzQjtBQUM1QkwscUJBQWFDLE1BQU0zQixPQUFPLENBQUNDLEtBQUtKLFNBQVM7QUFDckMsZ0JBQU1tQyxpQkFBaUJuQyxLQUFLQyxTQUFTLElBQUlFLE9BQU8sQ0FBQ2lDLFNBQVMvQixRQUFRK0IsVUFBVTlCLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQ2pHLGlCQUFPSCxNQUFNK0I7QUFBQUEsUUFDakIsR0FBRyxDQUFDO0FBQUEsTUFDUixPQUFPO0FBQ0hOLHNCQUFjZCxNQUFNZCxTQUFTLElBQUlFLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFBQSxNQUNyRjtBQUFBLElBQ0o7QUFFQSxXQUFPLEVBQUVrQixVQUFVQyxvQkFBb0JDLHNCQUFzQkMsU0FBU0MsV0FBVztBQUFBLEVBQ3JGLEdBQUcsQ0FBQ2QsT0FBT08saUJBQWlCLENBQUM7QUFHN0IsTUFBSU4sUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUE0QkE7QUFBQUEsT0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRTtBQUNsRixNQUFJLENBQUNGLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLHlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9FO0FBRXZGLFFBQU1zQixlQUFlaEIsV0FBV3ZDLHFCQUFxQmlDLEtBQUs7QUFHMUQsUUFBTXVCLGdCQUFnQkEsQ0FBQ0MsV0FBNEI7QUFDL0MsWUFBUUMsT0FBT0QsTUFBTSxHQUFDO0FBQUEsTUFDbEIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQjtBQUFTLGVBQU87QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFDQSxRQUFNRSxxQkFBcUJBLENBQUNGLFdBQTRCO0FBQ3BELFlBQVFDLE9BQU9ELE1BQU0sR0FBQztBQUFBLE1BQ2xCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakI7QUFBUyxlQUFPO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTUcsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQzNCLE1BQU87QUFFWixVQUFNNEIsVUFBVXBELGdCQUFnQjtBQUNoQyxRQUFJLENBQUNvRCxTQUFTO0FBQ1ZsRCxZQUFNd0IsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFILGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNBLFlBQU10QixpQkFBaUJtRCxTQUFTLGlCQUFpQjVCLE1BQU1MLEVBQUUsTUFBTTtBQUFBLElBQ25FLFNBQVNPLFFBQU87QUFDWixVQUFJLENBQUMwQixRQUFRQyxPQUFPQyxPQUFRRixTQUFRQyxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFROUIsTUFBTSw0QkFBNEJBLE1BQUs7QUFDL0N4QixZQUFNd0IsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dILG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNa0Msa0JBQWtCO0FBQ3hCLFFBQU1DLGtCQUFrQjtBQUV4QixTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFHWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwrQkFDWDtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNdEMsU0FBU2Isa0JBQWtCakIsd0JBQXdCc0MsU0FBUyxDQUFDLEdBQUcsV0FBVSxvREFDN0YsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlEQUErQztBQUFBO0FBQUEsWUFDaERKLE1BQU1tQztBQUFBQSxlQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVcsdURBQXVEVCxtQkFBbUIxQixNQUFNd0IsTUFBTSxDQUFDLElBQ25HRCx3QkFBY3ZCLE1BQU13QixNQUFNLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUcsTUFBSztBQUFBLFlBQ0wsU0FBU0c7QUFBQUEsWUFDVCxVQUFVN0I7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFFVEEsdUJBQ0csdUJBQUMsYUFBVSxXQUFVLDBCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQyxJQUUzQyx1QkFBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEI7QUFBQTtBQUFBLFVBVnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBO0FBQUEsUUFDQ3dCLGdCQUNHO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0xQixTQUFTLEdBQUc5Qix3QkFBd0JzQyxTQUFTLElBQUlULEVBQUUsU0FBUztBQUFBLFlBQzNFLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsWUFBUyxXQUFVLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0F0QlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLFNBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0E7QUFBQSxJQUdBLHVCQUFDLFFBQUcsV0FBVSxrRUFDVjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV3NDLGlCQUFpQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBVSw4QkFDVjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csSUFBSSxhQUFhakMsTUFBTVEsUUFBUWIsRUFBRTtBQUFBLFlBQ2pDLFdBQVU7QUFBQSxZQUVUSyxnQkFBTVEsUUFBUTRCLFFBQVFwQyxNQUFNcUMsZUFBZTtBQUFBO0FBQUEsVUFKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXSixpQkFBaUIsNEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUM1Qyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCN0Qsc0JBQVk0QixNQUFNc0MsWUFBWSxNQUFNLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxXQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV0wsaUJBQWlCLDZCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QmpDLGdCQUFNdUMsZ0JBQWdCbkUsWUFBWTRCLE1BQU11QyxlQUFlLE1BQU0sSUFBSSxTQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1IO0FBQUEsV0FGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdOLGlCQUFpQix3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFFBQ3hDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJqQyxnQkFBTXdDLGFBQWFKLFFBQVEsU0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFdBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXSCxpQkFBaUIseUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCakMsZ0JBQU15QyxPQUFPTCxRQUFRLFNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxXQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV0gsaUJBQWlCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsUUFDMUMsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QmpDLGdCQUFNMEMsV0FBV04sUUFBUSxTQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsV0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdILGlCQUFpQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJqQyxnQkFBTTJDLFVBQVVQLFFBQVEsU0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFdBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXSCxpQkFBaUIsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUN2Qyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCakMsZ0JBQU00Qyx5QkFBeUIsU0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXWCxpQkFBaUIsaUNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRCx1QkFBQyxRQUFHLFdBQVUsOEJBQThCakMsZ0JBQU02QyxvQkFBb0IsU0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFdBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXWixpQkFBaUIscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUNyQyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCakMsZ0JBQU04QyxTQUFTLFNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2IsaUJBQWlCLDhCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QmpDLGdCQUFNK0MsaUJBQWlCLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXBESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBO0FBQUEsSUFJQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0RBQWtELGdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFFbkYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCw2QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN4Rix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBRWxGLENBQUN4QyxxQkFBcUJQLE1BQU1tQix3QkFDekIsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx5QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUV4Rix1QkFBQyxRQUFHLFdBQVUsMkVBQTBFLDJCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBWHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNYbkIsaUJBQU1lLFNBQVMsSUFBSWlDLElBQUksQ0FBQy9ELE1BQU1nRSxVQUFVO0FBQ3RDLGdCQUFNdkMsV0FBWW5CLE9BQU9OLEtBQUsrQixRQUFRLElBQUl6QixPQUFPTixLQUFLZ0MsVUFBVTtBQUVoRSxnQkFBTWlDLFdBQVczRCxPQUFPTixLQUFLaUMsZUFBZSxLQUFLO0FBQ2pELGdCQUFNaUMsZUFBZXpDLFdBQVd3QztBQUdoQyxnQkFBTUUsVUFBVSxDQUFDN0MscUJBQXFCUCxNQUFNbUIsdUJBQXVCbkMsZ0JBQWdCQyxJQUFJLElBQUk7QUFDM0YsZ0JBQU1vRSxZQUFZRixlQUFlQztBQUVqQyxpQkFDSSx1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGtDQUNUbkUsZUFBS3FFLGFBQ0YsdUJBQUMsUUFBSyxJQUFJLGNBQWNyRSxLQUFLcUUsVUFBVSxJQUFJLFdBQVUseURBQ2pEO0FBQUEscUNBQUMsU0FBSSxXQUFVLDZCQUE2QnJFLGVBQUtzRSxnQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxnQkFBRXRFLEtBQUt1RTtBQUFBQSxnQkFBYTtBQUFBLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLElBRUEsbUNBQ0k7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQTZCdkUsZUFBS3NFLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGdCQUFFdEUsS0FBS3VFO0FBQUFBLGdCQUFhO0FBQUEsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsaUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FWUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsOENBQThDdkUsZUFBSytCLFlBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUUsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzVDLHNCQUFZYSxLQUFLZ0MsWUFBWSxVQUFVLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFFckcsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzdDLHNCQUFZOEUsVUFBVSxVQUFVLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThGO0FBQUEsWUFDOUYsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzlFLHNCQUFZK0UsY0FBYyxVQUFVLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUEsWUFHakcsQ0FBQzVDLHFCQUFxQlAsTUFBTW1CLHdCQUN6Qix1QkFBQyxRQUFHLFdBQVUsOENBQ1QvQyxzQkFBWWdGLFNBQVMsVUFBVSxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHSix1QkFBQyxRQUFHLFdBQVUsdUVBQ1RoRixzQkFBWWlGLFdBQVcsVUFBVSxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUE3QktwRSxLQUFLVSxNQUFNc0QsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxRQUVSLENBQUMsS0E1Q0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFdBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4REEsS0EvREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdFQTtBQUFBLFNBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxtQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDVixXQUFDMUMscUJBQXFCLENBQUNQLE1BQU1tQix3QkFBd0JuQixNQUFNZCxTQUFTYyxNQUFNZCxNQUFNQyxTQUFTLEtBQ3RGLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyw0Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzdFYSxNQUFNZCxNQUFNOEQ7QUFBQUEsVUFBSSxDQUFDMUQsS0FBSzJELFVBQ25CLHVCQUFDLFNBQThCLFdBQVUscUNBQ3JDO0FBQUEsbUNBQUMsVUFBSyxXQUFXaEIsZ0JBQWdCd0IsUUFBUSxpQkFBaUIsZUFBZSxHQUFJbkU7QUFBQUEsa0JBQUlvRTtBQUFBQSxjQUFTO0FBQUEsY0FBR3BFLElBQUlxRTtBQUFBQSxjQUFLO0FBQUEsaUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsWUFDekcsdUJBQUMsVUFBSyxXQUFXekIsaUJBQWtCOUQsc0JBQVlrQixJQUFJRSxRQUFRLFVBQVUsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxlQUZqRUYsSUFBSXNFLFVBQVVYLE9BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxRQUNIO0FBQUEsV0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FWUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxxREFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLGlDQUFDLFVBQUssV0FBV2hCLGlCQUFpQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFrQjlELHNCQUFZcUMsaUJBQWlCQyxVQUFVLFVBQVUsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxhQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLGlDQUFDLFVBQUssV0FBV3VCLGlCQUFpQiw4QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsWUFBRzlELFlBQVlxQyxpQkFBaUJFLG9CQUFvQixVQUFVO0FBQUEsZUFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0c7QUFBQSxhQUZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLGlDQUFDLFVBQUssV0FBV3NCLGlCQUFpQiwrQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsWUFBRzlELFlBQVlxQyxpQkFBaUJHLHNCQUFzQixVQUFVO0FBQUEsZUFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxhQUZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDLENBQUNMLHFCQUNFLG1DQUNJO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXLEdBQUcwQixlQUFlLGtCQUFrQiwrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZ0JBQWdCdUIsUUFBUSxXQUFXLFdBQVcsQ0FBQyxrQkFBbUJyRixzQkFBWXFDLGlCQUFpQkksU0FBUyxVQUFVLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdJO0FBQUEsZUFGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXb0IsaUJBQ1pqQyxnQkFBTW1CLHVCQUF1Qix1QkFBdUIseUJBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBV2UsaUJBQWlCO0FBQUE7QUFBQSxjQUFHOUQsWUFBWXFDLGlCQUFpQkssWUFBWSxVQUFVO0FBQUEsaUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsZUFKOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFFSix1QkFBQyxTQUFJLFdBQVUsd0RBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVcsR0FBR21CLGVBQWUsMEJBQTBCLDRCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBRXpFLHVCQUFDLFVBQUssV0FBVyxHQUFHQyxnQkFBZ0J1QixRQUFRLFdBQVcsU0FBUyxDQUFDLDhCQUM1RHJGLHNCQUFZNEIsTUFBTTZELGNBQWMsVUFBVSxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0F2REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdEQTtBQUFBLE9Bdk9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyT0E7QUFFUjtBQUFFbkUsR0FyVldELHdCQUFzQjtBQUFBLFVBQ2hCL0IsV0FDRUMsYUFDZWlCLGdCQUVRZixXQUFXO0FBQUE7QUFBQWlHLEtBTDFDckU7QUFBc0IsSUFBQXFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VDcnVkSXRlbSIsInNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnIiwiaXNTYWxlc09yZGVyRWRpdGFibGUiLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QZW5jaWwiLCJJb1ByaW50IiwiZm9ybWF0VmFsdWUiLCJpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwiYmVnaW5QZGZQcmV2aWV3IiwiZmluaXNoUGRmUHJldmlldyIsInRvYXN0IiwiRmFTcGlubmVyIiwidXNlUGVybWlzc2lvbnMiLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImdldExpc3RSZXR1cm5QYXRoIiwiZ2V0SXRlbVRheFRvdGFsIiwiaXRlbSIsInRheGVzIiwibGVuZ3RoIiwicmVkdWNlIiwic3VtIiwidGF4IiwiTnVtYmVyIiwiYW1vdW50IiwiUGVkaWRvc1ZlbnRhRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJpc1ByaW50aW5nIiwic2V0SXNQcmludGluZyIsIm9yZGVyIiwibG9hZGluZyIsImVycm9yIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJjYW5FZGl0IiwiaXNDbGllbnRUYXhFeGVtcHQiLCJjbGllbnQiLCJjYWxjdWxhdGVkVG90YWxzIiwic3VidG90YWwiLCJ0b3RhbEl0ZW1EaXNjb3VudHMiLCJnbG9iYWxEaXNjb3VudEFtb3VudCIsInRheEJhc2UiLCJ0b3RhbFRheGVzIiwiaXRlbXMiLCJxdWFudGl0eSIsInVuaXRfcHJpY2UiLCJkaXNjb3VudF9hbW91bnQiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsIml0ZW1UYXhBbW91bnQiLCJpdGVtU3VtIiwiY2FuRWRpdE9yZGVyIiwiZ2V0U3RhdHVzVGV4dCIsInN0YXR1cyIsIlN0cmluZyIsImdldFN0YXR1c0NsYXNzTmFtZSIsImhhbmRsZVByaW50Iiwic2Vzc2lvbiIsIndpbmRvdyIsImNsb3NlZCIsImNsb3NlIiwiY29uc29sZSIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsIm9yZGVyX251bWJlciIsIm5hbWUiLCJjbGllbnRfbmFtZSIsIm9yZGVyX2RhdGUiLCJkZWxpdmVyeV9kYXRlIiwic2FsZXNwZXJzb24iLCJidXllciIsInRyYW5zcG9ydCIsImN1cnJlbmN5IiwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyIiwiZGVsaXZlcnlfYWRkcmVzcyIsIm5vdGVzIiwiZXhjaGFuZ2VfcmF0ZSIsIm1hcCIsImluZGV4IiwiZGlzY291bnQiLCJsaW5lU3VidG90YWwiLCJpdGVtVGF4IiwibGluZVRvdGFsIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3RfY29kZSIsInJlcGxhY2UiLCJ0YXhfbmFtZSIsInJhdGUiLCJ0YXhfaWQiLCJ0b3RhbF9hbW91bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZWRpZG9zVmVudGFEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbi8vIC0tLSBNT0RJRklDQURPOiBJbXBvcnRhbW9zIFNhbGVzT3JkZXJJdGVtIC0tLVxuaW1wb3J0IHsgc2FsZXNPcmRlcnNNb2R1bGVDb25maWcsIGlzU2FsZXNPcmRlckVkaXRhYmxlLCB0eXBlIFNhbGVzT3JkZXIsIHR5cGUgU2FsZXNPcmRlckl0ZW0gfSBmcm9tICcuLi9wZWRpZG9zX3ZlbnRhX2NvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2ssIElvUGVuY2lsLCBJb1ByaW50IH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY2xpZW50VGF4RXhlbXB0aW9uJztcbmltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgYmVnaW5QZGZQcmV2aWV3LCBmaW5pc2hQZGZQcmV2aWV3IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvYmxvYkhlbHBlcic7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU3Bpbm5lciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG4vLyAtLS0gTlVFVk86IEhlbHBlciBwYXJhIGNhbGN1bGFyIGltcHVlc3RvcyBkZSB1biDDrXRlbSAtLS1cbmNvbnN0IGdldEl0ZW1UYXhUb3RhbCA9IChpdGVtOiBTYWxlc09yZGVySXRlbSkgPT4ge1xuICAgIGlmICghaXRlbS50YXhlcyB8fCBpdGVtLnRheGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgcmV0dXJuIGl0ZW0udGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbn07XG5cbmV4cG9ydCBjb25zdCBQZWRpZG9zVmVudGFEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IFtpc1ByaW50aW5nLCBzZXRJc1ByaW50aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCB7IGl0ZW06IG9yZGVyLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08U2FsZXNPcmRlcj4oc2FsZXNPcmRlcnNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihzYWxlc09yZGVyc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkVkaXQgPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnZWRpdCcpIDogdHJ1ZTtcblxuICAgIGNvbnN0IGlzQ2xpZW50VGF4RXhlbXB0ID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdChvcmRlcj8uY2xpZW50KSxcbiAgICAgICAgW29yZGVyPy5jbGllbnRdXG4gICAgKTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFvcmRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHsgc3VidG90YWw6IDAsIHRvdGFsSXRlbURpc2NvdW50czogMCwgZ2xvYmFsRGlzY291bnRBbW91bnQ6IDAsIHRheEJhc2U6IDAsIHRvdGFsVGF4ZXM6IDAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGl0ZW1zID0gb3JkZXIuaXRlbXMgfHwgW107XG5cbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHN1bSArIChOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKSk7XG4gICAgICAgIH0sIDApO1xuXG4gICAgICAgIGNvbnN0IHRvdGFsSXRlbURpc2NvdW50cyA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gc3VtICsgKE51bWJlcihpdGVtLmRpc2NvdW50X2Ftb3VudCkgfHwgMCk7XG4gICAgICAgIH0sIDApO1xuXG4gICAgICAgIGNvbnN0IGdsb2JhbERpc2NvdW50QW1vdW50ID0gTnVtYmVyKG9yZGVyLmRpc2NvdW50X2Ftb3VudCkgfHwgMDtcblxuICAgICAgICBjb25zdCB0YXhCYXNlID0gc3VidG90YWwgLSB0b3RhbEl0ZW1EaXNjb3VudHMgLSBnbG9iYWxEaXNjb3VudEFtb3VudDtcblxuICAgICAgICBsZXQgdG90YWxUYXhlcyA9IDA7XG4gICAgICAgIGlmICghaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGlmIChvcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtVGF4QW1vdW50ID0gKGl0ZW0udGF4ZXMgfHwgW10pLnJlZHVjZSgoaXRlbVN1bSwgdGF4KSA9PiBpdGVtU3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN1bSArIGl0ZW1UYXhBbW91bnQ7XG4gICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSAob3JkZXIudGF4ZXMgfHwgW10pLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4geyBzdWJ0b3RhbCwgdG90YWxJdGVtRGlzY291bnRzLCBnbG9iYWxEaXNjb3VudEFtb3VudCwgdGF4QmFzZSwgdG90YWxUYXhlcyB9O1xuICAgIH0sIFtvcmRlciwgaXNDbGllbnRUYXhFeGVtcHRdKTtcblxuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBhbCBjYXJnYXIgZWwgcGVkaWRvOiB7ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghb3JkZXIpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5ObyBzZSBlbmNvbnRyw7MgZWwgcGVkaWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IGNhbkVkaXRPcmRlciA9IGNhbkVkaXQgJiYgaXNTYWxlc09yZGVyRWRpdGFibGUob3JkZXIpO1xuXG4gICAgLy8gUGVxdWXDsW9zIGhlbHBlcnMgcGFyYSBlbCBlc3RhZG9cbiAgICBjb25zdCBnZXRTdGF0dXNUZXh0ID0gKHN0YXR1czogc3RyaW5nIHwgbnVtYmVyKSA9PiB7XG4gICAgICAgIHN3aXRjaCAoU3RyaW5nKHN0YXR1cykpIHtcbiAgICAgICAgICAgIGNhc2UgJzEnOiByZXR1cm4gJ1BlbmRpZW50ZSc7XG4gICAgICAgICAgICBjYXNlICcyJzogcmV0dXJuICdQcm9jZXNhZG8nO1xuICAgICAgICAgICAgY2FzZSAnMyc6IHJldHVybiAnQXV0b3JpemFkbyc7XG4gICAgICAgICAgICBjYXNlICcwJzogcmV0dXJuICdBbnVsYWRvJztcbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiAnRGVzY29ub2NpZG8nO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBnZXRTdGF0dXNDbGFzc05hbWUgPSAoc3RhdHVzOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgc3dpdGNoIChTdHJpbmcoc3RhdHVzKSkge1xuICAgICAgICAgICAgY2FzZSAnMSc6IHJldHVybiAnYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDAnO1xuICAgICAgICAgICAgY2FzZSAnMic6IHJldHVybiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgICAgICAgIGNhc2UgJzMnOiByZXR1cm4gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCc7XG4gICAgICAgICAgICBjYXNlICcwJzogcmV0dXJuICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCc7XG4gICAgICAgICAgICBkZWZhdWx0OiByZXR1cm4gJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVByaW50ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIW9yZGVyKSByZXR1cm47XG5cbiAgICAgICAgY29uc3Qgc2Vzc2lvbiA9IGJlZ2luUGRmUHJldmlldygpO1xuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdQZXJtaXTDrSB2ZW50YW5hcyBlbWVyZ2VudGVzIHBhcmEgdmVyIGVsIFBERi4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldElzUHJpbnRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBmaW5pc2hQZGZQcmV2aWV3KHNlc3Npb24sIGAvc2FsZXMtb3JkZXJzLyR7b3JkZXIuaWR9L3BkZmApO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgZ2VuZXJhciBlbCBQREY6XCIsIGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRvIGdlbmVyYXIgZWwgY29tcHJvYmFudGUgUERGLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNQcmludGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gRXN0aWxvcyBwYXJhIGxvcyB0b3RhbGVzXG4gICAgY29uc3QgdG90YWxMYWJlbFN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIjtcbiAgICBjb25zdCB0b3RhbFZhbHVlU3R5bGUgPSBcInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRleHQtcmlnaHRcIjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgey8qIC0tLSBDQUJFQ0VSQSAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgbWItNCBib3JkZXItYiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1ncmF5LTUwMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVkaWRvOiB7b3JkZXIub3JkZXJfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG10LTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSAke2dldFN0YXR1c0NsYXNzTmFtZShvcmRlci5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNUZXh0KG9yZGVyLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNtOm10LTAgc206bWwtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNQcmludGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm14LTQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQcmludGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUHJpbnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAge2NhbkVkaXRPcmRlciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYCR7c2FsZXNPcmRlcnNNb2R1bGVDb25maWcuYmFzZVJvdXRlfS8ke2lkfS9lZGl0YXJgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVuY2lsIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdGFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIERFVEFMTEVTIERFIENBQkVDRVJBIChDYW1wb3MgcmVzdGF1cmFkb3MpIC0tLSAqL31cbiAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC14LTQgZ2FwLXktNiBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkNsaWVudGU8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvY2xpZW50ZXMvJHtvcmRlci5jbGllbnQ/LmlkfWB9IC8vIEFzdW1vIHJ1dGEgL3Byb3ZlZWRvcmVzLzppZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXIuY2xpZW50Py5uYW1lIHx8IG9yZGVyLmNsaWVudF9uYW1lIHx8ICdOL0EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIFBlZGlkbzwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntmb3JtYXRWYWx1ZShvcmRlci5vcmRlcl9kYXRlLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RmVjaGEgRW50cmVnYTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntvcmRlci5kZWxpdmVyeV9kYXRlID8gZm9ybWF0VmFsdWUob3JkZXIuZGVsaXZlcnlfZGF0ZSwgJ2RhdGUnKSA6ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VmVuZGVkb3I8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuc2FsZXNwZXJzb24/Lm5hbWUgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogLS0tIENBTVBPUyBSRVNUQVVSQURPUyAtLS0gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q29tcHJhZG9yPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+e29yZGVyLmJ1eWVyPy5uYW1lIHx8ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VHJhbnNwb3J0ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntvcmRlci50cmFuc3BvcnQ/Lm5hbWUgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Nb25lZGE8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuY3VycmVuY3k/Lm5hbWUgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5OwrogTy5DLjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntvcmRlci5wdXJjaGFzZV9vcmRlcl9udW1iZXIgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5EaXJlY2Npw7NuIEVudHJlZ2E8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuZGVsaXZlcnlfYWRkcmVzcyB8fCAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9Pk5vdGFzPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+e29yZGVyLm5vdGVzIHx8ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VGlwbyBkZSBjYW1iaW88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuZXhjaGFuZ2VfcmF0ZSB8fCAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kbD5cblxuXG4gICAgICAgICAgICB7LyogLS0tIFNFQ0NJw5NOIERFIElURU1TIChNT0RJRklDQURBKSAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMCBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgIEl0ZW1zIGRlbCBQZWRpZG9cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+QXJ0w61jdWxvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DYW50LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+UC4gVW5pdC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE1PRElGSUNBRE86IGEgbm9taW5hbCAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RGVzYy4gKE1vbnRvKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+U3VidG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE5VRVZPOiBDb2x1bW5hIGRlIEltcHVlc3RvcyBwb3Igw410ZW0gKENvbmRpY2lvbmFsKSAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgb3JkZXIuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5JbXB1ZXN0b3M8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnByLTZcIj5Ub3RhbCBMw61uZWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsob3JkZXIuaXRlbXMgfHwgW10pLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VidG90YWwgPSAoTnVtYmVyKGl0ZW0ucXVhbnRpdHkpICogTnVtYmVyKGl0ZW0udW5pdF9wcmljZSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAtLS0gTU9ESUZJQ0FETzogYSBub21pbmFsIC0tLVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkaXNjb3VudCA9IE51bWJlcihpdGVtLmRpc2NvdW50X2Ftb3VudCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGluZVN1YnRvdGFsID0gc3VidG90YWwgLSBkaXNjb3VudDsgLy8gQmFzZSBpbXBvbmlibGVcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAtLS0gTlVFVk86IENhbGN1bGFtb3MgaW1wdWVzdG9zIGRlbCDDrXRlbSAtLS1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXRlbVRheCA9ICFpc0NsaWVudFRheEV4ZW1wdCAmJiBvcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IGdldEl0ZW1UYXhUb3RhbChpdGVtKSA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXg7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWQgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIHNtOnBsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHJvZHVjdF9pZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2FydGljdWxvcy8ke2l0ZW0ucHJvZHVjdF9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntpdGVtLnByb2R1Y3RfbmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e2l0ZW0ucHJvZHVjdF9uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPih7aXRlbS5wcm9kdWN0X2NvZGV9KTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0ucXVhbnRpdHl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGl0ZW0udW5pdF9wcmljZSwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE1PRElGSUNBRE86IGEgbm9taW5hbCAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShkaXNjb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGxpbmVTdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gTlVFVk86IENlbGRhIGRlIEltcHVlc3RvcyAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBvcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtVGF4LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtMyBwci00IHRleHQtc20gdGV4dC1yaWdodCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGxpbmVUb3RhbCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgVE9UQUxFUyAoTU9ESUZJQ0FEQSkgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIEVzcGFjaW8gdmFjw61vIHBhcmEgYWxpbmVhciBjb24gZWwgZm9ybXVsYXJpbyAqL31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gSU1QVUVTVE9TIEdMT0JBTEVTIChDT05ESUNJT05BTCkgLS0tICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmICFvcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiBvcmRlci50YXhlcyAmJiBvcmRlci50YXhlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkltcHVlc3RvcyBHbG9iYWxlcyBBcGxpY2Fkb3M8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlci50YXhlcy5tYXAoKHRheCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3RheC50YXhfaWQgfHwgaW5kZXh9IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGUucmVwbGFjZSgndGV4dC1ncmF5LTYwMCcsICd0ZXh0LWdyYXktNzAwJyl9Pnt0YXgudGF4X25hbWV9ICh7dGF4LnJhdGV9JSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogLS0tIFJFU1VNRU4gREUgVE9UQUxFUyAoTU9ESUZJQ0FETykgLS0tICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlN1YnRvdGFsIChJdGVtcyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnN1YnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIChJdGVtcyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxJdGVtRGlzY291bnRzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIChHbG9iYWwpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT4tIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLmdsb2JhbERpc2NvdW50QW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSBmb250LXNlbWlib2xkYH0+QmFzZSBJbXBvbmlibGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZS5yZXBsYWNlKCd0ZXh0LXNtJywgJ3RleHQtYmFzZScpfSBmb250LXNlbWlib2xkYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IFwiSW1wdWVzdG9zIChJdGVtcyk6XCIgOiBcIkltcHVlc3RvcyAoR2xvYmFsKTpcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsTGFiZWxTdHlsZX0gdGV4dC1sZyBmb250LXNlbWlib2xkYH0+VG90YWwgRmluYWw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEVsIHRvdGFsIGZpbmFsIGRlbCBwZWRpZG8gZXMgbGEgZnVlbnRlIGRlIHZlcmRhZCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1sZycpfSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKG9yZGVyLnRvdGFsX2Ftb3VudCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBMYSBzZWNjacOzbiBvcmlnaW5hbCBkZSBpbXB1ZXN0b3MgZ2xvYmFsZXMgc2UgZWxpbWluYSBcbiAgICAgICAgICAgICAgICBwb3JxdWUgYWhvcmEgZXN0w6EgaW50ZWdyYWRhIGVuIGVsIHJlc3VtZW4gZGUgMyBjb2x1bW5hcyBkZSBhcnJpYmEgKi99XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvcGVkaWRvc192ZW50YS9wYWdlcy9QZWRpZG9zVmVudGFEZXRhaWxQYWdlLnRzeCJ9