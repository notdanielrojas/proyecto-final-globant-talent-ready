import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cobranzas/pages/CobranzasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { cobranzasModuleConfig } from "/src/features/cobranzas/cobranzas.config.tsx";
import { notasCreditoModuleConfig } from "/src/features/notas_credito/notas_credito.config.tsx";
import { notasFinancierasModuleConfig } from "/src/features/notas_financieras/notas_financieras.config.tsx";
import { SignedDocumentTypeBadge } from "/src/components/common/PendingSignedDocumentsTable.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import __vite__cjsImport12_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useCallback = __vite__cjsImport12_react["useCallback"]; const useEffect = __vite__cjsImport12_react["useEffect"]; const useMemo = __vite__cjsImport12_react["useMemo"]; const useState = __vite__cjsImport12_react["useState"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getAll } from "/src/services/apiService.ts";
import { taxesModuleConfig } from "/src/features/impuestos/impuestos.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const CobranzasDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const { item: customerPayment, loading, error } = useCrudItem(cobranzasModuleConfig, id);
  const [retentionTaxes, setRetentionTaxes] = useState([]);
  const [isDownloadingReceiptPdf, setIsDownloadingReceiptPdf] = useState(false);
  const handlePrintReceipt = useCallback(async () => {
    if (!id) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsDownloadingReceiptPdf(true);
    try {
      await finishPdfPreview(session, `/collections/${id}/pdf`);
    } catch (e) {
      if (!session.window.closed) session.window.close();
      console.error(e);
      toast.error("No se pudo generar el recibo en PDF.");
    } finally {
      setIsDownloadingReceiptPdf(false);
    }
  }, [id]);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await getAll(taxesModuleConfig.endpoint, { type: 3, per_page: 500 });
        if (!cancelled) setRetentionTaxes(res.data ?? []);
      } catch {
        if (!cancelled) setRetentionTaxes([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  const retentionTaxNameById = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const t of retentionTaxes) {
      m.set(t.id, t.name);
    }
    return m;
  }, [retentionTaxes]);
  const formatItemReference = (item) => {
    if (item.payment_method_code === "RET" && item.reference_number) {
      const id2 = Number(item.reference_number);
      if (!Number.isNaN(id2)) {
        return retentionTaxNameById.get(id2) ?? item.reference_number;
      }
    }
    return item.reference_number || "-";
  };
  const formatPaymentMethodLabel = (item) => {
    const code = item.payment_method_code;
    switch (code) {
      case "EFE":
        return "Efectivo";
      case "CHE":
        return "Cheque";
      case "CHR":
        return "Cheque recibido";
      case "TRA":
        return "Transferencia recibida";
      case "DOC":
        return "Documento";
      case "SAL":
        return "Saldo anticipado";
      case "RET": {
        if (item.reference_number) {
          const tid = Number(item.reference_number);
          if (!Number.isNaN(tid)) {
            const taxName = retentionTaxNameById.get(tid);
            if (taxName) return `Retención — ${taxName}`;
          }
        }
        return "Retención";
      }
      default:
        return code || "-";
    }
  };
  const modulePermission = getRequiredPermission(cobranzasModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const totals = useMemo(() => {
    if (!customerPayment) {
      return {
        grossAmount: 0,
        invoicesSubtotal: 0,
        creditNotesSubtotal: 0,
        financialNotesSubtotal: 0,
        discount: 0,
        totalTaxes: 0,
        netAmount: 0,
        totalApplied: 0
      };
    }
    const invoicesSubtotal = customerPayment.applied_invoices?.reduce(
      (sum, app) => sum + (Number(app.amount_applied) || 0),
      0
    ) || 0;
    const creditNotesSubtotal = customerPayment.applied_credit_notes?.reduce(
      (sum, app) => sum + (Number(app.amount_applied) || 0),
      0
    ) || 0;
    const financialNotesSubtotal = customerPayment.applied_financial_notes?.reduce(
      (sum, app) => sum + (Number(app.amount_applied) || 0),
      0
    ) || 0;
    const grossAmount = invoicesSubtotal + creditNotesSubtotal + financialNotesSubtotal;
    const discount = customerPayment.discount_amount || 0;
    const totalTaxes = customerPayment.taxes?.reduce(
      (sum, tax) => sum + (Number(tax.amount) || 0),
      0
    ) || 0;
    const netAmount = grossAmount - discount - totalTaxes;
    return {
      grossAmount,
      invoicesSubtotal,
      creditNotesSubtotal,
      financialNotesSubtotal,
      discount,
      totalTaxes,
      netAmount,
      totalApplied: grossAmount
    };
  }, [customerPayment]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
    lineNumber: 199,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
    lineNumber: 200,
    columnNumber: 21
  }, this);
  if (!customerPayment) return /* @__PURE__ */ jsxDEV("div", { children: "No se encontró la cobranza." }, void 0, false, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
    lineNumber: 201,
    columnNumber: 32
  }, this);
  const mainDetails = [
    {
      label: "Cliente",
      // ✅ CAMBIO: Convertido en 'render' para añadir el Link
      render: () => customerPayment.client ? /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/clientes/${customerPayment.client.id}`,
          className: "text-indigo-600 hover:text-indigo-800 hover:underline",
          children: customerPayment.client?.name
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 209,
          columnNumber: 5
        },
        this
      ) : "N/A"
    },
    { label: "Nº Recibo", value: customerPayment.collection_number },
    { label: "Fecha", value: formatValue(customerPayment.collection_date, "date") },
    // Usamos el total_amount (Total Cobrado) del header
    { label: "Total Cobrado", value: formatValue(customerPayment.total_amount, "currency") },
    {
      label: "Total aplicado",
      value: formatValue(totals.totalApplied, "currency")
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3 pb-4 border-b sm:flex-row sm:justify-between sm:items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(cobranzasModuleConfig.baseRoute)), className: "flex items-center text-sm text-gray-600 hover:text-gray-900", children: [
          /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-1" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 236,
            columnNumber: 25
          }, this),
          " Volver al listado"
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 235,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: [
          cobranzasModuleConfig.moduleName,
          " #",
          customerPayment.collection_number
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 238,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 234,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => void handlePrintReceipt(),
            disabled: isDownloadingReceiptPdf,
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            title: "Abrir recibo en PDF",
            children: [
              isDownloadingReceiptPdf ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 -ml-1 animate-spin", "aria-hidden": true }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 251,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5 mr-2 -ml-1", "aria-hidden": true }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 253,
                columnNumber: 13
              }, this),
              "Imprimir recibo"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 243,
            columnNumber: 21
          },
          this
        ),
        canEdit && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(`${cobranzasModuleConfig.baseRoute}/${id}/editar`),
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-700",
            children: [
              /* @__PURE__ */ jsxDEV(IoPencil, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 263,
                columnNumber: 29
              }, this),
              " Editar"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 258,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 242,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 233,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-5", children: mainDetails.map(
      (detail) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-sm font-medium text-gray-500", children: detail.label }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 273,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base font-semibold text-gray-900", children: "render" in detail ? detail.render ? detail.render() : null : detail.value }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 274,
          columnNumber: 25
        }, this)
      ] }, detail.label, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 272,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 270,
      columnNumber: 13
    }, this),
    customerPayment.applied_invoices && customerPayment.applied_invoices.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Facturas Cobradas" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 285,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Factura" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 290,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 291,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto Aplicado" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 292,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 289,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 288,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: customerPayment.applied_invoices.map(
          (app) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `/facturas-de-venta/${app.sales_invoice.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: app.sales_invoice.invoice_number
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 300,
                columnNumber: 45
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 298,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: formatValue(app.sales_invoice.invoice_date, "date") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 307,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(app.amount_applied, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 308,
              columnNumber: 41
            }, this)
          ] }, app.id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 297,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 295,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV(
            "td",
            {
              colSpan: 2,
              className: "py-3.5 pl-4 pr-3 text-right text-sm font-bold text-gray-900 sm:pl-6"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 314,
              columnNumber: 37
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3.5 text-right text-sm font-bold text-gray-900", children: [
            "TOTAL APLICADO: ",
            formatValue(totals.invoicesSubtotal, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 320,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 313,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 312,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 287,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 286,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 284,
      columnNumber: 7
    }, this),
    customerPayment.applied_credit_notes && customerPayment.applied_credit_notes.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Notas de Crédito Aplicadas" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 333,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 338,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Comprobante" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 339,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Factura" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 340,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto Aplicado" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 341,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 337,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 336,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: customerPayment.applied_credit_notes.map((app) => {
          const note = app.credit_note;
          const docLabel = note.voucher_number || String(note.id);
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: formatValue(note.issue_date, "date") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 350,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm font-medium", children: /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `${notasCreditoModuleConfig.baseRoute}/${note.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: docLabel
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 352,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 351,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: note.sales_invoice?.id ? /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `/facturas-de-venta/${note.sales_invoice.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: note.sales_invoice.invoice_number ?? note.sales_invoice.id
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 361,
                columnNumber: 23
              },
              this
            ) : "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 359,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(app.amount_applied, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 371,
              columnNumber: 45
            }, this)
          ] }, app.id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 349,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 344,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 3, className: "py-3.5 pl-4 pr-3 text-right text-sm font-bold text-gray-900 sm:pl-6" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 378,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3.5 text-right text-sm font-bold text-gray-900", children: [
            "TOTAL APLICADO: ",
            formatValue(totals.creditNotesSubtotal, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 379,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 377,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 376,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 335,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 334,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 332,
      columnNumber: 7
    }, this),
    customerPayment.applied_financial_notes && customerPayment.applied_financial_notes.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Notas Financieras Aplicadas" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 392,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Tipo" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 397,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 398,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Comprobante" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 399,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Factura" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 400,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto Aplicado" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 401,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 396,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 395,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: customerPayment.applied_financial_notes.map((app) => {
          const note = app.financial_note;
          const docLabel = note.voucher_number || String(note.id);
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: /* @__PURE__ */ jsxDEV(SignedDocumentTypeBadge, { type: note.type }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 411,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 410,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: formatValue(note.issue_date, "date") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 413,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm font-medium", children: /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `${notasFinancierasModuleConfig.baseRoute}/${note.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: docLabel
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 415,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 414,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: note.sales_invoice?.id ? /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `/facturas-de-venta/${note.sales_invoice.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: note.sales_invoice.invoice_number ?? note.sales_invoice.id
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
                lineNumber: 424,
                columnNumber: 23
              },
              this
            ) : "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 422,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500 font-semibold", children: formatValue(app.amount_applied, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 434,
              columnNumber: 45
            }, this)
          ] }, app.id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 409,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 404,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 4, className: "py-3.5 pl-4 pr-3 text-right text-sm font-bold text-gray-900 sm:pl-6" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 441,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3.5 text-right text-sm font-bold text-gray-900", children: [
            "TOTAL APLICADO: ",
            formatValue(totals.financialNotesSubtotal, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 442,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 440,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 439,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 394,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 393,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 391,
      columnNumber: 7
    }, this),
    customerPayment.items && customerPayment.items.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Medios de Pago Recibidos" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 455,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Medio" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 460,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Banco" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 461,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Cheque/Certificado" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 462,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha emisión" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 463,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha pago/cobro" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 464,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Emisor del cheque" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 465,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Referencia" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 466,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "A la orden" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 467,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "CUIT emisor" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 468,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Valor" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 469,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 459,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 458,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: customerPayment.items.map(
          (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: formatPaymentMethodLabel(item) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 475,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.bank_name || "N/A" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 476,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.check_number || "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 477,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.check_date ? formatValue(item.check_date, "date") : "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 478,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.check_due_date ? formatValue(item.check_due_date, "date") : "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 479,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.check_holder || "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 480,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: formatItemReference(item) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 481,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.payment_method_code === "CHE" ? item.is_to_order ? "Sí" : "No" : "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 482,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.issuer_cuit || "-" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 483,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-medium", children: formatValue(item.value, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 484,
              columnNumber: 41
            }, this)
          ] }, item.id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 474,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 472,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 8, className: "py-3.5 pl-4 pr-3 text-right text-sm font-bold text-gray-900 sm:pl-6" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 490,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "px-3 py-3.5 text-right text-sm font-bold text-gray-900", children: [
            "TOTAL COBRADO: ",
            formatValue(customerPayment.total_amount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 491,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 489,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 488,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 457,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 456,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 454,
      columnNumber: 7
    }, this),
    customerPayment.taxes && customerPayment.taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Retenciones Aplicadas" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 503,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto/Retención" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 508,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 509,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 510,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 507,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 506,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: customerPayment.taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 517,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: tax.rate }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 518,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
              lineNumber: 519,
              columnNumber: 41
            }, this)
          ] }, tax.tax_id || index, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
            lineNumber: 516,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 513,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 505,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 504,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 502,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4 border-t", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/3 p-4 bg-gray-50 border rounded-lg space-y-2 text-sm", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Total aplicado:" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 532,
          columnNumber: 59
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.totalApplied, "currency") }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 532,
          columnNumber: 88
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 532,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-red-600", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Descuento:" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 533,
          columnNumber: 72
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: [
          "- ",
          formatValue(totals.discount, "currency")
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 533,
          columnNumber: 96
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 533,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-red-600", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Retenciones:" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 534,
          columnNumber: 72
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: [
          "- ",
          formatValue(totals.totalTaxes, "currency")
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 534,
          columnNumber: 98
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 534,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold text-base border-t pt-2 mt-2", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Neto Cobrado:" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 535,
          columnNumber: 98
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.netAmount, "currency") }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
          lineNumber: 535,
          columnNumber: 125
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
        lineNumber: 535,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 531,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
      lineNumber: 529,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx",
    lineNumber: 231,
    columnNumber: 5
  }, this);
};
_s(CobranzasDetailPage, "vb3JwJiQocx3+54q6p/SjVchCrI=", false, function() {
  return [useParams, useNavigate, usePermissions, useCrudItem];
});
_c = CobranzasDetailPage;
var _c;
$RefreshReg$(_c, "CobranzasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cobranzas/pages/CobranzasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUx3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuTHhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLDZCQUE2RTtBQUN0RixTQUFTQyxnQ0FBZ0M7QUFDekMsU0FBU0Msb0NBQW9DO0FBQzdDLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDMUQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUJDLHdCQUF3QjtBQUVsRCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCQywrQkFBK0I7QUFDL0QsU0FBU0MsY0FBYztBQUN2QixTQUFTQyx5QkFBbUM7QUFDNUMsU0FBU0MseUJBQXlCO0FBTzNCLGFBQU1DLHNCQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sRUFBRUMsR0FBRyxJQUFJN0IsVUFBMEI7QUFDekMsUUFBTThCLFdBQVc3QixZQUFZO0FBQzdCLFFBQU0sRUFBRThCLG9CQUFvQixJQUFJVixlQUFlO0FBRS9DLFFBQU0sRUFBRVcsTUFBTUMsaUJBQWlCQyxTQUFTQyxNQUFNLElBQUloQyxZQUFvQ0MsdUJBQXVCeUIsRUFBRTtBQUUvRyxRQUFNLENBQUNPLGdCQUFnQkMsaUJBQWlCLElBQUl0QixTQUFnQixFQUFFO0FBQzlELFFBQU0sQ0FBQ3VCLHlCQUF5QkMsMEJBQTBCLElBQUl4QixTQUFTLEtBQUs7QUFFNUUsUUFBTXlCLHFCQUFxQjVCLFlBQVksWUFBWTtBQUMvQyxRQUFJLENBQUNpQixHQUFJO0FBRVQsVUFBTVksVUFBVXRCLGdCQUFnQjtBQUNoQyxRQUFJLENBQUNzQixTQUFTO0FBQ1Z6QixZQUFNbUIsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFJLCtCQUEyQixJQUFJO0FBQy9CLFFBQUk7QUFDQSxZQUFNbkIsaUJBQWlCcUIsU0FBUyxnQkFBZ0JaLEVBQUUsTUFBTTtBQUFBLElBQzVELFNBQVNhLEdBQUc7QUFDUixVQUFJLENBQUNELFFBQVFFLE9BQU9DLE9BQVFILFNBQVFFLE9BQU9FLE1BQU07QUFDakRDLGNBQVFYLE1BQU1PLENBQUM7QUFDZjFCLFlBQU1tQixNQUFNLHNDQUFzQztBQUFBLElBQ3RELFVBQUM7QUFDR0ksaUNBQTJCLEtBQUs7QUFBQSxJQUNwQztBQUFBLEVBQ0osR0FBRyxDQUFDVixFQUFFLENBQUM7QUFFUGhCLFlBQVUsTUFBTTtBQUNaLFFBQUlrQyxZQUFZO0FBQ2hCLFVBQU0sWUFBWTtBQUNkLFVBQUk7QUFDQSxjQUFNQyxNQUFNLE1BQU14QixPQUFZQyxrQkFBa0J3QixVQUFVLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxJQUFJLENBQUM7QUFDcEYsWUFBSSxDQUFDSixVQUFXVixtQkFBa0JXLElBQUlJLFFBQVEsRUFBRTtBQUFBLE1BQ3BELFFBQVE7QUFDSixZQUFJLENBQUNMLFVBQVdWLG1CQUFrQixFQUFFO0FBQUEsTUFDeEM7QUFBQSxJQUNKLEdBQUc7QUFDSCxXQUFPLE1BQU07QUFDVFUsa0JBQVk7QUFBQSxJQUNoQjtBQUFBLEVBQ0osR0FBRyxFQUFFO0FBRUwsUUFBTU0sdUJBQXVCdkMsUUFBUSxNQUFNO0FBQ3ZDLFVBQU13QyxJQUFJLG9CQUFJQyxJQUFvQjtBQUNsQyxlQUFXQyxLQUFLcEIsZ0JBQWdCO0FBQzVCa0IsUUFBRUcsSUFBSUQsRUFBRTNCLElBQUkyQixFQUFFRSxJQUFJO0FBQUEsSUFDdEI7QUFDQSxXQUFPSjtBQUFBQSxFQUNYLEdBQUcsQ0FBQ2xCLGNBQWMsQ0FBQztBQUVuQixRQUFNdUIsc0JBQXNCQSxDQUFDM0IsU0FBOEI7QUFDdkQsUUFBSUEsS0FBSzRCLHdCQUF3QixTQUFTNUIsS0FBSzZCLGtCQUFrQjtBQUM3RCxZQUFNaEMsTUFBS2lDLE9BQU85QixLQUFLNkIsZ0JBQWdCO0FBQ3ZDLFVBQUksQ0FBQ0MsT0FBT0MsTUFBTWxDLEdBQUUsR0FBRztBQUNuQixlQUFPd0IscUJBQXFCVyxJQUFJbkMsR0FBRSxLQUFLRyxLQUFLNkI7QUFBQUEsTUFDaEQ7QUFBQSxJQUNKO0FBQ0EsV0FBTzdCLEtBQUs2QixvQkFBb0I7QUFBQSxFQUNwQztBQUdBLFFBQU1JLDJCQUEyQkEsQ0FBQ2pDLFNBQXNDO0FBQ3BFLFVBQU1rQyxPQUFPbEMsS0FBSzRCO0FBQ2xCLFlBQVFNLE1BQUk7QUFBQSxNQUNSLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1gsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1gsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYLEtBQUssT0FBTztBQUNSLFlBQUlsQyxLQUFLNkIsa0JBQWtCO0FBQ3ZCLGdCQUFNTSxNQUFNTCxPQUFPOUIsS0FBSzZCLGdCQUFnQjtBQUN4QyxjQUFJLENBQUNDLE9BQU9DLE1BQU1JLEdBQUcsR0FBRztBQUNwQixrQkFBTUMsVUFBVWYscUJBQXFCVyxJQUFJRyxHQUFHO0FBQzVDLGdCQUFJQyxRQUFTLFFBQU8sZUFBZUEsT0FBTztBQUFBLFVBQzlDO0FBQUEsUUFDSjtBQUNBLGVBQU87QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUNJLGVBQU9GLFFBQVE7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNRyxtQkFBbUIvQyxzQkFBc0JsQixzQkFBc0JrRSxTQUFTO0FBQzlFLFFBQU1DLGFBQWFGLG1CQUFtQjlDLHdCQUF3QjhDLGdCQUFnQixJQUFJO0FBQ2xGLFFBQU1HLFVBQVVELGFBQWF4QyxvQkFBb0J3QyxZQUFZLE1BQU0sSUFBSTtBQUV2RSxRQUFNRSxTQUFTM0QsUUFBUSxNQUFNO0FBQ3pCLFFBQUksQ0FBQ21CLGlCQUFpQjtBQUNsQixhQUFPO0FBQUEsUUFDSHlDLGFBQWE7QUFBQSxRQUNiQyxrQkFBa0I7QUFBQSxRQUNsQkMscUJBQXFCO0FBQUEsUUFDckJDLHdCQUF3QjtBQUFBLFFBQ3hCQyxVQUFVO0FBQUEsUUFDVkMsWUFBWTtBQUFBLFFBQ1pDLFdBQVc7QUFBQSxRQUNYQyxjQUFjO0FBQUEsTUFDbEI7QUFBQSxJQUNKO0FBRUEsVUFBTU4sbUJBQW1CMUMsZ0JBQWdCaUQsa0JBQWtCQztBQUFBQSxNQUN2RCxDQUFDQyxLQUFLQyxRQUFRRCxPQUFPdEIsT0FBT3VCLElBQUlDLGNBQWMsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDSixLQUFLO0FBRUwsVUFBTVYsc0JBQXNCM0MsZ0JBQWdCc0Qsc0JBQXNCSjtBQUFBQSxNQUM5RCxDQUFDQyxLQUFLQyxRQUFRRCxPQUFPdEIsT0FBT3VCLElBQUlDLGNBQWMsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDSixLQUFLO0FBRUwsVUFBTVQseUJBQXlCNUMsZ0JBQWdCdUQseUJBQXlCTDtBQUFBQSxNQUNwRSxDQUFDQyxLQUFLQyxRQUFRRCxPQUFPdEIsT0FBT3VCLElBQUlDLGNBQWMsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDSixLQUFLO0FBRUwsVUFBTVosY0FBY0MsbUJBQW1CQyxzQkFBc0JDO0FBRTdELFVBQU1DLFdBQVc3QyxnQkFBZ0J3RCxtQkFBbUI7QUFFcEQsVUFBTVYsYUFBYTlDLGdCQUFnQnlELE9BQU9QO0FBQUFBLE1BQ3RDLENBQUNDLEtBQUtPLFFBQVFQLE9BQU90QixPQUFPNkIsSUFBSUMsTUFBTSxLQUFLO0FBQUEsTUFDM0M7QUFBQSxJQUNKLEtBQUs7QUFFTCxVQUFNWixZQUFZTixjQUFjSSxXQUFXQztBQUUzQyxXQUFPO0FBQUEsTUFDSEw7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUMsY0FBY1A7QUFBQUEsSUFDbEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ3pDLGVBQWUsQ0FBQztBQUVwQixNQUFJQyxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLElBQVFBO0FBQUFBLE9BQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEM7QUFDOUQsTUFBSSxDQUFDRixnQkFBaUIsUUFBTyx1QkFBQyxTQUFJLDJDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0M7QUFFN0QsUUFBTTRELGNBQWM7QUFBQSxJQUNoQjtBQUFBLE1BQ0lDLE9BQU87QUFBQTtBQUFBLE1BRVBDLFFBQVFBLE1BQ0o5RCxnQkFBZ0IrRCxTQUNaO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxJQUFJLGFBQWEvRCxnQkFBZ0IrRCxPQUFPbkUsRUFBRTtBQUFBLFVBQzFDLFdBQVU7QUFBQSxVQUVUSSwwQkFBZ0IrRCxRQUFRdEM7QUFBQUE7QUFBQUEsUUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0EsSUFFQTtBQUFBLElBR1o7QUFBQSxJQUNBLEVBQUVvQyxPQUFPLGFBQWFHLE9BQU9oRSxnQkFBZ0JpRSxrQkFBa0I7QUFBQSxJQUMvRCxFQUFFSixPQUFPLFNBQVNHLE9BQU90RixZQUFZc0IsZ0JBQWdCa0UsaUJBQWlCLE1BQU0sRUFBRTtBQUFBO0FBQUEsSUFFOUUsRUFBRUwsT0FBTyxpQkFBaUJHLE9BQU90RixZQUFZc0IsZ0JBQWdCbUUsY0FBYyxVQUFVLEVBQUU7QUFBQSxJQUN2RjtBQUFBLE1BQ0lOLE9BQU87QUFBQSxNQUNQRyxPQUFPdEYsWUFBWThELE9BQU9RLGNBQWMsVUFBVTtBQUFBLElBQ3REO0FBQUEsRUFBQztBQUdMLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLCtDQUVYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9GQUNYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNbkQsU0FBU0osa0JBQWtCdEIsc0JBQXNCa0UsU0FBUyxDQUFDLEdBQUcsV0FBVSwrREFDM0Y7QUFBQSxpQ0FBQyxlQUFZLFdBQVUsa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFBRztBQUFBLGFBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLDJCQUNUbEU7QUFBQUEsZ0NBQXNCaUc7QUFBQUEsVUFBVztBQUFBLFVBQUdwRSxnQkFBZ0JpRTtBQUFBQSxhQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTSxLQUFLMUQsbUJBQW1CO0FBQUEsWUFDdkMsVUFBVUY7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFDVixPQUFNO0FBQUEsWUFFTEE7QUFBQUEsd0NBQ0csdUJBQUMsYUFBVSxXQUFVLG1DQUFrQyxlQUFXLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFLElBRWxFLHVCQUFDLFdBQVEsV0FBVSxzQkFBcUIsZUFBVyxRQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQ3REO0FBQUE7QUFBQTtBQUFBLFVBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxRQUNDa0MsV0FDRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNMUMsU0FBUyxHQUFHMUIsc0JBQXNCa0UsU0FBUyxJQUFJekMsRUFBRSxTQUFTO0FBQUEsWUFDekUsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQSxVQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBdEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBO0FBQUEsSUFHQSx1QkFBQyxRQUFHLFdBQVUsa0VBQ1RnRSxzQkFBWVM7QUFBQUEsTUFBSSxDQUFBQyxXQUNiLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQXFDQSxpQkFBT1QsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFLHVCQUFDLFFBQUcsV0FBVSw4Q0FFVCxzQkFBWVMsU0FBVUEsT0FBT1IsU0FBU1EsT0FBT1IsT0FBTyxJQUFJLE9BQVFRLE9BQU9OLFNBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTE1NLE9BQU9ULE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLElBQ0gsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdDN0QsZ0JBQWdCaUQsb0JBQW9CakQsZ0JBQWdCaUQsaUJBQWlCc0IsU0FBUyxLQUMzRSx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyxpQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQ25FLHVCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx1QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEY7QUFBQSxVQUM5Rix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsOEJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsYUFIN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p2RSwwQkFBZ0JpRCxpQkFBaUJvQjtBQUFBQSxVQUFJLENBQUFqQixRQUNsQyx1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhDQUVWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxzQkFBc0JBLElBQUlvQixjQUFjNUUsRUFBRTtBQUFBLGdCQUM5QyxXQUFVO0FBQUEsZ0JBRVR3RCxjQUFJb0IsY0FBY0M7QUFBQUE7QUFBQUEsY0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DL0Ysc0JBQVkwRSxJQUFJb0IsY0FBY0UsY0FBYyxNQUFNLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckcsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q2hHLHNCQUFZMEUsSUFBSUMsZ0JBQWdCLFVBQVUsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxlQVhuR0QsSUFBSXhELElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFFBQ0gsS0FmTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVM7QUFBQSxjQUNULFdBQVU7QUFBQTtBQUFBLFlBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSwwREFBd0Q7QUFBQTtBQUFBLFlBQ2pEbEIsWUFBWThELE9BQU9FLGtCQUFrQixVQUFVO0FBQUEsZUFEcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQSxLQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsU0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJDQTtBQUFBLElBSUgxQyxnQkFBZ0JzRCx3QkFBd0J0RCxnQkFBZ0JzRCxxQkFBcUJpQixTQUFTLEtBQ25GLHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLDBDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFDNUUsdUJBQUMsU0FBSSxXQUFVLDBDQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLHFCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RjtBQUFBLFVBQzVGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsOEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxVQUNqRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELDhCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBSjdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNadkUsMEJBQWdCc0QscUJBQXFCZSxJQUFJLENBQUFqQixRQUFPO0FBQzdDLGdCQUFNdUIsT0FBT3ZCLElBQUl3QjtBQUNqQixnQkFBTUMsV0FBV0YsS0FBS0csa0JBQWtCQyxPQUFPSixLQUFLL0UsRUFBRTtBQUN0RCxpQkFDSSx1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGtDQUFrQ2xCLHNCQUFZaUcsS0FBS0ssWUFBWSxNQUFNLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsWUFDckYsdUJBQUMsUUFBRyxXQUFVLGlDQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxHQUFHNUcseUJBQXlCaUUsU0FBUyxJQUFJc0MsS0FBSy9FLEVBQUU7QUFBQSxnQkFDcEQsV0FBVTtBQUFBLGdCQUVUaUY7QUFBQUE7QUFBQUEsY0FKTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDVEYsZUFBS0gsZUFBZTVFLEtBQ2pCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxzQkFBc0IrRSxLQUFLSCxjQUFjNUUsRUFBRTtBQUFBLGdCQUMvQyxXQUFVO0FBQUEsZ0JBRVQrRSxlQUFLSCxjQUFjQyxrQkFBa0JFLEtBQUtILGNBQWM1RTtBQUFBQTtBQUFBQSxjQUo3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxJQUVBLE9BVFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q2xCLHNCQUFZMEUsSUFBSUMsZ0JBQWdCLFVBQVUsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxlQXRCbkdELElBQUl4RCxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsUUFFUixDQUFDLEtBOUJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLHlFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLFVBQy9GLHVCQUFDLFFBQUcsV0FBVSwwREFBd0Q7QUFBQTtBQUFBLFlBQ2pEbEIsWUFBWThELE9BQU9HLHFCQUFxQixVQUFVO0FBQUEsZUFEdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FoREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlEQSxLQWxESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbURBO0FBQUEsU0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLElBSUgzQyxnQkFBZ0J1RCwyQkFBMkJ2RCxnQkFBZ0J1RCx3QkFBd0JnQixTQUFTLEtBQ3pGLHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLDJDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsTUFDN0UsdUJBQUMsU0FBSSxXQUFVLDBDQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLG9CQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCw4QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN4Rix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHVCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRjtBQUFBLFVBQ2pGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsOEJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsYUFMN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p2RSwwQkFBZ0J1RCx3QkFBd0JjLElBQUksQ0FBQWpCLFFBQU87QUFDaEQsZ0JBQU11QixPQUFPdkIsSUFBSTZCO0FBQ2pCLGdCQUFNSixXQUFXRixLQUFLRyxrQkFBa0JDLE9BQU9KLEtBQUsvRSxFQUFFO0FBQ3RELGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsa0NBQ1YsaUNBQUMsMkJBQXdCLE1BQU0rRSxLQUFLMUQsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQnZDLHNCQUFZaUcsS0FBS0ssWUFBWSxNQUFNLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFO0FBQUEsWUFDeEUsdUJBQUMsUUFBRyxXQUFVLGlDQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxHQUFHM0csNkJBQTZCZ0UsU0FBUyxJQUFJc0MsS0FBSy9FLEVBQUU7QUFBQSxnQkFDeEQsV0FBVTtBQUFBLGdCQUVUaUY7QUFBQUE7QUFBQUEsY0FKTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDVEYsZUFBS0gsZUFBZTVFLEtBQ2pCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxzQkFBc0IrRSxLQUFLSCxjQUFjNUUsRUFBRTtBQUFBLGdCQUMvQyxXQUFVO0FBQUEsZ0JBRVQrRSxlQUFLSCxjQUFjQyxrQkFBa0JFLEtBQUtILGNBQWM1RTtBQUFBQTtBQUFBQSxjQUo3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxJQUVBLE9BVFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDREQUE0RGxCLHNCQUFZMEUsSUFBSUMsZ0JBQWdCLFVBQVUsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxlQXpCakhELElBQUl4RCxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsUUFFUixDQUFDLEtBakNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLHlFQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLFVBQy9GLHVCQUFDLFFBQUcsV0FBVSwwREFBd0Q7QUFBQTtBQUFBLFlBQ2pEbEIsWUFBWThELE9BQU9JLHdCQUF3QixVQUFVO0FBQUEsZUFEMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFEQSxLQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsU0F6REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBEQTtBQUFBLElBSUg1QyxnQkFBZ0JrRixTQUFTbEYsZ0JBQWdCa0YsTUFBTVgsU0FBUyxLQUNyRCx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyx3Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLE1BQzFFLHVCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSxxQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQscUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCw2QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUN2Rix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELGdDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQzFGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsaUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDM0YsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCwwQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELDBCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLFVBQ3BGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsMkJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxhQVZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnZFLDBCQUFnQmtGLE1BQU1iO0FBQUFBLFVBQUksQ0FBQXRFLFNBQ3ZCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQThDaUMsbUNBQXlCakMsSUFBSSxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRjtBQUFBLFlBQzNGLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNBLGVBQUtvRixhQUFhLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ3BGLGVBQUtxRixnQkFBZ0IsT0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRSx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DckYsZUFBS3NGLGFBQWEzRyxZQUFZcUIsS0FBS3NGLFlBQVksTUFBTSxJQUFJLE9BQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThHO0FBQUEsWUFDOUcsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ3RGLGVBQUt1RixpQkFBaUI1RyxZQUFZcUIsS0FBS3VGLGdCQUFnQixNQUFNLElBQUksT0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxZQUN0SCx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DdkYsZUFBS3dGLGdCQUFnQixPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUM3RCw4QkFBb0IzQixJQUFJLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ0EsZUFBSzRCLHdCQUF3QixRQUFTNUIsS0FBS3lGLGNBQWMsT0FBTyxPQUFRLE9BQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZIO0FBQUEsWUFDN0gsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ3pGLGVBQUswRixlQUFlLE9BQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsUUFBRyxXQUFVLDRDQUE0Qy9HLHNCQUFZcUIsS0FBS2lFLE9BQU8sVUFBVSxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RjtBQUFBLGVBVnpGakUsS0FBS0gsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsUUFDSCxLQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUseUVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdHO0FBQUEsVUFDaEcsdUJBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSwwREFBeUQ7QUFBQTtBQUFBLFlBQWdCbEIsWUFBWXNCLGdCQUFnQm1FLGNBQWMsVUFBVTtBQUFBLGVBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlKO0FBQUEsYUFGN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQSxLQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsU0F6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLElBS0huRSxnQkFBZ0J5RCxTQUFTekQsZ0JBQWdCeUQsTUFBTWMsU0FBUyxLQUNyRCx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyxxQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLE1BQ3ZFLHVCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSxrQ0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUc7QUFBQSxVQUN6Ryx1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsYUFIcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBRVp2RSwwQkFBZ0J5RCxNQUFNWTtBQUFBQSxVQUFJLENBQUNYLEtBQUtnQyxVQUM3Qix1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhDQUE4Q2hDLGNBQUlpQyxZQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQ3pFLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENqQyxjQUFJa0MsUUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRSx1QkFBQyxRQUFHLFdBQVUsOENBQThDbEgsc0JBQVlnRixJQUFJQyxRQUFRLFVBQVUsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0c7QUFBQSxlQUgzRkQsSUFBSW1DLFVBQVVILE9BQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxRQUNILEtBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQSxLQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBSUosdUJBQUMsU0FBSSxXQUFVLGtDQUVYLGlDQUFDLFNBQUksV0FBVSxzRUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSx3QkFBdUI7QUFBQSwrQkFBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQSxRQUFPO0FBQUEsUUFBQyx1QkFBQyxVQUFNaEgsc0JBQVk4RCxPQUFPUSxjQUFjLFVBQVUsS0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFdBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEg7QUFBQSxNQUM5SCx1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUEsK0JBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsUUFBTztBQUFBLFFBQUMsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBR3RFLFlBQVk4RCxPQUFPSyxVQUFVLFVBQVU7QUFBQSxhQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvSTtBQUFBLE1BQ3BJLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0M7QUFBQSwrQkFBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUFPO0FBQUEsUUFBQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFHbkUsWUFBWThELE9BQU9NLFlBQVksVUFBVTtBQUFBLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxXQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdJO0FBQUEsTUFDeEksdUJBQUMsU0FBSSxXQUFVLCtEQUE4RDtBQUFBLCtCQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQU87QUFBQSxRQUFDLHVCQUFDLFVBQU1wRSxzQkFBWThELE9BQU9PLFdBQVcsVUFBVSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsV0FBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnSztBQUFBLFNBSnBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BbFRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvVEE7QUFFUjtBQUFFcEQsR0E5ZVdELHFCQUFtQjtBQUFBLFVBQ2IzQixXQUNFQyxhQUNlb0IsZ0JBRWtCbEIsV0FBVztBQUFBO0FBQUE0SCxLQUxwRHBHO0FBQW1CLElBQUFvRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlQ3J1ZEl0ZW0iLCJjb2JyYW56YXNNb2R1bGVDb25maWciLCJub3Rhc0NyZWRpdG9Nb2R1bGVDb25maWciLCJub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnIiwiU2lnbmVkRG9jdW1lbnRUeXBlQmFkZ2UiLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QZW5jaWwiLCJmb3JtYXRWYWx1ZSIsInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwidG9hc3QiLCJJb1ByaW50IiwiRmFTcGlubmVyIiwiYmVnaW5QZGZQcmV2aWV3IiwiZmluaXNoUGRmUHJldmlldyIsInVzZVBlcm1pc3Npb25zIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJnZXRBbGwiLCJ0YXhlc01vZHVsZUNvbmZpZyIsImdldExpc3RSZXR1cm5QYXRoIiwiQ29icmFuemFzRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJpdGVtIiwiY3VzdG9tZXJQYXltZW50IiwibG9hZGluZyIsImVycm9yIiwicmV0ZW50aW9uVGF4ZXMiLCJzZXRSZXRlbnRpb25UYXhlcyIsImlzRG93bmxvYWRpbmdSZWNlaXB0UGRmIiwic2V0SXNEb3dubG9hZGluZ1JlY2VpcHRQZGYiLCJoYW5kbGVQcmludFJlY2VpcHQiLCJzZXNzaW9uIiwiZSIsIndpbmRvdyIsImNsb3NlZCIsImNsb3NlIiwiY29uc29sZSIsImNhbmNlbGxlZCIsInJlcyIsImVuZHBvaW50IiwidHlwZSIsInBlcl9wYWdlIiwiZGF0YSIsInJldGVudGlvblRheE5hbWVCeUlkIiwibSIsIk1hcCIsInQiLCJzZXQiLCJuYW1lIiwiZm9ybWF0SXRlbVJlZmVyZW5jZSIsInBheW1lbnRfbWV0aG9kX2NvZGUiLCJyZWZlcmVuY2VfbnVtYmVyIiwiTnVtYmVyIiwiaXNOYU4iLCJnZXQiLCJmb3JtYXRQYXltZW50TWV0aG9kTGFiZWwiLCJjb2RlIiwidGlkIiwidGF4TmFtZSIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdCIsInRvdGFscyIsImdyb3NzQW1vdW50IiwiaW52b2ljZXNTdWJ0b3RhbCIsImNyZWRpdE5vdGVzU3VidG90YWwiLCJmaW5hbmNpYWxOb3Rlc1N1YnRvdGFsIiwiZGlzY291bnQiLCJ0b3RhbFRheGVzIiwibmV0QW1vdW50IiwidG90YWxBcHBsaWVkIiwiYXBwbGllZF9pbnZvaWNlcyIsInJlZHVjZSIsInN1bSIsImFwcCIsImFtb3VudF9hcHBsaWVkIiwiYXBwbGllZF9jcmVkaXRfbm90ZXMiLCJhcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyIsImRpc2NvdW50X2Ftb3VudCIsInRheGVzIiwidGF4IiwiYW1vdW50IiwibWFpbkRldGFpbHMiLCJsYWJlbCIsInJlbmRlciIsImNsaWVudCIsInZhbHVlIiwiY29sbGVjdGlvbl9udW1iZXIiLCJjb2xsZWN0aW9uX2RhdGUiLCJ0b3RhbF9hbW91bnQiLCJtb2R1bGVOYW1lIiwibWFwIiwiZGV0YWlsIiwibGVuZ3RoIiwic2FsZXNfaW52b2ljZSIsImludm9pY2VfbnVtYmVyIiwiaW52b2ljZV9kYXRlIiwibm90ZSIsImNyZWRpdF9ub3RlIiwiZG9jTGFiZWwiLCJ2b3VjaGVyX251bWJlciIsIlN0cmluZyIsImlzc3VlX2RhdGUiLCJmaW5hbmNpYWxfbm90ZSIsIml0ZW1zIiwiYmFua19uYW1lIiwiY2hlY2tfbnVtYmVyIiwiY2hlY2tfZGF0ZSIsImNoZWNrX2R1ZV9kYXRlIiwiY2hlY2tfaG9sZGVyIiwiaXNfdG9fb3JkZXIiLCJpc3N1ZXJfY3VpdCIsImluZGV4IiwidGF4X25hbWUiLCJyYXRlIiwidGF4X2lkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29icmFuemFzRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG4vLyDinIUgQ09SUkVDQ0nDk046IEltcG9ydGFtb3MgJ0FwcGxpZWRUYXgnIHBhcmEgdXNhcmxvIGVuIGVsIHRpcG8gZGVsIHBheWxvYWRcbmltcG9ydCB7IGNvYnJhbnphc01vZHVsZUNvbmZpZywgdHlwZSBDdXN0b21lclBheW1lbnQsIHR5cGUgQ3VzdG9tZXJQYXltZW50SXRlbSB9IGZyb20gJy4uL2NvYnJhbnphcy5jb25maWcnO1xuaW1wb3J0IHsgbm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vbm90YXNfY3JlZGl0by9ub3Rhc19jcmVkaXRvLmNvbmZpZyc7XG5pbXBvcnQgeyBub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vbm90YXNfZmluYW5jaWVyYXMvbm90YXNfZmluYW5jaWVyYXMuY29uZmlnJztcbmltcG9ydCB7IFNpZ25lZERvY3VtZW50VHlwZUJhZGdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9QZW5jaWwgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBJb1ByaW50IH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IEZhU3Bpbm5lciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGJlZ2luUGRmUHJldmlldywgZmluaXNoUGRmUHJldmlldyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHR5cGUgeyBBcHBsaWVkVGF4IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldEFsbCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgdGF4ZXNNb2R1bGVDb25maWcsIHR5cGUgVGF4IH0gZnJvbSAnLi4vLi4vaW1wdWVzdG9zL2ltcHVlc3Rvcy5jb25maWcnO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG4vLyDinIUgQ09SUkVDQ0nDk046IERlZmluaW1vcyBlbCB0aXBvIGRlbCBwYXlsb2FkIHJlYWwgcXVlIHZpZW5lIGRlbCBBUElcbi8vIChFbCBiYWNrZW5kIGVudsOtYSAndGF4ZXMnIGVuIGx1Z2FyIGRlICdhcHBsaWVkX3RheGVzJylcbnR5cGUgQ3VzdG9tZXJQYXltZW50UGF5bG9hZCA9IEN1c3RvbWVyUGF5bWVudCAmIHtcbiAgICB0YXhlcz86IEFwcGxpZWRUYXhbXTtcbn1cblxuZXhwb3J0IGNvbnN0IENvYnJhbnphc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGhhc01vZHVsZVBlcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBVc2Ftb3MgZWwgdGlwbyBkZSBQYXlsb2FkXG4gICAgY29uc3QgeyBpdGVtOiBjdXN0b21lclBheW1lbnQsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxDdXN0b21lclBheW1lbnRQYXlsb2FkPihjb2JyYW56YXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGNvbnN0IFtyZXRlbnRpb25UYXhlcywgc2V0UmV0ZW50aW9uVGF4ZXNdID0gdXNlU3RhdGU8VGF4W10+KFtdKTtcbiAgICBjb25zdCBbaXNEb3dubG9hZGluZ1JlY2VpcHRQZGYsIHNldElzRG93bmxvYWRpbmdSZWNlaXB0UGRmXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IGhhbmRsZVByaW50UmVjZWlwdCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFpZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBQREYuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc0Rvd25sb2FkaW5nUmVjZWlwdFBkZih0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9jb2xsZWN0aW9ucy8ke2lkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCByZWNpYm8gZW4gUERGLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNEb3dubG9hZGluZ1JlY2VpcHRQZGYoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW2lkXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2V0QWxsPFRheD4odGF4ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIHsgdHlwZTogMywgcGVyX3BhZ2U6IDUwMCB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0UmV0ZW50aW9uVGF4ZXMocmVzLmRhdGEgPz8gW10pO1xuICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldFJldGVudGlvblRheGVzKFtdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkoKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgIH07XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgcmV0ZW50aW9uVGF4TmFtZUJ5SWQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3QgbSA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XG4gICAgICAgIGZvciAoY29uc3QgdCBvZiByZXRlbnRpb25UYXhlcykge1xuICAgICAgICAgICAgbS5zZXQodC5pZCwgdC5uYW1lKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbTtcbiAgICB9LCBbcmV0ZW50aW9uVGF4ZXNdKTtcblxuICAgIGNvbnN0IGZvcm1hdEl0ZW1SZWZlcmVuY2UgPSAoaXRlbTogQ3VzdG9tZXJQYXltZW50SXRlbSkgPT4ge1xuICAgICAgICBpZiAoaXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnUkVUJyAmJiBpdGVtLnJlZmVyZW5jZV9udW1iZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IGlkID0gTnVtYmVyKGl0ZW0ucmVmZXJlbmNlX251bWJlcik7XG4gICAgICAgICAgICBpZiAoIU51bWJlci5pc05hTihpZCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmV0ZW50aW9uVGF4TmFtZUJ5SWQuZ2V0KGlkKSA/PyBpdGVtLnJlZmVyZW5jZV9udW1iZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGl0ZW0ucmVmZXJlbmNlX251bWJlciB8fCAnLSc7XG4gICAgfTtcblxuICAgIC8qKiBFdGlxdWV0YSBsZWdpYmxlIGRlbCBtZWRpbyBkZSBwYWdvIGVuIGNvbnRleHRvIGNvYnJhbnphIChyZWNpYmlkbykuICovXG4gICAgY29uc3QgZm9ybWF0UGF5bWVudE1ldGhvZExhYmVsID0gKGl0ZW06IEN1c3RvbWVyUGF5bWVudEl0ZW0pOiBzdHJpbmcgPT4ge1xuICAgICAgICBjb25zdCBjb2RlID0gaXRlbS5wYXltZW50X21ldGhvZF9jb2RlO1xuICAgICAgICBzd2l0Y2ggKGNvZGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ0VGRSc6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdFZmVjdGl2byc7XG4gICAgICAgICAgICBjYXNlICdDSEUnOlxuICAgICAgICAgICAgICAgIHJldHVybiAnQ2hlcXVlJztcbiAgICAgICAgICAgIGNhc2UgJ0NIUic6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdDaGVxdWUgcmVjaWJpZG8nO1xuICAgICAgICAgICAgY2FzZSAnVFJBJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ1RyYW5zZmVyZW5jaWEgcmVjaWJpZGEnO1xuICAgICAgICAgICAgY2FzZSAnRE9DJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ0RvY3VtZW50byc7XG4gICAgICAgICAgICBjYXNlICdTQUwnOlxuICAgICAgICAgICAgICAgIHJldHVybiAnU2FsZG8gYW50aWNpcGFkbyc7XG4gICAgICAgICAgICBjYXNlICdSRVQnOiB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZW0ucmVmZXJlbmNlX251bWJlcikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0aWQgPSBOdW1iZXIoaXRlbS5yZWZlcmVuY2VfbnVtYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFOdW1iZXIuaXNOYU4odGlkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGF4TmFtZSA9IHJldGVudGlvblRheE5hbWVCeUlkLmdldCh0aWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRheE5hbWUpIHJldHVybiBgUmV0ZW5jacOzbiDigJQgJHt0YXhOYW1lfWA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuICdSZXRlbmNpw7NuJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvZGUgfHwgJy0nO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihjb2JyYW56YXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBjYW5FZGl0ID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG5cbiAgICBjb25zdCB0b3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFjdXN0b21lclBheW1lbnQpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZ3Jvc3NBbW91bnQ6IDAsXG4gICAgICAgICAgICAgICAgaW52b2ljZXNTdWJ0b3RhbDogMCxcbiAgICAgICAgICAgICAgICBjcmVkaXROb3Rlc1N1YnRvdGFsOiAwLFxuICAgICAgICAgICAgICAgIGZpbmFuY2lhbE5vdGVzU3VidG90YWw6IDAsXG4gICAgICAgICAgICAgICAgZGlzY291bnQ6IDAsXG4gICAgICAgICAgICAgICAgdG90YWxUYXhlczogMCxcbiAgICAgICAgICAgICAgICBuZXRBbW91bnQ6IDAsXG4gICAgICAgICAgICAgICAgdG90YWxBcHBsaWVkOiAwLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGludm9pY2VzU3VidG90YWwgPSBjdXN0b21lclBheW1lbnQuYXBwbGllZF9pbnZvaWNlcz8ucmVkdWNlKFxuICAgICAgICAgICAgKHN1bSwgYXBwKSA9PiBzdW0gKyAoTnVtYmVyKGFwcC5hbW91bnRfYXBwbGllZCkgfHwgMCksXG4gICAgICAgICAgICAwXG4gICAgICAgICkgfHwgMDtcblxuICAgICAgICBjb25zdCBjcmVkaXROb3Rlc1N1YnRvdGFsID0gY3VzdG9tZXJQYXltZW50LmFwcGxpZWRfY3JlZGl0X25vdGVzPy5yZWR1Y2UoXG4gICAgICAgICAgICAoc3VtLCBhcHApID0+IHN1bSArIChOdW1iZXIoYXBwLmFtb3VudF9hcHBsaWVkKSB8fCAwKSxcbiAgICAgICAgICAgIDBcbiAgICAgICAgKSB8fCAwO1xuXG4gICAgICAgIGNvbnN0IGZpbmFuY2lhbE5vdGVzU3VidG90YWwgPSBjdXN0b21lclBheW1lbnQuYXBwbGllZF9maW5hbmNpYWxfbm90ZXM/LnJlZHVjZShcbiAgICAgICAgICAgIChzdW0sIGFwcCkgPT4gc3VtICsgKE51bWJlcihhcHAuYW1vdW50X2FwcGxpZWQpIHx8IDApLFxuICAgICAgICAgICAgMFxuICAgICAgICApIHx8IDA7XG5cbiAgICAgICAgY29uc3QgZ3Jvc3NBbW91bnQgPSBpbnZvaWNlc1N1YnRvdGFsICsgY3JlZGl0Tm90ZXNTdWJ0b3RhbCArIGZpbmFuY2lhbE5vdGVzU3VidG90YWw7XG5cbiAgICAgICAgY29uc3QgZGlzY291bnQgPSBjdXN0b21lclBheW1lbnQuZGlzY291bnRfYW1vdW50IHx8IDA7XG5cbiAgICAgICAgY29uc3QgdG90YWxUYXhlcyA9IGN1c3RvbWVyUGF5bWVudC50YXhlcz8ucmVkdWNlKFxuICAgICAgICAgICAgKHN1bSwgdGF4KSA9PiBzdW0gKyAoTnVtYmVyKHRheC5hbW91bnQpIHx8IDApLFxuICAgICAgICAgICAgMFxuICAgICAgICApIHx8IDA7XG5cbiAgICAgICAgY29uc3QgbmV0QW1vdW50ID0gZ3Jvc3NBbW91bnQgLSBkaXNjb3VudCAtIHRvdGFsVGF4ZXM7XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGdyb3NzQW1vdW50LFxuICAgICAgICAgICAgaW52b2ljZXNTdWJ0b3RhbCxcbiAgICAgICAgICAgIGNyZWRpdE5vdGVzU3VidG90YWwsXG4gICAgICAgICAgICBmaW5hbmNpYWxOb3Rlc1N1YnRvdGFsLFxuICAgICAgICAgICAgZGlzY291bnQsXG4gICAgICAgICAgICB0b3RhbFRheGVzLFxuICAgICAgICAgICAgbmV0QW1vdW50LFxuICAgICAgICAgICAgdG90YWxBcHBsaWVkOiBncm9zc0Ftb3VudCxcbiAgICAgICAgfTtcbiAgICB9LCBbY3VzdG9tZXJQYXltZW50XSk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yOiB7ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghY3VzdG9tZXJQYXltZW50KSByZXR1cm4gPGRpdj5ObyBzZSBlbmNvbnRyw7MgbGEgY29icmFuemEuPC9kaXY+O1xuXG4gICAgY29uc3QgbWFpbkRldGFpbHMgPSBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiAnQ2xpZW50ZScsXG4gICAgICAgICAgICAvLyDinIUgQ0FNQklPOiBDb252ZXJ0aWRvIGVuICdyZW5kZXInIHBhcmEgYcOxYWRpciBlbCBMaW5rXG4gICAgICAgICAgICByZW5kZXI6ICgpID0+IChcbiAgICAgICAgICAgICAgICBjdXN0b21lclBheW1lbnQuY2xpZW50ID8gKFxuICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvY2xpZW50ZXMvJHtjdXN0b21lclBheW1lbnQuY2xpZW50LmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lclBheW1lbnQuY2xpZW50Py5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgJ04vQSdcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgIH0sXG4gICAgICAgIHsgbGFiZWw6ICdOwrogUmVjaWJvJywgdmFsdWU6IGN1c3RvbWVyUGF5bWVudC5jb2xsZWN0aW9uX251bWJlciB9LFxuICAgICAgICB7IGxhYmVsOiAnRmVjaGEnLCB2YWx1ZTogZm9ybWF0VmFsdWUoY3VzdG9tZXJQYXltZW50LmNvbGxlY3Rpb25fZGF0ZSwgJ2RhdGUnKSB9LFxuICAgICAgICAvLyBVc2Ftb3MgZWwgdG90YWxfYW1vdW50IChUb3RhbCBDb2JyYWRvKSBkZWwgaGVhZGVyXG4gICAgICAgIHsgbGFiZWw6ICdUb3RhbCBDb2JyYWRvJywgdmFsdWU6IGZvcm1hdFZhbHVlKGN1c3RvbWVyUGF5bWVudC50b3RhbF9hbW91bnQsICdjdXJyZW5jeScpIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiAnVG90YWwgYXBsaWNhZG8nLFxuICAgICAgICAgICAgdmFsdWU6IGZvcm1hdFZhbHVlKHRvdGFscy50b3RhbEFwcGxpZWQsICdjdXJyZW5jeScpLFxuICAgICAgICB9LFxuICAgIF07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIHsvKiAtLS0gQ2FiZWNlcmEgY29uIEFjY2lvbmVzIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBwYi00IGJvcmRlci1iIHNtOmZsZXgtcm93IHNtOmp1c3RpZnktYmV0d2VlbiBzbTppdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGNvYnJhbnphc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTFcIiAvPiBWb2x2ZXIgYWwgbGlzdGFkb1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y29icmFuemFzTW9kdWxlQ29uZmlnLm1vZHVsZU5hbWV9ICN7Y3VzdG9tZXJQYXltZW50LmNvbGxlY3Rpb25fbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVQcmludFJlY2VpcHQoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nUmVjZWlwdFBkZn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWJyaXIgcmVjaWJvIGVuIFBERlwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0Rvd25sb2FkaW5nUmVjZWlwdFBkZiA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMSBhbmltYXRlLXNwaW5cIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9QcmludCBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIEltcHJpbWlyIHJlY2lib1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAge2NhbkVkaXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAke2NvYnJhbnphc01vZHVsZUNvbmZpZy5iYXNlUm91dGV9LyR7aWR9L2VkaXRhcmApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVuY2lsIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+IEVkaXRhclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBEZXRhbGxlcyBQcmluY2lwYWxlcyAtLS0gKi99XG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAteC00IGdhcC15LTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTVcIj5cbiAgICAgICAgICAgICAgICB7bWFpbkRldGFpbHMubWFwKGRldGFpbCA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkZXRhaWwubGFiZWx9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPntkZXRhaWwubGFiZWx9PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIENBTUJJTzogVXNhciAncmVuZGVyJyBzaSBleGlzdGUsIHNpIG5vICd2YWx1ZScgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeydyZW5kZXInIGluIGRldGFpbCA/IChkZXRhaWwucmVuZGVyID8gZGV0YWlsLnJlbmRlcigpIDogbnVsbCkgOiBkZXRhaWwudmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGw+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQkxPUVVFIDE6IEZhY3R1cmFzIEFwbGljYWRhcyAtLS0gKi99XG4gICAgICAgICAgICB7Y3VzdG9tZXJQYXltZW50LmFwcGxpZWRfaW52b2ljZXMgJiYgY3VzdG9tZXJQYXltZW50LmFwcGxpZWRfaW52b2ljZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkZhY3R1cmFzIENvYnJhZGFzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5GYWN0dXJhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5GZWNoYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk1vbnRvIEFwbGljYWRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyUGF5bWVudC5hcHBsaWVkX2ludm9pY2VzLm1hcChhcHAgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17YXBwLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDinIUgQ0FNQklPOiBBw7FhZGlkbyBMaW5rIGEgbGEgZmFjdHVyYSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL2ZhY3R1cmFzLWRlLXZlbnRhLyR7YXBwLnNhbGVzX2ludm9pY2UuaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FwcC5zYWxlc19pbnZvaWNlLmludm9pY2VfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShhcHAuc2FsZXNfaW52b2ljZS5pbnZvaWNlX2RhdGUsICdkYXRlJyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGFwcC5hbW91bnRfYXBwbGllZCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRmb290IGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sU3Bhbj17Mn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUT1RBTCBBUExJQ0FETzoge2Zvcm1hdFZhbHVlKHRvdGFscy5pbnZvaWNlc1N1YnRvdGFsLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Zm9vdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIC0tLSBCTE9RVUU6IE5vdGFzIGRlIENyw6lkaXRvIEFwbGljYWRhcyAtLS0gKi99XG4gICAgICAgICAgICB7Y3VzdG9tZXJQYXltZW50LmFwcGxpZWRfY3JlZGl0X25vdGVzICYmIGN1c3RvbWVyUGF5bWVudC5hcHBsaWVkX2NyZWRpdF9ub3Rlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+Tm90YXMgZGUgQ3LDqWRpdG8gQXBsaWNhZGFzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5GZWNoYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TsK6IENvbXByb2JhbnRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5GYWN0dXJhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TW9udG8gQXBsaWNhZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJQYXltZW50LmFwcGxpZWRfY3JlZGl0X25vdGVzLm1hcChhcHAgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgbm90ZSA9IGFwcC5jcmVkaXRfbm90ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRvY0xhYmVsID0gbm90ZS52b3VjaGVyX251bWJlciB8fCBTdHJpbmcobm90ZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2FwcC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIHNtOnBsLTZcIj57Zm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7bm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZX0vJHtub3RlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkb2NMYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlLnNhbGVzX2ludm9pY2U/LmlkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL2ZhY3R1cmFzLWRlLXZlbnRhLyR7bm90ZS5zYWxlc19pbnZvaWNlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlLnNhbGVzX2ludm9pY2UuaW52b2ljZV9udW1iZXIgPz8gbm90ZS5zYWxlc19pbnZvaWNlLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJy0nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGFwcC5hbW91bnRfYXBwbGllZCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17M30gY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVE9UQUwgQVBMSUNBRE86IHtmb3JtYXRWYWx1ZSh0b3RhbHMuY3JlZGl0Tm90ZXNTdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQkxPUVVFOiBOb3RhcyBGaW5hbmNpZXJhcyBBcGxpY2FkYXMgLS0tICovfVxuICAgICAgICAgICAge2N1c3RvbWVyUGF5bWVudC5hcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyAmJiBjdXN0b21lclBheW1lbnQuYXBwbGllZF9maW5hbmNpYWxfbm90ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPk5vdGFzIEZpbmFuY2llcmFzIEFwbGljYWRhczwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+VGlwbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmVjaGE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk7CuiBDb21wcm9iYW50ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmFjdHVyYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk1vbnRvIEFwbGljYWRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyUGF5bWVudC5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcy5tYXAoYXBwID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vdGUgPSBhcHAuZmluYW5jaWFsX25vdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkb2NMYWJlbCA9IG5vdGUudm91Y2hlcl9udW1iZXIgfHwgU3RyaW5nKG5vdGUuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXthcHAuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2lnbmVkRG9jdW1lbnRUeXBlQmFkZ2UgdHlwZT17bm90ZS50eXBlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj57Zm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7bm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZy5iYXNlUm91dGV9LyR7bm90ZS5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9jTGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5zYWxlc19pbnZvaWNlPy5pZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9mYWN0dXJhcy1kZS12ZW50YS8ke25vdGUuc2FsZXNfaW52b2ljZS5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5zYWxlc19pbnZvaWNlLmludm9pY2VfbnVtYmVyID8/IG5vdGUuc2FsZXNfaW52b2ljZS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICctJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMCBmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKGFwcC5hbW91bnRfYXBwbGllZCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17NH0gY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVE9UQUwgQVBMSUNBRE86IHtmb3JtYXRWYWx1ZSh0b3RhbHMuZmluYW5jaWFsTm90ZXNTdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQkxPUVVFIDI6IE1lZGlvcyBkZSBQYWdvIC0tLSAqL31cbiAgICAgICAgICAgIHtjdXN0b21lclBheW1lbnQuaXRlbXMgJiYgY3VzdG9tZXJQYXltZW50Lml0ZW1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5NZWRpb3MgZGUgUGFnbyBSZWNpYmlkb3M8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgb3ZlcmZsb3cteC1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPk1lZGlvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5CYW5jbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TsK6IENoZXF1ZS9DZXJ0aWZpY2FkbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmVjaGEgZW1pc2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkZlY2hhIHBhZ28vY29icm88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkVtaXNvciBkZWwgY2hlcXVlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5SZWZlcmVuY2lhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5BIGxhIG9yZGVuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DVUlUIGVtaXNvcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlZhbG9yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyUGF5bWVudC5pdGVtcy5tYXAoaXRlbSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+e2Zvcm1hdFBheW1lbnRNZXRob2RMYWJlbChpdGVtKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0uYmFua19uYW1lIHx8ICdOL0EnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aXRlbS5jaGVja19udW1iZXIgfHwgJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aXRlbS5jaGVja19kYXRlID8gZm9ybWF0VmFsdWUoaXRlbS5jaGVja19kYXRlLCAnZGF0ZScpIDogJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aXRlbS5jaGVja19kdWVfZGF0ZSA/IGZvcm1hdFZhbHVlKGl0ZW0uY2hlY2tfZHVlX2RhdGUsICdkYXRlJykgOiAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntpdGVtLmNoZWNrX2hvbGRlciB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRJdGVtUmVmZXJlbmNlKGl0ZW0pfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnQ0hFJyA/IChpdGVtLmlzX3RvX29yZGVyID8gJ1PDrScgOiAnTm8nKSA6ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0uaXNzdWVyX2N1aXQgfHwgJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW1cIj57Zm9ybWF0VmFsdWUoaXRlbS52YWx1ZSwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRmb290IGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezh9IGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezJ9IGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlRPVEFMIENPQlJBRE86IHtmb3JtYXRWYWx1ZShjdXN0b21lclBheW1lbnQudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQkxPUVVFIDM6IFJldGVuY2lvbmVzIHkgVG90YWxlcyAtLS0gKi99XG4gICAgICAgICAgICB7Lyog4pyFIENPUlJFQ0NJw5NOOiBMZWVtb3MgZGUgJ2N1c3RvbWVyUGF5bWVudC50YXhlcycgKi99XG4gICAgICAgICAgICB7Y3VzdG9tZXJQYXltZW50LnRheGVzICYmIGN1c3RvbWVyUGF5bWVudC50YXhlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+UmV0ZW5jaW9uZXMgQXBsaWNhZGFzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5JbXB1ZXN0by9SZXRlbmNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+VGFzYSAoJSk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDinIUgQ09SUkVDQ0nDk046IEl0ZXJhbW9zIHNvYnJlICdjdXN0b21lclBheW1lbnQudGF4ZXMnICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJQYXltZW50LnRheGVzLm1hcCgodGF4LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dGF4LnRheF9pZCB8fCBpbmRleH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPnt0YXgudGF4X25hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e3RheC5yYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIC0tLSBSZXN1bWVuIGRlIFRvdGFsZXMgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTQgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICB7Lyog4pyFIENPUlJFQ0NJw5NOOiBUb2RvcyBsb3MgdmFsb3JlcyAndG90YWxzLionIGFob3JhIHNlIGNhbGN1bGFuIGNvcnJlY3RhbWVudGUgZW4gZWwgdXNlTWVtbyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvMyBwLTQgYmctZ3JheS01MCBib3JkZXIgcm91bmRlZC1sZyBzcGFjZS15LTIgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+PHNwYW4+VG90YWwgYXBsaWNhZG86PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLnRvdGFsQXBwbGllZCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtcmVkLTYwMFwiPjxzcGFuPkRlc2N1ZW50bzo8L3NwYW4+IDxzcGFuPi0ge2Zvcm1hdFZhbHVlKHRvdGFscy5kaXNjb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtcmVkLTYwMFwiPjxzcGFuPlJldGVuY2lvbmVzOjwvc3Bhbj4gPHNwYW4+LSB7Zm9ybWF0VmFsdWUodG90YWxzLnRvdGFsVGF4ZXMsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBmb250LWJvbGQgdGV4dC1iYXNlIGJvcmRlci10IHB0LTIgbXQtMlwiPjxzcGFuPk5ldG8gQ29icmFkbzo8L3NwYW4+IDxzcGFuPntmb3JtYXRWYWx1ZSh0b3RhbHMubmV0QW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY29icmFuemFzL3BhZ2VzL0NvYnJhbnphc0RldGFpbFBhZ2UudHN4In0=