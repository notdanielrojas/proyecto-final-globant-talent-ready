import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/usuarios/pages/UsuariosEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/usuarios/pages/UsuariosEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { usuariosModuleConfig } from "/src/features/usuarios/usuarios.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport8_react["useEffect"]; const useState = __vite__cjsImport8_react["useState"]; const useMemo = __vite__cjsImport8_react["useMemo"];
import { getAll } from "/src/services/apiService.ts";
export const UsuarioEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: usuario, loading, error, saveItem } = useCrudItem(usuariosModuleConfig, id);
  const [profiles, setProfiles] = useState([]);
  useEffect(() => {
    getAll("profiles").then((response) => setProfiles(response.data));
  }, []);
  const handleSave = async (data) => {
    const payload = { ...data };
    if (payload.role_id) {
      payload.role_id = Number(payload.role_id);
    }
    const saved = await saveItem(payload);
    if (saved) {
      toast.info(`Usuario "${payload.name}" actualizado con éxito!`);
      navigate("/configuracion/usuarios");
    }
  };
  const formConfig = useMemo(() => {
    const newConfig = JSON.parse(JSON.stringify(usuariosModuleConfig));
    newConfig.form.block = newConfig.form.block.map((block) => {
      const updatedFields = block.fields.map((field) => {
        if (field.name === "role_id") {
          return {
            ...field,
            options: profiles.map((p) => ({ value: p.id, label: p.name }))
          };
        }
        return field;
      }).filter(
        (field) => field.name !== "password" && field.name !== "password_confirmation"
      );
      return { ...block, fields: updatedFields };
    });
    return newConfig;
  }, [profiles]);
  const initialData = useMemo(() => {
    if (!usuario) return void 0;
    const preparedData = { ...usuario };
    if (usuario.roles && usuario.roles.length > 0) {
      preparedData.role_id = usuario.roles[0].id;
    }
    return preparedData;
  }, [usuario]);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del usuario..." }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosEditPage.tsx",
    lineNumber: 103,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosEditPage.tsx",
    lineNumber: 104,
    columnNumber: 21
  }, this);
  if (!initialData) return /* @__PURE__ */ jsxDEV("div", { children: "Usuario no encontrado." }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosEditPage.tsx",
    lineNumber: 105,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: formConfig,
      initialData,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/usuarios/pages/UsuariosEditPage.tsx",
      lineNumber: 108,
      columnNumber: 5
    },
    this
  );
};
_s(UsuarioEditPage, "4mYbLu0bA3XzrZXe948JbVejbf0=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = UsuarioEditPage;
var _c;
$RefreshReg$(_c, "UsuarioEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/usuarios/pages/UsuariosEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/usuarios/pages/UsuariosEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsRnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsNEJBQTBDO0FBQ25ELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBRXRCLFNBQVNDLFdBQVdDLFVBQVVDLGVBQWU7QUFDN0MsU0FBU0MsY0FBYztBQUdoQixhQUFNQyxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVosVUFBMEI7QUFDekMsUUFBTWEsV0FBV1osWUFBWTtBQUM3QixRQUFNLEVBQUVhLE1BQU1DLFNBQVNDLFNBQVNDLE9BQU9DLFNBQVMsSUFBSWQsWUFBcUJELHNCQUFzQlMsRUFBRTtBQUNqRyxRQUFNLENBQUNPLFVBQVVDLFdBQVcsSUFBSWIsU0FBb0IsRUFBRTtBQUV0REQsWUFBVSxNQUFNO0FBQ1pHLFdBQWdCLFVBQVUsRUFBRVksS0FBSyxDQUFBQyxhQUFZRixZQUFZRSxTQUFTQyxJQUFJLENBQUM7QUFBQSxFQUMzRSxHQUFHLEVBQUU7QUFFTCxRQUFNQyxhQUFhLE9BQU9ELFNBQWtCO0FBRXhDLFVBQU1FLFVBQVUsRUFBRSxHQUFHRixLQUFLO0FBRzFCLFFBQUlFLFFBQVFDLFNBQVM7QUFDakJELGNBQVFDLFVBQVVDLE9BQU9GLFFBQVFDLE9BQU87QUFBQSxJQUM1QztBQUVBLFVBQU1FLFFBQVEsTUFBTVYsU0FBU08sT0FBTztBQUNwQyxRQUFJRyxPQUFPO0FBQ1B2QixZQUFNd0IsS0FBSyxZQUFZSixRQUFRSyxJQUFJLDBCQUEwQjtBQUM3RGpCLGVBQVMseUJBQXlCO0FBQUEsSUFDdEM7QUFBQSxFQUNKO0FBR0EsUUFBTWtCLGFBQWF2QixRQUFRLE1BQU07QUFDN0IsVUFBTXdCLFlBQVlDLEtBQUtDLE1BQU1ELEtBQUtFLFVBQVVoQyxvQkFBb0IsQ0FBQztBQUVqRTZCLGNBQVVJLEtBQUtDLFFBQVFMLFVBQVVJLEtBQUtDLE1BQU1DLElBQUksQ0FBQ0QsVUFBa0Q7QUFDL0YsWUFBTUUsZ0JBQWdCRixNQUFNRyxPQUV2QkYsSUFBSSxDQUFDRyxVQUFvQztBQUN0QyxZQUFJQSxNQUFNWCxTQUFTLFdBQVc7QUFDMUIsaUJBQU87QUFBQSxZQUNILEdBQUdXO0FBQUFBLFlBQ0hDLFNBQVN2QixTQUFTbUIsSUFBSSxDQUFBSyxPQUFNLEVBQUVDLE9BQU9ELEVBQUUvQixJQUFJaUMsT0FBT0YsRUFBRWIsS0FBSyxFQUFFO0FBQUEsVUFDL0Q7QUFBQSxRQUNKO0FBQ0EsZUFBT1c7QUFBQUEsTUFDWCxDQUFDLEVBRUFLO0FBQUFBLFFBQ0csQ0FBQUwsVUFBU0EsTUFBTVgsU0FBUyxjQUFjVyxNQUFNWCxTQUFTO0FBQUEsTUFDekQ7QUFFSixhQUFPLEVBQUUsR0FBR08sT0FBT0csUUFBUUQsY0FBYztBQUFBLElBQzdDLENBQUM7QUFFRCxXQUFPUDtBQUFBQSxFQUNYLEdBQUcsQ0FBQ2IsUUFBUSxDQUFDO0FBSWIsUUFBTTRCLGNBQWN2QyxRQUFRLE1BQU07QUFDOUIsUUFBSSxDQUFDTyxRQUFTLFFBQU9pQztBQUdyQixVQUFNQyxlQUFlLEVBQUUsR0FBR2xDLFFBQVE7QUFJbEMsUUFBSUEsUUFBUW1DLFNBQVNuQyxRQUFRbUMsTUFBTUMsU0FBUyxHQUFHO0FBQzNDRixtQkFBYXZCLFVBQVVYLFFBQVFtQyxNQUFNLENBQUMsRUFBRXRDO0FBQUFBLElBQzVDO0FBR0EsV0FBT3FDO0FBQUFBLEVBQ1gsR0FBRyxDQUFDbEMsT0FBTyxDQUFDO0FBR1osTUFBSUMsUUFBUyxRQUFPLHVCQUFDLFNBQUksNkNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrQztBQUN0RCxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDOEIsWUFBYSxRQUFPLHVCQUFDLFNBQUksc0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQjtBQUVwRCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRaEI7QUFBQUEsTUFDUjtBQUFBLE1BQ0EsUUFBUVA7QUFBQUEsTUFDUixNQUFLO0FBQUE7QUFBQSxJQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUllO0FBR3ZCO0FBQUViLEdBcEZXRCxpQkFBZTtBQUFBLFVBQ1RWLFdBQ0VDLGFBQ21DRyxXQUFXO0FBQUE7QUFBQWdELEtBSHREMUM7QUFBZSxJQUFBMEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwidXN1YXJpb3NNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInRvYXN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiZ2V0QWxsIiwiVXN1YXJpb0VkaXRQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiaXRlbSIsInVzdWFyaW8iLCJsb2FkaW5nIiwiZXJyb3IiLCJzYXZlSXRlbSIsInByb2ZpbGVzIiwic2V0UHJvZmlsZXMiLCJ0aGVuIiwicmVzcG9uc2UiLCJkYXRhIiwiaGFuZGxlU2F2ZSIsInBheWxvYWQiLCJyb2xlX2lkIiwiTnVtYmVyIiwic2F2ZWQiLCJpbmZvIiwibmFtZSIsImZvcm1Db25maWciLCJuZXdDb25maWciLCJKU09OIiwicGFyc2UiLCJzdHJpbmdpZnkiLCJmb3JtIiwiYmxvY2siLCJtYXAiLCJ1cGRhdGVkRmllbGRzIiwiZmllbGRzIiwiZmllbGQiLCJvcHRpb25zIiwicCIsInZhbHVlIiwibGFiZWwiLCJmaWx0ZXIiLCJpbml0aWFsRGF0YSIsInVuZGVmaW5lZCIsInByZXBhcmVkRGF0YSIsInJvbGVzIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVXN1YXJpb3NFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL3VzdWFyaW9zL3BhZ2VzL1VzdWFyaW9FZGl0UGFnZS50c3hcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyB1c3Vhcmlvc01vZHVsZUNvbmZpZywgdHlwZSBVc3VhcmlvIH0gZnJvbSAnLi4vdXN1YXJpb3MuY29uZmlnLnRzeCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHR5cGUgeyBQcm9maWxlIH0gZnJvbSAnLi4vLi4vcHJvZmlsZXMvcHJvZmlsZXMuY29uZmlnLnRzeCc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0QWxsIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZS50cyc7XG5pbXBvcnQgdHlwZSB7IEZvcm1GaWVsZENvbmZpZyB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZS50cyc7XG5cbmV4cG9ydCBjb25zdCBVc3VhcmlvRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IHVzdWFyaW8sIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08VXN1YXJpbz4odXN1YXJpb3NNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCBbcHJvZmlsZXMsIHNldFByb2ZpbGVzXSA9IHVzZVN0YXRlPFByb2ZpbGVbXT4oW10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZ2V0QWxsPFByb2ZpbGU+KCdwcm9maWxlcycpLnRoZW4ocmVzcG9uc2UgPT4gc2V0UHJvZmlsZXMocmVzcG9uc2UuZGF0YSkpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogVXN1YXJpbykgPT4ge1xuICAgICAgICAvLyBDcmVhbW9zIHVuYSBjb3BpYSBwYXJhIG5vIG11dGFyIGVsIGVzdGFkb1xuICAgICAgICBjb25zdCBwYXlsb2FkID0geyAuLi5kYXRhIH07XG5cbiAgICAgICAgLy8gQXNlZ3VyYW1vcyBxdWUgcm9sZV9pZCBlcyB1biBuw7ptZXJvXG4gICAgICAgIGlmIChwYXlsb2FkLnJvbGVfaWQpIHtcbiAgICAgICAgICAgIHBheWxvYWQucm9sZV9pZCA9IE51bWJlcihwYXlsb2FkLnJvbGVfaWQpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc2F2ZWQgPSBhd2FpdCBzYXZlSXRlbShwYXlsb2FkKTtcbiAgICAgICAgaWYgKHNhdmVkKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKGBVc3VhcmlvIFwiJHtwYXlsb2FkLm5hbWV9XCIgYWN0dWFsaXphZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvY29uZmlndXJhY2lvbi91c3VhcmlvcycpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIENhbGN1bGFtb3MgbGEgY29uZmlndXJhY2nDs24gZGVsIGZvcm11bGFyaW8gY29uIGxvcyBwZXJmaWxlcyB5IHNpbiBsb3MgY2FtcG9zIGRlIGNvbnRyYXNlw7FhXG4gICAgY29uc3QgZm9ybUNvbmZpZyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdDb25maWcgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHVzdWFyaW9zTW9kdWxlQ29uZmlnKSk7XG5cbiAgICAgICAgbmV3Q29uZmlnLmZvcm0uYmxvY2sgPSBuZXdDb25maWcuZm9ybS5ibG9jay5tYXAoKGJsb2NrOiB7IGZpZWxkczogRm9ybUZpZWxkQ29uZmlnPFVzdWFyaW8+W10gfSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkcyA9IGJsb2NrLmZpZWxkc1xuICAgICAgICAgICAgICAgIC8vIDEuIElueWVjdGFtb3MgbGFzIG9wY2lvbmVzIGRlIHBlcmZpbGVzXG4gICAgICAgICAgICAgICAgLm1hcCgoZmllbGQ6IEZvcm1GaWVsZENvbmZpZzxVc3VhcmlvPikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQubmFtZSA9PT0gJ3JvbGVfaWQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZpZWxkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IHByb2ZpbGVzLm1hcChwID0+ICh7IHZhbHVlOiBwLmlkLCBsYWJlbDogcC5uYW1lIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmllbGQ7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAvLyAyLiBGaWx0cmFtb3MgbG9zIGNhbXBvcyBkZSBjb250cmFzZcOxYVxuICAgICAgICAgICAgICAgIC5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgIGZpZWxkID0+IGZpZWxkLm5hbWUgIT09ICdwYXNzd29yZCcgJiYgZmllbGQubmFtZSAhPT0gJ3Bhc3N3b3JkX2NvbmZpcm1hdGlvbidcbiAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICByZXR1cm4geyAuLi5ibG9jaywgZmllbGRzOiB1cGRhdGVkRmllbGRzIH07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBuZXdDb25maWc7XG4gICAgfSwgW3Byb2ZpbGVzXSk7IC8vIFNlIHJlY2FsY3VsYSBzb2xvIHNpIGxvcyBwZXJmaWxlcyBjYW1iaWFuXG5cbiAgICAvLyAtLS0g4pyFIEFKVVNURSBQUklOQ0lQQUwgLS0tXG4gICAgLy8gQWRhcHRhbW9zIGxvcyBkYXRvcyBpbmljaWFsZXMgcGFyYSBxdWUgZWwgb2JqZXRvIHNpZW1wcmUgc2VhIHVuICdVc3VhcmlvJyB2w6FsaWRvLlxuICAgIGNvbnN0IGluaXRpYWxEYXRhID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICghdXN1YXJpbykgcmV0dXJuIHVuZGVmaW5lZDtcblxuICAgICAgICAvLyBDcmVhbW9zIHVuYSBjb3BpYSBkZWwgdXN1YXJpby4gRXN0ZSBvYmpldG8geWEgY3VtcGxlIGNvbiBlbCB0aXBvICdVc3VhcmlvJy5cbiAgICAgICAgY29uc3QgcHJlcGFyZWREYXRhID0geyAuLi51c3VhcmlvIH07XG5cbiAgICAgICAgLy8gU2kgbGEgQVBJIG5vcyBkZXZ1ZWx2ZSBsYSByZWxhY2nDs24gJ3JvbGVzJywgbGEgdXNhbW9zIHBhcmEgc29icmVlc2NyaWJpciAncm9sZV9pZCcuXG4gICAgICAgIC8vIEVzdG8gYXNlZ3VyYSBxdWUgJ3JvbGVfaWQnIHNpZW1wcmUgc2VhIHVuIG7Dum1lcm8geSBwcm92ZW5nYSBkZSBsYSBmdWVudGUgZGUgdmVyZGFkIG3DoXMgcmVjaWVudGUuXG4gICAgICAgIGlmICh1c3VhcmlvLnJvbGVzICYmIHVzdWFyaW8ucm9sZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgcHJlcGFyZWREYXRhLnJvbGVfaWQgPSB1c3VhcmlvLnJvbGVzWzBdLmlkO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gU2kgbm8gaGF5ICdyb2xlcycsIG5vIGhhY2Vtb3MgbmFkYSwgeSBzZSB1c2Fyw6EgZWwgJ3JvbGVfaWQnIHF1ZSB5YSB2ZW7DrWEgZW4gZWwgb2JqZXRvICd1c3VhcmlvJy5cbiAgICAgICAgcmV0dXJuIHByZXBhcmVkRGF0YTtcbiAgICB9LCBbdXN1YXJpb10pO1xuXG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGF0b3MgZGVsIHVzdWFyaW8uLi48L2Rpdj47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghaW5pdGlhbERhdGEpIHJldHVybiA8ZGl2PlVzdWFyaW8gbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e2Zvcm1Db25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbERhdGF9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiZWRpdFwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3VzdWFyaW9zL3BhZ2VzL1VzdWFyaW9zRWRpdFBhZ2UudHN4In0=